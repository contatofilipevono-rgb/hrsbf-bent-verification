import H12CloudChart0Data086

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound21983 : H12AffineFastState.Bounded env21983 := by
  intro p hp
  have h : env21983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21982_21983 : H12AffineEnvironment.transform 4 16 env21982 = env21983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21982 == env21983) = true)

theorem identity21983 : scanCanonicalize (H12AffineFastState.compose env21983 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21983 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21984 : List Nat := [2,4,8,0,0,64,9,5,65,69,0,65,8,65,0,67,64,64,68,1,0,1,65,66,9,65,1,65,64,1,5,64,4,64,0,0]

theorem envBound21984 : H12AffineFastState.Bounded env21984 := by
  intro p hp
  have h : env21984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21983_21984 : H12AffineEnvironment.transform 3 0 env21983 = env21984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21983 == env21984) = true)

theorem identity21984 : scanCanonicalize (H12AffineFastState.compose env21984 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21985 : List Nat := [2,4,8,0,0,0,9,5,1,5,0,1,8,1,0,3,0,0,4,1,0,1,1,2,9,1,1,1,0,1,5,0,4,0,0,0]

theorem envBound21985 : H12AffineFastState.Bounded env21985 := by
  intro p hp
  have h : env21985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21984_21985 : H12AffineEnvironment.transform 5 0 env21984 = env21985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21984 == env21985) = true)

theorem identity21985 : scanCanonicalize (H12AffineFastState.compose env21985 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21985 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21986 : List Nat := [2,4,2,0,0,0,3,5,1,5,0,1,2,1,0,3,0,0,4,1,0,1,1,2,3,1,1,1,0,1,5,0,4,0,0,0]

theorem envBound21986 : H12AffineFastState.Bounded env21986 := by
  intro p hp
  have h : env21986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21985_21986 : H12AffineEnvironment.transform 2 2 env21985 = env21986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21985 == env21986) = true)

def env21987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318701,466225,8328,65,4456925,313836,449005,138476,148940,4466848,257,21792,46213,221722]

theorem envBound21987 : H12AffineFastState.Bounded env21987 := by
  intro p hp
  have h : env21987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21886_21987 : H12AffineEnvironment.transform 20 151633 env21886 = env21987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env21886 == env21987) = true)

theorem identity21987 : scanCanonicalize (H12AffineFastState.compose env21987 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21987 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env21988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318564,466225,8193,65,4456788,313701,448868,138341,148805,4466729,257,21792,46092,221722]

theorem envBound21988 : H12AffineFastState.Bounded env21988 := by
  intro p hp
  have h : env21988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21987_21988 : H12AffineEnvironment.transform 6 9 env21987 = env21988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21987 == env21988) = true)

def env21989 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,262144,273,32769,151633,4194304,317812,464929,8193,65,4456788,313701,448868,137589,147541,4466729,257,20528,45340,221722]

theorem envBound21989 : H12AffineFastState.Bounded env21989 := by
  intro p hp
  have h : env21989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21988_21989 : H12AffineEnvironment.transform 9 272 env21988 = env21989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21988 == env21989) = true)

theorem identity21989 : scanCanonicalize (H12AffineFastState.compose env21989 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 235554) := by decide +kernel

theorem selectedBound21989 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env21990 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,235554,273,32769,151633,4194304,213334,32771,8193,65,4430198,217415,82246,137589,147541,4435979,257,20528,45340,221722]

theorem envBound21990 : H12AffineFastState.Bounded env21990 := by
  intro p hp
  have h : env21990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21989_21990 : H12AffineEnvironment.transform 17 235554 env21989 = env21990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 235554 env21989 == env21990) = true)

def env21991 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,235554,273,32769,151633,180320,213334,32771,8193,65,88342,217415,82246,137589,147541,94315,257,20528,45340,221722]

theorem envBound21991 : H12AffineFastState.Bounded env21991 := by
  intro p hp
  have h : env21991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21990_21991 : H12AffineEnvironment.transform 21 180320 env21990 = env21991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180320 env21990 == env21991) = true)

theorem identity21991 : scanCanonicalize (H12AffineFastState.compose env21991 (packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound21991 : packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21992 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,32768,65536,131072,235554,273,32769,139549,176428,208922,32771,8193,65,75866,204811,77834,137589,143641,65831,257,8572,45340,201558]

theorem envBound21992 : H12AffineFastState.Bounded env21992 := by
  intro p hp
  have h : env21992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21991_21992 : H12AffineEnvironment.transform 13 12620 env21991 = env21992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env21991 == env21992) = true)

theorem identity21992 : scanCanonicalize (H12AffineFastState.compose env21992 (packedSelected [0,1,8,9,18,22,23,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 77915) := by decide +kernel

theorem selectedBound21992 : packedSelected [0,1,8,9,18,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env21993 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,32768,65536,77915,43129,273,32769,69958,98679,65,32771,8193,65,75866,4176,77834,76078,65858,65831,257,8572,45340,8973]

theorem envBound21993 : H12AffineFastState.Bounded env21993 := by
  intro p hp
  have h : env21993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21992_21993 : H12AffineEnvironment.transform 16 77915 env21992 = env21993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 77915 env21992 == env21993) = true)

theorem identity21993 : scanCanonicalize (H12AffineFastState.compose env21993 (packedSelected [0,2,4,6,7,9,12,14,15,16,17,18,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound21993 : packedSelected [0,2,4,6,7,9,12,14,15,16,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env21994 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,80,65536,77915,10281,273,81,69958,65831,65,83,8193,65,75866,4176,77834,76078,65858,65831,257,8572,12620,8973]

theorem envBound21994 : H12AffineFastState.Bounded env21994 := by
  intro p hp
  have h : env21994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21993_21994 : H12AffineEnvironment.transform 14 80 env21993 = env21994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env21993 == env21994) = true)

theorem identity21994 : scanCanonicalize (H12AffineFastState.compose env21994 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound21994 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21995 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,80,262,12637,10281,273,81,4160,33,65,83,8193,65,10588,4176,12556,10280,68,33,257,8572,12620,8973]

theorem envBound21995 : H12AffineFastState.Bounded env21995 := by
  intro p hp
  have h : env21995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21994_21995 : H12AffineEnvironment.transform 15 262 env21994 = env21995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env21994 == env21995) = true)

theorem identity21995 : scanCanonicalize (H12AffineFastState.compose env21995 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21995 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21996 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,80,262,4097,2421,273,81,4160,33,65,83,349,65,2048,4176,4176,2420,68,33,257,32,4112,593]

theorem envBound21996 : H12AffineFastState.Bounded env21996 := by
  intro p hp
  have h : env21996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21995_21996 : H12AffineEnvironment.transform 12 348 env21995 = env21996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21995 == env21996) = true)

theorem identity21996 : scanCanonicalize (H12AffineFastState.compose env21996 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2421) := by decide +kernel

theorem selectedBound21996 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21997 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2421,348,2405,80,262,2420,2421,273,81,2357,33,65,83,349,65,2048,2341,2341,2420,68,33,257,32,2405,593]

theorem envBound21997 : H12AffineFastState.Bounded env21997 := by
  intro p hp
  have h : env21997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21996_21997 : H12AffineEnvironment.transform 11 2421 env21996 = env21997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2421 env21996 == env21997) = true)

theorem identity21997 : scanCanonicalize (H12AffineFastState.compose env21997 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound21997 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env21998 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,80,348,64,80,262,81,80,273,81,16,33,65,83,349,65,293,0,0,81,68,33,257,32,64,593]

theorem envBound21998 : H12AffineFastState.Bounded env21998 := by
  intro p hp
  have h : env21998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21997_21998 : H12AffineEnvironment.transform 10 293 env21997 = env21998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21997 == env21998) = true)

theorem identity21998 : scanCanonicalize (H12AffineFastState.compose env21998 (packedSelected [3,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 127) := by decide +kernel

theorem selectedBound21998 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env21999 : List Nat := [2,4,8,16,32,64,9,127,512,111,90,80,35,64,80,121,81,80,110,81,16,33,65,83,34,65,90,0,0,81,68,33,126,32,64,593]

theorem envBound21999 : H12AffineFastState.Bounded env21999 := by
  intro p hp
  have h : env21999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21998_21999 : H12AffineEnvironment.transform 7 127 env21998 = env21999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 127 env21998 == env21999) = true)

theorem identity21999 : scanCanonicalize (H12AffineFastState.compose env21999 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound21999 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env22000 : List Nat := [2,4,8,16,32,59,9,4,512,20,33,43,35,59,43,2,42,43,21,42,16,33,58,40,34,58,33,0,0,42,63,33,5,32,59,554]

theorem envBound22000 : H12AffineFastState.Bounded env22000 := by
  intro p hp
  have h : env22000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21999_22000 : H12AffineEnvironment.transform 5 59 env21999 = env22000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env21999 == env22000) = true)

theorem identity22000 : scanCanonicalize (H12AffineFastState.compose env22000 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22000 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22001 : List Nat := [2,4,8,0,32,43,9,4,512,4,33,43,35,43,43,2,42,43,5,42,0,33,42,40,34,42,33,0,0,42,47,33,5,32,43,554]

theorem envBound22001 : H12AffineFastState.Bounded env22001 := by
  intro p hp
  have h : env22001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22000_22001 : H12AffineEnvironment.transform 3 0 env22000 = env22001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22000 == env22001) = true)

theorem identity22001 : scanCanonicalize (H12AffineFastState.compose env22001 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22001 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22002 : List Nat := [2,4,8,0,1,10,9,4,512,4,0,10,2,10,10,2,11,10,5,11,0,0,11,9,3,11,0,0,0,11,14,0,5,1,10,523]

theorem envBound22002 : H12AffineFastState.Bounded env22002 := by
  intro p hp
  have h : env22002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22001_22002 : H12AffineEnvironment.transform 4 1 env22001 = env22002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22001 == env22002) = true)

theorem identity22002 : scanCanonicalize (H12AffineFastState.compose env22002 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22002 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22003 : List Nat := [2,4,2,0,1,0,3,4,512,4,0,0,2,0,0,2,1,0,5,1,0,0,1,3,3,1,0,0,0,1,4,0,5,1,0,513]

theorem envBound22003 : H12AffineFastState.Bounded env22003 := by
  intro p hp
  have h : env22003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22002_22003 : H12AffineEnvironment.transform 2 2 env22002 = env22003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22002 == env22003) = true)

theorem identity22003 : scanCanonicalize (H12AffineFastState.compose env22003 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound22003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22004 : List Nat := [2,4,2,0,1,0,3,4,5,4,0,0,2,0,0,2,1,0,5,1,0,0,1,3,3,1,0,0,0,1,4,0,5,1,0,4]

theorem envBound22004 : H12AffineFastState.Bounded env22004 := by
  intro p hp
  have h : env22004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22003_22004 : H12AffineEnvironment.transform 8 5 env22003 = env22004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env22003 == env22004) = true)

theorem identity22004 : scanCanonicalize (H12AffineFastState.compose env22004 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound22004 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22005 : List Nat := [2,2,2,0,1,0,3,2,3,2,0,0,2,0,0,2,1,0,3,1,0,0,1,3,3,1,0,0,0,1,2,0,3,1,0,2]

theorem envBound22005 : H12AffineFastState.Bounded env22005 := by
  intro p hp
  have h : env22005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22004_22005 : H12AffineEnvironment.transform 1 2 env22004 = env22005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env22004 == env22005) = true)

theorem identity22005 : scanCanonicalize (H12AffineFastState.compose env22005 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22005 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22006 : List Nat := [1,1,1,0,1,0,0,1,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,1,0,0,1,0,1]

theorem envBound22006 : H12AffineFastState.Bounded env22006 := by
  intro p hp
  have h : env22006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22005_22006 : H12AffineEnvironment.transform 0 1 env22005 = env22006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22005 == env22006) = true)

def env22007 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,235554,273,32769,151633,180321,213334,32771,8193,65,88343,217415,82246,137589,147541,94314,257,20528,45340,221722]

theorem envBound22007 : H12AffineFastState.Bounded env22007 := by
  intro p hp
  have h : env22007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21990_22007 : H12AffineEnvironment.transform 21 180321 env21990 = env22007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180321 env21990 == env22007) = true)

theorem identity22007 : scanCanonicalize (H12AffineFastState.compose env22007 (packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound22007 : packedSelected [7,8,11,12,14,15,17,20,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env22008 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12573,32768,65536,131072,235554,273,32769,139596,176508,208971,32771,8193,65,75786,204890,77915,137589,143688,65911,257,8493,45340,201479]

theorem envBound22008 : H12AffineFastState.Bounded env22008 := by
  intro p hp
  have h : env22008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22007_22008 : H12AffineEnvironment.transform 13 12573 env22007 = env22008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env22007 == env22008) = true)

theorem identity22008 : scanCanonicalize (H12AffineFastState.compose env22008 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound22008 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env22009 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12573,32768,65536,69894,35108,273,32769,77898,106618,8525,32771,8193,65,75786,12636,77915,67699,73806,65911,257,8493,45340,513]

theorem envBound22009 : H12AffineFastState.Bounded env22009 := by
  intro p hp
  have h : env22009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22008_22009 : H12AffineEnvironment.transform 16 69894 env22008 = env22009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env22008 == env22009) = true)

theorem identity22009 : scanCanonicalize (H12AffineFastState.compose env22009 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22009 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22010 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4161,32768,65536,69894,35108,273,32769,69910,98598,17,32771,349,65,67926,4096,69895,67699,65810,65911,257,113,36928,513]

theorem envBound22010 : H12AffineFastState.Bounded env22010 := by
  intro p hp
  have h : env22010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22009_22010 : H12AffineEnvironment.transform 12 348 env22009 = env22010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22009 == env22010) = true)

theorem identity22010 : scanCanonicalize (H12AffineFastState.compose env22010 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound22010 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22011 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4161,32768,33031,36865,35108,273,32769,36881,33,17,32771,349,65,34897,4096,36864,35188,32789,32880,257,113,36928,513]

theorem envBound22011 : H12AffineFastState.Bounded env22011 := by
  intro p hp
  have h : env22011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22010_22011 : H12AffineEnvironment.transform 15 33031 env22010 = env22011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env22010 == env22011) = true)

def env22012 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,32768,65536,131072,262144,272,32769,151633,4194304,317813,464928,8193,65,4456788,313701,448868,137588,147540,4466729,257,20529,45341,221722]

theorem envBound22012 : H12AffineFastState.Bounded env22012 := by
  intro p hp
  have h : env22012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21988_22012 : H12AffineEnvironment.transform 9 273 env21988 = env22012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21988 == env22012) = true)

theorem identity22012 : scanCanonicalize (H12AffineFastState.compose env22012 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 110603) := by decide +kernel

theorem selectedBound22012 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env22013 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,32768,65536,110603,262144,272,32769,122970,4194304,317813,305195,8193,65,4456788,313701,354671,108927,127071,4466729,257,20529,45341,53777]

theorem envBound22013 : H12AffineFastState.Bounded env22013 := by
  intro p hp
  have h : env22013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22012_22013 : H12AffineEnvironment.transform 16 110603 env22012 = env22013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110603 env22012 == env22013) = true)

def env22014 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,65536,110603,262144,272,32769,122890,4194304,317733,305195,8193,17,4456708,313653,354623,108847,126991,4466729,257,20529,45341,53777]

theorem envBound22014 : H12AffineFastState.Bounded env22014 := by
  intro p hp
  have h : env22014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22013_22014 : H12AffineEnvironment.transform 5 16 env22013 = env22014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22013 == env22014) = true)

theorem identity22014 : scanCanonicalize (H12AffineFastState.compose env22014 (packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound22014 : packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env22015 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,65536,110603,262144,272,32769,122890,65830,317733,305195,8193,17,327714,313653,354623,108847,126991,338191,257,20529,45341,53777]

theorem envBound22015 : H12AffineFastState.Bounded env22015 := by
  intro p hp
  have h : env22015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22014_22015 : H12AffineEnvironment.transform 21 65830 env22014 = env22015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env22014 == env22015) = true)

theorem identity22015 : scanCanonicalize (H12AffineFastState.compose env22015 (packedSelected [0,2,5,6,7,17,20,21,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 22836) := by decide +kernel

theorem selectedBound22015 : packedSelected [0,2,5,6,7,17,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env22016 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,65536,110603,22836,272,32769,122890,65830,32785,61727,8193,17,88342,36865,77835,108847,126991,94267,257,20529,45341,53777]

theorem envBound22016 : H12AffineFastState.Bounded env22016 := by
  intro p hp
  have h : env22016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22015_22016 : H12AffineEnvironment.transform 17 22836 env22015 = env22016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22836 env22015 == env22016) = true)

theorem identity22016 : scanCanonicalize (H12AffineFastState.compose env22016 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22016 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env22017 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,32768,262,45325,22836,272,32769,57612,32,32785,61727,8193,17,22544,36865,12557,43049,61705,28989,257,20529,45341,53777]

theorem envBound22017 : H12AffineFastState.Bounded env22017 := by
  intro p hp
  have h : env22017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22016_22017 : H12AffineEnvironment.transform 15 262 env22016 = env22017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22016 == env22017) = true)

theorem identity22017 : scanCanonicalize (H12AffineFastState.compose env22017 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound22017 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22018 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,8460,262,4097,22836,272,8461,16384,32,8477,20499,8193,17,22544,12557,12557,2341,20485,28989,257,20529,4113,29469]

theorem envBound22018 : H12AffineFastState.Bounded env22018 := by
  intro p hp
  have h : env22018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22017_22018 : H12AffineEnvironment.transform 14 8460 env22017 = env22018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env22017 == env22018) = true)

theorem identity22018 : scanCanonicalize (H12AffineFastState.compose env22018 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound22018 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env22019 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2367,8192,16384,8460,262,2366,16395,272,8461,16384,32,8477,18732,8193,17,16687,10290,10290,2341,18746,26626,257,18702,2350,27170]

theorem envBound22019 : H12AffineFastState.Bounded env22019 := by
  intro p hp
  have h : env22019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22018_22019 : H12AffineEnvironment.transform 11 2367 env22018 = env22019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env22018 == env22019) = true)

theorem identity22019 : scanCanonicalize (H12AffineFastState.compose env22019 (packedSelected [0,1,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22019 : packedSelected [0,1,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22020 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2367,269,16384,1,262,2366,16395,272,0,16384,32,16,18732,268,17,16687,2367,2367,2341,18746,18703,257,18702,2350,19247]

theorem envBound22020 : H12AffineFastState.Bounded env22020 := by
  intro p hp
  have h : env22020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22019_22020 : H12AffineEnvironment.transform 12 269 env22019 = env22020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22019 == env22020) = true)

theorem identity22020 : scanCanonicalize (H12AffineFastState.compose env22020 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound22020 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22021 : List Nat := [2,4,8,16,32,16,9,53,512,36,2048,2058,56,16384,1,51,2059,16395,37,0,16384,32,16,18457,57,17,16410,2058,2058,2064,18447,18490,52,18491,2075,18970]

theorem envBound22021 : H12AffineFastState.Bounded env22021 := by
  intro p hp
  have h : env22021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22020_22021 : H12AffineEnvironment.transform 7 53 env22020 = env22021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env22020 == env22021) = true)

theorem identity22021 : scanCanonicalize (H12AffineFastState.compose env22021 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 2065) := by decide +kernel

theorem selectedBound22021 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env22022 : List Nat := [2,4,8,16,32,16,9,53,512,36,2048,2058,56,2065,1,51,2059,2074,37,0,2065,32,16,8,57,17,2059,2058,2058,2064,30,43,52,42,2075,523]

theorem envBound22022 : H12AffineFastState.Bounded env22022 := by
  intro p hp
  have h : env22022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22021_22022 : H12AffineEnvironment.transform 13 2065 env22021 = env22022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2065 env22021 == env22022) = true)

theorem identity22022 : scanCanonicalize (H12AffineFastState.compose env22022 (packedSelected [1,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound22022 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env22023 : List Nat := [2,4,8,16,32,16,9,53,512,36,43,33,56,58,1,51,32,49,37,0,58,32,16,8,57,17,32,33,33,59,30,43,52,42,48,523]

theorem envBound22023 : H12AffineFastState.Bounded env22023 := by
  intro p hp
  have h : env22023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22022_22023 : H12AffineEnvironment.transform 10 43 env22022 = env22023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env22022 == env22023) = true)

theorem identity22023 : scanCanonicalize (H12AffineFastState.compose env22023 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22023 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22024 : List Nat := [2,4,8,1,32,1,9,36,512,36,43,33,41,43,1,34,32,32,37,0,43,32,1,8,40,0,32,33,33,42,15,43,37,42,33,523]

theorem envBound22024 : H12AffineFastState.Bounded env22024 := by
  intro p hp
  have h : env22024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22023_22024 : H12AffineEnvironment.transform 3 1 env22023 = env22024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22023 == env22024) = true)

theorem identity22024 : scanCanonicalize (H12AffineFastState.compose env22024 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound22024 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env22025 : List Nat := [2,4,8,1,32,1,9,36,5,36,43,33,41,43,1,34,32,32,37,0,43,32,1,8,40,0,32,33,33,42,15,43,37,42,33,14]

theorem envBound22025 : H12AffineFastState.Bounded env22025 := by
  intro p hp
  have h : env22025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22024_22025 : H12AffineEnvironment.transform 8 5 env22024 = env22025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env22024 == env22025) = true)

theorem identity22025 : scanCanonicalize (H12AffineFastState.compose env22025 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound22025 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22026 : List Nat := [2,4,1,1,32,1,0,36,5,36,34,33,32,34,1,34,32,32,37,0,34,32,1,1,33,0,32,33,33,35,6,34,37,35,33,7]

theorem envBound22026 : H12AffineFastState.Bounded env22026 := by
  intro p hp
  have h : env22026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22025_22026 : H12AffineEnvironment.transform 2 1 env22025 = env22026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env22025 == env22026) = true)

def env22027 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,32768,65536,110603,262144,272,32769,122891,4194304,317732,305195,8193,16,4456709,313652,354622,108846,126990,4466729,257,20529,45341,53777]

theorem envBound22027 : H12AffineFastState.Bounded env22027 := by
  intro p hp
  have h : env22027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22013_22027 : H12AffineEnvironment.transform 5 17 env22013 = env22027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22013 == env22027) = true)

theorem identity22027 : scanCanonicalize (H12AffineFastState.compose env22027 (packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 22836) := by decide +kernel

theorem selectedBound22027 : packedSelected [7,12,14,15,17,18,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env22028 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,32768,65536,110603,22836,272,32769,122891,4194304,32784,61727,8193,16,4216881,36864,77834,108846,126990,4223261,257,20529,45341,53777]

theorem envBound22028 : H12AffineFastState.Bounded env22028 := by
  intro p hp
  have h : env22028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22027_22028 : H12AffineEnvironment.transform 17 22836 env22027 = env22028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22836 env22027 == env22028) = true)

theorem identity22028 : scanCanonicalize (H12AffineFastState.compose env22028 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,16,20,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound22028 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,16,20,21,26] rootPS < 2^1333 := by decide +kernel

def env22029 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,32768,65536,110603,10280,272,32769,102679,4194304,32784,32771,8193,16,4204845,36864,77834,108846,98578,4194305,257,8493,45341,41741]

theorem envBound22029 : H12AffineFastState.Bounded env22029 := by
  intro p hp
  have h : env22029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22028_22029 : H12AffineEnvironment.transform 13 12572 env22028 = env22029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env22028 == env22029) = true)

theorem identity22029 : scanCanonicalize (H12AffineFastState.compose env22029 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound22029 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22030 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,8460,65536,69895,10280,272,8461,77851,4194304,8476,8463,8193,16,4204845,12556,77834,67618,73758,4194305,257,8493,4113,513]

theorem envBound22030 : H12AffineFastState.Bounded env22030 := by
  intro p hp
  have h : env22030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22029_22030 : H12AffineEnvironment.transform 14 8460 env22029 = env22030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env22029 == env22030) = true)

theorem identity22030 : scanCanonicalize (H12AffineFastState.compose env22030 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22030 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22031 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,1,65536,69895,2341,272,0,69910,4194304,17,2,268,16,4196384,4097,69895,67618,65811,4194305,257,32,4113,513]

theorem envBound22031 : H12AffineFastState.Bounded env22031 := by
  intro p hp
  have h : env22031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22030_22031 : H12AffineEnvironment.transform 12 269 env22030 = env22031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22030 == env22031) = true)

theorem identity22031 : scanCanonicalize (H12AffineFastState.compose env22031 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound22031 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22032 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,1,263,4096,2341,272,0,4113,4194304,17,2,268,16,4196384,4097,4096,2341,20,4194305,257,32,4113,513]

theorem envBound22032 : H12AffineFastState.Bounded env22032 := by
  intro p hp
  have h : env22032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22031_22032 : H12AffineEnvironment.transform 15 263 env22031 = env22032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env22031 == env22032) = true)

theorem identity22032 : scanCanonicalize (H12AffineFastState.compose env22032 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound22032 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22033 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,1,263,4096,2341,272,0,4113,32,17,2,268,16,2048,4097,4096,2341,20,33,257,32,4113,513]

theorem envBound22033 : H12AffineFastState.Bounded env22033 := by
  intro p hp
  have h : env22033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22032_22033 : H12AffineEnvironment.transform 21 32 env22032 = env22033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22032 == env22033) = true)

theorem identity22033 : scanCanonicalize (H12AffineFastState.compose env22033 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound22033 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22034 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,261,269,276,1,263,261,2341,272,0,276,32,17,2,268,16,2048,260,261,2341,20,33,257,32,276,513]

theorem envBound22034 : H12AffineFastState.Bounded env22034 := by
  intro p hp
  have h : env22034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22033_22034 : H12AffineEnvironment.transform 11 261 env22033 = env22034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env22033 == env22034) = true)

theorem identity22034 : scanCanonicalize (H12AffineFastState.compose env22034 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound22034 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22035 : List Nat := [2,4,8,16,32,17,9,256,512,273,10,261,269,276,1,263,261,303,272,0,276,32,17,2,268,16,10,260,261,303,20,33,257,32,276,513]

theorem envBound22035 : H12AffineFastState.Bounded env22035 := by
  intro p hp
  have h : env22035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22034_22035 : H12AffineEnvironment.transform 10 10 env22034 = env22035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env22034 == env22035) = true)

theorem identity22035 : scanCanonicalize (H12AffineFastState.compose env22035 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound22035 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22036 : List Nat := [2,4,8,16,32,17,9,256,308,273,10,261,269,276,1,263,261,303,272,0,276,32,17,2,268,16,10,260,261,303,20,33,257,32,276,309]

theorem envBound22036 : H12AffineFastState.Bounded env22036 := by
  intro p hp
  have h : env22036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22035_22036 : H12AffineEnvironment.transform 8 308 env22035 = env22036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env22035 == env22036) = true)

theorem identity22036 : scanCanonicalize (H12AffineFastState.compose env22036 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22036 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22037 : List Nat := [2,4,2,16,32,17,3,256,308,273,0,261,263,276,1,263,261,293,272,0,276,32,17,2,262,16,0,260,261,293,20,33,257,32,276,309]

theorem envBound22037 : H12AffineFastState.Bounded env22037 := by
  intro p hp
  have h : env22037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22036_22037 : H12AffineEnvironment.transform 2 2 env22036 = env22037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22036 == env22037) = true)

theorem identity22037 : scanCanonicalize (H12AffineFastState.compose env22037 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound22037 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22038 : List Nat := [2,4,2,16,32,17,3,50,6,35,0,55,53,38,1,53,55,23,34,0,38,32,17,2,52,16,0,54,55,23,20,33,51,32,38,7]

theorem envBound22038 : H12AffineFastState.Bounded env22038 := by
  intro p hp
  have h : env22038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22037_22038 : H12AffineEnvironment.transform 7 50 env22037 = env22038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env22037 == env22038) = true)

theorem identity22038 : scanCanonicalize (H12AffineFastState.compose env22038 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22038 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22039 : List Nat := [2,4,2,16,1,17,3,19,6,2,0,22,20,7,1,20,22,23,3,0,7,1,17,2,21,16,0,23,22,23,20,0,18,1,7,7]

theorem envBound22039 : H12AffineFastState.Bounded env22039 := by
  intro p hp
  have h : env22039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22038_22039 : H12AffineEnvironment.transform 4 1 env22038 = env22039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22038 == env22039) = true)

def env22040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound22040 : H12AffineFastState.Bounded env22040 := by
  intro p hp
  have h : env22040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21617_22040 : H12AffineEnvironment.transform 26 30393345 env21617 = env22040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env21617 == env22040) = true)

def env22041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound22041 : H12AffineFastState.Bounded env22041 := by
  intro p hp
  have h : env22041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22040_22041 : H12AffineEnvironment.transform 18 1024 env22040 = env22041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22040 == env22041) = true)

theorem identity22041 : scanCanonicalize (H12AffineFastState.compose env22041 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898593) := by decide +kernel

theorem selectedBound22041 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898593,8328,65,4196384,10898604,10507601,8830977,412721,15117792,256,2493580,2551081,486374]

theorem envBound22042 : H12AffineFastState.Bounded env22042 := by
  intro p hp
  have h : env22042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22041_22042 : H12AffineEnvironment.transform 23 8898593 env22041 = env22042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898593 env22041 == env22042) = true)

def env22043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,8388608,8898593,8328,65,4196384,8393984,8785149,8830977,412721,12645452,256,21792,46213,486374]

theorem envBound22043 : H12AffineFastState.Bounded env22043 := by
  intro p hp
  have h : env22043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22042_22043 : H12AffineEnvironment.transform 20 416172 env22042 = env22043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416172 env22042 == env22043) = true)

def env22044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441640,95497,8328,65,4196384,436264,45525,32041,412721,4606308,256,21792,46213,486374]

theorem envBound22044 : H12AffineFastState.Bounded env22044 := by
  intro p hp
  have h : env22044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22043_22044 : H12AffineEnvironment.transform 22 441640 env22043 = env22044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env22043 == env22044) = true)

def env22045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441640,95497,8328,65,270496,436264,45525,32041,412721,156132,256,21792,46213,486374]

theorem envBound22045 : H12AffineFastState.Bounded env22045 := by
  intro p hp
  have h : env22045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22044_22045 : H12AffineEnvironment.transform 21 272512 env22044 = env22045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22044 == env22045) = true)

theorem identity22045 : scanCanonicalize (H12AffineFastState.compose env22045 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound22045 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,115871,243123,73755,95497,8328,65,245139,79131,45525,32041,119042,156132,256,21792,46213,63189]

theorem envBound22046 : H12AffineFastState.Bounded env22046 := by
  intro p hp
  have h : env22046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22045_22046 : H12AffineEnvironment.transform 17 236851 env22045 = env22046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env22045 == env22046) = true)

def env22047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,67755,1024,32769,115871,73771,73755,95497,8328,65,75787,79131,45525,32041,119042,62588,256,21792,46213,63189]

theorem envBound22047 : H12AffineFastState.Bounded env22047 := by
  intro p hp
  have h : env22047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22046_22047 : H12AffineEnvironment.transform 16 38296 env22046 = env22047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env22046 == env22047) = true)

theorem identity22047 : scanCanonicalize (H12AffineFastState.compose env22047 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound22047 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env22048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,38296,64929,1024,32769,12693,54561,54545,32771,8328,65,56577,49169,45525,32041,9224,62588,256,21792,46213,63189]

theorem envBound22048 : H12AffineFastState.Bounded env22048 := by
  intro p hp
  have h : env22048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22047_22048 : H12AffineEnvironment.transform 15 62730 env22047 = env22048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env22047 == env22048) = true)

theorem identity22048 : scanCanonicalize (H12AffineFastState.compose env22048 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound22048 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env22049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,342,25028,2557,1024,29789,12693,8573,8525,29791,8328,65,10589,13389,17801,32041,9224,32,256,21792,16601,649]

theorem envBound22049 : H12AffineFastState.Bounded env22049 := by
  intro p hp
  have h : env22049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22048_22049 : H12AffineEnvironment.transform 14 29788 env22048 = env22049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env22048 == env22049) = true)

theorem identity22049 : scanCanonicalize (H12AffineFastState.compose env22049 (packedSelected [0,1,2,3,5,6,7,8,10,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 12740) := by decide +kernel

theorem selectedBound22049 : packedSelected [0,1,2,3,5,6,7,8,10,16,17,19] rootPS < 2^1333 := by decide +kernel

def env22050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12740,1432,342,4096,2557,1024,1433,12693,8573,8525,1435,8328,65,10589,13389,13389,3309,9224,32,256,9444,12573,649]

theorem envBound22050 : H12AffineFastState.Bounded env22050 := by
  intro p hp
  have h : env22050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22049_22050 : H12AffineEnvironment.transform 13 12740 env22049 = env22050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12740 env22049 == env22050) = true)

theorem identity22050 : scanCanonicalize (H12AffineFastState.compose env22050 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22050 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env22051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,1297,342,4096,2420,1024,1296,12572,8573,8525,1298,8193,65,10589,13389,13389,3172,9224,32,256,9325,12573,512]

theorem envBound22051 : H12AffineFastState.Bounded env22051 := by
  intro p hp
  have h : env22051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22050_22051 : H12AffineEnvironment.transform 6 9 env22050 = env22051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22050 == env22051) = true)

theorem identity22051 : scanCanonicalize (H12AffineFastState.compose env22051 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound22051 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,4145,1297,342,4096,2420,1024,1296,4192,1,49,1298,381,65,2081,5425,5425,3172,1396,32,256,1297,4193,512]

theorem envBound22052 : H12AffineFastState.Bounded env22052 := by
  intro p hp
  have h : env22052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22051_22052 : H12AffineEnvironment.transform 12 380 env22051 = env22052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env22051 == env22052) = true)

theorem identity22052 : scanCanonicalize (H12AffineFastState.compose env22052 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound22052 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22053 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,380,4145,373,342,4096,2420,100,372,4192,1,49,374,381,65,2081,4437,4437,2048,272,32,256,373,4193,512]

theorem envBound22053 : H12AffineFastState.Bounded env22053 := by
  intro p hp
  have h : env22053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22052_22053 : H12AffineEnvironment.transform 9 100 env22052 = env22053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env22052 == env22053) = true)

theorem identity22053 : scanCanonicalize (H12AffineFastState.compose env22053 (packedSelected [1,2,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound22053 : packedSelected [1,2,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env22054 : List Nat := [2,4,8,16,32,64,9,256,512,100,260,4096,380,4145,373,342,4096,112,100,372,4192,1,49,374,381,65,293,4437,4437,260,272,32,256,373,4193,512]

theorem envBound22054 : H12AffineFastState.Bounded env22054 := by
  intro p hp
  have h : env22054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22053_22054 : H12AffineEnvironment.transform 10 260 env22053 = env22054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env22053 == env22054) = true)

theorem identity22054 : scanCanonicalize (H12AffineFastState.compose env22054 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22054 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env22055 : List Nat := [2,4,8,16,32,64,9,4,512,100,0,4096,120,4145,113,82,4096,112,100,112,4192,1,49,114,121,65,33,4177,4177,0,20,32,4,113,4193,512]

theorem envBound22055 : H12AffineFastState.Bounded env22055 := by
  intro p hp
  have h : env22055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22054_22055 : H12AffineEnvironment.transform 7 4 env22054 = env22055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22054 == env22055) = true)

theorem identity22055 : scanCanonicalize (H12AffineFastState.compose env22055 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22055 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22056 : List Nat := [2,4,8,16,1,64,9,4,512,69,0,4096,89,4112,80,82,4096,81,69,81,4161,1,16,83,88,65,0,4177,4177,0,20,1,4,80,4160,512]

theorem envBound22056 : H12AffineFastState.Bounded env22056 := by
  intro p hp
  have h : env22056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22055_22056 : H12AffineEnvironment.transform 4 1 env22055 = env22056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22055 == env22056) = true)

theorem identity22056 : scanCanonicalize (H12AffineFastState.compose env22056 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound22056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22057 : List Nat := [2,4,8,16,1,64,9,4,512,69,0,64,89,80,80,82,64,81,69,81,1,1,16,83,88,65,0,17,17,0,20,1,4,80,0,512]

theorem envBound22057 : H12AffineFastState.Bounded env22057 := by
  intro p hp
  have h : env22057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22056_22057 : H12AffineEnvironment.transform 11 64 env22056 = env22057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env22056 == env22057) = true)

theorem identity22057 : scanCanonicalize (H12AffineFastState.compose env22057 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 21) := by decide +kernel

theorem selectedBound22057 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22058 : List Nat := [2,4,8,16,1,21,9,4,512,16,0,21,12,5,5,7,21,4,16,4,1,1,16,6,13,20,0,17,17,0,20,1,4,5,0,512]

theorem envBound22058 : H12AffineFastState.Bounded env22058 := by
  intro p hp
  have h : env22058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22057_22058 : H12AffineEnvironment.transform 5 21 env22057 = env22058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env22057 == env22058) = true)

theorem identity22058 : scanCanonicalize (H12AffineFastState.compose env22058 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound22058 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22059 : List Nat := [2,4,8,16,1,21,9,4,4,16,0,21,12,5,5,7,21,4,16,4,1,1,16,6,13,20,0,17,17,0,20,1,4,5,0,4]

theorem envBound22059 : H12AffineFastState.Bounded env22059 := by
  intro p hp
  have h : env22059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22058_22059 : H12AffineEnvironment.transform 8 4 env22058 = env22059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env22058 == env22059) = true)

theorem identity22059 : scanCanonicalize (H12AffineFastState.compose env22059 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22059 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22060 : List Nat := [2,4,8,0,1,5,9,4,4,0,0,5,12,5,5,7,5,4,0,4,1,1,0,6,13,4,0,1,1,0,4,1,4,5,0,4]

theorem envBound22060 : H12AffineFastState.Bounded env22060 := by
  intro p hp
  have h : env22060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22059_22060 : H12AffineEnvironment.transform 3 0 env22059 = env22060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22059 == env22060) = true)

def env22061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,67754,1024,32769,115871,73770,73755,95497,8328,65,75786,79131,45525,32041,119042,62589,256,21792,46213,63189]

theorem envBound22061 : H12AffineFastState.Bounded env22061 := by
  intro p hp
  have h : env22061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22046_22061 : H12AffineEnvironment.transform 16 38297 env22046 = env22061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env22046 == env22061) = true)

theorem identity22061 : scanCanonicalize (H12AffineFastState.compose env22061 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound22061 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env22062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,38297,56572,1024,32769,4297,62588,62541,41311,8328,65,64604,57677,45525,32041,1364,62589,256,21792,46213,63189]

theorem envBound22062 : H12AffineFastState.Bounded env22062 := by
  intro p hp
  have h : env22062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22061_22062 : H12AffineEnvironment.transform 15 54358 env22061 = env22062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env22061 == env22062) = true)

theorem identity22062 : scanCanonicalize (H12AffineFastState.compose env22062 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound22062 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env22063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,54358,38297,56572,1024,32769,4297,54697,54680,32906,349,65,56713,49304,36864,23804,1364,54696,256,21792,38224,55040]

theorem envBound22063 : H12AffineFastState.Bounded env22063 := by
  intro p hp
  have h : env22063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22062_22063 : H12AffineEnvironment.transform 12 469 env22062 = env22063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env22062 == env22063) = true)

theorem identity22063 : scanCanonicalize (H12AffineFastState.compose env22063 (packedSelected [1,5,8,16,17,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound22063 : packedSelected [1,5,8,16,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env22064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,343,16536,2557,1024,21760,4297,168,153,21899,349,65,2184,5529,17665,23804,1364,169,256,21792,16465,513]

theorem envBound22064 : H12AffineFastState.Bounded env22064 := by
  intro p hp
  have h : env22064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22063_22064 : H12AffineEnvironment.transform 14 21761 env22063 = env22064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22063 == env22064) = true)

def env22065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441640,95497,8328,65,270497,436264,45525,32041,412721,156133,256,21792,46213,486374]

theorem envBound22065 : H12AffineFastState.Bounded env22065 := by
  intro p hp
  have h : env22065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22044_22065 : H12AffineEnvironment.transform 21 272513 env22044 = env22065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22044 == env22065) = true)

theorem identity22065 : scanCanonicalize (H12AffineFastState.compose env22065 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22065 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416172,272513,441640,21762,8328,65,270497,436264,45525,32041,412721,156133,256,21792,46213,412653]

theorem envBound22066 : H12AffineFastState.Bounded env22066 := by
  intro p hp
  have h : env22066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22065_22066 : H12AffineEnvironment.transform 15 8203 env22065 = env22066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22065 == env22066) = true)

def env22067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416036,272393,441640,21762,8192,65,270377,436264,45405,32041,412721,156013,256,21792,46093,412517]

theorem envBound22067 : H12AffineFastState.Bounded env22067 := by
  intro p hp
  have h : env22067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22066_22067 : H12AffineEnvironment.transform 6 8 env22066 = env22067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22066 == env22067) = true)

theorem identity22067 : scanCanonicalize (H12AffineFastState.compose env22067 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound22067 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env22068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8203,131072,262144,1024,29992,416036,272393,411649,21762,8192,65,270377,417025,17524,32041,412721,156013,256,21792,16676,412517]

theorem envBound22068 : H12AffineFastState.Bounded env22068 := by
  intro p hp
  have h : env22068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22067_22068 : H12AffineEnvironment.transform 14 29993 env22067 = env22068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env22067 == env22068) = true)

theorem identity22068 : scanCanonicalize (H12AffineFastState.compose env22068 (packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound22068 : packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8203,5221,262144,1024,29992,281921,272393,285796,21762,8192,65,270377,280932,17524,32041,284756,29960,256,21792,16676,286464]

theorem envBound22069 : H12AffineFastState.Bounded env22069 := by
  intro p hp
  have h : env22069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22068_22069 : H12AffineEnvironment.transform 16 5221 env22068 = env22069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env22068 == env22069) = true)

theorem identity22069 : scanCanonicalize (H12AffineFastState.compose env22069 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound22069 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env22070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8232,8203,5221,262144,1024,8233,268352,272393,264549,3,8192,65,270377,269413,4469,10280,265557,8201,256,33,5157,264705]

theorem envBound22070 : H12AffineFastState.Bounded env22070 := by
  intro p hp
  have h : env22070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22069_22070 : H12AffineEnvironment.transform 13 5377 env22069 = env22070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22069 == env22070) = true)

theorem identity22070 : scanCanonicalize (H12AffineFastState.compose env22070 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound22070 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env22071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3385,5377,3345,3378,5221,262144,1024,3344,268352,263472,264549,3,3385,65,265488,269413,4469,1297,265557,3376,256,33,5157,264705]

theorem envBound22071 : H12AffineFastState.Bounded env22071 := by
  intro p hp
  have h : env22071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22070_22071 : H12AffineEnvironment.transform 12 3385 env22070 = env22071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env22070 == env22071) = true)

theorem identity22071 : scanCanonicalize (H12AffineFastState.compose env22071 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound22071 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3385,5377,3345,3378,5221,2420,1024,3344,4404,3140,17,3,3385,65,1124,5393,4469,1297,1057,3376,256,33,5157,885]

theorem envBound22072 : H12AffineFastState.Bounded env22072 := by
  intro p hp
  have h : env22072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22071_22072 : H12AffineEnvironment.transform 17 2420 env22071 = env22072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env22071 == env22072) = true)

theorem identity22072 : scanCanonicalize (H12AffineFastState.compose env22072 (packedSelected [1,4,6,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound22072 : packedSelected [1,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env22073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,3385,1,3345,3378,357,2420,1024,3344,1076,3140,17,3,3385,65,1124,17,1141,1297,1057,3376,256,33,293,885]

theorem envBound22073 : H12AffineFastState.Bounded env22073 := by
  intro p hp
  have h : env22073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22072_22073 : H12AffineEnvironment.transform 11 1280 env22072 = env22073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env22072 == env22073) = true)

theorem identity22073 : scanCanonicalize (H12AffineFastState.compose env22073 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound22073 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1280,1100,1,1124,1095,357,1,1024,1125,1076,1329,17,3,1100,65,1124,17,1141,1297,1057,1093,256,33,293,885]

theorem envBound22074 : H12AffineFastState.Bounded env22074 := by
  intro p hp
  have h : env22074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22073_22074 : H12AffineEnvironment.transform 10 373 env22073 = env22074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env22073 == env22074) = true)

theorem identity22074 : scanCanonicalize (H12AffineFastState.compose env22074 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22074 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22075 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,1061,1100,1,1124,1095,64,1,1024,1125,1076,1044,17,3,1100,65,1124,17,1141,1076,1057,1093,37,33,0,592]

theorem envBound22075 : H12AffineFastState.Bounded env22075 := by
  intro p hp
  have h : env22075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22074_22075 : H12AffineEnvironment.transform 7 37 env22074 = env22075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22074 == env22075) = true)

theorem identity22075 : scanCanonicalize (H12AffineFastState.compose env22075 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound22075 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env22076 : List Nat := [2,4,8,16,32,64,8,37,512,542,80,571,594,1,634,601,64,1,542,635,554,522,17,3,594,65,634,17,619,554,575,603,37,33,0,592]

theorem envBound22076 : H12AffineFastState.Bounded env22076 := by
  intro p hp
  have h : env22076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22075_22076 : H12AffineEnvironment.transform 9 542 env22075 = env22076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env22075 == env22076) = true)

theorem identity22076 : scanCanonicalize (H12AffineFastState.compose env22076 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22076 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env22077 : List Nat := [2,4,8,16,1,64,8,4,512,542,80,538,594,1,603,601,64,1,542,602,523,522,17,3,594,65,603,17,586,523,542,603,4,0,0,592]

theorem envBound22077 : H12AffineFastState.Bounded env22077 := by
  intro p hp
  have h : env22077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22076_22077 : H12AffineEnvironment.transform 4 1 env22076 = env22077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22076 == env22077) = true)

theorem identity22077 : scanCanonicalize (H12AffineFastState.compose env22077 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22077 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22078 : List Nat := [2,4,8,16,1,16,8,4,512,542,0,538,514,1,523,521,16,1,542,522,523,522,17,3,514,17,523,17,538,523,542,523,4,0,0,512]

theorem envBound22078 : H12AffineFastState.Bounded env22078 := by
  intro p hp
  have h : env22078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22077_22078 : H12AffineEnvironment.transform 5 16 env22077 = env22078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22077 == env22078) = true)

theorem identity22078 : scanCanonicalize (H12AffineFastState.compose env22078 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound22078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22079 : List Nat := [2,4,8,16,1,16,8,4,10,20,0,16,8,1,1,3,16,1,20,0,1,0,17,3,8,17,1,17,16,1,20,1,4,0,0,10]

theorem envBound22079 : H12AffineFastState.Bounded env22079 := by
  intro p hp
  have h : env22079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22078_22079 : H12AffineEnvironment.transform 8 10 env22078 = env22079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env22078 == env22079) = true)

theorem identity22079 : scanCanonicalize (H12AffineFastState.compose env22079 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound22079 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22080 : List Nat := [2,0,8,16,1,16,8,0,10,16,0,16,8,1,1,3,16,1,16,0,1,0,17,3,8,17,1,17,16,1,16,1,0,0,0,10]

theorem envBound22080 : H12AffineFastState.Bounded env22080 := by
  intro p hp
  have h : env22080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22079_22080 : H12AffineEnvironment.transform 1 0 env22079 = env22080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env22079 == env22080) = true)

theorem identity22080 : scanCanonicalize (H12AffineFastState.compose env22080 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound22080 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22081 : List Nat := [2,0,8,3,1,3,8,0,10,3,0,3,8,1,1,3,3,1,3,0,1,0,2,3,8,2,1,2,3,1,3,1,0,0,0,10]

theorem envBound22081 : H12AffineFastState.Bounded env22081 := by
  intro p hp
  have h : env22081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22080_22081 : H12AffineEnvironment.transform 3 3 env22080 = env22081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env22080 == env22081) = true)

def env22082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,416037,272392,441640,21762,8193,65,270376,436264,45404,32041,412721,156012,256,21792,46092,412516]

theorem envBound22082 : H12AffineFastState.Bounded env22082 := by
  intro p hp
  have h : env22082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22066_22082 : H12AffineEnvironment.transform 6 9 env22066 = env22082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22066 == env22082) = true)

theorem identity22082 : scanCanonicalize (H12AffineFastState.compose env22082 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound22082 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env22083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,157752,1024,32769,12573,147504,54544,21762,8193,65,149520,49168,45404,32041,9225,156012,256,21792,46092,9052]

theorem envBound22083 : H12AffineFastState.Bounded env22083 := by
  intro p hp
  have h : env22083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22082_22083 : H12AffineEnvironment.transform 17 157752 env22082 = env22083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env22082 == env22083) = true)

theorem identity22083 : scanCanonicalize (H12AffineFastState.compose env22083 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound22083 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env22084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46157,56437,1024,32769,12573,62589,54544,21762,8193,65,64605,49168,45404,32041,9225,54561,256,21792,46092,9052]

theorem envBound22084 : H12AffineFastState.Bounded env22084 := by
  intro p hp
  have h : env22084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22083_22084 : H12AffineEnvironment.transform 16 46157 env22083 = env22084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env22083 == env22084) = true)

theorem identity22084 : scanCanonicalize (H12AffineFastState.compose env22084 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22084 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env22085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,13388,23668,1024,0,12573,29820,21777,21762,8193,65,31836,16401,12637,32041,9225,21792,256,21792,13325,9052]

theorem envBound22085 : H12AffineFastState.Bounded env22085 := by
  intro p hp
  have h : env22085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22084_22085 : H12AffineEnvironment.transform 14 1 env22084 = env22085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22084 == env22085) = true)

theorem identity22085 : scanCanonicalize (H12AffineFastState.compose env22085 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22085 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,1,35,5220,23668,1024,0,4405,21588,21777,21762,41,65,23668,16401,4469,23809,1057,21792,256,21792,5157,884]

theorem envBound22086 : H12AffineFastState.Bounded env22086 := by
  intro p hp
  have h : env22086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22085_22086 : H12AffineEnvironment.transform 12 40 env22085 = env22086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22085 == env22086) = true)

theorem identity22086 : scanCanonicalize (H12AffineFastState.compose env22086 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22086 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,1,35,5220,2048,1024,0,4405,32,357,374,41,65,2048,5221,4469,2421,1057,340,256,340,5157,884]

theorem envBound22087 : H12AffineFastState.Bounded env22087 := by
  intro p hp
  have h : env22087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22086_22087 : H12AffineEnvironment.transform 13 5236 env22086 = env22087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22086 == env22087) = true)

theorem identity22087 : scanCanonicalize (H12AffineFastState.compose env22087 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22087 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22088 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,1,35,5220,2048,1024,0,4160,32,16,3,41,65,2048,5221,4096,2048,1057,33,117,33,5157,513]

theorem envBound22088 : H12AffineFastState.Bounded env22088 := by
  intro p hp
  have h : env22088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22087_22088 : H12AffineEnvironment.transform 7 117 env22087 = env22088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22087 == env22088) = true)

theorem identity22088 : scanCanonicalize (H12AffineFastState.compose env22088 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound22088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22089 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,4096,40,5236,1,35,5220,1134,1024,0,4160,32,16,3,41,65,1134,5221,4096,1134,1057,33,117,33,5157,513]

theorem envBound22089 : H12AffineFastState.Bounded env22089 := by
  intro p hp
  have h : env22089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22088_22089 : H12AffineEnvironment.transform 10 1134 env22088 = env22089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env22088 == env22089) = true)

theorem identity22089 : scanCanonicalize (H12AffineFastState.compose env22089 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound22089 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22090 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,1125,40,17,1,35,1,1134,1024,0,1061,32,16,3,41,65,1134,0,1125,1134,1057,33,117,33,64,513]

theorem envBound22090 : H12AffineFastState.Bounded env22090 := by
  intro p hp
  have h : env22090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22089_22090 : H12AffineEnvironment.transform 11 1125 env22089 = env22090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env22089 == env22090) = true)

theorem identity22090 : scanCanonicalize (H12AffineFastState.compose env22090 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound22090 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22091 : List Nat := [2,4,8,16,32,64,9,117,512,110,0,11,40,17,1,35,1,0,110,0,75,32,16,3,41,65,0,0,11,0,79,33,117,33,64,513]

theorem envBound22091 : H12AffineFastState.Bounded env22091 := by
  intro p hp
  have h : env22091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22090_22091 : H12AffineEnvironment.transform 9 110 env22090 = env22091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env22090 == env22091) = true)

theorem identity22091 : scanCanonicalize (H12AffineFastState.compose env22091 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound22091 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22092 : List Nat := [2,4,8,16,32,59,9,14,512,21,0,11,40,17,1,35,1,0,21,0,48,32,16,3,41,58,0,0,11,0,52,33,14,33,59,513]

theorem envBound22092 : H12AffineFastState.Bounded env22092 := by
  intro p hp
  have h : env22092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22091_22092 : H12AffineEnvironment.transform 5 59 env22091 = env22092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env22091 == env22092) = true)

theorem identity22092 : scanCanonicalize (H12AffineFastState.compose env22092 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound22092 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env22093 : List Nat := [2,4,8,16,10,17,9,14,512,21,0,11,2,17,1,9,1,0,21,0,26,10,16,3,3,16,0,0,11,0,30,11,14,11,17,513]

theorem envBound22093 : H12AffineFastState.Bounded env22093 := by
  intro p hp
  have h : env22093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22092_22093 : H12AffineEnvironment.transform 4 10 env22092 = env22093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env22092 == env22093) = true)

theorem identity22093 : scanCanonicalize (H12AffineFastState.compose env22093 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound22093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22094 : List Nat := [2,4,8,10,10,11,9,14,512,15,0,11,2,11,1,9,1,0,15,0,0,10,10,3,3,10,0,0,11,0,4,11,14,11,11,513]

theorem envBound22094 : H12AffineFastState.Bounded env22094 := by
  intro p hp
  have h : env22094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22093_22094 : H12AffineEnvironment.transform 3 10 env22093 = env22094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env22093 == env22094) = true)

theorem identity22094 : scanCanonicalize (H12AffineFastState.compose env22094 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound22094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22095 : List Nat := [2,4,8,10,10,11,9,14,14,15,0,11,2,11,1,9,1,0,15,0,0,10,10,3,3,10,0,0,11,0,4,11,14,11,11,15]

theorem envBound22095 : H12AffineFastState.Bounded env22095 := by
  intro p hp
  have h : env22095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22094_22095 : H12AffineEnvironment.transform 8 14 env22094 = env22095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env22094 == env22095) = true)

def env22096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,4194304,441641,95496,8328,65,4196384,436265,45524,32040,412721,4606309,256,21792,46213,486374]

theorem envBound22096 : H12AffineFastState.Bounded env22096 := by
  intro p hp
  have h : env22096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22043_22096 : H12AffineEnvironment.transform 22 441641 env22043 = env22096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env22043 == env22096) = true)

def env22097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272512,441641,95496,8328,65,270496,436265,45524,32040,412721,156133,256,21792,46213,486374]

theorem envBound22097 : H12AffineFastState.Bounded env22097 := by
  intro p hp
  have h : env22097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22096_22097 : H12AffineEnvironment.transform 21 272512 env22096 = env22097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22096 == env22097) = true)

theorem identity22097 : scanCanonicalize (H12AffineFastState.compose env22097 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound22097 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,77899,213351,120014,95496,8328,65,215367,115150,45524,32040,75222,156133,256,21792,46213,513]

theorem envBound22098 : H12AffineFastState.Bounded env22098 := by
  intro p hp
  have h : env22098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22097_22098 : H12AffineEnvironment.transform 17 223719 env22097 = env22098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env22097 == env22098) = true)

def env22099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77899,213351,119878,95496,8192,65,215367,115014,45404,32040,75102,156013,256,21792,46093,513]

theorem envBound22099 : H12AffineFastState.Bounded env22099 := by
  intro p hp
  have h : env22099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22098_22099 : H12AffineEnvironment.transform 6 8 env22098 = env22099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22098 == env22099) = true)

theorem identity22099 : scanCanonicalize (H12AffineFastState.compose env22099 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound22099 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,2421,1024,32769,77899,8573,119878,95496,8192,65,10589,115014,45404,32040,75102,65911,256,21792,46093,513]

theorem envBound22100 : H12AffineFastState.Bounded env22100 := by
  intro p hp
  have h : env22100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22099_22100 : H12AffineEnvironment.transform 16 90138 env22099 = env22100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env22099 == env22100) = true)

theorem identity22100 : scanCanonicalize (H12AffineFastState.compose env22100 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound22100 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env22101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,90138,2421,1024,29709,77899,8573,73802,95496,8192,65,10589,79178,17744,32040,75102,65911,256,21792,16385,513]

theorem envBound22101 : H12AffineFastState.Bounded env22101 := by
  intro p hp
  have h : env22101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22100_22101 : H12AffineEnvironment.transform 14 29708 env22100 = env22101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env22100 == env22101) = true)

theorem identity22101 : scanCanonicalize (H12AffineFastState.compose env22101 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound22101 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env22102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,29962,5392,2421,1024,29709,17729,8573,21824,2,8192,65,10589,16448,17744,32040,20564,29821,256,21792,16385,513]

theorem envBound22102 : H12AffineFastState.Bounded env22102 := by
  intro p hp
  have h : env22102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22101_22102 : H12AffineEnvironment.transform 15 29962 env22101 = env22102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env22101 == env22102) = true)

theorem identity22102 : scanCanonicalize (H12AffineFastState.compose env22102 (packedSelected [2,3,5,6,10,12,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound22102 : packedSelected [2,3,5,6,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env22103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,372,114,5392,2421,1024,373,12345,8573,8248,2,8192,65,10589,13624,12328,2128,9516,261,256,8280,13689,513]

theorem envBound22103 : H12AffineFastState.Bounded env22103 := by
  intro p hp
  have h : env22103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22102_22103 : H12AffineEnvironment.transform 13 13688 env22102 = env22103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env22102 == env22103) = true)

theorem identity22103 : scanCanonicalize (H12AffineFastState.compose env22103 (packedSelected [2,3,5,6,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound22103 : packedSelected [2,3,5,6,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env22104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4405,372,114,5392,2421,1024,373,5236,1328,1141,2,1101,65,3344,4469,5221,2128,353,261,256,1045,4404,513]

theorem envBound22104 : H12AffineFastState.Bounded env22104 := by
  intro p hp
  have h : env22104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22103_22104 : H12AffineEnvironment.transform 12 1101 env22103 = env22104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env22103 == env22104) = true)

theorem identity22104 : scanCanonicalize (H12AffineFastState.compose env22104 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22104 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env22105 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,4405,293,35,5392,2340,1024,292,5157,1328,1060,2,1052,16,3344,4388,5172,2049,304,261,256,1045,4404,513]

theorem envBound22105 : H12AffineFastState.Bounded env22105 := by
  intro p hp
  have h : env22105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22104_22105 : H12AffineEnvironment.transform 5 17 env22104 = env22105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22104 == env22105) = true)

theorem identity22105 : scanCanonicalize (H12AffineFastState.compose env22105 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22105 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env22106 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,41,4405,293,35,4389,2340,53,292,4112,261,17,2,41,16,2341,4388,4097,2049,304,261,256,32,4404,513]

theorem envBound22106 : H12AffineFastState.Bounded env22106 := by
  intro p hp
  have h : env22106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22105_22106 : H12AffineEnvironment.transform 9 53 env22105 = env22106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22105 == env22106) = true)

def env22107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213351,119879,95496,8193,65,215367,115015,45405,32040,75103,156012,256,21792,46092,513]

theorem envBound22107 : H12AffineFastState.Bounded env22107 := by
  intro p hp
  have h : env22107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22098_22107 : H12AffineEnvironment.transform 6 9 env22098 = env22107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22098 == env22107) = true)

theorem identity22107 : scanCanonicalize (H12AffineFastState.compose env22107 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound22107 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env22108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,77899,33,119879,95496,8193,65,2049,115015,45405,32040,75103,73770,256,21792,46092,513]

theorem envBound22108 : H12AffineFastState.Bounded env22108 := by
  intro p hp
  have h : env22108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22107_22108 : H12AffineEnvironment.transform 16 82246 env22107 = env22108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env22107 == env22108) = true)

theorem identity22108 : scanCanonicalize (H12AffineFastState.compose env22108 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound22108 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env22109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,5393,10280,1024,32769,25628,33,32784,8543,8193,65,2049,38160,45405,32040,28936,29821,256,21792,46092,513]

theorem envBound22109 : H12AffineFastState.Bounded env22109 := by
  intro p hp
  have h : env22109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22108_22109 : H12AffineEnvironment.transform 15 21591 env22108 = env22109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env22108 == env22109) = true)

theorem identity22109 : scanCanonicalize (H12AffineFastState.compose env22109 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22109 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env22110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21591,5393,10280,1024,0,25628,33,17,8543,8193,65,2049,5393,12636,32040,28936,29821,256,21792,13325,513]

theorem envBound22110 : H12AffineFastState.Bounded env22110 := by
  intro p hp
  have h : env22110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22109_22110 : H12AffineEnvironment.transform 14 1 env22109 = env22110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22109 == env22110) = true)

theorem identity22110 : scanCanonicalize (H12AffineFastState.compose env22110 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22110 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,1,21591,5393,2340,1024,0,17680,33,17,83,269,65,2049,5393,4176,23588,20484,21873,256,21792,5377,513]

theorem envBound22111 : H12AffineFastState.Bounded env22111 := by
  intro p hp
  have h : env22111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22110_22111 : H12AffineEnvironment.transform 12 268 env22110 = env22111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22110 == env22111) = true)

theorem identity22111 : scanCanonicalize (H12AffineFastState.compose env22111 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound22111 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,343,5393,2340,1024,0,4112,33,17,83,269,65,2049,5393,4176,2340,1284,113,256,32,5377,513]

theorem envBound22112 : H12AffineFastState.Bounded env22112 := by
  intro p hp
  have h : env22112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22111_22112 : H12AffineEnvironment.transform 13 5376 env22111 = env22112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22111 == env22112) = true)

def env22113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416172,272513,441641,95496,8328,65,270497,436265,45524,32040,412721,156132,256,21792,46213,486374]

theorem envBound22113 : H12AffineFastState.Bounded env22113 := by
  intro p hp
  have h : env22113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22096_22113 : H12AffineEnvironment.transform 21 272513 env22096 = env22113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22096 == env22113) = true)

theorem identity22113 : scanCanonicalize (H12AffineFastState.compose env22113 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound22113 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,416172,272513,441641,41430,8328,65,270497,436265,45524,32040,412721,156132,256,21792,46213,442168]

theorem envBound22114 : H12AffineFastState.Bounded env22114 := by
  intro p hp
  have h : env22114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22113_22114 : H12AffineEnvironment.transform 15 54494 env22113 = env22114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env22113 == env22114) = true)

def env22115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416036,272393,441641,41310,8192,65,270377,436265,45404,32040,412721,156012,256,21792,46093,442168]

theorem envBound22115 : H12AffineFastState.Bounded env22115 := by
  intro p hp
  have h : env22115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22114_22115 : H12AffineEnvironment.transform 6 8 env22114 = env22115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22114 == env22115) = true)

theorem identity22115 : scanCanonicalize (H12AffineFastState.compose env22115 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22115 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env22116 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,415825,272393,441436,41003,8192,65,270377,436265,45097,31837,412721,155673,117,21589,46093,441933]

theorem envBound22116 : H12AffineFastState.Bounded env22116 := by
  intro p hp
  have h : env22116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22115_22116 : H12AffineEnvironment.transform 7 117 env22115 = env22116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22115 == env22116) = true)

theorem identity22116 : scanCanonicalize (H12AffineFastState.compose env22116 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 34817) := by decide +kernel

theorem selectedBound22116 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env22117 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,131072,34817,1024,32769,184400,40968,144477,41003,8192,65,43048,139304,45097,31837,181296,155673,117,21589,46093,144972]

theorem envBound22117 : H12AffineFastState.Bounded env22117 := by
  intro p hp
  have h : env22117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22116_22117 : H12AffineEnvironment.transform 17 34817 env22116 = env22117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34817 env22116 == env22117) = true)

theorem identity22117 : scanCanonicalize (H12AffineFastState.compose env22117 (packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 57400) := by decide +kernel

theorem selectedBound22117 : packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env22118 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,57400,34817,1024,32769,12392,40968,54373,41003,8192,65,43048,49168,45097,31837,9224,32801,117,21589,46093,54900]

theorem envBound22118 : H12AffineFastState.Bounded env22118 := by
  intro p hp
  have h : env22118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22117_22118 : H12AffineEnvironment.transform 16 57400 env22117 = env22118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57400 env22117 == env22118) = true)

theorem identity22118 : scanCanonicalize (H12AffineFastState.compose env22118 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22118 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env22119 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,32768,54358,49168,34817,1024,32769,4160,32800,54373,32771,40,65,34816,49168,36865,23669,1056,32801,117,21589,37925,54900]

theorem envBound22119 : H12AffineFastState.Bounded env22119 := by
  intro p hp
  have h : env22119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22118_22119 : H12AffineEnvironment.transform 12 40 env22118 = env22119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22118 == env22119) = true)

theorem identity22119 : scanCanonicalize (H12AffineFastState.compose env22119 (packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound22119 : packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22120 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21621,35,5221,23668,1024,21620,4160,21589,16,21622,40,65,23669,5221,17524,23669,1056,21588,117,21589,16464,513]

theorem envBound22120 : H12AffineFastState.Bounded env22120 := by
  intro p hp
  have h : env22120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22119_22120 : H12AffineEnvironment.transform 14 21621 env22119 = env22120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env22119 == env22120) = true)

theorem identity22120 : scanCanonicalize (H12AffineFastState.compose env22120 (packedSelected [2,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound22120 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env22121 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,16384,20497,35,4097,22544,100,20496,4160,20529,16,20498,40,65,22545,4097,16400,22545,68,20528,117,20529,16464,513]

theorem envBound22121 : H12AffineFastState.Bounded env22121 := by
  intro p hp
  have h : env22121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22120_22121 : H12AffineEnvironment.transform 9 100 env22120 = env22121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env22120 == env22121) = true)

theorem identity22121 : scanCanonicalize (H12AffineFastState.compose env22121 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22121 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env22122 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,16384,20497,35,4097,22544,52,20496,4112,20529,16,20498,40,17,22545,4097,16400,22545,20,20528,37,20529,16384,513]

theorem envBound22122 : H12AffineFastState.Bounded env22122 := by
  intro p hp
  have h : env22122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22121_22122 : H12AffineEnvironment.transform 5 16 env22121 = env22122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22121 == env22122) = true)

theorem identity22122 : scanCanonicalize (H12AffineFastState.compose env22122 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound22122 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22123 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4113,0,35,4097,2049,52,1,4112,32,16,3,40,17,2048,4097,4097,2048,20,33,37,32,4113,513]

theorem envBound22123 : H12AffineFastState.Bounded env22123 := by
  intro p hp
  have h : env22123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22122_22123 : H12AffineEnvironment.transform 13 4113 env22122 = env22123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env22122 == env22123) = true)

theorem identity22123 : scanCanonicalize (H12AffineFastState.compose env22123 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 517) := by decide +kernel

theorem selectedBound22123 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22124 : List Nat := [2,4,8,16,32,16,8,37,512,52,517,4096,40,4113,0,35,4097,516,52,1,4112,32,16,3,40,17,517,4097,4097,517,20,33,37,32,4113,513]

theorem envBound22124 : H12AffineFastState.Bounded env22124 := by
  intro p hp
  have h : env22124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22123_22124 : H12AffineEnvironment.transform 10 517 env22123 = env22124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 517 env22123 == env22124) = true)

theorem identity22124 : scanCanonicalize (H12AffineFastState.compose env22124 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 19) := by decide +kernel

theorem selectedBound22124 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22125 : List Nat := [2,4,8,16,32,16,8,37,512,52,517,19,40,2,0,35,18,516,52,1,3,32,16,3,40,17,517,18,18,517,20,33,37,32,2,513]

theorem envBound22125 : H12AffineFastState.Bounded env22125 := by
  intro p hp
  have h : env22125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22124_22125 : H12AffineEnvironment.transform 11 19 env22124 = env22125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 19 env22124 == env22125) = true)

theorem identity22125 : scanCanonicalize (H12AffineFastState.compose env22125 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22126 : List Nat := [2,4,8,0,32,0,8,37,512,36,517,3,40,2,0,35,2,516,36,1,3,32,0,3,40,1,517,2,2,517,4,33,37,32,2,513]

theorem envBound22126 : H12AffineFastState.Bounded env22126 := by
  intro p hp
  have h : env22126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22125_22126 : H12AffineEnvironment.transform 3 0 env22125 = env22126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22125 == env22126) = true)

theorem identity22126 : scanCanonicalize (H12AffineFastState.compose env22126 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound22126 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22127 : List Nat := [2,4,8,0,32,0,8,37,13,36,8,3,40,2,0,35,2,9,36,1,3,32,0,3,40,1,8,2,2,8,4,33,37,32,2,12]

theorem envBound22127 : H12AffineFastState.Bounded env22127 := by
  intro p hp
  have h : env22127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22126_22127 : H12AffineEnvironment.transform 8 13 env22126 = env22127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env22126 == env22127) = true)

theorem identity22127 : scanCanonicalize (H12AffineFastState.compose env22127 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound22127 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22128 : List Nat := [2,4,8,0,11,0,8,14,13,15,8,3,3,2,0,8,2,9,15,1,3,11,0,3,3,1,8,2,2,8,4,10,14,11,2,12]

theorem envBound22128 : H12AffineFastState.Bounded env22128 := by
  intro p hp
  have h : env22128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22127_22128 : H12AffineEnvironment.transform 4 11 env22127 = env22128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env22127 == env22128) = true)

theorem identity22128 : scanCanonicalize (H12AffineFastState.compose env22128 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22128 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22129 : List Nat := [2,4,2,0,1,0,2,4,7,5,2,3,3,2,0,2,2,3,5,1,3,1,0,3,3,1,2,2,2,2,4,0,4,1,2,6]

theorem envBound22129 : H12AffineFastState.Bounded env22129 := by
  intro p hp
  have h : env22129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22128_22129 : H12AffineEnvironment.transform 2 2 env22128 = env22129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22128 == env22129) = true)

def env22130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416037,272392,441641,41311,8193,65,270376,436265,45405,32040,412721,156013,256,21792,46092,442168]

theorem envBound22130 : H12AffineFastState.Bounded env22130 := by
  intro p hp
  have h : env22130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22114_22130 : H12AffineEnvironment.transform 6 9 env22114 = env22130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22114 == env22130) = true)

theorem identity22130 : scanCanonicalize (H12AffineFastState.compose env22130 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound22130 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env22131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,262144,1024,32769,290153,272392,297317,41311,8193,65,270376,302181,45405,32040,292989,21793,256,21792,46092,297844]

theorem envBound22131 : H12AffineFastState.Bounded env22131 := by
  intro p hp
  have h : env22131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22130_22131 : H12AffineEnvironment.transform 16 13388 env22130 = env22131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env22130 == env22131) = true)

theorem identity22131 : scanCanonicalize (H12AffineFastState.compose env22131 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound22131 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env22132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,64809,1024,32769,36928,54561,29772,41311,8193,65,56577,24908,45405,32040,34132,21793,256,21792,46092,30301]

theorem envBound22132 : H12AffineFastState.Bounded env22132 := by
  intro p hp
  have h : env22132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22131_22132 : H12AffineEnvironment.transform 17 64809 env22131 = env22132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env22131 == env22132) = true)

theorem identity22132 : scanCanonicalize (H12AffineFastState.compose env22132 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22132 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env22133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54359,5441,56356,1024,32769,36928,54561,21825,32850,268,65,56577,16449,36944,23589,34132,21793,256,21792,38145,22352]

theorem envBound22133 : H12AffineFastState.Bounded env22133 := by
  intro p hp
  have h : env22133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22132_22133 : H12AffineEnvironment.transform 12 269 env22132 = env22133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22132 == env22133) = true)

theorem identity22133 : scanCanonicalize (H12AffineFastState.compose env22133 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22133 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env22134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,32768,33030,5441,35189,1024,32769,36928,32880,16,32850,268,65,34896,5392,36944,2420,34132,112,256,113,38145,513]

theorem envBound22134 : H12AffineFastState.Bounded env22134 := by
  intro p hp
  have h : env22134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22133_22134 : H12AffineEnvironment.transform 13 5457 env22133 = env22134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22133 == env22134) = true)

def env22135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,8388608,8898593,8328,65,4196384,8393985,8785148,8830977,412721,12645453,256,21793,46212,486374]

theorem envBound22135 : H12AffineFastState.Bounded env22135 := by
  intro p hp
  have h : env22135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22042_22135 : H12AffineEnvironment.transform 20 416173 env22042 = env22135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416173 env22042 == env22135) = true)

def env22136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441640,95497,8328,65,4196384,436265,45524,32041,412721,4606309,256,21793,46212,486374]

theorem envBound22136 : H12AffineFastState.Bounded env22136 := by
  intro p hp
  have h : env22136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22135_22136 : H12AffineEnvironment.transform 22 441640 env22135 = env22136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env22135 == env22136) = true)

def env22137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441640,95497,8328,65,270496,436265,45524,32041,412721,156133,256,21793,46212,486374]

theorem envBound22137 : H12AffineFastState.Bounded env22137 := by
  intro p hp
  have h : env22137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22136_22137 : H12AffineEnvironment.transform 21 272512 env22136 = env22137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22136 == env22137) = true)

def env22138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272392,441640,95497,8192,65,270376,436265,45404,32041,412721,156013,256,21793,46092,486254]

theorem envBound22138 : H12AffineFastState.Bounded env22138 := by
  intro p hp
  have h : env22138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22137_22138 : H12AffineEnvironment.transform 6 8 env22137 = env22138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22137 == env22138) = true)

def env22139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314421,272392,272440,95497,8192,65,270376,277817,45404,32041,317729,62589,256,21793,46092,392830]

theorem envBound22139 : H12AffineFastState.Bounded env22139 := by
  intro p hp
  have h : env22139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22138_22139 : H12AffineEnvironment.transform 16 38160 env22138 = env22139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env22138 == env22139) = true)

theorem identity22139 : scanCanonicalize (H12AffineFastState.compose env22139 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22139 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,38160,262144,1024,32769,314421,272392,272440,2,8192,65,270376,277817,45404,32041,317729,62589,256,21793,46092,297845]

theorem envBound22140 : H12AffineFastState.Bounded env22140 := by
  intro p hp
  have h : env22140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22139_22140 : H12AffineEnvironment.transform 15 29963 env22139 = env22140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22139 == env22140) = true)

theorem identity22140 : scanCanonicalize (H12AffineFastState.compose env22140 (packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound22140 : packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env22141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,38160,2129,1024,32769,50276,8281,8297,2,8192,65,10361,13672,45404,32041,53616,62589,256,21793,46092,33572]

theorem envBound22141 : H12AffineFastState.Bounded env22141 := by
  intro p hp
  have h : env22141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22140_22141 : H12AffineEnvironment.transform 17 2129 env22140 = env22141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env22140 == env22141) = true)

theorem identity22141 : scanCanonicalize (H12AffineFastState.compose env22141 (packedSelected [1,3,8,10,12,15,16,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound22141 : packedSelected [1,3,8,10,12,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env22142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,29963,24633,2129,1024,29992,12621,8281,8297,2,8192,65,10361,13672,17525,32041,9305,340,256,21793,16677,30221]

theorem envBound22142 : H12AffineFastState.Bounded env22142 := by
  intro p hp
  have h : env22142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22141_22142 : H12AffineEnvironment.transform 14 29993 env22141 = env22142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env22141 == env22142) = true)

theorem identity22142 : scanCanonicalize (H12AffineFastState.compose env22142 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22142 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env22143 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,29822,24633,2129,1024,29789,12344,8281,8297,2,8192,65,10361,13341,17525,31836,9305,33,117,21588,16464,30221]

theorem envBound22143 : H12AffineFastState.Bounded env22143 := by
  intro p hp
  have h : env22143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22142_22143 : H12AffineEnvironment.transform 7 117 env22142 = env22143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22142 == env22143) = true)

theorem identity22143 : scanCanonicalize (H12AffineFastState.compose env22143 (packedSelected [0,3,5,7,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound22143 : packedSelected [0,3,5,7,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env22144 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1052,16384,20544,20578,17445,2129,1024,20545,5156,1093,1141,2,1052,65,3173,4097,17525,22592,69,33,117,21588,16464,21009]

theorem envBound22144 : H12AffineFastState.Bounded env22144 := by
  intro p hp
  have h : env22144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22143_22144 : H12AffineEnvironment.transform 12 1052 env22143 = env22144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env22143 == env22144) = true)

theorem identity22144 : scanCanonicalize (H12AffineFastState.compose env22144 (packedSelected [2,4,6,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound22144 : packedSelected [2,4,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env22145 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,120,16384,20544,20578,16449,2129,100,20545,4160,33,17,2,120,65,2049,4097,16401,22592,69,33,117,20528,16464,21009]

theorem envBound22145 : H12AffineFastState.Bounded env22145 := by
  intro p hp
  have h : env22145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22144_22145 : H12AffineEnvironment.transform 9 100 env22144 = env22145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env22144 == env22145) = true)

theorem identity22145 : scanCanonicalize (H12AffineFastState.compose env22145 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound22145 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22146 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,120,4160,0,34,4097,2129,100,1,4160,33,17,2,120,65,2049,4097,4177,2048,69,33,117,112,4112,593]

theorem envBound22146 : H12AffineFastState.Bounded env22146 := by
  intro p hp
  have h : env22146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22145_22146 : H12AffineEnvironment.transform 13 4160 env22145 = env22146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env22145 == env22146) = true)

def env22147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314420,272392,272441,95497,8192,65,270376,277816,45404,32041,317728,62588,256,21793,46092,392831]

theorem envBound22147 : H12AffineFastState.Bounded env22147 := by
  intro p hp
  have h : env22147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22138_22147 : H12AffineEnvironment.transform 16 38161 env22138 = env22147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env22138 == env22147) = true)

theorem identity22147 : scanCanonicalize (H12AffineFastState.compose env22147 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound22147 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89379,1024,32769,102679,95531,95514,95497,8192,65,97547,90139,45404,32041,99331,62588,256,21793,46092,41820]

theorem envBound22148 : H12AffineFastState.Bounded env22148 := by
  intro p hp
  have h : env22148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22147_22148 : H12AffineEnvironment.transform 17 89379 env22147 = env22148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env22147 == env22148) = true)

theorem identity22148 : scanCanonicalize (H12AffineFastState.compose env22148 (packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound22148 : packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env22149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,65536,38161,89379,1024,32769,102679,87379,87394,87409,120,65,89459,82019,37156,23889,99331,54276,256,21793,38004,33572]

theorem envBound22149 : H12AffineFastState.Bounded env22149 := by
  intro p hp
  have h : env22149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22148_22149 : H12AffineEnvironment.transform 12 120 env22148 = env22149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env22148 == env22149) = true)

theorem identity22149 : scanCanonicalize (H12AffineFastState.compose env22149 (packedSelected [2,4,6,8,10,11,12,15,18,20,22,28] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22149 : packedSelected [2,4,6,8,10,11,12,15,18,20,22,28] rootPS < 2^1333 := by decide +kernel

def env22150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,33111,38161,56436,1024,32769,4160,54276,54325,54310,120,65,56356,49460,37156,23889,1364,54276,256,21793,38004,33572]

theorem envBound22150 : H12AffineFastState.Bounded env22150 := by
  intro p hp
  have h : env22150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22149_22150 : H12AffineEnvironment.transform 15 33111 env22149 = env22150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22149 == env22150) = true)

theorem identity22150 : scanCanonicalize (H12AffineFastState.compose env22150 (packedSelected [0,1,2,7,8,12,14,15,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound22150 : packedSelected [0,1,2,7,8,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env22151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21620,21795,16741,2048,1024,21621,4160,112,65,82,120,65,2128,5440,17744,23889,1364,112,256,21793,16384,22352]

theorem envBound22151 : H12AffineFastState.Bounded env22151 := by
  intro p hp
  have h : env22151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22150_22151 : H12AffineEnvironment.transform 14 21620 env22150 = env22151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env22150 == env22151) = true)

theorem identity22151 : scanCanonicalize (H12AffineFastState.compose env22151 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound22151 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env22152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5156,80,263,5441,2048,1024,81,4160,112,65,82,120,65,2128,5440,4468,2421,1364,112,256,261,5156,884]

theorem envBound22152 : H12AffineFastState.Bounded env22152 := by
  intro p hp
  have h : env22152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22151_22152 : H12AffineEnvironment.transform 13 5156 env22151 = env22152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env22151 == env22152) = true)

theorem identity22152 : scanCanonicalize (H12AffineFastState.compose env22152 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22152 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22153 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5156,80,114,5172,2048,1024,81,4160,112,65,82,120,65,2128,5173,4097,2048,1057,112,117,112,5156,513]

theorem envBound22153 : H12AffineFastState.Bounded env22153 := by
  intro p hp
  have h : env22153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22152_22153 : H12AffineEnvironment.transform 7 117 env22152 = env22153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22152 == env22153) = true)

theorem identity22153 : scanCanonicalize (H12AffineFastState.compose env22153 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound22153 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env22154 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,120,4161,80,114,4177,2048,101,81,4160,112,65,82,120,65,2128,4176,4097,2048,68,112,117,112,4161,513]

theorem envBound22154 : H12AffineFastState.Bounded env22154 := by
  intro p hp
  have h : env22154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22153_22154 : H12AffineEnvironment.transform 9 101 env22153 = env22154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env22153 == env22154) = true)

theorem identity22154 : scanCanonicalize (H12AffineFastState.compose env22154 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2160) := by decide +kernel

theorem selectedBound22154 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env22155 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,2160,120,2097,80,114,2081,2048,101,81,2096,112,65,82,120,65,2128,2080,2161,2048,68,112,117,112,2097,513]

theorem envBound22155 : H12AffineFastState.Bounded env22155 := by
  intro p hp
  have h : env22155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22154_22155 : H12AffineEnvironment.transform 11 2160 env22154 = env22155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2160 env22154 == env22155) = true)

theorem identity22155 : scanCanonicalize (H12AffineFastState.compose env22155 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22155 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22156 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2081,41,2097,1,35,2081,2048,52,0,2096,33,16,3,41,16,2049,2080,2080,2048,21,33,36,33,2097,513]

theorem envBound22156 : H12AffineFastState.Bounded env22156 := by
  intro p hp
  have h : env22156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22155_22156 : H12AffineEnvironment.transform 5 17 env22155 = env22156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22155 == env22156) = true)

theorem identity22156 : scanCanonicalize (H12AffineFastState.compose env22156 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound22156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22157 : List Nat := [2,4,8,16,32,17,8,36,17,52,2048,2081,41,2097,1,35,2081,2048,52,0,2096,33,16,3,41,16,2049,2080,2080,2048,21,33,36,33,2097,16]

theorem envBound22157 : H12AffineFastState.Bounded env22157 := by
  intro p hp
  have h : env22157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22156_22157 : H12AffineEnvironment.transform 8 17 env22156 = env22157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env22156 == env22157) = true)

theorem identity22157 : scanCanonicalize (H12AffineFastState.compose env22157 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22158 : List Nat := [2,4,8,16,17,17,8,21,17,5,2048,2064,24,2048,1,18,2064,2048,5,0,2049,16,16,3,24,16,2049,2065,2065,2048,21,16,21,16,2048,16]

theorem envBound22158 : H12AffineFastState.Bounded env22158 := by
  intro p hp
  have h : env22158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22157_22158 : H12AffineEnvironment.transform 4 17 env22157 = env22158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22157 == env22158) = true)

theorem identity22158 : scanCanonicalize (H12AffineFastState.compose env22158 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound22158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22159 : List Nat := [2,4,8,16,17,17,8,21,17,5,17,1,24,17,1,18,1,17,5,0,16,16,16,3,24,16,16,0,0,17,21,16,21,16,17,16]

theorem envBound22159 : H12AffineFastState.Bounded env22159 := by
  intro p hp
  have h : env22159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22158_22159 : H12AffineEnvironment.transform 10 17 env22158 = env22159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env22158 == env22159) = true)

theorem identity22159 : scanCanonicalize (H12AffineFastState.compose env22159 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22159 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22160 : List Nat := [2,4,8,0,1,1,8,5,1,5,1,1,8,1,1,2,1,1,5,0,0,0,0,3,8,0,0,0,0,1,5,0,5,0,1,0]

theorem envBound22160 : H12AffineFastState.Bounded env22160 := by
  intro p hp
  have h : env22160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22159_22160 : H12AffineEnvironment.transform 3 0 env22159 = env22160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22159 == env22160) = true)

def env22161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441640,95497,8193,65,270377,436265,45405,32041,412721,156012,256,21793,46093,486255]

theorem envBound22161 : H12AffineFastState.Bounded env22161 := by
  intro p hp
  have h : env22161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22137_22161 : H12AffineEnvironment.transform 6 9 env22137 = env22161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22137 == env22161) = true)

def env22162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272440,95497,8193,65,270377,277817,45405,32041,317729,62588,256,21793,46093,392831]

theorem envBound22162 : H12AffineFastState.Bounded env22162 := by
  intro p hp
  have h : env22162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22161_22162 : H12AffineEnvironment.transform 16 38160 env22161 = env22162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env22161 == env22162) = true)

theorem identity22162 : scanCanonicalize (H12AffineFastState.compose env22162 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound22162 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130174,1024,32769,77898,119927,119878,95497,8193,65,121943,115015,45405,32041,75103,62588,256,21793,46093,513]

theorem envBound22163 : H12AffineFastState.Bounded env22163 := by
  intro p hp
  have h : env22163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22162_22163 : H12AffineEnvironment.transform 17 130174 env22162 = env22163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env22162 == env22163) = true)

theorem identity22163 : scanCanonicalize (H12AffineFastState.compose env22163 (packedSelected [1,2,6,10,18,19,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound22163 : packedSelected [1,2,6,10,18,19,23,28] rootPS < 2^1333 := by decide +kernel

def env22164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30042,38160,35108,1024,32769,17680,41261,41244,83,8193,65,43277,46109,45405,32041,20485,62588,256,21793,46093,513]

theorem envBound22164 : H12AffineFastState.Bounded env22164 := by
  intro p hp
  have h : env22164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22163_22164 : H12AffineEnvironment.transform 15 30042 env22163 = env22164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env22163 == env22164) = true)

theorem identity22164 : scanCanonicalize (H12AffineFastState.compose env22164 (packedSelected [0,1,7,8,12,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound22164 : packedSelected [0,1,7,8,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env22165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,30042,5440,2420,1024,81,17680,8573,8524,83,8193,65,10589,13389,12557,32041,20485,29740,256,21793,13405,513]

theorem envBound22165 : H12AffineFastState.Bounded env22165 := by
  intro p hp
  have h : env22165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22164_22165 : H12AffineEnvironment.transform 14 80 env22164 = env22165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env22164 == env22165) = true)

theorem identity22165 : scanCanonicalize (H12AffineFastState.compose env22165 (packedSelected [0,3,4,5,7,9,10,12,14,15,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22165 : packedSelected [0,3,4,5,7,9,10,12,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env22166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,80,8203,5440,2420,1024,81,4161,8573,8524,83,8193,65,10589,13389,12557,10360,1364,8573,256,112,13405,513]

theorem envBound22166 : H12AffineFastState.Bounded env22166 := by
  intro p hp
  have h : env22166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22165_22166 : H12AffineEnvironment.transform 13 5457 env22165 = env22166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22165 == env22166) = true)

theorem identity22166 : scanCanonicalize (H12AffineFastState.compose env22166 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 5913) := by decide +kernel

theorem selectedBound22166 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env22167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5913,5457,80,5906,5440,2420,1024,81,4161,5732,5717,83,5912,65,7748,852,1556,8033,1364,5732,256,112,836,513]

theorem envBound22167 : H12AffineFastState.Bounded env22167 := by
  intro p hp
  have h : env22167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22166_22167 : H12AffineEnvironment.transform 12 5913 env22166 = env22167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5913 env22166 == env22167) = true)

theorem identity22167 : scanCanonicalize (H12AffineFastState.compose env22167 (packedSelected [0,1,2,4,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound22167 : packedSelected [0,1,2,4,8,14] rootPS < 2^1333 := by decide +kernel

def env22168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1556,269,837,80,262,852,2420,1024,81,1621,112,65,83,268,65,2128,852,1556,2421,1364,112,256,112,836,513]

theorem envBound22168 : H12AffineFastState.Bounded env22168 := by
  intro p hp
  have h : env22168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22167_22168 : H12AffineEnvironment.transform 11 1556 env22167 = env22168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env22167 == env22168) = true)

theorem identity22168 : scanCanonicalize (H12AffineFastState.compose env22168 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22168 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22169 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1556,269,789,0,262,772,2340,1024,1,1541,32,17,3,268,17,2048,772,1556,2341,1284,32,256,32,788,513]

theorem envBound22169 : H12AffineFastState.Bounded env22169 := by
  intro p hp
  have h : env22169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22168_22169 : H12AffineEnvironment.transform 5 16 env22168 = env22169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22168 == env22169) = true)

theorem identity22169 : scanCanonicalize (H12AffineFastState.compose env22169 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound22169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22170 : List Nat := [2,4,8,16,32,16,9,256,512,5,2048,529,269,789,0,262,772,2340,5,1,512,32,17,3,268,17,2048,772,529,2341,257,32,256,32,788,513]

theorem envBound22170 : H12AffineFastState.Bounded env22170 := by
  intro p hp
  have h : env22170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22169_22170 : H12AffineEnvironment.transform 9 5 env22169 = env22170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env22169 == env22170) = true)

def env22171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272441,95497,8193,65,270377,277816,45405,32041,317728,62589,256,21793,46093,392830]

theorem envBound22171 : H12AffineFastState.Bounded env22171 := by
  intro p hp
  have h : env22171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22161_22171 : H12AffineEnvironment.transform 16 38161 env22161 = env22171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env22161 == env22171) = true)

theorem identity22171 : scanCanonicalize (H12AffineFastState.compose env22171 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound22171 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1024,32769,314421,272393,272441,41310,8193,65,270377,277816,45405,32041,317728,62589,256,21793,46093,272937]

theorem envBound22172 : H12AffineFastState.Bounded env22172 := by
  intro p hp
  have h : env22172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22171_22172 : H12AffineEnvironment.transform 15 54359 env22171 = env22172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env22171 == env22172) = true)

theorem identity22172 : scanCanonicalize (H12AffineFastState.compose env22172 (packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22172 : packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env22173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21591,5393,262144,1024,1,281653,272393,272441,8542,8193,65,270377,277816,12637,32041,284960,29821,256,21793,13325,272937]

theorem envBound22173 : H12AffineFastState.Bounded env22173 := by
  intro p hp
  have h : env22173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22172_22173 : H12AffineEnvironment.transform 14 0 env22172 = env22173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22172 == env22173) = true)

theorem identity22173 : scanCanonicalize (H12AffineFastState.compose env22173 (packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound22173 : packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env22174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8202,5393,262144,1024,1,276584,272393,272441,8542,8193,65,270377,277816,12637,2420,273789,32,256,8572,13325,272937]

theorem envBound22174 : H12AffineFastState.Bounded env22174 := by
  intro p hp
  have h : env22174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22173_22174 : H12AffineEnvironment.transform 13 13405 env22173 = env22174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env22173 == env22174) = true)

theorem identity22174 : scanCanonicalize (H12AffineFastState.compose env22174 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound22174 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env22175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8202,5393,10361,1024,1,4113,112,64,8542,8193,65,2128,5441,12637,2420,1284,32,256,8572,13325,592]

theorem envBound22175 : H12AffineFastState.Bounded env22175 := by
  intro p hp
  have h : env22175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22174_22175 : H12AffineEnvironment.transform 17 10361 env22174 = env22175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env22174 == env22175) = true)

theorem identity22175 : scanCanonicalize (H12AffineFastState.compose env22175 (packedSelected [2,3,4,5,6,7,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound22175 : packedSelected [2,3,4,5,6,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,8192,10509,0,8202,2113,10361,1024,1,3393,112,64,8542,8193,65,2128,2065,11277,2420,1284,32,256,8572,10589,592]

theorem envBound22176 : H12AffineFastState.Bounded env22176 := by
  intro p hp
  have h : env22176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22175_22176 : H12AffineEnvironment.transform 11 3408 env22175 = env22176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env22175 == env22176) = true)

theorem identity22176 : scanCanonicalize (H12AffineFastState.compose env22176 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22176 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env22177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,268,2049,0,262,2113,2421,1024,1,3393,112,64,82,269,65,2128,2065,3329,2420,1284,32,256,112,2129,592]

theorem envBound22177 : H12AffineFastState.Bounded env22177 := by
  intro p hp
  have h : env22177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22176_22177 : H12AffineEnvironment.transform 12 268 env22176 = env22177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22176 == env22177) = true)

theorem identity22177 : scanCanonicalize (H12AffineFastState.compose env22177 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22177 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env22178 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,268,2049,0,262,2065,2341,1024,1,3345,32,16,2,269,17,2048,2065,3329,2340,1284,32,256,32,2049,512]

theorem envBound22178 : H12AffineFastState.Bounded env22178 := by
  intro p hp
  have h : env22178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22177_22178 : H12AffineEnvironment.transform 5 16 env22177 = env22178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22177 == env22178) = true)

theorem identity22178 : scanCanonicalize (H12AffineFastState.compose env22178 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22179 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,3328,268,2049,0,262,2065,2309,1024,1,3345,0,16,2,269,17,2048,2065,3329,2308,1284,0,256,0,2049,512]

theorem envBound22179 : H12AffineFastState.Bounded env22179 := by
  intro p hp
  have h : env22179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22178_22179 : H12AffineEnvironment.transform 4 0 env22178 = env22179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22178 == env22179) = true)

theorem identity22179 : scanCanonicalize (H12AffineFastState.compose env22179 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound22179 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22180 : List Nat := [2,4,8,16,0,16,9,256,270,1024,2048,3328,268,2049,0,262,2065,2309,1024,1,3345,0,16,2,269,17,2048,2065,3329,2308,1284,0,256,0,2049,270]

theorem envBound22180 : H12AffineFastState.Bounded env22180 := by
  intro p hp
  have h : env22180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22179_22180 : H12AffineEnvironment.transform 8 270 env22179 = env22180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env22179 == env22180) = true)

theorem identity22180 : scanCanonicalize (H12AffineFastState.compose env22180 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22180 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22181 : List Nat := [2,4,8,16,0,16,9,256,270,1024,0,1280,268,1,0,262,17,261,1024,1,1297,0,16,2,269,17,0,17,1281,260,1284,0,256,0,1,270]

theorem envBound22181 : H12AffineFastState.Bounded env22181 := by
  intro p hp
  have h : env22181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22180_22181 : H12AffineEnvironment.transform 10 0 env22180 = env22181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22180 == env22181) = true)

def env22182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441640,95497,8328,65,270497,436265,45524,32041,412721,156132,256,21793,46212,486374]

theorem envBound22182 : H12AffineFastState.Bounded env22182 := by
  intro p hp
  have h : env22182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22136_22182 : H12AffineEnvironment.transform 21 272513 env22136 = env22182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22136 == env22182) = true)

theorem identity22182 : scanCanonicalize (H12AffineFastState.compose env22182 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound22182 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58517,169401,16,95497,8328,65,171417,5393,45524,32041,61705,156132,256,21793,46212,120542]

theorem envBound22183 : H12AffineFastState.Bounded env22183 := by
  intro p hp
  have h : env22183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22182_22183 : H12AffineEnvironment.transform 17 179512 env22182 = env22183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env22182 == env22183) = true)

def env22184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58397,169265,16,95497,8192,65,171281,5393,45404,32041,61705,156012,256,21793,46092,120406]

theorem envBound22184 : H12AffineFastState.Bounded env22184 := by
  intro p hp
  have h : env22184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22183_22184 : H12AffineEnvironment.transform 6 8 env22183 = env22184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22183 == env22184) = true)

theorem identity22184 : scanCanonicalize (H12AffineFastState.compose env22184 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound22184 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,89379,1024,32769,58397,95530,16,95497,8192,65,97546,5393,45404,32041,61705,98679,256,21793,46092,120406]

theorem envBound22185 : H12AffineFastState.Bounded env22185 := by
  intro p hp
  have h : env22185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22184_22185 : H12AffineEnvironment.transform 16 122907 env22184 = env22185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env22184 == env22185) = true)

theorem identity22185 : scanCanonicalize (H12AffineFastState.compose env22185 (packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62590) := by decide +kernel

theorem selectedBound22185 : packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env22186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62590,5221,43357,1024,32769,58397,33108,16,33143,8192,65,35188,5393,45404,32041,61705,29961,256,21793,46092,8744]

theorem envBound22186 : H12AffineFastState.Bounded env22186 := by
  intro p hp
  have h : env22186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22185_22186 : H12AffineEnvironment.transform 15 62590 env22185 = env22186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62590 env22185 == env22186) = true)

theorem identity22186 : scanCanonicalize (H12AffineFastState.compose env22186 (packedSelected [2,3,5,6,9,10,11,12,14,15,19,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22186 : packedSelected [2,3,5,6,9,10,11,12,14,15,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env22187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,32768,40970,5221,43357,1024,32769,45161,33108,16,33143,8192,65,35188,5393,45404,10589,42365,8573,256,341,46092,8744]

theorem envBound22187 : H12AffineFastState.Bounded env22187 := by
  intro p hp
  have h : env22187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22186_22187 : H12AffineEnvironment.transform 13 5236 env22186 = env22187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22186 == env22187) = true)

theorem identity22187 : scanCanonicalize (H12AffineFastState.compose env22187 (packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22187 : packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8541,343,5221,2048,1024,8540,4404,8201,16,8234,8192,65,10281,5393,4097,10589,1056,8573,256,341,5457,8744]

theorem envBound22188 : H12AffineFastState.Bounded env22188 := by
  intro p hp
  have h : env22188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22187_22188 : H12AffineEnvironment.transform 14 8541 env22187 = env22188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22187 == env22188) = true)

theorem identity22188 : scanCanonicalize (H12AffineFastState.compose env22188 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22188 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env22189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,0,343,5221,2048,1024,1,4404,340,16,375,349,65,2420,5393,4097,2048,1056,32,256,341,5457,885]

theorem envBound22189 : H12AffineFastState.Bounded env22189 := by
  intro p hp
  have h : env22189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22188_22189 : H12AffineEnvironment.transform 12 349 env22188 = env22189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22188 == env22189) = true)

theorem identity22189 : scanCanonicalize (H12AffineFastState.compose env22189 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound22189 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22190 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,301,5124,0,295,5141,2048,1024,1,4404,292,16,263,301,49,2308,5393,4097,2048,1056,32,256,293,5409,773]

theorem envBound22190 : H12AffineFastState.Bounded env22190 := by
  intro p hp
  have h : env22190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22189_22190 : H12AffineEnvironment.transform 5 48 env22189 = env22190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env22189 == env22190) = true)

theorem identity22190 : scanCanonicalize (H12AffineFastState.compose env22190 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22190 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env22191 : List Nat := [2,4,8,16,32,48,8,4,512,1024,2048,4096,41,5124,0,35,5141,2048,1024,1,4144,32,16,3,41,49,2048,5141,4097,2048,1056,32,4,33,5157,513]

theorem envBound22191 : H12AffineFastState.Bounded env22191 := by
  intro p hp
  have h : env22191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22190_22191 : H12AffineEnvironment.transform 7 4 env22190 = env22191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22190 == env22191) = true)

theorem identity22191 : scanCanonicalize (H12AffineFastState.compose env22191 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound22191 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22192 : List Nat := [2,4,8,16,32,48,8,4,512,1024,1567,4096,41,5124,0,35,5141,1567,1024,1,4144,32,16,3,41,49,1567,5141,4097,1567,1056,32,4,33,5157,513]

theorem envBound22192 : H12AffineFastState.Bounded env22192 := by
  intro p hp
  have h : env22192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22191_22192 : H12AffineEnvironment.transform 10 1567 env22191 = env22192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env22191 == env22192) = true)

theorem identity22192 : scanCanonicalize (H12AffineFastState.compose env22192 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22192 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22193 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1567,4096,9,5124,0,3,5141,1567,1024,1,4112,0,16,3,9,17,1567,5141,4097,1567,1024,0,4,1,5125,513]

theorem envBound22193 : H12AffineFastState.Bounded env22193 := by
  intro p hp
  have h : env22193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22192_22193 : H12AffineEnvironment.transform 4 0 env22192 = env22193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22192 == env22193) = true)

def env22194 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58396,169264,16,95497,8193,65,171280,5393,45405,32041,61705,156013,256,21793,46093,120407]

theorem envBound22194 : H12AffineFastState.Bounded env22194 := by
  intro p hp
  have h : env22194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22183_22194 : H12AffineEnvironment.transform 6 9 env22183 = env22194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22183 == env22194) = true)

theorem identity22194 : scanCanonicalize (H12AffineFastState.compose env22194 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound22194 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130174,1024,32769,58396,119926,16,95497,8193,65,121942,5393,45405,32041,61705,73771,256,21793,46093,120407]

theorem envBound22195 : H12AffineFastState.Bounded env22195 := by
  intro p hp
  have h : env22195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22194_22195 : H12AffineEnvironment.transform 16 82246 env22194 = env22195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env22194 == env22195) = true)

theorem identity22195 : scanCanonicalize (H12AffineFastState.compose env22195 (packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22195 : packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS < 2^1333 := by decide +kernel

def env22196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,82246,122147,1024,32769,50497,119926,16,87124,348,65,121942,5393,36864,23668,53332,65910,256,21793,38224,120407]

theorem envBound22196 : H12AffineFastState.Bounded env22196 := by
  intro p hp
  have h : env22196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22195_22196 : H12AffineEnvironment.transform 12 349 env22195 = env22196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22195 == env22196) = true)

def env22197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,4194304,441641,95496,8328,65,4196384,436264,45525,32040,412721,4606308,256,21793,46212,486374]

theorem envBound22197 : H12AffineFastState.Bounded env22197 := by
  intro p hp
  have h : env22197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22135_22197 : H12AffineEnvironment.transform 22 441641 env22135 = env22197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env22135 == env22197) = true)

def env22198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272512,441641,95496,8328,65,270496,436264,45525,32040,412721,156132,256,21793,46212,486374]

theorem envBound22198 : H12AffineFastState.Bounded env22198 := by
  intro p hp
  have h : env22198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22197_22198 : H12AffineEnvironment.transform 21 272512 env22197 = env22198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env22197 == env22198) = true)

theorem identity22198 : scanCanonicalize (H12AffineFastState.compose env22198 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound22198 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416173,272512,412156,95496,8328,65,270496,417021,17664,32040,412721,156132,256,21793,16465,486374]

theorem envBound22199 : H12AffineFastState.Bounded env22199 := by
  intro p hp
  have h : env22199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22198_22199 : H12AffineEnvironment.transform 14 29909 env22198 = env22199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env22198 == env22199) = true)

def env22200 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272512,412076,95496,8328,17,270496,416941,17664,32040,412721,156084,256,21793,16385,486326]

theorem envBound22200 : H12AffineFastState.Bounded env22200 := by
  intro p hp
  have h : env22200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22199_22200 : H12AffineEnvironment.transform 5 16 env22199 = env22200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22199 == env22200) = true)

theorem identity22200 : scanCanonicalize (H12AffineFastState.compose env22200 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 212151) := by decide +kernel

theorem selectedBound22200 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env22201 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,212151,1024,29828,91418,201783,95515,95496,8328,17,203799,90138,17664,32040,94342,156084,256,21793,16385,22273]

theorem envBound22201 : H12AffineFastState.Bounded env22201 := by
  intro p hp
  have h : env22201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22200_22201 : H12AffineEnvironment.transform 17 212151 env22200 = env22201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212151 env22200 == env22201) = true)

theorem identity22201 : scanCanonicalize (H12AffineFastState.compose env22201 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound22201 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env22202 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,131072,138293,1024,29828,17816,144565,21913,21898,8328,17,146581,16536,17664,32040,20484,156084,256,21793,16385,22273]

theorem envBound22202 : H12AffineFastState.Bounded env22202 := by
  intro p hp
  have h : env22202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22201_22202 : H12AffineEnvironment.transform 15 8322 env22201 = env22202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env22201 == env22202) = true)

theorem identity22202 : scanCanonicalize (H12AffineFastState.compose env22202 (packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound22202 : packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env22203 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,16536,23725,1024,29828,17816,29741,21913,21898,8328,17,31757,16536,17664,32040,20484,8492,256,21793,16385,22273]

theorem envBound22203 : H12AffineFastState.Bounded env22203 := by
  intro p hp
  have h : env22203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22202_22203 : H12AffineEnvironment.transform 16 16536 env22202 = env22203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env22202 == env22203) = true)

theorem identity22203 : scanCanonicalize (H12AffineFastState.compose env22203 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound22203 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env22204 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,8322,5528,2477,1024,8580,4248,8493,153,138,8328,17,10509,5528,4096,10280,1284,8492,256,33,5377,513]

theorem envBound22204 : H12AffineFastState.Bounded env22204 := by
  intro p hp
  have h : env22204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22203_22204 : H12AffineEnvironment.transform 13 5376 env22203 = env22204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22203 == env22204) = true)

def env22205 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272512,412077,95496,8328,16,270496,416940,17664,32040,412721,156085,256,21793,16384,486327]

theorem envBound22205 : H12AffineFastState.Bounded env22205 := by
  intro p hp
  have h : env22205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22199_22205 : H12AffineEnvironment.transform 5 17 env22199 = env22205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22199 == env22205) = true)

theorem identity22205 : scanCanonicalize (H12AffineFastState.compose env22205 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound22205 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env22206 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24860,262144,1024,29829,276657,272512,272561,95496,8328,16,270496,277936,17664,32040,273709,169,256,21793,16384,330411]

theorem envBound22206 : H12AffineFastState.Bounded env22206 := by
  intro p hp
  have h : env22206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22205_22206 : H12AffineEnvironment.transform 16 24860 env22205 = env22206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env22205 == env22206) = true)

theorem identity22206 : scanCanonicalize (H12AffineFastState.compose env22206 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound22206 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env22207 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24860,2476,1024,29829,12573,8492,8477,95496,8328,16,10508,13340,17664,32040,9345,169,256,21793,16384,66311]

theorem envBound22207 : H12AffineFastState.Bounded env22207 := by
  intro p hp
  have h : env22207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22206_22207 : H12AffineEnvironment.transform 17 2476 env22206 = env22207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env22206 == env22207) = true)

theorem identity22207 : scanCanonicalize (H12AffineFastState.compose env22207 (packedSelected [1,10,17,19,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22207 : packedSelected [1,10,17,19,28] rootPS < 2^1333 := by decide +kernel

def env22208 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24860,2476,1024,29829,12573,8492,8477,21762,8328,16,10508,13340,17664,32040,9345,169,256,21793,16384,8973]

theorem envBound22208 : H12AffineFastState.Bounded env22208 := by
  intro p hp
  have h : env22208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22207_22208 : H12AffineEnvironment.transform 15 8202 env22207 = env22208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22207 == env22208) = true)

theorem identity22208 : scanCanonicalize (H12AffineFastState.compose env22208 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 11412) := by decide +kernel

theorem selectedBound22208 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env22209 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,11412,6160,8202,3464,2476,1024,6161,12573,8492,8477,14742,8328,16,10508,13340,10644,4540,9345,169,256,14773,11412,8973]

theorem envBound22209 : H12AffineFastState.Bounded env22209 := by
  intro p hp
  have h : env22209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22208_22209 : H12AffineEnvironment.transform 13 11412 env22208 = env22209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11412 env22208 == env22209) = true)

theorem identity22209 : scanCanonicalize (H12AffineFastState.compose env22209 (packedSelected [0,2,3,5,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound22209 : packedSelected [0,2,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env22210 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4153,7341,6160,4147,3464,2476,1024,6161,292,4373,4388,2479,4273,16,6453,1061,6573,4540,5304,169,256,2444,7341,4916]

theorem envBound22210 : H12AffineFastState.Bounded env22210 := by
  intro p hp
  have h : env22210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22209_22210 : H12AffineEnvironment.transform 12 4153 env22209 = env22210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env22209 == env22210) = true)

theorem identity22210 : scanCanonicalize (H12AffineFastState.compose env22210 (packedSelected [0,1,4,7,8,9,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound22210 : packedSelected [0,1,4,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env22211 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1212,4096,4153,4113,5292,4147,308,1296,1024,5293,292,4373,4388,1299,4273,16,5513,1061,5393,4540,5304,169,256,1328,4113,4916]

theorem envBound22211 : H12AffineFastState.Bounded env22211 := by
  intro p hp
  have h : env22211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22210_22211 : H12AffineEnvironment.transform 10 1212 env22210 = env22211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env22210 == env22211) = true)

theorem identity22211 : scanCanonicalize (H12AffineFastState.compose env22211 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound22211 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env22212 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1212,152,161,137,1076,171,308,1296,1024,1077,292,397,444,1299,41,16,1297,1061,1417,292,1056,169,256,1328,137,940]

theorem envBound22212 : H12AffineFastState.Bounded env22212 := by
  intro p hp
  have h : env22212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22211_22212 : H12AffineEnvironment.transform 11 152 env22211 = env22212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env22211 == env22212) = true)

theorem identity22212 : scanCanonicalize (H12AffineFastState.compose env22212 (packedSelected [2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22212 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env22213 : List Nat := [2,4,8,16,32,17,128,37,512,1024,1212,152,161,137,1076,171,17,1077,1024,1077,1,168,153,1078,41,16,1076,1061,1196,1,1056,169,37,1045,137,649]

theorem envBound22213 : H12AffineFastState.Bounded env22213 := by
  intro p hp
  have h : env22213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22212_22213 : H12AffineEnvironment.transform 7 37 env22212 = env22213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22212 == env22213) = true)

theorem identity22213 : scanCanonicalize (H12AffineFastState.compose env22213 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22213 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env22214 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,16,41,1,1076,35,17,1077,1024,1077,1,32,17,1078,41,16,1076,1061,1060,1,1056,33,37,1045,1,513]

theorem envBound22214 : H12AffineFastState.Bounded env22214 := by
  intro p hp
  have h : env22214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22213_22214 : H12AffineEnvironment.transform 6 8 env22213 = env22214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22213 == env22214) = true)

theorem identity22214 : scanCanonicalize (H12AffineFastState.compose env22214 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22214 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22215 : List Nat := [2,4,8,16,32,17,8,37,512,53,1,16,41,1,1,35,17,0,53,0,1,32,17,3,41,16,1,16,17,1,21,33,37,32,1,513]

theorem envBound22215 : H12AffineFastState.Bounded env22215 := by
  intro p hp
  have h : env22215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22214_22215 : H12AffineEnvironment.transform 9 53 env22214 = env22215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22214 == env22215) = true)

theorem identity22215 : scanCanonicalize (H12AffineFastState.compose env22215 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound22215 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22216 : List Nat := [2,4,8,16,32,17,8,37,49,53,1,16,41,1,1,35,17,0,53,0,1,32,17,3,41,16,1,16,17,1,21,33,37,32,1,48]

theorem envBound22216 : H12AffineFastState.Bounded env22216 := by
  intro p hp
  have h : env22216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22215_22216 : H12AffineEnvironment.transform 8 49 env22215 = env22216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env22215 == env22216) = true)

theorem identity22216 : scanCanonicalize (H12AffineFastState.compose env22216 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22217 : List Nat := [2,4,8,0,32,1,8,37,33,37,1,0,41,1,1,35,1,0,37,0,1,32,1,3,41,0,1,0,1,1,5,33,37,32,1,32]

theorem envBound22217 : H12AffineFastState.Bounded env22217 := by
  intro p hp
  have h : env22217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22216_22217 : H12AffineEnvironment.transform 3 0 env22216 = env22217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22216 == env22217) = true)

def env22218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416173,272513,441641,95496,8328,65,270497,436264,45525,32040,412721,156133,256,21793,46212,486374]

theorem envBound22218 : H12AffineFastState.Bounded env22218 := by
  intro p hp
  have h : env22218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22197_22218 : H12AffineEnvironment.transform 21 272513 env22197 = env22218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env22197 == env22218) = true)

theorem identity22218 : scanCanonicalize (H12AffineFastState.compose env22218 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound22218 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,156013,62661,95496,8328,65,158029,57796,45525,32040,1501,156133,256,21793,46212,74250]

theorem envBound22219 : H12AffineFastState.Bounded env22219 := by
  intro p hp
  have h : env22219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22218_22219 : H12AffineEnvironment.transform 17 149996 env22218 = env22219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env22218 == env22219) = true)

theorem identity22219 : scanCanonicalize (H12AffineFastState.compose env22219 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22219 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4161,156013,62661,21763,8328,65,158029,57796,45525,32040,1501,156133,256,21793,46212,513]

theorem envBound22220 : H12AffineFastState.Bounded env22220 := by
  intro p hp
  have h : env22220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22219_22220 : H12AffineEnvironment.transform 15 8203 env22219 = env22220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22219 == env22220) = true)

theorem identity22220 : scanCanonicalize (H12AffineFastState.compose env22220 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound22220 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env22221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8203,131072,146744,1024,32769,4161,136633,32785,8663,8328,65,138649,38160,45525,2556,1501,136497,256,8693,46212,513]

theorem envBound22221 : H12AffineFastState.Bounded env22221 := by
  intro p hp
  have h : env22221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22220_22221 : H12AffineEnvironment.transform 13 13524 env22220 = env22221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env22220 == env22221) = true)

theorem identity22221 : scanCanonicalize (H12AffineFastState.compose env22221 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound22221 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env22222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8203,5529,10401,1024,32769,4161,32,32785,8663,8328,65,2048,38160,45525,2556,1501,168,256,8693,46212,513]

theorem envBound22222 : H12AffineFastState.Bounded env22222 := by
  intro p hp
  have h : env22222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22221_22222 : H12AffineEnvironment.transform 16 5529 env22221 = env22222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env22221 == env22222) = true)

theorem identity22222 : scanCanonicalize (H12AffineFastState.compose env22222 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22222 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env22223 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,8203,5529,10401,1024,32769,4112,32,32785,8582,8328,16,2048,38160,45444,2477,1420,168,256,8612,46212,513]

theorem envBound22223 : H12AffineFastState.Bounded env22223 := by
  intro p hp
  have h : env22223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22222_22223 : H12AffineEnvironment.transform 5 17 env22222 = env22223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22222 == env22223) = true)

theorem identity22223 : scanCanonicalize (H12AffineFastState.compose env22223 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound22223 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22224 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,32768,398,5529,2340,1024,32769,4112,32,32785,3,269,16,2048,38160,36865,2477,1420,168,256,33,38145,513]

theorem envBound22224 : H12AffineFastState.Bounded env22224 := by
  intro p hp
  have h : env22224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22223_22224 : H12AffineEnvironment.transform 12 389 env22223 = env22224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env22223 == env22224) = true)

theorem identity22224 : scanCanonicalize (H12AffineFastState.compose env22224 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound22224 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env22225 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,292,398,5529,2340,1024,293,4112,32,309,3,269,16,2048,5172,4389,2477,1420,168,256,33,5157,513]

theorem envBound22225 : H12AffineFastState.Bounded env22225 := by
  intro p hp
  have h : env22225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22224_22225 : H12AffineEnvironment.transform 14 292 env22224 = env22225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env22224 == env22225) = true)

theorem identity22225 : scanCanonicalize (H12AffineFastState.compose env22225 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound22225 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env22226 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2493,389,3261,292,398,3108,2340,1024,293,2477,32,309,3,269,16,2048,3465,2200,2477,1420,168,256,33,3480,513]

theorem envBound22226 : H12AffineFastState.Bounded env22226 := by
  intro p hp
  have h : env22226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22225_22226 : H12AffineEnvironment.transform 11 2493 env22225 = env22226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env22225 == env22226) = true)

theorem identity22226 : scanCanonicalize (H12AffineFastState.compose env22226 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound22226 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22227 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2064,40,3261,137,35,3108,2185,1024,136,2048,32,152,3,160,16,2048,3108,2200,2048,1057,168,173,33,3125,513]

theorem envBound22227 : H12AffineFastState.Bounded env22227 := by
  intro p hp
  have h : env22227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22226_22227 : H12AffineEnvironment.transform 7 173 env22226 = env22227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env22226 == env22227) = true)

theorem identity22227 : scanCanonicalize (H12AffineFastState.compose env22227 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22227 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22228 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,2064,40,2185,137,35,2064,2185,52,136,2048,32,152,3,160,16,2048,2064,2200,2048,21,168,173,33,2049,513]

theorem envBound22228 : H12AffineFastState.Bounded env22228 := by
  intro p hp
  have h : env22228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22227_22228 : H12AffineEnvironment.transform 9 52 env22227 = env22228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22227 == env22228) = true)

theorem identity22228 : scanCanonicalize (H12AffineFastState.compose env22228 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22229 : List Nat := [2,4,8,16,32,17,128,173,512,52,0,16,40,137,137,35,16,137,52,136,0,32,152,3,160,16,0,16,152,0,21,168,173,33,1,513]

theorem envBound22229 : H12AffineFastState.Bounded env22229 := by
  intro p hp
  have h : env22229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22228_22229 : H12AffineEnvironment.transform 10 0 env22228 = env22229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22228 == env22229) = true)

def env22230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound22230 : H12AffineFastState.Bounded env22230 := by
  intro p hp
  have h : env22230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22040_22230 : H12AffineEnvironment.transform 18 1025 env22040 = env22230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22040 == env22230) = true)

theorem identity22230 : scanCanonicalize (H12AffineFastState.compose env22230 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound22230 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616288,18973836,10507601,8579232,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound22231 : H12AffineFastState.Bounded env22231 := by
  intro p hp
  have h : env22231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22230_22231 : H12AffineEnvironment.transform 17 10400 env22230 = env22231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env22230 == env22231) = true)

def env22232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616168,18973700,10507601,8579112,25265168,23160137,257,27378724,27337992,25207630]

theorem envBound22232 : H12AffineFastState.Bounded env22232 := by
  intro p hp
  have h : env22232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22231_22232 : H12AffineEnvironment.transform 6 8 env22231 = env22232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22231 == env22232) = true)

theorem identity22232 : scanCanonicalize (H12AffineFastState.compose env22232 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 8429903) := by decide +kernel

theorem selectedBound22232 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,8429903,8192,65,4409703,10560843,10507601,8579112,75103,14795782,257,2188651,2196551,513]

theorem envBound22233 : H12AffineFastState.Bounded env22233 := by
  intro p hp
  have h : env22233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22232_22233 : H12AffineEnvironment.transform 23 8429903 env22232 = env22233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429903 env22232 == env22233) = true)

def env22234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155532,2114883,8192,65,4409703,115015,45405,2231332,75103,4268042,257,2188651,2196551,513]

theorem envBound22234 : H12AffineFastState.Bounded env22234 := by
  intro p hp
  have h : env22234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22233_22234 : H12AffineEnvironment.transform 22 2155532 env22233 = env22234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env22233 == env22234) = true)

def env22235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114883,8192,65,215367,115015,45405,2231332,75103,73770,257,2188651,2196551,513]

theorem envBound22235 : H12AffineFastState.Bounded env22235 := by
  intro p hp
  have h : env22235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22234_22235 : H12AffineEnvironment.transform 21 32 env22234 = env22235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22234 == env22235) = true)

def env22236 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114835,8192,17,215319,114967,45325,2231332,75023,73770,257,2188603,2196503,513]

theorem envBound22236 : H12AffineFastState.Bounded env22236 := by
  intro p hp
  have h : env22236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22235_22236 : H12AffineEnvironment.transform 5 16 env22235 = env22236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22235 == env22236) = true)

theorem identity22236 : scanCanonicalize (H12AffineFastState.compose env22236 (packedSelected [14,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound22236 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env22237 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58397,32,17,41230,8192,17,215319,114967,45325,190521,75023,73770,257,98598,90122,513]

theorem envBound22237 : H12AffineFastState.Bounded env22237 := by
  intro p hp
  have h : env22237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22236_22237 : H12AffineEnvironment.transform 20 58397 env22236 = env22237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env22236 == env22237) = true)

theorem identity22237 : scanCanonicalize (H12AffineFastState.compose env22237 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound22237 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env22238 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10280,1025,32769,58397,32,17,41230,8192,17,190748,24860,45325,190521,34052,32801,257,8493,49153,513]

theorem envBound22238 : H12AffineFastState.Bounded env22238 := by
  intro p hp
  have h : env22238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22237_22238 : H12AffineEnvironment.transform 15 40971 env22237 = env22238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env22237 == env22238) = true)

theorem identity22238 : scanCanonicalize (H12AffineFastState.compose env22238 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound22238 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22239 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1025,32769,58397,32,17,41230,8192,17,43277,24860,45325,43048,34052,32801,257,8493,49153,513]

theorem envBound22239 : H12AffineFastState.Bounded env22239 := by
  intro p hp
  have h : env22239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22238_22239 : H12AffineEnvironment.transform 16 16401 env22238 = env22239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22238 == env22239) = true)

theorem identity22239 : scanCanonicalize (H12AffineFastState.compose env22239 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22239 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22240 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,262,16401,10280,1025,8460,17680,32,17,3,8192,17,2048,24860,4096,2341,9225,8492,257,8493,24844,513]

theorem envBound22240 : H12AffineFastState.Bounded env22240 := by
  intro p hp
  have h : env22240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22239_22240 : H12AffineEnvironment.transform 14 8461 env22239 = env22240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env22239 == env22240) = true)

theorem identity22240 : scanCanonicalize (H12AffineFastState.compose env22240 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22241 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1025,1,17680,32,17,3,269,17,2048,16401,4096,2341,1284,33,257,32,16385,513]

theorem envBound22241 : H12AffineFastState.Bounded env22241 := by
  intro p hp
  have h : env22241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22240_22241 : H12AffineEnvironment.transform 12 269 env22240 = env22241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22240 == env22241) = true)

end H12CloudChart0