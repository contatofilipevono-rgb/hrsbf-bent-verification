import H12CloudChart0Data217

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans55195_55196 : H12AffineEnvironment.transform 15 8202 env55195 = env55196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55195 == env55196) = true)

theorem identity55196 : scanCanonicalize (H12AffineFastState.compose env55196 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound55196 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55197 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,8202,5220,34816,1024,32769,4160,4194304,16,41003,8193,64,4229152,5221,4096,2048,1056,4235304,116,32,46093,513]

theorem envBound55197 : H12AffineFastState.Bounded env55197 := by
  intro p hp
  have h : env55197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55196_55197 : H12AffineEnvironment.transform 13 5237 env55196 = env55197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env55196 == env55197) = true)

theorem identity55197 : scanCanonicalize (H12AffineFastState.compose env55197 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 44135) := by decide +kernel

theorem selectedBound55197 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env55198 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,8202,5220,34816,1024,32769,4160,44135,16,41003,8193,64,9287,5221,4096,2048,1056,3151,116,32,46093,513]

theorem envBound55198 : H12AffineFastState.Bounded env55198 := by
  intro p hp
  have h : env55198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55197_55198 : H12AffineEnvironment.transform 21 44135 env55197 = env55198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 44135 env55197 == env55198) = true)

theorem identity55198 : scanCanonicalize (H12AffineFastState.compose env55198 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55198 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env55199 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,32768,35,5220,34816,1024,32769,4160,35918,16,32770,40,64,1134,5221,4096,2048,1056,3151,116,32,37924,513]

theorem envBound55199 : H12AffineFastState.Bounded env55199 := by
  intro p hp
  have h : env55199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55198_55199 : H12AffineEnvironment.transform 12 41 env55198 = env55199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55198 == env55199) = true)

theorem identity55199 : scanCanonicalize (H12AffineFastState.compose env55199 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound55199 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55200 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1087,4096,41,5237,32768,35,5220,33855,1024,32769,4160,32881,16,32770,40,64,1134,5221,4096,1087,1056,112,116,32,37924,513]

theorem envBound55200 : H12AffineFastState.Bounded env55200 := by
  intro p hp
  have h : env55200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55199_55200 : H12AffineEnvironment.transform 10 1087 env55199 = env55200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env55199 == env55200) = true)

theorem identity55200 : scanCanonicalize (H12AffineFastState.compose env55200 (packedSelected [5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound55200 : packedSelected [5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env55201 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1087,4096,41,5237,81,35,5220,1134,1024,80,4160,32,16,83,40,64,1134,5221,4096,1087,1056,112,116,32,5237,513]

theorem envBound55201 : H12AffineFastState.Bounded env55201 := by
  intro p hp
  have h : env55201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55200_55201 : H12AffineEnvironment.transform 14 81 env55200 = env55201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env55200 == env55201) = true)

theorem identity55201 : scanCanonicalize (H12AffineFastState.compose env55201 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound55201 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env55202 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1087,80,41,1061,81,35,1076,1134,1024,80,16,32,16,83,40,64,1134,1077,80,1087,1056,112,116,32,1061,513]

theorem envBound55202 : H12AffineFastState.Bounded env55202 := by
  intro p hp
  have h : env55202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55201_55202 : H12AffineEnvironment.transform 11 80 env55201 = env55202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env55201 == env55202) = true)

theorem identity55202 : scanCanonicalize (H12AffineFastState.compose env55202 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55202 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55203 : List Nat := [2,4,8,16,32,64,9,116,512,52,11,80,41,17,81,35,0,90,52,80,16,32,16,83,40,64,90,1,80,11,20,112,116,32,17,513]

theorem envBound55203 : H12AffineFastState.Bounded env55203 := by
  intro p hp
  have h : env55203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55202_55203 : H12AffineEnvironment.transform 9 52 env55202 = env55203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55202 == env55203) = true)

theorem identity55203 : scanCanonicalize (H12AffineFastState.compose env55203 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 127) := by decide +kernel

theorem selectedBound55203 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55204 : List Nat := [2,4,8,16,32,64,9,116,127,52,11,80,41,17,81,35,0,90,52,80,16,32,16,83,40,64,90,1,80,11,20,112,116,32,17,126]

theorem envBound55204 : H12AffineFastState.Bounded env55204 := by
  intro p hp
  have h : env55204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55203_55204 : H12AffineEnvironment.transform 8 127 env55203 = env55204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 127 env55203 == env55204) = true)

theorem identity55204 : scanCanonicalize (H12AffineFastState.compose env55204 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55204 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55205 : List Nat := [2,4,8,16,32,16,9,36,47,52,11,0,41,17,1,35,0,10,52,0,16,32,16,3,40,16,10,1,0,11,20,32,36,32,17,46]

theorem envBound55205 : H12AffineFastState.Bounded env55205 := by
  intro p hp
  have h : env55205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55204_55205 : H12AffineEnvironment.transform 5 16 env55204 = env55205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55204 == env55205) = true)

def env55206 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56437,1024,32769,4161,4194304,16,98336,8193,64,4250708,5221,17524,23669,1057,4256861,116,21589,46093,74250]

theorem envBound55206 : H12AffineFastState.Bounded env55206 := by
  intro p hp
  have h : env55206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55194_55206 : H12AffineEnvironment.transform 20 4161 env55194 = env55206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55194 == env55206) = true)

theorem identity55206 : scanCanonicalize (H12AffineFastState.compose env55206 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound55206 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55207 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54359,16401,56437,1024,32769,4161,4194304,16,21623,8193,64,4250708,5221,17524,23669,1057,4256861,116,21589,46093,63069]

theorem envBound55207 : H12AffineFastState.Bounded env55207 := by
  intro p hp
  have h : env55207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55206_55207 : H12AffineEnvironment.transform 15 54359 env55206 = env55207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env55206 == env55207) = true)

theorem identity55207 : scanCanonicalize (H12AffineFastState.compose env55207 (packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound55207 : packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env55208 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54359,16401,56437,1024,32769,4161,8201,16,21623,8193,64,64605,5221,17524,23669,1057,54356,116,21589,46093,63069]

theorem envBound55208 : H12AffineFastState.Bounded env55208 := by
  intro p hp
  have h : env55208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55207_55208 : H12AffineEnvironment.transform 21 8201 env55207 = env55208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env55207 == env55208) = true)

theorem identity55208 : scanCanonicalize (H12AffineFastState.compose env55208 (packedSelected [2,3,4,5,6,9,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound55208 : packedSelected [2,3,4,5,6,9,15,18,19] rootPS < 2^1333 := by decide +kernel

def env55209 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,32802,5220,34816,1024,32769,4161,8201,16,2,8193,64,43048,5221,4097,2048,1057,32801,116,32,46093,41512]

theorem envBound55209 : H12AffineFastState.Bounded env55209 := by
  intro p hp
  have h : env55209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55208_55209 : H12AffineEnvironment.transform 13 5237 env55208 = env55209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env55208 == env55209) = true)

theorem identity55209 : scanCanonicalize (H12AffineFastState.compose env55209 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound55209 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env55210 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,8233,8203,5220,10281,1024,8232,4161,8201,16,2,8193,64,2049,5221,4097,2048,1057,8200,116,32,5156,513]

theorem envBound55210 : H12AffineFastState.Bounded env55210 := by
  intro p hp
  have h : env55210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55209_55210 : H12AffineEnvironment.transform 14 8233 env55209 = env55210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env55209 == env55210) = true)

theorem identity55210 : scanCanonicalize (H12AffineFastState.compose env55210 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55210 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55211 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,0,34,5220,2048,1024,1,4161,32,16,2,40,64,2049,5221,4097,2048,1057,33,116,32,5156,513]

theorem envBound55211 : H12AffineFastState.Bounded env55211 := by
  intro p hp
  have h : env55211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55210_55211 : H12AffineEnvironment.transform 12 41 env55210 = env55211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55210 == env55211) = true)

theorem identity55211 : scanCanonicalize (H12AffineFastState.compose env55211 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound55211 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55212 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1572,41,593,0,34,576,2048,1024,1,1637,32,16,2,40,64,2049,577,1573,2048,1057,33,116,32,512,513]

theorem envBound55212 : H12AffineFastState.Bounded env55212 := by
  intro p hp
  have h : env55212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55211_55212 : H12AffineEnvironment.transform 11 1572 env55211 = env55212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env55211 == env55212) = true)

theorem identity55212 : scanCanonicalize (H12AffineFastState.compose env55212 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound55212 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55213 : List Nat := [2,4,8,16,32,64,9,116,512,1024,577,1572,41,593,0,34,576,577,1024,1,1637,32,16,2,40,64,576,577,1573,577,1057,33,116,32,512,513]

theorem envBound55213 : H12AffineFastState.Bounded env55213 := by
  intro p hp
  have h : env55213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55212_55213 : H12AffineEnvironment.transform 10 577 env55212 = env55213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env55212 == env55213) = true)

theorem identity55213 : scanCanonicalize (H12AffineFastState.compose env55213 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound55213 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55214 : List Nat := [2,4,8,16,32,1,9,53,512,1024,512,1572,41,528,0,34,513,512,1024,1,1572,32,16,2,40,1,513,512,1573,512,1057,33,53,32,512,513]

theorem envBound55214 : H12AffineFastState.Bounded env55214 := by
  intro p hp
  have h : env55214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55213_55214 : H12AffineEnvironment.transform 5 1 env55213 = env55214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55213 == env55214) = true)

theorem identity55214 : scanCanonicalize (H12AffineFastState.compose env55214 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound55214 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55215 : List Nat := [2,4,8,16,32,1,9,53,512,37,512,513,41,528,0,34,513,512,37,1,513,32,16,2,40,1,513,512,512,512,4,33,53,32,512,513]

theorem envBound55215 : H12AffineFastState.Bounded env55215 := by
  intro p hp
  have h : env55215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55214_55215 : H12AffineEnvironment.transform 9 37 env55214 = env55215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env55214 == env55215) = true)

theorem identity55215 : scanCanonicalize (H12AffineFastState.compose env55215 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55215 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55216 : List Nat := [2,4,8,16,16,1,9,5,512,21,512,513,25,528,0,18,513,512,21,1,513,16,16,2,24,1,513,512,512,512,4,17,5,16,512,513]

theorem envBound55216 : H12AffineFastState.Bounded env55216 := by
  intro p hp
  have h : env55216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55215_55216 : H12AffineEnvironment.transform 4 16 env55215 = env55216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55215 == env55216) = true)

theorem identity55216 : scanCanonicalize (H12AffineFastState.compose env55216 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55217 : List Nat := [2,4,8,0,0,1,9,5,512,5,512,513,9,512,0,2,513,512,5,1,513,0,0,2,8,1,513,512,512,512,4,1,5,0,512,513]

theorem envBound55217 : H12AffineFastState.Bounded env55217 := by
  intro p hp
  have h : env55217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55216_55217 : H12AffineEnvironment.transform 3 0 env55216 = env55217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55216 == env55217) = true)

theorem identity55217 : scanCanonicalize (H12AffineFastState.compose env55217 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55217 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55218 : List Nat := [2,4,8,0,0,1,9,5,1,5,1,0,9,1,0,2,0,1,5,1,0,0,0,2,8,1,0,1,1,1,4,1,5,0,1,0]

theorem envBound55218 : H12AffineFastState.Bounded env55218 := by
  intro p hp
  have h : env55218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55217_55218 : H12AffineEnvironment.transform 8 1 env55217 = env55218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55217 == env55218) = true)

def env55219 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331969,18973700,2118708,294912,16876545,23159869,117,18990132,18949229,16818731]

theorem envBound55219 : H12AffineFastState.Bounded env55219 := by
  intro p hp
  have h : env55219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55177_55219 : H12AffineEnvironment.transform 7 117 env55177 = env55219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55177 == env55219) = true)

theorem identity55219 : scanCanonicalize (H12AffineFastState.compose env55219 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound55219 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env55220 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,388159,4194304,16,16777216,8193,64,21331969,17066043,374795,294912,16876545,21268482,117,17049611,17090642,16818731]

theorem envBound55220 : H12AffineFastState.Bounded env55220 := by
  intro p hp
  have h : env55220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55219_55220 : H12AffineEnvironment.transform 20 388159 env55219 = env55220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env55219 == env55220) = true)

def env55221 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,388159,4194304,16,351316,8193,64,4250709,78959,374795,294912,317525,4314198,117,95327,103430,392831]

theorem envBound55221 : H12AffineFastState.Bounded env55221 := by
  intro p hp
  have h : env55221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55220_55221 : H12AffineEnvironment.transform 23 351316 env55220 = env55221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351316 env55220 == env55221) = true)

def env55222 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115735,4194304,16,95356,8193,64,4250709,78959,102435,43048,61565,4314198,117,95327,103430,120407]

theorem envBound55222 : H12AffineFastState.Bounded env55222 := by
  intro p hp
  have h : env55222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55221_55222 : H12AffineEnvironment.transform 17 10280 env55221 = env55222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55221 == env55222) = true)

theorem identity55222 : scanCanonicalize (H12AffineFastState.compose env55222 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55222 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55223 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1024,32769,58397,4194304,16,21622,8193,64,4250709,5221,45097,43048,61565,4256860,117,21589,46092,63069]

theorem envBound55223 : H12AffineFastState.Bounded env55223 := by
  intro p hp
  have h : env55223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55222_55223 : H12AffineEnvironment.transform 15 8202 env55222 = env55223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55222 == env55223) = true)

theorem identity55223 : scanCanonicalize (H12AffineFastState.compose env55223 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound55223 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55224 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29789,8202,16401,10280,1024,29788,4160,4194304,16,21622,8193,64,4204552,5221,17524,23669,1056,4194305,117,21589,16465,512]

theorem envBound55224 : H12AffineFastState.Bounded env55224 := by
  intro p hp
  have h : env55224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55223_55224 : H12AffineEnvironment.transform 14 29789 env55223 = env55224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env55223 == env55224) = true)

theorem identity55224 : scanCanonicalize (H12AffineFastState.compose env55224 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound55224 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55225 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,16384,28729,8202,16401,10280,100,28728,4160,4194304,16,20498,8193,64,4204552,4097,16400,22545,68,4194305,117,20529,16465,512]

theorem envBound55225 : H12AffineFastState.Bounded env55225 := by
  intro p hp
  have h : env55225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55224_55225 : H12AffineEnvironment.transform 9 100 env55224 = env55225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env55224 == env55225) = true)

theorem identity55225 : scanCanonicalize (H12AffineFastState.compose env55225 (packedSelected [2,4,6,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 10249) := by decide +kernel

theorem selectedBound55225 : packedSelected [2,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env55226 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,10249,6192,8202,10264,10280,100,6193,4160,4194304,16,14363,8193,64,4204552,4097,10265,12312,68,4194305,117,14392,10328,512]

theorem envBound55226 : H12AffineFastState.Bounded env55226 := by
  intro p hp
  have h : env55226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55225_55226 : H12AffineEnvironment.transform 13 10249 env55225 = env55226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10249 env55225 == env55226) = true)

theorem identity55226 : scanCanonicalize (H12AffineFastState.compose env55226 (packedSelected [1,2,3,6,15] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound55226 : packedSelected [1,2,3,6,15] rootPS < 2^1333 := by decide +kernel

def env55227 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,88,2129,6192,82,2112,2160,100,6193,4160,4194304,16,6211,89,64,4196432,4097,2113,4160,68,4194305,117,6240,2048,512]

theorem envBound55227 : H12AffineFastState.Bounded env55227 := by
  intro p hp
  have h : env55227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55226_55227 : H12AffineEnvironment.transform 12 88 env55226 = env55227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env55226 == env55227) = true)

theorem identity55227 : scanCanonicalize (H12AffineFastState.compose env55227 (packedSelected [1,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 80) := by decide +kernel

theorem selectedBound55227 : packedSelected [1,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env55228 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,88,2129,6192,82,2112,2160,100,6193,4160,80,16,6211,89,64,2048,4097,2113,4160,68,81,117,6240,2048,512]

theorem envBound55228 : H12AffineFastState.Bounded env55228 := by
  intro p hp
  have h : env55228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55227_55228 : H12AffineEnvironment.transform 21 80 env55227 = env55228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80 env55227 == env55228) = true)

theorem identity55228 : scanCanonicalize (H12AffineFastState.compose env55228 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound55228 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env55229 : List Nat := [2,4,8,16,32,48,9,5,512,20,2048,4096,40,2081,6192,34,2096,2048,20,6193,4144,32,16,6195,41,48,2048,4097,2097,4144,52,33,5,6160,2048,512]

theorem envBound55229 : H12AffineFastState.Bounded env55229 := by
  intro p hp
  have h : env55229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55228_55229 : H12AffineEnvironment.transform 5 48 env55228 = env55229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env55228 == env55229) = true)

theorem identity55229 : scanCanonicalize (H12AffineFastState.compose env55229 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55229 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env55230 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8,2049,6160,2,2064,2048,20,6161,4112,0,16,6163,9,16,2048,4097,2065,4112,20,1,5,6160,2048,512]

theorem envBound55230 : H12AffineFastState.Bounded env55230 := by
  intro p hp
  have h : env55230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55229_55230 : H12AffineEnvironment.transform 4 0 env55229 = env55230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55229 == env55230) = true)

theorem identity55230 : scanCanonicalize (H12AffineFastState.compose env55230 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound55230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55231 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2064,8,2049,0,2,2064,2048,20,1,2048,0,16,3,9,16,2048,2065,2065,2048,20,1,5,0,2048,512]

theorem envBound55231 : H12AffineFastState.Bounded env55231 := by
  intro p hp
  have h : env55231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55230_55231 : H12AffineEnvironment.transform 11 2064 env55230 = env55231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env55230 == env55231) = true)

theorem identity55231 : scanCanonicalize (H12AffineFastState.compose env55231 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55232 : List Nat := [2,4,8,16,0,16,9,5,0,20,2048,2064,8,2049,0,2,2064,2048,20,1,2048,0,16,3,9,16,2048,2065,2065,2048,20,1,5,0,2048,0]

theorem envBound55232 : H12AffineFastState.Bounded env55232 := by
  intro p hp
  have h : env55232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55231_55232 : H12AffineEnvironment.transform 8 0 env55231 = env55232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55231 == env55232) = true)

theorem identity55232 : scanCanonicalize (H12AffineFastState.compose env55232 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound55232 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55233 : List Nat := [2,4,8,4,0,4,9,5,0,0,2048,2052,8,2049,0,2,2052,2048,0,1,2048,0,4,3,9,4,2048,2053,2053,2048,0,1,5,0,2048,0]

theorem envBound55233 : H12AffineFastState.Bounded env55233 := by
  intro p hp
  have h : env55233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55232_55233 : H12AffineEnvironment.transform 3 4 env55232 = env55233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env55232 == env55233) = true)

def leafEnv55233 : List Nat := [2,4,8,4,0,4,9,5,0,0,2048,2052,8,2049,0,2,2052,2048,0,1,2048,0,4,3,0,9,1,4,2048,2053,2053,2048,0,1,5,0,4,3,2048,0,1,2049,0]

def active55233 : List Nat := [0,1,2,10]

def tree55233 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55233 : H12WitnessSearch.Good tree55233 := H12GlobalWitnessIndex.good

theorem leafIdentity55233 : H12AffineFastState.composeSystem env55233 rootObs = leafEnv55233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55233 rootObs == leafEnv55233) = true)

theorem terminalChecked55233 : H12PackedTerminal.terminalCheckFast leafEnv55233 active55233 tree55233 = true := by decide +kernel

def env55234 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1024,32769,115734,4194304,16,95357,8193,64,4250709,78959,102434,43049,61564,4314198,117,95327,103430,120406]

theorem envBound55234 : H12AffineFastState.Bounded env55234 := by
  intro p hp
  have h : env55234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55221_55234 : H12AffineEnvironment.transform 17 10281 env55221 = env55234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55221 == env55234) = true)

theorem identity55234 : scanCanonicalize (H12AffineFastState.compose env55234 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound55234 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55235 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54359,16401,10281,1024,32769,4161,4194304,16,41002,8193,64,4250709,57400,17525,43049,61564,4194305,117,40968,16465,513]

theorem envBound55235 : H12AffineFastState.Bounded env55235 := by
  intro p hp
  have h : env55235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55234_55235 : H12AffineEnvironment.transform 15 54359 env55234 = env55235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env55234 == env55235) = true)

theorem identity55235 : scanCanonicalize (H12AffineFastState.compose env55235 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound55235 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env55236 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54359,16401,10281,1024,32769,4161,8200,16,41002,8193,64,64605,57400,17525,43049,61564,8201,117,40968,16465,513]

theorem envBound55236 : H12AffineFastState.Bounded env55236 := by
  intro p hp
  have h : env55236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55235_55236 : H12AffineEnvironment.transform 21 8200 env55235 = env55236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env55235 == env55236) = true)

theorem identity55236 : scanCanonicalize (H12AffineFastState.compose env55236 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound55236 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env55237 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13404,32768,40971,13389,10281,1024,32769,4161,8200,16,41002,8193,64,34817,37988,12329,43049,33824,8201,117,40968,13325,513]

theorem envBound55237 : H12AffineFastState.Bounded env55237 := by
  intro p hp
  have h : env55237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55236_55237 : H12AffineEnvironment.transform 13 13404 env55236 = env55237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env55236 == env55237) = true)

theorem identity55237 : scanCanonicalize (H12AffineFastState.compose env55237 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55237 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55238 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13324,32768,40971,13341,10281,1024,32769,4113,8200,16,41002,8193,16,34817,37940,12329,43049,33824,8201,37,40968,13325,513]

theorem envBound55238 : H12AffineFastState.Bounded env55238 := by
  intro p hp
  have h : env55238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55237_55238 : H12AffineEnvironment.transform 5 16 env55237 = env55238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55237 == env55238) = true)

theorem identity55238 : scanCanonicalize (H12AffineFastState.compose env55238 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55238 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55239 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,32768,32803,5173,2049,1024,32769,4113,32,16,32770,41,16,34817,37940,4097,34817,33824,33,37,32800,5157,513]

theorem envBound55239 : H12AffineFastState.Bounded env55239 := by
  intro p hp
  have h : env55239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55238_55239 : H12AffineEnvironment.transform 12 40 env55238 = env55239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55238 == env55239) = true)

theorem identity55239 : scanCanonicalize (H12AffineFastState.compose env55239 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55239 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55240 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,35,5173,2049,1024,1,4113,32,16,2,41,16,2049,5172,4097,2049,1056,33,37,32,5157,513]

theorem envBound55240 : H12AffineFastState.Bounded env55240 := by
  intro p hp
  have h : env55240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55239_55240 : H12AffineEnvironment.transform 14 0 env55239 = env55240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55239 == env55240) = true)

theorem identity55240 : scanCanonicalize (H12AffineFastState.compose env55240 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound55240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55241 : List Nat := [2,4,8,16,32,16,9,37,512,36,2048,4096,40,4096,0,35,4113,2049,36,1,4113,32,16,2,41,16,2049,4112,4097,2049,4,33,37,32,4097,513]

theorem envBound55241 : H12AffineFastState.Bounded env55241 := by
  intro p hp
  have h : env55241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55240_55241 : H12AffineEnvironment.transform 9 36 env55240 = env55241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env55240 == env55241) = true)

theorem identity55241 : scanCanonicalize (H12AffineFastState.compose env55241 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound55241 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55242 : List Nat := [2,4,8,16,32,16,9,37,512,36,2048,512,40,512,0,35,529,2049,36,1,529,32,16,2,41,16,2049,528,513,2049,4,33,37,32,513,513]

theorem envBound55242 : H12AffineFastState.Bounded env55242 := by
  intro p hp
  have h : env55242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55241_55242 : H12AffineEnvironment.transform 11 512 env55241 = env55242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env55241 == env55242) = true)

theorem identity55242 : scanCanonicalize (H12AffineFastState.compose env55242 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55242 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55243 : List Nat := [2,4,8,16,32,16,9,37,1,36,2048,1,40,1,0,35,16,2049,36,1,16,32,16,2,41,16,2049,17,0,2049,4,33,37,32,0,0]

theorem envBound55243 : H12AffineFastState.Bounded env55243 := by
  intro p hp
  have h : env55243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55242_55243 : H12AffineEnvironment.transform 8 1 env55242 = env55243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55242 == env55243) = true)

theorem identity55243 : scanCanonicalize (H12AffineFastState.compose env55243 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55243 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55244 : List Nat := [2,4,8,1,32,1,9,37,1,36,2048,1,40,1,0,35,1,2049,36,1,1,32,1,2,41,1,2049,0,0,2049,4,33,37,32,0,0]

theorem envBound55244 : H12AffineFastState.Bounded env55244 := by
  intro p hp
  have h : env55244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55243_55244 : H12AffineEnvironment.transform 3 1 env55243 = env55244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55243 == env55244) = true)

theorem identity55244 : scanCanonicalize (H12AffineFastState.compose env55244 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55244 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55245 : List Nat := [2,4,8,1,1,1,9,4,1,5,2048,1,9,1,0,2,1,2049,5,1,1,1,1,2,8,1,2049,0,0,2049,4,0,4,1,0,0]

theorem envBound55245 : H12AffineFastState.Bounded env55245 := by
  intro p hp
  have h : env55245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55244_55245 : H12AffineEnvironment.transform 4 1 env55244 = env55245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55244 == env55245) = true)

def env55246 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,388159,4194304,16,351317,8193,64,4250708,78958,374795,294912,317524,4314199,117,95326,103431,392830]

theorem envBound55246 : H12AffineFastState.Bounded env55246 := by
  intro p hp
  have h : env55246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55220_55246 : H12AffineEnvironment.transform 23 351317 env55220 = env55246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351317 env55220 == env55246) = true)

theorem identity55246 : scanCanonicalize (H12AffineFastState.compose env55246 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound55246 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env55247 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,130175,1024,32769,4160,4194304,16,41002,8193,64,4250708,78958,17524,97407,74795,4314199,117,95326,103431,513]

theorem envBound55247 : H12AffineFastState.Bounded env55247 := by
  intro p hp
  have h : env55247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55246_55247 : H12AffineEnvironment.transform 17 130175 env55246 = env55247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env55246 == env55247) = true)

theorem identity55247 : scanCanonicalize (H12AffineFastState.compose env55247 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound55247 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env55248 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54358,16401,10281,1024,32769,4160,4194304,16,41002,8193,64,4250708,57400,17524,43049,61565,4194305,117,40968,16465,513]

theorem envBound55248 : H12AffineFastState.Bounded env55248 := by
  intro p hp
  have h : env55248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55247_55248 : H12AffineEnvironment.transform 15 54358 env55247 = env55248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env55247 == env55248) = true)

theorem identity55248 : scanCanonicalize (H12AffineFastState.compose env55248 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound55248 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env55249 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54358,16401,10281,1024,32769,4160,8200,16,41002,8193,64,64604,57400,17524,43049,61565,8201,117,40968,16465,513]

theorem envBound55249 : H12AffineFastState.Bounded env55249 := by
  intro p hp
  have h : env55249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55248_55249 : H12AffineEnvironment.transform 21 8200 env55248 = env55249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env55248 == env55249) = true)

theorem identity55249 : scanCanonicalize (H12AffineFastState.compose env55249 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55249 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env55250 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,32768,40971,13388,10281,1024,32769,4160,8200,16,41002,8193,64,34817,37989,12329,43049,33824,8201,117,40968,13324,513]

theorem envBound55250 : H12AffineFastState.Bounded env55250 := by
  intro p hp
  have h : env55250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55249_55250 : H12AffineEnvironment.transform 13 13405 env55249 = env55250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55249 == env55250) = true)

theorem identity55250 : scanCanonicalize (H12AffineFastState.compose env55250 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55250 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55251 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,32768,40971,13340,10281,1024,32769,4112,8200,16,41002,8193,16,34817,37941,12329,43049,33824,8201,37,40968,13324,513]

theorem envBound55251 : H12AffineFastState.Bounded env55251 := by
  intro p hp
  have h : env55251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55250_55251 : H12AffineEnvironment.transform 5 16 env55250 = env55251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55250 == env55251) = true)

theorem identity55251 : scanCanonicalize (H12AffineFastState.compose env55251 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55251 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55252 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,32768,32803,5172,2049,1024,32769,4112,32,16,32770,41,16,34817,37941,4097,34817,33824,33,37,32800,5156,513]

theorem envBound55252 : H12AffineFastState.Bounded env55252 := by
  intro p hp
  have h : env55252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55251_55252 : H12AffineEnvironment.transform 12 40 env55251 = env55252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55251 == env55252) = true)

theorem identity55252 : scanCanonicalize (H12AffineFastState.compose env55252 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55252 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55253 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,35,5172,2049,1024,1,4112,32,16,2,41,16,2049,5173,4097,2049,1056,33,37,32,5156,513]

theorem envBound55253 : H12AffineFastState.Bounded env55253 := by
  intro p hp
  have h : env55253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55252_55253 : H12AffineEnvironment.transform 14 0 env55252 = env55253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55252 == env55253) = true)

theorem identity55253 : scanCanonicalize (H12AffineFastState.compose env55253 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound55253 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55254 : List Nat := [2,4,8,16,32,16,9,37,512,37,2048,4096,40,4096,0,35,4113,2049,37,1,4112,32,16,2,41,16,2049,4112,4097,2049,5,33,37,32,4097,513]

theorem envBound55254 : H12AffineFastState.Bounded env55254 := by
  intro p hp
  have h : env55254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55253_55254 : H12AffineEnvironment.transform 9 37 env55253 = env55254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env55253 == env55254) = true)

theorem identity55254 : scanCanonicalize (H12AffineFastState.compose env55254 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound55254 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55255 : List Nat := [2,4,8,16,32,16,9,37,512,37,2048,512,40,512,0,35,529,2049,37,1,528,32,16,2,41,16,2049,528,513,2049,5,33,37,32,513,513]

theorem envBound55255 : H12AffineFastState.Bounded env55255 := by
  intro p hp
  have h : env55255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55254_55255 : H12AffineEnvironment.transform 11 512 env55254 = env55255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env55254 == env55255) = true)

theorem identity55255 : scanCanonicalize (H12AffineFastState.compose env55255 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55255 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55256 : List Nat := [2,4,8,16,32,16,9,37,0,37,2048,0,40,0,0,35,17,2049,37,1,16,32,16,2,41,16,2049,16,1,2049,5,33,37,32,1,1]

theorem envBound55256 : H12AffineFastState.Bounded env55256 := by
  intro p hp
  have h : env55256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55255_55256 : H12AffineEnvironment.transform 8 0 env55255 = env55256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55255 == env55256) = true)

theorem identity55256 : scanCanonicalize (H12AffineFastState.compose env55256 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55256 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55257 : List Nat := [2,4,8,1,32,1,9,37,0,37,2048,0,40,0,0,35,0,2049,37,1,1,32,1,2,41,1,2049,1,1,2049,5,33,37,32,1,1]

theorem envBound55257 : H12AffineFastState.Bounded env55257 := by
  intro p hp
  have h : env55257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55256_55257 : H12AffineEnvironment.transform 3 1 env55256 = env55257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55256 == env55257) = true)

theorem identity55257 : scanCanonicalize (H12AffineFastState.compose env55257 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55258 : List Nat := [2,4,8,1,1,1,9,4,0,4,2048,0,9,0,0,2,0,2049,4,1,1,1,1,2,8,1,2049,1,1,2049,5,0,4,1,1,1]

theorem envBound55258 : H12AffineFastState.Bounded env55258 := by
  intro p hp
  have h : env55258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55257_55258 : H12AffineEnvironment.transform 4 1 env55257 = env55258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55257 == env55258) = true)

theorem identity55258 : scanCanonicalize (H12AffineFastState.compose env55258 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55259 : List Nat := [2,4,8,1,1,1,9,4,0,4,0,0,9,0,0,2,0,1,4,1,1,1,1,2,8,1,1,1,1,1,5,0,4,1,1,1]

theorem envBound55259 : H12AffineFastState.Bounded env55259 := by
  intro p hp
  have h : env55259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55258_55259 : H12AffineEnvironment.transform 10 0 env55258 = env55259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55258 == env55259) = true)

def env55260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound55260 : H12AffineFastState.Bounded env55260 := by
  intro p hp
  have h : env55260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55094_55260 : H12AffineEnvironment.transform 18 1025 env55094 = env55260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env55094 == env55260) = true)

theorem identity55260 : scanCanonicalize (H12AffineFastState.compose env55260 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 254096) := by decide +kernel

theorem selectedBound55260 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,254096,8328,64,12853393,2253852,10507601,8830976,8545409,6456657,257,10626108,10667416,8602454]

theorem envBound55261 : H12AffineFastState.Bounded env55261 := by
  intro p hp
  have h : env55261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55260_55261 : H12AffineEnvironment.transform 23 254096 env55260 = env55261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254096 env55260 == env55261) = true)

def env55262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257180,254096,8328,64,6705549,2253852,140365,2404636,2102685,6456657,257,21792,46212,2175562]

theorem envBound55262 : H12AffineFastState.Bounded env55262 := by
  intro p hp
  have h : env55262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55261_55262 : H12AffineEnvironment.transform 22 2257180 env55261 = env55262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257180 env55261 == env55262) = true)

def env55263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257180,254096,8328,64,2157717,2253852,140365,2404636,2102685,2373705,257,21792,46212,2175562]

theorem envBound55263 : H12AffineFastState.Bounded env55263 := by
  intro p hp
  have h : env55263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55262_55263 : H12AffineEnvironment.transform 21 441624 env55262 = env55263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env55262 == env55263) = true)

def env55264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,254096,8328,64,64725,160860,140365,303452,1501,272393,257,21792,46212,74250]

theorem envBound55264 : H12AffineFastState.Bounded env55264 := by
  intro p hp
  have h : env55264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55263_55264 : H12AffineEnvironment.transform 20 4160 env55263 = env55264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55263 == env55264) = true)

theorem identity55264 : scanCanonicalize (H12AffineFastState.compose env55264 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound55264 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,441624,155996,144463,8328,64,64725,160860,140365,303452,1501,272393,257,21792,46212,63189]

theorem envBound55265 : H12AffineFastState.Bounded env55265 := by
  intro p hp
  have h : env55265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55264_55265 : H12AffineEnvironment.transform 15 54495 env55264 = env55265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env55264 == env55265) = true)

def env55266 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4112,441624,155916,144415,8328,16,64645,160780,140317,303372,1421,272393,257,21792,46212,63109]

theorem envBound55266 : H12AffineFastState.Bounded env55266 := by
  intro p hp
  have h : env55266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55265_55266 : H12AffineEnvironment.transform 5 16 env55265 = env55266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55265 == env55266) = true)

theorem identity55266 : scanCanonicalize (H12AffineFastState.compose env55266 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound55266 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env55267 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,171061,1025,32769,4112,8493,155916,144415,8328,16,64645,160780,140317,146745,1421,177212,257,21792,46212,63109]

theorem envBound55267 : H12AffineFastState.Bounded env55267 := by
  intro p hp
  have h : env55267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55266_55267 : H12AffineEnvironment.transform 17 171061 env55266 = env55267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env55266 == env55267) = true)

theorem identity55267 : scanCanonicalize (H12AffineFastState.compose env55267 (packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound55267 : packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env55268 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,13461,43168,1025,32769,4112,8493,21913,138,8328,16,64645,16537,4232,2476,1421,32937,257,21792,46212,63109]

theorem envBound55268 : H12AffineFastState.Bounded env55268 := by
  intro p hp
  have h : env55268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55267_55268 : H12AffineEnvironment.transform 16 13461 env55267 = env55268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env55267 == env55268) = true)

theorem identity55268 : scanCanonicalize (H12AffineFastState.compose env55268 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55268 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env55269 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,13341,43048,1025,32769,4112,8493,21777,2,8192,16,64525,16401,4096,2340,1285,32801,257,21792,46092,62989]

theorem envBound55269 : H12AffineFastState.Bounded env55269 := by
  intro p hp
  have h : env55269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55268_55269 : H12AffineEnvironment.transform 6 8 env55268 = env55269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55268 == env55269) = true)

theorem identity55269 : scanCanonicalize (H12AffineFastState.compose env55269 (packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55269 : packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env55270 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33030,13341,43048,1025,32769,4112,8493,16,2,8192,16,43276,5392,4096,2340,1285,32801,257,33,46092,41740]

theorem envBound55270 : H12AffineFastState.Bounded env55270 := by
  intro p hp
  have h : env55270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55269_55270 : H12AffineEnvironment.transform 13 5377 env55269 = env55270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55269 == env55270) = true)

def env55271 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4113,441624,155917,144414,8328,17,64644,160781,140316,303373,1420,272393,257,21792,46212,63108]

theorem envBound55271 : H12AffineFastState.Bounded env55271 := by
  intro p hp
  have h : env55271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55265_55271 : H12AffineEnvironment.transform 5 17 env55265 = env55271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55265 == env55271) = true)

theorem identity55271 : scanCanonicalize (H12AffineFastState.compose env55271 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 157872) := by decide +kernel

theorem selectedBound55271 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env55272 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,157872,1025,32769,4113,54696,155917,144414,8328,17,64644,160781,140316,182717,1420,147641,257,21792,46212,63108]

theorem envBound55272 : H12AffineFastState.Bounded env55272 := by
  intro p hp
  have h : env55272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55271_55272 : H12AffineEnvironment.transform 17 157872 env55271 = env55272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env55271 == env55272) = true)

theorem identity55272 : scanCanonicalize (H12AffineFastState.compose env55272 (packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound55272 : packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env55273 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,5528,32040,1025,32769,4113,54696,29845,8582,8328,17,64644,24981,12676,56357,1420,21793,257,21792,46212,63108]

theorem envBound55273 : H12AffineFastState.Bounded env55273 := by
  intro p hp
  have h : env55273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55272_55273 : H12AffineEnvironment.transform 16 5528 env55272 = env55273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env55272 == env55273) = true)

theorem identity55273 : scanCanonicalize (H12AffineFastState.compose env55273 (packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound55273 : packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,40971,5528,2477,1025,32769,4113,41261,16,8582,8328,17,34817,5392,12676,43168,1420,8612,257,8613,46212,33281]

theorem envBound55274 : H12AffineFastState.Bounded env55274 := by
  intro p hp
  have h : env55274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55273_55274 : H12AffineEnvironment.transform 13 13445 env55273 = env55274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env55273 == env55274) = true)

theorem identity55274 : scanCanonicalize (H12AffineFastState.compose env55274 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound55274 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env55275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,32768,33167,5528,2477,1025,32769,4113,32937,16,2,268,17,34817,5392,4096,35108,1420,32,257,33,38144,33281]

theorem envBound55275 : H12AffineFastState.Bounded env55275 := by
  intro p hp
  have h : env55275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55274_55275 : H12AffineEnvironment.transform 12 388 env55274 = env55275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env55274 == env55275) = true)

theorem identity55275 : scanCanonicalize (H12AffineFastState.compose env55275 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound55275 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,136,263,5528,2477,1025,137,4113,33,16,2,268,17,2185,5392,4096,2476,1420,32,257,33,5512,649]

theorem envBound55276 : H12AffineFastState.Bounded env55276 := by
  intro p hp
  have h : env55276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55275_55276 : H12AffineEnvironment.transform 14 136 env55275 = env55276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env55275 == env55276) = true)

theorem identity55276 : scanCanonicalize (H12AffineFastState.compose env55276 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55276 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env55277 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,160,5157,136,35,5308,2185,1025,137,4113,33,16,2,40,17,2185,5172,4096,2184,1192,32,37,33,5292,649]

theorem envBound55277 : H12AffineFastState.Bounded env55277 := by
  intro p hp
  have h : env55277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55276_55277 : H12AffineEnvironment.transform 7 36 env55276 = env55277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55276 == env55277) = true)

theorem identity55277 : scanCanonicalize (H12AffineFastState.compose env55277 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55277 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55278 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,0,35,5172,2049,1025,1,4113,33,16,2,40,17,2049,5172,4096,2048,1056,32,37,33,5156,513]

theorem envBound55278 : H12AffineFastState.Bounded env55278 := by
  intro p hp
  have h : env55278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55277_55278 : H12AffineEnvironment.transform 6 8 env55277 = env55278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55277 == env55278) = true)

theorem identity55278 : scanCanonicalize (H12AffineFastState.compose env55278 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55279 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,40,4112,0,35,4097,2049,52,1,4113,33,16,2,40,17,2049,4097,4096,2048,21,32,37,33,4113,513]

theorem envBound55279 : H12AffineFastState.Bounded env55279 := by
  intro p hp
  have h : env55279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55278_55279 : H12AffineEnvironment.transform 9 53 env55278 = env55279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55278 == env55279) = true)

theorem identity55279 : scanCanonicalize (H12AffineFastState.compose env55279 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound55279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55280 : List Nat := [2,4,8,16,32,17,8,36,512,53,48,4096,40,4112,0,35,4097,49,52,1,4113,33,16,2,40,17,49,4097,4096,48,21,32,37,33,4113,513]

theorem envBound55280 : H12AffineFastState.Bounded env55280 := by
  intro p hp
  have h : env55280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55279_55280 : H12AffineEnvironment.transform 10 48 env55279 = env55280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env55279 == env55280) = true)

theorem identity55280 : scanCanonicalize (H12AffineFastState.compose env55280 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound55280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55281 : List Nat := [2,4,8,16,32,17,8,36,512,53,48,529,40,513,0,35,528,49,52,1,512,33,16,2,40,17,49,528,529,48,21,32,37,33,512,513]

theorem envBound55281 : H12AffineFastState.Bounded env55281 := by
  intro p hp
  have h : env55281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55280_55281 : H12AffineEnvironment.transform 11 529 env55280 = env55281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env55280 == env55281) = true)

theorem identity55281 : scanCanonicalize (H12AffineFastState.compose env55281 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound55281 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55282 : List Nat := [2,4,8,16,32,17,8,36,48,53,48,33,40,49,0,35,32,49,52,1,48,33,16,2,40,17,49,32,33,48,21,32,37,33,48,49]

theorem envBound55282 : H12AffineFastState.Bounded env55282 := by
  intro p hp
  have h : env55282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55281_55282 : H12AffineEnvironment.transform 8 48 env55281 = env55282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env55281 == env55282) = true)

def env55283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,254096,8328,64,64724,160861,140365,303453,1500,272392,257,21792,46212,74251]

theorem envBound55283 : H12AffineFastState.Bounded env55283 := by
  intro p hp
  have h : env55283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55263_55283 : H12AffineEnvironment.transform 20 4161 env55263 = env55283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55263 == env55283) = true)

theorem identity55283 : scanCanonicalize (H12AffineFastState.compose env55283 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound55283 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4161,392286,73755,41430,8328,64,64724,79131,91403,303453,1500,272392,257,21792,46212,74251]

theorem envBound55284 : H12AffineFastState.Bounded env55284 := by
  intro p hp
  have h : env55284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55283_55284 : H12AffineEnvironment.transform 16 82246 env55283 = env55284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env55283 == env55284) = true)

def env55285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10400,1025,32769,4161,120062,73755,41430,8328,64,64724,79131,91403,35325,1500,168,257,21792,46212,74251]

theorem envBound55285 : H12AffineFastState.Bounded env55285 := by
  intro p hp
  have h : env55285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55284_55285 : H12AffineEnvironment.transform 17 10400 env55284 = env55285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env55284 == env55285) = true)

theorem identity55285 : scanCanonicalize (H12AffineFastState.compose env55285 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21756) := by decide +kernel

theorem selectedBound55285 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env55286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21756,65536,82246,10400,1025,21757,4161,65538,73755,29994,8328,64,10280,79131,91403,23809,1500,168,257,21792,24696,74251]

theorem envBound55286 : H12AffineFastState.Bounded env55286 := by
  intro p hp
  have h : env55286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55285_55286 : H12AffineEnvironment.transform 14 21756 env55285 = env55286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21756 env55285 == env55286) = true)

theorem identity55286 : scanCanonicalize (H12AffineFastState.compose env55286 (packedSelected [0,1,4,5,7,10,12,15,17,18,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55286 : packedSelected [0,1,4,5,7,10,12,15,17,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env55287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21756,263,16449,10400,1025,21757,4161,261,8476,29994,8328,64,10280,13340,25612,23809,1500,168,257,21792,24696,8972]

theorem envBound55287 : H12AffineFastState.Bounded env55287 := by
  intro p hp
  have h : env55287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55286_55287 : H12AffineEnvironment.transform 15 263 env55286 = env55287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55286 == env55287) = true)

theorem identity55287 : scanCanonicalize (H12AffineFastState.compose env55287 (packedSelected [0,2,3,6,7,10,11,17,18,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55287 : packedSelected [0,2,3,6,7,10,11,17,18,20,24,26] rootPS < 2^1333 := by decide +kernel

def env55288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21756,263,16449,2477,1025,21757,4161,261,17,21543,389,64,2341,5393,17665,23809,1500,168,257,21792,16757,513]

theorem envBound55288 : H12AffineFastState.Bounded env55288 := by
  intro p hp
  have h : env55288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55287_55288 : H12AffineEnvironment.transform 12 269 env55287 = env55288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55287 == env55288) = true)

theorem identity55288 : scanCanonicalize (H12AffineFastState.compose env55288 (packedSelected [4,9,10,11,15,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound55288 : packedSelected [4,9,10,11,15,17,19] rootPS < 2^1333 := by decide +kernel

def env55289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3244,269,16384,18512,263,16449,2477,1025,18513,3309,261,17,18571,389,64,2341,2493,17665,16813,1500,168,257,18828,16757,513]

theorem envBound55289 : H12AffineFastState.Bounded env55289 := by
  intro p hp
  have h : env55289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55288_55289 : H12AffineEnvironment.transform 11 3244 env55288 = env55289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env55288 == env55289) = true)

theorem identity55289 : scanCanonicalize (H12AffineFastState.compose env55289 (packedSelected [0,1,4,7,8,9,10,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound55289 : packedSelected [0,1,4,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env55290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1296,444,269,16384,17728,263,16449,1213,1025,17729,509,261,17,17819,389,64,1077,1197,17665,16813,1500,168,257,17564,16757,513]

theorem envBound55290 : H12AffineFastState.Bounded env55290 := by
  intro p hp
  have h : env55290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55289_55290 : H12AffineEnvironment.transform 10 1296 env55289 = env55290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env55289 == env55290) = true)

theorem identity55290 : scanCanonicalize (H12AffineFastState.compose env55290 (packedSelected [0,2,4,6,7,9,12,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound55290 : packedSelected [0,2,4,6,7,9,12,14,17] rootPS < 2^1333 := by decide +kernel

def env55291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1296,444,269,1297,81,263,1360,1213,1025,80,509,261,17,138,389,64,1077,1197,16,1212,1500,168,257,397,1124,513]

theorem envBound55291 : H12AffineFastState.Bounded env55291 := by
  intro p hp
  have h : env55291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55290_55291 : H12AffineEnvironment.transform 13 1297 env55290 = env55291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env55290 == env55291) = true)

theorem identity55291 : scanCanonicalize (H12AffineFastState.compose env55291 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound55291 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55292 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1213,17,160,1212,81,170,1277,1213,1025,80,80,168,17,138,40,64,1077,1197,16,1212,1137,168,172,32,1124,513]

theorem envBound55292 : H12AffineFastState.Bounded env55292 := by
  intro p hp
  have h : env55292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55291_55292 : H12AffineEnvironment.transform 7 173 env55291 = env55292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env55291 == env55292) = true)

theorem identity55292 : scanCanonicalize (H12AffineFastState.compose env55292 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound55292 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55293 : List Nat := [2,4,8,16,32,64,88,117,512,1024,1125,17,120,1124,81,114,1061,1125,1025,80,80,112,17,82,40,64,1077,1141,16,1124,1137,112,116,32,1124,513]

theorem envBound55293 : H12AffineFastState.Bounded env55293 := by
  intro p hp
  have h : env55293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55292_55293 : H12AffineEnvironment.transform 6 88 env55292 = env55293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env55292 == env55293) = true)

theorem identity55293 : scanCanonicalize (H12AffineFastState.compose env55293 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55293 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55294 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1076,17,41,1077,0,35,1061,1076,1025,1,1,33,17,3,40,17,1077,1060,16,1077,1056,33,37,32,1077,513]

theorem envBound55294 : H12AffineFastState.Bounded env55294 := by
  intro p hp
  have h : env55294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55293_55294 : H12AffineEnvironment.transform 5 17 env55293 = env55294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55293 == env55294) = true)

def env55295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10401,1025,32769,4161,120063,73755,41430,8328,64,64724,79131,91403,35324,1500,169,257,21792,46212,74251]

theorem envBound55295 : H12AffineFastState.Bounded env55295 := by
  intro p hp
  have h : env55295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55284_55295 : H12AffineEnvironment.transform 17 10401 env55284 = env55295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55284 == env55295) = true)

theorem identity55295 : scanCanonicalize (H12AffineFastState.compose env55295 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55295 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env55296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,82246,2557,1025,32769,4161,120063,65863,32906,468,64,56712,70727,83031,35324,1500,169,257,21792,38360,66391]

theorem envBound55296 : H12AffineFastState.Bounded env55296 := by
  intro p hp
  have h : env55296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55295_55296 : H12AffineEnvironment.transform 12 348 env55295 = env55296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55295 == env55296) = true)

theorem identity55296 : scanCanonicalize (H12AffineFastState.compose env55296 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55296 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env55297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,342,16400,2557,1025,32769,4161,54697,17,32906,468,64,56712,5393,17665,35324,1500,169,257,21792,38360,513]

theorem envBound55297 : H12AffineFastState.Bounded env55297 := by
  intro p hp
  have h : env55297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55296_55297 : H12AffineEnvironment.transform 15 342 env55296 = env55297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55296 == env55297) = true)

theorem identity55297 : scanCanonicalize (H12AffineFastState.compose env55297 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound55297 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,32768,342,5528,2557,1025,32769,4161,32801,17,32906,468,64,34816,5393,4233,35324,1500,169,257,168,38360,513]

theorem envBound55298 : H12AffineFastState.Bounded env55298 := by
  intro p hp
  have h : env55298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55297_55298 : H12AffineEnvironment.transform 13 5512 env55297 = env55298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env55297 == env55298) = true)

theorem identity55298 : scanCanonicalize (H12AffineFastState.compose env55298 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound55298 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,136,342,5528,2557,1025,137,4161,169,17,2,468,64,2184,5393,4233,2420,1500,169,257,168,5456,513]

theorem envBound55299 : H12AffineFastState.Bounded env55299 := by
  intro p hp
  have h : env55299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55298_55299 : H12AffineEnvironment.transform 14 136 env55298 = env55299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env55298 == env55299) = true)

theorem identity55299 : scanCanonicalize (H12AffineFastState.compose env55299 (packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound55299 : packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env55300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,292,4096,348,5512,136,342,5528,217,1025,137,4161,169,17,2,468,64,428,5393,4233,80,1500,169,257,168,5456,513]

theorem envBound55300 : H12AffineFastState.Bounded env55300 := by
  intro p hp
  have h : env55300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55299_55300 : H12AffineEnvironment.transform 10 292 env55299 = env55300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env55299 == env55300) = true)

theorem identity55300 : scanCanonicalize (H12AffineFastState.compose env55300 (packedSelected [0,3,4,7,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound55300 : packedSelected [0,3,4,7,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env55301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,292,201,348,1345,136,342,1361,217,1025,137,136,169,17,2,468,64,428,1496,64,80,1500,169,257,168,1433,513]

theorem envBound55301 : H12AffineFastState.Bounded env55301 := by
  intro p hp
  have h : env55301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55300_55301 : H12AffineEnvironment.transform 11 201 env55300 = env55301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env55300 == env55301) = true)

theorem identity55301 : scanCanonicalize (H12AffineFastState.compose env55301 (packedSelected [4,9,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound55301 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env55302 : List Nat := [2,4,8,16,32,64,89,256,512,1024,292,16,348,1345,81,342,1361,0,1025,80,81,112,17,2,269,64,373,1281,64,80,1285,112,257,113,1344,513]

theorem envBound55302 : H12AffineFastState.Bounded env55302 := by
  intro p hp
  have h : env55302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55301_55302 : H12AffineEnvironment.transform 6 89 env55301 = env55302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env55301 == env55302) = true)

theorem identity55302 : scanCanonicalize (H12AffineFastState.compose env55302 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55302 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55303 : List Nat := [2,4,8,16,32,64,89,256,512,273,292,16,348,80,81,342,64,0,272,80,81,112,17,2,269,64,373,16,64,80,20,112,257,113,81,513]

theorem envBound55303 : H12AffineFastState.Bounded env55303 := by
  intro p hp
  have h : env55303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55302_55303 : H12AffineEnvironment.transform 9 273 env55302 = env55303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55302 == env55303) = true)

theorem identity55303 : scanCanonicalize (H12AffineFastState.compose env55303 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55303 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env55304 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,16,268,0,1,262,16,0,272,0,1,32,17,2,269,16,293,16,16,0,20,32,257,33,1,513]

theorem envBound55304 : H12AffineFastState.Bounded env55304 := by
  intro p hp
  have h : env55304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55303_55304 : H12AffineEnvironment.transform 5 16 env55303 = env55304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55303 == env55304) = true)

theorem identity55304 : scanCanonicalize (H12AffineFastState.compose env55304 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55304 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55305 : List Nat := [2,4,8,16,32,16,9,37,512,52,1,16,41,0,1,35,16,0,53,0,1,32,17,2,40,16,0,16,16,0,20,32,36,33,1,513]

theorem envBound55305 : H12AffineFastState.Bounded env55305 := by
  intro p hp
  have h : env55305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55304_55305 : H12AffineEnvironment.transform 7 37 env55304 = env55305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55304 == env55305) = true)

theorem identity55305 : scanCanonicalize (H12AffineFastState.compose env55305 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound55305 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55306 : List Nat := [2,4,8,16,32,16,9,37,33,52,1,16,41,0,1,35,16,0,53,0,1,32,17,2,40,16,0,16,16,0,20,32,36,33,1,32]

theorem envBound55306 : H12AffineFastState.Bounded env55306 := by
  intro p hp
  have h : env55306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55305_55306 : H12AffineEnvironment.transform 8 33 env55305 = env55306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env55305 == env55306) = true)

def env55307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257180,254096,8328,64,2157716,2253852,140365,2404636,2102685,2373704,257,21792,46212,2175562]

theorem envBound55307 : H12AffineFastState.Bounded env55307 := by
  intro p hp
  have h : env55307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55262_55307 : H12AffineEnvironment.transform 21 441625 env55262 = env55307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env55262 == env55307) = true)

def env55308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,254096,8328,64,64724,160860,140365,303452,1501,272392,257,21792,46212,74250]

theorem envBound55308 : H12AffineFastState.Bounded env55308 := by
  intro p hp
  have h : env55308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55307_55308 : H12AffineEnvironment.transform 20 4160 env55307 = env55308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55307 == env55308) = true)

theorem identity55308 : scanCanonicalize (H12AffineFastState.compose env55308 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound55308 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,4160,329867,120014,21762,8328,64,64724,115150,102879,303452,1501,272392,257,21792,46212,74250]

theorem envBound55309 : H12AffineFastState.Bounded env55309 := by
  intro p hp
  have h : env55309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55308_55309 : H12AffineEnvironment.transform 16 112018 env55308 = env55309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env55308 == env55309) = true)

def env55310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,10400,1025,32769,4160,73771,120014,21762,8328,64,64724,115150,102879,35324,1501,168,257,21792,46212,74250]

theorem envBound55310 : H12AffineFastState.Bounded env55310 := by
  intro p hp
  have h : env55310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55309_55310 : H12AffineEnvironment.transform 17 10400 env55309 = env55310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env55309 == env55310) = true)

theorem identity55310 : scanCanonicalize (H12AffineFastState.compose env55310 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55310 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4160,73771,119878,21762,8192,64,64604,115014,102743,35188,1365,32,257,21792,46092,74250]

theorem envBound55311 : H12AffineFastState.Bounded env55311 := by
  intro p hp
  have h : env55311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55310_55311 : H12AffineEnvironment.transform 6 8 env55310 = env55311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55310 == env55311) = true)

theorem identity55311 : scanCanonicalize (H12AffineFastState.compose env55311 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound55311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24908,10280,1025,32769,4160,62589,16,21762,8192,64,64604,5392,17665,35188,1365,32,257,21792,46092,63068]

theorem envBound55312 : H12AffineFastState.Bounded env55312 := by
  intro p hp
  have h : env55312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55311_55312 : H12AffineEnvironment.transform 15 54358 env55311 = env55312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env55311 == env55312) = true)

theorem identity55312 : scanCanonicalize (H12AffineFastState.compose env55312 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound55312 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,42266,4096,10280,1025,32769,4160,34097,16,9294,8192,64,36112,5392,13389,35188,1365,32,257,9324,46092,34576]

theorem envBound55313 : H12AffineFastState.Bounded env55313 := by
  intro p hp
  have h : env55313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55312_55313 : H12AffineEnvironment.transform 13 12620 env55312 = env55313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env55312 == env55313) = true)

theorem identity55313 : scanCanonicalize (H12AffineFastState.compose env55313 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55313 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,32768,33863,4096,2421,1025,32769,4160,34097,16,1299,349,64,36112,5392,5392,35188,1365,32,257,1329,38225,34576]

theorem envBound55314 : H12AffineFastState.Bounded env55314 := by
  intro p hp
  have h : env55314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55313_55314 : H12AffineEnvironment.transform 12 349 env55313 = env55314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55313 == env55314) = true)

theorem identity55314 : scanCanonicalize (H12AffineFastState.compose env55314 (packedSelected [1,8,11,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound55314 : packedSelected [1,8,11,18,19] rootPS < 2^1333 := by decide +kernel

def env55315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1076,115,4096,2421,1025,1077,4160,261,16,1299,349,64,2340,5392,5392,3392,1365,32,257,1329,4453,804]

theorem envBound55315 : H12AffineFastState.Bounded env55315 := by
  intro p hp
  have h : env55315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55314_55315 : H12AffineEnvironment.transform 14 1076 env55314 = env55315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env55314 == env55315) = true)

theorem identity55315 : scanCanonicalize (H12AffineFastState.compose env55315 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55315 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55316 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4113,293,115,4096,2421,272,292,4160,261,16,2,349,64,2340,4097,4097,2129,68,32,257,32,4453,804]

theorem envBound55316 : H12AffineFastState.Bounded env55316 := by
  intro p hp
  have h : env55316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55315_55316 : H12AffineEnvironment.transform 9 273 env55315 = env55316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55315 == env55316) = true)

theorem identity55316 : scanCanonicalize (H12AffineFastState.compose env55316 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55316 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env55317 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,4096,349,4113,293,115,4096,373,272,292,4160,261,16,2,349,64,292,4097,4097,81,68,32,257,32,4453,804]

theorem envBound55317 : H12AffineFastState.Bounded env55317 := by
  intro p hp
  have h : env55317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55316_55317 : H12AffineEnvironment.transform 10 0 env55316 = env55317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55316 == env55317) = true)

theorem identity55317 : scanCanonicalize (H12AffineFastState.compose env55317 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound55317 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55318 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,65,349,80,293,115,65,373,272,292,1,261,16,2,349,64,292,64,64,81,68,32,257,32,292,804]

theorem envBound55318 : H12AffineFastState.Bounded env55318 := by
  intro p hp
  have h : env55318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55317_55318 : H12AffineEnvironment.transform 11 65 env55317 = env55318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env55317 == env55318) = true)

theorem identity55318 : scanCanonicalize (H12AffineFastState.compose env55318 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55318 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env55319 : List Nat := [2,4,8,16,32,64,8,117,512,100,0,65,40,80,80,115,65,0,101,81,1,112,16,2,40,64,81,64,64,81,68,32,116,32,81,593]

theorem envBound55319 : H12AffineFastState.Bounded env55319 := by
  intro p hp
  have h : env55319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55318_55319 : H12AffineEnvironment.transform 7 117 env55318 = env55319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55318 == env55319) = true)

theorem identity55319 : scanCanonicalize (H12AffineFastState.compose env55319 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound55319 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env55320 : List Nat := [2,4,8,16,32,64,8,117,81,100,0,65,40,80,80,115,65,0,101,81,1,112,16,2,40,64,81,64,64,81,68,32,116,32,81,0]

theorem envBound55320 : H12AffineFastState.Bounded env55320 := by
  intro p hp
  have h : env55320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55319_55320 : H12AffineEnvironment.transform 8 81 env55319 = env55320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env55319 == env55320) = true)

theorem identity55320 : scanCanonicalize (H12AffineFastState.compose env55320 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55320 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env55321 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,16,40,1,1,34,16,0,52,0,1,33,16,2,40,17,0,17,17,0,21,32,37,32,0,0]

theorem envBound55321 : H12AffineFastState.Bounded env55321 := by
  intro p hp
  have h : env55321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55320_55321 : H12AffineEnvironment.transform 5 17 env55320 = env55321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55320 == env55321) = true)

theorem identity55321 : scanCanonicalize (H12AffineFastState.compose env55321 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound55321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55322 : List Nat := [2,4,8,16,31,17,8,27,0,10,0,16,23,1,1,29,16,0,11,0,1,30,16,2,23,17,0,17,17,0,21,31,26,31,0,0]

theorem envBound55322 : H12AffineFastState.Bounded env55322 := by
  intro p hp
  have h : env55322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55321_55322 : H12AffineEnvironment.transform 4 31 env55321 = env55322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env55321 == env55322) = true)

theorem identity55322 : scanCanonicalize (H12AffineFastState.compose env55322 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55323 : List Nat := [2,4,6,16,17,17,6,21,0,4,0,16,23,1,1,19,16,0,5,0,1,16,16,2,23,17,0,17,17,0,21,17,20,17,0,0]

theorem envBound55323 : H12AffineFastState.Bounded env55323 := by
  intro p hp
  have h : env55323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55322_55323 : H12AffineEnvironment.transform 2 6 env55322 = env55323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55322 == env55323) = true)

theorem identity55323 : scanCanonicalize (H12AffineFastState.compose env55323 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55323 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55324 : List Nat := [2,4,6,1,0,0,6,4,0,4,0,1,6,1,1,2,1,0,5,0,1,1,1,2,6,0,0,0,0,0,4,0,5,0,0,0]

theorem envBound55324 : H12AffineFastState.Bounded env55324 := by
  intro p hp
  have h : env55324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55323_55324 : H12AffineEnvironment.transform 3 1 env55323 = env55324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55323 == env55324) = true)

def env55325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,10401,1025,32769,4160,73770,120014,21762,8328,64,64724,115150,102879,35325,1501,169,257,21792,46212,74250]

theorem envBound55325 : H12AffineFastState.Bounded env55325 := by
  intro p hp
  have h : env55325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55309_55325 : H12AffineEnvironment.transform 17 10401 env55309 = env55325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55309 == env55325) = true)

theorem identity55325 : scanCanonicalize (H12AffineFastState.compose env55325 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound55325 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,16536,10401,1025,32769,4160,54560,8644,21762,8328,64,64724,13508,25813,35325,1501,169,257,21792,46212,55040]

theorem envBound55326 : H12AffineFastState.Bounded env55326 := by
  intro p hp
  have h : env55326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55325_55326 : H12AffineEnvironment.transform 15 62730 env55325 = env55326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env55325 == env55326) = true)

theorem identity55326 : scanCanonicalize (H12AffineFastState.compose env55326 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound55326 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16536,10401,1025,21760,4160,33,8644,21762,8328,64,10709,13508,25813,23804,1501,169,257,21792,24965,513]

theorem envBound55327 : H12AffineFastState.Bounded env55327 := by
  intro p hp
  have h : env55327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55326_55327 : H12AffineEnvironment.transform 14 21761 env55326 = env55327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env55326 == env55327) = true)

theorem identity55327 : scanCanonicalize (H12AffineFastState.compose env55327 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound55327 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env55328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,80,8203,5577,10401,1025,81,4160,33,8644,83,8328,64,10709,13508,12676,2477,1501,169,257,113,13524,513]

theorem envBound55328 : H12AffineFastState.Bounded env55328 := by
  intro p hp
  have h : env55328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55327_55328 : H12AffineEnvironment.transform 13 5457 env55327 = env55328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env55327 == env55328) = true)

theorem identity55328 : scanCanonicalize (H12AffineFastState.compose env55328 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound55328 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env55329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5457,80,399,5577,2341,1025,81,4160,33,64,83,268,64,2129,5440,4096,2477,1501,169,257,113,5456,513]

theorem envBound55329 : H12AffineFastState.Bounded env55329 := by
  intro p hp
  have h : env55329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55328_55329 : H12AffineEnvironment.transform 12 388 env55328 = env55329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env55328 == env55329) = true)

theorem identity55329 : scanCanonicalize (H12AffineFastState.compose env55329 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55329 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,80,262,5440,2341,1025,81,4160,33,64,83,268,64,2129,5440,4096,2340,1364,32,257,113,5456,513]

theorem envBound55330 : H12AffineFastState.Bounded env55330 := by
  intro p hp
  have h : env55330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55329_55330 : H12AffineEnvironment.transform 6 9 env55329 = env55330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55329 == env55330) = true)

theorem identity55330 : scanCanonicalize (H12AffineFastState.compose env55330 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound55330 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,269,3173,80,262,3188,2341,1025,81,2420,33,64,83,268,64,2129,3188,2356,2340,1364,32,257,113,3172,513]

theorem envBound55331 : H12AffineFastState.Bounded env55331 := by
  intro p hp
  have h : env55331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55330_55331 : H12AffineEnvironment.transform 11 2356 env55330 = env55331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env55330 == env55331) = true)

theorem identity55331 : scanCanonicalize (H12AffineFastState.compose env55331 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55331 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env55332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,269,3125,0,262,3108,2341,1025,1,2340,33,16,3,268,16,2049,3108,2356,2340,1284,32,257,33,3124,513]

theorem envBound55332 : H12AffineFastState.Bounded env55332 := by
  intro p hp
  have h : env55332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55331_55332 : H12AffineEnvironment.transform 5 16 env55331 = env55332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55331 == env55332) = true)

theorem identity55332 : scanCanonicalize (H12AffineFastState.compose env55332 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55333 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2356,269,2341,0,262,2356,2341,273,1,2340,33,16,3,268,16,2049,2356,2356,2340,20,32,257,33,2340,513]

theorem envBound55333 : H12AffineFastState.Bounded env55333 := by
  intro p hp
  have h : env55333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55332_55333 : H12AffineEnvironment.transform 9 272 env55332 = env55333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55332 == env55333) = true)

def env55334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,254096,8328,64,64725,160861,140365,303453,1500,272393,257,21792,46212,74251]

theorem envBound55334 : H12AffineFastState.Bounded env55334 := by
  intro p hp
  have h : env55334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55307_55334 : H12AffineEnvironment.transform 20 4161 env55307 = env55334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55307 == env55334) = true)

theorem identity55334 : scanCanonicalize (H12AffineFastState.compose env55334 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55334 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,441625,155997,180378,8328,64,64725,160861,140365,303453,1500,272393,257,21792,46212,513]

theorem envBound55335 : H12AffineFastState.Bounded env55335 := by
  intro p hp
  have h : env55335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55334_55335 : H12AffineEnvironment.transform 15 8202 env55334 = env55335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55334 == env55335) = true)

def env55336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,326921,8525,32906,8328,64,64725,13389,25693,303453,1500,272393,257,21792,46212,513]

theorem envBound55336 : H12AffineFastState.Bounded env55336 := by
  intro p hp
  have h : env55336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55335_55336 : H12AffineEnvironment.transform 16 16400 env55335 = env55336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55335 == env55336) = true)

def env55337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,326921,8525,32770,8192,64,64605,13389,25693,303453,1364,272393,257,21792,46092,513]

theorem envBound55337 : H12AffineFastState.Bounded env55337 := by
  intro p hp
  have h : env55337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55336_55337 : H12AffineEnvironment.transform 6 8 env55336 = env55337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55336 == env55337) = true)

def env55338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,326921,8525,32771,8193,64,64604,13389,25693,303453,1365,272393,257,21792,46093,513]

theorem envBound55338 : H12AffineFastState.Bounded env55338 := by
  intro p hp
  have h : env55338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55336_55338 : H12AffineEnvironment.transform 6 9 env55336 = env55338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55336 == env55338) = true)

theorem identity55338 : scanCanonicalize (H12AffineFastState.compose env55338 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound55338 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,32768,8202,12637,262144,1025,32769,4161,298052,8525,32771,8193,64,36113,13389,5392,303453,1365,272393,257,9325,46093,513]

theorem envBound55339 : H12AffineFastState.Bounded env55339 := by
  intro p hp
  have h : env55339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55338_55339 : H12AffineEnvironment.transform 13 12621 env55338 = env55339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env55338 == env55339) = true)

theorem identity55339 : scanCanonicalize (H12AffineFastState.compose env55339 (packedSelected [12,15,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound55339 : packedSelected [12,15,38,41] rootPS < 2^1333 := by decide +kernel

def env55340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,32768,8202,12637,3173,1025,32769,4161,32801,8525,32771,8193,64,36113,13389,5392,44344,1365,9324,257,9325,46093,513]

theorem envBound55340 : H12AffineFastState.Bounded env55340 := by
  intro p hp
  have h : env55340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55339_55340 : H12AffineEnvironment.transform 17 3173 env55339 = env55340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env55339 == env55340) = true)

def env55341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,326920,8524,32907,8328,64,64725,13388,25692,303453,1500,272393,257,21792,46212,513]

theorem envBound55341 : H12AffineFastState.Bounded env55341 := by
  intro p hp
  have h : env55341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55335_55341 : H12AffineEnvironment.transform 16 16401 env55335 = env55341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55335 == env55341) = true)

theorem identity55341 : scanCanonicalize (H12AffineFastState.compose env55341 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55341 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16401,262144,1025,32769,4161,318549,17,32907,469,64,56712,5393,17665,294912,1500,264532,257,21792,38361,513]

theorem envBound55342 : H12AffineFastState.Bounded env55342 := by
  intro p hp
  have h : env55342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55341_55342 : H12AffineEnvironment.transform 12 349 env55341 = env55342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55341 == env55342) = true)

theorem identity55342 : scanCanonicalize (H12AffineFastState.compose env55342 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound55342 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16401,56573,1025,32769,4161,168,17,32907,469,64,56712,5393,17665,23805,1500,54697,257,21792,38361,513]

theorem envBound55343 : H12AffineFastState.Bounded env55343 := by
  intro p hp
  have h : env55343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55342_55343 : H12AffineEnvironment.transform 17 56573 env55342 = env55343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env55342 == env55343) = true)

theorem identity55343 : scanCanonicalize (H12AffineFastState.compose env55343 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55343 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env55344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,16401,56437,1025,32769,4161,32,17,32771,349,64,56576,5393,17665,23669,1364,54561,257,21792,38225,513]

theorem envBound55344 : H12AffineFastState.Bounded env55344 := by
  intro p hp
  have h : env55344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55343_55344 : H12AffineEnvironment.transform 6 8 env55343 = env55344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55343 == env55344) = true)

theorem identity55344 : scanCanonicalize (H12AffineFastState.compose env55344 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound55344 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16401,2420,1025,21760,4161,32,17,21762,349,64,2049,5393,17665,23669,1364,32,257,21792,16464,513]

theorem envBound55345 : H12AffineFastState.Bounded env55345 := by
  intro p hp
  have h : env55345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55344_55345 : H12AffineEnvironment.transform 14 21761 env55344 = env55345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env55344 == env55345) = true)

theorem identity55345 : scanCanonicalize (H12AffineFastState.compose env55345 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound55345 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,80,343,5440,2420,1025,81,4161,32,17,83,349,64,2049,5393,4176,2340,1364,32,257,113,5377,513]

theorem envBound55346 : H12AffineFastState.Bounded env55346 := by
  intro p hp
  have h : env55346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55345_55346 : H12AffineEnvironment.transform 13 5457 env55345 = env55346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env55345 == env55346) = true)

theorem identity55346 : scanCanonicalize (H12AffineFastState.compose env55346 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1339) := by decide +kernel

theorem selectedBound55346 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env55347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1339,349,106,80,343,123,2420,1025,81,1402,32,17,83,349,64,2049,42,1387,2340,1364,32,257,113,58,513]

theorem envBound55347 : H12AffineFastState.Bounded env55347 := by
  intro p hp
  have h : env55347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55346_55347 : H12AffineEnvironment.transform 11 1339 env55346 = env55347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1339 env55346 == env55347) = true)

theorem identity55347 : scanCanonicalize (H12AffineFastState.compose env55347 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound55347 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env55348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,270,1339,349,106,80,343,123,122,1025,81,1402,32,17,83,349,64,271,42,1387,42,1364,32,257,113,58,513]

theorem envBound55348 : H12AffineFastState.Bounded env55348 := by
  intro p hp
  have h : env55348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55347_55348 : H12AffineEnvironment.transform 10 270 env55347 = env55348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env55347 == env55348) = true)

theorem identity55348 : scanCanonicalize (H12AffineFastState.compose env55348 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound55348 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env55349 : List Nat := [2,4,8,16,32,64,8,256,512,116,270,335,349,106,80,343,123,122,117,81,270,32,17,83,349,64,271,42,287,42,288,32,257,113,58,513]

theorem envBound55349 : H12AffineFastState.Bounded env55349 := by
  intro p hp
  have h : env55349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55348_55349 : H12AffineEnvironment.transform 9 116 env55348 = env55349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env55348 == env55349) = true)

theorem identity55349 : scanCanonicalize (H12AffineFastState.compose env55349 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound55349 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55350 : List Nat := [2,4,8,16,32,64,8,110,512,116,96,33,51,106,80,57,123,122,117,81,96,32,17,83,51,64,97,42,113,42,78,32,111,113,58,513]

theorem envBound55350 : H12AffineFastState.Bounded env55350 := by
  intro p hp
  have h : env55350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55349_55350 : H12AffineEnvironment.transform 7 110 env55349 = env55350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env55349 == env55350) = true)

theorem identity55350 : scanCanonicalize (H12AffineFastState.compose env55350 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55350 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env55351 : List Nat := [2,4,8,16,32,17,8,63,512,37,49,33,51,59,1,57,42,43,36,0,49,32,17,2,51,17,48,42,32,42,31,32,62,32,58,513]

theorem envBound55351 : H12AffineFastState.Bounded env55351 := by
  intro p hp
  have h : env55351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55350_55351 : H12AffineEnvironment.transform 5 17 env55350 = env55351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55350 == env55351) = true)

theorem identity55351 : scanCanonicalize (H12AffineFastState.compose env55351 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55351 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55352 : List Nat := [2,4,8,11,32,10,8,36,512,37,42,33,40,32,1,34,42,43,36,0,42,32,10,2,40,10,43,42,32,42,4,32,37,32,33,513]

theorem envBound55352 : H12AffineFastState.Bounded env55352 := by
  intro p hp
  have h : env55352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55351_55352 : H12AffineEnvironment.transform 3 11 env55351 = env55352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55351 == env55352) = true)

theorem identity55352 : scanCanonicalize (H12AffineFastState.compose env55352 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound55352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55353 : List Nat := [2,4,8,11,4,10,8,0,512,1,14,5,12,4,1,6,14,15,0,0,14,4,10,2,12,10,15,14,4,14,4,4,1,4,5,513]

theorem envBound55353 : H12AffineFastState.Bounded env55353 := by
  intro p hp
  have h : env55353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55352_55353 : H12AffineEnvironment.transform 4 4 env55352 = env55353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env55352 == env55353) = true)

theorem identity55353 : scanCanonicalize (H12AffineFastState.compose env55353 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55353 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55354 : List Nat := [2,1,8,11,1,10,8,0,512,1,11,0,9,1,1,3,11,10,0,0,11,1,10,2,9,10,10,11,1,11,1,1,1,1,0,513]

theorem envBound55354 : H12AffineFastState.Bounded env55354 := by
  intro p hp
  have h : env55354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55353_55354 : H12AffineEnvironment.transform 1 1 env55353 = env55354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55353 == env55354) = true)

def env55355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257181,254096,8328,64,6705548,2253852,140364,2404637,2102684,6456657,257,21793,46213,2175563]

theorem envBound55355 : H12AffineFastState.Bounded env55355 := by
  intro p hp
  have h : env55355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55261_55355 : H12AffineEnvironment.transform 22 2257181 env55261 = env55355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257181 env55261 == env55355) = true)

def env55356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257181,254096,8328,64,2157716,2253852,140364,2404637,2102684,2373705,257,21793,46213,2175563]

theorem envBound55356 : H12AffineFastState.Bounded env55356 := by
  intro p hp
  have h : env55356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55355_55356 : H12AffineEnvironment.transform 21 441624 env55355 = env55356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env55355 == env55356) = true)

def env55357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,254096,8328,64,64724,160860,140364,303453,1500,272393,257,21793,46213,74251]

theorem envBound55357 : H12AffineFastState.Bounded env55357 := by
  intro p hp
  have h : env55357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55356_55357 : H12AffineEnvironment.transform 20 4160 env55356 = env55357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55356 == env55357) = true)

def env55358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169264,155997,254096,8328,64,64724,160860,140364,35189,1500,33,257,21793,46213,74251]

theorem envBound55358 : H12AffineFastState.Bounded env55358 := by
  intro p hp
  have h : env55358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55357_55358 : H12AffineEnvironment.transform 17 10280 env55357 = env55358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55357 == env55358) = true)

def env55359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21792,41293,73856,8328,64,64724,46156,58460,35189,1500,33,257,21793,46213,74251]

theorem envBound55359 : H12AffineFastState.Bounded env55359 := by
  intro p hp
  have h : env55359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55358_55359 : H12AffineEnvironment.transform 16 49168 env55358 = env55359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55358 == env55359) = true)

theorem identity55359 : scanCanonicalize (H12AffineFastState.compose env55359 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55359 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10280,1025,8540,4160,21792,16,73856,8328,64,23945,5393,17665,10280,1500,33,257,21793,5592,74251]

theorem envBound55360 : H12AffineFastState.Bounded env55360 := by
  intro p hp
  have h : env55360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55359_55360 : H12AffineEnvironment.transform 14 8541 env55359 = env55360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55359 == env55360) = true)

theorem identity55360 : scanCanonicalize (H12AffineFastState.compose env55360 (packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 9447) := by decide +kernel

theorem selectedBound55360 : packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env55361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,9447,24909,10280,1025,8540,4160,21792,16,1127,8328,64,23945,5393,17665,10280,1500,33,257,21793,5592,1772]

theorem envBound55361 : H12AffineFastState.Bounded env55361 := by
  intro p hp
  have h : env55361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55360_55361 : H12AffineEnvironment.transform 15 9447 env55360 = env55361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9447 env55360 == env55361) = true)

theorem identity55361 : scanCanonicalize (H12AffineFastState.compose env55361 (packedSelected [2,4,6,11,16,18,19,22,26] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55361 : packedSelected [2,4,6,11,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env55362 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,9447,24633,10280,1025,8232,4160,21588,16,1127,8328,64,23805,5221,17525,10280,1192,33,117,21589,5292,1772]

theorem envBound55362 : H12AffineFastState.Bounded env55362 := by
  intro p hp
  have h : env55362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55361_55362 : H12AffineEnvironment.transform 7 116 env55361 = env55362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55361 == env55362) = true)

theorem identity55362 : scanCanonicalize (H12AffineFastState.compose env55362 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound55362 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env55363 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,4112,8233,9447,12329,10280,1025,8232,4160,1092,16,1127,8328,64,3309,5221,5221,10280,1192,33,117,1093,5292,1772]

theorem envBound55363 : H12AffineFastState.Bounded env55363 := by
  intro p hp
  have h : env55363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55362_55363 : H12AffineEnvironment.transform 13 4112 env55362 = env55363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env55362 == env55363) = true)

theorem identity55363 : scanCanonicalize (H12AffineFastState.compose env55363 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55363 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env55364 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,4112,8233,9399,12329,10280,1025,8232,4112,1044,16,1079,8328,16,3261,5173,5173,10280,1192,33,37,1045,5292,1724]

theorem envBound55364 : H12AffineFastState.Bounded env55364 := by
  intro p hp
  have h : env55364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55363_55364 : H12AffineEnvironment.transform 5 16 env55363 = env55364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55363 == env55364) = true)

theorem identity55364 : scanCanonicalize (H12AffineFastState.compose env55364 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6321) := by decide +kernel

theorem selectedBound55364 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55365 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,6321,4112,6296,7174,2200,4249,1025,6297,4112,1044,16,1079,6201,16,3261,5173,5173,4249,1192,33,37,1045,5292,1724]

theorem envBound55365 : H12AffineFastState.Bounded env55365 := by
  intro p hp
  have h : env55365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55364_55365 : H12AffineEnvironment.transform 12 6321 env55364 = env55365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6321 env55364 == env55365) = true)

theorem identity55365 : scanCanonicalize (H12AffineFastState.compose env55365 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound55365 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55366 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,1196,3101,1212,3124,2218,2200,1077,1025,3125,1212,1044,16,1079,3221,16,3261,153,153,1077,1192,33,37,1045,0,1724]

theorem envBound55366 : H12AffineFastState.Bounded env55366 := by
  intro p hp
  have h : env55366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55365_55366 : H12AffineEnvironment.transform 11 1196 env55365 = env55366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env55365 == env55366) = true)

theorem identity55366 : scanCanonicalize (H12AffineFastState.compose env55366 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55366 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env55367 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,1060,3101,1076,3124,2082,2064,1077,1025,3125,1076,1044,16,1079,3101,16,3125,17,17,1077,1056,33,37,1045,0,1588]

theorem envBound55367 : H12AffineFastState.Bounded env55367 := by
  intro p hp
  have h : env55367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55366_55367 : H12AffineEnvironment.transform 6 8 env55366 = env55367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55366 == env55367) = true)

theorem identity55367 : scanCanonicalize (H12AffineFastState.compose env55367 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55367 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env55368 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,16,2089,0,2048,2082,2064,1,53,2049,0,32,16,3,2089,16,2049,17,17,1,20,33,37,33,0,512]

theorem envBound55368 : H12AffineFastState.Bounded env55368 := by
  intro p hp
  have h : env55368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55367_55368 : H12AffineEnvironment.transform 9 52 env55367 = env55368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55367 == env55368) = true)

theorem identity55368 : scanCanonicalize (H12AffineFastState.compose env55368 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55368 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55369 : List Nat := [2,4,8,16,32,16,8,36,512,52,32,16,9,0,32,2,48,1,53,33,0,32,16,3,9,16,33,17,17,1,20,33,37,33,0,512]

theorem envBound55369 : H12AffineFastState.Bounded env55369 := by
  intro p hp
  have h : env55369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55368_55369 : H12AffineEnvironment.transform 10 32 env55368 = env55369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55368 == env55369) = true)

theorem identity55369 : scanCanonicalize (H12AffineFastState.compose env55369 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55369 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55370 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,0,0,2,16,1,21,1,0,0,16,3,9,16,1,17,17,1,20,1,5,1,0,512]

theorem envBound55370 : H12AffineFastState.Bounded env55370 := by
  intro p hp
  have h : env55370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55369_55370 : H12AffineEnvironment.transform 4 0 env55369 = env55370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55369 == env55370) = true)

theorem identity55370 : scanCanonicalize (H12AffineFastState.compose env55370 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55371 : List Nat := [2,4,8,1,0,1,8,4,512,5,0,1,9,0,0,2,1,1,4,1,0,0,1,3,9,1,1,0,0,1,5,1,5,1,0,512]

theorem envBound55371 : H12AffineFastState.Bounded env55371 := by
  intro p hp
  have h : env55371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55370_55371 : H12AffineEnvironment.transform 3 1 env55370 = env55371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55370 == env55371) = true)

theorem identity55371 : scanCanonicalize (H12AffineFastState.compose env55371 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound55371 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55372 : List Nat := [2,4,8,1,0,1,8,4,15,5,0,1,9,0,0,2,1,1,4,1,0,0,1,3,9,1,1,0,0,1,5,1,5,1,0,15]

theorem envBound55372 : H12AffineFastState.Bounded env55372 := by
  intro p hp
  have h : env55372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55371_55372 : H12AffineEnvironment.transform 8 15 env55371 = env55372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env55371 == env55372) = true)

def env55373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21793,41292,73857,8328,64,64724,46157,58461,35189,1500,33,257,21793,46213,74251]

theorem envBound55373 : H12AffineFastState.Bounded env55373 := by
  intro p hp
  have h : env55373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55358_55373 : H12AffineEnvironment.transform 16 49169 env55358 = env55373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55358 == env55373) = true)

theorem identity55373 : scanCanonicalize (H12AffineFastState.compose env55373 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound55373 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1025,8661,4160,21793,152,73857,8328,64,23808,5529,17801,10401,1500,33,257,21793,5457,74251]

theorem envBound55374 : H12AffineFastState.Bounded env55374 := by
  intro p hp
  have h : env55374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55373_55374 : H12AffineEnvironment.transform 14 8660 env55373 = env55374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env55373 == env55374) = true)

theorem identity55374 : scanCanonicalize (H12AffineFastState.compose env55374 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound55374 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8660,65536,12756,10280,1025,8661,4160,1328,152,73857,8328,64,3345,5529,5528,10401,1500,33,257,1328,5457,74251]

theorem envBound55375 : H12AffineFastState.Bounded env55375 := by
  intro p hp
  have h : env55375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55374_55375 : H12AffineEnvironment.transform 13 4113 env55374 = env55375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env55374 == env55375) = true)

theorem identity55375 : scanCanonicalize (H12AffineFastState.compose env55375 (packedSelected [4,5,7,9,18,19,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound55375 : packedSelected [4,5,7,9,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env55376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8660,8283,12756,10280,1025,8661,4160,1328,152,218,8328,64,3345,5529,5528,10401,1500,33,257,1328,5457,592]

theorem envBound55376 : H12AffineFastState.Bounded env55376 := by
  intro p hp
  have h : env55376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55375_55376 : H12AffineEnvironment.transform 15 8283 env55375 = env55376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env55375 == env55376) = true)

theorem identity55376 : scanCanonicalize (H12AffineFastState.compose env55376 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound55376 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env55377 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4113,8233,8283,12329,10280,1025,8232,4160,1229,152,218,8328,64,3308,5220,5221,10401,1057,33,252,1229,5292,592]

theorem envBound55377 : H12AffineFastState.Bounded env55377 := by
  intro p hp
  have h : env55377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55376_55377 : H12AffineEnvironment.transform 7 253 env55376 = env55377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env55376 == env55377) = true)

theorem identity55377 : scanCanonicalize (H12AffineFastState.compose env55377 (packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55377 : packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS < 2^1333 := by decide +kernel

def env55378 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4113,8233,8283,12329,10280,1025,8232,4160,1093,16,82,8192,64,3172,5220,5221,10281,1057,33,116,1093,5156,592]

theorem envBound55378 : H12AffineFastState.Bounded env55378 := by
  intro p hp
  have h : env55378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55377_55378 : H12AffineEnvironment.transform 6 8 env55377 = env55378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55377 == env55378) = true)

theorem identity55378 : scanCanonicalize (H12AffineFastState.compose env55378 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55378 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env55379 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,41,4113,0,114,4096,2049,1025,1,4160,1093,16,82,41,64,3172,5220,5221,2048,1057,33,116,1093,5156,592]

theorem envBound55379 : H12AffineFastState.Bounded env55379 := by
  intro p hp
  have h : env55379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55378_55379 : H12AffineEnvironment.transform 12 41 env55378 = env55379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55378 == env55379) = true)

theorem identity55379 : scanCanonicalize (H12AffineFastState.compose env55379 (packedSelected [0,2,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 107) := by decide +kernel

theorem selectedBound55379 : packedSelected [0,2,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55380 : List Nat := [2,4,8,16,32,64,8,117,512,107,2048,4096,41,4113,0,114,4096,2049,106,1,4160,46,16,82,41,64,2063,4111,4110,2048,74,33,116,46,4175,592]

theorem envBound55380 : H12AffineFastState.Bounded env55380 := by
  intro p hp
  have h : env55380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55379_55380 : H12AffineEnvironment.transform 9 107 env55379 = env55380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 107 env55379 == env55380) = true)

def env55381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169265,155997,254096,8328,64,64724,160860,140364,35188,1500,32,257,21793,46213,74251]

theorem envBound55381 : H12AffineFastState.Bounded env55381 := by
  intro p hp
  have h : env55381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55357_55381 : H12AffineEnvironment.transform 17 10281 env55357 = env55381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55357 == env55381) = true)

def env55382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21793,41293,73856,8328,64,64724,46156,58460,35188,1500,32,257,21793,46213,74251]

theorem envBound55382 : H12AffineFastState.Bounded env55382 := by
  intro p hp
  have h : env55382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55381_55382 : H12AffineEnvironment.transform 16 49168 env55381 = env55382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55381 == env55382) = true)

theorem identity55382 : scanCanonicalize (H12AffineFastState.compose env55382 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound55382 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env55383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10281,1025,32769,4160,21793,41293,2,8328,64,64724,46156,58460,35188,1500,32,257,21793,46213,649]

theorem envBound55383 : H12AffineFastState.Bounded env55383 := by
  intro p hp
  have h : env55383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55382_55383 : H12AffineEnvironment.transform 15 8322 env55382 = env55383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env55382 == env55383) = true)

theorem identity55383 : scanCanonicalize (H12AffineFastState.compose env55383 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound55383 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env55384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8322,46156,10281,1025,32769,4160,8573,41293,2,8328,64,34952,46156,36864,35188,1500,32,257,8573,46213,649]

theorem envBound55384 : H12AffineFastState.Bounded env55384 := by
  intro p hp
  have h : env55384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55383_55384 : H12AffineEnvironment.transform 13 13404 env55383 = env55384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env55383 == env55384) = true)

theorem identity55384 : scanCanonicalize (H12AffineFastState.compose env55384 (packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55384 : packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env55385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5457,32768,399,38209,2340,1025,32769,4160,112,32832,2,389,64,34952,38209,36864,35188,1500,32,257,112,38280,649]

theorem envBound55385 : H12AffineFastState.Bounded env55385 := by
  intro p hp
  have h : env55385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55384_55385 : H12AffineEnvironment.transform 12 269 env55384 = env55385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55384 == env55385) = true)

theorem identity55385 : scanCanonicalize (H12AffineFastState.compose env55385 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound55385 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env55386 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5457,32768,343,38209,2340,1025,32769,4160,112,32832,2,349,64,34896,38209,36864,35188,1284,32,257,112,38224,593]

theorem envBound55386 : H12AffineFastState.Bounded env55386 := by
  intro p hp
  have h : env55386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55385_55386 : H12AffineEnvironment.transform 6 88 env55385 = env55386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env55385 == env55386) = true)

theorem identity55386 : scanCanonicalize (H12AffineFastState.compose env55386 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound55386 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55387 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5457,81,343,5392,2340,1025,80,4160,112,17,2,349,64,2049,5392,4177,2341,1284,32,257,112,5377,593]

theorem envBound55387 : H12AffineFastState.Bounded env55387 := by
  intro p hp
  have h : env55387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55386_55387 : H12AffineEnvironment.transform 14 81 env55386 = env55387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env55386 == env55387) = true)

theorem identity55387 : scanCanonicalize (H12AffineFastState.compose env55387 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound55387 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55388 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1,269,1360,81,343,1297,2340,1025,80,65,112,17,2,349,64,2049,1297,80,2341,1284,32,257,112,1280,593]

theorem envBound55388 : H12AffineFastState.Bounded env55388 := by
  intro p hp
  have h : env55388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55387_55388 : H12AffineEnvironment.transform 11 1 env55387 = env55388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env55387 == env55388) = true)

def env55389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21792,41292,73857,8328,64,64724,46157,58461,35188,1500,32,257,21793,46213,74251]

theorem envBound55389 : H12AffineFastState.Bounded env55389 := by
  intro p hp
  have h : env55389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55381_55389 : H12AffineEnvironment.transform 16 49169 env55381 = env55389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55381 == env55389) = true)

theorem identity55389 : scanCanonicalize (H12AffineFastState.compose env55389 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55389 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21792,41292,73737,8192,64,64604,46157,58461,35188,1364,32,257,21793,46093,74251]

theorem envBound55390 : H12AffineFastState.Bounded env55390 := by
  intro p hp
  have h : env55390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55389_55390 : H12AffineEnvironment.transform 6 8 env55389 = env55390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55389 == env55390) = true)

theorem identity55390 : scanCanonicalize (H12AffineFastState.compose env55390 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55390 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10281,1025,8541,4160,21792,16,73737,8192,64,23808,5393,17665,10280,1364,32,257,21793,5457,74251]

theorem envBound55391 : H12AffineFastState.Bounded env55391 := by
  intro p hp
  have h : env55391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55390_55391 : H12AffineEnvironment.transform 14 8540 env55390 = env55391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55390 == env55391) = true)

theorem identity55391 : scanCanonicalize (H12AffineFastState.compose env55391 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55391 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,24909,10281,1025,8541,4160,21792,16,8543,8192,64,23808,5393,17665,10280,1364,32,257,21793,5457,9053]

theorem envBound55392 : H12AffineFastState.Bounded env55392 := by
  intro p hp
  have h : env55392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55391_55392 : H12AffineEnvironment.transform 15 342 env55391 = env55392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55391 == env55392) = true)

theorem identity55392 : scanCanonicalize (H12AffineFastState.compose env55392 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound55392 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,342,5393,10281,1025,8541,4160,8572,16,8543,8192,64,10588,5393,12637,10280,1364,32,257,8573,5457,9053]

theorem envBound55393 : H12AffineFastState.Bounded env55393 := by
  intro p hp
  have h : env55393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55392_55393 : H12AffineEnvironment.transform 13 13404 env55392 = env55393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env55392 == env55393) = true)

theorem identity55393 : scanCanonicalize (H12AffineFastState.compose env55393 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55393 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5393,2421,1025,1,4160,32,16,3,348,64,2048,5393,4097,2420,1364,32,257,33,5457,513]

theorem envBound55394 : H12AffineFastState.Bounded env55394 := by
  intro p hp
  have h : env55394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55393_55394 : H12AffineEnvironment.transform 12 348 env55393 = env55394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55393 == env55394) = true)

theorem identity55394 : scanCanonicalize (H12AffineFastState.compose env55394 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2926) := by decide +kernel

theorem selectedBound55394 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2926,348,3694,0,342,3711,2421,1025,1,2862,32,16,3,348,64,2048,3711,2927,2420,1364,32,257,33,3647,513]

theorem envBound55395 : H12AffineFastState.Bounded env55395 := by
  intro p hp
  have h : env55395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55394_55395 : H12AffineEnvironment.transform 11 2926 env55394 = env55395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2926 env55394 == env55395) = true)

theorem identity55395 : scanCanonicalize (H12AffineFastState.compose env55395 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55395 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55396 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2878,268,3646,0,262,3631,2341,1025,1,2862,32,16,3,268,16,2048,3631,2879,2340,1284,32,257,33,3647,513]

theorem envBound55396 : H12AffineFastState.Bounded env55396 := by
  intro p hp
  have h : env55396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55395_55396 : H12AffineEnvironment.transform 5 16 env55395 = env55396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55395 == env55396) = true)

theorem identity55396 : scanCanonicalize (H12AffineFastState.compose env55396 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound55396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55397 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1819,1061,268,293,0,262,308,1598,1025,1,1077,32,16,3,268,16,1819,308,1060,1599,1284,32,257,33,292,513]

theorem envBound55397 : H12AffineFastState.Bounded env55397 := by
  intro p hp
  have h : env55397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55396_55397 : H12AffineEnvironment.transform 10 1819 env55396 = env55397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env55396 == env55397) = true)

theorem identity55397 : scanCanonicalize (H12AffineFastState.compose env55397 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound55397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55398 : List Nat := [2,4,8,16,32,16,8,256,512,542,261,571,268,293,0,262,308,32,543,1,555,32,16,3,268,16,261,308,570,33,794,32,257,33,292,513]

theorem envBound55398 : H12AffineFastState.Bounded env55398 := by
  intro p hp
  have h : env55398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55397_55398 : H12AffineEnvironment.transform 9 542 env55397 = env55398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env55397 == env55398) = true)

theorem identity55398 : scanCanonicalize (H12AffineFastState.compose env55398 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound55398 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55399 : List Nat := [2,4,8,16,32,16,8,256,270,272,261,309,268,293,0,262,308,32,273,1,293,32,16,3,268,16,261,308,308,33,20,32,257,33,292,271]

theorem envBound55399 : H12AffineFastState.Bounded env55399 := by
  intro p hp
  have h : env55399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55398_55399 : H12AffineEnvironment.transform 8 270 env55398 = env55399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env55398 == env55399) = true)

theorem identity55399 : scanCanonicalize (H12AffineFastState.compose env55399 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55399 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55400 : List Nat := [2,4,8,16,0,16,8,256,270,272,261,277,268,261,0,262,276,0,273,1,261,0,16,3,268,16,261,276,276,1,20,0,257,1,260,271]

theorem envBound55400 : H12AffineFastState.Bounded env55400 := by
  intro p hp
  have h : env55400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55399_55400 : H12AffineEnvironment.transform 4 0 env55399 = env55400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55399 == env55400) = true)

theorem identity55400 : scanCanonicalize (H12AffineFastState.compose env55400 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55400 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55401 : List Nat := [2,4,8,16,0,16,8,4,10,20,1,17,8,1,0,2,16,0,21,1,1,0,16,3,8,16,1,16,16,1,20,0,5,1,0,11]

theorem envBound55401 : H12AffineFastState.Bounded env55401 := by
  intro p hp
  have h : env55401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55400_55401 : H12AffineEnvironment.transform 7 4 env55400 = env55401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55400 == env55401) = true)

theorem identity55401 : scanCanonicalize (H12AffineFastState.compose env55401 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55401 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55402 : List Nat := [2,4,6,16,0,16,6,4,4,20,1,17,6,1,0,2,16,0,21,1,1,0,16,3,6,16,1,16,16,1,20,0,5,1,0,5]

theorem envBound55402 : H12AffineFastState.Bounded env55402 := by
  intro p hp
  have h : env55402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55401_55402 : H12AffineEnvironment.transform 2 6 env55401 = env55402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55401 == env55402) = true)

theorem identity55402 : scanCanonicalize (H12AffineFastState.compose env55402 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound55402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55403 : List Nat := [2,4,6,3,0,3,6,4,4,7,1,2,6,1,0,2,3,0,6,1,1,0,3,3,6,3,1,3,3,1,7,0,5,1,0,5]

theorem envBound55403 : H12AffineFastState.Bounded env55403 := by
  intro p hp
  have h : env55403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55402_55403 : H12AffineEnvironment.transform 3 3 env55402 = env55403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env55402 == env55403) = true)

def env55404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,254096,8328,64,64725,160861,140364,303452,1501,272392,257,21793,46213,74250]

theorem envBound55404 : H12AffineFastState.Bounded env55404 := by
  intro p hp
  have h : env55404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55356_55404 : H12AffineEnvironment.transform 20 4161 env55356 = env55404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55356 == env55404) = true)

theorem identity55404 : scanCanonicalize (H12AffineFastState.compose env55404 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound55404 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,272512,62660,95496,8328,64,64725,57797,45524,303452,1501,272392,257,21793,46213,74250]

theorem envBound55405 : H12AffineFastState.Bounded env55405 := by
  intro p hp
  have h : env55405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55404_55405 : H12AffineEnvironment.transform 16 38296 env55404 = env55405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env55404 == env55405) = true)

theorem identity55405 : scanCanonicalize (H12AffineFastState.compose env55405 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55405 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env55406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38296,262144,1025,32769,4161,272512,62660,21763,8328,64,64725,57797,45524,303452,1501,272392,257,21793,46213,513]

theorem envBound55406 : H12AffineFastState.Bounded env55406 := by
  intro p hp
  have h : env55406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55405_55406 : H12AffineEnvironment.transform 15 8203 env55405 = env55406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55405 == env55406) = true)

theorem identity55406 : scanCanonicalize (H12AffineFastState.compose env55406 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 64929) := by decide +kernel

theorem selectedBound55406 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38296,64929,1025,32769,4161,54561,62660,21763,8328,64,64725,57797,45524,23805,1501,54697,257,21793,46213,513]

theorem envBound55407 : H12AffineFastState.Bounded env55407 := by
  intro p hp
  have h : env55407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55406_55407 : H12AffineEnvironment.transform 17 64929 env55406 = env55407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64929 env55406 == env55407) = true)

theorem identity55407 : scanCanonicalize (H12AffineFastState.compose env55407 (packedSelected [2,3,4,5,6,8,9,14,16,28] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound55407 : packedSelected [2,3,4,5,6,8,9,14,16,28] rootPS < 2^1333 := by decide +kernel

def env55408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,8203,5441,32120,1025,216,4161,22008,29725,21763,8328,64,31756,24860,12557,23805,1501,21872,257,21793,13404,513]

theorem envBound55408 : H12AffineFastState.Bounded env55408 := by
  intro p hp
  have h : env55408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55407_55408 : H12AffineEnvironment.transform 14 217 env55407 = env55408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env55407 == env55408) = true)

theorem identity55408 : scanCanonicalize (H12AffineFastState.compose env55408 (packedSelected [0,2,4,6,7,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound55408 : packedSelected [0,2,4,6,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env55409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,217,399,5441,23804,1025,216,4161,22008,21913,21763,268,64,23944,16536,4233,23805,1501,21872,257,21793,5592,513]

theorem envBound55409 : H12AffineFastState.Bounded env55409 := by
  intro p hp
  have h : env55409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55408_55409 : H12AffineEnvironment.transform 12 388 env55408 = env55409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env55408 == env55409) = true)

theorem identity55409 : scanCanonicalize (H12AffineFastState.compose env55409 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound55409 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5456,217,399,5441,2476,1025,216,4161,168,201,83,268,64,2264,5576,4233,2477,1501,32,257,113,5592,513]

theorem envBound55410 : H12AffineFastState.Bounded env55410 := by
  intro p hp
  have h : env55410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55409_55410 : H12AffineEnvironment.transform 13 5456 env55409 = env55410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env55409 == env55410) = true)

theorem identity55410 : scanCanonicalize (H12AffineFastState.compose env55410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound55410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55411 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,388,4113,217,399,4096,2476,320,216,4161,168,201,83,268,64,2264,4233,4233,2477,156,32,257,113,4249,513]

theorem envBound55411 : H12AffineFastState.Bounded env55411 := by
  intro p hp
  have h : env55411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55410_55411 : H12AffineEnvironment.transform 9 321 env55410 = env55411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env55410 == env55411) = true)

theorem identity55411 : scanCanonicalize (H12AffineFastState.compose env55411 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55411 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env55412 : List Nat := [2,4,8,16,32,64,128,36,512,101,2048,4096,160,4113,217,171,4096,2184,100,216,4161,168,201,83,40,64,2264,4233,4233,2185,156,32,37,113,4249,513]

theorem envBound55412 : H12AffineFastState.Bounded env55412 := by
  intro p hp
  have h : env55412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55411_55412 : H12AffineEnvironment.transform 7 36 env55411 = env55412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55411 == env55412) = true)

theorem identity55412 : scanCanonicalize (H12AffineFastState.compose env55412 (packedSelected [2,4,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55412 : packedSelected [2,4,7,11] rootPS < 2^1333 := by decide +kernel

def env55413 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,4096,160,4113,136,171,4096,2184,53,137,4112,168,152,2,40,17,2185,4233,4233,2185,156,32,37,32,4249,513]

theorem envBound55413 : H12AffineFastState.Bounded env55413 := by
  intro p hp
  have h : env55413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55412_55413 : H12AffineEnvironment.transform 5 17 env55412 = env55413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55412 == env55413) = true)

theorem identity55413 : scanCanonicalize (H12AffineFastState.compose env55413 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound55413 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55414 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,2065,160,2048,136,171,2065,2184,53,137,2049,168,152,2,40,17,2185,2200,2200,2185,156,32,37,32,2184,513]

theorem envBound55414 : H12AffineFastState.Bounded env55414 := by
  intro p hp
  have h : env55414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55413_55414 : H12AffineEnvironment.transform 11 2065 env55413 = env55414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env55413 == env55414) = true)

theorem identity55414 : scanCanonicalize (H12AffineFastState.compose env55414 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound55414 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55415 : List Nat := [2,4,8,16,32,17,128,36,512,52,137,152,160,137,136,171,152,1,53,137,136,168,152,2,40,17,0,17,17,0,156,32,37,32,1,513]

theorem envBound55415 : H12AffineFastState.Bounded env55415 := by
  intro p hp
  have h : env55415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55414_55415 : H12AffineEnvironment.transform 10 137 env55414 = env55415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env55414 == env55415) = true)

def env55416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257181,254096,8328,64,2157717,2253852,140364,2404637,2102684,2373704,257,21793,46213,2175563]

theorem envBound55416 : H12AffineFastState.Bounded env55416 := by
  intro p hp
  have h : env55416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55355_55416 : H12AffineEnvironment.transform 21 441625 env55355 = env55416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env55355 == env55416) = true)

def env55417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,254096,8328,64,64725,160860,140364,303453,1500,272392,257,21793,46213,74251]

theorem envBound55417 : H12AffineFastState.Bounded env55417 := by
  intro p hp
  have h : env55417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55416_55417 : H12AffineEnvironment.transform 20 4160 env55416 = env55417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55416 == env55417) = true)

theorem identity55417 : scanCanonicalize (H12AffineFastState.compose env55417 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound55417 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,98780,8328,64,64725,5392,17664,303453,1500,272392,257,21793,46213,74251]

theorem envBound55418 : H12AffineFastState.Bounded env55418 := by
  intro p hp
  have h : env55418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55417_55418 : H12AffineEnvironment.transform 16 24908 env55417 = env55418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env55417 == env55418) = true)

def env55419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,98644,8192,64,64605,5392,17664,303453,1364,272392,257,21793,46093,74251]

theorem envBound55419 : H12AffineFastState.Bounded env55419 := by
  intro p hp
  have h : env55419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55418_55419 : H12AffineEnvironment.transform 6 8 env55418 = env55419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55418 == env55419) = true)

theorem identity55419 : scanCanonicalize (H12AffineFastState.compose env55419 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55419 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1025,32769,4160,62588,17,98644,8192,64,64605,5392,17664,35188,1364,33,257,21793,46093,74251]

theorem envBound55420 : H12AffineFastState.Bounded env55420 := by
  intro p hp
  have h : env55420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55419_55420 : H12AffineEnvironment.transform 17 10281 env55419 = env55420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55419 == env55420) = true)

theorem identity55420 : scanCanonicalize (H12AffineFastState.compose env55420 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound55420 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24908,10281,1025,32769,4160,62588,17,29791,8192,64,64605,5392,17664,35188,1364,33,257,21793,46093,55040]

theorem envBound55421 : H12AffineFastState.Bounded env55421 := by
  intro p hp
  have h : env55421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55420_55421 : H12AffineEnvironment.transform 15 62731 env55420 = env55421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env55420 == env55421) = true)

theorem identity55421 : scanCanonicalize (H12AffineFastState.compose env55421 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55421 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env55422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,33110,5393,10281,1025,32769,4160,32801,17,2,8192,64,34816,5392,12637,35188,1364,33,257,8572,46093,41821]

theorem envBound55422 : H12AffineFastState.Bounded env55422 := by
  intro p hp
  have h : env55422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55421_55422 : H12AffineEnvironment.transform 13 13405 env55421 = env55422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55421 == env55422) = true)

theorem identity55422 : scanCanonicalize (H12AffineFastState.compose env55422 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55422 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,33110,5393,2421,1025,32769,4160,32801,17,2,348,64,34816,5392,4097,35188,1364,33,257,32,38225,33281]

theorem envBound55423 : H12AffineFastState.Bounded env55423 := by
  intro p hp
  have h : env55423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55422_55423 : H12AffineEnvironment.transform 12 348 env55422 = env55423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55422 == env55423) = true)

theorem identity55423 : scanCanonicalize (H12AffineFastState.compose env55423 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55423 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env55424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,32768,33031,5393,2340,1025,32769,4113,32801,17,2,269,17,34816,5392,4097,35109,1285,33,257,32,38144,33281]

theorem envBound55424 : H12AffineFastState.Bounded env55424 := by
  intro p hp
  have h : env55424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55423_55424 : H12AffineEnvironment.transform 5 17 env55423 = env55424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55423 == env55424) = true)

theorem identity55424 : scanCanonicalize (H12AffineFastState.compose env55424 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 4388) := by decide +kernel

theorem selectedBound55424 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55425 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,4388,4131,5393,2340,1025,4389,4113,4357,17,2,269,17,6436,5392,4097,6145,1285,33,257,32,1060,4901]

theorem envBound55425 : H12AffineFastState.Bounded env55425 := by
  intro p hp
  have h : env55425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55424_55425 : H12AffineEnvironment.transform 14 4388 env55424 = env55425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4388 env55424 == env55425) = true)

theorem identity55425 : scanCanonicalize (H12AffineFastState.compose env55425 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound55425 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env55426 : List Nat := [2,4,8,16,32,17,8,256,512,817,2048,4096,269,4656,4388,4131,4640,2340,816,4389,4113,4357,17,2,269,17,6436,4641,4097,6145,564,33,257,32,789,4901]

theorem envBound55426 : H12AffineFastState.Bounded env55426 := by
  intro p hp
  have h : env55426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55425_55426 : H12AffineEnvironment.transform 9 817 env55425 = env55426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env55425 == env55426) = true)

theorem identity55426 : scanCanonicalize (H12AffineFastState.compose env55426 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound55426 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env55427 : List Nat := [2,4,8,16,32,17,8,256,512,817,2048,261,269,821,33,294,805,2340,816,32,276,0,17,2,269,17,2081,804,260,2308,564,33,257,32,789,544]

theorem envBound55427 : H12AffineFastState.Bounded env55427 := by
  intro p hp
  have h : env55427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55426_55427 : H12AffineEnvironment.transform 11 261 env55426 = env55427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env55426 == env55427) = true)

theorem identity55427 : scanCanonicalize (H12AffineFastState.compose env55427 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound55427 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env55428 : List Nat := [2,4,8,16,32,17,8,256,16,289,2048,261,269,293,33,294,309,2340,288,32,276,0,17,2,269,17,2081,308,260,2308,36,33,257,32,261,48]

theorem envBound55428 : H12AffineFastState.Bounded env55428 := by
  intro p hp
  have h : env55428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55427_55428 : H12AffineEnvironment.transform 8 16 env55427 = env55428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env55427 == env55428) = true)

theorem identity55428 : scanCanonicalize (H12AffineFastState.compose env55428 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound55428 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55429 : List Nat := [2,4,8,16,32,17,8,256,16,289,17,261,269,293,33,294,309,309,288,32,276,0,17,2,269,17,48,308,260,277,36,33,257,32,261,48]

theorem envBound55429 : H12AffineFastState.Bounded env55429 := by
  intro p hp
  have h : env55429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55428_55429 : H12AffineEnvironment.transform 10 17 env55428 = env55429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env55428 == env55429) = true)

theorem identity55429 : scanCanonicalize (H12AffineFastState.compose env55429 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound55429 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env55430 : List Nat := [2,4,8,16,32,17,8,53,16,20,17,48,56,16,33,19,0,0,21,32,33,0,17,2,56,17,48,1,49,32,36,33,52,32,48,48]

theorem envBound55430 : H12AffineFastState.Bounded env55430 := by
  intro p hp
  have h : env55430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55429_55430 : H12AffineEnvironment.transform 7 53 env55429 = env55430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env55429 == env55430) = true)

theorem identity55430 : scanCanonicalize (H12AffineFastState.compose env55430 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55431 : List Nat := [2,4,8,16,1,17,8,20,16,20,17,17,25,16,0,19,0,0,21,1,0,0,17,2,25,17,17,1,16,1,5,0,21,1,17,17]

theorem envBound55431 : H12AffineFastState.Bounded env55431 := by
  intro p hp
  have h : env55431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55430_55431 : H12AffineEnvironment.transform 4 1 env55430 = env55431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55430 == env55431) = true)

def env55432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,98645,8193,64,64604,5392,17664,303453,1365,272392,257,21793,46092,74251]

theorem envBound55432 : H12AffineFastState.Bounded env55432 := by
  intro p hp
  have h : env55432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55418_55432 : H12AffineEnvironment.transform 6 9 env55418 = env55432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55418 == env55432) = true)

theorem identity55432 : scanCanonicalize (H12AffineFastState.compose env55432 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound55432 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1025,32769,4160,21792,17,98645,8193,64,64604,5392,17664,10280,1365,41341,257,21793,46092,74251]

theorem envBound55433 : H12AffineFastState.Bounded env55433 := by
  intro p hp
  have h : env55433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55432_55433 : H12AffineEnvironment.transform 17 35189 env55432 = env55433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env55432 == env55433) = true)

theorem identity55433 : scanCanonicalize (H12AffineFastState.compose env55433 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound55433 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,65536,24908,10361,1025,8461,4160,21792,17,73817,8193,64,23888,5392,17664,10280,1365,113,257,21793,5376,74251]

theorem envBound55434 : H12AffineFastState.Bounded env55434 := by
  intro p hp
  have h : env55434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55433_55434 : H12AffineEnvironment.transform 14 8460 env55433 = env55434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env55433 == env55434) = true)

theorem identity55434 : scanCanonicalize (H12AffineFastState.compose env55434 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55434 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8203,24908,10361,1025,8461,4160,21792,17,82,8193,64,23888,5392,17664,10280,1365,113,257,21793,5376,512]

theorem envBound55435 : H12AffineFastState.Bounded env55435 := by
  intro p hp
  have h : env55435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55434_55435 : H12AffineEnvironment.transform 15 8203 env55434 = env55435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55434 == env55435) = true)

theorem identity55435 : scanCanonicalize (H12AffineFastState.compose env55435 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55435 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,292,35,16740,2129,1025,293,4160,21792,17,82,41,64,23888,5392,17664,2048,1365,113,257,21793,5376,512]

theorem envBound55436 : H12AffineFastState.Bounded env55436 := by
  intro p hp
  have h : env55436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55435_55436 : H12AffineEnvironment.transform 12 40 env55435 = env55436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55435 == env55436) = true)

theorem identity55436 : scanCanonicalize (H12AffineFastState.compose env55436 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55436 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env55437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,292,35,5221,2129,1025,293,4160,33,17,82,41,64,2129,5392,4097,2048,1365,113,257,32,5376,512]

theorem envBound55437 : H12AffineFastState.Bounded env55437 := by
  intro p hp
  have h : env55437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55436_55437 : H12AffineEnvironment.transform 13 5377 env55436 = env55437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55436 == env55437) = true)

theorem identity55437 : scanCanonicalize (H12AffineFastState.compose env55437 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55437 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55438 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,40,5205,112,35,5221,2129,1025,113,4160,33,17,82,41,64,2129,5188,4097,2048,1025,113,85,32,5204,512]

theorem envBound55438 : H12AffineFastState.Bounded env55438 := by
  intro p hp
  have h : env55438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55437_55438 : H12AffineEnvironment.transform 7 84 env55437 = env55438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55437 == env55438) = true)

theorem identity55438 : scanCanonicalize (H12AffineFastState.compose env55438 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55438 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55439 : List Nat := [2,4,8,16,32,64,9,84,512,52,2048,4096,40,4193,112,35,4177,2129,53,113,4160,33,17,82,41,64,2129,4208,4097,2048,53,113,85,32,4192,512]

theorem envBound55439 : H12AffineFastState.Bounded env55439 := by
  intro p hp
  have h : env55439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55438_55439 : H12AffineEnvironment.transform 9 52 env55438 = env55439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55438 == env55439) = true)

theorem identity55439 : scanCanonicalize (H12AffineFastState.compose env55439 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55439 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env55440 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,4096,40,4145,32,35,4097,2049,53,33,4112,33,17,2,41,16,2049,4128,4097,2048,53,33,5,32,4144,512]

theorem envBound55440 : H12AffineFastState.Bounded env55440 := by
  intro p hp
  have h : env55440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55439_55440 : H12AffineEnvironment.transform 5 16 env55439 = env55440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55439 == env55440) = true)

theorem identity55440 : scanCanonicalize (H12AffineFastState.compose env55440 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55440 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55441 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,4096,8,4113,0,3,4097,2049,21,1,4112,1,17,2,9,16,2049,4096,4097,2048,21,1,5,0,4112,512]

theorem envBound55441 : H12AffineFastState.Bounded env55441 := by
  intro p hp
  have h : env55441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55440_55441 : H12AffineEnvironment.transform 4 0 env55440 = env55441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55440 == env55441) = true)

theorem identity55441 : scanCanonicalize (H12AffineFastState.compose env55441 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound55441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55442 : List Nat := [2,4,8,16,0,16,9,4,512,20,512,4096,8,4113,0,3,4097,513,21,1,4112,1,17,2,9,16,513,4096,4097,512,21,1,5,0,4112,512]

theorem envBound55442 : H12AffineFastState.Bounded env55442 := by
  intro p hp
  have h : env55442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55441_55442 : H12AffineEnvironment.transform 10 512 env55441 = env55442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env55441 == env55442) = true)

theorem identity55442 : scanCanonicalize (H12AffineFastState.compose env55442 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 543) := by decide +kernel

theorem selectedBound55442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55443 : List Nat := [2,4,8,16,0,16,9,4,512,20,512,543,8,526,0,3,542,513,21,1,527,1,17,2,9,16,513,543,542,512,21,1,5,0,527,512]

theorem envBound55443 : H12AffineFastState.Bounded env55443 := by
  intro p hp
  have h : env55443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55442_55443 : H12AffineEnvironment.transform 11 543 env55442 = env55443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 543 env55442 == env55443) = true)

theorem identity55443 : scanCanonicalize (H12AffineFastState.compose env55443 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound55443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55444 : List Nat := [2,4,8,16,0,16,9,4,30,20,30,1,8,16,0,3,0,31,21,1,17,1,17,2,9,16,31,1,0,30,21,1,5,0,17,30]

theorem envBound55444 : H12AffineFastState.Bounded env55444 := by
  intro p hp
  have h : env55444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55443_55444 : H12AffineEnvironment.transform 8 30 env55443 = env55444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env55443 == env55444) = true)

theorem identity55444 : scanCanonicalize (H12AffineFastState.compose env55444 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound55444 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55445 : List Nat := [2,4,8,15,0,15,9,4,1,11,1,1,8,15,0,3,0,0,10,1,14,1,14,2,9,15,0,1,0,1,10,1,5,0,14,1]

theorem envBound55445 : H12AffineFastState.Bounded env55445 := by
  intro p hp
  have h : env55445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55444_55445 : H12AffineEnvironment.transform 3 15 env55444 = env55445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env55444 == env55445) = true)

theorem identity55445 : scanCanonicalize (H12AffineFastState.compose env55445 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55445 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55446 : List Nat := [2,4,6,1,0,1,7,4,1,5,1,1,6,1,0,3,0,0,4,1,0,1,0,2,7,1,0,1,0,1,4,1,5,0,0,1]

theorem envBound55446 : H12AffineFastState.Bounded env55446 := by
  intro p hp
  have h : env55446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55445_55446 : H12AffineEnvironment.transform 2 6 env55445 = env55446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55445 == env55446) = true)

def env55447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,254096,8328,64,64724,160861,140364,303452,1501,272393,257,21793,46213,74250]

theorem envBound55447 : H12AffineFastState.Bounded env55447 := by
  intro p hp
  have h : env55447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55416_55447 : H12AffineEnvironment.transform 20 4161 env55416 = env55447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55416 == env55447) = true)

theorem identity55447 : scanCanonicalize (H12AffineFastState.compose env55447 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound55447 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,412108,155996,201797,8328,64,2049,160861,140364,284041,1501,272393,257,21793,16464,74250]

theorem envBound55448 : H12AffineFastState.Bounded env55448 := by
  intro p hp
  have h : env55448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55447_55448 : H12AffineEnvironment.transform 14 29909 env55447 = env55448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env55447 == env55448) = true)

def env55449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,411972,155996,201797,8192,64,2049,160861,140364,283905,1365,272393,257,21793,16464,74250]

theorem envBound55449 : H12AffineFastState.Bounded env55449 := by
  intro p hp
  have h : env55449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55448_55449 : H12AffineEnvironment.transform 6 8 env55448 = env55449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55448 == env55449) = true)

theorem identity55449 : scanCanonicalize (H12AffineFastState.compose env55449 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound55449 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,157801,1025,29788,4161,8493,155996,201797,8192,64,2049,160861,140364,146792,1365,147552,257,21793,16464,74250]

theorem envBound55450 : H12AffineFastState.Bounded env55450 := by
  intro p hp
  have h : env55450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55449_55450 : H12AffineEnvironment.transform 17 157801 env55449 = env55450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env55449 == env55450) = true)

theorem identity55450 : scanCanonicalize (H12AffineFastState.compose env55450 (packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound55450 : packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS < 2^1333 := by decide +kernel

def env55451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,79130,89459,1025,29788,4161,8493,87110,8543,8192,64,2049,82247,69974,67698,1365,95610,257,21793,16464,74250]

end H12CloudChart0