import H12CloudChart0Data195

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound49637 : H12AffineFastState.Bounded env49637 := by
  intro p hp
  have h : env49637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49636_49637 : H12AffineEnvironment.transform 14 8541 env49636 = env49637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49636 == env49637) = true)

theorem identity49637 : scanCanonicalize (H12AffineFastState.compose env49637 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49637 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,1,343,5392,2556,1024,0,4161,32,16,139,468,65,2048,5393,4096,2557,1501,33,256,32,5592,513]

theorem envBound49638 : H12AffineFastState.Bounded env49638 := by
  intro p hp
  have h : env49638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49637_49638 : H12AffineEnvironment.transform 12 348 env49637 = env49638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49637 == env49638) = true)

theorem identity49638 : scanCanonicalize (H12AffineFastState.compose env49638 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3309) := by decide +kernel

theorem selectedBound49638 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3309,348,2541,1,343,2557,2556,1024,0,3244,32,16,139,468,65,2048,2556,3309,2557,1501,33,256,32,2357,513]

theorem envBound49639 : H12AffineFastState.Bounded env49639 := by
  intro p hp
  have h : env49639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49638_49639 : H12AffineEnvironment.transform 11 3309 env49638 = env49639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3309 env49638 == env49639) = true)

theorem identity49639 : scanCanonicalize (H12AffineFastState.compose env49639 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound49639 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env49640 : List Nat := [2,4,8,16,32,64,128,256,512,266,2048,2535,348,2541,1,343,2557,2556,266,0,2470,32,16,139,468,65,2048,2556,2535,2557,215,33,256,32,2357,513]

theorem envBound49640 : H12AffineFastState.Bounded env49640 := by
  intro p hp
  have h : env49640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49639_49640 : H12AffineEnvironment.transform 9 266 env49639 = env49640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env49639 == env49640) = true)

theorem identity49640 : scanCanonicalize (H12AffineFastState.compose env49640 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49640 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env49641 : List Nat := [2,4,8,16,32,64,8,256,512,266,2048,2415,348,2405,1,343,2421,2420,266,0,2350,32,16,3,348,65,2048,2420,2415,2421,95,33,256,32,2357,513]

theorem envBound49641 : H12AffineFastState.Bounded env49641 := by
  intro p hp
  have h : env49641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49640_49641 : H12AffineEnvironment.transform 6 8 env49640 = env49641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49640 == env49641) = true)

theorem identity49641 : scanCanonicalize (H12AffineFastState.compose env49641 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49641 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49642 : List Nat := [2,4,8,11,32,64,8,256,512,266,2048,2415,327,2405,1,332,2414,2415,266,0,2350,32,11,3,327,65,2048,2415,2415,2414,68,33,256,32,2350,513]

theorem envBound49642 : H12AffineFastState.Bounded env49642 := by
  intro p hp
  have h : env49642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49641_49642 : H12AffineEnvironment.transform 3 11 env49641 = env49642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49641 == env49642) = true)

theorem identity49642 : scanCanonicalize (H12AffineFastState.compose env49642 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49643 : List Nat := [2,4,8,11,32,0,8,256,512,266,2048,2351,263,2341,1,268,2350,2351,266,0,2350,32,11,3,263,1,2048,2351,2351,2350,4,33,256,32,2350,513]

theorem envBound49643 : H12AffineFastState.Bounded env49643 := by
  intro p hp
  have h : env49643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49642_49643 : H12AffineEnvironment.transform 5 0 env49642 = env49643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49642 == env49643) = true)

theorem identity49643 : scanCanonicalize (H12AffineFastState.compose env49643 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 294) := by decide +kernel

theorem selectedBound49643 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env49644 : List Nat := [2,4,8,11,32,0,8,256,294,266,2048,2351,263,2341,1,268,2350,2351,266,0,2350,32,11,3,263,1,2048,2351,2351,2350,4,33,256,32,2350,295]

theorem envBound49644 : H12AffineFastState.Bounded env49644 := by
  intro p hp
  have h : env49644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49643_49644 : H12AffineEnvironment.transform 8 294 env49643 = env49644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 294 env49643 == env49644) = true)

theorem identity49644 : scanCanonicalize (H12AffineFastState.compose env49644 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49644 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env49645 : List Nat := [2,4,3,0,32,0,3,256,294,257,2048,2340,263,2341,1,263,2341,2340,257,0,2341,32,0,3,263,1,2048,2340,2340,2341,4,33,256,32,2341,295]

theorem envBound49645 : H12AffineFastState.Bounded env49645 := by
  intro p hp
  have h : env49645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49644_49645 : H12AffineEnvironment.transform 2 3 env49644 = env49645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49644 == env49645) = true)

theorem identity49645 : scanCanonicalize (H12AffineFastState.compose env49645 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49645 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49646 : List Nat := [2,4,3,0,32,0,3,4,34,5,2048,2080,3,2081,1,3,2081,2080,5,0,2081,32,0,3,3,1,2048,2080,2080,2081,4,33,4,32,2081,35]

theorem envBound49646 : H12AffineFastState.Bounded env49646 := by
  intro p hp
  have h : env49646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49645_49646 : H12AffineEnvironment.transform 7 4 env49645 = env49646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49645 == env49646) = true)

theorem identity49646 : scanCanonicalize (H12AffineFastState.compose env49646 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49646 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env49647 : List Nat := [2,4,3,0,1,0,3,4,3,5,2048,2049,3,2048,1,3,2048,2049,5,0,2048,1,0,3,3,1,2048,2049,2049,2048,4,0,4,1,2048,2]

theorem envBound49647 : H12AffineFastState.Bounded env49647 := by
  intro p hp
  have h : env49647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49646_49647 : H12AffineEnvironment.transform 4 1 env49646 = env49647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49646 == env49647) = true)

theorem identity49647 : scanCanonicalize (H12AffineFastState.compose env49647 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49647 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49648 : List Nat := [2,3,3,0,1,0,3,3,3,2,2048,2049,3,2048,1,3,2048,2049,2,0,2048,1,0,3,3,1,2048,2049,2049,2048,3,0,3,1,2048,2]

theorem envBound49648 : H12AffineFastState.Bounded env49648 := by
  intro p hp
  have h : env49648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49647_49648 : H12AffineEnvironment.transform 1 3 env49647 = env49648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49647 == env49648) = true)

def env49649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,98781,8328,65,295420,458144,17664,10401,453996,144492,256,21792,46213,510651]

theorem envBound49649 : H12AffineFastState.Bounded env49649 := by
  intro p hp
  have h : env49649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49631_49649 : H12AffineEnvironment.transform 21 272513 env49631 = env49649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49631 == env49649) = true)

def env49650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452649,98645,8192,65,295284,458024,17664,10281,453996,144492,256,21792,46093,510515]

theorem envBound49650 : H12AffineFastState.Bounded env49650 := by
  intro p hp
  have h : env49650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49649_49650 : H12AffineEnvironment.transform 6 8 env49649 = env49650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49649 == env49650) = true)

theorem identity49650 : scanCanonicalize (H12AffineFastState.compose env49650 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound49650 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,100386,1024,32769,225370,106539,221195,98645,8192,65,67926,226570,17664,10281,222542,144492,256,21792,46093,147985]

theorem envBound49651 : H12AffineFastState.Bounded env49651 := by
  intro p hp
  have h : env49651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49650_49651 : H12AffineEnvironment.transform 17 100386 env49650 = env49651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env49650 == env49651) = true)

theorem identity49651 : scanCanonicalize (H12AffineFastState.compose env49651 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound49651 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,100386,1024,32769,102679,106539,98630,98645,8192,65,67926,103495,17664,10281,99331,54561,256,21792,46093,41820]

theorem envBound49652 : H12AffineFastState.Bounded env49652 := by
  intro p hp
  have h : env49652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49651_49652 : H12AffineEnvironment.transform 16 57677 env49651 = env49652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env49651 == env49652) = true)

theorem identity49652 : scanCanonicalize (H12AffineFastState.compose env49652 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49652 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env49653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,76159,1024,8540,77898,65910,73755,73736,8192,65,67926,79130,17664,10281,75102,29820,256,21792,5456,513]

theorem envBound49653 : H12AffineFastState.Bounded env49653 := by
  intro p hp
  have h : env49653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49652_49653 : H12AffineEnvironment.transform 14 8541 env49652 = env49653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49652 == env49653) = true)

theorem identity49653 : scanCanonicalize (H12AffineFastState.compose env49653 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound49653 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,16400,22885,1024,8540,16464,29036,20481,20498,8192,65,31052,17664,17664,10281,21828,29820,256,21792,5456,513]

theorem envBound49654 : H12AffineFastState.Bounded env49654 := by
  intro p hp
  have h : env49654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49653_49654 : H12AffineEnvironment.transform 15 28698 env49653 = env49654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env49653 == env49654) = true)

theorem identity49654 : scanCanonicalize (H12AffineFastState.compose env49654 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound49654 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,8541,343,12637,10280,1024,8540,12573,33,8524,8543,8192,65,2049,13389,13389,10281,9225,1329,256,9325,5456,513]

theorem envBound49655 : H12AffineFastState.Bounded env49655 := by
  intro p hp
  have h : env49655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49654_49655 : H12AffineEnvironment.transform 13 12621 env49654 = env49655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env49654 == env49655) = true)

theorem identity49655 : scanCanonicalize (H12AffineFastState.compose env49655 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49655 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env49656 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,12393,8313,115,12409,10280,1024,8312,12345,33,8296,8315,8192,65,2049,13389,13389,10281,9225,1045,36,9325,5236,513]

theorem envBound49656 : H12AffineFastState.Bounded env49656 := by
  intro p hp
  have h : env49656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49655_49656 : H12AffineEnvironment.transform 7 36 env49655 = env49656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49655 == env49656) = true)

theorem identity49656 : scanCanonicalize (H12AffineFastState.compose env49656 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound49656 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env49657 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3188,8192,11293,8313,115,11277,10280,1024,8312,11341,33,8296,8315,8192,65,2049,10297,10297,10281,9225,1045,36,9325,2048,513]

theorem envBound49657 : H12AffineFastState.Bounded env49657 := by
  intro p hp
  have h : env49657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49656_49657 : H12AffineEnvironment.transform 11 3188 env49656 = env49657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env49656 == env49657) = true)

theorem identity49657 : scanCanonicalize (H12AffineFastState.compose env49657 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound49657 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env49658 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3188,121,3172,0,115,3188,2129,1024,1,3124,33,17,2,121,65,2049,2112,2112,2128,1136,1045,36,1044,2048,513]

theorem envBound49658 : H12AffineFastState.Bounded env49658 := by
  intro p hp
  have h : env49658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49657_49658 : H12AffineEnvironment.transform 12 121 env49657 = env49658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env49657 == env49658) = true)

theorem identity49658 : scanCanonicalize (H12AffineFastState.compose env49658 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49658 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49659 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,2112,121,2128,0,115,2112,2129,52,1,2048,33,17,2,121,65,2049,2112,2112,2128,68,33,36,32,2048,513]

theorem envBound49659 : H12AffineFastState.Bounded env49659 := by
  intro p hp
  have h : env49659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49658_49659 : H12AffineEnvironment.transform 9 52 env49658 = env49659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49658 == env49659) = true)

theorem identity49659 : scanCanonicalize (H12AffineFastState.compose env49659 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49660 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,41,2048,0,35,2064,2049,52,1,2048,33,17,2,41,17,2049,2064,2064,2048,20,33,36,32,2048,513]

theorem envBound49660 : H12AffineFastState.Bounded env49660 := by
  intro p hp
  have h : env49660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49659_49660 : H12AffineEnvironment.transform 5 16 env49659 = env49660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49659 == env49660) = true)

def env49661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452648,98644,8193,65,295285,458025,17664,10280,453996,144492,256,21792,46092,510514]

theorem envBound49661 : H12AffineFastState.Bounded env49661 := by
  intro p hp
  have h : env49661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49649_49661 : H12AffineEnvironment.transform 6 9 env49649 = env49661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49649 == env49661) = true)

def env49662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272392,272440,98644,8193,65,295285,277817,17664,10280,273788,62588,256,21792,46092,330274]

theorem envBound49662 : H12AffineFastState.Bounded env49662 := by
  intro p hp
  have h : env49662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49661_49662 : H12AffineEnvironment.transform 16 49168 env49661 = env49662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env49661 == env49662) = true)

theorem identity49662 : scanCanonicalize (H12AffineFastState.compose env49662 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49662 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,33,17,98644,8193,65,43356,5392,17664,10280,1365,62588,256,21792,46092,74251]

theorem envBound49663 : H12AffineFastState.Bounded env49663 := by
  intro p hp
  have h : env49663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49662_49663 : H12AffineEnvironment.transform 17 10281 env49662 = env49663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49662 == env49663) = true)

theorem identity49663 : scanCanonicalize (H12AffineFastState.compose env49663 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound49663 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env49664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10281,1024,32769,4160,33,17,8543,8193,65,43356,5392,17664,10280,1365,62588,256,21792,46092,33280]

theorem envBound49664 : H12AffineFastState.Bounded env49664 := by
  intro p hp
  have h : env49664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49663_49664 : H12AffineEnvironment.transform 15 40971 env49663 = env49664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env49663 == env49664) = true)

theorem identity49664 : scanCanonicalize (H12AffineFastState.compose env49664 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49664 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env49665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,46157,10281,1024,32769,4160,33,17,8543,8193,65,43356,5392,12637,10280,1365,32801,256,8573,46092,33280]

theorem envBound49665 : H12AffineFastState.Bounded env49665 := by
  intro p hp
  have h : env49665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49664_49665 : H12AffineEnvironment.transform 13 13405 env49664 = env49665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49664 == env49665) = true)

theorem identity49665 : scanCanonicalize (H12AffineFastState.compose env49665 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49665 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env49666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33111,38161,2421,1024,32769,4160,33,17,3,349,65,34816,5392,4097,2420,1365,32801,256,33,38224,33280]

theorem envBound49666 : H12AffineFastState.Bounded env49666 := by
  intro p hp
  have h : env49666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49665_49666 : H12AffineEnvironment.transform 12 348 env49665 = env49666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49665 == env49666) = true)

theorem identity49666 : scanCanonicalize (H12AffineFastState.compose env49666 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49666 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2421,1024,0,4160,33,17,3,349,65,2049,5392,4097,2420,1365,32,256,33,5457,513]

theorem envBound49667 : H12AffineFastState.Bounded env49667 := by
  intro p hp
  have h : env49667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49666_49667 : H12AffineEnvironment.transform 14 1 env49666 = env49667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49666 == env49667) = true)

theorem identity49667 : scanCanonicalize (H12AffineFastState.compose env49667 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound49667 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1087,4096,348,5377,1,342,5392,1354,1024,0,4160,33,17,3,349,65,1086,5392,4097,1355,1365,32,256,33,5457,513]

theorem envBound49668 : H12AffineFastState.Bounded env49668 := by
  intro p hp
  have h : env49668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49667_49668 : H12AffineEnvironment.transform 10 1087 env49667 = env49668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env49667 == env49668) = true)

theorem identity49668 : scanCanonicalize (H12AffineFastState.compose env49668 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound49668 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1087,80,348,1361,1,342,1344,1354,1024,0,16,33,17,3,349,65,1086,1344,81,1355,1365,32,256,33,1281,513]

theorem envBound49669 : H12AffineFastState.Bounded env49669 := by
  intro p hp
  have h : env49669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49668_49669 : H12AffineEnvironment.transform 11 80 env49668 = env49669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env49668 == env49669) = true)

theorem identity49669 : scanCanonicalize (H12AffineFastState.compose env49669 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49669 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env49670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1087,0,268,1281,1,262,1296,1306,1024,0,16,33,17,3,269,17,1086,1296,1,1307,1285,32,256,33,1281,513]

theorem envBound49670 : H12AffineFastState.Bounded env49670 := by
  intro p hp
  have h : env49670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49669_49670 : H12AffineEnvironment.transform 5 16 env49669 = env49670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49669 == env49670) = true)

theorem identity49670 : scanCanonicalize (H12AffineFastState.compose env49670 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49671 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1087,0,40,1061,1,34,1076,1086,1024,0,16,33,17,3,41,17,1086,1076,1,1087,1057,32,36,33,1061,513]

theorem envBound49671 : H12AffineFastState.Bounded env49671 := by
  intro p hp
  have h : env49671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49670_49671 : H12AffineEnvironment.transform 7 36 env49670 = env49671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49670 == env49671) = true)

theorem identity49671 : scanCanonicalize (H12AffineFastState.compose env49671 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound49671 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49672 : List Nat := [2,4,8,16,27,16,9,31,512,1024,1028,0,19,1054,1,25,1039,1029,1024,0,16,26,17,3,18,17,1029,1039,1,1028,1050,27,31,26,1054,513]

theorem envBound49672 : H12AffineFastState.Bounded env49672 := by
  intro p hp
  have h : env49672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49671_49672 : H12AffineEnvironment.transform 4 27 env49671 = env49672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env49671 == env49672) = true)

def env49673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272392,272441,98644,8193,65,295285,277816,17664,10280,273789,62589,256,21792,46092,330275]

theorem envBound49673 : H12AffineFastState.Bounded env49673 := by
  intro p hp
  have h : env49673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49661_49673 : H12AffineEnvironment.transform 16 49169 env49661 = env49673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env49661 == env49673) = true)

theorem identity49673 : scanCanonicalize (H12AffineFastState.compose env49673 (packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49673 : packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env49674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,33,16,98644,8193,65,43356,5393,17664,10280,1364,62589,256,21792,46092,74250]

theorem envBound49674 : H12AffineFastState.Bounded env49674 := by
  intro p hp
  have h : env49674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49673_49674 : H12AffineEnvironment.transform 17 10281 env49673 = env49674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49673 == env49674) = true)

theorem identity49674 : scanCanonicalize (H12AffineFastState.compose env49674 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound49674 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env49675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,49169,10281,1024,32769,4161,33,16,8543,8193,65,43356,5393,17664,10280,1364,62589,256,21792,46092,33281]

theorem envBound49675 : H12AffineFastState.Bounded env49675 := by
  intro p hp
  have h : env49675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49674_49675 : H12AffineEnvironment.transform 15 40971 env49674 = env49675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env49674 == env49675) = true)

theorem identity49675 : scanCanonicalize (H12AffineFastState.compose env49675 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49675 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env49676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40971,46157,10281,1024,32769,4161,33,16,8543,8193,65,43356,5393,12636,10280,1364,32801,256,8572,46092,33281]

theorem envBound49676 : H12AffineFastState.Bounded env49676 := by
  intro p hp
  have h : env49676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49675_49676 : H12AffineEnvironment.transform 13 13404 env49675 = env49676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49675 == env49676) = true)

theorem identity49676 : scanCanonicalize (H12AffineFastState.compose env49676 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49676 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env49677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,342,5392,10281,1024,8540,4161,33,16,8543,8193,65,2049,5393,12636,10280,1364,8572,256,8572,5457,9052]

theorem envBound49677 : H12AffineFastState.Bounded env49677 := by
  intro p hp
  have h : env49677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49676_49677 : H12AffineEnvironment.transform 14 8541 env49676 = env49677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49676 == env49677) = true)

theorem identity49677 : scanCanonicalize (H12AffineFastState.compose env49677 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound49677 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4112,1297,342,5392,3173,1024,1296,4161,33,16,1299,1101,65,2049,5393,5392,3172,1364,1328,256,1328,5457,1808]

theorem envBound49678 : H12AffineFastState.Bounded env49678 := by
  intro p hp
  have h : env49678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49677_49678 : H12AffineEnvironment.transform 12 1100 env49677 = env49678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env49677 == env49678) = true)

theorem identity49678 : scanCanonicalize (H12AffineFastState.compose env49678 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound49678 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env49679 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,4096,8,4112,341,342,4436,2081,68,340,4161,33,16,343,9,65,2049,4437,4436,2080,272,372,256,372,4373,852]

theorem envBound49679 : H12AffineFastState.Bounded env49679 := by
  intro p hp
  have h : env49679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49678_49679 : H12AffineEnvironment.transform 9 68 env49678 = env49679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env49678 == env49679) = true)

theorem identity49679 : scanCanonicalize (H12AffineFastState.compose env49679 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound49679 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env49680 : List Nat := [2,4,8,16,32,64,9,84,512,68,2048,4096,8,4112,1,2,4096,2081,68,0,4161,33,16,3,9,65,2049,4097,4096,2080,68,32,84,32,4161,512]

theorem envBound49680 : H12AffineFastState.Bounded env49680 := by
  intro p hp
  have h : env49680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49679_49680 : H12AffineEnvironment.transform 7 84 env49679 = env49680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env49679 == env49680) = true)

theorem identity49680 : scanCanonicalize (H12AffineFastState.compose env49680 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49681 : List Nat := [2,4,8,16,32,16,9,4,512,20,2048,4096,8,4112,1,2,4096,2081,20,0,4113,33,16,3,9,17,2049,4097,4096,2080,20,32,4,32,4113,512]

theorem envBound49681 : H12AffineFastState.Bounded env49681 := by
  intro p hp
  have h : env49681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49680_49681 : H12AffineEnvironment.transform 5 16 env49680 = env49681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49680 == env49681) = true)

theorem identity49681 : scanCanonicalize (H12AffineFastState.compose env49681 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound49681 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49682 : List Nat := [2,4,8,16,32,16,9,4,512,20,555,4096,8,4112,1,2,4096,522,20,0,4113,33,16,3,9,17,554,4097,4096,523,20,32,4,32,4113,512]

theorem envBound49682 : H12AffineFastState.Bounded env49682 := by
  intro p hp
  have h : env49682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49681_49682 : H12AffineEnvironment.transform 10 555 env49681 = env49682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env49681 == env49682) = true)

def env49683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,8388608,8874364,8328,65,4237693,8393984,8826272,8830976,453996,12645453,256,21793,46212,510651]

theorem envBound49683 : H12AffineFastState.Bounded env49683 := by
  intro p hp
  have h : env49683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49579_49683 : H12AffineEnvironment.transform 20 456945 env49579 = env49683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env49579 == env49683) = true)

def env49684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,98780,8328,65,4237693,458144,17664,10400,453996,4594925,256,21793,46212,510651]

theorem envBound49684 : H12AffineFastState.Bounded env49684 := by
  intro p hp
  have h : env49684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49683_49684 : H12AffineEnvironment.transform 22 452768 env49683 = env49684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env49683 == env49684) = true)

def env49685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,98780,8328,65,295421,458144,17664,10400,453996,144493,256,21793,46212,510651]

theorem envBound49685 : H12AffineFastState.Bounded env49685 := by
  intro p hp
  have h : env49685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49684_49685 : H12AffineEnvironment.transform 21 272512 env49684 = env49685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49684 == env49685) = true)

theorem identity49685 : scanCanonicalize (H12AffineFastState.compose env49685 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound49685 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456945,272512,452768,21763,8328,65,295421,458144,17664,10400,453996,144493,256,21793,46212,400996]

theorem envBound49686 : H12AffineFastState.Bounded env49686 := by
  intro p hp
  have h : env49686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49685_49686 : H12AffineEnvironment.transform 15 54495 env49685 = env49686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env49685 == env49686) = true)

def env49687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456825,272392,452648,21763,8192,65,295285,458024,17664,10280,453996,144493,256,21793,46092,400996]

theorem envBound49687 : H12AffineFastState.Bounded env49687 := by
  intro p hp
  have h : env49687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49686_49687 : H12AffineEnvironment.transform 6 8 env49686 = env49687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49686 == env49687) = true)

theorem identity49687 : scanCanonicalize (H12AffineFastState.compose env49687 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound49687 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env49688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24632,262144,1024,32769,301121,272392,296976,21763,8192,65,295285,302352,17664,10280,298324,21589,256,21793,46092,294492]

theorem envBound49688 : H12AffineFastState.Bounded env49688 := by
  intro p hp
  have h : env49688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49687_49688 : H12AffineEnvironment.transform 16 24632 env49687 = env49688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env49687 == env49688) = true)

theorem identity49688 : scanCanonicalize (H12AffineFastState.compose env49688 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49688 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env49689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,5221,262144,1024,32769,301121,272392,296976,8542,8192,65,295285,302352,12637,10280,298324,8200,256,8572,46092,264705]

theorem envBound49689 : H12AffineFastState.Bounded env49689 := by
  intro p hp
  have h : env49689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49688_49689 : H12AffineEnvironment.transform 13 13405 env49688 = env49689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49688 == env49689) = true)

theorem identity49689 : scanCanonicalize (H12AffineFastState.compose env49689 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound49689 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env49690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,5221,2048,1024,32769,36929,8200,32784,8542,8192,65,35189,38160,12637,10280,34132,8200,256,8572,46092,513]

theorem envBound49690 : H12AffineFastState.Bounded env49690 := by
  intro p hp
  have h : env49690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49689_49690 : H12AffineEnvironment.transform 17 2048 env49689 = env49690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env49689 == env49690) = true)

theorem identity49690 : scanCanonicalize (H12AffineFastState.compose env49690 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49690 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49691 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,32768,40970,5173,2048,1024,32769,36881,8200,32784,8462,8192,17,35109,38160,12557,10280,34052,8200,256,8492,46092,513]

theorem envBound49691 : H12AffineFastState.Bounded env49691 := by
  intro p hp
  have h : env49691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49690_49691 : H12AffineEnvironment.transform 5 16 env49690 = env49691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49690 == env49691) = true)

theorem identity49691 : scanCanonicalize (H12AffineFastState.compose env49691 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound49691 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49692 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,292,8494,5173,2048,1024,293,4405,8200,308,8462,8192,17,2049,5172,12557,10280,1056,8200,256,8492,13608,513]

theorem envBound49692 : H12AffineFastState.Bounded env49692 := by
  intro p hp
  have h : env49692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49691_49692 : H12AffineEnvironment.transform 14 292 env49691 = env49692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env49691 == env49692) = true)

theorem identity49692 : scanCanonicalize (H12AffineFastState.compose env49692 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound49692 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env49693 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,8192,12572,292,8494,4388,2048,273,293,4405,8200,308,8462,8192,17,2049,4389,12557,10280,305,8200,256,8492,12345,513]

theorem envBound49693 : H12AffineFastState.Bounded env49693 := by
  intro p hp
  have h : env49693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49692_49693 : H12AffineEnvironment.transform 9 273 env49692 = env49693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env49692 == env49693) = true)

theorem identity49693 : scanCanonicalize (H12AffineFastState.compose env49693 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49693 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49694 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,40,4404,292,262,4388,2048,273,293,4405,32,308,294,40,17,2049,4389,4389,2048,305,32,256,260,4113,513]

theorem envBound49694 : H12AffineFastState.Bounded env49694 := by
  intro p hp
  have h : env49694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49693_49694 : H12AffineEnvironment.transform 12 40 env49693 = env49694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49693 == env49694) = true)

theorem identity49694 : scanCanonicalize (H12AffineFastState.compose env49694 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49694 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env49695 : List Nat := [2,4,8,16,32,16,8,5,512,20,2048,4096,40,4145,33,3,4129,2048,20,32,4144,32,49,35,40,17,2049,4128,4128,2048,52,32,5,1,4113,513]

theorem envBound49695 : H12AffineFastState.Bounded env49695 := by
  intro p hp
  have h : env49695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49694_49695 : H12AffineEnvironment.transform 7 5 env49694 = env49695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49694 == env49695) = true)

theorem identity49695 : scanCanonicalize (H12AffineFastState.compose env49695 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49695 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env49696 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,4096,8,4113,1,3,4097,2048,20,0,4112,0,17,3,8,17,2049,4096,4096,2048,20,0,5,1,4113,513]

theorem envBound49696 : H12AffineFastState.Bounded env49696 := by
  intro p hp
  have h : env49696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49695_49696 : H12AffineEnvironment.transform 4 0 env49695 = env49696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49695 == env49696) = true)

theorem identity49696 : scanCanonicalize (H12AffineFastState.compose env49696 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2581) := by decide +kernel

theorem selectedBound49696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49697 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,2581,8,2564,1,3,2580,2048,20,0,2565,0,17,3,8,17,2049,2581,2581,2048,20,0,5,1,2564,513]

theorem envBound49697 : H12AffineFastState.Bounded env49697 := by
  intro p hp
  have h : env49697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49696_49697 : H12AffineEnvironment.transform 11 2581 env49696 = env49697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2581 env49696 == env49697) = true)

theorem identity49697 : scanCanonicalize (H12AffineFastState.compose env49697 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49698 : List Nat := [2,4,1,16,0,16,1,5,512,20,2048,2581,1,2564,1,3,2580,2048,20,0,2565,0,17,3,1,17,2049,2581,2581,2048,20,0,5,1,2564,513]

theorem envBound49698 : H12AffineFastState.Bounded env49698 := by
  intro p hp
  have h : env49698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49697_49698 : H12AffineEnvironment.transform 2 1 env49697 = env49698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49697 == env49698) = true)

theorem identity49698 : scanCanonicalize (H12AffineFastState.compose env49698 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound49698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49699 : List Nat := [2,4,1,16,0,16,1,5,512,20,516,17,1,0,1,3,16,516,20,0,1,0,17,3,1,17,517,17,17,516,20,0,5,1,0,513]

theorem envBound49699 : H12AffineFastState.Bounded env49699 := by
  intro p hp
  have h : env49699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49698_49699 : H12AffineEnvironment.transform 10 516 env49698 = env49699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env49698 == env49699) = true)

theorem identity49699 : scanCanonicalize (H12AffineFastState.compose env49699 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49699 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49700 : List Nat := [2,2,1,16,0,16,1,3,512,18,514,17,1,0,1,3,16,514,18,0,1,0,17,3,1,17,515,17,17,514,18,0,3,1,0,513]

theorem envBound49700 : H12AffineFastState.Bounded env49700 := by
  intro p hp
  have h : env49700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49699_49700 : H12AffineEnvironment.transform 1 2 env49699 = env49700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49699 == env49700) = true)

def env49701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456824,272393,452649,21763,8193,65,295284,458025,17664,10281,453996,144493,256,21793,46093,400996]

theorem envBound49701 : H12AffineFastState.Bounded env49701 := by
  intro p hp
  have h : env49701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49686_49701 : H12AffineEnvironment.transform 6 9 env49686 = env49701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49686 == env49701) = true)

theorem identity49701 : scanCanonicalize (H12AffineFastState.compose env49701 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound49701 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env49702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35189,1024,32769,160013,41340,155996,21763,8193,65,2049,160860,17664,10281,156697,144493,256,21793,46093,169745]

theorem envBound49702 : H12AffineFastState.Bounded env49702 := by
  intro p hp
  have h : env49702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49701_49702 : H12AffineEnvironment.transform 17 35189 env49701 = env49702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env49701 == env49702) = true)

theorem identity49702 : scanCanonicalize (H12AffineFastState.compose env49702 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound49702 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,35189,1024,32769,58397,41340,62540,21763,8193,65,2049,57676,17664,10281,61705,41341,256,21793,46093,513]

theorem envBound49703 : H12AffineFastState.Bounded env49703 := by
  intro p hp
  have h : env49703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49702_49703 : H12AffineEnvironment.transform 16 38160 env49702 = env49703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env49702 == env49703) = true)

theorem identity49703 : scanCanonicalize (H12AffineFastState.compose env49703 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49703 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24909,32040,1024,29788,4160,21793,17,21763,8193,65,2049,5393,17664,10281,1364,21792,256,21793,16464,513]

theorem envBound49704 : H12AffineFastState.Bounded env49704 := by
  intro p hp
  have h : env49704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49703_49704 : H12AffineEnvironment.transform 14 29789 env49703 = env49704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49703 == env49704) = true)

theorem identity49704 : scanCanonicalize (H12AffineFastState.compose env49704 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound49704 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,8203,5440,2341,1024,81,4160,8492,17,8462,8193,65,2049,5393,12557,10281,1364,8493,256,8492,13405,513]

theorem envBound49705 : H12AffineFastState.Bounded env49705 := by
  intro p hp
  have h : env49705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49704_49705 : H12AffineEnvironment.transform 13 13325 env49704 = env49705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env49704 == env49705) = true)

theorem identity49705 : scanCanonicalize (H12AffineFastState.compose env49705 (packedSelected [1,3,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound49705 : packedSelected [1,3,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env49706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,11341,80,8203,3328,2341,1024,81,2048,8492,17,8462,8193,65,2049,3409,10573,10281,1364,8493,256,8492,11293,513]

theorem envBound49706 : H12AffineFastState.Bounded env49706 := by
  intro p hp
  have h : env49706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49705_49706 : H12AffineEnvironment.transform 11 2112 env49705 = env49706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env49705 == env49706) = true)

theorem identity49706 : scanCanonicalize (H12AffineFastState.compose env49706 (packedSelected [4,6,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49706 : packedSelected [4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env49707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,269,3392,80,262,3328,2341,1024,81,2048,33,17,3,268,65,2049,3409,2112,2340,1364,32,256,33,3344,513]

theorem envBound49707 : H12AffineFastState.Bounded env49707 := by
  intro p hp
  have h : env49707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49706_49707 : H12AffineEnvironment.transform 12 269 env49706 = env49707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49706 == env49707) = true)

theorem identity49707 : scanCanonicalize (H12AffineFastState.compose env49707 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49707 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1077,1141,269,373,80,262,309,1296,1024,81,1077,33,17,3,268,65,1076,356,1141,1297,1364,32,256,33,293,513]

theorem envBound49708 : H12AffineFastState.Bounded env49708 := by
  intro p hp
  have h : env49708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49707_49708 : H12AffineEnvironment.transform 10 1077 env49707 = env49708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env49707 == env49708) = true)

theorem identity49708 : scanCanonicalize (H12AffineFastState.compose env49708 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49708 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49709 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,1060,269,292,1,262,309,1296,1024,0,1077,33,17,3,268,16,1076,309,1060,1297,1285,32,256,33,293,513]

theorem envBound49709 : H12AffineFastState.Bounded env49709 := by
  intro p hp
  have h : env49709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49708_49709 : H12AffineEnvironment.transform 5 17 env49708 = env49709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49708 == env49709) = true)

theorem identity49709 : scanCanonicalize (H12AffineFastState.compose env49709 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49710 : List Nat := [2,4,8,0,32,1,9,256,512,1024,1061,1060,269,292,1,262,293,1280,1024,0,1061,33,1,3,268,0,1060,293,1060,1281,1285,32,256,33,293,513]

theorem envBound49710 : H12AffineFastState.Bounded env49710 := by
  intro p hp
  have h : env49710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49709_49710 : H12AffineEnvironment.transform 3 0 env49709 = env49710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49709 == env49710) = true)

theorem identity49710 : scanCanonicalize (H12AffineFastState.compose env49710 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49710 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49711 : List Nat := [2,4,8,0,32,1,9,256,1,1024,1061,1060,269,292,1,262,293,1280,1024,0,1061,33,1,3,268,0,1060,293,1060,1281,1285,32,256,33,293,0]

theorem envBound49711 : H12AffineFastState.Bounded env49711 := by
  intro p hp
  have h : env49711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49710_49711 : H12AffineEnvironment.transform 8 1 env49710 = env49711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49710 == env49711) = true)

theorem identity49711 : scanCanonicalize (H12AffineFastState.compose env49711 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound49711 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49712 : List Nat := [2,4,8,0,32,1,9,256,1,36,1,0,269,292,1,262,293,292,36,0,1,33,1,3,268,0,0,293,0,293,289,32,256,33,293,0]

theorem envBound49712 : H12AffineFastState.Bounded env49712 := by
  intro p hp
  have h : env49712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49711_49712 : H12AffineEnvironment.transform 9 36 env49711 = env49712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env49711 == env49712) = true)

theorem identity49712 : scanCanonicalize (H12AffineFastState.compose env49712 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49712 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env49713 : List Nat := [2,4,8,0,32,1,9,37,1,36,1,0,40,1,1,35,0,1,36,0,1,33,1,3,41,0,0,0,0,0,4,32,37,33,0,0]

theorem envBound49713 : H12AffineFastState.Bounded env49713 := by
  intro p hp
  have h : env49713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49712_49713 : H12AffineEnvironment.transform 7 37 env49712 = env49713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49712 == env49713) = true)

theorem identity49713 : scanCanonicalize (H12AffineFastState.compose env49713 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49714 : List Nat := [2,4,2,0,32,1,3,37,1,36,1,0,34,1,1,35,0,1,36,0,1,33,1,3,35,0,0,0,0,0,4,32,37,33,0,0]

theorem envBound49714 : H12AffineFastState.Bounded env49714 := by
  intro p hp
  have h : env49714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49713_49714 : H12AffineEnvironment.transform 2 2 env49713 = env49714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49713 == env49714) = true)

def env49715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,98780,8328,65,295420,458144,17664,10400,453996,144492,256,21793,46212,510651]

theorem envBound49715 : H12AffineFastState.Bounded env49715 := by
  intro p hp
  have h : env49715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49684_49715 : H12AffineEnvironment.transform 21 272513 env49684 = env49715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49684 == env49715) = true)

theorem identity49715 : scanCanonicalize (H12AffineFastState.compose env49715 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound49715 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115870,201966,120015,98780,8328,65,245139,115151,17664,10400,119043,144492,256,21793,46212,63188]

theorem envBound49716 : H12AffineFastState.Bounded env49716 := by
  intro p hp
  have h : env49716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49715_49716 : H12AffineEnvironment.transform 17 212079 env49715 = env49716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env49715 == env49716) = true)

def env49717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115870,120062,120015,98780,8328,65,97667,115151,17664,10400,119043,62588,256,21793,46212,63188]

theorem envBound49717 : H12AffineFastState.Bounded env49717 := by
  intro p hp
  have h : env49717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49716_49717 : H12AffineEnvironment.transform 16 49168 env49716 = env49717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env49716 == env49717) = true)

theorem identity49717 : scanCanonicalize (H12AffineFastState.compose env49717 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49717 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env49718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,65536,49168,122226,1024,32769,115870,120062,120015,98780,389,65,89230,115151,17664,2477,119043,54641,256,21793,38281,55257]

theorem envBound49718 : H12AffineFastState.Bounded env49718 := by
  intro p hp
  have h : env49718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49717_49718 : H12AffineEnvironment.transform 12 269 env49717 = env49718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49717 == env49718) = true)

theorem identity49718 : scanCanonicalize (H12AffineFastState.compose env49718 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound49718 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env49719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,33110,49168,23588,1024,32769,17864,21928,21913,138,389,65,56792,16537,17664,2477,20565,54641,256,21793,38281,55257]

theorem envBound49719 : H12AffineFastState.Bounded env49719 := by
  intro p hp
  have h : env49719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49718_49719 : H12AffineEnvironment.transform 15 33110 env49718 = env49719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env49718 == env49719) = true)

theorem identity49719 : scanCanonicalize (H12AffineFastState.compose env49719 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound49719 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env49720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,216,398,16584,23588,1024,217,17864,21928,21913,138,389,65,23808,16537,17664,2477,20565,21929,256,21793,5457,22273]

theorem envBound49720 : H12AffineFastState.Bounded env49720 := by
  intro p hp
  have h : env49720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49719_49720 : H12AffineEnvironment.transform 14 216 env49719 = env49720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env49719 == env49720) = true)

theorem identity49720 : scanCanonicalize (H12AffineFastState.compose env49720 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound49720 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env49721 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,1,343,16401,23588,1024,0,17681,21873,21824,83,348,65,23808,16448,17664,2420,20565,21872,256,21793,5457,22273]

theorem envBound49721 : H12AffineFastState.Bounded env49721 := by
  intro p hp
  have h : env49721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49720_49721 : H12AffineEnvironment.transform 6 89 env49720 = env49721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env49720 == env49721) = true)

theorem identity49721 : scanCanonicalize (H12AffineFastState.compose env49721 (packedSelected [0,1,4,6,7,8,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound49721 : packedSelected [0,1,4,6,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env49722 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5409,1,343,5424,2309,1024,0,4144,80,97,83,348,65,2081,5473,4129,2420,1396,81,256,0,5457,544]

theorem envBound49722 : H12AffineFastState.Bounded env49722 := by
  intro p hp
  have h : env49722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49721_49722 : H12AffineEnvironment.transform 13 5409 env49721 = env49722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env49721 == env49722) = true)

theorem identity49722 : scanCanonicalize (H12AffineFastState.compose env49722 (packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49722 : packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49723 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5409,1,263,5424,2309,1024,0,4144,0,49,3,268,17,2081,5425,4129,2340,1316,1,256,0,5377,544]

theorem envBound49723 : H12AffineFastState.Bounded env49723 := by
  intro p hp
  have h : env49723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49722_49723 : H12AffineEnvironment.transform 5 16 env49722 = env49723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49722 == env49723) = true)

theorem identity49723 : scanCanonicalize (H12AffineFastState.compose env49723 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49723 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env49724 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,9,5157,1,3,5172,2049,1024,0,4144,0,49,3,8,17,2081,5173,4129,2080,1056,1,4,0,5125,544]

theorem envBound49724 : H12AffineFastState.Bounded env49724 := by
  intro p hp
  have h : env49724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49723_49724 : H12AffineEnvironment.transform 7 4 env49723 = env49724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49723 == env49724) = true)

theorem identity49724 : scanCanonicalize (H12AffineFastState.compose env49724 (packedSelected [2,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49724 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env49725 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,1,3,5141,2049,1024,0,4113,0,16,3,8,17,2048,5140,4096,2049,1025,1,4,0,5125,513]

theorem envBound49725 : H12AffineFastState.Bounded env49725 := by
  intro p hp
  have h : env49725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49724_49725 : H12AffineEnvironment.transform 4 1 env49724 = env49725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49724 == env49725) = true)

theorem identity49725 : scanCanonicalize (H12AffineFastState.compose env49725 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound49725 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49726 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,4096,9,5124,1,3,5141,523,1024,0,4113,0,16,3,8,17,522,5140,4096,523,1025,1,4,0,5125,513]

theorem envBound49726 : H12AffineFastState.Bounded env49726 := by
  intro p hp
  have h : env49726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49725_49726 : H12AffineEnvironment.transform 10 522 env49725 = env49726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env49725 == env49726) = true)

def env49727 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,16,9,1044,1,3,1029,523,1024,0,1,0,16,3,8,17,522,1028,16,523,1025,1,4,0,1045,513]

theorem envBound49727 : H12AffineFastState.Bounded env49727 := by
  intro p hp
  have h : env49727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49726_49727 : H12AffineEnvironment.transform 11 16 env49726 = env49727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49726 == env49727) = true)

theorem identity49727 : scanCanonicalize (H12AffineFastState.compose env49727 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound49727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49728 : List Nat := [2,4,8,5,1,5,9,4,512,1024,522,5,9,1025,1,3,1029,523,1024,0,1,0,5,3,8,4,522,1028,5,523,1025,1,4,0,1024,513]

theorem envBound49728 : H12AffineFastState.Bounded env49728 := by
  intro p hp
  have h : env49728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49727_49728 : H12AffineEnvironment.transform 3 5 env49727 = env49728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49727 == env49728) = true)

def env49729 : List Nat := [2,4,8,5,1,5,9,4,512,0,522,5,9,1,1,3,5,523,0,0,1,0,5,3,8,4,522,4,5,523,1,1,4,0,0,513]

theorem envBound49729 : H12AffineFastState.Bounded env49729 := by
  intro p hp
  have h : env49729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49728_49729 : H12AffineEnvironment.transform 9 0 env49728 = env49729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env49728 == env49729) = true)

theorem identity49729 : scanCanonicalize (H12AffineFastState.compose env49729 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound49729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49730 : List Nat := [2,4,8,5,1,5,9,4,8,0,2,5,9,1,1,3,5,3,0,0,1,0,5,3,8,4,2,4,5,3,1,1,4,0,0,9]

theorem envBound49730 : H12AffineFastState.Bounded env49730 := by
  intro p hp
  have h : env49730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49729_49730 : H12AffineEnvironment.transform 8 8 env49729 = env49730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env49729 == env49730) = true)

def leafEnv49730 : List Nat := [2,4,8,5,1,5,9,4,8,0,2,5,9,1,1,3,5,3,0,0,1,0,5,3,0,8,1,4,2,4,5,3,1,1,4,0,5,2,0,9,1,0,0]

def active49730 : List Nat := [0,1,2]

def tree49730 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49730 : H12WitnessSearch.Good tree49730 := H12GlobalWitnessIndex.good

theorem leafIdentity49730 : H12AffineFastState.composeSystem env49730 rootObs = leafEnv49730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49730 rootObs == leafEnv49730) = true)

theorem terminalChecked49730 : H12PackedTerminal.terminalCheckFast leafEnv49730 active49730 tree49730 = true := by decide +kernel

def env49731 : List Nat := [2,4,8,5,1,5,9,4,512,1,522,5,9,0,1,3,4,523,1,0,1,0,5,3,8,4,522,5,5,523,0,1,4,0,1,513]

theorem envBound49731 : H12AffineFastState.Bounded env49731 := by
  intro p hp
  have h : env49731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49728_49731 : H12AffineEnvironment.transform 9 1 env49728 = env49731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env49728 == env49731) = true)

theorem identity49731 : scanCanonicalize (H12AffineFastState.compose env49731 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49732 : List Nat := [1,4,8,5,1,5,9,4,512,1,521,5,9,0,1,0,4,520,1,0,1,0,5,0,8,4,521,5,5,520,0,1,4,0,1,513]

theorem envBound49732 : H12AffineFastState.Bounded env49732 := by
  intro p hp
  have h : env49732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49731_49732 : H12AffineEnvironment.transform 0 1 env49731 = env49732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49731 == env49732) = true)

def leafEnv49732 : List Nat := [1,4,8,5,1,5,9,4,512,1,521,5,9,0,1,0,4,520,1,0,1,0,5,0,1,8,1,4,521,5,5,520,0,1,4,0,5,1,1,513,1,0,0]

def active49732 : List Nat := [1,2,8]

def tree49732 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49732 : H12WitnessSearch.Good tree49732 := H12GlobalWitnessIndex.good

theorem leafIdentity49732 : H12AffineFastState.composeSystem env49732 rootObs = leafEnv49732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49732 rootObs == leafEnv49732) = true)

theorem terminalChecked49732 : H12PackedTerminal.terminalCheckFast leafEnv49732 active49732 tree49732 = true := by decide +kernel

def env49733 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,17,9,1045,1,3,1028,523,1024,0,0,0,16,3,8,17,522,1029,17,523,1025,1,4,0,1044,513]

theorem envBound49733 : H12AffineFastState.Bounded env49733 := by
  intro p hp
  have h : env49733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49726_49733 : H12AffineEnvironment.transform 11 17 env49726 = env49733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49726 == env49733) = true)

theorem identity49733 : scanCanonicalize (H12AffineFastState.compose env49733 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound49733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49734 : List Nat := [2,4,8,16,1,16,9,4,512,0,522,17,9,21,1,3,4,523,0,0,0,0,16,3,8,17,522,5,17,523,1,1,4,0,20,513]

theorem envBound49734 : H12AffineFastState.Bounded env49734 := by
  intro p hp
  have h : env49734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49733_49734 : H12AffineEnvironment.transform 9 0 env49733 = env49734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env49733 == env49734) = true)

def env49735 : List Nat := [2,4,8,4,1,4,9,4,512,0,522,5,9,1,1,3,4,523,0,0,0,0,4,3,8,5,522,5,5,523,1,1,4,0,0,513]

theorem envBound49735 : H12AffineFastState.Bounded env49735 := by
  intro p hp
  have h : env49735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49734_49735 : H12AffineEnvironment.transform 3 4 env49734 = env49735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env49734 == env49735) = true)

theorem identity49735 : scanCanonicalize (H12AffineFastState.compose env49735 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49736 : List Nat := [0,4,8,4,1,4,9,4,512,0,520,5,9,1,1,1,4,521,0,0,0,0,4,1,8,5,520,5,5,521,1,1,4,0,0,513]

theorem envBound49736 : H12AffineFastState.Bounded env49736 := by
  intro p hp
  have h : env49736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49735_49736 : H12AffineEnvironment.transform 0 0 env49735 = env49736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49735 == env49736) = true)

def leafEnv49736 : List Nat := [0,4,8,4,1,4,9,4,512,0,520,5,9,1,1,1,4,521,0,0,0,0,4,1,0,8,1,5,520,5,5,521,1,1,4,0,5,0,0,513,1,1,0]

def active49736 : List Nat := [1,2,8]

def tree49736 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49736 : H12WitnessSearch.Good tree49736 := H12GlobalWitnessIndex.good

theorem leafIdentity49736 : H12AffineFastState.composeSystem env49736 rootObs = leafEnv49736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49736 rootObs == leafEnv49736) = true)

theorem terminalChecked49736 : H12PackedTerminal.terminalCheckFast leafEnv49736 active49736 tree49736 = true := by decide +kernel

def env49737 : List Nat := [2,4,8,5,1,5,9,4,512,0,522,4,9,0,1,3,4,523,0,0,0,0,5,3,8,4,522,5,4,523,1,1,4,0,1,513]

theorem envBound49737 : H12AffineFastState.Bounded env49737 := by
  intro p hp
  have h : env49737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49734_49737 : H12AffineEnvironment.transform 3 5 env49734 = env49737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49734 == env49737) = true)

theorem identity49737 : scanCanonicalize (H12AffineFastState.compose env49737 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound49737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49738 : List Nat := [2,4,8,5,1,5,9,4,9,0,3,4,9,0,1,3,4,2,0,0,0,0,5,3,8,4,3,5,4,2,1,1,4,0,1,8]

theorem envBound49738 : H12AffineFastState.Bounded env49738 := by
  intro p hp
  have h : env49738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49737_49738 : H12AffineEnvironment.transform 8 9 env49737 = env49738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env49737 == env49738) = true)

def leafEnv49738 : List Nat := [2,4,8,5,1,5,9,4,9,0,3,4,9,0,1,3,4,2,0,0,0,0,5,3,0,8,1,4,3,5,4,2,1,1,4,0,5,2,1,8,1,1,0]

def active49738 : List Nat := [0,1,2]

def tree49738 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49738 : H12WitnessSearch.Good tree49738 := H12GlobalWitnessIndex.good

theorem leafIdentity49738 : H12AffineFastState.composeSystem env49738 rootObs = leafEnv49738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49738 rootObs == leafEnv49738) = true)

theorem terminalChecked49738 : H12PackedTerminal.terminalCheckFast leafEnv49738 active49738 tree49738 = true := by decide +kernel

def env49739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115870,120063,120015,98780,8328,65,97666,115151,17664,10400,119043,62589,256,21793,46212,63188]

theorem envBound49739 : H12AffineFastState.Bounded env49739 := by
  intro p hp
  have h : env49739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49716_49739 : H12AffineEnvironment.transform 16 49169 env49716 = env49739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env49716 == env49739) = true)

theorem identity49739 : scanCanonicalize (H12AffineFastState.compose env49739 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound49739 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env49740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,49169,32040,1024,32769,17864,21929,21913,138,8328,65,64724,16537,17664,10400,20565,62589,256,21793,46212,63188]

theorem envBound49740 : H12AffineFastState.Bounded env49740 := by
  intro p hp
  have h : env49740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49739_49740 : H12AffineEnvironment.transform 15 33110 env49739 = env49740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env49739 == env49740) = true)

theorem identity49740 : scanCanonicalize (H12AffineFastState.compose env49740 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49740 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env49741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,342,16401,32040,1024,1,17864,21929,21913,138,8328,65,31956,16537,17664,10400,20565,29821,256,21793,13444,30420]

theorem envBound49741 : H12AffineFastState.Bounded env49741 := by
  intro p hp
  have h : env49741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49740_49741 : H12AffineEnvironment.transform 14 0 env49740 = env49741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49740 == env49741) = true)

theorem identity49741 : scanCanonicalize (H12AffineFastState.compose env49741 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound49741 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env49742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,342,13509,2556,1024,1,12572,8573,8525,138,8328,65,2048,13389,12756,10400,9345,169,256,8693,13444,512]

theorem envBound49742 : H12AffineFastState.Bounded env49742 := by
  intro p hp
  have h : env49742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49741_49742 : H12AffineEnvironment.transform 13 13524 env49741 = env49742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env49741 == env49742) = true)

theorem identity49742 : scanCanonicalize (H12AffineFastState.compose env49742 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49742 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49743 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13524,0,342,13509,2525,1024,1,12572,8540,8525,138,8328,65,2048,13389,12756,10369,9345,136,256,8660,13444,512]

theorem envBound49743 : H12AffineFastState.Bounded env49743 := by
  intro p hp
  have h : env49743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49742_49743 : H12AffineEnvironment.transform 4 1 env49742 = env49743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49742 == env49743) = true)

theorem identity49743 : scanCanonicalize (H12AffineFastState.compose env49743 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound49743 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49744 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,8192,13524,0,2,13509,2185,1024,1,12360,8200,8217,138,8328,65,2048,13389,12416,10369,9345,136,84,8320,13444,512]

theorem envBound49744 : H12AffineFastState.Bounded env49744 := by
  intro p hp
  have h : env49744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49743_49744 : H12AffineEnvironment.transform 7 84 env49743 = env49744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env49743 == env49744) = true)

theorem identity49744 : scanCanonicalize (H12AffineFastState.compose env49744 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound49744 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49745 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,2201,8192,11341,0,2,11356,2185,1024,1,10449,8200,8217,138,8328,65,2048,11476,10265,10369,9345,136,84,8320,11293,512]

theorem envBound49745 : H12AffineFastState.Bounded env49745 := by
  intro p hp
  have h : env49745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49744_49745 : H12AffineEnvironment.transform 11 2201 env49744 = env49745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env49744 == env49745) = true)

theorem identity49745 : scanCanonicalize (H12AffineFastState.compose env49745 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49745 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env49746 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,2201,9,3140,0,2,3157,2185,1024,1,2264,1,16,138,129,65,2048,3293,2064,2184,1160,136,84,137,3092,512]

theorem envBound49746 : H12AffineFastState.Bounded env49746 := by
  intro p hp
  have h : env49746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49745_49746 : H12AffineEnvironment.transform 12 9 env49745 = env49746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49745 == env49746) = true)

theorem identity49746 : scanCanonicalize (H12AffineFastState.compose env49746 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound49746 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env49747 : List Nat := [2,4,8,16,1,64,128,84,512,1024,643,538,9,1735,0,2,1750,522,1024,1,603,1,16,138,129,65,643,1630,659,523,1160,136,84,137,1687,512]

theorem envBound49747 : H12AffineFastState.Bounded env49747 := by
  intro p hp
  have h : env49747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49746_49747 : H12AffineEnvironment.transform 10 643 env49746 = env49747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env49746 == env49747) = true)

theorem identity49747 : scanCanonicalize (H12AffineFastState.compose env49747 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound49747 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49748 : List Nat := [2,4,8,16,1,64,128,84,512,84,643,538,9,659,0,2,642,522,84,1,603,1,16,138,129,65,643,522,659,523,220,136,84,137,707,512]

theorem envBound49748 : H12AffineFastState.Bounded env49748 := by
  intro p hp
  have h : env49748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49747_49748 : H12AffineEnvironment.transform 9 84 env49747 = env49748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env49747 == env49748) = true)

theorem identity49748 : scanCanonicalize (H12AffineFastState.compose env49748 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49748 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env49749 : List Nat := [2,4,8,16,1,10,128,30,512,30,643,538,9,659,0,2,642,522,30,1,529,1,16,138,129,11,643,522,659,523,150,136,30,137,649,512]

theorem envBound49749 : H12AffineFastState.Bounded env49749 := by
  intro p hp
  have h : env49749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49748_49749 : H12AffineEnvironment.transform 5 10 env49748 = env49749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49748 == env49749) = true)

theorem identity49749 : scanCanonicalize (H12AffineFastState.compose env49749 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49749 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env49750 : List Nat := [2,4,8,16,1,10,9,30,512,30,522,538,9,538,0,2,523,522,30,1,529,1,16,3,8,11,522,522,538,523,31,1,30,0,512,512]

theorem envBound49750 : H12AffineFastState.Bounded env49750 := by
  intro p hp
  have h : env49750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49749_49750 : H12AffineEnvironment.transform 6 9 env49749 = env49750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49749 == env49750) = true)

theorem identity49750 : scanCanonicalize (H12AffineFastState.compose env49750 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound49750 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env49751 : List Nat := [2,4,8,16,1,10,9,30,9,30,3,19,9,19,0,2,2,3,30,1,24,1,16,3,8,11,3,3,19,2,31,1,30,0,9,9]

theorem envBound49751 : H12AffineFastState.Bounded env49751 := by
  intro p hp
  have h : env49751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49750_49751 : H12AffineEnvironment.transform 8 9 env49750 = env49751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env49750 == env49751) = true)

theorem identity49751 : scanCanonicalize (H12AffineFastState.compose env49751 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49751 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49752 : List Nat := [2,4,8,0,1,10,9,14,9,14,3,3,9,3,0,2,2,3,14,1,8,1,0,3,8,11,3,3,3,2,15,1,14,0,9,9]

theorem envBound49752 : H12AffineFastState.Bounded env49752 := by
  intro p hp
  have h : env49752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49751_49752 : H12AffineEnvironment.transform 3 0 env49751 = env49752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49751 == env49752) = true)

def env49753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,98781,8328,65,4237693,458145,17665,10401,453996,4594924,256,21793,46212,510651]

theorem envBound49753 : H12AffineFastState.Bounded env49753 := by
  intro p hp
  have h : env49753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49683_49753 : H12AffineEnvironment.transform 22 452769 env49683 = env49753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env49683 == env49753) = true)

def env49754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,98781,8328,65,295421,458145,17665,10401,453996,144492,256,21793,46212,510651]

theorem envBound49754 : H12AffineFastState.Bounded env49754 := by
  intro p hp
  have h : env49754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49753_49754 : H12AffineEnvironment.transform 21 272512 env49753 = env49754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49753 == env49754) = true)

theorem identity49754 : scanCanonicalize (H12AffineFastState.compose env49754 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49754 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456945,272512,452769,41430,8328,65,295421,458145,17665,10401,453996,144492,256,21793,46212,453296]

theorem envBound49755 : H12AffineFastState.Bounded env49755 := by
  intro p hp
  have h : env49755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49754_49755 : H12AffineEnvironment.transform 15 8203 env49754 = env49755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49754 == env49755) = true)

theorem identity49755 : scanCanonicalize (H12AffineFastState.compose env49755 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49755 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env49756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,131072,262144,1024,1,424177,272512,420001,8662,8328,65,262653,425377,17665,10401,421228,144492,256,21793,13444,420528]

theorem envBound49756 : H12AffineFastState.Bounded env49756 := by
  intro p hp
  have h : env49756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49755_49756 : H12AffineEnvironment.transform 14 0 env49755 = env49756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49755 == env49756) = true)

theorem identity49756 : scanCanonicalize (H12AffineFastState.compose env49756 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound49756 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,16400,262144,1024,1,276705,272512,272561,8662,8328,65,262653,277937,17665,10401,273788,29820,256,21793,13444,273056]

theorem envBound49757 : H12AffineFastState.Bounded env49757 := by
  intro p hp
  have h : env49757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49756_49757 : H12AffineEnvironment.transform 16 16400 env49756 = env49757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49756 == env49757) = true)

theorem identity49757 : scanCanonicalize (H12AffineFastState.compose env49757 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound49757 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,0,8203,5528,262144,1024,1,276705,272512,272561,8662,8328,65,262653,277937,4233,10401,273788,8692,256,169,13444,273056]

theorem envBound49758 : H12AffineFastState.Bounded env49758 := by
  intro p hp
  have h : env49758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49757_49758 : H12AffineEnvironment.transform 13 5512 env49757 = env49758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env49757 == env49758) = true)

theorem identity49758 : scanCanonicalize (H12AffineFastState.compose env49758 (packedSelected [1,2,3,4,5,6,8,9,12,17,23] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound49758 : packedSelected [1,2,3,4,5,6,8,9,12,17,23] rootPS < 2^1333 := by decide +kernel

def env49759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,8192,3124,0,8203,3108,262144,1024,1,270685,272512,272561,8662,8328,65,262653,271373,2357,10401,273788,8692,256,169,11576,273056]

theorem envBound49759 : H12AffineFastState.Bounded env49759 := by
  intro p hp
  have h : env49759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49758_49759 : H12AffineEnvironment.transform 11 2492 env49758 = env49759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env49758 == env49759) = true)

theorem identity49759 : scanCanonicalize (H12AffineFastState.compose env49759 (packedSelected [0,2,3,5,6,7,11,15,16,17,18,19] rootPS)) = affineNative (2^(17+1) ^^^ 8432) := by decide +kernel

theorem selectedBound49759 : packedSelected [0,2,3,5,6,7,11,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env49760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,8192,3124,0,8203,3108,8432,1024,1,429,2160,2113,8662,8328,65,8461,1277,2357,10401,3468,8692,256,169,11576,2640]

theorem envBound49760 : H12AffineFastState.Bounded env49760 := by
  intro p hp
  have h : env49760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49759_49760 : H12AffineEnvironment.transform 17 8432 env49759 = env49760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8432 env49759 == env49760) = true)

theorem identity49760 : scanCanonicalize (H12AffineFastState.compose env49760 (packedSelected [2,7,10,12,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound49760 : packedSelected [2,7,10,12,17,22] rootPS < 2^1333 := by decide +kernel

def env49761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,1156,3124,0,1167,3108,1140,1024,1,429,2160,2113,1362,1036,65,1417,1277,2357,3109,3468,1392,256,169,2492,2640]

theorem envBound49761 : H12AffineFastState.Bounded env49761 := by
  intro p hp
  have h : env49761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49760_49761 : H12AffineEnvironment.transform 12 1156 env49760 = env49761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env49760 == env49761) = true)

def env49762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,98781,8328,65,295420,458145,17665,10401,453996,144493,256,21793,46212,510651]

theorem envBound49762 : H12AffineFastState.Bounded env49762 := by
  intro p hp
  have h : env49762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49753_49762 : H12AffineEnvironment.transform 21 272513 env49753 = env49762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49753 == env49762) = true)

theorem identity49762 : scanCanonicalize (H12AffineFastState.compose env49762 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound49762 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,77899,254011,73755,98781,8328,65,215366,79131,17665,10401,75222,144493,256,21793,46212,513]

theorem envBound49763 : H12AffineFastState.Bounded env49763 := by
  intro p hp
  have h : env49763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49762_49763 : H12AffineEnvironment.transform 17 247994 env49762 = env49763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env49762 == env49763) = true)

def env49764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77899,254011,73755,98645,8192,65,215366,79131,17665,10281,75102,144493,256,21793,46092,513]

theorem envBound49764 : H12AffineFastState.Bounded env49764 := by
  intro p hp
  have h : env49764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49763_49764 : H12AffineEnvironment.transform 6 8 env49763 = env49764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49763 == env49764) = true)

theorem identity49764 : scanCanonicalize (H12AffineFastState.compose env49764 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49764 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,43048,1024,32769,77899,32801,73755,98645,8192,65,10588,79131,17665,10281,75102,87159,256,21793,46092,513]

theorem envBound49765 : H12AffineFastState.Bounded env49765 := by
  intro p hp
  have h : env49765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49764_49765 : H12AffineEnvironment.transform 16 90138 env49764 = env49765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49764 == env49765) = true)

theorem identity49765 : scanCanonicalize (H12AffineFastState.compose env49765 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound49765 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env49766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,46109,43048,1024,32769,58444,32801,62492,21842,8192,65,10588,57628,17665,10281,61785,32880,256,21793,46092,513]

theorem envBound49766 : H12AffineFastState.Bounded env49766 := by
  intro p hp
  have h : env49766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49765_49766 : H12AffineEnvironment.transform 15 54279 env49765 = env49766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env49765 == env49766) = true)

theorem identity49766 : scanCanonicalize (H12AffineFastState.compose env49766 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound49766 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env49767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,16384,32768,54279,37157,36112,1024,32769,49524,32801,53540,21842,1336,65,3172,50212,17665,3345,54369,32880,256,21793,37172,513]

theorem envBound49767 : H12AffineFastState.Bounded env49767 := by
  intro p hp
  have h : env49767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49766_49767 : H12AffineEnvironment.transform 12 1336 env49766 = env49767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env49766 == env49767) = true)

theorem identity49767 : scanCanonicalize (H12AffineFastState.compose env49767 (packedSelected [2,3,4,5,6,9,10,11,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound49767 : packedSelected [2,3,4,5,6,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env49768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,16384,21621,114,17744,22885,1024,21620,5377,21588,1361,21842,1336,65,3172,4177,17665,3345,20,21509,256,21793,17729,513]

theorem envBound49768 : H12AffineFastState.Bounded env49768 := by
  intro p hp
  have h : env49768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49767_49768 : H12AffineEnvironment.transform 14 21621 env49767 = env49768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env49767 == env49768) = true)

theorem identity49768 : scanCanonicalize (H12AffineFastState.compose env49768 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49768 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS < 2^1333 := by decide +kernel

def env49769 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,120,16384,20789,114,16400,22885,320,20788,4161,20756,17,20498,120,65,2340,4177,16449,2129,20,20805,256,20577,16385,513]

theorem envBound49769 : H12AffineFastState.Bounded env49769 := by
  intro p hp
  have h : env49769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49768_49769 : H12AffineEnvironment.transform 9 320 env49768 = env49769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49768 == env49769) = true)

theorem identity49769 : scanCanonicalize (H12AffineFastState.compose env49769 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound49769 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env49770 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,120,4453,80,114,4469,2048,320,81,4161,113,17,375,120,65,2340,4177,4388,2129,20,32,256,260,4452,513]

theorem envBound49770 : H12AffineFastState.Bounded env49770 := by
  intro p hp
  have h : env49770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49769_49770 : H12AffineEnvironment.transform 13 4453 env49769 = env49770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env49769 == env49770) = true)

theorem identity49770 : scanCanonicalize (H12AffineFastState.compose env49770 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49770 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49771 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,40,4405,0,34,4389,2048,272,1,4113,33,17,295,40,17,2340,4097,4388,2049,20,32,256,260,4404,513]

theorem envBound49771 : H12AffineFastState.Bounded env49771 := by
  intro p hp
  have h : env49771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49770_49771 : H12AffineEnvironment.transform 5 16 env49770 = env49771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49770 == env49771) = true)

theorem identity49771 : scanCanonicalize (H12AffineFastState.compose env49771 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49771 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49772 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,40,4113,0,34,4097,2048,52,1,4113,33,17,3,40,17,2048,4097,4096,2049,20,32,36,32,4112,513]

theorem envBound49772 : H12AffineFastState.Bounded env49772 := by
  intro p hp
  have h : env49772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49771_49772 : H12AffineEnvironment.transform 7 36 env49771 = env49772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49771 == env49772) = true)

theorem identity49772 : scanCanonicalize (H12AffineFastState.compose env49772 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49772 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49773 : List Nat := [2,4,8,16,16,16,8,20,512,4,2048,4096,24,4113,0,18,4097,2048,4,1,4113,17,17,3,24,17,2048,4097,4096,2049,20,16,20,16,4112,513]

theorem envBound49773 : H12AffineFastState.Bounded env49773 := by
  intro p hp
  have h : env49773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49772_49773 : H12AffineEnvironment.transform 4 16 env49772 = env49773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49772 == env49773) = true)

theorem identity49773 : scanCanonicalize (H12AffineFastState.compose env49773 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound49773 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49774 : List Nat := [2,4,8,16,16,16,8,20,512,4,529,4096,24,4113,0,18,4097,529,4,1,4113,17,17,3,24,17,529,4097,4096,528,20,16,20,16,4112,513]

theorem envBound49774 : H12AffineFastState.Bounded env49774 := by
  intro p hp
  have h : env49774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49773_49774 : H12AffineEnvironment.transform 10 529 env49773 = env49774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env49773 == env49774) = true)

theorem identity49774 : scanCanonicalize (H12AffineFastState.compose env49774 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound49774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49775 : List Nat := [2,4,8,16,16,16,8,20,512,4,529,17,24,0,0,18,16,529,4,1,0,17,17,3,24,17,529,16,17,528,20,16,20,16,1,513]

theorem envBound49775 : H12AffineFastState.Bounded env49775 := by
  intro p hp
  have h : env49775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49774_49775 : H12AffineEnvironment.transform 11 17 env49774 = env49775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49774 == env49775) = true)

theorem identity49775 : scanCanonicalize (H12AffineFastState.compose env49775 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound49775 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49776 : List Nat := [2,4,8,16,16,16,8,20,17,4,0,17,24,0,0,18,16,0,4,1,0,17,17,3,24,17,0,16,17,1,20,16,20,16,1,16]

theorem envBound49776 : H12AffineFastState.Bounded env49776 := by
  intro p hp
  have h : env49776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49775_49776 : H12AffineEnvironment.transform 8 17 env49775 = env49776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env49775 == env49776) = true)

def env49777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77899,254011,73755,98644,8193,65,215366,79131,17665,10280,75103,144493,256,21793,46093,513]

theorem envBound49777 : H12AffineFastState.Bounded env49777 := by
  intro p hp
  have h : env49777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49763_49777 : H12AffineEnvironment.transform 6 9 env49763 = env49777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49763 == env49777) = true)

theorem identity49777 : scanCanonicalize (H12AffineFastState.compose env49777 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound49777 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env49778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,77899,33,73755,98644,8193,65,43356,79131,17665,10280,75103,119927,256,21793,46093,513]

theorem envBound49778 : H12AffineFastState.Bounded env49778 := by
  intro p hp
  have h : env49778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49777_49778 : H12AffineEnvironment.transform 16 122906 env49777 = env49778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env49777 == env49778) = true)

theorem identity49778 : scanCanonicalize (H12AffineFastState.compose env49778 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49778 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env49779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1024,32769,4160,33,16,41311,8193,65,43356,5392,17665,10280,1364,62588,256,21793,46093,513]

theorem envBound49779 : H12AffineFastState.Bounded env49779 := by
  intro p hp
  have h : env49779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49778_49779 : H12AffineEnvironment.transform 15 8203 env49778 = env49779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49778 == env49779) = true)

theorem identity49779 : scanCanonicalize (H12AffineFastState.compose env49779 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49779 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49169,2340,1024,32769,4160,33,16,32850,268,65,34897,5392,17665,2341,1364,54641,256,21793,38144,513]

theorem envBound49780 : H12AffineFastState.Bounded env49780 := by
  intro p hp
  have h : env49780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49779_49780 : H12AffineEnvironment.transform 12 269 env49779 = env49780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49779 == env49780) = true)

theorem identity49780 : scanCanonicalize (H12AffineFastState.compose env49780 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49780 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,262,16401,2340,1024,1,4160,33,16,82,268,65,2129,5392,17665,2341,1364,21873,256,21793,5376,513]

theorem envBound49781 : H12AffineFastState.Bounded env49781 := by
  intro p hp
  have h : env49781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49780_49781 : H12AffineEnvironment.transform 14 0 env49780 = env49781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49780 == env49781) = true)

theorem identity49781 : scanCanonicalize (H12AffineFastState.compose env49781 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49781 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49782 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,262,16401,2340,1024,1,4112,33,16,2,268,17,2049,5392,17665,2341,1284,21793,256,21793,5376,513]

theorem envBound49782 : H12AffineFastState.Bounded env49782 := by
  intro p hp
  have h : env49782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49781_49782 : H12AffineEnvironment.transform 5 16 env49781 = env49782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49781 == env49782) = true)

theorem identity49782 : scanCanonicalize (H12AffineFastState.compose env49782 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49782 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49783 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,16384,0,262,16401,2340,272,1,4112,33,16,2,268,17,2049,4096,16401,2341,20,20529,256,20529,4112,513]

theorem envBound49783 : H12AffineFastState.Bounded env49783 := by
  intro p hp
  have h : env49783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49782_49783 : H12AffineEnvironment.transform 9 272 env49782 = env49783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49782 == env49783) = true)

theorem identity49783 : scanCanonicalize (H12AffineFastState.compose env49783 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound49783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49784 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,33,0,262,48,2340,272,1,4112,33,16,2,268,17,2049,4096,48,2341,20,4112,256,4112,4112,513]

theorem envBound49784 : H12AffineFastState.Bounded env49784 := by
  intro p hp
  have h : env49784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49783_49784 : H12AffineEnvironment.transform 13 33 env49783 = env49784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env49783 == env49784) = true)

theorem identity49784 : scanCanonicalize (H12AffineFastState.compose env49784 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49784 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49785 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,4096,269,33,0,262,48,293,272,1,4112,33,16,2,268,17,0,4096,48,292,20,4112,256,4112,4112,513]

theorem envBound49785 : H12AffineFastState.Bounded env49785 := by
  intro p hp
  have h : env49785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49784_49785 : H12AffineEnvironment.transform 10 1 env49784 = env49785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49784 == env49785) = true)

theorem identity49785 : scanCanonicalize (H12AffineFastState.compose env49785 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound49785 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49786 : List Nat := [2,4,8,16,32,16,9,53,512,37,1,4096,56,33,0,51,48,16,37,1,4112,33,16,2,57,17,0,4096,48,17,20,4112,53,4112,4112,513]

theorem envBound49786 : H12AffineFastState.Bounded env49786 := by
  intro p hp
  have h : env49786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49785_49786 : H12AffineEnvironment.transform 7 53 env49785 = env49786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env49785 == env49786) = true)

theorem identity49786 : scanCanonicalize (H12AffineFastState.compose env49786 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49786 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env49787 : List Nat := [2,4,8,16,17,16,9,4,512,20,1,4096,9,16,0,2,1,16,20,1,4112,16,16,2,8,17,0,4096,1,17,20,4112,4,4112,4112,513]

theorem envBound49787 : H12AffineFastState.Bounded env49787 := by
  intro p hp
  have h : env49787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49786_49787 : H12AffineEnvironment.transform 4 17 env49786 = env49787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49786 == env49787) = true)

theorem identity49787 : scanCanonicalize (H12AffineFastState.compose env49787 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound49787 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49788 : List Nat := [2,4,8,16,17,16,9,4,17,20,1,4096,9,16,0,2,1,16,20,1,4112,16,16,2,8,17,0,4096,1,17,20,4112,4,4112,4112,16]

theorem envBound49788 : H12AffineFastState.Bounded env49788 := by
  intro p hp
  have h : env49788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49787_49788 : H12AffineEnvironment.transform 8 17 env49787 = env49788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env49787 == env49788) = true)

theorem identity49788 : scanCanonicalize (H12AffineFastState.compose env49788 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound49788 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env49789 : List Nat := [2,4,8,16,17,16,9,4,17,20,1,1,9,16,0,2,1,16,20,1,17,16,16,2,8,17,0,1,1,17,20,17,4,17,17,16]

theorem envBound49789 : H12AffineFastState.Bounded env49789 := by
  intro p hp
  have h : env49789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49788_49789 : H12AffineEnvironment.transform 11 1 env49788 = env49789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49788 == env49789) = true)

theorem identity49789 : scanCanonicalize (H12AffineFastState.compose env49789 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49790 : List Nat := [2,4,8,0,1,0,9,4,1,4,1,1,9,0,0,2,1,0,4,1,1,0,0,2,8,1,0,1,1,1,4,1,4,1,1,0]

theorem envBound49790 : H12AffineFastState.Bounded env49790 := by
  intro p hp
  have h : env49790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49789_49790 : H12AffineEnvironment.transform 3 0 env49789 = env49790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49789 == env49790) = true)

def env49791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound49791 : H12AffineFastState.Bounded env49791 := by
  intro p hp
  have h : env49791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49577_49791 : H12AffineEnvironment.transform 18 1025 env49577 = env49791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env49577 == env49791) = true)

theorem identity49791 : scanCanonicalize (H12AffineFastState.compose env49791 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound49791 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35325,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575677,18973836,10507601,8538620,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound49792 : H12AffineFastState.Bounded env49792 := by
  intro p hp
  have h : env49792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49791_49792 : H12AffineEnvironment.transform 17 35325 env49791 = env49792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env49791 == env49792) = true)

def env49793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575541,18973700,10507601,8538484,25265168,23160136,257,27378725,27337993,25207630]

theorem envBound49793 : H12AffineFastState.Bounded env49793 := by
  intro p hp
  have h : env49793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49792_49793 : H12AffineEnvironment.transform 6 8 env49792 = env49793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49792 == env49793) = true)

def env49794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,16777216,8192,65,21039477,18973700,2233681,2420,17024016,23160136,257,19104805,19096841,16966478]

theorem envBound49794 : H12AffineFastState.Bounded env49794 := by
  intro p hp
  have h : env49794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49793_49794 : H12AffineEnvironment.transform 22 147456 env49793 = env49794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env49793 == env49794) = true)

theorem identity49794 : scanCanonicalize (H12AffineFastState.compose env49794 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound49794 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,188751,8192,65,4450362,2319691,2233681,2420,75103,6521863,257,2188650,2196550,513]

theorem envBound49795 : H12AffineFastState.Bounded env49795 := by
  intro p hp
  have h : env49795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49794_49795 : H12AffineEnvironment.transform 23 188751 env49794 = env49795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env49794 == env49795) = true)

def env49796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302890,2172251,2118977,2420,75103,6407191,257,2188650,2196550,513]

theorem envBound49796 : H12AffineFastState.Bounded env49796 := by
  intro p hp
  have h : env49796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49795_49796 : H12AffineEnvironment.transform 16 16400 env49795 = env49796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49795 == env49796) = true)

theorem identity49796 : scanCanonicalize (H12AffineFastState.compose env49796 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49796 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229152,2098513,2118977,2420,1365,6349853,257,2114912,2139212,513]

theorem envBound49797 : H12AffineFastState.Bounded env49797 := by
  intro p hp
  have h : env49797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49796_49797 : H12AffineEnvironment.transform 15 8202 env49796 = env49797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49796 == env49797) = true)

theorem identity49797 : scanCanonicalize (H12AffineFastState.compose env49797 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound49797 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,2097152,32,16,41311,8192,65,34816,2098513,2118977,2420,1365,2155581,257,2114912,2139212,513]

theorem envBound49798 : H12AffineFastState.Bounded env49798 := by
  intro p hp
  have h : env49798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49797_49798 : H12AffineEnvironment.transform 21 32 env49797 = env49798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env49797 == env49798) = true)

theorem identity49798 : scanCanonicalize (H12AffineFastState.compose env49798 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49798 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1025,8541,2097152,32,16,3,8192,65,10588,2098513,2118977,2420,1365,2114913,257,2114912,2098448,513]

theorem envBound49799 : H12AffineFastState.Bounded env49799 := by
  intro p hp
  have h : env49799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49798_49799 : H12AffineEnvironment.transform 14 8540 env49798 = env49799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49798 == env49799) = true)

theorem identity49799 : scanCanonicalize (H12AffineFastState.compose env49799 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49799 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1025,8541,25676,32,16,3,8192,65,10588,24861,12557,2420,1365,8493,257,8492,24924,513]

theorem envBound49800 : H12AffineFastState.Bounded env49800 := by
  intro p hp
  have h : env49800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49799_49800 : H12AffineEnvironment.transform 20 25676 env49799 = env49800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env49799 == env49800) = true)

theorem identity49800 : scanCanonicalize (H12AffineFastState.compose env49800 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49800 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5392,10281,1025,8541,12620,32,16,3,8192,65,10588,13341,12557,2420,1365,8493,257,8492,13404,513]

theorem envBound49801 : H12AffineFastState.Bounded env49801 := by
  intro p hp
  have h : env49801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49800_49801 : H12AffineEnvironment.transform 13 5376 env49800 = env49801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49800 == env49801) = true)

theorem identity49801 : scanCanonicalize (H12AffineFastState.compose env49801 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49801 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,262,5392,2341,1025,81,4160,32,16,3,268,65,2128,5393,4097,2420,1365,33,257,32,5456,513]

theorem envBound49802 : H12AffineFastState.Bounded env49802 := by
  intro p hp
  have h : env49802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49801_49802 : H12AffineEnvironment.transform 12 268 env49801 = env49802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49801 == env49802) = true)

theorem identity49802 : scanCanonicalize (H12AffineFastState.compose env49802 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49802 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49803 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4453,80,262,4469,2341,100,81,4160,32,16,3,268,65,2128,4468,4097,2420,304,33,257,32,4405,513]

theorem envBound49803 : H12AffineFastState.Bounded env49803 := by
  intro p hp
  have h : env49803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49802_49803 : H12AffineEnvironment.transform 9 101 env49802 = env49803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49802 == env49803) = true)

theorem identity49803 : scanCanonicalize (H12AffineFastState.compose env49803 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound49803 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env49804 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,268,2421,80,262,2405,2341,100,81,2128,32,16,3,268,65,2128,2404,2065,2420,304,33,257,32,2341,513]

theorem envBound49804 : H12AffineFastState.Bounded env49804 := by
  intro p hp
  have h : env49804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49803_49804 : H12AffineEnvironment.transform 11 2064 env49803 = env49804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env49803 == env49804) = true)

theorem identity49804 : scanCanonicalize (H12AffineFastState.compose env49804 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49804 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49805 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2064,268,2341,0,262,2357,2341,52,1,2048,32,16,3,268,17,2048,2356,2065,2340,304,33,257,32,2341,513]

theorem envBound49805 : H12AffineFastState.Bounded env49805 := by
  intro p hp
  have h : env49805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49804_49805 : H12AffineEnvironment.transform 5 16 env49804 = env49805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49804 == env49805) = true)

theorem identity49805 : scanCanonicalize (H12AffineFastState.compose env49805 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound49805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49806 : List Nat := [2,4,8,16,32,16,8,256,512,53,0,16,268,293,0,262,309,293,52,1,0,32,16,3,268,17,0,308,17,292,304,33,257,32,293,513]

theorem envBound49806 : H12AffineFastState.Bounded env49806 := by
  intro p hp
  have h : env49806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49805_49806 : H12AffineEnvironment.transform 10 0 env49805 = env49806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env49805 == env49806) = true)

def env49807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41310,8192,65,4302891,2172250,2118976,2420,75103,6407190,257,2188650,2196550,513]

theorem envBound49807 : H12AffineFastState.Bounded env49807 := by
  intro p hp
  have h : env49807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49795_49807 : H12AffineEnvironment.transform 16 16401 env49795 = env49807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49795 == env49807) = true)

theorem identity49807 : scanCanonicalize (H12AffineFastState.compose env49807 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound49807 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115734,4194304,17,41310,8192,65,4302891,57676,102742,2420,75103,4194304,257,41340,16464,513]

theorem envBound49808 : H12AffineFastState.Bounded env49808 := by
  intro p hp
  have h : env49808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49807_49808 : H12AffineEnvironment.transform 20 115734 env49807 = env49808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env49807 == env49808) = true)

def env49809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91198,4194304,17,374,8192,65,4261891,16740,78206,2420,75103,4194304,257,340,16464,513]

theorem envBound49809 : H12AffineFastState.Bounded env49809 := by
  intro p hp
  have h : env49809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49808_49809 : H12AffineEnvironment.transform 14 8232 env49808 = env49809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env49808 == env49809) = true)

theorem identity49809 : scanCanonicalize (H12AffineFastState.compose env49809 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound49809 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env49810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91198,8200,17,374,8192,65,75787,16740,78206,2420,75103,8200,257,340,16464,513]

theorem envBound49810 : H12AffineFastState.Bounded env49810 := by
  intro p hp
  have h : env49810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49809_49810 : H12AffineEnvironment.transform 21 8200 env49809 = env49810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env49809 == env49810) = true)

theorem identity49810 : scanCanonicalize (H12AffineFastState.compose env49810 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49810 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env49811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,34,16401,10589,1025,8233,25628,8200,17,374,8192,65,10281,16740,12636,2420,9597,8200,257,340,16464,513]

theorem envBound49811 : H12AffineFastState.Bounded env49811 := by
  intro p hp
  have h : env49811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49810_49811 : H12AffineEnvironment.transform 15 34 env49810 = env49811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49810 == env49811) = true)

theorem identity49811 : scanCanonicalize (H12AffineFastState.compose env49811 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49811 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,1,34,16401,2420,1025,0,17461,33,17,374,41,65,2048,16740,4469,2420,1364,33,257,340,16464,513]

theorem envBound49812 : H12AffineFastState.Bounded env49812 := by
  intro p hp
  have h : env49812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49811_49812 : H12AffineEnvironment.transform 12 41 env49811 = env49812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49811 == env49812) = true)

theorem identity49812 : scanCanonicalize (H12AffineFastState.compose env49812 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,1,34,5392,2420,1025,0,4404,33,17,374,41,65,2048,5221,4469,2420,1364,33,257,340,5457,513]

theorem envBound49813 : H12AffineFastState.Bounded env49813 := by
  intro p hp
  have h : env49813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49812_49813 : H12AffineEnvironment.transform 13 5377 env49812 = env49813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49812 == env49813) = true)

theorem identity49813 : scanCanonicalize (H12AffineFastState.compose env49813 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49813 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49814 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5157,1,34,5172,2128,1025,0,4112,33,17,82,41,65,2048,5221,4177,2128,1136,33,37,112,5237,513]

theorem envBound49814 : H12AffineFastState.Bounded env49814 := by
  intro p hp
  have h : env49814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49813_49814 : H12AffineEnvironment.transform 7 36 env49813 = env49814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49813 == env49814) = true)

theorem identity49814 : scanCanonicalize (H12AffineFastState.compose env49814 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49814 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49815 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,34,5172,2048,1025,0,4112,33,17,2,41,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound49815 : H12AffineFastState.Bounded env49815 := by
  intro p hp
  have h : env49815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49814_49815 : H12AffineEnvironment.transform 5 16 env49814 = env49815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49814 == env49815) = true)

def env49816 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,1,34,1028,2048,1025,0,32,33,17,2,41,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound49816 : H12AffineFastState.Bounded env49816 := by
  intro p hp
  have h : env49816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49815_49816 : H12AffineEnvironment.transform 11 48 env49815 = env49816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49815 == env49816) = true)

theorem identity49816 : scanCanonicalize (H12AffineFastState.compose env49816 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound49816 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49817 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1045,48,41,1045,1,34,1028,1045,1025,0,32,33,17,2,41,17,1045,1029,49,1045,1056,33,37,32,1045,513]

theorem envBound49817 : H12AffineFastState.Bounded env49817 := by
  intro p hp
  have h : env49817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49816_49817 : H12AffineEnvironment.transform 10 1045 env49816 = env49817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env49816 == env49817) = true)

def env49818 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,48,41,33,1,34,48,33,53,0,32,33,17,2,41,17,33,49,49,33,20,33,37,32,33,513]

theorem envBound49818 : H12AffineFastState.Bounded env49818 := by
  intro p hp
  have h : env49818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49817_49818 : H12AffineEnvironment.transform 9 52 env49817 = env49818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49817 == env49818) = true)

def env49819 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,48,41,32,1,34,49,32,52,0,32,33,17,2,41,17,32,48,49,32,21,33,37,32,32,513]

theorem envBound49819 : H12AffineFastState.Bounded env49819 := by
  intro p hp
  have h : env49819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49817_49819 : H12AffineEnvironment.transform 9 53 env49817 = env49819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49817 == env49819) = true)

theorem identity49819 : scanCanonicalize (H12AffineFastState.compose env49819 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49820 : List Nat := [2,4,8,16,32,16,8,36,43,53,32,48,41,32,1,34,49,32,52,0,32,33,17,2,41,17,32,48,49,32,21,33,37,32,32,42]

theorem envBound49820 : H12AffineFastState.Bounded env49820 := by
  intro p hp
  have h : env49820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49819_49820 : H12AffineEnvironment.transform 8 43 env49819 = env49820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49819 == env49820) = true)

def leafEnv49820 : List Nat := [2,4,8,16,32,16,8,36,43,53,32,48,41,32,1,34,49,32,52,0,32,33,17,2,20,41,1,17,32,48,49,32,21,33,37,32,5,34,32,42,1,32,0]

def active49820 : List Nat := [0,1,2,3,4]

def tree49820 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49820 : H12WitnessSearch.Good tree49820 := H12GlobalWitnessIndex.good

theorem leafIdentity49820 : H12AffineFastState.composeSystem env49820 rootObs = leafEnv49820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49820 rootObs == leafEnv49820) = true)

theorem terminalChecked49820 : H12PackedTerminal.terminalCheckFast leafEnv49820 active49820 tree49820 = true := by decide +kernel

def env49821 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,1,34,1029,2048,1025,0,33,33,17,2,41,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound49821 : H12AffineFastState.Bounded env49821 := by
  intro p hp
  have h : env49821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49815_49821 : H12AffineEnvironment.transform 11 49 env49815 = env49821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49815 == env49821) = true)

theorem identity49821 : scanCanonicalize (H12AffineFastState.compose env49821 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49822 : List Nat := [2,4,8,16,32,16,8,36,512,1024,33,49,41,1044,1,34,1029,33,1025,0,33,33,17,2,41,17,33,1028,48,33,1056,33,37,32,1044,513]

theorem envBound49822 : H12AffineFastState.Bounded env49822 := by
  intro p hp
  have h : env49822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49821_49822 : H12AffineEnvironment.transform 10 33 env49821 = env49822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49821 == env49822) = true)

def env49823 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,49,41,32,1,34,49,33,53,0,33,33,17,2,41,17,33,48,48,33,20,33,37,32,32,513]

theorem envBound49823 : H12AffineFastState.Bounded env49823 := by
  intro p hp
  have h : env49823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49822_49823 : H12AffineEnvironment.transform 9 52 env49822 = env49823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49822 == env49823) = true)

def env49824 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,49,41,33,1,34,48,33,52,0,33,33,17,2,41,17,33,49,48,33,21,33,37,32,33,513]

theorem envBound49824 : H12AffineFastState.Bounded env49824 := by
  intro p hp
  have h : env49824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49822_49824 : H12AffineEnvironment.transform 9 53 env49822 = env49824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49822 == env49824) = true)

theorem identity49824 : scanCanonicalize (H12AffineFastState.compose env49824 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49825 : List Nat := [2,4,8,16,32,16,8,36,42,53,33,49,41,33,1,34,48,33,52,0,33,33,17,2,41,17,33,49,48,33,21,33,37,32,33,43]

theorem envBound49825 : H12AffineFastState.Bounded env49825 := by
  intro p hp
  have h : env49825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49824_49825 : H12AffineEnvironment.transform 8 42 env49824 = env49825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49824 == env49825) = true)

def leafEnv49825 : List Nat := [2,4,8,16,32,16,8,36,42,53,33,49,41,33,1,34,48,33,52,0,33,33,17,2,20,41,1,17,33,49,48,33,21,33,37,32,5,34,33,43,1,33,0]

def active49825 : List Nat := [0,1,2,3,4]

def tree49825 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49825 : H12WitnessSearch.Good tree49825 := H12GlobalWitnessIndex.good

theorem leafIdentity49825 : H12AffineFastState.composeSystem env49825 rootObs = leafEnv49825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49825 rootObs == leafEnv49825) = true)

theorem terminalChecked49825 : H12PackedTerminal.terminalCheckFast leafEnv49825 active49825 tree49825 = true := by decide +kernel

def env49826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91199,4194304,17,375,8192,65,4261890,16741,78207,2420,75103,4194304,257,341,16464,513]

theorem envBound49826 : H12AffineFastState.Bounded env49826 := by
  intro p hp
  have h : env49826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49808_49826 : H12AffineEnvironment.transform 14 8233 env49808 = env49826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env49808 == env49826) = true)

theorem identity49826 : scanCanonicalize (H12AffineFastState.compose env49826 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound49826 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env49827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91199,8572,17,375,8192,65,76158,16741,78207,2420,75103,8572,257,341,16464,513]

theorem envBound49827 : H12AffineFastState.Bounded env49827 := by
  intro p hp
  have h : env49827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49826_49827 : H12AffineEnvironment.transform 21 8572 env49826 = env49827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env49826 == env49827) = true)

theorem identity49827 : scanCanonicalize (H12AffineFastState.compose env49827 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound49827 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env49828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,342,16401,10588,1025,8232,25961,8572,17,375,8192,65,10280,16741,12329,2420,9225,8572,257,341,16464,513]

theorem envBound49828 : H12AffineFastState.Bounded env49828 := by
  intro p hp
  have h : env49828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49827_49828 : H12AffineEnvironment.transform 15 342 env49827 = env49828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env49827 == env49828) = true)

theorem identity49828 : scanCanonicalize (H12AffineFastState.compose env49828 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49828 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,1,342,16401,2420,1025,0,17729,340,17,375,40,65,2048,16741,4097,2420,1057,340,257,341,16464,513]

theorem envBound49829 : H12AffineFastState.Bounded env49829 := by
  intro p hp
  have h : env49829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49828_49829 : H12AffineEnvironment.transform 12 40 env49828 = env49829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49828 == env49829) = true)

theorem identity49829 : scanCanonicalize (H12AffineFastState.compose env49829 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49829 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49830 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,16384,1,262,16401,2340,1025,0,17681,260,17,295,40,17,2048,16693,4097,2340,1057,260,257,261,16384,513]

theorem envBound49830 : H12AffineFastState.Bounded env49830 := by
  intro p hp
  have h : env49830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49829_49830 : H12AffineEnvironment.transform 5 16 env49829 = env49830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49829 == env49830) = true)

theorem identity49830 : scanCanonicalize (H12AffineFastState.compose env49830 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound49830 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49831 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5157,1,262,5172,2340,1025,0,4404,260,17,295,40,17,2048,5392,4097,2340,1057,260,257,261,5157,513]

theorem envBound49831 : H12AffineFastState.Bounded env49831 := by
  intro p hp
  have h : env49831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49830_49831 : H12AffineEnvironment.transform 13 5157 env49830 = env49831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env49830 == env49831) = true)

theorem identity49831 : scanCanonicalize (H12AffineFastState.compose env49831 (packedSelected [1,3,4,5,8,9,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49831 : packedSelected [1,3,4,5,8,9,15] rootPS < 2^1333 := by decide +kernel

def env49832 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,1,35,5172,2049,1025,0,4113,33,17,2,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound49832 : H12AffineFastState.Bounded env49832 := by
  intro p hp
  have h : env49832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49831_49832 : H12AffineEnvironment.transform 7 37 env49831 = env49832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49831 == env49832) = true)

def env49833 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1045,1,35,1028,2049,1025,0,33,33,17,2,40,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound49833 : H12AffineFastState.Bounded env49833 := by
  intro p hp
  have h : env49833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49832_49833 : H12AffineEnvironment.transform 11 48 env49832 = env49833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49832 == env49833) = true)

theorem identity49833 : scanCanonicalize (H12AffineFastState.compose env49833 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound49833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49834 : List Nat := [2,4,8,16,32,16,8,37,48,1024,2048,48,40,1045,1,35,1028,2049,1025,0,33,33,17,2,40,17,2048,1029,49,2049,1057,33,36,32,1045,49]

theorem envBound49834 : H12AffineFastState.Bounded env49834 := by
  intro p hp
  have h : env49834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49833_49834 : H12AffineEnvironment.transform 8 48 env49833 = env49834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49833 == env49834) = true)

def env49835 : List Nat := [2,4,8,16,32,16,8,37,48,52,2048,48,40,33,1,35,48,2049,53,0,33,33,17,2,40,17,2048,49,49,2049,21,33,36,32,33,49]

theorem envBound49835 : H12AffineFastState.Bounded env49835 := by
  intro p hp
  have h : env49835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49834_49835 : H12AffineEnvironment.transform 9 52 env49834 = env49835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49834 == env49835) = true)

def env49836 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,48,40,32,1,35,49,2049,52,0,33,33,17,2,40,17,2048,48,49,2049,20,33,36,32,32,49]

theorem envBound49836 : H12AffineFastState.Bounded env49836 := by
  intro p hp
  have h : env49836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49834_49836 : H12AffineEnvironment.transform 9 53 env49834 = env49836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49834 == env49836) = true)

theorem identity49836 : scanCanonicalize (H12AffineFastState.compose env49836 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49836 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49837 : List Nat := [2,4,8,10,32,10,8,37,42,47,2048,42,40,32,1,35,43,2049,46,0,33,33,11,2,40,11,2048,42,43,2049,14,33,36,32,32,43]

theorem envBound49837 : H12AffineFastState.Bounded env49837 := by
  intro p hp
  have h : env49837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49836_49837 : H12AffineEnvironment.transform 3 10 env49836 = env49837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49836 == env49837) = true)

def leafEnv49837 : List Nat := [2,4,8,10,32,10,8,37,42,47,2048,42,40,32,1,35,43,2049,46,0,33,33,11,2,15,40,1,11,2048,42,43,2049,14,33,36,32,5,35,32,43,1,33,0]

def active49837 : List Nat := [0,1,2,4,10]

def tree49837 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49837 : H12WitnessSearch.Good tree49837 := H12GlobalWitnessIndex.good

theorem leafIdentity49837 : H12AffineFastState.composeSystem env49837 rootObs = leafEnv49837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49837 rootObs == leafEnv49837) = true)

theorem terminalChecked49837 : H12PackedTerminal.terminalCheckFast leafEnv49837 active49837 tree49837 = true := by decide +kernel

def env49838 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1044,1,35,1029,2049,1025,0,32,33,17,2,40,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound49838 : H12AffineFastState.Bounded env49838 := by
  intro p hp
  have h : env49838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49832_49838 : H12AffineEnvironment.transform 11 49 env49832 = env49838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49832 == env49838) = true)

theorem identity49838 : scanCanonicalize (H12AffineFastState.compose env49838 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound49838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49839 : List Nat := [2,4,8,16,32,16,8,37,512,516,2048,49,40,528,1,35,513,2049,517,0,32,33,17,2,40,17,2048,512,48,2049,549,33,36,32,528,513]

theorem envBound49839 : H12AffineFastState.Bounded env49839 := by
  intro p hp
  have h : env49839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49838_49839 : H12AffineEnvironment.transform 9 516 env49838 = env49839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env49838 == env49839) = true)

def env49840 : List Nat := [2,4,8,16,32,16,8,37,48,52,2048,49,40,32,1,35,49,2049,53,0,32,33,17,2,40,17,2048,48,48,2049,21,33,36,32,32,49]

theorem envBound49840 : H12AffineFastState.Bounded env49840 := by
  intro p hp
  have h : env49840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49839_49840 : H12AffineEnvironment.transform 8 48 env49839 = env49840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49839 == env49840) = true)

def env49841 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,49,40,33,1,35,48,2049,52,0,32,33,17,2,40,17,2048,49,48,2049,20,33,36,32,33,48]

theorem envBound49841 : H12AffineFastState.Bounded env49841 := by
  intro p hp
  have h : env49841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49839_49841 : H12AffineEnvironment.transform 8 49 env49839 = env49841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env49839 == env49841) = true)

theorem identity49841 : scanCanonicalize (H12AffineFastState.compose env49841 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49842 : List Nat := [2,4,8,10,32,10,8,37,43,47,2048,43,40,33,1,35,42,2049,46,0,32,33,11,2,40,11,2048,43,42,2049,14,33,36,32,33,42]

theorem envBound49842 : H12AffineFastState.Bounded env49842 := by
  intro p hp
  have h : env49842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49841_49842 : H12AffineEnvironment.transform 3 10 env49841 = env49842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49841 == env49842) = true)

def leafEnv49842 : List Nat := [2,4,8,10,32,10,8,37,43,47,2048,43,40,33,1,35,42,2049,46,0,32,33,11,2,15,40,1,11,2048,43,42,2049,14,33,36,32,5,35,33,42,1,32,0]

def active49842 : List Nat := [0,1,2,4,10]

def tree49842 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49842 : H12WitnessSearch.Good tree49842 := H12GlobalWitnessIndex.good

theorem leafIdentity49842 : H12AffineFastState.composeSystem env49842 rootObs = leafEnv49842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49842 rootObs == leafEnv49842) = true)

theorem terminalChecked49842 : H12PackedTerminal.terminalCheckFast leafEnv49842 active49842 tree49842 = true := by decide +kernel

def env49843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,16777216,8192,65,21039476,18973700,2233680,2421,17024017,23160136,257,19104804,19096840,16966479]

theorem envBound49843 : H12AffineFastState.Bounded env49843 := by
  intro p hp
  have h : env49843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49793_49843 : H12AffineEnvironment.transform 22 147457 env49793 = env49843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env49793 == env49843) = true)

def env49844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,16777216,8192,65,21039476,18973700,2118976,2421,16876545,23160136,257,18990132,18949400,16819039]

theorem envBound49844 : H12AffineFastState.Bounded env49844 := by
  intro p hp
  have h : env49844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49843_49844 : H12AffineEnvironment.transform 16 16400 env49843 = env49844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49843 == env49844) = true)

def env49845 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,16777216,8192,65,21039104,18973700,2118708,2049,16876545,23159868,117,18990132,18949228,16818731]

theorem envBound49845 : H12AffineFastState.Bounded env49845 := by
  intro p hp
  have h : env49845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49844_49845 : H12AffineEnvironment.transform 7 116 env49844 = env49845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49844 == env49845) = true)

theorem identity49845 : scanCanonicalize (H12AffineFastState.compose env49845 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound49845 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env49846 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,16777216,8192,65,21039104,16834618,77834,2049,16876545,20971522,117,16818186,16793682,16818731]

theorem envBound49846 : H12AffineFastState.Bounded env49846 := by
  intro p hp
  have h : env49846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49845_49846 : H12AffineEnvironment.transform 20 91198 env49845 = env49846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env49845 == env49846) = true)

def env49847 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,16777216,8192,17,21039104,16834618,77834,2049,16876545,20971522,37,16818186,16793602,16818731]

theorem envBound49847 : H12AffineFastState.Bounded env49847 := by
  intro p hp
  have h : env49847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49846_49847 : H12AffineEnvironment.transform 5 16 env49846 = env49847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49846 == env49847) = true)

theorem identity49847 : scanCanonicalize (H12AffineFastState.compose env49847 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292609) := by decide +kernel

theorem selectedBound49847 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49848 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,4292609,8192,17,34817,4284475,77834,2049,4195328,98307,37,4268043,4308995,4268586]

theorem envBound49848 : H12AffineFastState.Bounded env49848 := by
  intro p hp
  have h : env49848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49847_49848 : H12AffineEnvironment.transform 23 4292609 env49847 = env49848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292609 env49847 == env49848) = true)

theorem identity49848 : scanCanonicalize (H12AffineFastState.compose env49848 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound49848 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49849 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1025,8233,91198,4194304,17,4268073,8192,17,10281,4284475,77834,2049,4195328,73771,37,4268043,4284459,4268586]

theorem envBound49849 : H12AffineFastState.Bounded env49849 := by
  intro p hp
  have h : env49849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49848_49849 : H12AffineEnvironment.transform 14 8232 env49848 = env49849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env49848 == env49849) = true)

theorem identity49849 : scanCanonicalize (H12AffineFastState.compose env49849 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(21+1) ^^^ 87047) := by decide +kernel

theorem selectedBound49849 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env49850 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1025,8233,91198,87047,17,29742,8192,17,10281,13372,77834,2049,86023,73771,37,29708,13356,30253]

theorem envBound49850 : H12AffineFastState.Bounded env49850 := by
  intro p hp
  have h : env49850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49849_49850 : H12AffineEnvironment.transform 21 87047 env49849 = env49850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87047 env49849 == env49850) = true)

theorem identity49850 : scanCanonicalize (H12AffineFastState.compose env49850 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound49850 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env49851 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5125,8232,65536,5141,10281,1025,8233,77883,65538,17,8235,8192,17,10281,13372,77834,2049,66562,73771,37,8201,13356,8744]

theorem envBound49851 : H12AffineFastState.Bounded env49851 := by
  intro p hp
  have h : env49851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49850_49851 : H12AffineEnvironment.transform 13 5125 env49850 = env49851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env49850 == env49851) = true)

theorem identity49851 : scanCanonicalize (H12AffineFastState.compose env49851 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49851 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49852 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5125,8232,8203,5141,10281,1025,8233,4144,8201,17,8235,8192,17,10281,13372,4097,2049,9225,32,37,8201,13356,8744]

theorem envBound49852 : H12AffineFastState.Bounded env49852 := by
  intro p hp
  have h : env49852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49851_49852 : H12AffineEnvironment.transform 15 8203 env49851 = env49852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49851 == env49852) = true)

theorem identity49852 : scanCanonicalize (H12AffineFastState.compose env49852 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound49852 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env49853 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,5125,1076,1047,5141,3125,1025,1077,4144,1045,17,1079,1052,17,3125,4128,4097,2049,21,32,37,1045,4144,1588]

theorem envBound49853 : H12AffineFastState.Bounded env49853 := by
  intro p hp
  have h : env49853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49852_49853 : H12AffineEnvironment.transform 12 1052 env49852 = env49853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env49852 == env49853) = true)

theorem identity49853 : scanCanonicalize (H12AffineFastState.compose env49853 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound49853 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env49854 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,4096,1052,5125,1076,1047,5141,1,1025,1077,4144,1045,17,1079,1052,17,1,4128,4097,1077,21,32,37,1045,4144,1588]

theorem envBound49854 : H12AffineFastState.Bounded env49854 := by
  intro p hp
  have h : env49854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49853_49854 : H12AffineEnvironment.transform 10 1076 env49853 = env49854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env49853 == env49854) = true)

theorem identity49854 : scanCanonicalize (H12AffineFastState.compose env49854 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound49854 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env49855 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,49,1052,1076,1076,1047,1060,1,1025,1077,1,1045,17,1079,1052,17,1,17,48,1077,21,32,37,1045,1,1588]

theorem envBound49855 : H12AffineFastState.Bounded env49855 := by
  intro p hp
  have h : env49855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49854_49855 : H12AffineEnvironment.transform 11 49 env49854 = env49855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49854 == env49855) = true)

def env49856 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,16777216,8192,16,21039104,16834618,77834,2049,16876545,20971522,36,16818186,16793603,16818731]

theorem envBound49856 : H12AffineFastState.Bounded env49856 := by
  intro p hp
  have h : env49856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49846_49856 : H12AffineEnvironment.transform 5 17 env49846 = env49856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49846 == env49856) = true)

theorem identity49856 : scanCanonicalize (H12AffineFastState.compose env49856 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235275) := by decide +kernel

theorem selectedBound49856 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49857 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,4235275,8192,16,108555,4210737,77834,2049,4269066,40969,36,4194305,4251656,4194848]

theorem envBound49857 : H12AffineFastState.Bounded env49857 := by
  intro p hp
  have h : env49857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49856_49857 : H12AffineEnvironment.transform 23 4235275 env49856 = env49857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235275 env49856 == env49857) = true)

theorem identity49857 : scanCanonicalize (H12AffineFastState.compose env49857 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound49857 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env49858 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,8201,17,32770,8192,16,108555,24632,77834,2049,66563,40969,36,8200,49153,8745]

theorem envBound49858 : H12AffineFastState.Bounded env49858 := by
  intro p hp
  have h : env49858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49857_49858 : H12AffineEnvironment.transform 21 8201 env49857 = env49858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env49857 == env49858) = true)

theorem identity49858 : scanCanonicalize (H12AffineFastState.compose env49858 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49858 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env49859 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,34,16400,34817,1025,32769,25628,8201,17,32770,8192,16,43049,24632,12328,2049,1057,40969,36,8200,49153,8745]

theorem envBound49859 : H12AffineFastState.Bounded env49859 := by
  intro p hp
  have h : env49859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49858_49859 : H12AffineEnvironment.transform 15 34 env49858 = env49859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49858 == env49859) = true)

theorem identity49859 : scanCanonicalize (H12AffineFastState.compose env49859 (packedSelected [0,2,3,5,6,7,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49859 : packedSelected [0,2,3,5,6,7,14,19] rootPS < 2^1333 := by decide +kernel

def env49860 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,0,34,16400,2049,1025,1,25628,8201,17,2,8192,16,10281,24632,12328,2049,1057,8201,36,8200,16385,8745]

theorem envBound49860 : H12AffineFastState.Bounded env49860 := by
  intro p hp
  have h : env49860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49859_49860 : H12AffineEnvironment.transform 14 0 env49859 = env49860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49859 == env49860) = true)

theorem identity49860 : scanCanonicalize (H12AffineFastState.compose env49860 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound49860 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49861 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5124,0,34,5140,2049,1025,1,12312,8201,17,2,8192,16,10281,13372,12328,2049,1057,8201,36,8200,5125,8745]

theorem envBound49861 : H12AffineFastState.Bounded env49861 := by
  intro p hp
  have h : env49861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49860_49861 : H12AffineEnvironment.transform 13 5124 env49860 = env49861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env49860 == env49861) = true)

theorem identity49861 : scanCanonicalize (H12AffineFastState.compose env49861 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49861 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env49862 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5124,0,34,5140,2049,1025,1,4145,32,17,2,41,16,2048,5141,4097,2049,1057,32,36,33,5125,512]

theorem envBound49862 : H12AffineFastState.Bounded env49862 := by
  intro p hp
  have h : env49862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49861_49862 : H12AffineEnvironment.transform 12 41 env49861 = env49862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49861 == env49862) = true)

theorem identity49862 : scanCanonicalize (H12AffineFastState.compose env49862 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound49862 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49863 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3076,41,2048,0,34,2064,2049,1025,1,3125,32,17,2,41,16,2048,2065,3077,2049,1057,32,36,33,2049,512]

theorem envBound49863 : H12AffineFastState.Bounded env49863 := by
  intro p hp
  have h : env49863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49862_49863 : H12AffineEnvironment.transform 11 3076 env49862 = env49863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env49862 == env49863) = true)

theorem identity49863 : scanCanonicalize (H12AffineFastState.compose env49863 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49863 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49864 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,3076,8,2048,0,3,2064,2049,1025,1,3092,1,17,2,8,16,2048,2065,3077,2049,1024,1,5,0,2049,512]

theorem envBound49864 : H12AffineFastState.Bounded env49864 := by
  intro p hp
  have h : env49864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49863_49864 : H12AffineEnvironment.transform 4 1 env49863 = env49864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49863 == env49864) = true)

theorem identity49864 : scanCanonicalize (H12AffineFastState.compose env49864 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound49864 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49865 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,8,2048,0,3,2064,2049,21,1,2048,1,17,2,8,16,2048,2065,2065,2049,20,1,5,0,2049,512]

theorem envBound49865 : H12AffineFastState.Bounded env49865 := by
  intro p hp
  have h : env49865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49864_49865 : H12AffineEnvironment.transform 9 20 env49864 = env49865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env49864 == env49865) = true)

theorem identity49865 : scanCanonicalize (H12AffineFastState.compose env49865 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49866 : List Nat := [2,4,8,16,1,17,8,4,1,20,2048,2064,8,2048,0,3,2064,2049,21,1,2048,1,17,2,8,16,2048,2065,2065,2049,20,1,5,0,2049,1]

theorem envBound49866 : H12AffineFastState.Bounded env49866 := by
  intro p hp
  have h : env49866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49865_49866 : H12AffineEnvironment.transform 8 1 env49865 = env49866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49865 == env49866) = true)

theorem identity49866 : scanCanonicalize (H12AffineFastState.compose env49866 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound49866 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49867 : List Nat := [2,4,8,5,1,4,8,4,1,1,2048,2053,8,2048,0,3,2053,2049,0,1,2048,1,4,2,8,5,2048,2052,2052,2049,1,1,5,0,2049,1]

theorem envBound49867 : H12AffineFastState.Bounded env49867 := by
  intro p hp
  have h : env49867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49866_49867 : H12AffineEnvironment.transform 3 5 env49866 = env49867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49866 == env49867) = true)

def leafEnv49867 : List Nat := [2,4,8,5,1,4,8,4,1,1,2048,2053,8,2048,0,3,2053,2049,0,1,2048,1,4,2,0,8,1,5,2048,2052,2052,2049,1,1,5,0,5,3,2049,1,1,2049,0]

def active49867 : List Nat := [0,1,2,10]

def tree49867 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49867 : H12WitnessSearch.Good tree49867 := H12GlobalWitnessIndex.good

theorem leafIdentity49867 : H12AffineFastState.composeSystem env49867 rootObs = leafEnv49867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49867 rootObs == leafEnv49867) = true)

theorem terminalChecked49867 : H12PackedTerminal.terminalCheckFast leafEnv49867 active49867 tree49867 = true := by decide +kernel

def env49868 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,16777216,8192,65,21039105,18973700,2118709,2048,16876545,23159869,116,18990132,18949229,16818730]

theorem envBound49868 : H12AffineFastState.Bounded env49868 := by
  intro p hp
  have h : env49868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49844_49868 : H12AffineEnvironment.transform 7 117 env49844 = env49868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49844 == env49868) = true)

theorem identity49868 : scanCanonicalize (H12AffineFastState.compose env49868 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound49868 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env49869 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,2212884,8192,65,6343701,16400,2118709,2048,2113557,4235305,116,32,57465,2188862]

theorem envBound49869 : H12AffineFastState.Bounded env49869 := by
  intro p hp
  have h : env49869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49868_49869 : H12AffineEnvironment.transform 23 2212884 env49868 = env49869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env49868 == env49869) = true)

def env49870 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,2212884,8192,17,6343701,16400,2118709,2048,2113557,4235305,36,32,57385,2188862]

theorem envBound49870 : H12AffineFastState.Bounded env49870 := by
  intro p hp
  have h : env49870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49869_49870 : H12AffineEnvironment.transform 5 16 env49869 = env49870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49869 == env49870) = true)

theorem identity49870 : scanCanonicalize (H12AffineFastState.compose env49870 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound49870 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env49871 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,73770,17,2212884,8192,17,2223167,16400,2118709,2048,2113557,98307,36,32,57385,2188862]

theorem envBound49871 : H12AffineFastState.Bounded env49871 := by
  intro p hp
  have h : env49871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49870_49871 : H12AffineEnvironment.transform 21 73770 env49870 = env49871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env49870 == env49871) = true)

theorem identity49871 : scanCanonicalize (H12AffineFastState.compose env49871 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound49871 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49872 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1025,8232,2097152,73770,17,2188349,8192,17,2182166,16400,2118709,2048,2113557,73770,36,32,16384,2188862]

theorem envBound49872 : H12AffineFastState.Bounded env49872 := by
  intro p hp
  have h : env49872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49871_49872 : H12AffineEnvironment.transform 14 8233 env49871 = env49872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env49871 == env49872) = true)

theorem identity49872 : scanCanonicalize (H12AffineFastState.compose env49872 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49872 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env49873 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,34,16400,10281,1025,8232,2097152,8200,17,2122783,8192,17,2116660,16400,2118709,2048,2113557,8200,36,32,16384,2123292]

theorem envBound49873 : H12AffineFastState.Bounded env49873 := by
  intro p hp
  have h : env49873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49872_49873 : H12AffineEnvironment.transform 15 34 env49872 = env49873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49872 == env49873) = true)

theorem identity49873 : scanCanonicalize (H12AffineFastState.compose env49873 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound49873 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49874 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,34,16400,10281,1025,8232,17460,8200,17,8235,8192,17,2048,16400,4097,2048,1057,8200,36,32,16384,8744]

theorem envBound49874 : H12AffineFastState.Bounded env49874 := by
  intro p hp
  have h : env49874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49873_49874 : H12AffineEnvironment.transform 20 17460 env49873 = env49874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env49873 == env49874) = true)

theorem identity49874 : scanCanonicalize (H12AffineFastState.compose env49874 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound49874 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env49875 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1029,8192,16384,8233,34,16400,10281,1025,8232,17460,8200,17,8235,8192,17,2048,16400,1028,2048,1057,8200,36,32,16384,8744]

theorem envBound49875 : H12AffineFastState.Bounded env49875 := by
  intro p hp
  have h : env49875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49874_49875 : H12AffineEnvironment.transform 11 1029 env49874 = env49875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env49874 == env49875) = true)

theorem identity49875 : scanCanonicalize (H12AffineFastState.compose env49875 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 32) := by decide +kernel

theorem selectedBound49875 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49876 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1029,8192,32,8233,34,48,10281,1025,8232,1044,8200,17,8235,8192,17,2048,48,1028,2048,1057,8200,36,32,32,8744]

theorem envBound49876 : H12AffineFastState.Bounded env49876 := by
  intro p hp
  have h : env49876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49875_49876 : H12AffineEnvironment.transform 13 32 env49875 = env49876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 32 env49875 == env49876) = true)

theorem identity49876 : scanCanonicalize (H12AffineFastState.compose env49876 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49876 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49877 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,1029,8192,32,8233,34,48,8200,1025,8232,1044,8200,17,8235,8192,17,33,48,1028,33,1057,8200,36,32,32,8744]

theorem envBound49877 : H12AffineFastState.Bounded env49877 := by
  intro p hp
  have h : env49877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49876_49877 : H12AffineEnvironment.transform 10 33 env49876 = env49877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49876 == env49877) = true)

def env49878 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,2212884,8192,16,6343701,16400,2118709,2048,2113557,4235305,37,32,57384,2188862]

theorem envBound49878 : H12AffineFastState.Bounded env49878 := by
  intro p hp
  have h : env49878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49869_49878 : H12AffineEnvironment.transform 5 17 env49869 = env49878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49869 == env49878) = true)

theorem identity49878 : scanCanonicalize (H12AffineFastState.compose env49878 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49878 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env49879 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,0,65536,16400,2048,1025,1,2097152,4194304,17,2180116,8192,16,6310933,16400,2118709,2048,2113557,4202537,37,32,24616,2188862]

theorem envBound49879 : H12AffineFastState.Bounded env49879 := by
  intro p hp
  have h : env49879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49878_49879 : H12AffineEnvironment.transform 14 0 env49878 = env49879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49878 == env49879) = true)

theorem identity49879 : scanCanonicalize (H12AffineFastState.compose env49879 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122813) := by decide +kernel

theorem selectedBound49879 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49880 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,0,65536,16400,2048,1025,1,2097152,2122813,17,2180116,8192,16,10280,16400,2118709,2048,2113557,2114580,37,32,24616,2188862]

theorem envBound49880 : H12AffineFastState.Bounded env49880 := by
  intro p hp
  have h : env49880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49879_49880 : H12AffineEnvironment.transform 21 2122813 env49879 = env49880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122813 env49879 == env49880) = true)

theorem identity49880 : scanCanonicalize (H12AffineFastState.compose env49880 (packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 29711) := by decide +kernel

theorem selectedBound49880 : packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env49881 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,0,29711,16400,2048,1025,1,2097152,2122813,17,2109467,8192,16,10280,16400,2118709,2048,2113557,2114580,37,32,24616,2101809]

theorem envBound49881 : H12AffineFastState.Bounded env49881 := by
  intro p hp
  have h : env49881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49880_49881 : H12AffineEnvironment.transform 15 29711 env49880 = env49881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29711 env49880 == env49881) = true)

theorem identity49881 : scanCanonicalize (H12AffineFastState.compose env49881 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 12312) := by decide +kernel

theorem selectedBound49881 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env49882 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,0,29711,16400,2048,1025,1,12312,21541,17,3,8192,16,10280,16400,25645,2048,28685,29708,37,32,24616,8745]

theorem envBound49882 : H12AffineFastState.Bounded env49882 := by
  intro p hp
  have h : env49882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49881_49882 : H12AffineEnvironment.transform 20 12312 env49881 = env49882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12312 env49881 == env49882) = true)

theorem identity49882 : scanCanonicalize (H12AffineFastState.compose env49882 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound49882 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49883 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,2081,0,15406,2097,2048,1025,1,12312,7172,17,3,8192,16,10280,2097,11276,2048,14380,15405,37,32,10249,8745]

theorem envBound49883 : H12AffineFastState.Bounded env49883 := by
  intro p hp
  have h : env49883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49882_49883 : H12AffineEnvironment.transform 13 2081 env49882 = env49883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env49882 == env49883) = true)

theorem identity49883 : scanCanonicalize (H12AffineFastState.compose env49883 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound49883 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env49884 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,5133,2081,0,2083,2097,2048,1025,1,1045,7172,17,3,5133,16,7205,2097,6145,2048,3105,2080,37,32,7172,5668]

theorem envBound49884 : H12AffineFastState.Bounded env49884 := by
  intro p hp
  have h : env49884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49883_49884 : H12AffineEnvironment.transform 12 5133 env49883 = env49884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env49883 == env49884) = true)

theorem identity49884 : scanCanonicalize (H12AffineFastState.compose env49884 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound49884 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49885 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,4096,5133,1045,0,1047,1029,1076,1025,1,1045,4144,17,3,5133,16,4113,1029,5173,1076,21,1044,37,32,4144,5668]

theorem envBound49885 : H12AffineFastState.Bounded env49885 := by
  intro p hp
  have h : env49885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49884_49885 : H12AffineEnvironment.transform 10 1076 env49884 = env49885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env49884 == env49885) = true)

theorem identity49885 : scanCanonicalize (H12AffineFastState.compose env49885 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49885 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env49886 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,4096,4152,32,0,34,48,1,52,1,32,4144,17,3,4152,16,4113,48,4096,1,21,33,37,32,4144,4625]

theorem envBound49886 : H12AffineFastState.Bounded env49886 := by
  intro p hp
  have h : env49886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49885_49886 : H12AffineEnvironment.transform 9 53 env49885 = env49886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49885 == env49886) = true)

def env49887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,16777216,8192,65,21039476,18973700,2118977,2421,16876544,23160136,257,18990133,18949401,16819038]

end H12CloudChart0