import H12CloudChart0Data092

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans23515_23516 : H12AffineEnvironment.transform 9 47 env23515 = env23516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env23515 == env23516) = true)

theorem identity23516 : scanCanonicalize (H12AffineFastState.compose env23516 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound23516 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env23517 : List Nat := [2,4,8,16,32,64,41,5,512,47,97,90,88,81,33,82,65,49,47,32,26,1,17,3,121,65,64,97,123,17,94,1,5,1,32,512]

theorem envBound23517 : H12AffineFastState.Bounded env23517 := by
  intro p hp
  have h : env23517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23516_23517 : H12AffineEnvironment.transform 10 97 env23516 = env23517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env23516 == env23517) = true)

theorem identity23517 : scanCanonicalize (H12AffineFastState.compose env23517 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23517 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env23518 : List Nat := [2,4,8,16,32,17,41,5,512,47,48,11,9,0,33,3,16,49,47,32,26,1,17,3,40,16,17,48,42,17,15,1,5,1,32,512]

theorem envBound23518 : H12AffineFastState.Bounded env23518 := by
  intro p hp
  have h : env23518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23517_23518 : H12AffineEnvironment.transform 5 17 env23517 = env23518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23517 == env23518) = true)

theorem identity23518 : scanCanonicalize (H12AffineFastState.compose env23518 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23519 : List Nat := [2,4,3,16,32,17,34,5,512,36,48,0,2,0,33,3,16,49,36,32,17,1,17,3,35,16,17,48,33,17,4,1,5,1,32,512]

theorem envBound23519 : H12AffineFastState.Bounded env23519 := by
  intro p hp
  have h : env23519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23518_23519 : H12AffineEnvironment.transform 2 3 env23518 = env23519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23518 == env23519) = true)

theorem identity23519 : scanCanonicalize (H12AffineFastState.compose env23519 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23519 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23520 : List Nat := [2,4,3,16,1,17,3,5,512,5,17,0,2,0,0,3,16,16,5,1,17,1,17,3,2,16,17,17,0,17,4,1,5,1,1,512]

theorem envBound23520 : H12AffineFastState.Bounded env23520 := by
  intro p hp
  have h : env23520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23519_23520 : H12AffineEnvironment.transform 4 1 env23519 = env23520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23519 == env23520) = true)

theorem identity23520 : scanCanonicalize (H12AffineFastState.compose env23520 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound23520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23521 : List Nat := [2,4,3,16,1,17,3,5,5,5,17,0,2,0,0,3,16,16,5,1,17,1,17,3,2,16,17,17,0,17,4,1,5,1,1,5]

theorem envBound23521 : H12AffineFastState.Bounded env23521 := by
  intro p hp
  have h : env23521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23520_23521 : H12AffineEnvironment.transform 8 5 env23520 = env23521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env23520 == env23521) = true)

theorem identity23521 : scanCanonicalize (H12AffineFastState.compose env23521 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23521 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23522 : List Nat := [2,4,3,0,1,1,3,5,5,5,1,0,2,0,0,3,0,0,5,1,1,1,1,3,2,0,1,1,0,1,4,1,5,1,1,5]

theorem envBound23522 : H12AffineFastState.Bounded env23522 := by
  intro p hp
  have h : env23522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23521_23522 : H12AffineEnvironment.transform 3 0 env23521 = env23522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23521 == env23522) = true)

theorem identity23522 : scanCanonicalize (H12AffineFastState.compose env23522 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound23522 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23523 : List Nat := [2,2,3,0,1,1,3,3,3,3,1,0,2,0,0,3,0,0,3,1,1,1,1,3,2,0,1,1,0,1,2,1,3,1,1,3]

theorem envBound23523 : H12AffineFastState.Bounded env23523 := by
  intro p hp
  have h : env23523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23522_23523 : H12AffineEnvironment.transform 1 2 env23522 = env23523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env23522 == env23523) = true)

def env23524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,510000,8328,65,316533,417020,396524,35324,1500,272392,256,21792,46213,74251]

theorem envBound23524 : H12AffineFastState.Bounded env23524 := by
  intro p hp
  have h : env23524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23489_23524 : H12AffineEnvironment.transform 20 4161 env23489 = env23524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23489 == env23524) = true)

theorem identity23524 : scanCanonicalize (H12AffineFastState.compose env23524 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound23524 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,169400,412156,400622,8328,65,316533,417020,396524,35324,1500,272392,256,21792,46213,63189]

theorem envBound23525 : H12AffineFastState.Bounded env23525 := by
  intro p hp
  have h : env23525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23524_23525 : H12AffineEnvironment.transform 15 54494 env23524 = env23525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env23524 == env23525) = true)

def env23526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146912,1024,32769,4161,169400,29724,8462,8328,65,190869,24860,12556,35324,1500,136680,256,21792,46213,63189]

theorem envBound23526 : H12AffineFastState.Bounded env23526 := by
  intro p hp
  have h : env23526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23525_23526 : H12AffineEnvironment.transform 17 146912 env23525 = env23526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env23525 == env23526) = true)

theorem identity23526 : scanCanonicalize (H12AffineFastState.compose env23526 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23526 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30083,131072,146912,1024,8540,4161,144613,29724,8462,8328,65,149704,24860,12556,10401,1500,136680,256,21792,5592,22408]

theorem envBound23527 : H12AffineFastState.Bounded env23527 := by
  intro p hp
  have h : env23527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23526_23527 : H12AffineEnvironment.transform 14 8541 env23526 = env23527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23526 == env23527) = true)

theorem identity23527 : scanCanonicalize (H12AffineFastState.compose env23527 (packedSelected [0,3,4,5,7,8,17,22,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23527 : packedSelected [0,3,4,5,7,8,17,22,28] rootPS < 2^1333 := by decide +kernel

def env23528 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,30083,131072,146864,1024,8460,4113,144565,29724,8462,8328,17,149656,24860,12556,10401,1420,136632,256,21792,5512,22408]

theorem envBound23528 : H12AffineFastState.Bounded env23528 := by
  intro p hp
  have h : env23528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23527_23528 : H12AffineEnvironment.transform 5 16 env23527 = env23528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23527 == env23528) = true)

theorem identity23528 : scanCanonicalize (H12AffineFastState.compose env23528 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound23528 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env23529 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8461,8202,131072,146864,1024,8460,4113,144565,8597,8462,8328,17,138513,13461,12556,10401,1420,136632,256,169,5512,513]

theorem envBound23529 : H12AffineFastState.Bounded env23529 := by
  intro p hp
  have h : env23529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23528_23529 : H12AffineEnvironment.transform 13 5513 env23528 = env23529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env23528 == env23529) = true)

theorem identity23529 : scanCanonicalize (H12AffineFastState.compose env23529 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound23529 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23530 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8461,8202,5392,10400,1024,8460,4113,8613,8597,8462,8328,17,2049,13461,12556,10401,1420,168,256,169,5512,513]

theorem envBound23530 : H12AffineFastState.Bounded env23530 := by
  intro p hp
  have h : env23530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23529_23530 : H12AffineEnvironment.transform 16 5392 env23529 = env23530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env23529 == env23530) = true)

def env23531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146913,1024,32769,4161,169400,29725,8463,8328,65,190868,24861,12557,35324,1500,136681,256,21792,46213,63189]

theorem envBound23531 : H12AffineFastState.Bounded env23531 := by
  intro p hp
  have h : env23531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23525_23531 : H12AffineEnvironment.transform 17 146913 env23525 = env23531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env23525 == env23531) = true)

theorem identity23531 : scanCanonicalize (H12AffineFastState.compose env23531 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound23531 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29963,131072,146913,1024,8660,4161,144493,29725,8463,8328,65,149569,24861,12557,10281,1500,136681,256,21792,5456,22272]

theorem envBound23532 : H12AffineFastState.Bounded env23532 := by
  intro p hp
  have h : env23532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23531_23532 : H12AffineEnvironment.transform 14 8661 env23531 = env23532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env23531 == env23532) = true)

theorem identity23532 : scanCanonicalize (H12AffineFastState.compose env23532 (packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound23532 : packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS < 2^1333 := by decide +kernel

def env23533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29963,5529,10360,1024,8660,4161,8692,29725,8463,8328,65,24024,24861,12557,10281,1500,112,256,21792,5456,22272]

theorem envBound23533 : H12AffineFastState.Bounded env23533 := by
  intro p hp
  have h : env23533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23532_23533 : H12AffineEnvironment.transform 16 5529 env23532 = env23533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env23532 == env23533) = true)

theorem identity23533 : scanCanonicalize (H12AffineFastState.compose env23533 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound23533 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env23534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8322,5529,10360,1024,8660,4161,8692,8596,8463,8328,65,2129,13460,12557,10281,1500,112,256,169,5456,649]

theorem envBound23534 : H12AffineFastState.Bounded env23534 := by
  intro p hp
  have h : env23534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23533_23534 : H12AffineEnvironment.transform 13 5513 env23533 = env23534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env23533 == env23534) = true)

theorem identity23534 : scanCanonicalize (H12AffineFastState.compose env23534 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23534 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env23535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5513,508,171,5529,2129,1024,509,4161,477,445,294,161,65,2129,5309,4388,2048,1500,112,256,169,5456,649]

theorem envBound23535 : H12AffineFastState.Bounded env23535 := by
  intro p hp
  have h : env23535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23534_23535 : H12AffineEnvironment.transform 12 41 env23534 = env23535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23534 == env23535) = true)

theorem identity23535 : scanCanonicalize (H12AffineFastState.compose env23535 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23535 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23536 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5513,429,171,5529,2048,1024,428,4112,396,445,294,161,16,2048,5309,4388,2048,1421,33,256,169,5377,649]

theorem envBound23536 : H12AffineFastState.Bounded env23536 := by
  intro p hp
  have h : env23536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23535_23536 : H12AffineEnvironment.transform 5 17 env23535 = env23536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23535 == env23536) = true)

theorem identity23536 : scanCanonicalize (H12AffineFastState.compose env23536 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound23536 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23537 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1061,41,428,429,171,444,2048,1024,428,1077,396,445,294,161,16,2048,152,1281,2048,1421,33,256,169,292,649]

theorem envBound23537 : H12AffineFastState.Bounded env23537 := by
  intro p hp
  have h : env23537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23536_23537 : H12AffineEnvironment.transform 11 1061 env23536 = env23537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env23536 == env23537) = true)

theorem identity23537 : scanCanonicalize (H12AffineFastState.compose env23537 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound23537 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23538 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,444,41,428,429,171,444,2048,409,428,428,396,445,294,161,16,2048,152,152,2048,20,33,256,169,292,649]

theorem envBound23538 : H12AffineFastState.Bounded env23538 := by
  intro p hp
  have h : env23538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23537_23538 : H12AffineEnvironment.transform 9 409 env23537 = env23538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env23537 == env23538) = true)

theorem identity23538 : scanCanonicalize (H12AffineFastState.compose env23538 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23538 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23539 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,16,41,0,1,171,16,2048,53,0,0,32,17,138,161,16,2048,152,152,2048,20,33,172,169,136,649]

theorem envBound23539 : H12AffineFastState.Bounded env23539 := by
  intro p hp
  have h : env23539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23538_23539 : H12AffineEnvironment.transform 7 172 env23538 = env23539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23538 == env23539) = true)

theorem identity23539 : scanCanonicalize (H12AffineFastState.compose env23539 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound23539 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env23540 : List Nat := [2,4,8,16,32,17,128,172,512,53,152,16,41,0,1,171,16,152,53,0,0,32,17,138,161,16,152,152,152,152,20,33,172,169,136,649]

theorem envBound23540 : H12AffineFastState.Bounded env23540 := by
  intro p hp
  have h : env23540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23539_23540 : H12AffineEnvironment.transform 10 152 env23539 = env23540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env23539 == env23540) = true)

theorem identity23540 : scanCanonicalize (H12AffineFastState.compose env23540 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23540 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23541 : List Nat := [2,4,8,16,32,17,9,37,512,53,17,16,41,0,1,34,16,17,53,0,0,32,17,3,40,16,17,17,17,17,20,33,37,32,1,512]

theorem envBound23541 : H12AffineFastState.Bounded env23541 := by
  intro p hp
  have h : env23541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23540_23541 : H12AffineEnvironment.transform 6 9 env23540 = env23541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23540 == env23541) = true)

theorem identity23541 : scanCanonicalize (H12AffineFastState.compose env23541 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound23541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23542 : List Nat := [2,4,8,16,32,17,9,37,16,53,17,16,41,0,1,34,16,17,53,0,0,32,17,3,40,16,17,17,17,17,20,33,37,32,1,16]

theorem envBound23542 : H12AffineFastState.Bounded env23542 := by
  intro p hp
  have h : env23542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23541_23542 : H12AffineEnvironment.transform 8 16 env23541 = env23542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env23541 == env23542) = true)

theorem identity23542 : scanCanonicalize (H12AffineFastState.compose env23542 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound23542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23543 : List Nat := [2,4,8,16,14,17,9,11,16,27,17,16,7,0,1,12,16,17,27,0,0,14,17,3,6,16,17,17,17,17,20,15,11,14,1,16]

theorem envBound23543 : H12AffineFastState.Bounded env23543 := by
  intro p hp
  have h : env23543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23542_23543 : H12AffineEnvironment.transform 4 14 env23542 = env23543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env23542 == env23543) = true)

theorem identity23543 : scanCanonicalize (H12AffineFastState.compose env23543 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound23543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23544 : List Nat := [2,4,8,15,14,14,9,11,15,4,14,15,7,0,1,12,15,14,4,0,0,14,14,3,6,15,14,14,14,14,11,15,11,14,1,15]

theorem envBound23544 : H12AffineFastState.Bounded env23544 := by
  intro p hp
  have h : env23544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23543_23544 : H12AffineEnvironment.transform 3 15 env23543 = env23544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env23543 == env23544) = true)

def env23545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513341,510000,8328,65,2409525,2510013,396524,2136509,2102685,2373704,256,21792,46213,2175562]

theorem envBound23545 : H12AffineFastState.Bounded env23545 := by
  intro p hp
  have h : env23545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23488_23545 : H12AffineEnvironment.transform 21 169401 env23488 = env23545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env23488 == env23545) = true)

def env23546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,510000,8328,65,316533,417021,396524,35325,1501,272392,256,21792,46213,74250]

theorem envBound23546 : H12AffineFastState.Bounded env23546 := by
  intro p hp
  have h : env23546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23545_23546 : H12AffineEnvironment.transform 20 4160 env23545 = env23546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23545 == env23546) = true)

theorem identity23546 : scanCanonicalize (H12AffineFastState.compose env23546 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23546 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,169401,412157,452667,8328,65,316533,417021,396524,35325,1501,272392,256,21792,46213,513]

theorem envBound23547 : H12AffineFastState.Bounded env23547 := by
  intro p hp
  have h : env23547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23546_23547 : H12AffineEnvironment.transform 15 8203 env23546 = env23547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23546 == env23547) = true)

def env23548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4160,54697,264685,305195,8328,65,316533,269549,281852,35325,1501,272392,256,21792,46213,513]

theorem envBound23548 : H12AffineFastState.Bounded env23548 := by
  intro p hp
  have h : env23548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23547_23548 : H12AffineEnvironment.transform 16 16400 env23547 = env23548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23547 == env23548) = true)

theorem identity23548 : scanCanonicalize (H12AffineFastState.compose env23548 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound23548 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2557,1024,32769,4160,54697,16,41430,8328,65,56712,5392,17665,35325,1501,8693,256,21792,46213,513]

theorem envBound23549 : H12AffineFastState.Bounded env23549 := by
  intro p hp
  have h : env23549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23548_23549 : H12AffineEnvironment.transform 17 2557 env23548 = env23549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env23548 == env23549) = true)

theorem identity23549 : scanCanonicalize (H12AffineFastState.compose env23549 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound23549 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16400,2557,1024,21761,4160,169,16,29910,8328,65,2184,5392,17665,23805,1501,8693,256,21792,24965,513]

theorem envBound23550 : H12AffineFastState.Bounded env23550 := by
  intro p hp
  have h : env23550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23549_23550 : H12AffineEnvironment.transform 14 21760 env23549 = env23550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env23549 == env23550) = true)

theorem identity23550 : scanCanonicalize (H12AffineFastState.compose env23550 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23550 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env23551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,16400,2420,1024,21761,4160,32,16,29791,8193,65,2049,5392,17665,23668,1364,8572,256,21792,24844,513]

theorem envBound23551 : H12AffineFastState.Bounded env23551 := by
  intro p hp
  have h : env23551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23550_23551 : H12AffineEnvironment.transform 6 9 env23550 = env23551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23550 == env23551) = true)

theorem identity23551 : scanCanonicalize (H12AffineFastState.compose env23551 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23551 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8203,13388,2420,1024,8541,4160,32,16,3,8193,65,2049,5392,12637,10280,1364,8572,256,8572,5456,513]

theorem envBound23552 : H12AffineFastState.Bounded env23552 := by
  intro p hp
  have h : env23552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23551_23552 : H12AffineEnvironment.transform 13 13404 env23551 = env23552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23551 == env23552) = true)

theorem identity23552 : scanCanonicalize (H12AffineFastState.compose env23552 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound23552 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env23553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,8192,8477,8540,8203,8461,2420,1024,8541,1281,32,16,3,8193,65,2049,81,9244,10280,1364,8572,256,8572,17,513]

theorem envBound23553 : H12AffineFastState.Bounded env23553 := by
  intro p hp
  have h : env23553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23552_23553 : H12AffineEnvironment.transform 11 1345 env23552 = env23553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23552 == env23553) = true)

def env23554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4160,54696,264684,305194,8328,65,316533,269548,281853,35325,1501,272392,256,21792,46213,513]

theorem envBound23554 : H12AffineFastState.Bounded env23554 := by
  intro p hp
  have h : env23554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23547_23554 : H12AffineEnvironment.transform 16 16401 env23547 = env23554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23547 == env23554) = true)

def env23555 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4112,54696,264636,305194,8328,17,316453,269500,281773,35245,1421,272392,256,21792,46213,513]

theorem envBound23555 : H12AffineFastState.Bounded env23555 := by
  intro p hp
  have h : env23555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23554_23555 : H12AffineEnvironment.transform 5 16 env23554 = env23555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23554 == env23555) = true)

theorem identity23555 : scanCanonicalize (H12AffineFastState.compose env23555 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound23555 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env23556 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56356,1024,32769,4112,54696,54680,29710,8328,17,2049,49304,37001,35245,1421,62508,256,21792,46213,513]

theorem envBound23556 : H12AffineFastState.Bounded env23556 := by
  intro p hp
  have h : env23556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23555_23556 : H12AffineEnvironment.transform 17 56356 env23555 = env23556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env23555 == env23556) = true)

theorem identity23556 : scanCanonicalize (H12AffineFastState.compose env23556 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound23556 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env23557 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8203,16401,10400,1024,29829,4112,8492,8476,29710,8328,17,2049,13340,25613,32041,1421,168,256,21792,16385,513]

theorem envBound23557 : H12AffineFastState.Bounded env23557 := by
  intro p hp
  have h : env23557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23556_23557 : H12AffineEnvironment.transform 14 29828 env23556 = env23557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env23556 == env23557) = true)

theorem identity23557 : scanCanonicalize (H12AffineFastState.compose env23557 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound23557 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env23558 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,8203,13341,10400,1024,137,4112,8492,8476,2,8328,17,2049,13340,4097,2341,1421,168,256,8492,13325,513]

theorem envBound23558 : H12AffineFastState.Bounded env23558 := by
  intro p hp
  have h : env23558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23557_23558 : H12AffineEnvironment.transform 13 13324 env23557 = env23558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env23557 == env23558) = true)

theorem identity23558 : scanCanonicalize (H12AffineFastState.compose env23558 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound23558 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23559 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,136,398,5528,2341,1024,137,4112,169,153,2,269,17,2049,5529,4097,2341,1421,168,256,169,5512,513]

theorem envBound23559 : H12AffineFastState.Bounded env23559 := by
  intro p hp
  have h : env23559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23558_23559 : H12AffineEnvironment.transform 12 389 env23558 = env23559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env23558 == env23559) = true)

theorem identity23559 : scanCanonicalize (H12AffineFastState.compose env23559 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23559 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23560 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5392,2341,1024,1,4112,33,17,2,269,17,2049,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound23560 : H12AffineFastState.Bounded env23560 := by
  intro p hp
  have h : env23560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23559_23560 : H12AffineEnvironment.transform 6 8 env23559 = env23560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23559 == env23560) = true)

theorem identity23560 : scanCanonicalize (H12AffineFastState.compose env23560 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound23560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23561 : List Nat := [2,4,8,16,32,16,8,256,512,288,2048,4096,269,4129,0,262,4144,2341,288,1,4112,33,17,2,269,17,2049,4145,4097,2341,37,32,256,33,4128,513]

theorem envBound23561 : H12AffineFastState.Bounded env23561 := by
  intro p hp
  have h : env23561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23560_23561 : H12AffineEnvironment.transform 9 288 env23560 = env23561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env23560 == env23561) = true)

theorem identity23561 : scanCanonicalize (H12AffineFastState.compose env23561 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound23561 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23562 : List Nat := [2,4,8,16,32,16,8,256,512,288,2048,821,269,788,0,262,773,2341,288,1,805,33,17,2,269,17,2049,772,820,2341,37,32,256,33,789,513]

theorem envBound23562 : H12AffineFastState.Bounded env23562 := by
  intro p hp
  have h : env23562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23561_23562 : H12AffineEnvironment.transform 11 821 env23561 = env23562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env23561 == env23562) = true)

theorem identity23562 : scanCanonicalize (H12AffineFastState.compose env23562 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23562 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23563 : List Nat := [2,4,8,16,32,16,8,5,512,37,2048,560,8,529,0,3,512,2080,37,1,544,33,17,2,8,17,2049,513,561,2080,37,32,5,33,528,513]

theorem envBound23563 : H12AffineFastState.Bounded env23563 := by
  intro p hp
  have h : env23563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23562_23563 : H12AffineEnvironment.transform 7 5 env23562 = env23563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23562 == env23563) = true)

theorem identity23563 : scanCanonicalize (H12AffineFastState.compose env23563 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound23563 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23564 : List Nat := [2,4,8,16,32,16,8,5,512,37,513,560,8,529,0,3,512,545,37,1,544,33,17,2,8,17,512,513,561,545,37,32,5,33,528,513]

theorem envBound23564 : H12AffineFastState.Bounded env23564 := by
  intro p hp
  have h : env23564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23563_23564 : H12AffineEnvironment.transform 10 513 env23563 = env23564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env23563 == env23564) = true)

theorem identity23564 : scanCanonicalize (H12AffineFastState.compose env23564 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23564 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env23565 : List Nat := [2,4,8,16,16,16,8,5,512,21,513,512,8,529,0,3,512,529,21,1,528,17,17,2,8,17,512,513,513,529,21,16,5,17,528,513]

theorem envBound23565 : H12AffineFastState.Bounded env23565 := by
  intro p hp
  have h : env23565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23564_23565 : H12AffineEnvironment.transform 4 16 env23564 = env23565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23564 == env23565) = true)

theorem identity23565 : scanCanonicalize (H12AffineFastState.compose env23565 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound23565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23566 : List Nat := [2,4,8,16,16,16,8,5,17,21,16,17,8,0,0,3,17,0,21,1,1,17,17,2,8,17,17,16,16,0,21,16,5,17,1,16]

theorem envBound23566 : H12AffineFastState.Bounded env23566 := by
  intro p hp
  have h : env23566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23565_23566 : H12AffineEnvironment.transform 8 17 env23565 = env23566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env23565 == env23566) = true)

theorem identity23566 : scanCanonicalize (H12AffineFastState.compose env23566 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound23566 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23567 : List Nat := [2,4,8,10,10,10,8,5,11,15,10,11,8,0,0,3,11,0,15,1,1,11,11,2,8,11,11,10,10,0,15,10,5,11,1,10]

theorem envBound23567 : H12AffineFastState.Bounded env23567 := by
  intro p hp
  have h : env23567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23566_23567 : H12AffineEnvironment.transform 3 10 env23566 = env23567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env23566 == env23567) = true)

theorem identity23567 : scanCanonicalize (H12AffineFastState.compose env23567 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23567 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23568 : List Nat := [2,4,3,1,1,1,3,5,0,4,1,0,3,0,0,3,0,0,4,1,1,0,0,2,3,0,0,1,1,0,4,1,5,0,1,1]

theorem envBound23568 : H12AffineFastState.Bounded env23568 := by
  intro p hp
  have h : env23568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23567_23568 : H12AffineEnvironment.transform 2 3 env23567 = env23568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23567 == env23568) = true)

def env23569 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4113,54696,264637,305194,8328,16,316452,269501,281772,35244,1420,272392,256,21792,46213,513]

theorem envBound23569 : H12AffineFastState.Bounded env23569 := by
  intro p hp
  have h : env23569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23554_23569 : H12AffineEnvironment.transform 5 17 env23554 = env23569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23554 == env23569) = true)

theorem identity23569 : scanCanonicalize (H12AffineFastState.compose env23569 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23569 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env23570 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,8203,5393,262144,1024,32769,4113,32936,264637,305194,8328,16,295204,269501,268716,35244,1420,272392,256,32,46213,513]

theorem envBound23570 : H12AffineFastState.Bounded env23570 := by
  intro p hp
  have h : env23570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23569_23570 : H12AffineEnvironment.transform 13 5376 env23569 = env23570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23569 == env23570) = true)

theorem identity23570 : scanCanonicalize (H12AffineFastState.compose env23570 (packedSelected [3,5,7,8,14,17,18,20,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23570 : packedSelected [3,5,7,8,14,17,18,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env23571 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,8203,5393,10280,1024,32769,4113,32936,8597,32770,8328,16,43276,13461,12676,35244,1420,32,256,32,46213,513]

theorem envBound23571 : H12AffineFastState.Bounded env23571 := by
  intro p hp
  have h : env23571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23570_23571 : H12AffineEnvironment.transform 17 10280 env23570 = env23571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23570 == env23571) = true)

theorem identity23571 : scanCanonicalize (H12AffineFastState.compose env23571 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound23571 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env23572 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,5376,32768,1182,5393,3261,1024,32769,4113,32936,1280,32770,1053,16,36249,4096,5393,35244,1420,32,256,32,36880,513]

theorem envBound23572 : H12AffineFastState.Bounded env23572 := by
  intro p hp
  have h : env23572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23571_23572 : H12AffineEnvironment.transform 12 1173 env23571 = env23572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env23571 == env23572) = true)

theorem identity23572 : scanCanonicalize (H12AffineFastState.compose env23572 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 7425) := by decide +kernel

theorem selectedBound23572 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env23573 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,5376,7425,1182,5393,3261,1024,7424,4113,7593,1280,7427,1053,16,4248,4096,5393,5293,1420,32,256,32,3345,513]

theorem envBound23573 : H12AffineFastState.Bounded env23573 := by
  intro p hp
  have h : env23573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23572_23573 : H12AffineEnvironment.transform 14 7425 env23572 = env23573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7425 env23572 == env23573) = true)

theorem identity23573 : scanCanonicalize (H12AffineFastState.compose env23573 (packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound23573 : packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env23574 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,1173,2184,137,1182,2201,3261,1024,136,3481,33,1280,139,1053,16,3344,3464,2201,2341,1420,32,256,32,3345,513]

theorem envBound23574 : H12AffineFastState.Bounded env23574 := by
  intro p hp
  have h : env23574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23573_23574 : H12AffineEnvironment.transform 11 3464 env23573 = env23574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env23573 == env23574) = true)

theorem identity23574 : scanCanonicalize (H12AffineFastState.compose env23574 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound23574 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23575 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,2064,269,2184,137,262,2201,2341,408,136,2049,33,152,139,389,16,2184,2064,2201,2341,20,32,256,32,2185,513]

theorem envBound23575 : H12AffineFastState.Bounded env23575 := by
  intro p hp
  have h : env23575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23574_23575 : H12AffineEnvironment.transform 9 408 env23574 = env23575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env23574 == env23575) = true)

def env23576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,510000,8328,65,316532,417020,396524,35324,1500,272393,256,21792,46213,74251]

theorem envBound23576 : H12AffineFastState.Bounded env23576 := by
  intro p hp
  have h : env23576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23545_23576 : H12AffineEnvironment.transform 20 4161 env23545 = env23576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23545 == env23576) = true)

theorem identity23576 : scanCanonicalize (H12AffineFastState.compose env23576 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound23576 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,4161,169401,120014,21762,8328,65,215366,115150,102878,35324,1500,243003,256,21792,46213,74251]

theorem envBound23577 : H12AffineFastState.Bounded env23577 := by
  intro p hp
  have h : env23577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23576_23577 : H12AffineEnvironment.transform 17 236850 env23576 = env23577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env23576 == env23577) = true)

def env23578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4161,62709,120014,21762,8328,65,75786,115150,102878,35324,1500,119927,256,21792,46213,74251]

theorem envBound23578 : H12AffineFastState.Bounded env23578 := by
  intro p hp
  have h : env23578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23577_23578 : H12AffineEnvironment.transform 16 24908 env23577 = env23578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env23577 == env23578) = true)

def env23579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4161,62589,119878,21762,8192,65,75786,115014,102742,35188,1364,119927,256,21792,46093,74251]

theorem envBound23579 : H12AffineFastState.Bounded env23579 := by
  intro p hp
  have h : env23579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23578_23579 : H12AffineEnvironment.transform 6 8 env23578 = env23579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23578 == env23579) = true)

theorem identity23579 : scanCanonicalize (H12AffineFastState.compose env23579 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound23579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,24908,32041,1024,32769,4161,62589,21777,21762,8192,65,43357,16401,4097,35188,1364,21792,256,21792,46093,41820]

theorem envBound23580 : H12AffineFastState.Bounded env23580 := by
  intro p hp
  have h : env23580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23579_23580 : H12AffineEnvironment.transform 15 33111 env23579 = env23580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env23579 == env23580) = true)

theorem identity23580 : scanCanonicalize (H12AffineFastState.compose env23580 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23580 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env23581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,32768,33111,16741,23808,1024,32769,4161,54356,21777,21762,41,65,35188,16401,4097,35188,1364,21792,256,21792,37924,33653]

theorem envBound23581 : H12AffineFastState.Bounded env23581 := by
  intro p hp
  have h : env23581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23580_23581 : H12AffineEnvironment.transform 12 41 env23580 = env23581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23580 == env23581) = true)

theorem identity23581 : scanCanonicalize (H12AffineFastState.compose env23581 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23581 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env23582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,1,342,16741,23808,1024,0,4161,21589,21777,21762,41,65,2421,16401,4097,2421,1364,21792,256,21792,5157,884]

theorem envBound23582 : H12AffineFastState.Bounded env23582 := by
  intro p hp
  have h : env23582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23581_23582 : H12AffineEnvironment.transform 14 1 env23581 = env23582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23581 == env23582) = true)

def env23583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4161,62588,119879,21762,8193,65,75786,115015,102743,35189,1365,119927,256,21792,46092,74251]

theorem envBound23583 : H12AffineFastState.Bounded env23583 := by
  intro p hp
  have h : env23583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23578_23583 : H12AffineEnvironment.transform 6 9 env23578 = env23583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23578 == env23583) = true)

theorem identity23583 : scanCanonicalize (H12AffineFastState.compose env23583 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23583 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24908,56436,1024,32769,4161,62588,62541,21762,8193,65,2048,57677,45405,35189,1365,62589,256,21792,46092,513]

theorem envBound23584 : H12AffineFastState.Bounded env23584 := by
  intro p hp
  have h : env23584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23583_23584 : H12AffineEnvironment.transform 15 8202 env23583 = env23584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23583 == env23584) = true)

theorem identity23584 : scanCanonicalize (H12AffineFastState.compose env23584 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound23584 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env23585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8202,13340,35108,1024,32769,4161,41260,41245,82,8193,65,2048,46109,45405,35189,1365,41261,256,112,46092,513]

theorem envBound23585 : H12AffineFastState.Bounded env23585 := by
  intro p hp
  have h : env23585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23584_23585 : H12AffineEnvironment.transform 13 5456 env23584 = env23585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env23584 == env23585) = true)

theorem identity23585 : scanCanonicalize (H12AffineFastState.compose env23585 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23585 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,343,5441,35108,1024,32769,4161,32881,32832,82,348,65,2048,38208,36864,35189,1365,32880,256,112,38225,513]

theorem envBound23586 : H12AffineFastState.Bounded env23586 := by
  intro p hp
  have h : env23586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23585_23586 : H12AffineEnvironment.transform 12 349 env23585 = env23586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23585 == env23586) = true)

theorem identity23586 : scanCanonicalize (H12AffineFastState.compose env23586 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23586 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23587 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,32768,262,5392,35108,1024,32769,4112,32800,32785,3,269,16,2048,38161,36864,35108,1284,32801,256,33,38144,513]

theorem envBound23587 : H12AffineFastState.Bounded env23587 := by
  intro p hp
  have h : env23587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23586_23587 : H12AffineEnvironment.transform 5 17 env23586 = env23587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23586 == env23587) = true)

theorem identity23587 : scanCanonicalize (H12AffineFastState.compose env23587 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23587 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23588 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,32768,262,4097,35108,273,32769,4112,32800,32785,3,269,16,2048,36864,36864,35108,21,32801,256,33,36881,513]

theorem envBound23588 : H12AffineFastState.Bounded env23588 := by
  intro p hp
  have h : env23588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23587_23588 : H12AffineEnvironment.transform 9 273 env23587 = env23588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23587 == env23588) = true)

theorem identity23588 : scanCanonicalize (H12AffineFastState.compose env23588 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23588 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23589 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,0,262,4097,2340,273,1,4112,32,17,3,269,16,2048,4096,4096,2340,21,33,256,33,4113,513]

theorem envBound23589 : H12AffineFastState.Bounded env23589 := by
  intro p hp
  have h : env23589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23588_23589 : H12AffineEnvironment.transform 14 0 env23588 = env23589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23588 == env23589) = true)

theorem identity23589 : scanCanonicalize (H12AffineFastState.compose env23589 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound23589 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23590 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,293,268,309,0,262,292,2340,273,1,309,32,17,3,269,16,2048,293,293,2340,21,33,256,33,308,513]

theorem envBound23590 : H12AffineFastState.Bounded env23590 := by
  intro p hp
  have h : env23590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23589_23590 : H12AffineEnvironment.transform 11 293 env23589 = env23590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env23589 == env23590) = true)

theorem identity23590 : scanCanonicalize (H12AffineFastState.compose env23590 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound23590 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23591 : List Nat := [2,4,8,16,32,17,9,256,512,273,10,293,268,309,0,262,292,302,273,1,309,32,17,3,269,16,10,293,293,302,21,33,256,33,308,513]

theorem envBound23591 : H12AffineFastState.Bounded env23591 := by
  intro p hp
  have h : env23591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23590_23591 : H12AffineEnvironment.transform 10 10 env23590 = env23591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env23590 == env23591) = true)

theorem identity23591 : scanCanonicalize (H12AffineFastState.compose env23591 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23591 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23592 : List Nat := [2,4,8,16,32,17,9,4,512,21,10,33,8,49,0,2,32,42,21,1,49,32,17,3,9,16,10,33,33,42,21,33,4,33,48,513]

theorem envBound23592 : H12AffineFastState.Bounded env23592 := by
  intro p hp
  have h : env23592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23591_23592 : H12AffineEnvironment.transform 7 4 env23591 = env23592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23591 == env23592) = true)

theorem identity23592 : scanCanonicalize (H12AffineFastState.compose env23592 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23592 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23593 : List Nat := [2,4,8,16,1,17,9,4,512,21,10,0,8,16,0,2,1,11,21,1,16,1,17,3,9,16,10,0,0,11,21,0,4,0,17,513]

theorem envBound23593 : H12AffineFastState.Bounded env23593 := by
  intro p hp
  have h : env23593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23592_23593 : H12AffineEnvironment.transform 4 1 env23592 = env23593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23592 == env23593) = true)

theorem identity23593 : scanCanonicalize (H12AffineFastState.compose env23593 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23594 : List Nat := [2,0,8,16,1,17,9,0,512,17,10,0,8,16,0,2,1,11,17,1,16,1,17,3,9,16,10,0,0,11,17,0,0,0,17,513]

theorem envBound23594 : H12AffineFastState.Bounded env23594 := by
  intro p hp
  have h : env23594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23593_23594 : H12AffineEnvironment.transform 1 0 env23593 = env23594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23593 == env23594) = true)

theorem identity23594 : scanCanonicalize (H12AffineFastState.compose env23594 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound23594 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23595 : List Nat := [2,0,8,16,1,17,9,0,18,17,10,0,8,16,0,2,1,11,17,1,16,1,17,3,9,16,10,0,0,11,17,0,0,0,17,19]

theorem envBound23595 : H12AffineFastState.Bounded env23595 := by
  intro p hp
  have h : env23595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23594_23595 : H12AffineEnvironment.transform 8 18 env23594 = env23595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env23594 == env23595) = true)

theorem identity23595 : scanCanonicalize (H12AffineFastState.compose env23595 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23595 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23596 : List Nat := [2,0,3,16,1,17,2,0,18,17,1,0,3,16,0,2,1,0,17,1,16,1,17,3,2,16,1,0,0,0,17,0,0,0,17,19]

theorem envBound23596 : H12AffineFastState.Bounded env23596 := by
  intro p hp
  have h : env23596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23595_23596 : H12AffineEnvironment.transform 2 3 env23595 = env23596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23595 == env23596) = true)

theorem identity23596 : scanCanonicalize (H12AffineFastState.compose env23596 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23596 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23597 : List Nat := [2,0,3,1,1,0,2,0,3,0,1,0,3,1,0,2,1,0,0,1,1,1,0,3,2,1,1,0,0,0,0,0,0,0,0,2]

theorem envBound23597 : H12AffineFastState.Bounded env23597 := by
  intro p hp
  have h : env23597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23596_23597 : H12AffineEnvironment.transform 3 1 env23596 = env23597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23596 == env23597) = true)

def env23598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4161,62708,120014,21762,8328,65,75787,115150,102878,35324,1500,119926,256,21792,46213,74251]

theorem envBound23598 : H12AffineFastState.Bounded env23598 := by
  intro p hp
  have h : env23598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23577_23598 : H12AffineEnvironment.transform 16 24909 env23577 = env23598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env23577 == env23598) = true)

def env23599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4161,62588,119878,21762,8192,65,75787,115014,102742,35188,1364,119926,256,21792,46093,74251]

theorem envBound23599 : H12AffineFastState.Bounded env23599 := by
  intro p hp
  have h : env23599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23598_23599 : H12AffineEnvironment.transform 6 8 env23598 = env23599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23598 == env23599) = true)

theorem identity23599 : scanCanonicalize (H12AffineFastState.compose env23599 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23599 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13389,108927,1024,32769,4161,41340,98630,2,8192,65,75787,103494,102742,35188,1364,98678,256,32,46093,74251]

theorem envBound23600 : H12AffineFastState.Bounded env23600 := by
  intro p hp
  have h : env23600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23599_23600 : H12AffineEnvironment.transform 13 5376 env23599 = env23600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23599 == env23600) = true)

theorem identity23600 : scanCanonicalize (H12AffineFastState.compose env23600 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23600 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env23601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,65536,13389,76159,1024,1,4161,8572,65862,2,8192,65,75787,70726,69974,2420,1364,65910,256,32,13325,74251]

theorem envBound23601 : H12AffineFastState.Bounded env23601 := by
  intro p hp
  have h : env23601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23600_23601 : H12AffineEnvironment.transform 14 0 env23600 = env23601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23600 == env23601) = true)

theorem identity23601 : scanCanonicalize (H12AffineFastState.compose env23601 (packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound23601 : packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS < 2^1333 := by decide +kernel

def env23602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,8574,13389,2049,1024,1,4161,8572,8248,2,8192,65,2421,13624,12328,2420,1364,8200,256,32,13325,885]

theorem envBound23602 : H12AffineFastState.Bounded env23602 := by
  intro p hp
  have h : env23602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23601_23602 : H12AffineEnvironment.transform 15 8574 env23601 = env23602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env23601 == env23602) = true)

theorem identity23602 : scanCanonicalize (H12AffineFastState.compose env23602 (packedSelected [0,2,4,7,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23602 : packedSelected [0,2,4,7,9,16] rootPS < 2^1333 := by decide +kernel

def env23603 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,0,8202,13389,2049,1024,1,4161,8200,8248,2,8192,65,2049,13388,12328,2048,1056,8200,116,32,13325,513]

theorem envBound23603 : H12AffineFastState.Bounded env23603 := by
  intro p hp
  have h : env23603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23602_23603 : H12AffineEnvironment.transform 7 116 env23602 = env23603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23602 == env23603) = true)

theorem identity23603 : scanCanonicalize (H12AffineFastState.compose env23603 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound23603 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env23604 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1053,5236,0,1047,4176,2049,1024,1,4161,1045,1061,2,1053,65,2049,4177,5173,2048,1056,1045,116,32,4112,513]

theorem envBound23604 : H12AffineFastState.Bounded env23604 := by
  intro p hp
  have h : env23604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23603_23604 : H12AffineEnvironment.transform 12 1053 env23603 = env23604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env23603 == env23604) = true)

theorem identity23604 : scanCanonicalize (H12AffineFastState.compose env23604 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23605 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,40,4161,0,34,4176,2049,53,1,4161,32,16,2,40,65,2049,4177,4096,2048,21,32,116,32,4112,513]

theorem envBound23605 : H12AffineFastState.Bounded env23605 := by
  intro p hp
  have h : env23605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23604_23605 : H12AffineEnvironment.transform 9 53 env23604 = env23605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23604 == env23605) = true)

theorem identity23605 : scanCanonicalize (H12AffineFastState.compose env23605 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound23605 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23606 : List Nat := [2,4,8,16,32,64,8,116,512,53,602,4096,40,4161,0,34,4176,603,53,1,4161,32,16,2,40,65,603,4177,4096,602,21,32,116,32,4112,513]

theorem envBound23606 : H12AffineFastState.Bounded env23606 := by
  intro p hp
  have h : env23606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23605_23606 : H12AffineEnvironment.transform 10 602 env23605 = env23606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env23605 == env23606) = true)

theorem identity23606 : scanCanonicalize (H12AffineFastState.compose env23606 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 70) := by decide +kernel

theorem selectedBound23606 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23607 : List Nat := [2,4,8,16,32,64,8,116,512,53,602,70,40,7,0,34,22,603,53,1,7,32,16,2,40,65,603,23,70,602,21,32,116,32,86,513]

theorem envBound23607 : H12AffineFastState.Bounded env23607 := by
  intro p hp
  have h : env23607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23606_23607 : H12AffineEnvironment.transform 11 70 env23606 = env23607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 70 env23606 == env23607) = true)

theorem identity23607 : scanCanonicalize (H12AffineFastState.compose env23607 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23607 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23608 : List Nat := [2,4,8,16,32,16,8,36,512,53,522,22,40,7,0,34,22,523,53,1,7,32,16,2,40,17,523,23,22,522,21,32,36,32,6,513]

theorem envBound23608 : H12AffineFastState.Bounded env23608 := by
  intro p hp
  have h : env23608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23607_23608 : H12AffineEnvironment.transform 5 16 env23607 = env23608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23607 == env23608) = true)

theorem identity23608 : scanCanonicalize (H12AffineFastState.compose env23608 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 57) := by decide +kernel

theorem selectedBound23608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23609 : List Nat := [2,4,8,16,32,16,8,36,57,53,51,22,40,7,0,34,22,50,53,1,7,32,16,2,40,17,50,23,22,51,21,32,36,32,6,56]

theorem envBound23609 : H12AffineFastState.Bounded env23609 := by
  intro p hp
  have h : env23609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23608_23609 : H12AffineEnvironment.transform 8 57 env23608 = env23609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 57 env23608 == env23609) = true)

theorem identity23609 : scanCanonicalize (H12AffineFastState.compose env23609 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound23609 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23610 : List Nat := [2,4,8,2,32,2,8,36,43,39,33,4,40,7,0,34,4,32,39,1,7,32,2,2,40,3,32,5,4,33,7,32,36,32,6,42]

theorem envBound23610 : H12AffineFastState.Bounded env23610 := by
  intro p hp
  have h : env23610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23609_23610 : H12AffineEnvironment.transform 3 2 env23609 = env23610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env23609 == env23610) = true)

theorem identity23610 : scanCanonicalize (H12AffineFastState.compose env23610 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound23610 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23611 : List Nat := [2,4,8,2,7,2,8,3,12,0,6,4,15,7,0,5,4,7,0,1,7,7,2,2,15,3,7,5,4,6,7,7,3,7,6,13]

theorem envBound23611 : H12AffineFastState.Bounded env23611 := by
  intro p hp
  have h : env23611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23610_23611 : H12AffineEnvironment.transform 4 7 env23610 = env23611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env23610 == env23611) = true)

def env23612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4161,62589,119879,21762,8193,65,75787,115015,102743,35189,1365,119926,256,21792,46092,74251]

theorem envBound23612 : H12AffineFastState.Bounded env23612 := by
  intro p hp
  have h : env23612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23598_23612 : H12AffineEnvironment.transform 6 9 env23598 = env23612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23598 == env23612) = true)

theorem identity23612 : scanCanonicalize (H12AffineFastState.compose env23612 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23612 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,24909,67619,1024,29789,4161,33,73755,21762,8193,65,75787,79131,91403,32041,1365,73770,256,21792,16464,74251]

theorem envBound23613 : H12AffineFastState.Bounded env23613 := by
  intro p hp
  have h : env23613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23612_23613 : H12AffineEnvironment.transform 14 29788 env23612 = env23613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23612 == env23613) = true)

def env23614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound23614 : H12AffineFastState.Bounded env23614 := by
  intro p hp
  have h : env23614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23370_23614 : H12AffineEnvironment.transform 18 1025 env23370 = env23614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23370 == env23614) = true)

theorem identity23614 : scanCanonicalize (H12AffineFastState.compose env23614 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272560) := by decide +kernel

theorem selectedBound23614 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272560,16777216,8328,65,21227696,18973836,2391521,190641,17149088,23160257,257,19262492,19205560,17075062]

theorem envBound23615 : H12AffineFastState.Bounded env23615 := by
  intro p hp
  have h : env23615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23614_23615 : H12AffineEnvironment.transform 22 272560 env23614 = env23615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272560 env23614 == env23615) = true)

def env23616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227576,18973700,2391401,190521,17148968,23160137,257,19262492,19205424,17075062]

theorem envBound23616 : H12AffineFastState.Bounded env23616 := by
  intro p hp
  have h : env23616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23615_23616 : H12AffineEnvironment.transform 6 8 env23615 = env23616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23615 == env23616) = true)

theorem identity23616 : scanCanonicalize (H12AffineFastState.compose env23616 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound23616 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,41310,8192,65,4409702,2172250,2391401,190521,331126,6407191,257,2444610,2468974,272936]

theorem envBound23617 : H12AffineFastState.Bounded env23617 := by
  intro p hp
  have h : env23617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23616_23617 : H12AffineEnvironment.transform 23 41310 env23616 = env23617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env23616 == env23617) = true)

def env23618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,272440,41310,8192,65,4262262,2172250,2391401,43049,331126,6407191,257,2444610,2468974,272936]

theorem envBound23618 : H12AffineFastState.Bounded env23618 := by
  intro p hp
  have h : env23618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23617_23618 : H12AffineEnvironment.transform 16 16400 env23617 = env23618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23617 == env23618) = true)

theorem identity23618 : scanCanonicalize (H12AffineFastState.compose env23618 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound23618 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41310,8192,65,4262262,2172250,2118976,43049,75103,6407191,257,2188651,2196551,513]

theorem envBound23619 : H12AffineFastState.Bounded env23619 := by
  intro p hp
  have h : env23619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23618_23619 : H12AffineEnvironment.transform 17 10281 env23618 = env23619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23618 == env23619) = true)

theorem identity23619 : scanCanonicalize (H12AffineFastState.compose env23619 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound23619 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env23620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115735,4194304,17,41310,8192,65,4262262,57677,102743,43049,75103,4194304,257,41340,16464,513]

theorem envBound23620 : H12AffineFastState.Bounded env23620 := by
  intro p hp
  have h : env23620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23619_23620 : H12AffineEnvironment.transform 20 115735 env23619 = env23620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env23619 == env23620) = true)

theorem identity23620 : scanCanonicalize (H12AffineFastState.compose env23620 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound23620 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env23621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16400,10281,1025,32769,50496,4194304,17,41310,8192,65,4196385,57677,36864,43049,9224,4194304,257,41340,16464,513]

theorem envBound23621 : H12AffineFastState.Bounded env23621 := by
  intro p hp
  have h : env23621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23620_23621 : H12AffineEnvironment.transform 15 343 env23620 = env23621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env23620 == env23621) = true)

theorem identity23621 : scanCanonicalize (H12AffineFastState.compose env23621 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23621 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env23622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16400,10281,1025,8540,25629,4194304,17,3,8192,65,4196385,16400,12637,2420,9224,4194304,257,33,16464,513]

theorem envBound23622 : H12AffineFastState.Bounded env23622 := by
  intro p hp
  have h : env23622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23621_23622 : H12AffineEnvironment.transform 14 8541 env23621 = env23622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23621 == env23622) = true)

theorem identity23622 : scanCanonicalize (H12AffineFastState.compose env23622 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound23622 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16400,10281,1025,8540,25629,8572,17,3,8192,65,10589,16400,12637,2420,9224,8572,257,33,16464,513]

theorem envBound23623 : H12AffineFastState.Bounded env23623 := by
  intro p hp
  have h : env23623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23622_23623 : H12AffineEnvironment.transform 21 8572 env23622 = env23623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env23622 == env23623) = true)

theorem identity23623 : scanCanonicalize (H12AffineFastState.compose env23623 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 9340) := by decide +kernel

theorem selectedBound23623 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env23624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9340,8541,343,9324,10281,1025,8540,97,8572,17,3,8192,65,10589,9324,12637,2420,9224,8572,257,33,9260,513]

theorem envBound23624 : H12AffineFastState.Bounded env23624 := by
  intro p hp
  have h : env23624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23623_23624 : H12AffineEnvironment.transform 13 9340 env23623 = env23624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9340 env23623 == env23624) = true)

theorem identity23624 : scanCanonicalize (H12AffineFastState.compose env23624 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23624 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,1313,0,343,1329,2420,1025,1,97,33,17,3,349,65,2048,1329,4096,2420,1365,33,257,33,1393,513]

theorem envBound23625 : H12AffineFastState.Bounded env23625 := by
  intro p hp
  have h : env23625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23624_23625 : H12AffineEnvironment.transform 12 349 env23624 = env23625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23624 == env23625) = true)

theorem identity23625 : scanCanonicalize (H12AffineFastState.compose env23625 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound23625 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23626 : List Nat := [2,4,8,16,32,64,8,256,512,784,2048,4096,349,561,0,343,545,2420,785,1,97,33,17,3,349,65,2048,545,4096,2420,581,33,257,33,609,513]

theorem envBound23626 : H12AffineFastState.Bounded env23626 := by
  intro p hp
  have h : env23626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23625_23626 : H12AffineEnvironment.transform 9 784 env23625 = env23626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env23625 == env23626) = true)

def env23627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,272440,41310,8192,65,4262263,2172250,2391401,43048,331126,6407191,257,2444610,2468974,272936]

theorem envBound23627 : H12AffineFastState.Bounded env23627 := by
  intro p hp
  have h : env23627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23617_23627 : H12AffineEnvironment.transform 16 16401 env23617 = env23627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23617 == env23627) = true)

def env23628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,58396,4194304,272440,41310,8192,65,4262263,115014,301429,43048,331126,4268043,257,371038,346226,272936]

theorem envBound23628 : H12AffineFastState.Bounded env23628 := by
  intro p hp
  have h : env23628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23627_23628 : H12AffineEnvironment.transform 20 58396 env23627 = env23628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env23627 == env23628) = true)

def env23629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,4194304,16,41310,8192,65,4262263,115014,45405,43048,75102,4268043,257,98678,90202,512]

theorem envBound23629 : H12AffineFastState.Bounded env23629 := by
  intro p hp
  have h : env23629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23628_23629 : H12AffineEnvironment.transform 17 10280 env23628 = env23629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23628 == env23629) = true)

theorem identity23629 : scanCanonicalize (H12AffineFastState.compose env23629 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23629 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23630 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,4194304,16,41002,8192,65,4261891,114738,45097,43048,74794,4268043,117,98306,90202,512]

theorem envBound23630 : H12AffineFastState.Bounded env23630 := by
  intro p hp
  have h : env23630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23629_23630 : H12AffineEnvironment.transform 7 116 env23629 = env23630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23629 == env23630) = true)

theorem identity23630 : scanCanonicalize (H12AffineFastState.compose env23630 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 119927) := by decide +kernel

theorem selectedBound23630 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23631 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,119927,16,41002,8192,65,56436,114738,45097,43048,74794,62588,117,98306,90202,512]

theorem envBound23631 : H12AffineFastState.Bounded env23631 := by
  intro p hp
  have h : env23631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23630_23631 : H12AffineEnvironment.transform 21 119927 env23630 = env23631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119927 env23630 == env23631) = true)

theorem identity23631 : scanCanonicalize (H12AffineFastState.compose env23631 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound23631 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23632 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,29823,16401,10280,1025,32769,58396,40968,16,41002,8192,65,56436,46157,45097,43048,20565,62588,117,62589,5157,512]

theorem envBound23632 : H12AffineFastState.Bounded env23632 := by
  intro p hp
  have h : env23632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23631_23632 : H12AffineEnvironment.transform 15 29823 env23631 = env23632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env23631 == env23632) = true)

theorem identity23632 : scanCanonicalize (H12AffineFastState.compose env23632 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound23632 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23633 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5205,32768,8234,5188,10280,1025,32769,45129,40968,16,41002,8192,65,34849,46157,45097,43048,1024,41001,117,41000,5157,512]

theorem envBound23633 : H12AffineFastState.Bounded env23633 := by
  intro p hp
  have h : env23633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23632_23633 : H12AffineEnvironment.transform 13 5205 env23632 = env23633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env23632 == env23633) = true)

theorem identity23633 : scanCanonicalize (H12AffineFastState.compose env23633 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound23633 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23634 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5205,112,8234,5188,10280,1025,113,12345,8312,16,8282,8192,65,2129,13373,12377,10328,1024,8281,117,8280,5157,512]

theorem envBound23634 : H12AffineFastState.Bounded env23634 := by
  intro p hp
  have h : env23634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23633_23634 : H12AffineEnvironment.transform 14 112 env23633 = env23634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env23633 == env23634) = true)

theorem identity23634 : scanCanonicalize (H12AffineFastState.compose env23634 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound23634 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23635 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2064,8192,3141,112,8234,3156,10280,1025,113,10281,8312,16,8282,8192,65,2129,11309,10313,10328,1024,8281,117,8280,3125,512]

theorem envBound23635 : H12AffineFastState.Bounded env23635 := by
  intro p hp
  have h : env23635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23634_23635 : H12AffineEnvironment.transform 11 2064 env23634 = env23635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env23634 == env23635) = true)

theorem identity23635 : scanCanonicalize (H12AffineFastState.compose env23635 (packedSelected [0,1,2,7,8,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound23635 : packedSelected [0,1,2,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env23636 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,8192,2080,112,8234,2097,10280,100,113,10281,8312,16,8282,8192,65,2129,10312,10313,10328,101,8281,117,8280,2128,512]

theorem envBound23636 : H12AffineFastState.Bounded env23636 := by
  intro p hp
  have h : env23636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23635_23636 : H12AffineEnvironment.transform 9 101 env23635 = env23636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env23635 == env23636) = true)

theorem identity23636 : scanCanonicalize (H12AffineFastState.compose env23636 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound23636 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env23637 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,88,2080,112,114,2097,2160,100,113,2161,32,16,2,88,65,2129,2064,2065,2048,101,1,117,0,2128,512]

theorem envBound23637 : H12AffineFastState.Bounded env23637 := by
  intro p hp
  have h : env23637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23636_23637 : H12AffineEnvironment.transform 12 88 env23636 = env23637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env23636 == env23637) = true)

theorem identity23637 : scanCanonicalize (H12AffineFastState.compose env23637 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23637 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env23638 : List Nat := [2,4,8,16,32,48,8,4,512,21,2048,2064,40,2080,0,2,2097,2048,20,1,2049,32,16,2,40,49,2081,2064,2065,2048,21,1,5,0,2080,512]

theorem envBound23638 : H12AffineFastState.Bounded env23638 := by
  intro p hp
  have h : env23638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23637_23638 : H12AffineEnvironment.transform 5 48 env23637 = env23638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23637 == env23638) = true)

theorem identity23638 : scanCanonicalize (H12AffineFastState.compose env23638 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23638 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23639 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,9,2049,0,2,2064,2048,20,1,2049,1,16,2,9,16,2048,2064,2065,2048,21,1,5,0,2049,512]

theorem envBound23639 : H12AffineFastState.Bounded env23639 := by
  intro p hp
  have h : env23639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23638_23639 : H12AffineEnvironment.transform 4 1 env23638 = env23639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23638 == env23639) = true)

theorem identity23639 : scanCanonicalize (H12AffineFastState.compose env23639 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound23639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23640 : List Nat := [2,4,8,16,1,17,8,4,512,21,20,4,9,21,0,2,4,20,20,1,21,1,16,2,9,16,20,4,5,20,21,1,5,0,21,512]

theorem envBound23640 : H12AffineFastState.Bounded env23640 := by
  intro p hp
  have h : env23640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23639_23640 : H12AffineEnvironment.transform 10 20 env23639 = env23640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env23639 == env23640) = true)

theorem identity23640 : scanCanonicalize (H12AffineFastState.compose env23640 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound23640 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23641 : List Nat := [2,4,8,16,1,17,8,4,7,21,20,4,9,21,0,2,4,20,20,1,21,1,16,2,9,16,20,4,5,20,21,1,5,0,21,7]

theorem envBound23641 : H12AffineFastState.Bounded env23641 := by
  intro p hp
  have h : env23641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23640_23641 : H12AffineEnvironment.transform 8 7 env23640 = env23641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env23640 == env23641) = true)

theorem identity23641 : scanCanonicalize (H12AffineFastState.compose env23641 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound23641 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23642 : List Nat := [2,4,8,9,1,8,8,4,7,12,13,4,9,12,0,2,4,13,13,1,12,1,9,2,9,9,13,4,5,13,12,1,5,0,12,7]

theorem envBound23642 : H12AffineFastState.Bounded env23642 := by
  intro p hp
  have h : env23642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23641_23642 : H12AffineEnvironment.transform 3 9 env23641 = env23642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env23641 == env23642) = true)

def env23643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,4194304,17,41310,8192,65,4262263,115014,45404,43048,75103,4268043,257,98679,90203,513]

theorem envBound23643 : H12AffineFastState.Bounded env23643 := by
  intro p hp
  have h : env23643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23628_23643 : H12AffineEnvironment.transform 17 10281 env23628 = env23643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23628 == env23643) = true)

theorem identity23643 : scanCanonicalize (H12AffineFastState.compose env23643 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23643 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58396,4194304,17,41310,8192,65,4204924,57677,45404,43048,1364,4194304,257,41340,16464,513]

theorem envBound23644 : H12AffineFastState.Bounded env23644 := by
  intro p hp
  have h : env23644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23643_23644 : H12AffineEnvironment.transform 15 8203 env23643 = env23644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23643 == env23644) = true)

theorem identity23644 : scanCanonicalize (H12AffineFastState.compose env23644 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound23644 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env23645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58396,113,17,41310,8192,65,10509,57677,45404,43048,1364,113,257,41340,16464,513]

theorem envBound23645 : H12AffineFastState.Bounded env23645 := by
  intro p hp
  have h : env23645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23644_23645 : H12AffineEnvironment.transform 21 113 env23644 = env23645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env23644 == env23645) = true)

theorem identity23645 : scanCanonicalize (H12AffineFastState.compose env23645 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23645 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,16401,2421,1025,32769,50496,113,17,32770,348,65,2129,49169,36864,35188,1364,113,257,32800,16464,513]

theorem envBound23646 : H12AffineFastState.Bounded env23646 := by
  intro p hp
  have h : env23646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23645_23646 : H12AffineEnvironment.transform 12 348 env23645 = env23646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23645 == env23646) = true)

theorem identity23646 : scanCanonicalize (H12AffineFastState.compose env23646 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23646 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23647 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16401,2341,1025,32769,50448,33,17,32770,268,17,2049,49169,36864,35108,1284,33,257,32800,16384,513]

theorem envBound23647 : H12AffineFastState.Bounded env23647 := by
  intro p hp
  have h : env23647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23646_23647 : H12AffineEnvironment.transform 5 16 env23646 = env23647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23646 == env23647) = true)

theorem identity23647 : scanCanonicalize (H12AffineFastState.compose env23647 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23647 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23648 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16401,2341,1025,0,17681,33,17,3,268,17,2049,16400,4097,2341,1284,33,257,33,16384,513]

theorem envBound23648 : H12AffineFastState.Bounded env23648 := by
  intro p hp
  have h : env23648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23647_23648 : H12AffineEnvironment.transform 14 1 env23647 = env23648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23647 == env23648) = true)

theorem identity23648 : scanCanonicalize (H12AffineFastState.compose env23648 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23649 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1025,0,4113,33,17,3,268,17,2049,5392,4097,2341,1284,33,257,33,5376,513]

theorem envBound23649 : H12AffineFastState.Bounded env23649 := by
  intro p hp
  have h : env23649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23648_23649 : H12AffineEnvironment.transform 13 5376 env23648 = env23649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23648 == env23649) = true)

theorem identity23649 : scanCanonicalize (H12AffineFastState.compose env23649 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound23649 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23650 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,268,1077,1,263,1060,2341,1025,0,292,33,17,3,268,17,2049,1061,308,2341,1284,33,257,33,1077,513]

theorem envBound23650 : H12AffineFastState.Bounded env23650 := by
  intro p hp
  have h : env23650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23649_23650 : H12AffineEnvironment.transform 11 309 env23649 = env23650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env23649 == env23650) = true)

def env23651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,58397,4194304,272440,41310,8192,65,4262263,115015,301428,43048,331126,4268042,257,371039,346227,272936]

theorem envBound23651 : H12AffineFastState.Bounded env23651 := by
  intro p hp
  have h : env23651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23627_23651 : H12AffineEnvironment.transform 20 58397 env23627 = env23651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env23627 == env23651) = true)

def env23652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,4194304,16,41310,8192,65,4262263,115015,45404,43048,75102,4268042,257,98679,90203,512]

theorem envBound23652 : H12AffineFastState.Bounded env23652 := by
  intro p hp
  have h : env23652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23651_23652 : H12AffineEnvironment.transform 17 10280 env23651 = env23652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23651 == env23652) = true)

theorem identity23652 : scanCanonicalize (H12AffineFastState.compose env23652 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23652 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23653 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,4194304,16,41003,8192,65,4261890,114738,45097,43048,74795,4268042,116,98306,90203,512]

theorem envBound23653 : H12AffineFastState.Bounded env23653 := by
  intro p hp
  have h : env23653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23652_23653 : H12AffineEnvironment.transform 7 117 env23652 = env23653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23652 == env23653) = true)

theorem identity23653 : scanCanonicalize (H12AffineFastState.compose env23653 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound23653 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23654 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,62589,16,41003,8192,65,130175,114738,45097,43048,74795,119927,116,98306,90203,512]

theorem envBound23654 : H12AffineFastState.Bounded env23654 := by
  intro p hp
  have h : env23654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23653_23654 : H12AffineEnvironment.transform 21 62589 env23653 = env23654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env23653 == env23654) = true)

theorem identity23654 : scanCanonicalize (H12AffineFastState.compose env23654 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound23654 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23655 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,32768,65536,5221,10280,1025,32769,45161,40969,16,41003,8192,65,108555,103494,45097,43048,74795,98307,116,98306,78895,512]

theorem envBound23655 : H12AffineFastState.Bounded env23655 := by
  intro p hp
  have h : env23655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23654_23655 : H12AffineEnvironment.transform 13 5236 env23654 = env23655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env23654 == env23655) = true)

theorem identity23655 : scanCanonicalize (H12AffineFastState.compose env23655 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound23655 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23656 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8200,65536,5221,10280,1025,8201,4193,1,16,35,8192,65,67587,78926,4129,2080,74795,73739,116,73738,78895,512]

theorem envBound23656 : H12AffineFastState.Bounded env23656 := by
  intro p hp
  have h : env23656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23655_23656 : H12AffineEnvironment.transform 14 8200 env23655 = env23656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env23655 == env23656) = true)

theorem identity23656 : scanCanonicalize (H12AffineFastState.compose env23656 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound23656 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env23657 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1093,65536,5221,3173,1025,1092,4193,1,16,35,1101,65,67587,69635,4129,2080,65638,66630,116,66631,69730,512]

theorem envBound23657 : H12AffineFastState.Bounded env23657 := by
  intro p hp
  have h : env23657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23656_23657 : H12AffineEnvironment.transform 12 1101 env23656 = env23657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env23656 == env23657) = true)

theorem identity23657 : scanCanonicalize (H12AffineFastState.compose env23657 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 6162) := by decide +kernel

theorem selectedBound23657 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env23658 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1093,6162,5221,3173,1025,1092,4193,1,16,35,1101,65,4113,2065,4129,2080,6260,7252,116,7253,2160,512]

theorem envBound23658 : H12AffineFastState.Bounded env23658 := by
  intro p hp
  have h : env23658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23657_23658 : H12AffineEnvironment.transform 15 6162 env23657 = env23658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6162 env23657 == env23658) = true)

theorem identity23658 : scanCanonicalize (H12AffineFastState.compose env23658 (packedSelected [1,2,6,8,10,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23658 : packedSelected [1,2,6,8,10,18] rootPS < 2^1333 := by decide +kernel

def env23659 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,120,4161,112,6162,4176,2128,52,113,4193,1,16,35,120,65,4113,2065,4129,2080,6260,6241,116,6240,2160,512]

theorem envBound23659 : H12AffineFastState.Bounded env23659 := by
  intro p hp
  have h : env23659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23658_23659 : H12AffineEnvironment.transform 9 53 env23658 = env23659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23658 == env23659) = true)

theorem identity23659 : scanCanonicalize (H12AffineFastState.compose env23659 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound23659 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23660 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2096,120,2161,112,34,2144,2128,52,113,2129,1,16,35,120,65,2081,2065,2065,2080,68,81,116,80,2160,512]

theorem envBound23660 : H12AffineFastState.Bounded env23660 := by
  intro p hp
  have h : env23660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23659_23660 : H12AffineEnvironment.transform 11 2096 env23659 = env23660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env23659 == env23660) = true)

def env23661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,4194304,17,41310,8192,65,4262263,115015,45405,43048,75103,4268042,257,98678,90202,513]

theorem envBound23661 : H12AffineFastState.Bounded env23661 := by
  intro p hp
  have h : env23661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23651_23661 : H12AffineEnvironment.transform 17 10281 env23651 = env23661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23651 == env23661) = true)

theorem identity23661 : scanCanonicalize (H12AffineFastState.compose env23661 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23661 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env23662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,17729,4194304,17,2,8192,65,4262263,90139,4097,2420,75103,4268042,257,73770,90202,513]

theorem envBound23662 : H12AffineFastState.Bounded env23662 := by
  intro p hp
  have h : env23662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23661_23662 : H12AffineEnvironment.transform 14 8540 env23661 = env23662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23661 == env23662) = true)

theorem identity23662 : scanCanonicalize (H12AffineFastState.compose env23662 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound23662 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env23663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,263,16401,10281,1025,8541,17729,4194304,17,2,8192,65,4196464,24860,4097,2420,9304,4202765,257,8493,24925,513]

theorem envBound23663 : H12AffineFastState.Bounded env23663 := by
  intro p hp
  have h : env23663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23662_23663 : H12AffineEnvironment.transform 15 263 env23662 = env23663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env23662 == env23663) = true)

theorem identity23663 : scanCanonicalize (H12AffineFastState.compose env23663 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound23663 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,263,16401,10281,1025,8541,17729,113,17,2,8192,65,2049,24860,4097,2420,9304,8572,257,8493,24925,513]

theorem envBound23664 : H12AffineFastState.Bounded env23664 := by
  intro p hp
  have h : env23664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23663_23664 : H12AffineEnvironment.transform 21 113 env23663 = env23664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env23663 == env23664) = true)

theorem identity23664 : scanCanonicalize (H12AffineFastState.compose env23664 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23664 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23665 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,263,16401,10281,1025,8461,17681,33,17,2,8192,17,2049,24860,4097,2340,9224,8492,257,8493,24845,513]

theorem envBound23665 : H12AffineFastState.Bounded env23665 := by
  intro p hp
  have h : env23665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23664_23665 : H12AffineEnvironment.transform 5 16 env23664 = env23665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23664 == env23665) = true)

def env23666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272441,16777216,8193,65,21227577,18973701,2391400,190520,17148969,23160136,257,19262492,19205425,17075062]

theorem envBound23666 : H12AffineFastState.Bounded env23666 := by
  intro p hp
  have h : env23666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23615_23666 : H12AffineEnvironment.transform 6 9 env23615 = env23666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23615 == env23666) = true)

theorem identity23666 : scanCanonicalize (H12AffineFastState.compose env23666 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound23666 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272441,3,8193,65,4450362,2196486,2391400,190520,371754,6382923,257,2485279,2428210,297845]

theorem envBound23667 : H12AffineFastState.Bounded env23667 := by
  intro p hp
  have h : env23667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23666_23667 : H12AffineEnvironment.transform 23 3 env23666 = env23667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env23666 == env23667) = true)

theorem identity23667 : scanCanonicalize (H12AffineFastState.compose env23667 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23667 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env23668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,2097152,4194304,272441,3,8193,65,4229152,2196486,2391400,100386,371754,6382923,257,2485279,2428210,297845]

theorem envBound23668 : H12AffineFastState.Bounded env23668 := by
  intro p hp
  have h : env23668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23667_23668 : H12AffineEnvironment.transform 16 90138 env23667 = env23668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23667 == env23668) = true)

def env23669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,41293,3,8193,65,4229152,2196486,2159644,100386,75102,6382923,257,2188651,2196550,513]

theorem envBound23669 : H12AffineFastState.Bounded env23669 := by
  intro p hp
  have h : env23669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23668_23669 : H12AffineEnvironment.transform 17 35188 env23668 = env23669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env23668 == env23669) = true)

def env23670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35108,1025,32769,2097152,4194304,41245,3,8193,17,4229152,2196486,2159644,100386,75022,6382875,257,2188603,2196502,513]

theorem envBound23670 : H12AffineFastState.Bounded env23670 := by
  intro p hp
  have h : env23670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23669_23670 : H12AffineEnvironment.transform 5 16 env23669 = env23670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23669 == env23670) = true)

theorem identity23670 : scanCanonicalize (H12AffineFastState.compose env23670 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23670 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env23671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,2340,1025,1,2097152,4194304,8477,3,8193,17,4196384,2163718,2126876,67618,75022,6382875,257,2188603,2163734,513]

theorem envBound23671 : H12AffineFastState.Bounded env23671 := by
  intro p hp
  have h : env23671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23670_23671 : H12AffineEnvironment.transform 14 0 env23670 = env23671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23670 == env23671) = true)

theorem identity23671 : scanCanonicalize (H12AffineFastState.compose env23671 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2102561) := by decide +kernel

theorem selectedBound23671 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env23672 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,2340,1025,1,2097152,2102561,8477,3,8193,17,2104577,2163718,2126876,67618,75022,94266,257,2188603,2163734,513]

theorem envBound23672 : H12AffineFastState.Bounded env23672 := by
  intro p hp
  have h : env23672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23671_23672 : H12AffineEnvironment.transform 21 2102561 env23671 = env23672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102561 env23671 == env23672) = true)

theorem identity23672 : scanCanonicalize (H12AffineFastState.compose env23672 (packedSelected [0,1,2,4,5,6,7,8,9,14,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound23672 : packedSelected [0,1,2,4,5,6,7,8,9,14,17,24] rootPS < 2^1333 := by decide +kernel

def env23673 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,20759,12557,2340,1025,1,2097152,2102561,8477,3,8193,17,2104577,2118929,2126876,22837,29721,8493,257,2110508,2118913,513]

theorem envBound23673 : H12AffineFastState.Bounded env23673 := by
  intro p hp
  have h : env23673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23672_23673 : H12AffineEnvironment.transform 15 20759 env23672 = env23673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env23672 == env23673) = true)

theorem identity23673 : scanCanonicalize (H12AffineFastState.compose env23673 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(20+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23673 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23674 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,20759,12557,2340,1025,1,5376,33,8477,3,8193,17,2049,16401,24860,22837,29721,8493,257,8492,16385,513]

theorem envBound23674 : H12AffineFastState.Bounded env23674 := by
  intro p hp
  have h : env23674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23673_23674 : H12AffineEnvironment.transform 20 5376 env23673 = env23674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5376 env23673 == env23674) = true)

theorem identity23674 : scanCanonicalize (H12AffineFastState.compose env23674 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23674 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23675 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,20759,4097,2340,1025,1,5376,33,17,3,269,17,2049,16401,16400,22837,21781,33,257,32,16385,513]

theorem envBound23675 : H12AffineFastState.Bounded env23675 := by
  intro p hp
  have h : env23675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23674_23675 : H12AffineEnvironment.transform 12 268 env23674 = env23675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23674 == env23675) = true)

theorem identity23675 : scanCanonicalize (H12AffineFastState.compose env23675 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound23675 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23676 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,4112,0,263,4097,2340,1025,1,5376,33,17,3,269,17,2049,4097,4096,2341,1285,33,257,32,4113,513]

theorem envBound23676 : H12AffineFastState.Bounded env23676 := by
  intro p hp
  have h : env23676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23675_23676 : H12AffineEnvironment.transform 13 4112 env23675 = env23676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env23675 == env23676) = true)

def env23677 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35109,1025,32769,2097152,4194304,41244,3,8193,16,4229152,2196486,2159644,100386,75023,6382874,257,2188602,2196503,513]

theorem envBound23677 : H12AffineFastState.Bounded env23677 := by
  intro p hp
  have h : env23677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23669_23677 : H12AffineEnvironment.transform 5 17 env23669 = env23677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23669 == env23677) = true)

theorem identity23677 : scanCanonicalize (H12AffineFastState.compose env23677 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound23677 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env23678 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,262,24860,35109,1025,32769,2097152,4194304,41244,3,8193,16,4229152,2131200,2159644,35108,9225,6317084,257,2122812,2131217,513]

theorem envBound23678 : H12AffineFastState.Bounded env23678 := by
  intro p hp
  have h : env23678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23677_23678 : H12AffineEnvironment.transform 15 262 env23677 = env23678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env23677 == env23678) = true)

theorem identity23678 : scanCanonicalize (H12AffineFastState.compose env23678 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound23678 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env23679 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,262,24860,35109,1025,32769,58397,4194304,41244,3,8193,16,4229152,24861,4097,35108,9225,4227073,257,32801,24844,513]

theorem envBound23679 : H12AffineFastState.Bounded env23679 := by
  intro p hp
  have h : env23679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23678_23679 : H12AffineEnvironment.transform 20 58397 env23678 = env23679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env23678 == env23679) = true)

theorem identity23679 : scanCanonicalize (H12AffineFastState.compose env23679 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 20496) := by decide +kernel

theorem selectedBound23679 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env23680 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,20496,262,24860,22837,1025,20497,13325,4194304,28940,3,8193,16,4216880,24861,4097,22836,9225,4214801,257,20529,24844,513]

theorem envBound23680 : H12AffineFastState.Bounded env23680 := by
  intro p hp
  have h : env23680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23679_23680 : H12AffineEnvironment.transform 14 20496 env23679 = env23680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20496 env23679 == env23680) = true)

theorem identity23680 : scanCanonicalize (H12AffineFastState.compose env23680 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound23680 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23681 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,20496,262,24860,22837,1025,20497,13325,8492,28940,3,8193,16,31004,24861,4097,22836,9225,28989,257,20529,24844,513]

theorem envBound23681 : H12AffineFastState.Bounded env23681 := by
  intro p hp
  have h : env23681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23680_23681 : H12AffineEnvironment.transform 21 8492 env23680 = env23681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env23680 == env23681) = true)

theorem identity23681 : scanCanonicalize (H12AffineFastState.compose env23681 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23681 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23682 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,20496,262,16401,22837,1025,20497,5376,33,20481,3,268,16,22545,16400,4097,22836,1284,20528,257,20529,16385,513]

theorem envBound23682 : H12AffineFastState.Bounded env23682 := by
  intro p hp
  have h : env23682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23681_23682 : H12AffineEnvironment.transform 12 269 env23681 = env23682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23681 == env23682) = true)

theorem identity23682 : scanCanonicalize (H12AffineFastState.compose env23682 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound23682 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23683 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,4113,1,262,4096,2340,1025,0,5376,33,16,3,268,16,2048,4097,4097,2341,1284,33,257,32,4112,513]

theorem envBound23683 : H12AffineFastState.Bounded env23683 := by
  intro p hp
  have h : env23683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23682_23683 : H12AffineEnvironment.transform 13 4113 env23682 = env23683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env23682 == env23683) = true)

theorem identity23683 : scanCanonicalize (H12AffineFastState.compose env23683 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound23683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23684 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1044,269,1029,1,262,1044,2340,1025,0,276,33,16,3,268,16,2048,1045,1045,2341,1284,33,257,32,1028,513]

theorem envBound23684 : H12AffineFastState.Bounded env23684 := by
  intro p hp
  have h : env23684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23683_23684 : H12AffineEnvironment.transform 11 1044 env23683 = env23684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env23683 == env23684) = true)

theorem identity23684 : scanCanonicalize (H12AffineFastState.compose env23684 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound23684 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23685 : List Nat := [2,4,8,16,32,17,9,256,276,1024,2048,1044,269,1029,1,262,1044,2340,1025,0,276,33,16,3,268,16,2048,1045,1045,2341,1284,33,257,32,1028,277]

theorem envBound23685 : H12AffineFastState.Bounded env23685 := by
  intro p hp
  have h : env23685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23684_23685 : H12AffineEnvironment.transform 8 276 env23684 = env23685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env23684 == env23685) = true)

theorem identity23685 : scanCanonicalize (H12AffineFastState.compose env23685 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound23685 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23686 : List Nat := [2,4,8,16,32,17,9,256,276,1024,1296,1044,269,1029,1,262,1044,1076,1025,0,276,33,16,3,268,16,1296,1045,1045,1077,1284,33,257,32,1028,277]

theorem envBound23686 : H12AffineFastState.Bounded env23686 := by
  intro p hp
  have h : env23686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23685_23686 : H12AffineEnvironment.transform 10 1296 env23685 = env23686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env23685 == env23686) = true)

theorem identity23686 : scanCanonicalize (H12AffineFastState.compose env23686 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23686 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23687 : List Nat := [2,4,8,16,1,17,9,256,276,1024,1296,1044,269,1029,1,262,1044,1045,1025,0,276,0,16,3,268,16,1296,1045,1045,1044,1284,0,257,1,1028,277]

theorem envBound23687 : H12AffineFastState.Bounded env23687 := by
  intro p hp
  have h : env23687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23686_23687 : H12AffineEnvironment.transform 4 1 env23686 = env23687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23686 == env23687) = true)

theorem identity23687 : scanCanonicalize (H12AffineFastState.compose env23687 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23687 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23688 : List Nat := [2,4,2,16,1,17,3,256,276,1024,1296,1044,263,1029,1,262,1044,1045,1025,0,276,0,16,3,262,16,1296,1045,1045,1044,1284,0,257,1,1028,277]

theorem envBound23688 : H12AffineFastState.Bounded env23688 := by
  intro p hp
  have h : env23688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23687_23688 : H12AffineEnvironment.transform 2 2 env23687 = env23688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23687 == env23688) = true)

def env23689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,41292,3,8193,65,4229152,2196486,2159645,100386,75103,6382923,257,2188650,2196551,512]

theorem envBound23689 : H12AffineFastState.Bounded env23689 := by
  intro p hp
  have h : env23689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23668_23689 : H12AffineEnvironment.transform 17 35189 env23668 = env23689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env23668 == env23689) = true)

theorem identity23689 : scanCanonicalize (H12AffineFastState.compose env23689 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound23689 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,17461,4194304,41292,3,8193,65,4229152,114739,45096,100386,75103,4268414,257,74079,114802,512]

theorem envBound23690 : H12AffineFastState.Bounded env23690 := by
  intro p hp
  have h : env23690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23689_23690 : H12AffineEnvironment.transform 20 17461 env23689 = env23690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env23689 == env23690) = true)

theorem identity23690 : scanCanonicalize (H12AffineFastState.compose env23690 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound23690 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,65536,90138,31836,1025,29992,17461,4194304,21605,3,8193,65,4226313,79130,17665,97547,75103,4268414,257,74079,79195,512]

theorem envBound23691 : H12AffineFastState.Bounded env23691 := by
  intro p hp
  have h : env23691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23690_23691 : H12AffineEnvironment.transform 14 29993 env23690 = env23691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env23690 == env23691) = true)

theorem identity23691 : scanCanonicalize (H12AffineFastState.compose env23691 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound23691 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env23692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,65536,90138,31836,1025,29992,17461,32,21605,3,8193,65,32041,79130,17665,97547,75103,74078,257,74079,79195,512]

theorem envBound23692 : H12AffineFastState.Bounded env23692 := by
  intro p hp
  have h : env23692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23691_23692 : H12AffineEnvironment.transform 21 32 env23691 = env23692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env23691 == env23692) = true)

theorem identity23692 : scanCanonicalize (H12AffineFastState.compose env23692 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23692 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env23693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8203,16401,31836,1025,29992,17461,32,21605,3,8193,65,32041,5393,17665,23808,1364,341,257,340,5456,512]

theorem envBound23693 : H12AffineFastState.Bounded env23693 := by
  intro p hp
  have h : env23693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23692_23693 : H12AffineEnvironment.transform 15 8203 env23692 = env23693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23692 == env23693) = true)

theorem identity23693 : scanCanonicalize (H12AffineFastState.compose env23693 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound23693 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,16384,21589,375,16401,23840,1025,21588,17461,32,21605,3,381,65,23637,5393,17665,23808,1364,341,257,340,5456,512]

theorem envBound23694 : H12AffineFastState.Bounded env23694 := by
  intro p hp
  have h : env23694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23693_23694 : H12AffineEnvironment.transform 12 380 env23693 = env23694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env23693 == env23694) = true)

theorem identity23694 : scanCanonicalize (H12AffineFastState.compose env23694 (packedSelected [6,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound23694 : packedSelected [6,14,17] rootPS < 2^1333 := by decide +kernel

def env23695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,5124,81,375,5141,2340,1025,80,4145,32,97,3,381,65,2129,5393,4357,2308,1364,341,257,340,5456,512]

theorem envBound23695 : H12AffineFastState.Bounded env23695 := by
  intro p hp
  have h : env23695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23694_23695 : H12AffineEnvironment.transform 13 5124 env23694 = env23695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env23694 == env23695) = true)

theorem identity23695 : scanCanonicalize (H12AffineFastState.compose env23695 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23695 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23696 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5124,81,342,5141,2309,1025,80,4112,1,64,3,348,65,2129,5393,4357,2308,1364,341,257,340,5456,512]

theorem envBound23696 : H12AffineFastState.Bounded env23696 := by
  intro p hp
  have h : env23696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23695_23696 : H12AffineEnvironment.transform 4 1 env23695 = env23696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23695 == env23696) = true)

theorem identity23696 : scanCanonicalize (H12AffineFastState.compose env23696 (packedSelected [2,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23696 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env23697 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,268,5124,0,263,5141,2309,1025,1,4112,1,17,3,269,16,2048,5393,4357,2308,1285,260,257,261,5377,512]

theorem envBound23697 : H12AffineFastState.Bounded env23697 := by
  intro p hp
  have h : env23697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23696_23697 : H12AffineEnvironment.transform 5 17 env23696 = env23697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23696 == env23697) = true)

theorem identity23697 : scanCanonicalize (H12AffineFastState.compose env23697 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound23697 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23698 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,2075,268,3103,0,263,3086,2309,1025,1,2059,1,17,3,269,16,2048,3338,2334,2308,1285,260,257,261,3354,512]

theorem envBound23698 : H12AffineFastState.Bounded env23698 := by
  intro p hp
  have h : env23698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23697_23698 : H12AffineEnvironment.transform 11 2075 env23697 = env23698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env23697 == env23698) = true)

theorem identity23698 : scanCanonicalize (H12AffineFastState.compose env23698 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23698 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23699 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,2075,8,3103,0,3,3086,2049,1025,1,2059,1,17,3,9,16,2048,3086,2074,2048,1025,0,5,1,3102,512]

theorem envBound23699 : H12AffineFastState.Bounded env23699 := by
  intro p hp
  have h : env23699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23698_23699 : H12AffineEnvironment.transform 7 4 env23698 = env23699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23698 == env23699) = true)

theorem identity23699 : scanCanonicalize (H12AffineFastState.compose env23699 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound23699 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23700 : List Nat := [2,4,8,16,1,17,9,4,512,1024,1038,1045,8,17,0,3,0,1039,1025,1,1029,1,17,3,9,16,1038,0,1044,1038,1025,0,5,1,16,512]

theorem envBound23700 : H12AffineFastState.Bounded env23700 := by
  intro p hp
  have h : env23700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23699_23700 : H12AffineEnvironment.transform 10 1038 env23699 = env23700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env23699 == env23700) = true)

theorem identity23700 : scanCanonicalize (H12AffineFastState.compose env23700 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23700 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23701 : List Nat := [2,4,8,16,1,17,9,4,1,1024,1038,1045,8,17,0,3,0,1039,1025,1,1029,1,17,3,9,16,1038,0,1044,1038,1025,0,5,1,16,1]

theorem envBound23701 : H12AffineFastState.Bounded env23701 := by
  intro p hp
  have h : env23701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23700_23701 : H12AffineEnvironment.transform 8 1 env23700 = env23701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23700 == env23701) = true)

theorem identity23701 : scanCanonicalize (H12AffineFastState.compose env23701 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound23701 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23702 : List Nat := [2,4,8,16,1,17,9,4,1,4,10,17,8,17,0,3,0,11,5,1,1,1,17,3,9,16,10,0,16,10,5,0,5,1,16,1]

theorem envBound23702 : H12AffineFastState.Bounded env23702 := by
  intro p hp
  have h : env23702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23701_23702 : H12AffineEnvironment.transform 9 4 env23701 = env23702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env23701 == env23702) = true)

theorem identity23702 : scanCanonicalize (H12AffineFastState.compose env23702 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound23702 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23703 : List Nat := [2,4,8,14,1,15,9,4,1,4,10,15,8,15,0,3,0,11,5,1,1,1,15,3,9,14,10,0,14,10,5,0,5,1,14,1]

theorem envBound23703 : H12AffineFastState.Bounded env23703 := by
  intro p hp
  have h : env23703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23702_23703 : H12AffineEnvironment.transform 3 14 env23702 = env23703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env23702 == env23703) = true)

theorem identity23703 : scanCanonicalize (H12AffineFastState.compose env23703 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23703 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23704 : List Nat := [2,0,8,10,1,11,9,0,1,0,10,11,8,11,0,3,0,11,1,1,1,1,11,3,9,10,10,0,10,10,1,0,1,1,10,1]

theorem envBound23704 : H12AffineFastState.Bounded env23704 := by
  intro p hp
  have h : env23704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23703_23704 : H12AffineEnvironment.transform 1 0 env23703 = env23704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23703 == env23704) = true)

theorem identity23704 : scanCanonicalize (H12AffineFastState.compose env23704 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23705 : List Nat := [1,0,8,9,1,8,9,0,1,0,9,8,8,8,0,0,0,8,1,1,1,1,8,0,9,9,9,0,9,9,1,0,1,1,9,1]

theorem envBound23705 : H12AffineFastState.Bounded env23705 := by
  intro p hp
  have h : env23705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23704_23705 : H12AffineEnvironment.transform 0 1 env23704 = env23705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23704 == env23705) = true)

def env23706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound23706 : H12AffineFastState.Bounded env23706 := by
  intro p hp
  have h : env23706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20772_23706 : H12AffineEnvironment.transform 31 145662401 env20772 = env23706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env20772 == env23706) = true)

def env23707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound23707 : H12AffineFastState.Bounded env23707 := by
  intro p hp
  have h : env23707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23706_23707 : H12AffineEnvironment.transform 29 155254784 env23706 = env23707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env23706 == env23707) = true)

def env23708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound23708 : H12AffineFastState.Bounded env23708 := by
  intro p hp
  have h : env23708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23707_23708 : H12AffineEnvironment.transform 25 64 env23707 = env23708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env23707 == env23708) = true)

def env23709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound23709 : H12AffineFastState.Bounded env23709 := by
  intro p hp
  have h : env23709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23708_23709 : H12AffineEnvironment.transform 26 30393344 env23708 = env23709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env23708 == env23709) = true)

def env23710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound23710 : H12AffineFastState.Bounded env23710 := by
  intro p hp
  have h : env23710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23709_23710 : H12AffineEnvironment.transform 18 1024 env23709 = env23710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env23709 == env23710) = true)

theorem identity23710 : scanCanonicalize (H12AffineFastState.compose env23710 (packedSelected [13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23710 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8192,64,29868032,18973701,10507600,8830976,25265169,23160137,256,27378725,27337992,25207631]

theorem envBound23711 : H12AffineFastState.Bounded env23711 := by
  intro p hp
  have h : env23711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23710_23711 : H12AffineEnvironment.transform 6 8 env23710 = env23711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23710 == env23711) = true)

def env23712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147456,16777216,8192,64,21331968,18973701,2233680,294912,17024017,23160137,256,19104805,19096840,16966479]

theorem envBound23712 : H12AffineFastState.Bounded env23712 := by
  intro p hp
  have h : env23712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23711_23712 : H12AffineEnvironment.transform 22 147456 env23711 = env23712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env23711 == env23712) = true)

theorem identity23712 : scanCanonicalize (H12AffineFastState.compose env23712 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound23712 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147456,188750,8192,64,4677966,2319691,2233680,294912,75103,6521863,256,2188651,2196550,513]

theorem envBound23713 : H12AffineFastState.Bounded env23713 := by
  intro p hp
  have h : env23713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23712_23713 : H12AffineEnvironment.transform 23 188750 env23712 = env23713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env23712 == env23713) = true)

def env23714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,41310,8192,64,4530526,2172251,2118976,294912,75103,6407191,256,2188651,2196550,513]

theorem envBound23714 : H12AffineFastState.Bounded env23714 := by
  intro p hp
  have h : env23714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23713_23714 : H12AffineEnvironment.transform 16 16400 env23713 = env23714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23713 == env23714) = true)

def env23715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41310,8192,64,4530526,115015,45404,294912,75103,4268043,256,98679,90202,513]

theorem envBound23715 : H12AffineFastState.Bounded env23715 := by
  intro p hp
  have h : env23715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23714_23715 : H12AffineEnvironment.transform 20 58396 env23714 = env23715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env23714 == env23715) = true)

theorem identity23715 : scanCanonicalize (H12AffineFastState.compose env23715 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,58396,4194304,16,41310,8192,64,4456789,57676,45404,294912,1364,4194304,256,41340,16465,513]

theorem envBound23716 : H12AffineFastState.Bounded env23716 := by
  intro p hp
  have h : env23716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23715_23716 : H12AffineEnvironment.transform 15 8203 env23715 = env23716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23715 == env23716) = true)

theorem identity23716 : scanCanonicalize (H12AffineFastState.compose env23716 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272472) := by decide +kernel

theorem selectedBound23716 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env23717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,58396,272472,16,41310,8192,64,10509,57676,45404,294912,1364,272472,256,41340,16465,513]

theorem envBound23717 : H12AffineFastState.Bounded env23717 := by
  intro p hp
  have h : env23717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23716_23717 : H12AffineEnvironment.transform 21 272472 env23716 = env23717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272472 env23716 == env23717) = true)

theorem identity23717 : scanCanonicalize (H12AffineFastState.compose env23717 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23717 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env23718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,16400,262144,1024,32769,50448,264532,16,32850,268,64,2049,49216,36944,294912,1364,264532,256,32880,16465,513]

theorem envBound23718 : H12AffineFastState.Bounded env23718 := by
  intro p hp
  have h : env23718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23717_23718 : H12AffineEnvironment.transform 12 268 env23717 = env23718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23717 == env23718) = true)

theorem identity23718 : scanCanonicalize (H12AffineFastState.compose env23718 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound23718 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,16400,2420,1024,32769,50448,32,16,32850,268,64,2049,49216,36944,35188,1364,32,256,32880,16465,513]

theorem envBound23719 : H12AffineFastState.Bounded env23719 := by
  intro p hp
  have h : env23719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23718_23719 : H12AffineEnvironment.transform 17 2420 env23718 = env23719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env23718 == env23719) = true)

theorem identity23719 : scanCanonicalize (H12AffineFastState.compose env23719 (packedSelected [3,5,8,18,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23719 : packedSelected [3,5,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env23720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,1,263,16400,2420,1024,0,17681,32,16,83,268,64,2049,16449,4177,2421,1364,32,256,113,16465,513]

theorem envBound23720 : H12AffineFastState.Bounded env23720 := by
  intro p hp
  have h : env23720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23719_23720 : H12AffineEnvironment.transform 14 1 env23719 = env23720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23719 == env23720) = true)

theorem identity23720 : scanCanonicalize (H12AffineFastState.compose env23720 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound23720 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,4453,1,263,4469,2420,1024,0,5236,32,16,83,268,64,2049,4388,4177,2421,1364,32,256,113,4404,513]

theorem envBound23721 : H12AffineFastState.Bounded env23721 := by
  intro p hp
  have h : env23721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23720_23721 : H12AffineEnvironment.transform 13 4453 env23720 = env23721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env23720 == env23721) = true)

theorem identity23721 : scanCanonicalize (H12AffineFastState.compose env23721 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound23721 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env23722 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,268,4453,1,263,4469,2420,320,0,4404,32,16,83,268,64,2049,4388,4177,2421,20,32,256,113,4404,513]

theorem envBound23722 : H12AffineFastState.Bounded env23722 := by
  intro p hp
  have h : env23722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23721_23722 : H12AffineEnvironment.transform 9 320 env23721 = env23722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23721 == env23722) = true)

theorem identity23722 : scanCanonicalize (H12AffineFastState.compose env23722 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23722 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23723 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,4096,40,4161,1,35,4177,2128,100,0,4112,32,16,83,40,64,2049,4096,4177,2129,20,32,36,113,4112,513]

theorem envBound23723 : H12AffineFastState.Bounded env23723 := by
  intro p hp
  have h : env23723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23722_23723 : H12AffineEnvironment.transform 7 36 env23722 = env23723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23722 == env23723) = true)

def env23724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41310,8192,64,4530526,115014,45405,294912,75103,4268042,256,98678,90203,513]

theorem envBound23724 : H12AffineFastState.Bounded env23724 := by
  intro p hp
  have h : env23724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23714_23724 : H12AffineEnvironment.transform 20 58397 env23714 = env23724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env23714 == env23724) = true)

def env23725 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41230,8192,16,4530446,114966,45325,294912,75023,4268042,256,98598,90123,513]

theorem envBound23725 : H12AffineFastState.Bounded env23725 := by
  intro p hp
  have h : env23725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23724_23725 : H12AffineEnvironment.transform 5 16 env23724 = env23725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23724 == env23725) = true)

theorem identity23725 : scanCanonicalize (H12AffineFastState.compose env23725 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329731) := by decide +kernel

theorem selectedBound23725 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env23726 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,329731,16,41230,8192,16,10509,114966,45325,294912,75023,272393,256,98598,90123,513]

theorem envBound23726 : H12AffineFastState.Bounded env23726 := by
  intro p hp
  have h : env23726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23725_23726 : H12AffineEnvironment.transform 21 329731 env23725 = env23726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329731 env23725 == env23726) = true)

theorem identity23726 : scanCanonicalize (H12AffineFastState.compose env23726 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 108846) := by decide +kernel

theorem selectedBound23726 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env23727 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108846,1024,32769,58397,41261,16,41230,8192,16,10509,114966,45325,76078,75023,98599,256,98598,90123,513]

theorem envBound23727 : H12AffineFastState.Bounded env23727 := by
  intro p hp
  have h : env23727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23726_23727 : H12AffineEnvironment.transform 17 108846 env23726 = env23727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108846 env23726 == env23727) = true)

def env23728 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41231,8192,17,4530447,114967,45324,294912,75022,4268042,256,98599,90122,513]

theorem envBound23728 : H12AffineFastState.Bounded env23728 := by
  intro p hp
  have h : env23728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23724_23728 : H12AffineEnvironment.transform 5 17 env23724 = env23728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23724 == env23728) = true)

theorem identity23728 : scanCanonicalize (H12AffineFastState.compose env23728 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound23728 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env23729 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,272393,16,41231,8192,17,67846,114967,45324,294912,75022,329731,256,98599,90122,513]

theorem envBound23729 : H12AffineFastState.Bounded env23729 := by
  intro p hp
  have h : env23729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23728_23729 : H12AffineEnvironment.transform 21 272393 env23728 = env23729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env23728 == env23729) = true)

theorem identity23729 : scanCanonicalize (H12AffineFastState.compose env23729 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23729 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env23730 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,262144,1024,0,25628,272393,16,8462,8192,17,67846,82198,12557,262145,75022,329731,256,65830,90122,513]

theorem envBound23730 : H12AffineFastState.Bounded env23730 := by
  intro p hp
  have h : env23730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23729_23730 : H12AffineEnvironment.transform 14 1 env23729 = env23730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23729 == env23730) = true)

theorem identity23730 : scanCanonicalize (H12AffineFastState.compose env23730 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23730 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23731 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,10280,1024,0,25628,33,16,8462,8192,17,67846,82198,12557,10281,75022,73771,256,65830,90122,513]

theorem envBound23731 : H12AffineFastState.Bounded env23731 := by
  intro p hp
  have h : env23731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23730_23731 : H12AffineEnvironment.transform 17 10280 env23730 = env23731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23730 == env23731) = true)

def env23732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,17,41311,8192,64,4530527,2172250,2118977,294912,75103,6407190,256,2188651,2196550,513]

theorem envBound23732 : H12AffineFastState.Bounded env23732 := by
  intro p hp
  have h : env23732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23713_23732 : H12AffineEnvironment.transform 16 16401 env23713 = env23732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23713 == env23732) = true)

theorem identity23732 : scanCanonicalize (H12AffineFastState.compose env23732 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23732 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456789,2098512,2118977,294912,1365,6349852,256,2114913,2139212,513]

theorem envBound23733 : H12AffineFastState.Bounded env23733 := by
  intro p hp
  have h : env23733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23732_23733 : H12AffineEnvironment.transform 15 8202 env23732 = env23733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23732 == env23733) = true)

theorem identity23733 : scanCanonicalize (H12AffineFastState.compose env23733 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound23733 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,2097152,32,17,41311,8192,64,262517,2098512,2118977,294912,1365,2155580,256,2114913,2139212,513]

theorem envBound23734 : H12AffineFastState.Bounded env23734 := by
  intro p hp
  have h : env23734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23733_23734 : H12AffineEnvironment.transform 21 32 env23733 = env23734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env23733 == env23734) = true)

theorem identity23734 : scanCanonicalize (H12AffineFastState.compose env23734 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23734 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1024,8541,2097152,32,17,3,8192,64,262517,2098512,2118977,270684,1365,2114912,256,2114913,2098448,513]

theorem envBound23735 : H12AffineFastState.Bounded env23735 := by
  intro p hp
  have h : env23735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23734_23735 : H12AffineEnvironment.transform 14 8540 env23734 = env23735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23734 == env23735) = true)

theorem identity23735 : scanCanonicalize (H12AffineFastState.compose env23735 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 281700) := by decide +kernel

theorem selectedBound23735 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,262144,1024,8541,281700,32,17,3,8192,64,262517,280884,268581,270684,1365,264452,256,264453,280948,513]

theorem envBound23736 : H12AffineFastState.Bounded env23736 := by
  intro p hp
  have h : env23736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23735_23736 : H12AffineEnvironment.transform 20 281700 env23735 = env23736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281700 env23735 == env23736) = true)

theorem identity23736 : scanCanonicalize (H12AffineFastState.compose env23736 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23736 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10280,1024,8541,25676,32,17,3,8192,64,10589,24860,12557,2420,1365,8492,256,8493,24924,513]

theorem envBound23737 : H12AffineFastState.Bounded env23737 := by
  intro p hp
  have h : env23737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23736_23737 : H12AffineEnvironment.transform 17 10280 env23736 = env23737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23736 == env23737) = true)

theorem identity23737 : scanCanonicalize (H12AffineFastState.compose env23737 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound23737 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,16384,1124,1330,16401,3344,1024,1125,16756,32,17,3,1336,64,3173,17444,5173,2420,1365,1044,256,1045,17508,513]

theorem envBound23738 : H12AffineFastState.Bounded env23738 := by
  intro p hp
  have h : env23738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23737_23738 : H12AffineEnvironment.transform 12 1336 env23737 = env23738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env23737 == env23738) = true)

theorem identity23738 : scanCanonicalize (H12AffineFastState.compose env23738 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound23738 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,1336,16384,1124,1330,16401,3344,1024,1125,16756,32,17,3,1336,64,3173,17444,2405,2420,1365,1044,256,1045,17508,513]

theorem envBound23739 : H12AffineFastState.Bounded env23739 := by
  intro p hp
  have h : env23739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23738_23739 : H12AffineEnvironment.transform 11 3408 env23738 = env23739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env23738 == env23739) = true)

theorem identity23739 : scanCanonicalize (H12AffineFastState.compose env23739 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23739 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23740 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2405,269,16384,81,263,16401,2341,53,80,16756,32,17,3,269,64,2128,16401,2405,2420,352,33,256,32,16465,513]

theorem envBound23740 : H12AffineFastState.Bounded env23740 := by
  intro p hp
  have h : env23740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23739_23740 : H12AffineEnvironment.transform 9 53 env23739 = env23740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23739 == env23740) = true)

theorem identity23740 : scanCanonicalize (H12AffineFastState.compose env23740 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23740 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23741 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,2065,121,16384,81,115,16401,2129,53,80,16384,32,17,3,121,64,2128,16401,2065,2048,20,33,116,32,16465,513]

theorem envBound23741 : H12AffineFastState.Bounded env23741 := by
  intro p hp
  have h : env23741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23740_23741 : H12AffineEnvironment.transform 7 116 env23740 = env23741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23740 == env23741) = true)

theorem identity23741 : scanCanonicalize (H12AffineFastState.compose env23741 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound23741 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23742 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,2065,121,1,81,115,16,2129,53,80,1,32,17,3,121,64,2128,16,2065,2048,20,33,116,32,80,513]

theorem envBound23742 : H12AffineFastState.Bounded env23742 := by
  intro p hp
  have h : env23742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23741_23742 : H12AffineEnvironment.transform 13 1 env23741 = env23742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env23741 == env23742) = true)

theorem identity23742 : scanCanonicalize (H12AffineFastState.compose env23742 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23742 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23743 : List Nat := [2,4,8,16,32,64,8,116,512,53,0,17,121,1,81,115,16,81,53,80,1,32,17,3,121,64,80,16,17,0,20,33,116,32,80,513]

theorem envBound23743 : H12AffineFastState.Bounded env23743 := by
  intro p hp
  have h : env23743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23742_23743 : H12AffineEnvironment.transform 10 0 env23742 = env23743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23742 == env23743) = true)

def env23744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147457,16777216,8192,64,21331969,18973701,2233681,294913,17024016,23160137,256,19104804,19096841,16966478]

theorem envBound23744 : H12AffineFastState.Bounded env23744 := by
  intro p hp
  have h : env23744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23711_23744 : H12AffineEnvironment.transform 22 147457 env23711 = env23744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env23711 == env23744) = true)

def env23745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,17,16777216,8192,64,21331969,18973701,2118977,294913,16876544,23160137,256,18990132,18949401,16819038]

theorem envBound23745 : H12AffineFastState.Bounded env23745 := by
  intro p hp
  have h : env23745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23744_23745 : H12AffineEnvironment.transform 16 16400 env23744 = env23745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23744 == env23745) = true)

theorem identity23745 : scanCanonicalize (H12AffineFastState.compose env23745 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 297335) := by decide +kernel

theorem selectedBound23745 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,17,297335,8192,64,4262262,2428274,2118977,294913,331127,6679614,256,2444611,2468974,272937]

theorem envBound23746 : H12AffineFastState.Bounded env23746 := by
  intro p hp
  have h : env23746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23745_23746 : H12AffineEnvironment.transform 23 297335 env23745 = env23746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297335 env23745 == env23746) = true)

def env23747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,17,41311,8192,64,4262262,2172250,2118977,43049,75103,6407190,256,2188651,2196550,513]

theorem envBound23747 : H12AffineFastState.Bounded env23747 := by
  intro p hp
  have h : env23747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23746_23747 : H12AffineEnvironment.transform 17 10280 env23746 = env23747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23746 == env23747) = true)

theorem identity23747 : scanCanonicalize (H12AffineFastState.compose env23747 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23747 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,2097152,4194304,17,41311,8192,64,4204925,2098513,2118977,43049,1364,6349853,256,2114912,2139213,513]

theorem envBound23748 : H12AffineFastState.Bounded env23748 := by
  intro p hp
  have h : env23748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23747_23748 : H12AffineEnvironment.transform 15 8203 env23747 = env23748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23747 == env23748) = true)

theorem identity23748 : scanCanonicalize (H12AffineFastState.compose env23748 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 2155580) := by decide +kernel

theorem selectedBound23748 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,2097152,2155580,17,41311,8192,64,2149697,2098513,2118977,43049,1364,33,256,2114912,2139213,513]

theorem envBound23749 : H12AffineFastState.Bounded env23749 := by
  intro p hp
  have h : env23749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23748_23749 : H12AffineEnvironment.transform 21 2155580 env23748 = env23749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env23748 == env23749) = true)

theorem identity23749 : scanCanonicalize (H12AffineFastState.compose env23749 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23749 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23750 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,2097152,2155580,17,41230,8192,17,2149648,2098432,2118928,43049,1285,33,256,2114865,2139164,513]

theorem envBound23750 : H12AffineFastState.Bounded env23750 := by
  intro p hp
  have h : env23750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23749_23750 : H12AffineEnvironment.transform 5 17 env23749 = env23750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23749 == env23750) = true)

theorem identity23750 : scanCanonicalize (H12AffineFastState.compose env23750 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound23750 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23751 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,25628,32800,17,41230,8192,17,43276,24860,12556,43049,1285,33,256,8493,49152,513]

theorem envBound23751 : H12AffineFastState.Bounded env23751 := by
  intro p hp
  have h : env23751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23750_23751 : H12AffineEnvironment.transform 20 25628 env23750 = env23751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env23750 == env23751) = true)

theorem identity23751 : scanCanonicalize (H12AffineFastState.compose env23751 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23751 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23752 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,262,16400,2341,1024,32769,17681,32800,17,32771,269,17,34817,16401,4097,35108,1285,33,256,32,49152,513]

theorem envBound23752 : H12AffineFastState.Bounded env23752 := by
  intro p hp
  have h : env23752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23751_23752 : H12AffineEnvironment.transform 12 269 env23751 = env23752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23751 == env23752) = true)

def env23753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,2097152,4194304,17,41310,8192,64,4262262,2172251,2118977,43048,75102,6407191,256,2188650,2196551,512]

theorem envBound23753 : H12AffineFastState.Bounded env23753 := by
  intro p hp
  have h : env23753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23746_23753 : H12AffineEnvironment.transform 17 10281 env23746 = env23753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23746 == env23753) = true)

theorem identity23753 : scanCanonicalize (H12AffineFastState.compose env23753 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 58728) := by decide +kernel

theorem selectedBound23753 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,58728,4194304,17,41310,8192,64,4262262,114739,45097,43048,75102,4268415,256,98306,90415,512]

theorem envBound23754 : H12AffineFastState.Bounded env23754 := by
  intro p hp
  have h : env23754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23753_23754 : H12AffineEnvironment.transform 20 58728 env23753 = env23754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58728 env23753 == env23754) = true)

theorem identity23754 : scanCanonicalize (H12AffineFastState.compose env23754 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound23754 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env23755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,58728,41340,17,41310,8192,64,108554,114739,45097,43048,75102,98307,256,98306,90415,512]

theorem envBound23755 : H12AffineFastState.Bounded env23755 := by
  intro p hp
  have h : env23755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23754_23755 : H12AffineEnvironment.transform 21 41340 env23754 = env23755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env23754 == env23755) = true)

theorem identity23755 : scanCanonicalize (H12AffineFastState.compose env23755 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 62842) := by decide +kernel

theorem selectedBound23755 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62842,16400,10281,1024,32769,58728,41340,17,41310,8192,64,23920,13641,45097,43048,53284,30073,256,30072,37973,512]

theorem envBound23756 : H12AffineFastState.Bounded env23756 := by
  intro p hp
  have h : env23756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23755_23756 : H12AffineEnvironment.transform 15 62842 env23755 = env23756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62842 env23755 == env23756) = true)

theorem identity23756 : scanCanonicalize (H12AffineFastState.compose env23756 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21872) := by decide +kernel

theorem selectedBound23756 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env23757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21872,8202,16400,10281,1024,21873,12312,29708,17,29742,8192,64,23920,13641,25945,32088,1364,30073,256,30072,16677,512]

theorem envBound23757 : H12AffineFastState.Bounded env23757 := by
  intro p hp
  have h : env23757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23756_23757 : H12AffineEnvironment.transform 14 21872 env23756 = env23757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21872 env23756 == env23757) = true)

theorem identity23757 : scanCanonicalize (H12AffineFastState.compose env23757 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 3424) := by decide +kernel

theorem selectedBound23757 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env23758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,3424,6160,8202,3440,10281,1024,6161,12312,14700,17,14670,8192,64,4112,13641,10297,12344,1364,14361,256,14360,3141,512]

theorem envBound23758 : H12AffineFastState.Bounded env23758 := by
  intro p hp
  have h : env23758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23757_23758 : H12AffineEnvironment.transform 13 3424 env23757 = env23758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3424 env23757 == env23758) = true)

theorem identity23758 : scanCanonicalize (H12AffineFastState.compose env23758 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound23758 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,8192,3424,1345,8202,3440,10281,1024,1344,11593,9277,17,9247,8192,64,3393,10264,10297,11625,1364,9544,256,9545,3141,512]

theorem envBound23759 : H12AffineFastState.Bounded env23759 := by
  intro p hp
  have h : env23759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23758_23759 : H12AffineEnvironment.transform 11 3409 env23758 = env23759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env23758 == env23759) = true)

theorem identity23759 : scanCanonicalize (H12AffineFastState.compose env23759 (packedSelected [12,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23759 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23760 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,3409,8192,3392,1345,8202,3408,10249,1024,1344,11593,9245,17,9247,8192,64,3393,10264,10265,11593,1364,9544,256,9545,3141,512]

theorem envBound23760 : H12AffineFastState.Bounded env23760 := by
  intro p hp
  have h : env23760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23759_23760 : H12AffineEnvironment.transform 4 0 env23759 = env23760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23759 == env23760) = true)

theorem identity23760 : scanCanonicalize (H12AffineFastState.compose env23760 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23760 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env23761 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,3077,8192,3092,1045,8202,3076,10249,1024,1044,11293,9245,17,9247,8192,64,3093,10264,10265,11293,1024,9244,84,9245,3141,512]

theorem envBound23761 : H12AffineFastState.Bounded env23761 := by
  intro p hp
  have h : env23761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23760_23761 : H12AffineEnvironment.transform 7 84 env23760 = env23761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23760 == env23761) = true)

theorem identity23761 : scanCanonicalize (H12AffineFastState.compose env23761 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound23761 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env23762 : List Nat := [2,4,8,16,0,64,8,84,512,1024,1093,64,8192,81,1045,8202,65,9292,1024,1044,8280,9245,17,9247,8192,64,80,9309,9308,8280,1024,9244,84,9245,0,512]

theorem envBound23762 : H12AffineFastState.Bounded env23762 := by
  intro p hp
  have h : env23762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23761_23762 : H12AffineEnvironment.transform 10 1093 env23761 = env23762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env23761 == env23762) = true)

theorem identity23762 : scanCanonicalize (H12AffineFastState.compose env23762 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound23762 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23763 : List Nat := [2,4,8,16,0,64,8,84,512,69,0,64,8192,81,80,8202,65,8201,69,81,8280,8280,17,8282,8192,64,80,8216,8217,8280,69,8281,84,8280,0,512]

theorem envBound23763 : H12AffineFastState.Bounded env23763 := by
  intro p hp
  have h : env23763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23762_23763 : H12AffineEnvironment.transform 9 69 env23762 = env23763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env23762 == env23763) = true)

theorem identity23763 : scanCanonicalize (H12AffineFastState.compose env23763 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound23763 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23764 : List Nat := [2,4,8,16,0,64,8,84,512,69,0,64,89,81,80,83,65,80,69,81,1,1,17,3,89,64,80,65,64,1,69,0,84,1,0,512]

theorem envBound23764 : H12AffineFastState.Bounded env23764 := by
  intro p hp
  have h : env23764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23763_23764 : H12AffineEnvironment.transform 12 89 env23763 = env23764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env23763 == env23764) = true)

theorem identity23764 : scanCanonicalize (H12AffineFastState.compose env23764 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23764 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23765 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,1,2,16,1,20,0,1,1,17,3,8,17,1,16,17,1,20,0,5,1,0,512]

theorem envBound23765 : H12AffineFastState.Bounded env23765 := by
  intro p hp
  have h : env23765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23764_23765 : H12AffineEnvironment.transform 5 17 env23764 = env23765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23764 == env23765) = true)

theorem identity23765 : scanCanonicalize (H12AffineFastState.compose env23765 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23766 : List Nat := [2,1,8,16,0,17,8,0,512,17,0,17,8,0,1,2,16,1,17,0,1,1,17,3,8,17,1,16,17,1,17,0,0,1,0,512]

theorem envBound23766 : H12AffineFastState.Bounded env23766 := by
  intro p hp
  have h : env23766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23765_23766 : H12AffineEnvironment.transform 1 1 env23765 = env23766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23765 == env23766) = true)

def env23767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973701,2118976,294913,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound23767 : H12AffineFastState.Bounded env23767 := by
  intro p hp
  have h : env23767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23744_23767 : H12AffineEnvironment.transform 16 16401 env23744 = env23767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23744 == env23767) = true)

theorem identity23767 : scanCanonicalize (H12AffineFastState.compose env23767 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound23767 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,41310,8192,64,4530527,2172251,2118976,294913,75103,6407191,256,2188651,2196550,513]

theorem envBound23768 : H12AffineFastState.Bounded env23768 := by
  intro p hp
  have h : env23768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23767_23768 : H12AffineEnvironment.transform 23 41310 env23767 = env23768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env23767 == env23768) = true)

theorem identity23768 : scanCanonicalize (H12AffineFastState.compose env23768 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound23768 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env23769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115735,4194304,16,41310,8192,64,4530527,57676,102743,294913,75103,4194304,256,41340,16465,513]

theorem envBound23769 : H12AffineFastState.Bounded env23769 := by
  intro p hp
  have h : env23769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23768_23769 : H12AffineEnvironment.transform 20 115735 env23768 = env23769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env23768 == env23769) = true)

theorem identity23769 : scanCanonicalize (H12AffineFastState.compose env23769 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23769 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env23770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115735,4194304,16,41310,8192,64,4262263,57676,102743,43049,75103,4194304,256,41340,16465,513]

theorem envBound23770 : H12AffineFastState.Bounded env23770 := by
  intro p hp
  have h : env23770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23769_23770 : H12AffineEnvironment.transform 17 10280 env23769 = env23770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23769 == env23770) = true)

theorem identity23770 : scanCanonicalize (H12AffineFastState.compose env23770 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound23770 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env23771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115735,113,16,41310,8192,64,67846,57676,102743,43049,75103,113,256,41340,16465,513]

theorem envBound23771 : H12AffineFastState.Bounded env23771 := by
  intro p hp
  have h : env23771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23770_23771 : H12AffineEnvironment.transform 21 113 env23770 = env23771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env23770 == env23771) = true)

theorem identity23771 : scanCanonicalize (H12AffineFastState.compose env23771 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound23771 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env23772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,65536,16401,10280,1024,81,83015,113,16,8462,8192,64,67846,24860,69895,10361,75103,113,256,8492,16465,513]

theorem envBound23772 : H12AffineFastState.Bounded env23772 := by
  intro p hp
  have h : env23772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23771_23772 : H12AffineEnvironment.transform 14 80 env23771 = env23772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env23771 == env23772) = true)

theorem identity23772 : scanCanonicalize (H12AffineFastState.compose env23772 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound23772 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env23773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8283,16401,10280,1024,81,25628,113,16,8462,8192,64,10589,24860,12636,10361,1284,113,256,8492,16465,513]

theorem envBound23773 : H12AffineFastState.Bounded env23773 := by
  intro p hp
  have h : env23773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23772_23773 : H12AffineEnvironment.transform 15 8283 env23772 = env23773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env23772 == env23773) = true)

theorem identity23773 : scanCanonicalize (H12AffineFastState.compose env23773 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23773 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,80,263,16401,2420,1024,81,17728,113,16,82,348,64,2049,16448,4096,2341,1284,113,256,112,16465,513]

theorem envBound23774 : H12AffineFastState.Bounded env23774 := by
  intro p hp
  have h : env23774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23773_23774 : H12AffineEnvironment.transform 12 348 env23773 = env23774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23773 == env23774) = true)

def env23775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound23775 : H12AffineFastState.Bounded env23775 := by
  intro p hp
  have h : env23775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23709_23775 : H12AffineEnvironment.transform 18 1025 env23709 = env23775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23709 == env23775) = true)

theorem identity23775 : scanCanonicalize (H12AffineFastState.compose env23775 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642569) := by decide +kernel

theorem selectedBound23775 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0