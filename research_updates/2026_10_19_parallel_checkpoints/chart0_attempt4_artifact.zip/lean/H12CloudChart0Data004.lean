import H12CloudChart0Data003

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity959 : scanCanonicalize (H12AffineFastState.compose env959 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound959 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env960 : List Nat := [2,4,8,1,32,1,40,5,43,4,2048,2081,9,2080,0,34,2081,2081,5,0,2080,32,1,34,41,0,2048,2080,2081,2080,5,1,4,0,2081,42]

theorem envBound960 : H12AffineFastState.Bounded env960 := by
  intro p hp
  have h : env960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans959_960 : H12AffineEnvironment.transform 9 4 env959 = env960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env959 == env960) = true)

theorem identity960 : scanCanonicalize (H12AffineFastState.compose env960 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound960 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env961 : List Nat := [2,4,6,1,32,1,38,5,37,4,2048,2081,7,2080,0,34,2081,2081,5,0,2080,32,1,34,39,0,2048,2080,2081,2080,5,1,4,0,2081,36]

theorem envBound961 : H12AffineFastState.Bounded env961 := by
  intro p hp
  have h : env961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans960_961 : H12AffineEnvironment.transform 2 6 env960 = env961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env960 == env961) = true)

theorem identity961 : scanCanonicalize (H12AffineFastState.compose env961 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound961 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env962 : List Nat := [2,4,6,1,32,1,38,5,37,4,1,32,7,33,0,34,32,32,5,0,33,32,1,34,39,0,1,33,32,33,5,1,4,0,32,36]

theorem envBound962 : H12AffineFastState.Bounded env962 := by
  intro p hp
  have h : env962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans961_962 : H12AffineEnvironment.transform 10 1 env961 = env962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env961 == env962) = true)

theorem identity962 : scanCanonicalize (H12AffineFastState.compose env962 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound962 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env963 : List Nat := [2,4,6,1,2,1,4,5,7,4,1,2,7,3,0,0,2,2,5,0,3,2,1,0,5,0,1,3,2,3,5,1,4,0,2,6]

theorem envBound963 : H12AffineFastState.Bounded env963 := by
  intro p hp
  have h : env963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans962_963 : H12AffineEnvironment.transform 4 2 env962 = env963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env962 == env963) = true)

theorem identity963 : scanCanonicalize (H12AffineFastState.compose env963 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound963 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env964 : List Nat := [0,4,4,1,0,1,4,5,5,4,1,0,5,1,0,0,0,0,5,0,1,0,1,0,5,0,1,1,0,1,5,1,4,0,0,4]

theorem envBound964 : H12AffineFastState.Bounded env964 := by
  intro p hp
  have h : env964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans963_964 : H12AffineEnvironment.transform 0 0 env963 = env964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env963 == env964) = true)

def env965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147472,409816,16384,151553,2080,16852469,4341976,257,0,131073,16925298]

theorem envBound965 : H12AffineFastState.Bounded env965 := by
  intro p hp
  have h : env965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans929_965 : H12AffineEnvironment.transform 34 131073 env929 = env965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env929 == env965) = true)

theorem identity965 : scanCanonicalize (H12AffineFastState.compose env965 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2188705) := by decide +kernel

theorem selectedBound965 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,2188705,8328,147472,409816,16384,151553,2080,2113620,4341976,257,0,131073,2303955]

theorem envBound966 : H12AffineFastState.Bounded env966 := by
  intro p hp
  have h : env966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans965_966 : H12AffineEnvironment.transform 23 2188705 env965 = env966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188705 env965 == env966) = true)

theorem identity966 : scanCanonicalize (H12AffineFastState.compose env966 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(20+1) ^^^ 91435) := by decide +kernel

theorem selectedBound966 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,91435,4194304,147521,138,8328,147472,409816,16384,151553,2080,75135,4341976,257,0,131073,148216]

theorem envBound967 : H12AffineFastState.Bounded env967 := by
  intro p hp
  have h : env967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans966_967 : H12AffineEnvironment.transform 20 91435 env966 = env967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91435 env966 == env967) = true)

theorem identity967 : scanCanonicalize (H12AffineFastState.compose env967 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 147748) := by decide +kernel

theorem selectedBound967 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,91435,147748,147521,138,8328,147472,409816,16384,151553,2080,75135,508,257,0,131073,148216]

theorem envBound968 : H12AffineFastState.Bounded env968 := by
  intro p hp
  have h : env968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans967_968 : H12AffineEnvironment.transform 21 147748 env967 = env968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147748 env967 == env968) = true)

theorem identity968 : scanCanonicalize (H12AffineFastState.compose env968 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound968 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1025,8692,17493,147748,147521,138,8328,147472,409816,16384,151553,2080,1025,508,257,0,131073,148216]

theorem envBound969 : H12AffineFastState.Bounded env969 := by
  intro p hp
  have h : env969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans968_969 : H12AffineEnvironment.transform 15 8574 env968 = env969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env968 == env969) = true)

def env970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,262144,1025,8692,17493,476,185,138,8328,232,262176,16384,4345,2080,1025,508,257,0,16633,512]

theorem envBound970 : H12AffineFastState.Bounded env970 := by
  intro p hp
  have h : env970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans969_970 : H12AffineEnvironment.transform 16 16632 env969 = env970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env969 == env970) = true)

theorem identity970 : scanCanonicalize (H12AffineFastState.compose env970 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound970 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,10281,1025,8692,17493,476,185,138,8328,232,10249,16384,4345,2080,1025,508,257,0,16633,512]

theorem envBound971 : H12AffineFastState.Bounded env971 := by
  intro p hp
  have h : env971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans970_971 : H12AffineEnvironment.transform 17 10281 env970 = env971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env970 == env971) = true)

theorem identity971 : scanCanonicalize (H12AffineFastState.compose env971 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound971 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,16384,80,218,16632,2445,1025,80,17493,476,185,138,300,232,2477,16384,4345,2080,1025,508,257,0,16633,512]

theorem envBound972 : H12AffineFastState.Bounded env972 := by
  intro p hp
  have h : env972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans971_972 : H12AffineEnvironment.transform 12 420 env971 = env972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env971 == env972) = true)

theorem identity972 : scanCanonicalize (H12AffineFastState.compose env972 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound972 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env973 : List Nat := [2,4,8,16,32,64,57,256,512,1024,2048,4096,285,16384,80,99,16449,2356,1025,80,17493,357,0,51,300,81,2324,16384,4160,2080,1025,325,257,0,16448,512]

theorem envBound973 : H12AffineFastState.Bounded env973 := by
  intro p hp
  have h : env973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans972_973 : H12AffineEnvironment.transform 6 57 env972 = env973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env972 == env973) = true)

def env974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16633,262144,1025,8692,17493,477,184,138,8328,233,262177,16384,4344,2080,1025,508,257,0,16632,513]

theorem envBound974 : H12AffineFastState.Bounded env974 := by
  intro p hp
  have h : env974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans969_974 : H12AffineEnvironment.transform 16 16633 env969 = env974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env969 == env974) = true)

theorem identity974 : scanCanonicalize (H12AffineFastState.compose env974 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13809) := by decide +kernel

theorem selectedBound974 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13809,8692,8574,13576,262144,1025,8692,12708,477,184,138,8328,233,262177,13809,4344,2080,1025,508,257,0,13577,513]

theorem envBound975 : H12AffineFastState.Bounded env975 := by
  intro p hp
  have h : env975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans974_975 : H12AffineEnvironment.transform 13 13809 env974 = env975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13809 env974 == env975) = true)

theorem identity975 : scanCanonicalize (H12AffineFastState.compose env975 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound975 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5625,508,374,5376,262144,1025,508,4524,477,184,138,128,233,262177,5625,4344,2080,1025,508,257,0,5377,513]

theorem envBound976 : H12AffineFastState.Bounded env976 := by
  intro p hp
  have h : env976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans975_976 : H12AffineEnvironment.transform 12 8 env975 = env976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env975 == env976) = true)

theorem identity976 : scanCanonicalize (H12AffineFastState.compose env976 (packedSelected [4,6,9,20] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound976 : packedSelected [4,6,9,20] rootPS < 2^1333 := by decide +kernel

def env977 : List Nat := [2,4,8,16,32,64,104,256,512,1024,2048,4096,8,5393,276,374,5376,262144,1025,276,4420,309,80,98,104,1,262177,5393,4112,2080,1025,276,257,0,5377,513]

theorem envBound977 : H12AffineFastState.Bounded env977 := by
  intro p hp
  have h : env977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans976_977 : H12AffineEnvironment.transform 6 104 env976 = env977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env976 == env977) = true)

theorem identity977 : scanCanonicalize (H12AffineFastState.compose env977 (packedSelected [0,2,7,11,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound977 : packedSelected [0,2,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env978 : List Nat := [2,4,8,16,32,64,104,256,512,1024,2048,4096,8,5393,276,374,5376,2341,1025,276,4420,309,80,98,104,1,2308,5393,4112,2080,1025,276,257,0,5377,513]

theorem envBound978 : H12AffineFastState.Bounded env978 := by
  intro p hp
  have h : env978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans977_978 : H12AffineEnvironment.transform 17 2341 env977 = env978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env977 == env978) = true)

theorem identity978 : scanCanonicalize (H12AffineFastState.compose env978 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound978 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env979 : List Nat := [2,4,8,16,32,64,104,21,512,1024,2048,4096,8,5124,1,99,5141,2096,1025,1,4177,32,80,98,104,1,2065,5124,4112,2080,1025,1,20,0,5140,513]

theorem envBound979 : H12AffineFastState.Bounded env979 := by
  intro p hp
  have h : env979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans978_979 : H12AffineEnvironment.transform 7 21 env978 = env979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env978 == env979) = true)

theorem identity979 : scanCanonicalize (H12AffineFastState.compose env979 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound979 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env980 : List Nat := [2,4,8,16,32,64,104,21,512,1024,2048,3189,8,2161,1,99,2144,2096,1025,1,3108,32,80,98,104,1,2065,2161,3173,2080,1025,1,20,0,2145,513]

theorem envBound980 : H12AffineFastState.Bounded env980 := by
  intro p hp
  have h : env980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans979_980 : H12AffineEnvironment.transform 11 3189 env979 = env980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env979 == env980) = true)

theorem identity980 : scanCanonicalize (H12AffineFastState.compose env980 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound980 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env981 : List Nat := [2,4,8,0,32,64,104,5,512,1024,2048,3173,8,2145,1,99,2144,2080,1025,1,3108,32,64,98,104,1,2049,2145,3173,2080,1025,1,4,0,2145,513]

theorem envBound981 : H12AffineFastState.Bounded env981 := by
  intro p hp
  have h : env981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans980_981 : H12AffineEnvironment.transform 3 0 env980 = env981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env980 == env981) = true)

theorem identity981 : scanCanonicalize (H12AffineFastState.compose env981 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound981 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env982 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,3109,8,2081,1,35,2080,2080,1025,1,3108,32,0,34,40,1,2049,2081,3109,2080,1025,1,4,0,2081,513]

theorem envBound982 : H12AffineFastState.Bounded env982 := by
  intro p hp
  have h : env982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans981_982 : H12AffineEnvironment.transform 5 0 env981 = env982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env981 == env982) = true)

theorem identity982 : scanCanonicalize (H12AffineFastState.compose env982 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound982 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env983 : List Nat := [2,4,8,0,32,0,40,5,42,1024,2048,3109,8,2081,1,35,2080,2080,1025,1,3108,32,0,34,40,1,2049,2081,3109,2080,1025,1,4,0,2081,43]

theorem envBound983 : H12AffineFastState.Bounded env983 := by
  intro p hp
  have h : env983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans982_983 : H12AffineEnvironment.transform 8 42 env982 = env983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env982 == env983) = true)

theorem identity983 : scanCanonicalize (H12AffineFastState.compose env983 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env984 : List Nat := [2,4,8,0,32,0,40,5,42,37,2048,2048,8,2081,1,35,2080,2080,36,1,2049,32,0,34,40,1,2049,2081,2048,2080,36,1,4,0,2081,43]

theorem envBound984 : H12AffineFastState.Bounded env984 := by
  intro p hp
  have h : env984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans983_984 : H12AffineEnvironment.transform 9 37 env983 = env984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env983 == env984) = true)

theorem identity984 : scanCanonicalize (H12AffineFastState.compose env984 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env985 : List Nat := [2,4,8,0,12,0,4,5,6,9,2048,2048,8,2061,1,15,2060,2060,8,1,2049,12,0,14,4,1,2049,2061,2048,2060,8,1,4,0,2061,7]

theorem envBound985 : H12AffineFastState.Bounded env985 := by
  intro p hp
  have h : env985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans984_985 : H12AffineEnvironment.transform 4 12 env984 = env985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env984 == env985) = true)

theorem identity985 : scanCanonicalize (H12AffineFastState.compose env985 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound985 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env986 : List Nat := [2,4,8,0,12,0,4,5,6,9,0,0,8,13,1,15,12,12,8,1,1,12,0,14,4,1,1,13,0,12,8,1,4,0,13,7]

theorem envBound986 : H12AffineFastState.Bounded env986 := by
  intro p hp
  have h : env986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans985_986 : H12AffineEnvironment.transform 10 0 env985 = env986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env985 == env986) = true)

theorem identity986 : scanCanonicalize (H12AffineFastState.compose env986 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env987 : List Nat := [2,4,1,0,5,0,4,5,6,0,0,0,1,4,1,6,5,5,1,1,1,5,0,7,4,1,1,4,0,5,1,1,4,0,4,7]

theorem envBound987 : H12AffineFastState.Bounded env987 := by
  intro p hp
  have h : env987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans986_987 : H12AffineEnvironment.transform 2 1 env986 = env987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env986 == env987) = true)

def env988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2080,17375733,13108377,525568,0,34359738368,25691699]

theorem envBound988 : H12AffineFastState.Bounded env988 := by
  intro p hp
  have h : env988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans783_988 : H12AffineEnvironment.transform 14 8693 env783 = env988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env783 == env988) = true)

theorem identity988 : scanCanonicalize (H12AffineFastState.compose env988 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound988 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913971,8328,8914000,9176216,16384,151553,2080,8463814,13108377,525568,0,34359738368,512]

theorem envBound989 : H12AffineFastState.Bounded env989 := by
  intro p hp
  have h : env989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans988_989 : H12AffineEnvironment.transform 23 8913971 env988 = env989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env988 == env989) = true)

theorem identity989 : scanCanonicalize (H12AffineFastState.compose env989 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound989 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,525344,8388608,8913971,8328,8914000,9176216,16384,151553,2080,8463814,8388793,525568,0,34359738368,512]

theorem envBound990 : H12AffineFastState.Bounded env990 := by
  intro p hp
  have h : env990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans989_990 : H12AffineEnvironment.transform 21 525344 env989 = env990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env989 == env990) = true)

theorem identity990 : scanCanonicalize (H12AffineFastState.compose env990 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound990 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462669,8328,8462638,8724966,16384,151553,2080,8463814,8388793,73854,0,34359738368,512]

theorem envBound991 : H12AffineFastState.Bounded env991 := by
  intro p hp
  have h : env991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans990_991 : H12AffineEnvironment.transform 18 75134 env990 = env991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env990 == env991) = true)

theorem identity991 : scanCanonicalize (H12AffineFastState.compose env991 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131333) := by decide +kernel

theorem selectedBound991 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,8388608,8462669,8328,8462638,8724966,16384,151553,2080,8463814,8388793,73854,0,131333,512]

theorem envBound992 : H12AffineFastState.Bounded env992 := by
  intro p hp
  have h : env992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans991_992 : H12AffineEnvironment.transform 34 131333 env991 = env992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131333 env991 == env992) = true)

def env993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,184,74229,8328,74134,336222,16384,151553,2080,75134,1,73854,0,131333,512]

theorem envBound993 : H12AffineFastState.Bounded env993 := by
  intro p hp
  have h : env993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans992_993 : H12AffineEnvironment.transform 22 184 env992 = env993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env992 == env993) = true)

theorem identity993 : scanCanonicalize (H12AffineFastState.compose env993 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound993 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env994 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,74883,8200,2097152,73891,184,73736,8328,73835,336035,16384,151553,2080,74883,1,73854,0,131320,512]

theorem envBound994 : H12AffineFastState.Bounded env994 := by
  intro p hp
  have h : env994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans993_994 : H12AffineEnvironment.transform 7 253 env993 = env994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env993 == env994) = true)

def env995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75134,8693,2097152,74078,185,74228,8328,74135,336223,16384,151553,2080,75135,0,73854,0,131333,512]

theorem envBound995 : H12AffineFastState.Bounded env995 := by
  intro p hp
  have h : env995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans992_995 : H12AffineEnvironment.transform 22 185 env992 = env995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env992 == env995) = true)

theorem identity995 : scanCanonicalize (H12AffineFastState.compose env995 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223322) := by decide +kernel

theorem selectedBound995 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,223322,75134,8693,2097152,74078,185,74228,8328,74135,149765,16384,151553,2080,75135,0,73854,0,131333,512]

theorem envBound996 : H12AffineFastState.Bounded env996 := by
  intro p hp
  have h : env996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans995_996 : H12AffineEnvironment.transform 17 223322 env995 = env996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223322 env995 == env996) = true)

def env997 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74882,8201,2097152,73890,185,73736,8328,73835,149753,16384,151553,2080,74883,0,73854,0,131321,512]

theorem envBound997 : H12AffineFastState.Bounded env997 := by
  intro p hp
  have h : env997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans996_997 : H12AffineEnvironment.transform 7 252 env996 = env997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env996 == env997) = true)

theorem identity997 : scanCanonicalize (H12AffineFastState.compose env997 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound997 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env998 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74882,8201,151553,73890,185,73736,8328,73835,149753,16384,151553,2080,74883,0,73854,0,131321,512]

theorem envBound998 : H12AffineFastState.Bounded env998 := by
  intro p hp
  have h : env998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans997_998 : H12AffineEnvironment.transform 20 151553 env997 = env998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env997 == env998) = true)

theorem identity998 : scanCanonicalize (H12AffineFastState.compose env998 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90234) := by decide +kernel

theorem selectedBound998 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env999 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,90234,2080,74882,8201,77947,73890,185,73736,8328,73835,75907,16384,77947,2080,74883,0,73854,0,90243,512]

theorem envBound999 : H12AffineFastState.Bounded env999 := by
  intro p hp
  have h : env999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans998_999 : H12AffineEnvironment.transform 16 90234 env998 = env999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90234 env998 == env999) = true)

theorem identity999 : scanCanonicalize (H12AffineFastState.compose env999 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound999 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1000 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,8323,16633,2080,1025,8201,4344,33,185,139,8328,232,2048,16384,4344,2080,1024,0,253,0,16384,512]

theorem envBound1000 : H12AffineFastState.Bounded env1000 := by
  intro p hp
  have h : env1000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans999_1000 : H12AffineEnvironment.transform 15 8323 env999 = env1000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env999 == env1000) = true)

theorem identity1000 : scanCanonicalize (H12AffineFastState.compose env1000 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound1000 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1001 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8201,8323,5261,2080,1025,8201,4344,33,185,139,8328,232,2048,5236,4344,2080,1024,0,253,0,5236,512]

theorem envBound1001 : H12AffineFastState.Bounded env1001 := by
  intro p hp
  have h : env1001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1000_1001 : H12AffineEnvironment.transform 13 5236 env1000 = env1001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env1000 == env1001) = true)

theorem identity1001 : scanCanonicalize (H12AffineFastState.compose env1001 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound1001 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1002 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,8192,602,8201,8323,675,2080,1025,8201,1750,33,185,139,8328,232,2048,602,1750,2080,1024,0,253,0,602,512]

theorem envBound1002 : H12AffineFastState.Bounded env1002 := by
  intro p hp
  have h : env1002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1001_1002 : H12AffineEnvironment.transform 11 1582 env1001 = env1002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env1001 == env1002) = true)

theorem identity1002 : scanCanonicalize (H12AffineFastState.compose env1002 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound1002 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1003 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,3822,602,3815,3693,675,2080,1025,3815,1750,33,185,139,3686,232,2048,602,1750,2080,1024,0,253,0,602,512]

theorem envBound1003 : H12AffineFastState.Bounded env1003 := by
  intro p hp
  have h : env1003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1002_1003 : H12AffineEnvironment.transform 12 3822 env1002 = env1003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env1002 == env1003) = true)

theorem identity1003 : scanCanonicalize (H12AffineFastState.compose env1003 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound1003 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1004 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,555,2795,602,2786,2664,675,2080,4,2786,723,33,185,139,2659,232,2048,602,723,2080,5,0,253,0,602,512]

theorem envBound1004 : H12AffineFastState.Bounded env1004 := by
  intro p hp
  have h : env1004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1003_1004 : H12AffineEnvironment.transform 9 5 env1003 = env1004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env1003 == env1004) = true)

theorem identity1004 : scanCanonicalize (H12AffineFastState.compose env1004 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1004 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1005 : List Nat := [2,4,8,16,32,64,120,4,512,5,2048,555,2579,602,2586,2664,603,2080,4,2586,555,33,65,115,2659,16,2048,602,555,2080,5,0,5,0,602,512]

theorem envBound1005 : H12AffineFastState.Bounded env1005 := by
  intro p hp
  have h : env1005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1004_1005 : H12AffineEnvironment.transform 6 120 env1004 = env1005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1004 == env1005) = true)

theorem identity1005 : scanCanonicalize (H12AffineFastState.compose env1005 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound1005 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1006 : List Nat := [2,4,8,16,32,64,120,4,512,5,609,555,114,602,123,9,603,577,4,123,555,33,65,115,2,16,609,602,555,577,5,0,5,0,602,512]

theorem envBound1006 : H12AffineFastState.Bounded env1006 := by
  intro p hp
  have h : env1006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1005_1006 : H12AffineEnvironment.transform 10 609 env1005 = env1006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env1005 == env1006) = true)

theorem identity1006 : scanCanonicalize (H12AffineFastState.compose env1006 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound1006 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1007 : List Nat := [2,4,8,16,27,64,67,4,512,5,602,528,73,602,64,9,603,577,4,64,528,26,65,72,2,16,602,602,528,577,5,0,5,0,602,512]

theorem envBound1007 : H12AffineFastState.Bounded env1007 := by
  intro p hp
  have h : env1007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1006_1007 : H12AffineEnvironment.transform 4 27 env1006 = env1007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env1006 == env1007) = true)

def env1008 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74883,8200,2097152,73891,185,73737,8328,73834,149752,16384,151553,2080,74882,0,73854,0,131320,512]

theorem envBound1008 : H12AffineFastState.Bounded env1008 := by
  intro p hp
  have h : env1008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans996_1008 : H12AffineEnvironment.transform 7 253 env996 = env1008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env996 == env1008) = true)

theorem identity1008 : scanCanonicalize (H12AffineFastState.compose env1008 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound1008 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1009 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74883,8200,78035,73891,185,73737,8328,73834,149752,16384,151553,2080,74882,0,73854,0,131320,512]

theorem envBound1009 : H12AffineFastState.Bounded env1009 := by
  intro p hp
  have h : env1009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1008_1009 : H12AffineEnvironment.transform 20 78035 env1008 = env1009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env1008 == env1009) = true)

theorem identity1009 : scanCanonicalize (H12AffineFastState.compose env1009 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound1009 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1010 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7694,8200,65536,131072,210516,74883,8200,78035,73891,185,73737,8328,73834,136950,7694,134671,2080,74882,0,73854,0,131320,512]

theorem envBound1010 : H12AffineFastState.Bounded env1010 := by
  intro p hp
  have h : env1010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1009_1010 : H12AffineEnvironment.transform 13 7694 env1009 = env1010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env1009 == env1010) = true)

def env1011 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,131072,205376,74883,8200,74951,73891,185,73737,8328,73834,131810,2586,134671,2080,74882,0,73854,0,131320,512]

theorem envBound1011 : H12AffineFastState.Bounded env1011 := by
  intro p hp
  have h : env1011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1010_1011 : H12AffineEnvironment.transform 11 1044 env1010 = env1011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1010 == env1011) = true)

def env1012 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76384,2080,74883,8200,74951,73891,185,73737,8328,73834,75906,2586,74863,2080,74882,0,73854,0,76440,512]

theorem envBound1012 : H12AffineFastState.Bounded env1012 := by
  intro p hp
  have h : env1012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1011_1012 : H12AffineEnvironment.transform 16 76384 env1011 = env1012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1011 == env1012) = true)

theorem identity1012 : scanCanonicalize (H12AffineFastState.compose env1012 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound1012 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1013 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,98,10754,2080,9441,8200,9381,8385,185,8299,8328,8200,10464,2586,9229,2080,9440,0,8220,0,11002,512]

theorem envBound1013 : H12AffineFastState.Bounded env1013 := by
  intro p hp
  have h : env1013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1012_1013 : H12AffineEnvironment.transform 15 98 env1012 = env1013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env1012 == env1013) = true)

def env1014 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76385,2081,74883,8200,74951,73891,185,73737,8328,73834,75907,2586,74862,2080,74882,0,73854,0,76441,512]

theorem envBound1014 : H12AffineFastState.Bounded env1014 := by
  intro p hp
  have h : env1014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1011_1014 : H12AffineEnvironment.transform 16 76385 env1011 = env1014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1011 == env1014) = true)

theorem identity1014 : scanCanonicalize (H12AffineFastState.compose env1014 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1014 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1015 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2586,3615,65536,66678,2081,68244,3615,68304,69300,185,69150,3743,69245,67220,2586,68217,2080,68245,0,69225,0,66702,512]

theorem envBound1015 : H12AffineFastState.Bounded env1015 := by
  intro p hp
  have h : env1015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1014_1015 : H12AffineEnvironment.transform 12 3607 env1014 = env1015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1014 == env1015) = true)

theorem identity1015 : scanCanonicalize (H12AffineFastState.compose env1015 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1015 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1016 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2586,3615,3733,2787,2081,1025,3615,1093,33,185,139,3743,232,2049,2586,1260,2080,1024,0,252,0,2587,512]

theorem envBound1016 : H12AffineFastState.Bounded env1016 := by
  intro p hp
  have h : env1016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1015_1016 : H12AffineEnvironment.transform 15 3733 env1015 = env1016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1015 == env1016) = true)

theorem identity1016 : scanCanonicalize (H12AffineFastState.compose env1016 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1016 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1017 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,64,2627,2586,2635,2753,2787,2081,85,2635,17,33,185,139,2763,232,2049,2586,184,2080,84,0,252,0,2587,512]

theorem envBound1017 : H12AffineFastState.Bounded env1017 := by
  intro p hp
  have h : env1017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1016_1017 : H12AffineEnvironment.transform 9 84 env1016 = env1017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1016 == env1017) = true)

theorem identity1017 : scanCanonicalize (H12AffineFastState.compose env1017 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1017 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1018 : List Nat := [2,4,8,16,32,64,41,84,512,84,2048,64,2627,2586,2635,2664,2634,2081,85,2635,17,33,16,34,2658,65,2049,2586,17,2080,84,0,85,0,2587,512]

theorem envBound1018 : H12AffineFastState.Bounded env1018 := by
  intro p hp
  have h : env1018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1017_1018 : H12AffineEnvironment.transform 6 41 env1017 = env1018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1017 == env1018) = true)

def env1019 : List Nat := [2,4,8,16,16,64,25,84,512,84,2048,64,2627,2586,2635,2648,2634,2065,85,2635,17,17,16,18,2642,65,2049,2586,17,2064,84,0,85,0,2587,512]

theorem envBound1019 : H12AffineFastState.Bounded env1019 := by
  intro p hp
  have h : env1019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1018_1019 : H12AffineEnvironment.transform 4 16 env1018 = env1019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1018 == env1019) = true)

def env1020 : List Nat := [2,4,8,16,16,64,25,84,512,84,0,64,579,538,587,600,586,17,85,587,17,17,16,18,594,65,1,538,17,16,84,0,85,0,539,512]

theorem envBound1020 : H12AffineFastState.Bounded env1020 := by
  intro p hp
  have h : env1020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1019_1020 : H12AffineEnvironment.transform 10 0 env1019 = env1020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1019 == env1020) = true)

theorem identity1020 : scanCanonicalize (H12AffineFastState.compose env1020 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound1020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1021 : List Nat := [2,4,8,16,16,64,25,84,86,84,0,64,21,76,29,14,28,17,85,29,17,17,16,18,4,65,1,76,17,16,84,0,85,0,77,86]

theorem envBound1021 : H12AffineFastState.Bounded env1021 := by
  intro p hp
  have h : env1021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1020_1021 : H12AffineEnvironment.transform 8 86 env1020 = env1021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env1020 == env1021) = true)

def env1022 : List Nat := [2,4,8,16,16,0,25,20,22,20,0,0,21,12,29,14,28,17,21,29,17,17,16,18,4,1,1,12,17,16,20,0,21,0,13,22]

theorem envBound1022 : H12AffineFastState.Bounded env1022 := by
  intro p hp
  have h : env1022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1021_1022 : H12AffineEnvironment.transform 5 0 env1021 = env1022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1021 == env1022) = true)

theorem identity1022 : scanCanonicalize (H12AffineFastState.compose env1022 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1023 : List Nat := [2,4,4,16,16,0,21,20,22,20,0,0,21,0,17,2,16,17,21,17,17,17,16,18,4,1,1,0,17,16,20,0,21,0,1,22]

theorem envBound1023 : H12AffineFastState.Bounded env1023 := by
  intro p hp
  have h : env1023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1022_1023 : H12AffineEnvironment.transform 2 4 env1022 = env1023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1022 == env1023) = true)

def leafEnv1023 : List Nat := [2,4,4,16,16,0,21,20,22,20,0,0,21,0,17,2,16,17,21,17,17,17,16,18,20,4,1,1,1,0,17,16,20,0,21,0,4,18,1,22,1,16,0]

def active1023 : List Nat := [0,1,3]

def tree1023 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1023 : H12WitnessSearch.Good tree1023 := H12GlobalWitnessIndex.good

theorem leafIdentity1023 : H12AffineFastState.composeSystem env1023 rootObs = leafEnv1023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1023 rootObs == leafEnv1023) = true)

theorem terminalChecked1023 : H12PackedTerminal.terminalCheckFast leafEnv1023 active1023 tree1023 = true := by decide +kernel

def env1024 : List Nat := [2,4,8,16,16,1,25,21,23,21,0,1,21,13,29,14,28,17,20,29,17,17,16,18,4,0,1,13,17,16,21,0,20,0,12,23]

theorem envBound1024 : H12AffineFastState.Bounded env1024 := by
  intro p hp
  have h : env1024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1021_1024 : H12AffineEnvironment.transform 5 1 env1021 = env1024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1021 == env1024) = true)

def leafEnv1024 : List Nat := [2,4,8,16,16,1,25,21,23,21,0,1,21,13,29,14,28,17,20,29,17,17,16,18,21,4,1,0,1,13,17,16,21,0,20,0,4,30,12,23,1,16,0]

def active1024 : List Nat := [0,1,2,3]

def tree1024 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1024 : H12WitnessSearch.Good tree1024 := H12GlobalWitnessIndex.good

theorem leafIdentity1024 : H12AffineFastState.composeSystem env1024 rootObs = leafEnv1024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1024 rootObs == leafEnv1024) = true)

theorem terminalChecked1024 : H12PackedTerminal.terminalCheckFast leafEnv1024 active1024 tree1024 = true := by decide +kernel

def env1025 : List Nat := [2,4,8,16,16,64,25,84,512,84,1,64,578,539,586,601,587,16,85,586,17,17,16,18,595,65,0,539,17,17,84,0,85,0,538,512]

theorem envBound1025 : H12AffineFastState.Bounded env1025 := by
  intro p hp
  have h : env1025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1019_1025 : H12AffineEnvironment.transform 10 1 env1019 = env1025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1019 == env1025) = true)

theorem identity1025 : scanCanonicalize (H12AffineFastState.compose env1025 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound1025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1026 : List Nat := [2,4,8,16,16,64,25,84,71,84,1,64,5,92,13,30,12,16,85,13,17,17,16,18,20,65,0,92,17,17,84,0,85,0,93,71]

theorem envBound1026 : H12AffineFastState.Bounded env1026 := by
  intro p hp
  have h : env1026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1025_1026 : H12AffineEnvironment.transform 8 71 env1025 = env1026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env1025 == env1026) = true)

def env1027 : List Nat := [2,4,8,16,16,0,25,20,7,20,1,0,5,28,13,30,12,16,21,13,17,17,16,18,20,1,0,28,17,17,20,0,21,0,29,7]

theorem envBound1027 : H12AffineFastState.Bounded env1027 := by
  intro p hp
  have h : env1027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1026_1027 : H12AffineEnvironment.transform 5 0 env1026 = env1027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1026 == env1027) = true)

def leafEnv1027 : List Nat := [2,4,8,16,16,0,25,20,7,20,1,0,5,28,13,30,12,16,21,13,17,17,16,18,20,20,1,1,0,28,17,17,20,0,21,0,4,14,29,7,1,16,0]

def active1027 : List Nat := [0,1,2,3]

def tree1027 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1027 : H12WitnessSearch.Good tree1027 := H12GlobalWitnessIndex.good

theorem leafIdentity1027 : H12AffineFastState.composeSystem env1027 rootObs = leafEnv1027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1027 rootObs == leafEnv1027) = true)

theorem terminalChecked1027 : H12PackedTerminal.terminalCheckFast leafEnv1027 active1027 tree1027 = true := by decide +kernel

def env1028 : List Nat := [2,4,8,16,16,1,25,21,6,21,1,1,5,29,13,30,12,16,20,13,17,17,16,18,20,0,0,29,17,17,21,0,20,0,28,6]

theorem envBound1028 : H12AffineFastState.Bounded env1028 := by
  intro p hp
  have h : env1028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1026_1028 : H12AffineEnvironment.transform 5 1 env1026 = env1028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1026 == env1028) = true)

theorem identity1028 : scanCanonicalize (H12AffineFastState.compose env1028 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1029 : List Nat := [2,4,8,13,13,1,4,8,6,8,1,1,5,0,13,3,12,13,9,13,12,12,13,15,9,0,0,0,12,12,8,0,9,0,1,6]

theorem envBound1029 : H12AffineFastState.Bounded env1029 := by
  intro p hp
  have h : env1029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1028_1029 : H12AffineEnvironment.transform 3 13 env1028 = env1029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1028 == env1029) = true)

def leafEnv1029 : List Nat := [2,4,8,13,13,1,4,8,6,8,1,1,5,0,13,3,12,13,9,13,12,12,13,15,8,9,1,0,0,0,12,12,8,0,9,0,4,14,1,6,1,13,0]

def active1029 : List Nat := [0,1,2]

def tree1029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1029 : H12WitnessSearch.Good tree1029 := H12GlobalWitnessIndex.good

theorem leafIdentity1029 : H12AffineFastState.composeSystem env1029 rootObs = leafEnv1029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1029 rootObs == leafEnv1029) = true)

theorem terminalChecked1029 : H12PackedTerminal.terminalCheckFast leafEnv1029 active1029 tree1029 = true := by decide +kernel

def env1030 : List Nat := [2,4,8,16,17,64,24,84,512,84,2048,64,2627,2586,2635,2649,2634,2064,85,2635,17,16,16,19,2643,65,2049,2586,17,2065,84,0,85,0,2587,512]

theorem envBound1030 : H12AffineFastState.Bounded env1030 := by
  intro p hp
  have h : env1030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1018_1030 : H12AffineEnvironment.transform 4 17 env1018 = env1030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1018 == env1030) = true)

def env1031 : List Nat := [2,4,8,16,17,64,24,84,512,84,0,64,579,538,587,601,586,16,85,587,17,16,16,19,595,65,1,538,17,17,84,0,85,0,539,512]

theorem envBound1031 : H12AffineFastState.Bounded env1031 := by
  intro p hp
  have h : env1031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1030_1031 : H12AffineEnvironment.transform 10 0 env1030 = env1031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1030 == env1031) = true)

theorem identity1031 : scanCanonicalize (H12AffineFastState.compose env1031 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1032 : List Nat := [2,4,8,12,13,64,4,72,512,72,0,64,579,518,587,581,586,12,73,587,13,12,12,15,591,65,1,518,13,13,72,0,73,0,519,512]

theorem envBound1032 : H12AffineFastState.Bounded env1032 := by
  intro p hp
  have h : env1032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1031_1032 : H12AffineEnvironment.transform 3 12 env1031 = env1032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1031 == env1032) = true)

def env1033 : List Nat := [2,4,8,12,13,0,4,8,512,8,0,0,515,518,523,517,522,12,9,523,13,12,12,15,527,1,1,518,13,13,8,0,9,0,519,512]

theorem envBound1033 : H12AffineFastState.Bounded env1033 := by
  intro p hp
  have h : env1033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1032_1033 : H12AffineEnvironment.transform 5 0 env1032 = env1033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1032 == env1033) = true)

theorem identity1033 : scanCanonicalize (H12AffineFastState.compose env1033 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1034 : List Nat := [2,4,8,12,13,0,4,8,7,8,0,0,4,1,12,2,13,12,9,12,13,12,12,15,8,1,1,1,13,13,8,0,9,0,0,7]

theorem envBound1034 : H12AffineFastState.Bounded env1034 := by
  intro p hp
  have h : env1034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1033_1034 : H12AffineEnvironment.transform 8 7 env1033 = env1034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1033 == env1034) = true)

def leafEnv1034 : List Nat := [2,4,8,12,13,0,4,8,7,8,0,0,4,1,12,2,13,12,9,12,13,12,12,15,8,8,1,1,1,1,13,13,8,0,9,0,4,15,0,7,1,12,0]

def active1034 : List Nat := [0,1,2]

def tree1034 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1034 : H12WitnessSearch.Good tree1034 := H12GlobalWitnessIndex.good

theorem leafIdentity1034 : H12AffineFastState.composeSystem env1034 rootObs = leafEnv1034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1034 rootObs == leafEnv1034) = true)

theorem terminalChecked1034 : H12PackedTerminal.terminalCheckFast leafEnv1034 active1034 tree1034 = true := by decide +kernel

def env1035 : List Nat := [2,4,8,12,13,1,4,9,512,9,0,1,514,518,522,516,523,12,8,522,13,12,12,15,526,0,1,518,13,13,9,0,8,0,519,512]

theorem envBound1035 : H12AffineFastState.Bounded env1035 := by
  intro p hp
  have h : env1035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1032_1035 : H12AffineEnvironment.transform 5 1 env1032 = env1035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1032 == env1035) = true)

def leafEnv1035 : List Nat := [2,4,8,12,13,1,4,9,512,9,0,1,514,518,522,516,523,12,8,522,13,12,12,15,9,526,1,0,1,518,13,13,9,0,8,0,4,521,519,512,1,12,0]

def active1035 : List Nat := [0,1,2,8]

def tree1035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1035 : H12WitnessSearch.Good tree1035 := H12GlobalWitnessIndex.good

theorem leafIdentity1035 : H12AffineFastState.composeSystem env1035 rootObs = leafEnv1035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1035 rootObs == leafEnv1035) = true)

theorem terminalChecked1035 : H12PackedTerminal.terminalCheckFast leafEnv1035 active1035 tree1035 = true := by decide +kernel

def env1036 : List Nat := [2,4,8,16,17,64,24,84,512,84,1,64,578,539,586,600,587,17,85,586,17,16,16,19,594,65,0,539,17,16,84,0,85,0,538,512]

theorem envBound1036 : H12AffineFastState.Bounded env1036 := by
  intro p hp
  have h : env1036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1030_1036 : H12AffineEnvironment.transform 10 1 env1030 = env1036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1030 == env1036) = true)

theorem identity1036 : scanCanonicalize (H12AffineFastState.compose env1036 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1036 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1037 : List Nat := [2,4,5,16,17,64,21,84,512,84,1,64,578,534,583,597,582,17,85,583,17,16,16,19,594,65,0,534,17,16,84,0,85,0,535,512]

theorem envBound1037 : H12AffineFastState.Bounded env1037 := by
  intro p hp
  have h : env1037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1036_1037 : H12AffineEnvironment.transform 2 5 env1036 = env1037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1036 == env1037) = true)

def env1038 : List Nat := [2,4,5,16,17,0,21,20,512,20,1,0,514,534,519,533,518,17,21,519,17,16,16,19,530,1,0,534,17,16,20,0,21,0,535,512]

theorem envBound1038 : H12AffineFastState.Bounded env1038 := by
  intro p hp
  have h : env1038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1037_1038 : H12AffineEnvironment.transform 5 0 env1037 = env1038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1037 == env1038) = true)

def leafEnv1038 : List Nat := [2,4,5,16,17,0,21,20,512,20,1,0,514,534,519,533,518,17,21,519,17,16,16,19,20,530,1,1,0,534,17,16,20,0,21,0,4,516,535,512,1,16,0]

def active1038 : List Nat := [0,1,3,8]

def tree1038 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1038 : H12WitnessSearch.Good tree1038 := H12GlobalWitnessIndex.good

theorem leafIdentity1038 : H12AffineFastState.composeSystem env1038 rootObs = leafEnv1038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1038 rootObs == leafEnv1038) = true)

theorem terminalChecked1038 : H12PackedTerminal.terminalCheckFast leafEnv1038 active1038 tree1038 = true := by decide +kernel

def env1039 : List Nat := [2,4,5,16,17,1,21,21,512,21,1,1,515,534,518,532,519,17,20,518,17,16,16,19,531,0,0,534,17,16,21,0,20,0,535,512]

theorem envBound1039 : H12AffineFastState.Bounded env1039 := by
  intro p hp
  have h : env1039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1037_1039 : H12AffineEnvironment.transform 5 1 env1037 = env1039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1037 == env1039) = true)

theorem identity1039 : scanCanonicalize (H12AffineFastState.compose env1039 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1040 : List Nat := [2,4,5,16,17,1,21,21,23,21,1,1,20,1,17,3,16,17,20,17,17,16,16,19,4,0,0,1,17,16,21,0,20,0,0,23]

theorem envBound1040 : H12AffineFastState.Bounded env1040 := by
  intro p hp
  have h : env1040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1039_1040 : H12AffineEnvironment.transform 8 23 env1039 = env1040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1039 == env1040) = true)

def leafEnv1040 : List Nat := [2,4,5,16,17,1,21,21,23,21,1,1,20,1,17,3,16,17,20,17,17,16,16,19,21,4,1,0,0,1,17,16,21,0,20,0,4,18,0,23,1,16,0]

def active1040 : List Nat := [0,1,3]

def tree1040 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1040 : H12WitnessSearch.Good tree1040 := H12GlobalWitnessIndex.good

theorem leafIdentity1040 : H12AffineFastState.composeSystem env1040 rootObs = leafEnv1040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1040 rootObs == leafEnv1040) = true)

theorem terminalChecked1040 : H12PackedTerminal.terminalCheckFast leafEnv1040 active1040 tree1040 = true := by decide +kernel

def env1041 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,131072,205377,74883,8200,74950,73891,185,73737,8328,73834,131811,2587,134671,2080,74882,0,73854,0,131320,512]

theorem envBound1041 : H12AffineFastState.Bounded env1041 := by
  intro p hp
  have h : env1041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1010_1041 : H12AffineEnvironment.transform 11 1045 env1010 = env1041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1010 == env1041) = true)

def env1042 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76384,2081,74883,8200,74950,73891,185,73737,8328,73834,75907,2587,74863,2080,74882,0,73854,0,76440,512]

theorem envBound1042 : H12AffineFastState.Bounded env1042 := by
  intro p hp
  have h : env1042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1041_1042 : H12AffineEnvironment.transform 16 76384 env1041 = env1042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1041 == env1042) = true)

theorem identity1042 : scanCanonicalize (H12AffineFastState.compose env1042 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1042 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1043 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,3733,9461,2081,10774,8200,10835,11830,185,11932,8328,12031,9750,2587,11002,2080,10775,0,12011,0,9229,512]

theorem envBound1043 : H12AffineFastState.Bounded env1043 := by
  intro p hp
  have h : env1043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1042_1043 : H12AffineEnvironment.transform 15 3733 env1042 = env1043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1042 == env1043) = true)

theorem identity1043 : scanCanonicalize (H12AffineFastState.compose env1043 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1043 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1044 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2587,3615,3733,2786,2081,1025,3615,1092,33,185,139,3743,232,2049,2587,1261,2080,1024,0,252,0,2586,512]

theorem envBound1044 : H12AffineFastState.Bounded env1044 := by
  intro p hp
  have h : env1044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1043_1044 : H12AffineEnvironment.transform 12 3607 env1043 = env1044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1043 == env1044) = true)

theorem identity1044 : scanCanonicalize (H12AffineFastState.compose env1044 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1044 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1045 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2627,2587,2635,2753,2786,2081,85,2635,16,33,185,139,2763,232,2049,2587,185,2080,84,0,252,0,2586,512]

theorem envBound1045 : H12AffineFastState.Bounded env1045 := by
  intro p hp
  have h : env1045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1044_1045 : H12AffineEnvironment.transform 9 84 env1044 = env1045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1044 == env1045) = true)

theorem identity1045 : scanCanonicalize (H12AffineFastState.compose env1045 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1045 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1046 : List Nat := [2,4,8,16,32,64,41,84,512,84,2048,65,2627,2587,2635,2664,2635,2081,85,2635,16,33,16,34,2658,65,2049,2587,16,2080,84,0,85,0,2586,512]

theorem envBound1046 : H12AffineFastState.Bounded env1046 := by
  intro p hp
  have h : env1046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1045_1046 : H12AffineEnvironment.transform 6 41 env1045 = env1046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1045 == env1046) = true)

def env1047 : List Nat := [2,4,8,16,16,64,25,84,512,84,2048,65,2627,2587,2635,2648,2635,2065,85,2635,16,17,16,18,2642,65,2049,2587,16,2064,84,0,85,0,2586,512]

theorem envBound1047 : H12AffineFastState.Bounded env1047 := by
  intro p hp
  have h : env1047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1046_1047 : H12AffineEnvironment.transform 4 16 env1046 = env1047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1046 == env1047) = true)

def env1048 : List Nat := [2,4,8,16,16,64,25,84,512,84,0,65,579,539,587,600,587,17,85,587,16,17,16,18,594,65,1,539,16,16,84,0,85,0,538,512]

theorem envBound1048 : H12AffineFastState.Bounded env1048 := by
  intro p hp
  have h : env1048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1047_1048 : H12AffineEnvironment.transform 10 0 env1047 = env1048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1047 == env1048) = true)

theorem identity1048 : scanCanonicalize (H12AffineFastState.compose env1048 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound1048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1049 : List Nat := [2,4,8,16,16,28,25,8,512,8,0,29,543,539,535,516,535,17,9,535,16,17,16,18,526,29,1,539,16,16,8,0,9,0,538,512]

theorem envBound1049 : H12AffineFastState.Bounded env1049 := by
  intro p hp
  have h : env1049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1048_1049 : H12AffineEnvironment.transform 5 28 env1048 = env1049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env1048 == env1049) = true)

def env1050 : List Nat := [2,4,8,12,12,0,5,8,512,8,0,1,515,519,523,516,523,13,9,523,12,13,12,14,526,1,1,519,12,12,8,0,9,0,518,512]

theorem envBound1050 : H12AffineFastState.Bounded env1050 := by
  intro p hp
  have h : env1050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1049_1050 : H12AffineEnvironment.transform 3 12 env1049 = env1050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1049 == env1050) = true)

def leafEnv1050 : List Nat := [2,4,8,12,12,0,5,8,512,8,0,1,515,519,523,516,523,13,9,523,12,13,12,14,8,526,1,1,1,519,12,12,8,0,9,0,4,520,518,512,1,13,0]

def active1050 : List Nat := [0,1,2,8]

def tree1050 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1050 : H12WitnessSearch.Good tree1050 := H12GlobalWitnessIndex.good

theorem leafIdentity1050 : H12AffineFastState.composeSystem env1050 rootObs = leafEnv1050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1050 rootObs == leafEnv1050) = true)

theorem terminalChecked1050 : H12PackedTerminal.terminalCheckFast leafEnv1050 active1050 tree1050 = true := by decide +kernel

def env1051 : List Nat := [2,4,8,13,13,1,4,8,512,8,0,0,514,518,522,516,522,12,9,522,13,12,13,15,526,0,1,518,13,13,8,0,9,0,519,512]

theorem envBound1051 : H12AffineFastState.Bounded env1051 := by
  intro p hp
  have h : env1051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1049_1051 : H12AffineEnvironment.transform 3 13 env1049 = env1051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1049 == env1051) = true)

theorem identity1051 : scanCanonicalize (H12AffineFastState.compose env1051 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1052 : List Nat := [2,4,8,13,13,1,4,8,7,8,0,0,5,1,13,3,13,12,9,13,13,12,13,15,9,0,1,1,13,13,8,0,9,0,0,7]

theorem envBound1052 : H12AffineFastState.Bounded env1052 := by
  intro p hp
  have h : env1052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1051_1052 : H12AffineEnvironment.transform 8 7 env1051 = env1052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1051 == env1052) = true)

def leafEnv1052 : List Nat := [2,4,8,13,13,1,4,8,7,8,0,0,5,1,13,3,13,12,9,13,13,12,13,15,8,9,1,0,1,1,13,13,8,0,9,0,4,14,0,7,1,12,0]

def active1052 : List Nat := [0,1,2]

def tree1052 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1052 : H12WitnessSearch.Good tree1052 := H12GlobalWitnessIndex.good

theorem leafIdentity1052 : H12AffineFastState.composeSystem env1052 rootObs = leafEnv1052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1052 rootObs == leafEnv1052) = true)

theorem terminalChecked1052 : H12PackedTerminal.terminalCheckFast leafEnv1052 active1052 tree1052 = true := by decide +kernel

def env1053 : List Nat := [2,4,8,16,16,64,25,84,512,84,1,65,578,538,586,601,586,16,85,586,16,17,16,18,595,65,0,538,16,17,84,0,85,0,539,512]

theorem envBound1053 : H12AffineFastState.Bounded env1053 := by
  intro p hp
  have h : env1053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1047_1053 : H12AffineEnvironment.transform 10 1 env1047 = env1053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1047 == env1053) = true)

theorem identity1053 : scanCanonicalize (H12AffineFastState.compose env1053 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound1053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1054 : List Nat := [2,4,8,16,16,12,25,24,512,24,1,13,526,538,518,533,518,16,25,518,16,17,16,18,543,13,0,538,16,17,24,0,25,0,539,512]

theorem envBound1054 : H12AffineFastState.Bounded env1054 := by
  intro p hp
  have h : env1054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1053_1054 : H12AffineEnvironment.transform 5 12 env1053 = env1054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env1053 == env1054) = true)

def env1055 : List Nat := [2,4,4,16,16,0,21,20,512,20,1,1,514,534,518,533,518,16,21,518,16,17,16,18,531,1,0,534,16,17,20,0,21,0,535,512]

theorem envBound1055 : H12AffineFastState.Bounded env1055 := by
  intro p hp
  have h : env1055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1054_1055 : H12AffineEnvironment.transform 2 4 env1054 = env1055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1054 == env1055) = true)

theorem identity1055 : scanCanonicalize (H12AffineFastState.compose env1055 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1055 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1056 : List Nat := [2,4,4,16,16,0,21,20,23,20,1,1,21,1,17,2,17,16,21,17,16,17,16,18,4,1,0,1,16,17,20,0,21,0,0,23]

theorem envBound1056 : H12AffineFastState.Bounded env1056 := by
  intro p hp
  have h : env1056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1055_1056 : H12AffineEnvironment.transform 8 23 env1055 = env1056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1055 == env1056) = true)

def leafEnv1056 : List Nat := [2,4,4,16,16,0,21,20,23,20,1,1,21,1,17,2,17,16,21,17,16,17,16,18,20,4,1,1,0,1,16,17,20,0,21,0,4,18,0,23,1,17,0]

def active1056 : List Nat := [0,1,3]

def tree1056 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1056 : H12WitnessSearch.Good tree1056 := H12GlobalWitnessIndex.good

theorem leafIdentity1056 : H12AffineFastState.composeSystem env1056 rootObs = leafEnv1056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1056 rootObs == leafEnv1056) = true)

theorem terminalChecked1056 : H12PackedTerminal.terminalCheckFast leafEnv1056 active1056 tree1056 = true := by decide +kernel

def env1057 : List Nat := [2,4,5,16,16,1,20,21,512,21,1,0,515,535,518,533,518,16,20,518,16,17,16,18,530,0,0,535,16,17,21,0,20,0,534,512]

theorem envBound1057 : H12AffineFastState.Bounded env1057 := by
  intro p hp
  have h : env1057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1054_1057 : H12AffineEnvironment.transform 2 5 env1054 = env1057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1054 == env1057) = true)

def leafEnv1057 : List Nat := [2,4,5,16,16,1,20,21,512,21,1,0,515,535,518,533,518,16,20,518,16,17,16,18,21,530,1,0,0,535,16,17,21,0,20,0,4,517,534,512,1,17,0]

def active1057 : List Nat := [0,1,3,8]

def tree1057 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1057 : H12WitnessSearch.Good tree1057 := H12GlobalWitnessIndex.good

theorem leafIdentity1057 : H12AffineFastState.composeSystem env1057 rootObs = leafEnv1057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1057 rootObs == leafEnv1057) = true)

theorem terminalChecked1057 : H12PackedTerminal.terminalCheckFast leafEnv1057 active1057 tree1057 = true := by decide +kernel

def env1058 : List Nat := [2,4,8,16,17,64,24,84,512,84,2048,65,2627,2587,2635,2649,2635,2064,85,2635,16,16,16,19,2643,65,2049,2587,16,2065,84,0,85,0,2586,512]

theorem envBound1058 : H12AffineFastState.Bounded env1058 := by
  intro p hp
  have h : env1058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1046_1058 : H12AffineEnvironment.transform 4 17 env1046 = env1058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1046 == env1058) = true)

def env1059 : List Nat := [2,4,8,16,17,64,24,84,512,84,0,65,579,539,587,601,587,16,85,587,16,16,16,19,595,65,1,539,16,17,84,0,85,0,538,512]

theorem envBound1059 : H12AffineFastState.Bounded env1059 := by
  intro p hp
  have h : env1059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1058_1059 : H12AffineEnvironment.transform 10 0 env1058 = env1059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1058 == env1059) = true)

theorem identity1059 : scanCanonicalize (H12AffineFastState.compose env1059 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1060 : List Nat := [2,4,8,16,17,64,24,84,22,84,0,65,85,13,93,79,93,16,85,93,16,16,16,19,69,65,1,13,16,17,84,0,85,0,12,22]

theorem envBound1060 : H12AffineFastState.Bounded env1060 := by
  intro p hp
  have h : env1060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1059_1060 : H12AffineEnvironment.transform 8 22 env1059 = env1060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1059 == env1060) = true)

def env1061 : List Nat := [2,4,8,16,17,0,24,20,22,20,0,1,21,13,29,15,29,16,21,29,16,16,16,19,5,1,1,13,16,17,20,0,21,0,12,22]

theorem envBound1061 : H12AffineFastState.Bounded env1061 := by
  intro p hp
  have h : env1061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1060_1061 : H12AffineEnvironment.transform 5 0 env1060 = env1061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1060 == env1061) = true)

def leafEnv1061 : List Nat := [2,4,8,16,17,0,24,20,22,20,0,1,21,13,29,15,29,16,21,29,16,16,16,19,20,5,1,1,1,13,16,17,20,0,21,0,4,30,12,22,1,17,0]

def active1061 : List Nat := [0,1,2,3]

def tree1061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1061 : H12WitnessSearch.Good tree1061 := H12GlobalWitnessIndex.good

theorem leafIdentity1061 : H12AffineFastState.composeSystem env1061 rootObs = leafEnv1061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1061 rootObs == leafEnv1061) = true)

theorem terminalChecked1061 : H12PackedTerminal.terminalCheckFast leafEnv1061 active1061 tree1061 = true := by decide +kernel

def env1062 : List Nat := [2,4,8,16,17,1,24,21,22,21,0,0,20,13,28,14,28,16,20,28,16,16,16,19,4,0,1,13,16,17,21,0,20,0,12,22]

theorem envBound1062 : H12AffineFastState.Bounded env1062 := by
  intro p hp
  have h : env1062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1060_1062 : H12AffineEnvironment.transform 5 1 env1060 = env1062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1060 == env1062) = true)

theorem identity1062 : scanCanonicalize (H12AffineFastState.compose env1062 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1062 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1063 : List Nat := [2,4,5,16,17,1,21,21,22,21,0,0,20,0,17,3,17,16,20,17,16,16,16,19,4,0,1,0,16,17,21,0,20,0,1,22]

theorem envBound1063 : H12AffineFastState.Bounded env1063 := by
  intro p hp
  have h : env1063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1062_1063 : H12AffineEnvironment.transform 2 5 env1062 = env1063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1062 == env1063) = true)

def leafEnv1063 : List Nat := [2,4,5,16,17,1,21,21,22,21,0,0,20,0,17,3,17,16,20,17,16,16,16,19,21,4,1,0,1,0,16,17,21,0,20,0,4,18,1,22,1,17,0]

def active1063 : List Nat := [0,1,3]

def tree1063 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1063 : H12WitnessSearch.Good tree1063 := H12GlobalWitnessIndex.good

theorem leafIdentity1063 : H12AffineFastState.composeSystem env1063 rootObs = leafEnv1063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1063 rootObs == leafEnv1063) = true)

theorem terminalChecked1063 : H12PackedTerminal.terminalCheckFast leafEnv1063 active1063 tree1063 = true := by decide +kernel

def env1064 : List Nat := [2,4,8,16,17,64,24,84,512,84,1,65,578,538,586,600,586,17,85,586,16,16,16,19,594,65,0,538,16,16,84,0,85,0,539,512]

theorem envBound1064 : H12AffineFastState.Bounded env1064 := by
  intro p hp
  have h : env1064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1058_1064 : H12AffineEnvironment.transform 10 1 env1058 = env1064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1058 == env1064) = true)

theorem identity1064 : scanCanonicalize (H12AffineFastState.compose env1064 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1064 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1065 : List Nat := [2,4,8,16,17,64,24,84,6,84,1,65,68,28,76,94,76,17,85,76,16,16,16,19,84,65,0,28,16,16,84,0,85,0,29,6]

theorem envBound1065 : H12AffineFastState.Bounded env1065 := by
  intro p hp
  have h : env1065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1064_1065 : H12AffineEnvironment.transform 8 6 env1064 = env1065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1064 == env1065) = true)

def env1066 : List Nat := [2,4,8,16,17,0,24,20,6,20,1,1,4,28,12,30,12,17,21,12,16,16,16,19,20,1,0,28,16,16,20,0,21,0,29,6]

theorem envBound1066 : H12AffineFastState.Bounded env1066 := by
  intro p hp
  have h : env1066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1065_1066 : H12AffineEnvironment.transform 5 0 env1065 = env1066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1065 == env1066) = true)

theorem identity1066 : scanCanonicalize (H12AffineFastState.compose env1066 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1066 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1067 : List Nat := [2,4,8,12,13,0,4,8,6,8,1,1,4,0,12,2,12,13,9,12,12,12,12,15,8,1,0,0,12,12,8,0,9,0,1,6]

theorem envBound1067 : H12AffineFastState.Bounded env1067 := by
  intro p hp
  have h : env1067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1066_1067 : H12AffineEnvironment.transform 3 12 env1066 = env1067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1066 == env1067) = true)

def leafEnv1067 : List Nat := [2,4,8,12,13,0,4,8,6,8,1,1,4,0,12,2,12,13,9,12,12,12,12,15,8,8,1,1,0,0,12,12,8,0,9,0,4,15,1,6,1,13,0]

def active1067 : List Nat := [0,1,2]

def tree1067 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1067 : H12WitnessSearch.Good tree1067 := H12GlobalWitnessIndex.good

theorem leafIdentity1067 : H12AffineFastState.composeSystem env1067 rootObs = leafEnv1067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1067 rootObs == leafEnv1067) = true)

theorem terminalChecked1067 : H12PackedTerminal.terminalCheckFast leafEnv1067 active1067 tree1067 = true := by decide +kernel

def env1068 : List Nat := [2,4,8,16,17,1,24,21,6,21,1,0,5,28,13,31,13,17,20,13,16,16,16,19,21,0,0,28,16,16,21,0,20,0,29,6]

theorem envBound1068 : H12AffineFastState.Bounded env1068 := by
  intro p hp
  have h : env1068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1065_1068 : H12AffineEnvironment.transform 5 1 env1065 = env1068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1065 == env1068) = true)

def leafEnv1068 : List Nat := [2,4,8,16,17,1,24,21,6,21,1,0,5,28,13,31,13,17,20,13,16,16,16,19,21,21,1,0,0,28,16,16,21,0,20,0,4,14,29,6,1,17,0]

def active1068 : List Nat := [0,1,2,3]

def tree1068 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1068 : H12WitnessSearch.Good tree1068 := H12GlobalWitnessIndex.good

theorem leafIdentity1068 : H12AffineFastState.composeSystem env1068 rootObs = leafEnv1068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1068 rootObs == leafEnv1068) = true)

theorem terminalChecked1068 : H12PackedTerminal.terminalCheckFast leafEnv1068 active1068 tree1068 = true := by decide +kernel

def env1069 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76385,2080,74883,8200,74950,73891,185,73737,8328,73834,75906,2587,74862,2080,74882,0,73854,0,76441,512]

theorem envBound1069 : H12AffineFastState.Bounded env1069 := by
  intro p hp
  have h : env1069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1041_1069 : H12AffineEnvironment.transform 16 76385 env1041 = env1069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1041 == env1069) = true)

theorem identity1069 : scanCanonicalize (H12AffineFastState.compose env1069 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 224) := by decide +kernel

theorem selectedBound1069 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1070 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,224,2587,232,65536,68225,2080,66659,232,66598,65603,185,65769,104,65674,67682,2587,66702,2080,66658,0,65694,0,68217,512]

theorem envBound1070 : H12AffineFastState.Bounded env1070 := by
  intro p hp
  have h : env1070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1069_1070 : H12AffineEnvironment.transform 12 224 env1069 = env1070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env1069 == env1070) = true)

def env1071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2081,17399808,13149549,525568,1,34359738368,25733062]

theorem envBound1071 : H12AffineFastState.Bounded env1071 := by
  intro p hp
  have h : env1071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans782_1071 : H12AffineEnvironment.transform 27 16385 env782 = env1071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env782 == env1071) = true)

def env1072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2081,17375732,13108377,525568,1,34359738368,25691698]

theorem envBound1072 : H12AffineFastState.Bounded env1072 := by
  intro p hp
  have h : env1072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1071_1072 : H12AffineEnvironment.transform 14 8692 env1071 = env1072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env1071 == env1072) = true)

theorem identity1072 : scanCanonicalize (H12AffineFastState.compose env1072 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound1072 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913970,8328,8914000,9176216,16385,151552,2081,8463814,13108377,525568,1,34359738368,512]

theorem envBound1073 : H12AffineFastState.Bounded env1073 := by
  intro p hp
  have h : env1073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1072_1073 : H12AffineEnvironment.transform 23 8913970 env1072 = env1073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env1072 == env1073) = true)

theorem identity1073 : scanCanonicalize (H12AffineFastState.compose env1073 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound1073 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525344,8388608,8913970,8328,8914000,9176216,16385,151552,2081,8463814,8388793,525568,1,34359738368,512]

theorem envBound1074 : H12AffineFastState.Bounded env1074 := by
  intro p hp
  have h : env1074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1073_1074 : H12AffineEnvironment.transform 21 525344 env1073 = env1074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env1073 == env1074) = true)

theorem identity1074 : scanCanonicalize (H12AffineFastState.compose env1074 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound1074 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462668,8328,8462638,8724966,16385,151552,2081,8463814,8388793,73854,1,34359738368,512]

theorem envBound1075 : H12AffineFastState.Bounded env1075 := by
  intro p hp
  have h : env1075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1074_1075 : H12AffineEnvironment.transform 18 75134 env1074 = env1075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env1074 == env1075) = true)

theorem identity1075 : scanCanonicalize (H12AffineFastState.compose env1075 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131333) := by decide +kernel

theorem selectedBound1075 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462668,8328,8462638,8724966,16385,151552,2081,8463814,8388793,73854,1,131333,512]

theorem envBound1076 : H12AffineFastState.Bounded env1076 := by
  intro p hp
  have h : env1076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1075_1076 : H12AffineEnvironment.transform 34 131333 env1075 = env1076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131333 env1075 == env1076) = true)

def env1077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,184,74228,8328,74134,336222,16385,151552,2081,75134,1,73854,1,131333,512]

theorem envBound1077 : H12AffineFastState.Bounded env1077 := by
  intro p hp
  have h : env1077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1076_1077 : H12AffineEnvironment.transform 22 184 env1076 = env1077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1076 == env1077) = true)

theorem identity1077 : scanCanonicalize (H12AffineFastState.compose env1077 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound1077 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223323,75134,8692,2097152,74078,184,74228,8328,74134,149765,16385,151552,2081,75134,1,73854,1,131333,512]

theorem envBound1078 : H12AffineFastState.Bounded env1078 := by
  intro p hp
  have h : env1078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1077_1078 : H12AffineEnvironment.transform 17 223323 env1077 = env1078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env1077 == env1078) = true)

def env1079 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74882,8200,2097152,73890,184,73736,8328,73834,149753,16385,151552,2081,74882,1,73854,1,131321,512]

theorem envBound1079 : H12AffineFastState.Bounded env1079 := by
  intro p hp
  have h : env1079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1078_1079 : H12AffineEnvironment.transform 7 252 env1078 = env1079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1078 == env1079) = true)

theorem identity1079 : scanCanonicalize (H12AffineFastState.compose env1079 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound1079 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1080 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74882,8200,151553,73890,184,73736,8328,73834,149753,16385,151552,2081,74882,1,73854,1,131321,512]

theorem envBound1080 : H12AffineFastState.Bounded env1080 := by
  intro p hp
  have h : env1080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1079_1080 : H12AffineEnvironment.transform 20 151553 env1079 = env1080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env1079 == env1080) = true)

theorem identity1080 : scanCanonicalize (H12AffineFastState.compose env1080 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90234) := by decide +kernel

theorem selectedBound1080 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1081 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90234,2081,74882,8200,77947,73890,184,73736,8328,73834,75907,16385,77946,2081,74882,1,73854,1,90243,512]

theorem envBound1081 : H12AffineFastState.Bounded env1081 := by
  intro p hp
  have h : env1081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1080_1081 : H12AffineEnvironment.transform 16 90234 env1080 = env1081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90234 env1080 == env1081) = true)

theorem identity1081 : scanCanonicalize (H12AffineFastState.compose env1081 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1081 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1082 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16633,2081,1025,8200,4344,33,184,139,8328,233,2048,16385,4345,2081,1025,1,253,1,16384,512]

theorem envBound1082 : H12AffineFastState.Bounded env1082 := by
  intro p hp
  have h : env1082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1081_1082 : H12AffineEnvironment.transform 15 8323 env1081 = env1082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1081 == env1082) = true)

theorem identity1082 : scanCanonicalize (H12AffineFastState.compose env1082 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound1082 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1083 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8200,8323,5260,2081,1025,8200,4344,33,184,139,8328,233,2048,5236,4345,2081,1025,1,253,1,5237,512]

theorem envBound1083 : H12AffineFastState.Bounded env1083 := by
  intro p hp
  have h : env1083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1082_1083 : H12AffineEnvironment.transform 13 5237 env1082 = env1083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env1082 == env1083) = true)

theorem identity1083 : scanCanonicalize (H12AffineFastState.compose env1083 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound1083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1084 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,8192,603,8200,8323,674,2081,1025,8200,1750,33,184,139,8328,233,2048,602,1751,2081,1025,1,253,1,603,512]

theorem envBound1084 : H12AffineFastState.Bounded env1084 := by
  intro p hp
  have h : env1084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1083_1084 : H12AffineEnvironment.transform 11 1582 env1083 = env1084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env1083 == env1084) = true)

theorem identity1084 : scanCanonicalize (H12AffineFastState.compose env1084 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound1084 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1085 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,3822,603,3814,3693,674,2081,1025,3814,1750,33,184,139,3686,233,2048,602,1751,2081,1025,1,253,1,603,512]

theorem envBound1085 : H12AffineFastState.Bounded env1085 := by
  intro p hp
  have h : env1085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1084_1085 : H12AffineEnvironment.transform 12 3822 env1084 = env1085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env1084 == env1085) = true)

theorem identity1085 : scanCanonicalize (H12AffineFastState.compose env1085 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1085 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1086 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,554,2794,603,2786,2665,674,2081,5,2786,722,33,184,139,2658,233,2048,602,723,2081,5,1,253,1,603,512]

theorem envBound1086 : H12AffineFastState.Bounded env1086 := by
  intro p hp
  have h : env1086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1085_1086 : H12AffineEnvironment.transform 9 4 env1085 = env1086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1085 == env1086) = true)

theorem identity1086 : scanCanonicalize (H12AffineFastState.compose env1086 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1086 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1087 : List Nat := [2,4,8,16,32,64,121,5,512,4,2048,554,2579,603,2587,2665,603,2081,5,2587,555,33,65,114,2658,16,2048,602,554,2081,5,1,4,1,603,512]

theorem envBound1087 : H12AffineFastState.Bounded env1087 := by
  intro p hp
  have h : env1087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1086_1087 : H12AffineEnvironment.transform 6 121 env1086 = env1087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1086 == env1087) = true)

theorem identity1087 : scanCanonicalize (H12AffineFastState.compose env1087 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound1087 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1088 : List Nat := [2,4,8,16,32,64,121,5,512,4,609,554,114,603,122,8,603,576,5,122,555,33,65,114,3,16,609,602,554,576,5,1,4,1,603,512]

theorem envBound1088 : H12AffineFastState.Bounded env1088 := by
  intro p hp
  have h : env1088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1087_1088 : H12AffineEnvironment.transform 10 609 env1087 = env1088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env1087 == env1088) = true)

theorem identity1088 : scanCanonicalize (H12AffineFastState.compose env1088 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound1088 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1089 : List Nat := [2,4,8,16,26,64,67,5,512,4,603,528,72,603,64,8,603,576,5,64,529,27,65,72,3,16,603,602,528,576,5,1,4,1,603,512]

theorem envBound1089 : H12AffineFastState.Bounded env1089 := by
  intro p hp
  have h : env1089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1088_1089 : H12AffineEnvironment.transform 4 26 env1088 = env1089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env1088 == env1089) = true)

def env1090 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74883,8201,2097152,73891,184,73737,8328,73835,149752,16385,151552,2081,74883,1,73854,1,131320,512]

theorem envBound1090 : H12AffineFastState.Bounded env1090 := by
  intro p hp
  have h : env1090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1078_1090 : H12AffineEnvironment.transform 7 253 env1078 = env1090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1078 == env1090) = true)

theorem identity1090 : scanCanonicalize (H12AffineFastState.compose env1090 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78034) := by decide +kernel

theorem selectedBound1090 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1091 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74883,8201,78034,73891,184,73737,8328,73835,149752,16385,151552,2081,74883,1,73854,1,131320,512]

theorem envBound1091 : H12AffineFastState.Bounded env1091 := by
  intro p hp
  have h : env1091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1090_1091 : H12AffineEnvironment.transform 20 78034 env1090 = env1091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78034 env1090 == env1091) = true)

theorem identity1091 : scanCanonicalize (H12AffineFastState.compose env1091 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound1091 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1092 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210516,74883,8201,78034,73891,184,73737,8328,73835,136951,7694,134671,2081,74883,1,73854,1,131320,512]

theorem envBound1092 : H12AffineFastState.Bounded env1092 := by
  intro p hp
  have h : env1092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1091_1092 : H12AffineEnvironment.transform 13 7695 env1091 = env1092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env1091 == env1092) = true)

def env1093 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205376,74883,8201,74950,73891,184,73737,8328,73835,131811,2586,134671,2081,74883,1,73854,1,131320,512]

theorem envBound1093 : H12AffineFastState.Bounded env1093 := by
  intro p hp
  have h : env1093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1092_1093 : H12AffineEnvironment.transform 11 1044 env1092 = env1093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1092 == env1093) = true)

def env1094 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2080,74883,8201,74950,73891,184,73737,8328,73835,75907,2586,74863,2081,74883,1,73854,1,76440,512]

theorem envBound1094 : H12AffineFastState.Bounded env1094 := by
  intro p hp
  have h : env1094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1093_1094 : H12AffineEnvironment.transform 16 76384 env1093 = env1094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1093 == env1094) = true)

theorem identity1094 : scanCanonicalize (H12AffineFastState.compose env1094 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1094 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1095 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2587,3615,65536,66678,2080,68245,3615,68304,69301,184,69151,3742,69245,67221,2586,68217,2081,68245,1,69224,1,66702,512]

theorem envBound1095 : H12AffineFastState.Bounded env1095 := by
  intro p hp
  have h : env1095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1094_1095 : H12AffineEnvironment.transform 12 3606 env1094 = env1095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1094 == env1095) = true)

theorem identity1095 : scanCanonicalize (H12AffineFastState.compose env1095 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1095 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1096 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2587,3615,3732,2786,2080,1025,3615,1092,33,184,139,3742,233,2049,2586,1261,2081,1025,1,252,1,2586,512]

theorem envBound1096 : H12AffineFastState.Bounded env1096 := by
  intro p hp
  have h : env1096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1095_1096 : H12AffineEnvironment.transform 15 3732 env1095 = env1096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1095 == env1096) = true)

theorem identity1096 : scanCanonicalize (H12AffineFastState.compose env1096 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1096 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1097 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2627,2587,2634,2753,2786,2080,84,2634,17,33,184,139,2763,233,2049,2586,184,2081,84,1,252,1,2586,512]

theorem envBound1097 : H12AffineFastState.Bounded env1097 := by
  intro p hp
  have h : env1097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1096_1097 : H12AffineEnvironment.transform 9 85 env1096 = env1097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1096 == env1097) = true)

theorem identity1097 : scanCanonicalize (H12AffineFastState.compose env1097 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1097 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1098 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,65,2627,2587,2634,2665,2634,2080,84,2634,17,33,16,35,2659,65,2049,2586,16,2081,84,1,84,1,2586,512]

theorem envBound1098 : H12AffineFastState.Bounded env1098 := by
  intro p hp
  have h : env1098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1097_1098 : H12AffineEnvironment.transform 6 40 env1097 = env1098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1097 == env1098) = true)

def env1099 : List Nat := [2,4,8,16,16,64,24,85,512,85,2048,65,2627,2587,2634,2649,2634,2064,84,2634,17,17,16,19,2643,65,2049,2586,16,2065,84,1,84,1,2586,512]

theorem envBound1099 : H12AffineFastState.Bounded env1099 := by
  intro p hp
  have h : env1099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1098_1099 : H12AffineEnvironment.transform 4 16 env1098 = env1099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1098 == env1099) = true)

def env1100 : List Nat := [2,4,8,16,16,64,24,85,512,85,0,65,579,539,586,601,586,16,84,586,17,17,16,19,595,65,1,538,16,17,84,1,84,1,538,512]

theorem envBound1100 : H12AffineFastState.Bounded env1100 := by
  intro p hp
  have h : env1100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1099_1100 : H12AffineEnvironment.transform 10 0 env1099 = env1100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1099 == env1100) = true)

theorem identity1100 : scanCanonicalize (H12AffineFastState.compose env1100 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound1100 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1101 : List Nat := [2,4,8,16,16,13,24,24,512,24,0,12,526,539,519,532,519,16,25,519,17,17,16,19,542,12,1,538,16,17,25,1,25,1,538,512]

theorem envBound1101 : H12AffineFastState.Bounded env1101 := by
  intro p hp
  have h : env1101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1100_1101 : H12AffineEnvironment.transform 5 13 env1100 = env1101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env1100 == env1101) = true)

def env1102 : List Nat := [2,4,4,16,16,1,20,20,512,20,0,0,514,535,519,532,519,16,21,519,17,17,16,19,530,0,1,534,16,17,21,1,21,1,534,512]

theorem envBound1102 : H12AffineFastState.Bounded env1102 := by
  intro p hp
  have h : env1102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1101_1102 : H12AffineEnvironment.transform 2 4 env1101 = env1102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1101 == env1102) = true)

def leafEnv1102 : List Nat := [2,4,4,16,16,1,20,20,512,20,0,0,514,535,519,532,519,16,21,519,17,17,16,19,21,530,1,0,1,534,16,17,21,1,21,1,4,517,534,512,1,16,0]

def active1102 : List Nat := [0,1,3,8]

def tree1102 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1102 : H12WitnessSearch.Good tree1102 := H12GlobalWitnessIndex.good

theorem leafIdentity1102 : H12AffineFastState.composeSystem env1102 rootObs = leafEnv1102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1102 rootObs == leafEnv1102) = true)

theorem terminalChecked1102 : H12PackedTerminal.terminalCheckFast leafEnv1102 active1102 tree1102 = true := by decide +kernel

def env1103 : List Nat := [2,4,5,16,16,0,21,21,512,21,0,1,515,534,519,532,519,16,20,519,17,17,16,19,531,1,1,535,16,17,20,1,20,1,535,512]

theorem envBound1103 : H12AffineFastState.Bounded env1103 := by
  intro p hp
  have h : env1103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1101_1103 : H12AffineEnvironment.transform 2 5 env1101 = env1103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1101 == env1103) = true)

theorem identity1103 : scanCanonicalize (H12AffineFastState.compose env1103 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1104 : List Nat := [2,4,5,16,16,0,21,21,23,21,0,1,20,1,16,3,16,16,20,16,17,17,16,19,4,1,1,0,16,17,20,1,20,1,0,23]

theorem envBound1104 : H12AffineFastState.Bounded env1104 := by
  intro p hp
  have h : env1104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1103_1104 : H12AffineEnvironment.transform 8 23 env1103 = env1104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1103 == env1104) = true)

def leafEnv1104 : List Nat := [2,4,5,16,16,0,21,21,23,21,0,1,20,1,16,3,16,16,20,16,17,17,16,19,20,4,1,1,1,0,16,17,20,1,20,1,4,18,0,23,1,16,0]

def active1104 : List Nat := [0,1,3]

def tree1104 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1104 : H12WitnessSearch.Good tree1104 := H12GlobalWitnessIndex.good

theorem leafIdentity1104 : H12AffineFastState.composeSystem env1104 rootObs = leafEnv1104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1104 rootObs == leafEnv1104) = true)

theorem terminalChecked1104 : H12PackedTerminal.terminalCheckFast leafEnv1104 active1104 tree1104 = true := by decide +kernel

def env1105 : List Nat := [2,4,8,16,16,64,24,85,512,85,1,65,578,538,587,600,587,17,84,587,17,17,16,19,594,65,0,539,16,16,84,1,84,1,539,512]

theorem envBound1105 : H12AffineFastState.Bounded env1105 := by
  intro p hp
  have h : env1105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1099_1105 : H12AffineEnvironment.transform 10 1 env1099 = env1105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1099 == env1105) = true)

theorem identity1105 : scanCanonicalize (H12AffineFastState.compose env1105 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound1105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1106 : List Nat := [2,4,8,16,16,28,24,9,512,9,1,29,542,538,535,516,535,17,8,535,17,17,16,19,526,29,0,539,16,16,8,1,8,1,539,512]

theorem envBound1106 : H12AffineFastState.Bounded env1106 := by
  intro p hp
  have h : env1106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1105_1106 : H12AffineEnvironment.transform 5 28 env1105 = env1106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env1105 == env1106) = true)

def env1107 : List Nat := [2,4,8,12,12,0,4,9,512,9,1,1,514,518,523,516,523,13,8,523,13,13,12,15,526,1,0,519,12,12,8,1,8,1,519,512]

theorem envBound1107 : H12AffineFastState.Bounded env1107 := by
  intro p hp
  have h : env1107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1106_1107 : H12AffineEnvironment.transform 3 12 env1106 = env1107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1106 == env1107) = true)

def leafEnv1107 : List Nat := [2,4,8,12,12,0,4,9,512,9,1,1,514,518,523,516,523,13,8,523,13,13,12,15,8,526,1,1,0,519,12,12,8,1,8,1,4,521,519,512,1,12,0]

def active1107 : List Nat := [0,1,2,8]

def tree1107 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1107 : H12WitnessSearch.Good tree1107 := H12GlobalWitnessIndex.good

theorem leafIdentity1107 : H12AffineFastState.composeSystem env1107 rootObs = leafEnv1107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1107 rootObs == leafEnv1107) = true)

theorem terminalChecked1107 : H12PackedTerminal.terminalCheckFast leafEnv1107 active1107 tree1107 = true := by decide +kernel

def env1108 : List Nat := [2,4,8,13,13,1,5,9,512,9,1,0,515,519,522,516,522,12,8,522,12,12,13,14,526,0,0,518,13,13,8,1,8,1,518,512]

theorem envBound1108 : H12AffineFastState.Bounded env1108 := by
  intro p hp
  have h : env1108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1106_1108 : H12AffineEnvironment.transform 3 13 env1106 = env1108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1106 == env1108) = true)

theorem identity1108 : scanCanonicalize (H12AffineFastState.compose env1108 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1109 : List Nat := [2,4,8,13,13,1,5,9,6,9,1,0,5,1,12,2,12,12,8,12,12,12,13,14,8,0,0,0,13,13,8,1,8,1,0,6]

theorem envBound1109 : H12AffineFastState.Bounded env1109 := by
  intro p hp
  have h : env1109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1108_1109 : H12AffineEnvironment.transform 8 6 env1108 = env1109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1108 == env1109) = true)

def leafEnv1109 : List Nat := [2,4,8,13,13,1,5,9,6,9,1,0,5,1,12,2,12,12,8,12,12,12,13,14,8,8,1,0,0,0,13,13,8,1,8,1,4,14,0,6,1,13,0]

def active1109 : List Nat := [0,1,2]

def tree1109 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1109 : H12WitnessSearch.Good tree1109 := H12GlobalWitnessIndex.good

theorem leafIdentity1109 : H12AffineFastState.composeSystem env1109 rootObs = leafEnv1109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1109 rootObs == leafEnv1109) = true)

theorem terminalChecked1109 : H12PackedTerminal.terminalCheckFast leafEnv1109 active1109 tree1109 = true := by decide +kernel

def env1110 : List Nat := [2,4,8,16,17,64,25,85,512,85,2048,65,2627,2587,2634,2648,2634,2065,84,2634,17,16,16,18,2642,65,2049,2586,16,2064,84,1,84,1,2586,512]

theorem envBound1110 : H12AffineFastState.Bounded env1110 := by
  intro p hp
  have h : env1110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1098_1110 : H12AffineEnvironment.transform 4 17 env1098 = env1110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1098 == env1110) = true)

def env1111 : List Nat := [2,4,8,16,17,64,25,85,512,85,0,65,579,539,586,600,586,17,84,586,17,16,16,18,594,65,1,538,16,16,84,1,84,1,538,512]

theorem envBound1111 : H12AffineFastState.Bounded env1111 := by
  intro p hp
  have h : env1111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1110_1111 : H12AffineEnvironment.transform 10 0 env1110 = env1111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1110 == env1111) = true)

theorem identity1111 : scanCanonicalize (H12AffineFastState.compose env1111 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1112 : List Nat := [2,4,8,16,17,64,25,85,6,85,0,65,69,29,76,94,76,17,84,76,17,16,16,18,84,65,1,28,16,16,84,1,84,1,28,6]

theorem envBound1112 : H12AffineFastState.Bounded env1112 := by
  intro p hp
  have h : env1112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1111_1112 : H12AffineEnvironment.transform 8 6 env1111 = env1112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1111 == env1112) = true)

def env1113 : List Nat := [2,4,8,16,17,0,25,21,6,21,0,1,5,29,12,30,12,17,20,12,17,16,16,18,20,1,1,28,16,16,20,1,20,1,28,6]

theorem envBound1113 : H12AffineFastState.Bounded env1113 := by
  intro p hp
  have h : env1113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1112_1113 : H12AffineEnvironment.transform 5 0 env1112 = env1113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1112 == env1113) = true)

theorem identity1113 : scanCanonicalize (H12AffineFastState.compose env1113 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1114 : List Nat := [2,4,8,13,12,0,4,8,6,8,0,1,5,0,12,3,12,12,9,12,12,13,13,15,9,1,1,1,13,13,9,1,9,1,1,6]

theorem envBound1114 : H12AffineFastState.Bounded env1114 := by
  intro p hp
  have h : env1114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1113_1114 : H12AffineEnvironment.transform 3 13 env1113 = env1114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1113 == env1114) = true)

def leafEnv1114 : List Nat := [2,4,8,13,12,0,4,8,6,8,0,1,5,0,12,3,12,12,9,12,12,13,13,15,9,9,1,1,1,1,13,13,9,1,9,1,4,14,1,6,1,13,0]

def active1114 : List Nat := [0,1,2]

def tree1114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1114 : H12WitnessSearch.Good tree1114 := H12GlobalWitnessIndex.good

theorem leafIdentity1114 : H12AffineFastState.composeSystem env1114 rootObs = leafEnv1114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1114 rootObs == leafEnv1114) = true)

theorem terminalChecked1114 : H12PackedTerminal.terminalCheckFast leafEnv1114 active1114 tree1114 = true := by decide +kernel

def env1115 : List Nat := [2,4,8,16,17,1,25,20,6,20,0,0,4,29,13,31,13,17,21,13,17,16,16,18,21,0,1,28,16,16,21,1,21,1,28,6]

theorem envBound1115 : H12AffineFastState.Bounded env1115 := by
  intro p hp
  have h : env1115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1112_1115 : H12AffineEnvironment.transform 5 1 env1112 = env1115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1112 == env1115) = true)

def leafEnv1115 : List Nat := [2,4,8,16,17,1,25,20,6,20,0,0,4,29,13,31,13,17,21,13,17,16,16,18,21,21,1,0,1,28,16,16,21,1,21,1,4,15,28,6,1,16,0]

def active1115 : List Nat := [0,1,2,3]

def tree1115 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1115 : H12WitnessSearch.Good tree1115 := H12GlobalWitnessIndex.good

theorem leafIdentity1115 : H12AffineFastState.composeSystem env1115 rootObs = leafEnv1115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1115 rootObs == leafEnv1115) = true)

theorem terminalChecked1115 : H12PackedTerminal.terminalCheckFast leafEnv1115 active1115 tree1115 = true := by decide +kernel

def env1116 : List Nat := [2,4,8,16,17,64,25,85,512,85,1,65,578,538,587,601,587,16,84,587,17,16,16,18,595,65,0,539,16,17,84,1,84,1,539,512]

theorem envBound1116 : H12AffineFastState.Bounded env1116 := by
  intro p hp
  have h : env1116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1110_1116 : H12AffineEnvironment.transform 10 1 env1110 = env1116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1110 == env1116) = true)

theorem identity1116 : scanCanonicalize (H12AffineFastState.compose env1116 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1116 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1117 : List Nat := [2,4,8,16,17,64,25,85,23,85,1,65,85,13,92,78,92,16,84,92,17,16,16,18,68,65,0,12,16,17,84,1,84,1,12,23]

theorem envBound1117 : H12AffineFastState.Bounded env1117 := by
  intro p hp
  have h : env1117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1116_1117 : H12AffineEnvironment.transform 8 23 env1116 = env1117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1116 == env1117) = true)

def env1118 : List Nat := [2,4,8,16,17,0,25,21,23,21,1,1,21,13,28,14,28,16,20,28,17,16,16,18,4,1,0,12,16,17,20,1,20,1,12,23]

theorem envBound1118 : H12AffineFastState.Bounded env1118 := by
  intro p hp
  have h : env1118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1117_1118 : H12AffineEnvironment.transform 5 0 env1117 = env1118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1117 == env1118) = true)

def leafEnv1118 : List Nat := [2,4,8,16,17,0,25,21,23,21,1,1,21,13,28,14,28,16,20,28,17,16,16,18,20,4,1,1,0,12,16,17,20,1,20,1,4,30,12,23,1,16,0]

def active1118 : List Nat := [0,1,2,3]

def tree1118 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1118 : H12WitnessSearch.Good tree1118 := H12GlobalWitnessIndex.good

theorem leafIdentity1118 : H12AffineFastState.composeSystem env1118 rootObs = leafEnv1118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1118 rootObs == leafEnv1118) = true)

theorem terminalChecked1118 : H12PackedTerminal.terminalCheckFast leafEnv1118 active1118 tree1118 = true := by decide +kernel

def env1119 : List Nat := [2,4,8,16,17,1,25,20,23,20,1,0,20,13,29,15,29,16,21,29,17,16,16,18,5,0,0,12,16,17,21,1,21,1,12,23]

theorem envBound1119 : H12AffineFastState.Bounded env1119 := by
  intro p hp
  have h : env1119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1117_1119 : H12AffineEnvironment.transform 5 1 env1117 = env1119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1117 == env1119) = true)

theorem identity1119 : scanCanonicalize (H12AffineFastState.compose env1119 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1120 : List Nat := [2,4,5,16,17,1,20,20,23,20,1,0,20,0,16,2,16,16,21,16,17,16,16,18,5,0,0,1,16,17,21,1,21,1,1,23]

theorem envBound1120 : H12AffineFastState.Bounded env1120 := by
  intro p hp
  have h : env1120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1119_1120 : H12AffineEnvironment.transform 2 5 env1119 = env1120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1119 == env1120) = true)

def leafEnv1120 : List Nat := [2,4,5,16,17,1,20,20,23,20,1,0,20,0,16,2,16,16,21,16,17,16,16,18,21,5,1,0,0,1,16,17,21,1,21,1,4,18,1,23,1,16,0]

def active1120 : List Nat := [0,1,3]

def tree1120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1120 : H12WitnessSearch.Good tree1120 := H12GlobalWitnessIndex.good

theorem leafIdentity1120 : H12AffineFastState.composeSystem env1120 rootObs = leafEnv1120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1120 rootObs == leafEnv1120) = true)

theorem terminalChecked1120 : H12PackedTerminal.terminalCheckFast leafEnv1120 active1120 tree1120 = true := by decide +kernel

def env1121 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2081,74883,8201,74950,73891,184,73737,8328,73835,75906,2586,74862,2081,74883,1,73854,1,76441,512]

theorem envBound1121 : H12AffineFastState.Bounded env1121 := by
  intro p hp
  have h : env1121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1093_1121 : H12AffineEnvironment.transform 16 76385 env1093 = env1121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1093 == env1121) = true)

theorem identity1121 : scanCanonicalize (H12AffineFastState.compose env1121 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound1121 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1122 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,98,10755,2081,9441,8201,9380,8385,184,8299,8328,8201,10464,2586,9228,2081,9441,1,8220,1,11003,512]

theorem envBound1122 : H12AffineFastState.Bounded env1122 := by
  intro p hp
  have h : env1122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1121_1122 : H12AffineEnvironment.transform 15 98 env1121 = env1122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env1121 == env1122) = true)

def env1123 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205377,74883,8201,74951,73891,184,73737,8328,73835,131810,2587,134671,2081,74883,1,73854,1,131320,512]

theorem envBound1123 : H12AffineFastState.Bounded env1123 := by
  intro p hp
  have h : env1123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1092_1123 : H12AffineEnvironment.transform 11 1045 env1092 = env1123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1092 == env1123) = true)

def env1124 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2081,74883,8201,74951,73891,184,73737,8328,73835,75906,2587,74863,2081,74883,1,73854,1,76440,512]

theorem envBound1124 : H12AffineFastState.Bounded env1124 := by
  intro p hp
  have h : env1124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1123_1124 : H12AffineEnvironment.transform 16 76384 env1123 = env1124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1123 == env1124) = true)

theorem identity1124 : scanCanonicalize (H12AffineFastState.compose env1124 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 224) := by decide +kernel

theorem selectedBound1124 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1125 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,224,2586,233,65536,68224,2081,66659,233,66599,65603,184,65769,104,65675,67682,2587,66703,2081,66659,1,65694,1,68216,512]

theorem envBound1125 : H12AffineFastState.Bounded env1125 := by
  intro p hp
  have h : env1125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1124_1125 : H12AffineEnvironment.transform 12 224 env1124 = env1125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env1124 == env1125) = true)

def env1126 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2080,74883,8201,74951,73891,184,73737,8328,73835,75907,2587,74862,2081,74883,1,73854,1,76441,512]

theorem envBound1126 : H12AffineFastState.Bounded env1126 := by
  intro p hp
  have h : env1126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1123_1126 : H12AffineEnvironment.transform 16 76385 env1123 = env1126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1123 == env1126) = true)

theorem identity1126 : scanCanonicalize (H12AffineFastState.compose env1126 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1126 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1127 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,3732,9461,2080,10775,8201,10835,11831,184,11933,8328,12031,9751,2587,11002,2081,10775,1,12010,1,9229,512]

theorem envBound1127 : H12AffineFastState.Bounded env1127 := by
  intro p hp
  have h : env1127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1126_1127 : H12AffineEnvironment.transform 15 3732 env1126 = env1127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1126 == env1127) = true)

theorem identity1127 : scanCanonicalize (H12AffineFastState.compose env1127 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1127 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1128 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2586,3615,3732,2787,2080,1025,3615,1093,33,184,139,3742,233,2049,2587,1260,2081,1025,1,252,1,2587,512]

theorem envBound1128 : H12AffineFastState.Bounded env1128 := by
  intro p hp
  have h : env1128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1127_1128 : H12AffineEnvironment.transform 12 3606 env1127 = env1128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1127 == env1128) = true)

theorem identity1128 : scanCanonicalize (H12AffineFastState.compose env1128 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1128 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1129 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2627,2586,2634,2753,2787,2080,84,2634,16,33,184,139,2763,233,2049,2587,185,2081,84,1,252,1,2587,512]

theorem envBound1129 : H12AffineFastState.Bounded env1129 := by
  intro p hp
  have h : env1129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1128_1129 : H12AffineEnvironment.transform 9 85 env1128 = env1129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1128 == env1129) = true)

theorem identity1129 : scanCanonicalize (H12AffineFastState.compose env1129 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1129 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1130 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,64,2627,2586,2634,2665,2635,2080,84,2634,16,33,16,35,2659,65,2049,2587,17,2081,84,1,84,1,2587,512]

theorem envBound1130 : H12AffineFastState.Bounded env1130 := by
  intro p hp
  have h : env1130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1129_1130 : H12AffineEnvironment.transform 6 40 env1129 = env1130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1129 == env1130) = true)

def env1131 : List Nat := [2,4,8,16,16,64,24,85,512,85,2048,64,2627,2586,2634,2649,2635,2064,84,2634,16,17,16,19,2643,65,2049,2587,17,2065,84,1,84,1,2587,512]

theorem envBound1131 : H12AffineFastState.Bounded env1131 := by
  intro p hp
  have h : env1131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1130_1131 : H12AffineEnvironment.transform 4 16 env1130 = env1131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1130 == env1131) = true)

def env1132 : List Nat := [2,4,8,16,16,64,24,85,512,85,0,64,579,538,586,601,587,16,84,586,16,17,16,19,595,65,1,539,17,17,84,1,84,1,539,512]

theorem envBound1132 : H12AffineFastState.Bounded env1132 := by
  intro p hp
  have h : env1132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1131_1132 : H12AffineEnvironment.transform 10 0 env1131 = env1132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1131 == env1132) = true)

theorem identity1132 : scanCanonicalize (H12AffineFastState.compose env1132 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound1132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1133 : List Nat := [2,4,8,16,16,64,24,85,70,85,0,64,5,92,12,31,13,16,84,12,16,17,16,19,21,65,1,93,17,17,84,1,84,1,93,70]

theorem envBound1133 : H12AffineFastState.Bounded env1133 := by
  intro p hp
  have h : env1133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1132_1133 : H12AffineEnvironment.transform 8 70 env1132 = env1133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env1132 == env1133) = true)

def env1134 : List Nat := [2,4,8,16,16,0,24,21,6,21,0,0,5,28,12,31,13,16,20,12,16,17,16,19,21,1,1,29,17,17,20,1,20,1,29,6]

theorem envBound1134 : H12AffineFastState.Bounded env1134 := by
  intro p hp
  have h : env1134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1133_1134 : H12AffineEnvironment.transform 5 0 env1133 = env1134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1133 == env1134) = true)

def leafEnv1134 : List Nat := [2,4,8,16,16,0,24,21,6,21,0,0,5,28,12,31,13,16,20,12,16,17,16,19,20,21,1,1,1,29,17,17,20,1,20,1,4,14,29,6,1,17,0]

def active1134 : List Nat := [0,1,2,3]

def tree1134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1134 : H12WitnessSearch.Good tree1134 := H12GlobalWitnessIndex.good

theorem leafIdentity1134 : H12AffineFastState.composeSystem env1134 rootObs = leafEnv1134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1134 rootObs == leafEnv1134) = true)

theorem terminalChecked1134 : H12PackedTerminal.terminalCheckFast leafEnv1134 active1134 tree1134 = true := by decide +kernel

def env1135 : List Nat := [2,4,8,16,16,1,24,20,7,20,0,1,5,29,12,31,13,16,21,12,16,17,16,19,21,0,1,28,17,17,21,1,21,1,28,7]

theorem envBound1135 : H12AffineFastState.Bounded env1135 := by
  intro p hp
  have h : env1135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1133_1135 : H12AffineEnvironment.transform 5 1 env1133 = env1135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1133 == env1135) = true)

theorem identity1135 : scanCanonicalize (H12AffineFastState.compose env1135 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1136 : List Nat := [2,4,8,13,13,1,5,9,7,9,0,1,5,0,12,2,13,13,8,12,13,12,13,14,8,0,1,1,12,12,8,1,8,1,1,7]

theorem envBound1136 : H12AffineFastState.Bounded env1136 := by
  intro p hp
  have h : env1136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1135_1136 : H12AffineEnvironment.transform 3 13 env1135 = env1136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1135 == env1136) = true)

def leafEnv1136 : List Nat := [2,4,8,13,13,1,5,9,7,9,0,1,5,0,12,2,13,13,8,12,13,12,13,14,8,8,1,0,1,1,12,12,8,1,8,1,4,14,1,7,1,12,0]

def active1136 : List Nat := [0,1,2]

def tree1136 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1136 : H12WitnessSearch.Good tree1136 := H12GlobalWitnessIndex.good

theorem leafIdentity1136 : H12AffineFastState.composeSystem env1136 rootObs = leafEnv1136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1136 rootObs == leafEnv1136) = true)

theorem terminalChecked1136 : H12PackedTerminal.terminalCheckFast leafEnv1136 active1136 tree1136 = true := by decide +kernel

def env1137 : List Nat := [2,4,8,16,16,64,24,85,512,85,1,64,578,539,587,600,586,17,84,587,16,17,16,19,594,65,0,538,17,16,84,1,84,1,538,512]

theorem envBound1137 : H12AffineFastState.Bounded env1137 := by
  intro p hp
  have h : env1137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1131_1137 : H12AffineEnvironment.transform 10 1 env1131 = env1137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1131 == env1137) = true)

theorem identity1137 : scanCanonicalize (H12AffineFastState.compose env1137 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound1137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1138 : List Nat := [2,4,8,16,16,64,24,85,86,85,1,64,20,77,29,14,28,17,84,29,16,17,16,19,4,65,0,76,17,16,84,1,84,1,76,86]

theorem envBound1138 : H12AffineFastState.Bounded env1138 := by
  intro p hp
  have h : env1138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1137_1138 : H12AffineEnvironment.transform 8 86 env1137 = env1138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env1137 == env1138) = true)

def env1139 : List Nat := [2,4,8,16,16,0,24,21,22,21,1,0,20,13,29,14,28,17,20,29,16,17,16,19,4,1,0,12,17,16,20,1,20,1,12,22]

theorem envBound1139 : H12AffineFastState.Bounded env1139 := by
  intro p hp
  have h : env1139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1138_1139 : H12AffineEnvironment.transform 5 0 env1138 = env1139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1138 == env1139) = true)

theorem identity1139 : scanCanonicalize (H12AffineFastState.compose env1139 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1140 : List Nat := [2,4,5,16,16,0,21,21,22,21,1,0,20,0,16,3,17,17,20,16,16,17,16,19,4,1,0,1,17,16,20,1,20,1,1,22]

theorem envBound1140 : H12AffineFastState.Bounded env1140 := by
  intro p hp
  have h : env1140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1139_1140 : H12AffineEnvironment.transform 2 5 env1139 = env1140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1139 == env1140) = true)

def leafEnv1140 : List Nat := [2,4,5,16,16,0,21,21,22,21,1,0,20,0,16,3,17,17,20,16,16,17,16,19,20,4,1,1,0,1,17,16,20,1,20,1,4,18,1,22,1,17,0]

def active1140 : List Nat := [0,1,3]

def tree1140 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1140 : H12WitnessSearch.Good tree1140 := H12GlobalWitnessIndex.good

theorem leafIdentity1140 : H12AffineFastState.composeSystem env1140 rootObs = leafEnv1140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1140 rootObs == leafEnv1140) = true)

theorem terminalChecked1140 : H12PackedTerminal.terminalCheckFast leafEnv1140 active1140 tree1140 = true := by decide +kernel

def env1141 : List Nat := [2,4,8,16,16,1,24,20,23,20,1,1,20,12,29,14,28,17,21,29,16,17,16,19,4,0,0,13,17,16,21,1,21,1,13,23]

theorem envBound1141 : H12AffineFastState.Bounded env1141 := by
  intro p hp
  have h : env1141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1138_1141 : H12AffineEnvironment.transform 5 1 env1138 = env1141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1138 == env1141) = true)

def leafEnv1141 : List Nat := [2,4,8,16,16,1,24,20,23,20,1,1,20,12,29,14,28,17,21,29,16,17,16,19,21,4,1,0,0,13,17,16,21,1,21,1,4,31,13,23,1,17,0]

def active1141 : List Nat := [0,1,2,3]

def tree1141 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1141 : H12WitnessSearch.Good tree1141 := H12GlobalWitnessIndex.good

theorem leafIdentity1141 : H12AffineFastState.composeSystem env1141 rootObs = leafEnv1141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1141 rootObs == leafEnv1141) = true)

theorem terminalChecked1141 : H12PackedTerminal.terminalCheckFast leafEnv1141 active1141 tree1141 = true := by decide +kernel

def env1142 : List Nat := [2,4,8,16,17,64,25,85,512,85,2048,64,2627,2586,2634,2648,2635,2065,84,2634,16,16,16,18,2642,65,2049,2587,17,2064,84,1,84,1,2587,512]

theorem envBound1142 : H12AffineFastState.Bounded env1142 := by
  intro p hp
  have h : env1142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1130_1142 : H12AffineEnvironment.transform 4 17 env1130 = env1142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1130 == env1142) = true)

def env1143 : List Nat := [2,4,8,16,17,64,25,85,512,85,0,64,579,538,586,600,587,17,84,586,16,16,16,18,594,65,1,539,17,16,84,1,84,1,539,512]

theorem envBound1143 : H12AffineFastState.Bounded env1143 := by
  intro p hp
  have h : env1143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1142_1143 : H12AffineEnvironment.transform 10 0 env1142 = env1143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1142 == env1143) = true)

theorem identity1143 : scanCanonicalize (H12AffineFastState.compose env1143 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1144 : List Nat := [2,4,5,16,17,64,20,85,512,85,0,64,579,535,583,597,582,17,84,583,16,16,16,18,594,65,1,534,17,16,84,1,84,1,534,512]

theorem envBound1144 : H12AffineFastState.Bounded env1144 := by
  intro p hp
  have h : env1144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1143_1144 : H12AffineEnvironment.transform 2 5 env1143 = env1144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1143 == env1144) = true)

def env1145 : List Nat := [2,4,5,16,17,0,20,21,512,21,0,0,515,535,519,533,518,17,20,519,16,16,16,18,530,1,1,534,17,16,20,1,20,1,534,512]

theorem envBound1145 : H12AffineFastState.Bounded env1145 := by
  intro p hp
  have h : env1145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1144_1145 : H12AffineEnvironment.transform 5 0 env1144 = env1145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1144 == env1145) = true)

def leafEnv1145 : List Nat := [2,4,5,16,17,0,20,21,512,21,0,0,515,535,519,533,518,17,20,519,16,16,16,18,20,530,1,1,1,534,17,16,20,1,20,1,4,517,534,512,1,17,0]

def active1145 : List Nat := [0,1,3,8]

def tree1145 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1145 : H12WitnessSearch.Good tree1145 := H12GlobalWitnessIndex.good

theorem leafIdentity1145 : H12AffineFastState.composeSystem env1145 rootObs = leafEnv1145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1145 rootObs == leafEnv1145) = true)

theorem terminalChecked1145 : H12PackedTerminal.terminalCheckFast leafEnv1145 active1145 tree1145 = true := by decide +kernel

def env1146 : List Nat := [2,4,5,16,17,1,20,20,512,20,0,1,514,535,518,532,519,17,21,518,16,16,16,18,531,0,1,534,17,16,21,1,21,1,534,512]

theorem envBound1146 : H12AffineFastState.Bounded env1146 := by
  intro p hp
  have h : env1146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1144_1146 : H12AffineEnvironment.transform 5 1 env1144 = env1146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1144 == env1146) = true)

theorem identity1146 : scanCanonicalize (H12AffineFastState.compose env1146 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1146 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1147 : List Nat := [2,4,5,16,17,1,20,20,22,20,0,1,20,1,16,2,17,17,21,16,16,16,16,18,5,0,1,0,17,16,21,1,21,1,0,22]

theorem envBound1147 : H12AffineFastState.Bounded env1147 := by
  intro p hp
  have h : env1147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1146_1147 : H12AffineEnvironment.transform 8 22 env1146 = env1147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1146 == env1147) = true)

def leafEnv1147 : List Nat := [2,4,5,16,17,1,20,20,22,20,0,1,20,1,16,2,17,17,21,16,16,16,16,18,21,5,1,0,1,0,17,16,21,1,21,1,4,18,0,22,1,17,0]

def active1147 : List Nat := [0,1,3]

def tree1147 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1147 : H12WitnessSearch.Good tree1147 := H12GlobalWitnessIndex.good

theorem leafIdentity1147 : H12AffineFastState.composeSystem env1147 rootObs = leafEnv1147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1147 rootObs == leafEnv1147) = true)

theorem terminalChecked1147 : H12PackedTerminal.terminalCheckFast leafEnv1147 active1147 tree1147 = true := by decide +kernel

def env1148 : List Nat := [2,4,8,16,17,64,25,85,512,85,1,64,578,539,587,601,586,16,84,587,16,16,16,18,595,65,0,538,17,17,84,1,84,1,538,512]

theorem envBound1148 : H12AffineFastState.Bounded env1148 := by
  intro p hp
  have h : env1148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1142_1148 : H12AffineEnvironment.transform 10 1 env1142 = env1148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1142 == env1148) = true)

theorem identity1148 : scanCanonicalize (H12AffineFastState.compose env1148 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1149 : List Nat := [2,4,8,13,12,64,4,72,512,72,1,64,578,518,587,580,586,13,73,587,13,13,13,15,590,65,0,519,12,12,73,1,73,1,519,512]

theorem envBound1149 : H12AffineFastState.Bounded env1149 := by
  intro p hp
  have h : env1149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1148_1149 : H12AffineEnvironment.transform 3 13 env1148 = env1149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1148 == env1149) = true)

def env1150 : List Nat := [2,4,8,13,12,0,4,8,512,8,1,0,514,518,523,516,522,13,9,523,13,13,13,15,526,1,0,519,12,12,9,1,9,1,519,512]

theorem envBound1150 : H12AffineFastState.Bounded env1150 := by
  intro p hp
  have h : env1150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1149_1150 : H12AffineEnvironment.transform 5 0 env1149 = env1150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1149 == env1150) = true)

theorem identity1150 : scanCanonicalize (H12AffineFastState.compose env1150 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1151 : List Nat := [2,4,8,13,12,0,4,8,7,8,1,0,5,1,12,3,13,13,9,12,13,13,13,15,9,1,0,0,12,12,9,1,9,1,0,7]

theorem envBound1151 : H12AffineFastState.Bounded env1151 := by
  intro p hp
  have h : env1151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1150_1151 : H12AffineEnvironment.transform 8 7 env1150 = env1151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1150 == env1151) = true)

def leafEnv1151 : List Nat := [2,4,8,13,12,0,4,8,7,8,1,0,5,1,12,3,13,13,9,12,13,13,13,15,9,9,1,1,0,0,12,12,9,1,9,1,4,14,0,7,1,12,0]

def active1151 : List Nat := [0,1,2]

def tree1151 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1151 : H12WitnessSearch.Good tree1151 := H12GlobalWitnessIndex.good

theorem leafIdentity1151 : H12AffineFastState.composeSystem env1151 rootObs = leafEnv1151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1151 rootObs == leafEnv1151) = true)

theorem terminalChecked1151 : H12PackedTerminal.terminalCheckFast leafEnv1151 active1151 tree1151 = true := by decide +kernel

def env1152 : List Nat := [2,4,8,13,12,1,4,9,512,9,1,1,515,518,522,517,523,13,8,522,13,13,13,15,527,0,0,519,12,12,8,1,8,1,519,512]

theorem envBound1152 : H12AffineFastState.Bounded env1152 := by
  intro p hp
  have h : env1152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1149_1152 : H12AffineEnvironment.transform 5 1 env1149 = env1152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1149 == env1152) = true)

def leafEnv1152 : List Nat := [2,4,8,13,12,1,4,9,512,9,1,1,515,518,522,517,523,13,8,522,13,13,13,15,8,527,1,0,0,519,12,12,8,1,8,1,4,520,519,512,1,12,0]

def active1152 : List Nat := [0,1,2,8]

def tree1152 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1152 : H12WitnessSearch.Good tree1152 := H12GlobalWitnessIndex.good

theorem leafIdentity1152 : H12AffineFastState.composeSystem env1152 rootObs = leafEnv1152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1152 rootObs == leafEnv1152) = true)

theorem terminalChecked1152 : H12PackedTerminal.terminalCheckFast leafEnv1152 active1152 tree1152 = true := by decide +kernel

def env1153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,185,74229,8328,74135,336223,16385,151552,2081,75135,0,73854,1,131333,512]

theorem envBound1153 : H12AffineFastState.Bounded env1153 := by
  intro p hp
  have h : env1153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1076_1153 : H12AffineEnvironment.transform 22 185 env1076 = env1153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1076 == env1153) = true)

theorem identity1153 : scanCanonicalize (H12AffineFastState.compose env1153 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1153 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1154 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74883,8201,2097152,73891,185,73736,8328,73834,336034,16385,151552,2081,74882,0,73854,1,131320,512]

theorem envBound1154 : H12AffineFastState.Bounded env1154 := by
  intro p hp
  have h : env1154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1153_1154 : H12AffineEnvironment.transform 7 253 env1153 = env1154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1153 == env1154) = true)

def env1155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16385,151552,2081,17375733,13108376,525568,1,34359738368,25691699]

theorem envBound1155 : H12AffineFastState.Bounded env1155 := by
  intro p hp
  have h : env1155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1071_1155 : H12AffineEnvironment.transform 14 8693 env1071 = env1155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1071 == env1155) = true)

def env1156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672784,935128,16385,151552,2081,17375733,4867288,525568,1,34359738368,17450611]

theorem envBound1156 : H12AffineFastState.Bounded env1156 := by
  intro p hp
  have h : env1156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1155_1156 : H12AffineEnvironment.transform 22 147520 env1155 = env1156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env1155 == env1156) = true)

def env1157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16385,151552,2081,16852469,4341976,256,1,34359738368,16925299]

theorem envBound1157 : H12AffineFastState.Bounded env1157 := by
  intro p hp
  have h : env1157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1156_1157 : H12AffineEnvironment.transform 18 1024 env1156 = env1157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1156 == env1157) = true)

def env1158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16385,151552,2081,16852469,4341976,256,1,131072,16925299]

theorem envBound1158 : H12AffineFastState.Bounded env1158 := by
  intro p hp
  have h : env1158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1157_1158 : H12AffineEnvironment.transform 34 131072 env1157 = env1158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1157 == env1158) = true)

theorem identity1158 : scanCanonicalize (H12AffineFastState.compose env1158 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2097612) := by decide +kernel

theorem selectedBound1158 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2097612,147520,16777216,8328,147472,409816,16385,151552,2081,16852469,2244884,256,1,131072,16925299]

theorem envBound1159 : H12AffineFastState.Bounded env1159 := by
  intro p hp
  have h : env1159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1158_1159 : H12AffineEnvironment.transform 21 2097612 env1158 = env1159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2097612 env1158 == env1159) = true)

theorem identity1159 : scanCanonicalize (H12AffineFastState.compose env1159 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1159 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,2097152,2097612,147520,16777216,8328,147472,409816,16385,151552,2081,16778638,2244884,256,1,131072,16925299]

theorem envBound1160 : H12AffineFastState.Bounded env1160 := by
  intro p hp
  have h : env1160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1159_1160 : H12AffineEnvironment.transform 15 8315 env1159 = env1160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1159 == env1160) = true)

def env1161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,147732,147672,147520,16777216,8328,147472,409816,16385,151552,2081,16778638,0,256,1,131072,16925299]

theorem envBound1161 : H12AffineFastState.Bounded env1161 := by
  intro p hp
  have h : env1161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1160_1161 : H12AffineEnvironment.transform 20 147732 env1160 = env1161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147732 env1160 == env1161) = true)

theorem identity1161 : scanCanonicalize (H12AffineFastState.compose env1161 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1161 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1162 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,131072,262144,1024,8433,147472,147672,147520,16777216,8328,147472,409816,16385,151552,2081,16778378,0,4,1,131072,16925299]

theorem envBound1162 : H12AffineFastState.Bounded env1162 := by
  intro p hp
  have h : env1162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1161_1162 : H12AffineEnvironment.transform 7 4 env1161 = env1162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1161 == env1162) = true)

def env1163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,147733,147673,147520,16777216,8328,147472,409816,16385,151552,2081,16778638,1,256,1,131072,16925299]

theorem envBound1163 : H12AffineFastState.Bounded env1163 := by
  intro p hp
  have h : env1163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1160_1163 : H12AffineEnvironment.transform 20 147733 env1160 = env1163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147733 env1160 == env1163) = true)

theorem identity1163 : scanCanonicalize (H12AffineFastState.compose env1163 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147831) := by decide +kernel

theorem selectedBound1163 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,147733,147673,147520,147831,8328,147472,409816,16385,151552,2081,148729,1,256,1,131072,772]

theorem envBound1164 : H12AffineFastState.Bounded env1164 := by
  intro p hp
  have h : env1164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1163_1164 : H12AffineEnvironment.transform 23 147831 env1163 = env1164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147831 env1163 == env1164) = true)

theorem identity1164 : scanCanonicalize (H12AffineFastState.compose env1164 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1164 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16633,262144,1024,8693,492,32,185,398,8328,233,262177,16385,4345,2081,1024,1,256,1,16633,772]

theorem envBound1165 : H12AffineFastState.Bounded env1165 := by
  intro p hp
  have h : env1165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1164_1165 : H12AffineEnvironment.transform 16 16633 env1164 = env1165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1164 == env1165) = true)

theorem identity1165 : scanCanonicalize (H12AffineFastState.compose env1165 (packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound1165 : packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env1166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16633,2265,1024,8693,492,32,185,398,8328,233,2296,16385,4345,2081,1024,1,256,1,16633,772]

theorem envBound1166 : H12AffineFastState.Bounded env1166 := by
  intro p hp
  have h : env1166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1165_1166 : H12AffineEnvironment.transform 17 2265 env1165 = env1166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env1165 == env1166) = true)

theorem identity1166 : scanCanonicalize (H12AffineFastState.compose env1166 (packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound1166 : packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env1167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1084,16384,1481,1095,16633,2265,1024,1481,492,32,185,398,1204,233,2296,16385,4345,2081,1024,1,256,1,16633,772]

theorem envBound1167 : H12AffineFastState.Bounded env1167 := by
  intro p hp
  have h : env1167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1166_1167 : H12AffineEnvironment.transform 12 1084 env1166 = env1167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env1166 == env1167) = true)

theorem identity1167 : scanCanonicalize (H12AffineFastState.compose env1167 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound1167 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1168 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1084,16384,1124,1095,16633,2265,1024,1124,65,32,185,35,1204,233,2296,16385,4345,2081,1024,1,173,1,16633,681]

theorem envBound1168 : H12AffineFastState.Bounded env1168 := by
  intro p hp
  have h : env1168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1167_1168 : H12AffineEnvironment.transform 7 173 env1167 = env1168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env1167 == env1168) = true)

theorem identity1168 : scanCanonicalize (H12AffineFastState.compose env1168 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2097) := by decide +kernel

theorem selectedBound1168 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env1169 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1084,2097,1124,1095,2248,2265,1024,1124,65,32,185,35,1204,233,2296,2096,4345,2081,1024,1,173,1,2248,681]

theorem envBound1169 : H12AffineFastState.Bounded env1169 := by
  intro p hp
  have h : env1169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1168_1169 : H12AffineEnvironment.transform 13 2097 env1168 = env1169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2097 env1168 == env1169) = true)

theorem identity1169 : scanCanonicalize (H12AffineFastState.compose env1169 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound1169 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env1170 : List Nat := [2,4,8,16,32,64,128,173,512,116,2048,4096,72,2097,16,51,2248,2265,116,16,65,32,185,35,192,233,2296,2096,4345,2081,116,1,173,1,2248,681]

theorem envBound1170 : H12AffineFastState.Bounded env1170 := by
  intro p hp
  have h : env1170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1169_1170 : H12AffineEnvironment.transform 9 116 env1169 = env1170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env1169 == env1170) = true)

theorem identity1170 : scanCanonicalize (H12AffineFastState.compose env1170 (packedSelected [0,1,3,5,7,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 2128) := by decide +kernel

theorem selectedBound1170 : packedSelected [0,1,3,5,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env1171 : List Nat := [2,4,8,16,32,64,128,173,512,116,2048,2128,72,2097,16,51,2248,2265,116,16,65,32,185,35,192,233,2296,2096,2217,2081,116,1,173,1,2248,681]

theorem envBound1171 : H12AffineFastState.Bounded env1171 := by
  intro p hp
  have h : env1171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1170_1171 : H12AffineEnvironment.transform 11 2128 env1170 = env1171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2128 env1170 == env1171) = true)

theorem identity1171 : scanCanonicalize (H12AffineFastState.compose env1171 (packedSelected [0,1,2,4,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound1171 : packedSelected [0,1,2,4,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env1172 : List Nat := [2,4,8,16,32,64,128,173,512,116,64,16,72,113,16,51,136,153,116,16,65,32,185,35,192,233,184,112,233,97,116,1,173,1,136,681]

theorem envBound1172 : H12AffineFastState.Bounded env1172 := by
  intro p hp
  have h : env1172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1171_1172 : H12AffineEnvironment.transform 10 64 env1171 = env1172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env1171 == env1172) = true)

theorem identity1172 : scanCanonicalize (H12AffineFastState.compose env1172 (packedSelected [0,2,3,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound1172 : packedSelected [0,2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env1173 : List Nat := [2,4,8,16,32,64,84,121,512,116,64,16,72,113,16,51,92,77,116,16,65,32,109,35,20,61,108,112,61,97,116,1,121,1,92,637]

theorem envBound1173 : H12AffineFastState.Bounded env1173 := by
  intro p hp
  have h : env1173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1172_1173 : H12AffineEnvironment.transform 6 84 env1172 = env1173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env1172 == env1173) = true)

theorem identity1173 : scanCanonicalize (H12AffineFastState.compose env1173 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound1173 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env1174 : List Nat := [2,4,8,16,13,64,84,84,512,89,64,16,72,92,16,30,92,77,89,16,65,13,64,14,20,16,65,93,16,76,89,1,84,1,92,592]

theorem envBound1174 : H12AffineFastState.Bounded env1174 := by
  intro p hp
  have h : env1174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1173_1174 : H12AffineEnvironment.transform 4 13 env1173 = env1174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env1173 == env1174) = true)

theorem identity1174 : scanCanonicalize (H12AffineFastState.compose env1174 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound1174 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env1175 : List Nat := [2,4,8,1,13,64,69,69,512,72,64,1,72,77,1,15,77,77,72,1,65,13,64,14,5,1,65,76,1,76,72,1,69,1,77,577]

theorem envBound1175 : H12AffineFastState.Bounded env1175 := by
  intro p hp
  have h : env1175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1174_1175 : H12AffineEnvironment.transform 3 1 env1174 = env1175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env1174 == env1175) = true)

theorem identity1175 : scanCanonicalize (H12AffineFastState.compose env1175 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound1175 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env1176 : List Nat := [2,4,8,1,13,0,5,5,512,8,0,1,8,13,1,15,13,13,8,1,1,13,0,14,5,1,1,12,1,12,8,1,5,1,13,513]

theorem envBound1176 : H12AffineFastState.Bounded env1176 := by
  intro p hp
  have h : env1176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1175_1176 : H12AffineEnvironment.transform 5 0 env1175 = env1176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1175 == env1176) = true)

theorem identity1176 : scanCanonicalize (H12AffineFastState.compose env1176 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1177 : List Nat := [2,4,8,1,13,0,5,5,7,8,0,1,8,13,1,15,13,13,8,1,1,13,0,14,5,1,1,12,1,12,8,1,5,1,13,6]

theorem envBound1177 : H12AffineFastState.Bounded env1177 := by
  intro p hp
  have h : env1177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1176_1177 : H12AffineEnvironment.transform 8 7 env1176 = env1177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1176 == env1177) = true)

theorem identity1177 : scanCanonicalize (H12AffineFastState.compose env1177 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound1177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1178 : List Nat := [2,1,8,1,8,0,0,0,2,8,0,1,8,8,1,10,8,8,8,1,1,8,0,11,0,1,1,9,1,9,8,1,0,1,8,3]

theorem envBound1178 : H12AffineFastState.Bounded env1178 := by
  intro p hp
  have h : env1178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1177_1178 : H12AffineEnvironment.transform 1 1 env1177 = env1178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env1177 == env1178) = true)

theorem identity1178 : scanCanonicalize (H12AffineFastState.compose env1178 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound1178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1179 : List Nat := [2,1,0,1,0,0,0,0,2,0,0,1,0,0,1,2,0,0,0,1,1,0,0,3,0,1,1,1,1,1,0,1,0,1,0,3]

theorem envBound1179 : H12AffineFastState.Bounded env1179 := by
  intro p hp
  have h : env1179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1178_1179 : H12AffineEnvironment.transform 2 0 env1178 = env1179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env1178 == env1179) = true)

def env1180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16385,151552,2081,16852469,4341976,256,1,131073,16925299]

theorem envBound1180 : H12AffineFastState.Bounded env1180 := by
  intro p hp
  have h : env1180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1157_1180 : H12AffineEnvironment.transform 34 131073 env1157 = env1180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1157 == env1180) = true)

theorem identity1180 : scanCanonicalize (H12AffineFastState.compose env1180 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 4557) := by decide +kernel

theorem selectedBound1180 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4557,147520,16777216,8328,147472,409816,16385,151552,2081,16852469,151829,256,1,131073,16925299]

theorem envBound1181 : H12AffineFastState.Bounded env1181 := by
  intro p hp
  have h : env1181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1180_1181 : H12AffineEnvironment.transform 21 4557 env1180 = env1181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4557 env1180 == env1181) = true)

theorem identity1181 : scanCanonicalize (H12AffineFastState.compose env1181 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound1181 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,131072,262144,1024,8693,2097152,292,147520,16777216,8328,147472,409816,16385,147689,2081,16852469,147964,256,1,131073,16925299]

theorem envBound1182 : H12AffineFastState.Bounded env1182 := by
  intro p hp
  have h : env1182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1181_1182 : H12AffineEnvironment.transform 11 233 env1181 = env1182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env1181 == env1182) = true)

def env1183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,16892,262144,1024,8693,2097152,292,444,16777216,8328,492,262436,16385,277,2081,16852469,0,256,1,16893,16778127]

theorem envBound1183 : H12AffineFastState.Bounded env1183 := by
  intro p hp
  have h : env1183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1182_1183 : H12AffineEnvironment.transform 16 16892 env1182 = env1183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1182 == env1183) = true)

theorem identity1183 : scanCanonicalize (H12AffineFastState.compose env1183 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1183 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,8575,16892,262144,1024,8693,2097152,292,444,16777216,8328,492,262436,16385,277,2081,16778378,0,256,1,16893,16778127]

theorem envBound1184 : H12AffineFastState.Bounded env1184 := by
  intro p hp
  have h : env1184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1183_1184 : H12AffineEnvironment.transform 15 8575 env1183 = env1184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1183 == env1184) = true)

def env1185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,16893,262144,1024,8693,2097152,292,445,16777216,8328,493,262437,16385,276,2081,16852469,1,256,1,16892,16778126]

theorem envBound1185 : H12AffineFastState.Bounded env1185 := by
  intro p hp
  have h : env1185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1182_1185 : H12AffineEnvironment.transform 16 16893 env1182 = env1185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1182 == env1185) = true)

theorem identity1185 : scanCanonicalize (H12AffineFastState.compose env1185 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 73969) := by decide +kernel

theorem selectedBound1185 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,16893,262144,1024,8693,2097152,292,445,73969,8328,493,262437,16385,276,2081,1284,1,256,1,16892,74623]

theorem envBound1186 : H12AffineFastState.Bounded env1186 := by
  intro p hp
  have h : env1186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1185_1186 : H12AffineEnvironment.transform 23 73969 env1185 = env1186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73969 env1185 == env1186) = true)

theorem identity1186 : scanCanonicalize (H12AffineFastState.compose env1186 (packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1186 : packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env1187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,16384,8693,65536,16893,2525,1024,8693,2097152,292,445,73969,8328,493,2296,16385,276,2081,1284,1,256,1,16892,74623]

theorem envBound1187 : H12AffineFastState.Bounded env1187 := by
  intro p hp
  have h : env1187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1186_1187 : H12AffineEnvironment.transform 17 2525 env1186 = env1187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1186 == env1187) = true)

theorem identity1187 : scanCanonicalize (H12AffineFastState.compose env1187 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1187 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env1188 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8433,65536,16633,2265,1024,8433,2097152,32,185,73969,8328,233,2296,16385,16,2081,1024,1,4,1,16632,74363]

theorem envBound1188 : H12AffineFastState.Bounded env1188 := by
  intro p hp
  have h : env1188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1187_1188 : H12AffineEnvironment.transform 7 4 env1187 = env1188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1187 == env1188) = true)

theorem identity1188 : scanCanonicalize (H12AffineFastState.compose env1188 (packedSelected [2,6,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound1188 : packedSelected [2,6,11,15,17] rootPS < 2^1333 := by decide +kernel

def env1189 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8433,8314,16633,2265,1024,8433,2097152,32,185,139,8328,233,2296,16385,16,2081,1024,1,4,1,16632,513]

theorem envBound1189 : H12AffineFastState.Bounded env1189 := by
  intro p hp
  have h : env1189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1188_1189 : H12AffineEnvironment.transform 15 8314 env1188 = env1189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env1188 == env1189) = true)

theorem identity1189 : scanCanonicalize (H12AffineFastState.compose env1189 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(20+1) ^^^ 3767) := by decide +kernel

theorem selectedBound1189 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1190 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8433,8314,16633,2265,1024,8433,3767,32,185,139,8328,233,2296,16385,16,2081,1024,1,4,1,16632,513]

theorem envBound1190 : H12AffineFastState.Bounded env1190 := by
  intro p hp
  have h : env1190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1189_1190 : H12AffineEnvironment.transform 20 3767 env1189 = env1190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3767 env1189 == env1190) = true)

theorem identity1190 : scanCanonicalize (H12AffineFastState.compose env1190 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 2296) := by decide +kernel

theorem selectedBound1190 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1191 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,2296,8433,8314,2049,2265,1024,8433,3767,32,185,139,8328,233,2296,2297,16,2081,1024,1,4,1,2048,513]

theorem envBound1191 : H12AffineFastState.Bounded env1191 := by
  intro p hp
  have h : env1191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1190_1191 : H12AffineEnvironment.transform 13 2296 env1190 = env1191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2296 env1190 == env1191) = true)

theorem identity1191 : scanCanonicalize (H12AffineFastState.compose env1191 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1670) := by decide +kernel

theorem selectedBound1191 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1192 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1670,233,8192,1662,8433,8314,1671,1631,1024,8433,49,32,185,139,8328,233,1662,1663,16,1703,1024,1,4,1,1670,513]

theorem envBound1192 : H12AffineFastState.Bounded env1192 := by
  intro p hp
  have h : env1192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1191_1192 : H12AffineEnvironment.transform 10 1670 env1191 = env1192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1670 env1191 == env1192) = true)

theorem identity1192 : scanCanonicalize (H12AffineFastState.compose env1192 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1236) := by decide +kernel

theorem selectedBound1192 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1193 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1670,233,1236,1662,1061,1198,1671,1631,1024,1061,49,32,185,139,1116,233,1662,1663,16,1703,1024,1,4,1,1670,513]

theorem envBound1193 : H12AffineFastState.Bounded env1193 := by
  intro p hp
  have h : env1193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1192_1193 : H12AffineEnvironment.transform 12 1236 env1192 = env1193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1236 env1192 == env1193) = true)

theorem identity1193 : scanCanonicalize (H12AffineFastState.compose env1193 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound1193 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1194 : List Nat := [2,4,8,16,32,64,128,4,512,679,33,233,627,217,642,521,32,248,679,642,49,32,185,139,763,233,217,216,16,0,679,1,4,1,33,513]

theorem envBound1194 : H12AffineFastState.Bounded env1194 := by
  intro p hp
  have h : env1194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1193_1194 : H12AffineEnvironment.transform 9 679 env1193 = env1194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env1193 == env1194) = true)

theorem identity1194 : scanCanonicalize (H12AffineFastState.compose env1194 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound1194 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1195 : List Nat := [2,4,8,16,32,48,128,4,512,679,33,153,515,169,642,521,32,136,679,642,49,32,185,139,651,153,169,168,16,0,679,1,4,1,33,513]

theorem envBound1195 : H12AffineFastState.Bounded env1195 := by
  intro p hp
  have h : env1195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1194_1195 : H12AffineEnvironment.transform 5 48 env1194 = env1195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env1194 == env1195) = true)

theorem identity1195 : scanCanonicalize (H12AffineFastState.compose env1195 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound1195 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1196 : List Nat := [2,4,8,16,32,48,128,4,42,141,33,153,41,169,168,35,32,136,141,168,49,32,185,139,161,153,169,168,16,0,141,1,4,1,33,43]

theorem envBound1196 : H12AffineFastState.Bounded env1196 := by
  intro p hp
  have h : env1196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1195_1196 : H12AffineEnvironment.transform 8 42 env1195 = env1196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env1195 == env1196) = true)

theorem identity1196 : scanCanonicalize (H12AffineFastState.compose env1196 (packedSelected [1,6] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound1196 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env1197 : List Nat := [2,4,8,16,32,48,43,4,42,38,33,50,41,2,3,35,32,35,38,3,49,32,18,32,10,50,2,3,16,0,38,1,4,1,33,43]

theorem envBound1197 : H12AffineFastState.Bounded env1197 := by
  intro p hp
  have h : env1197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1196_1197 : H12AffineEnvironment.transform 6 43 env1196 = env1197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env1196 == env1197) = true)

end H12CloudChart0