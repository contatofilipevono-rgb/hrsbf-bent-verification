import H12CloudChart0Data073

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound18659 : H12AffineFastState.Bounded env18659 := by
  intro p hp
  have h : env18659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18597_18659 : H12AffineEnvironment.transform 20 456825 env18597 = env18659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env18597 == env18659) = true)

def env18660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,441658,8328,65,245138,115151,17665,10280,119042,329730,256,485830,493666,63189]

theorem envBound18660 : H12AffineFastState.Bounded env18660 := by
  intro p hp
  have h : env18660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18659_18660 : H12AffineEnvironment.transform 21 272512 env18659 = env18660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18659 == env18660) = true)

theorem identity18660 : scanCanonicalize (H12AffineFastState.compose env18660 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound18660 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456825,272512,452648,441658,8328,65,158028,5393,17665,10280,1500,318684,256,441624,416956,63189]

theorem envBound18661 : H12AffineFastState.Bounded env18661 := by
  intro p hp
  have h : env18661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18660_18661 : H12AffineEnvironment.transform 15 54494 env18660 = env18661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env18660 == env18661) = true)

theorem identity18661 : scanCanonicalize (H12AffineFastState.compose env18661 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound18661 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,262144,1024,29909,396461,272512,400636,412142,8328,65,158028,5393,17665,10280,1500,272392,256,412108,416956,513]

theorem envBound18662 : H12AffineFastState.Bounded env18662 := by
  intro p hp
  have h : env18662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18661_18662 : H12AffineEnvironment.transform 14 29908 env18661 = env18662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env18661 == env18662) = true)

theorem identity18662 : scanCanonicalize (H12AffineFastState.compose env18662 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound18662 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env18663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,2421,1024,29909,132568,8693,136585,147611,8328,65,158028,5393,17665,10280,1500,8573,256,147641,153033,513]

theorem envBound18663 : H12AffineFastState.Bounded env18663 := by
  intro p hp
  have h : env18663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18662_18663 : H12AffineEnvironment.transform 17 2421 env18662 = env18663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env18662 == env18663) = true)

theorem identity18663 : scanCanonicalize (H12AffineFastState.compose env18663 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound18663 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env18664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,13389,2421,1024,29909,12693,8693,8644,29910,8328,65,23809,5393,17665,10280,1500,8573,256,29940,24964,513]

theorem envBound18664 : H12AffineFastState.Bounded env18664 := by
  intro p hp
  have h : env18664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18663_18664 : H12AffineEnvironment.transform 16 13389 env18663 = env18664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env18663 == env18664) = true)

theorem identity18664 : scanCanonicalize (H12AffineFastState.compose env18664 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18664 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env18665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,8202,13389,2421,1024,136,12693,8693,8644,139,8328,65,10588,5393,12636,10280,1500,8573,256,169,5593,513]

theorem envBound18665 : H12AffineFastState.Bounded env18665 := by
  intro p hp
  have h : env18665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18664_18665 : H12AffineEnvironment.transform 13 13405 env18664 = env18665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18664 == env18665) = true)

theorem identity18665 : scanCanonicalize (H12AffineFastState.compose env18665 (packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18665 : packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env18666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,478,5529,2421,1024,136,4161,33,16,139,348,65,2184,5393,4232,2556,1500,169,256,169,5593,513]

theorem envBound18666 : H12AffineFastState.Bounded env18666 := by
  intro p hp
  have h : env18666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18665_18666 : H12AffineEnvironment.transform 12 468 env18665 = env18666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18665 == env18666) = true)

def env18667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,441658,8328,65,245139,115151,17665,10280,119042,329731,256,485830,493666,63189]

theorem envBound18667 : H12AffineFastState.Bounded env18667 := by
  intro p hp
  have h : env18667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18659_18667 : H12AffineEnvironment.transform 21 272513 env18659 = env18667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18659 == env18667) = true)

theorem identity18667 : scanCanonicalize (H12AffineFastState.compose env18667 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound18667 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115871,201831,120014,98780,8328,65,245139,115151,17665,10280,119042,144613,256,21792,46212,63189]

theorem envBound18668 : H12AffineFastState.Bounded env18668 := by
  intro p hp
  have h : env18668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18667_18668 : H12AffineEnvironment.transform 17 212198 env18667 = env18668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env18667 == env18668) = true)

def env18669 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115871,201783,119966,98700,8328,17,245139,115103,17665,10280,119042,144565,256,21792,46212,63109]

theorem envBound18669 : H12AffineFastState.Bounded env18669 := by
  intro p hp
  have h : env18669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18668_18669 : H12AffineEnvironment.transform 5 16 env18668 = env18669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18668 == env18669) = true)

theorem identity18669 : scanCanonicalize (H12AffineFastState.compose env18669 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound18669 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18670 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76078,1024,32769,115871,65967,119966,98700,8328,17,108555,115103,17665,10280,119042,8493,256,21792,46212,63109]

theorem envBound18670 : H12AffineFastState.Bounded env18670 := by
  intro p hp
  have h : env18670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18669_18670 : H12AffineEnvironment.transform 16 5528 env18669 = env18670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env18669 == env18670) = true)

theorem identity18670 : scanCanonicalize (H12AffineFastState.compose env18670 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18670 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env18671 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,5528,2341,1024,32769,58516,8612,62613,41351,8328,17,34816,57748,17665,10280,61705,8493,256,21792,46212,63109]

theorem envBound18671 : H12AffineFastState.Bounded env18671 := by
  intro p hp
  have h : env18671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18670_18671 : H12AffineEnvironment.transform 15 8203 env18670 = env18671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18670 == env18671) = true)

theorem identity18671 : scanCanonicalize (H12AffineFastState.compose env18671 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18671 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env18672 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8203,5528,2341,1024,32769,45341,8612,41244,41351,8328,17,34816,46109,4232,10280,42112,8493,256,169,46212,41740]

theorem envBound18672 : H12AffineFastState.Bounded env18672 := by
  intro p hp
  have h : env18672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18671_18672 : H12AffineEnvironment.transform 13 5513 env18671 = env18672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18671 == env18672) = true)

theorem identity18672 : scanCanonicalize (H12AffineFastState.compose env18672 (packedSelected [0,7,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound18672 : packedSelected [0,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env18673 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1337,5513,32768,1330,5528,2341,1024,32769,37924,1181,33829,33982,1457,17,34816,37156,4232,3345,33209,1044,256,169,37309,34357]

theorem envBound18673 : H12AffineFastState.Bounded env18673 := by
  intro p hp
  have h : env18673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18672_18673 : H12AffineEnvironment.transform 12 1337 env18672 = env18673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env18672 == env18673) = true)

theorem identity18673 : scanCanonicalize (H12AffineFastState.compose env18673 (packedSelected [2,3,5,6,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18673 : packedSelected [2,3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18674 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,268,4540,32768,263,4525,2341,53,32769,36881,168,32784,32907,388,17,34816,37156,4232,2340,33209,33,256,169,37309,33280]

theorem envBound18674 : H12AffineFastState.Bounded env18674 := by
  intro p hp
  have h : env18674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18673_18674 : H12AffineEnvironment.transform 9 53 env18673 = env18674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18673 == env18674) = true)

theorem identity18674 : scanCanonicalize (H12AffineFastState.compose env18674 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound18674 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env18675 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,2065,268,2477,32768,263,2492,2341,53,32769,34816,168,32784,32907,388,17,34816,35125,2201,2340,33209,33,256,169,35244,33280]

theorem envBound18675 : H12AffineFastState.Bounded env18675 := by
  intro p hp
  have h : env18675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18674_18675 : H12AffineEnvironment.transform 11 2065 env18674 = env18675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env18674 == env18675) = true)

theorem identity18675 : scanCanonicalize (H12AffineFastState.compose env18675 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound18675 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env18676 : List Nat := [2,4,8,16,32,16,128,256,512,53,136,153,268,293,32768,263,308,429,53,32769,32904,168,32784,32907,388,17,32904,33213,17,428,33209,33,256,169,33060,33280]

theorem envBound18676 : H12AffineFastState.Bounded env18676 := by
  intro p hp
  have h : env18676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18675_18676 : H12AffineEnvironment.transform 10 136 env18675 = env18676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env18675 == env18676) = true)

theorem identity18676 : scanCanonicalize (H12AffineFastState.compose env18676 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18676 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env18677 : List Nat := [2,4,8,16,32,16,128,36,512,53,136,153,40,1,32768,35,16,137,53,32769,32904,168,32784,32907,160,17,32904,32921,17,136,32925,33,36,169,32768,33280]

theorem envBound18677 : H12AffineFastState.Bounded env18677 := by
  intro p hp
  have h : env18677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18676_18677 : H12AffineEnvironment.transform 7 36 env18676 = env18677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18676 == env18677) = true)

def env18678 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115871,201782,119967,98701,8328,16,245139,115102,17665,10280,119042,144564,256,21792,46212,63108]

theorem envBound18678 : H12AffineFastState.Bounded env18678 := by
  intro p hp
  have h : env18678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18668_18678 : H12AffineEnvironment.transform 5 17 env18668 = env18678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18668 == env18678) = true)

theorem identity18678 : scanCanonicalize (H12AffineFastState.compose env18678 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115103) := by decide +kernel

theorem selectedBound18678 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18679 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,115103,64808,1024,32769,115871,54697,119967,98701,8328,16,31756,115102,17665,10280,119042,128299,256,21792,46212,63108]

theorem envBound18679 : H12AffineFastState.Bounded env18679 := by
  intro p hp
  have h : env18679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18678_18679 : H12AffineEnvironment.transform 16 115103 env18678 = env18679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115103 env18678 == env18679) = true)

theorem identity18679 : scanCanonicalize (H12AffineFastState.compose env18679 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18679 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env18680 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,114966,64808,1024,32769,115734,54560,119830,98564,8193,16,31756,114967,17665,10280,119042,128299,256,21792,46093,62989]

theorem envBound18680 : H12AffineFastState.Bounded env18680 := by
  intro p hp
  have h : env18680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18679_18680 : H12AffineEnvironment.transform 6 9 env18679 = env18680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18679 == env18680) = true)

theorem identity18680 : scanCanonicalize (H12AffineFastState.compose env18680 (packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound18680 : packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env18681 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,65536,79130,2340,1024,29709,77850,8492,73754,95496,8193,16,31756,79131,17665,10280,75022,65831,256,21792,16385,513]

theorem envBound18681 : H12AffineFastState.Bounded env18681 := by
  intro p hp
  have h : env18681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18680_18681 : H12AffineEnvironment.transform 14 29708 env18680 = env18681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env18680 == env18681) = true)

theorem identity18681 : scanCanonicalize (H12AffineFastState.compose env18681 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound18681 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18682 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,34,13624,2340,1024,29709,12344,8492,8248,29994,8193,16,31756,13625,17665,10280,9516,261,256,21792,16385,513]

theorem envBound18682 : H12AffineFastState.Bounded env18682 := by
  intro p hp
  have h : env18682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18681_18682 : H12AffineEnvironment.transform 15 34 env18681 = env18682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env18681 == env18682) = true)

theorem identity18682 : scanCanonicalize (H12AffineFastState.compose env18682 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18682 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env18683 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,28728,34,12556,2340,52,28729,12344,8492,8248,28958,8193,16,30776,12557,16693,10280,8472,261,256,20756,16385,513]

theorem envBound18683 : H12AffineFastState.Bounded env18683 := by
  intro p hp
  have h : env18683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18682_18683 : H12AffineEnvironment.transform 9 52 env18682 = env18683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18682 == env18683) = true)

def env18684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452649,2114882,8328,65,6385003,115150,2538873,10281,2566523,4268163,256,485830,493666,2494124]

theorem envBound18684 : H12AffineFastState.Bounded env18684 := by
  intro p hp
  have h : env18684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18596_18684 : H12AffineEnvironment.transform 22 452649 env18596 = env18684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env18596 == env18684) = true)

def env18685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,441658,8328,65,4691219,115150,17665,10281,119043,4268163,256,485830,493666,63188]

theorem envBound18685 : H12AffineFastState.Bounded env18685 := by
  intro p hp
  have h : env18685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18684_18685 : H12AffineEnvironment.transform 20 456824 env18684 = env18685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env18684 == env18685) = true)

def env18686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,441658,8328,65,245139,115150,17665,10281,119043,329731,256,485830,493666,63188]

theorem envBound18686 : H12AffineFastState.Bounded env18686 := by
  intro p hp
  have h : env18686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18685_18686 : H12AffineEnvironment.transform 21 272512 env18685 = env18686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18685 == env18686) = true)

theorem identity18686 : scanCanonicalize (H12AffineFastState.compose env18686 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound18686 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180409,16,21763,8328,65,245139,115150,17665,10281,119043,254010,256,98815,90203,63188]

theorem envBound18687 : H12AffineFastState.Bounded env18687 := by
  intro p hp
  have h : env18687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18686_18687 : H12AffineEnvironment.transform 17 190521 env18686 = env18687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env18686 == env18687) = true)

def env18688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180273,16,21763,8192,65,245019,115014,17665,10281,119043,254010,256,98679,90203,63068]

theorem envBound18688 : H12AffineFastState.Bounded env18688 := by
  intro p hp
  have h : env18688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18687_18688 : H12AffineEnvironment.transform 6 8 env18687 = env18688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18687 == env18688) = true)

theorem identity18688 : scanCanonicalize (H12AffineFastState.compose env18688 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound18688 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56437,1024,32769,4161,62589,16,21763,8192,65,100695,115014,17665,10281,119043,119926,256,98679,90203,63068]

theorem envBound18689 : H12AffineFastState.Bounded env18689 := by
  intro p hp
  have h : env18689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18688_18689 : H12AffineEnvironment.transform 16 13388 env18688 = env18689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env18688 == env18689) = true)

theorem identity18689 : scanCanonicalize (H12AffineFastState.compose env18689 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18689 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env18690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,13388,23668,1024,0,4161,29820,16,21763,8192,65,67926,82247,17665,10281,86274,87159,256,65910,90203,30301]

theorem envBound18690 : H12AffineFastState.Bounded env18690 := by
  intro p hp
  have h : env18690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18689_18690 : H12AffineEnvironment.transform 14 1 env18689 = env18690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18689 == env18690) = true)

theorem identity18690 : scanCanonicalize (H12AffineFastState.compose env18690 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound18690 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env18691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,65536,13388,2341,1024,0,4161,8493,16,82,8192,65,67926,70678,4176,10281,66643,65830,256,65910,79114,8972]

theorem envBound18691 : H12AffineFastState.Bounded env18691 := by
  intro p hp
  have h : env18691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18690_18691 : H12AffineEnvironment.transform 13 5457 env18690 = env18691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env18690 == env18691) = true)

theorem identity18691 : scanCanonicalize (H12AffineFastState.compose env18691 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound18691 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env18692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,342,13388,2341,1024,0,4161,8493,16,82,8192,65,2048,5440,4176,10281,1285,112,256,32,13404,8972]

theorem envBound18692 : H12AffineFastState.Bounded env18692 := by
  intro p hp
  have h : env18692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18691_18692 : H12AffineEnvironment.transform 15 342 env18691 = env18692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env18691 == env18692) = true)

theorem identity18692 : scanCanonicalize (H12AffineFastState.compose env18692 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18692 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,1,342,5441,2341,1024,0,4161,32,16,82,269,65,2048,5440,4176,2340,1285,112,256,32,5457,513]

theorem envBound18693 : H12AffineFastState.Bounded env18693 := by
  intro p hp
  have h : env18693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18692_18693 : H12AffineEnvironment.transform 12 269 env18692 = env18693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18692 == env18693) = true)

def env18694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180272,16,21763,8193,65,245018,115015,17665,10281,119043,254010,256,98678,90203,63069]

theorem envBound18694 : H12AffineFastState.Bounded env18694 := by
  intro p hp
  have h : env18694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18687_18694 : H12AffineEnvironment.transform 6 9 env18687 = env18694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18687 == env18694) = true)

theorem identity18694 : scanCanonicalize (H12AffineFastState.compose env18694 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound18694 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,32040,1024,32769,4161,21793,16,21763,8193,65,75787,115015,17665,10281,119043,95531,256,98678,90203,63069]

theorem envBound18695 : H12AffineFastState.Bounded env18695 := by
  intro p hp
  have h : env18695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18694_18695 : H12AffineEnvironment.transform 16 38161 env18694 = env18695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env18694 == env18695) = true)

theorem identity18695 : scanCanonicalize (H12AffineFastState.compose env18695 (packedSelected [10,16,18,20,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound18695 : packedSelected [10,16,18,20,23,31] rootPS < 2^1333 := by decide +kernel

def env18696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,32040,1024,32769,4161,21793,16,21763,8193,65,56576,13388,17665,10281,9224,32800,256,29821,38224,63069]

theorem envBound18696 : H12AffineFastState.Bounded env18696 := by
  intro p hp
  have h : env18696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18695_18696 : H12AffineEnvironment.transform 15 62731 env18695 = env18696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env18695 == env18696) = true)

theorem identity18696 : scanCanonicalize (H12AffineFastState.compose env18696 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18696 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,24909,32040,1024,29789,4161,21793,16,21763,8193,65,10588,13388,17665,10281,9224,29820,256,29821,24844,513]

theorem envBound18697 : H12AffineFastState.Bounded env18697 := by
  intro p hp
  have h : env18697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18696_18697 : H12AffineEnvironment.transform 14 29788 env18696 = env18697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18696 == env18697) = true)

theorem identity18697 : scanCanonicalize (H12AffineFastState.compose env18697 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound18697 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,20496,343,17665,22884,1024,20497,4161,21793,16,21763,1101,65,3344,4096,17665,3173,68,20528,256,20529,17728,513]

theorem envBound18698 : H12AffineFastState.Bounded env18698 := by
  intro p hp
  have h : env18698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18697_18698 : H12AffineEnvironment.transform 12 1100 env18697 = env18698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env18697 == env18698) = true)

theorem identity18698 : scanCanonicalize (H12AffineFastState.compose env18698 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound18698 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18699 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,40,16384,20496,343,16741,22884,100,20497,4161,20805,16,20839,41,65,2420,4096,16741,2049,68,20528,256,20529,16676,513]

theorem envBound18699 : H12AffineFastState.Bounded env18699 := by
  intro p hp
  have h : env18699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18698_18699 : H12AffineEnvironment.transform 9 100 env18698 = env18699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env18698 == env18699) = true)

theorem identity18699 : scanCanonicalize (H12AffineFastState.compose env18699 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound18699 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env18700 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,40,4112,0,343,4469,2420,100,1,4161,341,16,375,41,65,2420,4096,4469,2049,68,32,256,33,4404,513]

theorem envBound18700 : H12AffineFastState.Bounded env18700 := by
  intro p hp
  have h : env18700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18699_18700 : H12AffineEnvironment.transform 13 4112 env18699 = env18700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env18699 == env18700) = true)

theorem identity18700 : scanCanonicalize (H12AffineFastState.compose env18700 (packedSelected [0,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound18700 : packedSelected [0,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env18701 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2609,40,2593,0,343,2884,2420,100,1,2672,341,16,375,41,65,2420,2609,2884,2049,68,32,256,33,2821,513]

theorem envBound18701 : H12AffineFastState.Bounded env18701 := by
  intro p hp
  have h : env18701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18700_18701 : H12AffineEnvironment.transform 11 2609 env18700 = env18701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env18700 == env18701) = true)

theorem identity18701 : scanCanonicalize (H12AffineFastState.compose env18701 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound18701 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env18702 : List Nat := [2,4,8,16,32,64,9,256,512,100,544,17,40,1,0,343,356,852,100,1,80,341,16,375,41,65,852,17,356,545,68,32,256,33,293,513]

theorem envBound18702 : H12AffineFastState.Bounded env18702 := by
  intro p hp
  have h : env18702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18701_18702 : H12AffineEnvironment.transform 10 544 env18701 = env18702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env18701 == env18702) = true)

theorem identity18702 : scanCanonicalize (H12AffineFastState.compose env18702 (packedSelected [2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound18702 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env18703 : List Nat := [2,4,8,16,32,64,9,256,261,100,293,17,40,1,0,343,356,81,100,1,80,341,16,375,41,65,81,17,356,292,68,32,256,33,293,260]

theorem envBound18703 : H12AffineFastState.Bounded env18703 := by
  intro p hp
  have h : env18703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18702_18703 : H12AffineEnvironment.transform 8 261 env18702 = env18703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env18702 == env18703) = true)

theorem identity18703 : scanCanonicalize (H12AffineFastState.compose env18703 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18703 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env18704 : List Nat := [2,4,8,16,32,64,9,116,113,100,81,17,40,1,0,35,16,81,100,1,80,33,16,3,41,65,81,17,16,80,68,32,116,33,81,112]

theorem envBound18704 : H12AffineFastState.Bounded env18704 := by
  intro p hp
  have h : env18704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18703_18704 : H12AffineEnvironment.transform 7 116 env18703 = env18704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18703 == env18704) = true)

theorem identity18704 : scanCanonicalize (H12AffineFastState.compose env18704 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18705 : List Nat := [2,4,8,16,32,49,9,5,0,21,32,17,40,1,0,35,16,32,21,1,33,33,16,3,41,48,32,17,16,33,53,32,5,33,32,1]

theorem envBound18705 : H12AffineFastState.Bounded env18705 := by
  intro p hp
  have h : env18705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18704_18705 : H12AffineEnvironment.transform 5 49 env18704 = env18705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18704 == env18705) = true)

theorem identity18705 : scanCanonicalize (H12AffineFastState.compose env18705 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound18705 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18706 : List Nat := [2,4,8,10,32,43,9,5,0,15,32,11,40,1,0,35,10,32,15,1,33,33,10,3,41,42,32,11,10,33,47,32,5,33,32,1]

theorem envBound18706 : H12AffineFastState.Bounded env18706 := by
  intro p hp
  have h : env18706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18705_18706 : H12AffineEnvironment.transform 3 10 env18705 = env18706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env18705 == env18706) = true)

theorem identity18706 : scanCanonicalize (H12AffineFastState.compose env18706 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18707 : List Nat := [2,4,8,10,10,1,9,5,0,15,10,11,2,1,0,9,10,10,15,1,11,11,10,3,3,0,10,11,10,11,5,10,5,11,10,1]

theorem envBound18707 : H12AffineFastState.Bounded env18707 := by
  intro p hp
  have h : env18707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18706_18707 : H12AffineEnvironment.transform 4 10 env18706 = env18707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18706 == env18707) = true)

theorem identity18707 : scanCanonicalize (H12AffineFastState.compose env18707 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18707 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18708 : List Nat := [2,4,3,1,1,1,2,5,0,4,1,0,2,1,0,2,1,1,4,1,0,0,1,3,3,0,1,0,1,0,5,1,5,0,1,1]

theorem envBound18708 : H12AffineFastState.Bounded env18708 := by
  intro p hp
  have h : env18708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18707_18708 : H12AffineEnvironment.transform 2 3 env18707 = env18708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18707 == env18708) = true)

def env18709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,441658,8328,65,245138,115150,17665,10281,119043,329730,256,485830,493666,63188]

theorem envBound18709 : H12AffineFastState.Bounded env18709 := by
  intro p hp
  have h : env18709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18685_18709 : H12AffineEnvironment.transform 21 272513 env18685 = env18709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18685 == env18709) = true)

def env18710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452649,441658,8192,65,245018,115014,17665,10281,119043,329730,256,485710,493666,63068]

theorem envBound18710 : H12AffineFastState.Bounded env18710 := by
  intro p hp
  have h : env18710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18709_18710 : H12AffineEnvironment.transform 6 8 env18709 = env18710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18709 == env18710) = true)

def env18711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272393,272441,294186,8192,65,97546,115014,17665,10281,119043,329730,256,371038,346226,63068]

theorem envBound18711 : H12AffineFastState.Bounded env18711 := by
  intro p hp
  have h : env18711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18710_18711 : H12AffineEnvironment.transform 16 49168 env18710 = env18711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18710 == env18711) = true)

theorem identity18711 : scanCanonicalize (H12AffineFastState.compose env18711 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound18711 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56437,1024,32769,58397,62588,62540,41311,8192,65,97546,115014,17665,10281,119043,119927,256,95531,103431,63068]

theorem envBound18712 : H12AffineFastState.Bounded env18712 := by
  intro p hp
  have h : env18712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18711_18712 : H12AffineEnvironment.transform 17 56437 env18711 = env18712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env18711 == env18712) = true)

theorem identity18712 : scanCanonicalize (H12AffineFastState.compose env18712 (packedSelected [0,4,5,7,9,10,11,15,16,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound18712 : packedSelected [0,4,5,7,9,10,11,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env18713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,65536,5441,2340,1024,21840,12620,8493,8477,29710,8192,65,97546,70679,17665,10281,66642,65830,256,95531,82262,8973]

theorem envBound18713 : H12AffineFastState.Bounded env18713 := by
  intro p hp
  have h : env18713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18712_18713 : H12AffineEnvironment.transform 14 21841 env18712 = env18713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env18712 == env18713) = true)

theorem identity18713 : scanCanonicalize (H12AffineFastState.compose env18713 (packedSelected [1,3,4,5,8,14,15,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18713 : packedSelected [1,3,4,5,8,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env18714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8461,65536,5441,2340,1024,8460,12620,8493,8477,82,8192,65,67926,70679,12637,10281,66642,65830,256,65911,79114,8973]

theorem envBound18714 : H12AffineFastState.Bounded env18714 := by
  intro p hp
  have h : env18714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18713_18714 : H12AffineEnvironment.transform 13 13404 env18713 = env18714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18713 == env18714) = true)

theorem identity18714 : scanCanonicalize (H12AffineFastState.compose env18714 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18714 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,81,65536,5441,2340,1024,80,4112,113,65,82,348,65,67926,70679,4097,2421,66642,65830,256,65911,70742,593]

theorem envBound18715 : H12AffineFastState.Bounded env18715 := by
  intro p hp
  have h : env18715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18714_18715 : H12AffineEnvironment.transform 12 348 env18714 = env18715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18714 == env18715) = true)

theorem identity18715 : scanCanonicalize (H12AffineFastState.compose env18715 (packedSelected [1,2,3,5,6,8,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18715 : packedSelected [1,2,3,5,6,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env18716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,81,343,5441,2340,1024,80,4112,113,65,82,348,65,2049,5440,4097,2421,1285,113,256,32,5377,593]

theorem envBound18716 : H12AffineFastState.Bounded env18716 := by
  intro p hp
  have h : env18716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18715_18716 : H12AffineEnvironment.transform 15 343 env18715 = env18716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18715 == env18716) = true)

theorem identity18716 : scanCanonicalize (H12AffineFastState.compose env18716 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound18716 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env18717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,348,3392,81,343,3329,2340,1024,80,2128,113,65,82,348,65,2049,3328,2113,2421,1285,113,256,32,3393,593]

theorem envBound18717 : H12AffineFastState.Bounded env18717 := by
  intro p hp
  have h : env18717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18716_18717 : H12AffineEnvironment.transform 11 2112 env18716 = env18717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env18716 == env18717) = true)

theorem identity18717 : scanCanonicalize (H12AffineFastState.compose env18717 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18717 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18718 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,269,3345,0,262,3329,2340,1024,1,2049,32,16,3,269,16,2049,3328,2064,2340,1285,32,256,32,3344,512]

theorem envBound18718 : H12AffineFastState.Bounded env18718 := by
  intro p hp
  have h : env18718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18717_18718 : H12AffineEnvironment.transform 5 17 env18717 = env18718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18717 == env18718) = true)

theorem identity18718 : scanCanonicalize (H12AffineFastState.compose env18718 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound18718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18719 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1313,1328,269,48,0,262,32,1029,1024,1,1312,32,16,3,269,16,1312,33,1329,1029,1285,32,256,32,49,512]

theorem envBound18719 : H12AffineFastState.Bounded env18719 := by
  intro p hp
  have h : env18719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18718_18719 : H12AffineEnvironment.transform 10 1313 env18718 = env18719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env18718 == env18719) = true)

theorem identity18719 : scanCanonicalize (H12AffineFastState.compose env18719 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound18719 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18720 : List Nat := [2,4,8,16,32,17,8,256,512,548,773,788,269,48,0,262,32,545,548,1,772,32,16,3,269,16,772,33,789,545,801,32,256,32,49,512]

theorem envBound18720 : H12AffineFastState.Bounded env18720 := by
  intro p hp
  have h : env18720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18719_18720 : H12AffineEnvironment.transform 9 548 env18719 = env18720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env18719 == env18720) = true)

theorem identity18720 : scanCanonicalize (H12AffineFastState.compose env18720 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound18720 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18721 : List Nat := [2,4,8,16,32,17,8,256,48,20,309,292,269,48,0,262,32,17,20,1,308,32,16,3,269,16,308,33,293,17,273,32,256,32,49,48]

theorem envBound18721 : H12AffineFastState.Bounded env18721 := by
  intro p hp
  have h : env18721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18720_18721 : H12AffineEnvironment.transform 8 48 env18720 = env18721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env18720 == env18721) = true)

theorem identity18721 : scanCanonicalize (H12AffineFastState.compose env18721 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18721 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18722 : List Nat := [2,4,8,1,32,0,8,256,33,5,292,292,269,33,0,262,32,0,5,1,293,32,1,3,269,1,293,33,293,0,256,32,256,32,32,33]

theorem envBound18722 : H12AffineFastState.Bounded env18722 := by
  intro p hp
  have h : env18722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18721_18722 : H12AffineEnvironment.transform 3 1 env18721 = env18722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18721 == env18722) = true)

theorem identity18722 : scanCanonicalize (H12AffineFastState.compose env18722 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18722 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18723 : List Nat := [2,4,8,1,32,0,8,36,33,5,0,0,41,33,0,34,32,0,5,1,1,32,1,3,41,1,1,33,1,0,36,32,36,32,32,33]

theorem envBound18723 : H12AffineFastState.Bounded env18723 := by
  intro p hp
  have h : env18723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18722_18723 : H12AffineEnvironment.transform 7 36 env18722 = env18723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18722 == env18723) = true)

theorem identity18723 : scanCanonicalize (H12AffineFastState.compose env18723 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18723 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18724 : List Nat := [2,4,8,1,1,0,8,5,0,5,0,0,8,0,0,3,1,0,5,1,1,1,1,3,8,1,1,0,1,0,5,1,5,1,1,0]

theorem envBound18724 : H12AffineFastState.Bounded env18724 := by
  intro p hp
  have h : env18724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18723_18724 : H12AffineEnvironment.transform 4 1 env18723 = env18724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18723 == env18724) = true)

theorem identity18724 : scanCanonicalize (H12AffineFastState.compose env18724 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound18724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18725 : List Nat := [2,4,7,1,1,0,7,5,0,5,0,0,7,0,0,3,1,0,5,1,1,1,1,3,7,1,1,0,1,0,5,1,5,1,1,0]

theorem envBound18725 : H12AffineFastState.Bounded env18725 := by
  intro p hp
  have h : env18725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18724_18725 : H12AffineEnvironment.transform 2 7 env18724 = env18725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env18724 == env18725) = true)

def env18726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272393,272440,294187,8192,65,97547,115014,17665,10281,119043,329730,256,371039,346227,63068]

theorem envBound18726 : H12AffineFastState.Bounded env18726 := by
  intro p hp
  have h : env18726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18710_18726 : H12AffineEnvironment.transform 16 49169 env18710 = env18726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18710 == env18726) = true)

theorem identity18726 : scanCanonicalize (H12AffineFastState.compose env18726 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18726 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1024,29788,276585,272393,272440,294187,8192,65,97547,79131,17665,10281,75102,329730,256,351490,346227,513]

theorem envBound18727 : H12AffineFastState.Bounded env18727 := by
  intro p hp
  have h : env18727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18726_18727 : H12AffineEnvironment.transform 14 29789 env18726 = env18727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18726 == env18727) = true)

theorem identity18727 : scanCanonicalize (H12AffineFastState.compose env18727 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18727 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10280,1024,29788,4161,33,16,21763,8192,65,97547,79131,17665,10281,75102,73770,256,95530,90203,513]

theorem envBound18728 : H12AffineFastState.Bounded env18728 := by
  intro p hp
  have h : env18728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18727_18728 : H12AffineEnvironment.transform 17 10280 env18727 = env18728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18727 == env18728) = true)

theorem identity18728 : scanCanonicalize (H12AffineFastState.compose env18728 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound18728 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env18729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,262,13388,10280,1024,29788,4161,33,16,21763,8192,65,31757,13341,17665,10281,9304,8492,256,29740,24925,513]

theorem envBound18729 : H12AffineFastState.Bounded env18729 := by
  intro p hp
  have h : env18729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18728_18729 : H12AffineEnvironment.transform 15 262 env18728 = env18729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env18728 == env18729) = true)

theorem identity18729 : scanCanonicalize (H12AffineFastState.compose env18729 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound18729 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env18730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,262,13388,10280,1024,8460,4161,33,16,83,8192,65,10589,13341,4177,10281,9304,8492,256,8572,13325,513]

theorem envBound18730 : H12AffineFastState.Bounded env18730 := by
  intro p hp
  have h : env18730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18729_18730 : H12AffineEnvironment.transform 13 5456 env18729 = env18730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env18729 == env18730) = true)

theorem identity18730 : scanCanonicalize (H12AffineFastState.compose env18730 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18730 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,81,262,5392,2420,1024,80,4161,33,16,83,348,65,2049,5441,4177,2421,1284,112,256,32,5457,513]

theorem envBound18731 : H12AffineFastState.Bounded env18731 := by
  intro p hp
  have h : env18731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18730_18731 : H12AffineEnvironment.transform 12 348 env18730 = env18731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18730 == env18731) = true)

theorem identity18731 : scanCanonicalize (H12AffineFastState.compose env18731 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound18731 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env18732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1280,4096,348,5456,81,262,5392,1140,1024,80,4161,33,16,83,348,65,1281,5441,4177,1141,1284,112,256,32,5457,513]

theorem envBound18732 : H12AffineFastState.Bounded env18732 := by
  intro p hp
  have h : env18732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18731_18732 : H12AffineEnvironment.transform 10 1280 env18731 = env18732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env18731 == env18732) = true)

theorem identity18732 : scanCanonicalize (H12AffineFastState.compose env18732 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound18732 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env18733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1280,81,348,1281,81,262,1345,1140,1024,80,16,33,16,83,348,65,1281,1296,0,1141,1284,112,256,32,1280,513]

theorem envBound18733 : H12AffineFastState.Bounded env18733 := by
  intro p hp
  have h : env18733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18732_18733 : H12AffineEnvironment.transform 11 81 env18732 = env18733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env18732 == env18733) = true)

theorem identity18733 : scanCanonicalize (H12AffineFastState.compose env18733 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18733 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env18734 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1280,0,269,1281,0,262,1296,1061,1024,1,16,33,16,2,269,16,1281,1296,0,1060,1284,33,256,32,1280,513]

theorem envBound18734 : H12AffineFastState.Bounded env18734 := by
  intro p hp
  have h : env18734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18733_18734 : H12AffineEnvironment.transform 5 17 env18733 = env18734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18733 == env18734) = true)

theorem identity18734 : scanCanonicalize (H12AffineFastState.compose env18734 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18734 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18735 : List Nat := [2,4,8,16,32,17,8,256,512,53,309,0,269,308,0,262,293,16,53,1,16,33,16,2,269,16,308,293,0,17,305,33,256,32,309,513]

theorem envBound18735 : H12AffineFastState.Bounded env18735 := by
  intro p hp
  have h : env18735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18734_18735 : H12AffineEnvironment.transform 9 53 env18734 = env18735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18734 == env18735) = true)

theorem identity18735 : scanCanonicalize (H12AffineFastState.compose env18735 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18735 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18736 : List Nat := [2,4,8,16,32,17,8,256,1,53,309,0,269,308,0,262,293,16,53,1,16,33,16,2,269,16,308,293,0,17,305,33,256,32,309,0]

theorem envBound18736 : H12AffineFastState.Bounded env18736 := by
  intro p hp
  have h : env18736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18735_18736 : H12AffineEnvironment.transform 8 1 env18735 = env18736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18735 == env18736) = true)

theorem identity18736 : scanCanonicalize (H12AffineFastState.compose env18736 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18736 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18737 : List Nat := [2,4,8,16,32,17,8,37,1,53,16,0,40,17,0,35,0,16,53,1,16,33,16,2,40,16,17,0,0,17,20,33,37,32,16,0]

theorem envBound18737 : H12AffineFastState.Bounded env18737 := by
  intro p hp
  have h : env18737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18736_18737 : H12AffineEnvironment.transform 7 37 env18736 = env18737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18736 == env18737) = true)

theorem identity18737 : scanCanonicalize (H12AffineFastState.compose env18737 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18738 : List Nat := [2,4,8,16,0,17,8,5,1,21,16,0,8,17,0,3,0,16,21,1,16,1,16,2,8,16,17,0,0,17,20,1,5,0,16,0]

theorem envBound18738 : H12AffineFastState.Bounded env18738 := by
  intro p hp
  have h : env18738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18737_18738 : H12AffineEnvironment.transform 4 0 env18737 = env18738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18737 == env18738) = true)

theorem identity18738 : scanCanonicalize (H12AffineFastState.compose env18738 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18738 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18739 : List Nat := [2,4,8,1,0,0,8,5,1,4,1,0,8,0,0,3,0,1,4,1,1,1,1,2,8,1,0,0,0,0,5,1,5,0,1,0]

theorem envBound18739 : H12AffineFastState.Bounded env18739 := by
  intro p hp
  have h : env18739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18738_18739 : H12AffineEnvironment.transform 3 1 env18738 = env18739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18738 == env18739) = true)

def env18740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452649,441658,8193,65,245019,115015,17665,10281,119043,329730,256,485711,493666,63069]

theorem envBound18740 : H12AffineFastState.Bounded env18740 := by
  intro p hp
  have h : env18740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18709_18740 : H12AffineEnvironment.transform 6 9 env18709 = env18740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18709 == env18740) = true)

def env18741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272392,272441,294186,8193,65,97547,115015,17665,10281,119043,329730,256,371039,346226,63069]

theorem envBound18741 : H12AffineFastState.Bounded env18741 := by
  intro p hp
  have h : env18741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18740_18741 : H12AffineEnvironment.transform 16 49168 env18740 = env18741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18740 == env18741) = true)

theorem identity18741 : scanCanonicalize (H12AffineFastState.compose env18741 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18741 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,262144,1024,32769,276584,272392,272441,272427,8193,65,75786,103494,4096,10281,99330,329730,256,371039,335219,41820]

theorem envBound18742 : H12AffineFastState.Bounded env18742 := by
  intro p hp
  have h : env18742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18741_18742 : H12AffineEnvironment.transform 13 5377 env18741 = env18742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18741 == env18742) = true)

theorem identity18742 : scanCanonicalize (H12AffineFastState.compose env18742 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound18742 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env18743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,108927,1024,32769,102679,98679,98630,98644,8193,65,75786,103494,4096,10281,99330,41341,256,32,46092,41820]

theorem envBound18743 : H12AffineFastState.Bounded env18743 := by
  intro p hp
  have h : env18743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18742_18743 : H12AffineEnvironment.transform 17 108927 env18742 = env18743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env18742 == env18743) = true)

theorem identity18743 : scanCanonicalize (H12AffineFastState.compose env18743 (packedSelected [4,5,9,12,14,15,16,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 41342) := by decide +kernel

theorem selectedBound18743 : packedSelected [4,5,9,12,14,15,16,19,24] rootPS < 2^1333 := by decide +kernel

def env18744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,41342,38161,2049,1024,32769,12393,8201,8248,8234,8193,65,35188,13624,4096,10281,9596,41341,256,32,46092,41820]

theorem envBound18744 : H12AffineFastState.Bounded env18744 := by
  intro p hp
  have h : env18744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18743_18744 : H12AffineEnvironment.transform 15 41342 env18743 = env18744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41342 env18743 == env18744) = true)

theorem identity18744 : scanCanonicalize (H12AffineFastState.compose env18744 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18744 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18745 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,41263,38161,2049,1024,32769,12344,8201,8248,8234,8193,16,35109,13624,4096,10281,9517,41260,256,32,46092,41741]

theorem envBound18745 : H12AffineFastState.Bounded env18745 := by
  intro p hp
  have h : env18745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18744_18745 : H12AffineEnvironment.transform 5 17 env18744 = env18745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18744 == env18745) = true)

theorem identity18745 : scanCanonicalize (H12AffineFastState.compose env18745 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound18745 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS < 2^1333 := by decide +kernel

def env18746 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5377,32768,33030,38161,2049,1024,32769,4113,32,17,3,40,16,35109,5393,4096,2048,1284,33029,256,32,37925,33572]

theorem envBound18746 : H12AffineFastState.Bounded env18746 := by
  intro p hp
  have h : env18746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18745_18746 : H12AffineEnvironment.transform 12 41 env18745 = env18746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18745 == env18746) = true)

theorem identity18746 : scanCanonicalize (H12AffineFastState.compose env18746 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound18746 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18747 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5377,32,294,5425,2049,1024,33,4113,32,17,3,40,16,2309,5393,4096,2048,1284,293,256,32,5125,772]

theorem envBound18747 : H12AffineFastState.Bounded env18747 := by
  intro p hp
  have h : env18747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18746_18747 : H12AffineEnvironment.transform 14 32 env18746 = env18747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env18746 == env18747) = true)

theorem identity18747 : scanCanonicalize (H12AffineFastState.compose env18747 (packedSelected [0,6,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18747 : packedSelected [0,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env18748 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,41,5125,32,34,5173,2049,1024,33,4113,32,17,3,40,16,2049,5141,4096,2048,1024,33,4,32,5125,512]

theorem envBound18748 : H12AffineFastState.Bounded env18748 := by
  intro p hp
  have h : env18748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18747_18748 : H12AffineEnvironment.transform 7 4 env18747 = env18748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18747 == env18748) = true)

theorem identity18748 : scanCanonicalize (H12AffineFastState.compose env18748 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18748 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18749 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5125,0,2,5141,2049,1024,1,4113,0,17,3,8,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound18749 : H12AffineFastState.Bounded env18749 := by
  intro p hp
  have h : env18749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18748_18749 : H12AffineEnvironment.transform 4 0 env18748 = env18749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18748 == env18749) = true)

def env18750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272392,272440,294187,8193,65,97546,115015,17665,10281,119043,329730,256,371038,346227,63069]

theorem envBound18750 : H12AffineFastState.Bounded env18750 := by
  intro p hp
  have h : env18750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18740_18750 : H12AffineEnvironment.transform 16 49169 env18740 = env18750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18740 == env18750) = true)

theorem identity18750 : scanCanonicalize (H12AffineFastState.compose env18750 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound18750 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1024,32769,17729,21792,21776,3,8193,65,97546,115015,17665,10281,119043,95530,256,119926,79195,63069]

theorem envBound18751 : H12AffineFastState.Bounded env18751 := by
  intro p hp
  have h : env18751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18750_18751 : H12AffineEnvironment.transform 17 32040 env18750 = env18751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env18750 == env18751) = true)

theorem identity18751 : scanCanonicalize (H12AffineFastState.compose env18751 (packedSelected [0,1,4,5,10,12,14,15,18,19,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound18751 : packedSelected [0,1,4,5,10,12,14,15,18,19,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env18752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29823,49169,32040,1024,32769,17729,21792,21776,3,8193,65,2421,46392,17665,10281,42364,341,256,40969,16676,63069]

theorem envBound18752 : H12AffineFastState.Bounded env18752 := by
  intro p hp
  have h : env18752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18751_18752 : H12AffineEnvironment.transform 15 29823 env18751 = env18752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env18751 == env18752) = true)

theorem identity18752 : scanCanonicalize (H12AffineFastState.compose env18752 (packedSelected [0,1,2,5,6,8,11,14,16,18,19,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18752 : packedSelected [0,1,2,5,6,8,11,14,16,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env18753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,21794,49169,23669,1024,32769,17729,21792,21776,3,348,65,2421,37989,17665,2420,33825,341,256,33108,16676,55040]

theorem envBound18753 : H12AffineFastState.Bounded env18753 := by
  intro p hp
  have h : env18753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18752_18753 : H12AffineEnvironment.transform 12 349 env18752 = env18753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18752 == env18753) = true)

theorem identity18753 : scanCanonicalize (H12AffineFastState.compose env18753 (packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound18753 : packedSelected [0,1,3,7,8,9,10,12,14,15,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env18754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5157,32768,263,37940,2128,1024,32769,4452,261,309,3,348,65,2421,37989,4388,2420,33825,341,256,33108,5377,33573]

theorem envBound18754 : H12AffineFastState.Bounded env18754 := by
  intro p hp
  have h : env18754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18753_18754 : H12AffineEnvironment.transform 13 5157 env18753 = env18754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env18753 == env18754) = true)

theorem identity18754 : scanCanonicalize (H12AffineFastState.compose env18754 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18754 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18755 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5157,32768,115,37940,2128,1024,32769,4112,113,65,3,40,65,2049,37989,4176,2048,33825,33,116,32800,5237,33361]

theorem envBound18755 : H12AffineFastState.Bounded env18755 := by
  intro p hp
  have h : env18755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18754_18755 : H12AffineEnvironment.transform 7 116 env18754 = env18755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18754 == env18755) = true)

theorem identity18755 : scanCanonicalize (H12AffineFastState.compose env18755 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18755 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env18756 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,32768,35,37940,2048,1024,32769,4112,33,17,3,40,17,2049,37941,4096,2048,33825,33,36,32800,5157,33281]

theorem envBound18756 : H12AffineFastState.Bounded env18756 := by
  intro p hp
  have h : env18756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18755_18756 : H12AffineEnvironment.transform 5 16 env18755 = env18756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18755 == env18756) = true)

theorem identity18756 : scanCanonicalize (H12AffineFastState.compose env18756 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 6682) := by decide +kernel

theorem selectedBound18756 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env18757 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,6682,35,3630,2048,1024,6683,4112,33,17,3,40,17,2049,3631,4096,2048,7739,33,36,6714,5157,6171]

theorem envBound18757 : H12AffineFastState.Bounded env18757 := by
  intro p hp
  have h : env18757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18756_18757 : H12AffineEnvironment.transform 14 6682 env18756 = env18757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6682 env18756 == env18757) = true)

theorem identity18757 : scanCanonicalize (H12AffineFastState.compose env18757 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound18757 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env18758 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,3077,41,2080,1567,35,3630,2048,1024,1566,3093,33,17,3,40,17,2049,3631,3077,2048,574,33,36,1599,2080,1054]

theorem envBound18758 : H12AffineFastState.Bounded env18758 := by
  intro p hp
  have h : env18758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18757_18758 : H12AffineEnvironment.transform 11 3077 env18757 = env18758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env18757 == env18758) = true)

theorem identity18758 : scanCanonicalize (H12AffineFastState.compose env18758 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound18758 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18759 : List Nat := [2,4,8,10,32,10,9,36,512,1024,2048,3077,41,2080,1541,35,3630,2048,1024,1540,3087,33,11,3,40,11,2049,3631,3077,2048,548,33,36,1573,2080,1028]

theorem envBound18759 : H12AffineFastState.Bounded env18759 := by
  intro p hp
  have h : env18759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18758_18759 : H12AffineEnvironment.transform 3 10 env18758 = env18759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env18758 == env18759) = true)

theorem identity18759 : scanCanonicalize (H12AffineFastState.compose env18759 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound18759 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18760 : List Nat := [2,4,8,10,32,10,9,36,512,1024,1573,544,41,1541,1541,35,11,1573,1024,1540,554,33,11,3,40,11,1572,10,544,1573,548,33,36,1573,1541,1028]

theorem envBound18760 : H12AffineFastState.Bounded env18760 := by
  intro p hp
  have h : env18760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18759_18760 : H12AffineEnvironment.transform 10 1573 env18759 = env18760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env18759 == env18760) = true)

theorem identity18760 : scanCanonicalize (H12AffineFastState.compose env18760 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18760 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18761 : List Nat := [2,4,2,0,32,0,3,36,512,1024,1573,544,35,1541,1541,35,1,1573,1024,1540,544,33,1,3,34,1,1572,0,544,1573,548,33,36,1573,1541,1028]

theorem envBound18761 : H12AffineFastState.Bounded env18761 := by
  intro p hp
  have h : env18761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18760_18761 : H12AffineEnvironment.transform 2 2 env18760 = env18761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18760 == env18761) = true)

theorem identity18761 : scanCanonicalize (H12AffineFastState.compose env18761 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18761 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env18762 : List Nat := [2,4,2,0,1,0,3,5,512,1024,1540,513,2,1541,1541,2,1,1540,1024,1540,513,0,1,3,3,1,1541,0,513,1540,517,0,5,1540,1541,1028]

theorem envBound18762 : H12AffineFastState.Bounded env18762 := by
  intro p hp
  have h : env18762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18761_18762 : H12AffineEnvironment.transform 4 1 env18761 = env18762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18761 == env18762) = true)

theorem identity18762 : scanCanonicalize (H12AffineFastState.compose env18762 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound18762 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18763 : List Nat := [2,1,2,0,1,0,3,0,512,1024,1537,513,2,1536,1536,2,1,1537,1024,1537,513,0,1,3,3,1,1536,0,513,1537,512,0,0,1537,1536,1025]

theorem envBound18763 : H12AffineFastState.Bounded env18763 := by
  intro p hp
  have h : env18763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18762_18763 : H12AffineEnvironment.transform 1 1 env18762 = env18763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env18762 == env18763) = true)

theorem identity18763 : scanCanonicalize (H12AffineFastState.compose env18763 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound18763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18764 : List Nat := [0,1,0,0,1,0,1,0,512,1024,1537,513,0,1536,1536,0,1,1537,1024,1537,513,0,1,1,1,1,1536,0,513,1537,512,0,0,1537,1536,1025]

theorem envBound18764 : H12AffineFastState.Bounded env18764 := by
  intro p hp
  have h : env18764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18763_18764 : H12AffineEnvironment.transform 0 0 env18763 = env18764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env18763 == env18764) = true)

theorem identity18764 : scanCanonicalize (H12AffineFastState.compose env18764 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 512) := by decide +kernel

theorem selectedBound18764 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18765 : List Nat := [0,1,0,0,1,0,1,0,512,512,1,513,0,0,0,0,1,1,512,1,513,0,1,1,1,1,0,0,513,1,512,0,0,1,0,513]

theorem envBound18765 : H12AffineFastState.Bounded env18765 := by
  intro p hp
  have h : env18765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18764_18765 : H12AffineEnvironment.transform 9 512 env18764 = env18765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 512 env18764 == env18765) = true)

theorem identity18765 : scanCanonicalize (H12AffineFastState.compose env18765 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18766 : List Nat := [0,1,0,0,1,0,1,0,1,1,1,0,0,0,0,0,1,1,1,1,0,0,1,1,1,1,0,0,0,1,1,0,0,1,0,0]

theorem envBound18766 : H12AffineFastState.Bounded env18766 := by
  intro p hp
  have h : env18766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18765_18766 : H12AffineEnvironment.transform 8 1 env18765 = env18766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18765 == env18766) = true)

def env18767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,441659,8328,65,4691218,115150,17664,10281,119042,4268163,256,485830,493666,63189]

theorem envBound18767 : H12AffineFastState.Bounded env18767 := by
  intro p hp
  have h : env18767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18684_18767 : H12AffineEnvironment.transform 20 456825 env18684 = env18767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env18684 == env18767) = true)

def env18768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,441659,8328,65,245138,115150,17664,10281,119042,329731,256,485830,493666,63189]

theorem envBound18768 : H12AffineFastState.Bounded env18768 := by
  intro p hp
  have h : env18768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18767_18768 : H12AffineEnvironment.transform 21 272512 env18767 = env18768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18767 == env18768) = true)

theorem identity18768 : scanCanonicalize (H12AffineFastState.compose env18768 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound18768 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,58516,144493,62660,41430,8328,65,245138,115150,17664,10281,119042,201966,256,95531,103567,63189]

theorem envBound18769 : H12AffineFastState.Bounded env18769 := by
  intro p hp
  have h : env18769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18768_18769 : H12AffineEnvironment.transform 17 138477 env18768 = env18769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env18768 == env18769) = true)

def env18770 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138429,1024,32769,58516,144445,62612,41350,8328,17,245138,115102,17664,10281,119042,201918,256,95531,103567,63109]

theorem envBound18770 : H12AffineFastState.Bounded env18770 := by
  intro p hp
  have h : env18770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18769_18770 : H12AffineEnvironment.transform 5 16 env18769 = env18770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18769 == env18770) = true)

theorem identity18770 : scanCanonicalize (H12AffineFastState.compose env18770 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound18770 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env18771 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33030,131072,138429,1024,32769,58516,144445,62612,41350,8328,17,146580,16536,17664,10281,20484,169400,256,62509,5513,63109]

theorem envBound18771 : H12AffineFastState.Bounded env18771 := by
  intro p hp
  have h : env18771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18770_18771 : H12AffineEnvironment.transform 15 33030 env18770 = env18771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env18770 == env18771) = true)

theorem identity18771 : scanCanonicalize (H12AffineFastState.compose env18771 (packedSelected [4,7,9,16,17,18,20,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18771 : packedSelected [4,7,9,16,17,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env18772 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33030,131072,138429,1024,32769,45341,144445,41245,41350,8328,17,146580,5393,4233,10281,1421,169400,256,41380,5513,41740]

theorem envBound18772 : H12AffineFastState.Bounded env18772 := by
  intro p hp
  have h : env18772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18771_18772 : H12AffineEnvironment.transform 13 5513 env18771 = env18772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18771 == env18772) = true)

theorem identity18772 : scanCanonicalize (H12AffineFastState.compose env18772 (packedSelected [16,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound18772 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env18773 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33030,13341,10400,1024,32769,45341,32,41245,41350,8328,17,2185,5393,4233,10281,1421,41381,256,41380,5513,41740]

theorem envBound18773 : H12AffineFastState.Bounded env18773 := by
  intro p hp
  have h : env18773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18772_18773 : H12AffineEnvironment.transform 16 13341 env18772 = env18773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env18772 == env18773) = true)

theorem identity18773 : scanCanonicalize (H12AffineFastState.compose env18773 (packedSelected [2,4,6,9,14,15,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18773 : packedSelected [2,4,6,9,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env18774 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4541,32768,33030,12329,10400,52,32769,45341,32,41245,41350,8328,17,2185,4389,4233,10281,441,41381,256,41380,4541,41740]

theorem envBound18774 : H12AffineFastState.Bounded env18774 := by
  intro p hp
  have h : env18774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18773_18774 : H12AffineEnvironment.transform 9 52 env18773 = env18774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18773 == env18774) = true)

theorem identity18774 : scanCanonicalize (H12AffineFastState.compose env18774 (packedSelected [6,14] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound18774 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env18775 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4541,8493,8235,12329,10400,52,8492,4144,32,48,171,8328,17,2185,4389,4233,10281,441,136,256,137,4541,545]

theorem envBound18775 : H12AffineFastState.Bounded env18775 := by
  intro p hp
  have h : env18775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18774_18775 : H12AffineEnvironment.transform 14 8493 env18774 = env18775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env18774 == env18775) = true)

theorem identity18775 : scanCanonicalize (H12AffineFastState.compose env18775 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound18775 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env18776 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,301,4541,0,262,4356,2445,52,1,4144,32,48,171,421,17,2185,4389,4233,2308,441,136,256,137,4541,545]

theorem envBound18776 : H12AffineFastState.Bounded env18776 := by
  intro p hp
  have h : env18776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18775_18776 : H12AffineEnvironment.transform 12 301 env18775 = env18776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env18775 == env18776) = true)

theorem identity18776 : scanCanonicalize (H12AffineFastState.compose env18776 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18776 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18777 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,301,4405,0,262,4356,2309,52,1,4144,32,48,35,301,17,2049,4389,4097,2308,305,0,256,1,4405,545]

theorem envBound18777 : H12AffineFastState.Bounded env18777 := by
  intro p hp
  have h : env18777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18776_18777 : H12AffineEnvironment.transform 6 8 env18776 = env18777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18776 == env18777) = true)

theorem identity18777 : scanCanonicalize (H12AffineFastState.compose env18777 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18777 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18778 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,269,4373,0,262,4356,2309,20,1,4112,0,16,3,269,17,2049,4357,4097,2308,273,0,256,1,4373,513]

theorem envBound18778 : H12AffineFastState.Bounded env18778 := by
  intro p hp
  have h : env18778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18777_18778 : H12AffineEnvironment.transform 4 0 env18777 = env18778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18777 == env18778) = true)

theorem identity18778 : scanCanonicalize (H12AffineFastState.compose env18778 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound18778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18779 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,1,269,276,0,262,261,2309,20,1,17,0,16,3,269,17,2049,260,0,2308,273,0,256,1,276,513]

theorem envBound18779 : H12AffineFastState.Bounded env18779 := by
  intro p hp
  have h : env18779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18778_18779 : H12AffineEnvironment.transform 11 1 env18778 = env18779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env18778 == env18779) = true)

theorem identity18779 : scanCanonicalize (H12AffineFastState.compose env18779 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound18779 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18780 : List Nat := [2,4,8,16,0,16,8,256,260,20,2048,1,269,276,0,262,261,2309,20,1,17,0,16,3,269,17,2049,260,0,2308,273,0,256,1,276,261]

theorem envBound18780 : H12AffineFastState.Bounded env18780 := by
  intro p hp
  have h : env18780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18779_18780 : H12AffineEnvironment.transform 8 260 env18779 = env18780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env18779 == env18780) = true)

theorem identity18780 : scanCanonicalize (H12AffineFastState.compose env18780 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18780 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18781 : List Nat := [2,4,8,16,0,16,8,256,260,20,0,1,269,276,0,262,261,261,20,1,17,0,16,3,269,17,1,260,0,260,273,0,256,1,276,261]

theorem envBound18781 : H12AffineFastState.Bounded env18781 := by
  intro p hp
  have h : env18781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18780_18781 : H12AffineEnvironment.transform 10 0 env18780 = env18781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18780 == env18781) = true)

theorem identity18781 : scanCanonicalize (H12AffineFastState.compose env18781 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18781 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18782 : List Nat := [2,4,8,1,0,1,8,256,260,5,0,1,269,261,0,262,261,261,5,1,0,0,1,3,269,0,1,260,0,260,256,0,256,1,261,261]

theorem envBound18782 : H12AffineFastState.Bounded env18782 := by
  intro p hp
  have h : env18782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18781_18782 : H12AffineEnvironment.transform 3 1 env18781 = env18782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18781 == env18782) = true)

theorem identity18782 : scanCanonicalize (H12AffineFastState.compose env18782 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18783 : List Nat := [2,4,8,1,0,1,8,4,0,5,0,1,9,1,0,2,1,1,5,1,0,0,1,3,9,0,1,0,0,0,4,0,4,1,1,1]

theorem envBound18783 : H12AffineFastState.Bounded env18783 := by
  intro p hp
  have h : env18783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18782_18783 : H12AffineEnvironment.transform 7 4 env18782 = env18783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18782 == env18783) = true)

def env18784 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138428,1024,32769,58516,144444,62613,41351,8328,16,245138,115103,17664,10281,119042,201919,256,95531,103567,63108]

theorem envBound18784 : H12AffineFastState.Bounded env18784 := by
  intro p hp
  have h : env18784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18769_18784 : H12AffineEnvironment.transform 5 17 env18769 = env18784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18769 == env18784) = true)

theorem identity18784 : scanCanonicalize (H12AffineFastState.compose env18784 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound18784 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env18785 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,131072,138428,1024,32769,58516,144444,62613,41351,8328,16,171281,57628,17664,10281,61825,144444,256,21928,46092,63108]

theorem envBound18785 : H12AffineFastState.Bounded env18785 := by
  intro p hp
  have h : env18785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18784_18785 : H12AffineEnvironment.transform 15 8323 env18784 = env18785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env18784 == env18785) = true)

theorem identity18785 : scanCanonicalize (H12AffineFastState.compose env18785 (packedSelected [3,4,7,9,17,18,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 46228) := by decide +kernel

theorem selectedBound18785 : packedSelected [3,4,7,9,17,18,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env18786 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,46228,43048,1024,32769,58516,32936,62613,41351,8328,16,10629,57628,17664,10281,61825,32936,256,21928,46092,63108]

theorem envBound18786 : H12AffineFastState.Bounded env18786 := by
  intro p hp
  have h : env18786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18785_18786 : H12AffineEnvironment.transform 16 46228 env18785 = env18786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46228 env18785 == env18786) = true)

theorem identity18786 : scanCanonicalize (H12AffineFastState.compose env18786 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18786 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env18787 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,46228,43048,1024,32769,45341,32936,41244,41351,8328,16,10629,46229,4233,10281,41992,32936,256,33,46092,41741]

theorem envBound18787 : H12AffineFastState.Bounded env18787 := by
  intro p hp
  have h : env18787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18786_18787 : H12AffineEnvironment.transform 13 5513 env18786 = env18787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18786 == env18787) = true)

theorem identity18787 : scanCanonicalize (H12AffineFastState.compose env18787 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18787 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env18788 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,32768,399,38296,35108,1024,32769,36881,32936,32784,32907,388,16,2185,38297,4233,2341,34052,32936,256,33,38144,33281]

theorem envBound18788 : H12AffineFastState.Bounded env18788 := by
  intro p hp
  have h : env18788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18787_18788 : H12AffineEnvironment.transform 12 268 env18787 = env18788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18787 == env18788) = true)

theorem identity18788 : scanCanonicalize (H12AffineFastState.compose env18788 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound18788 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18789 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,136,399,5392,2476,1024,137,4249,32,152,3,388,16,2185,5393,4233,2341,1420,32,256,33,5512,649]

theorem envBound18789 : H12AffineFastState.Bounded env18789 := by
  intro p hp
  have h : env18789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18788_18789 : H12AffineEnvironment.transform 14 136 env18788 = env18789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18788 == env18789) = true)

theorem identity18789 : scanCanonicalize (H12AffineFastState.compose env18789 (packedSelected [4,6,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound18789 : packedSelected [4,6,9,10] rootPS < 2^1333 := by decide +kernel

def env18790 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2233,268,3376,136,399,3497,2476,1024,137,2080,32,152,3,388,16,2185,3496,2096,2341,1420,32,256,33,3377,649]

theorem envBound18790 : H12AffineFastState.Bounded env18790 := by
  intro p hp
  have h : env18790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18789_18790 : H12AffineEnvironment.transform 11 2233 env18789 = env18790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env18789 == env18790) = true)

theorem identity18790 : scanCanonicalize (H12AffineFastState.compose env18790 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18790 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env18791 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2097,268,3376,0,263,3361,2340,1024,1,2080,32,16,3,268,16,2049,3360,2096,2341,1284,32,256,33,3377,513]

theorem envBound18791 : H12AffineFastState.Bounded env18791 := by
  intro p hp
  have h : env18791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18790_18791 : H12AffineEnvironment.transform 6 8 env18790 = env18791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18790 == env18791) = true)

theorem identity18791 : scanCanonicalize (H12AffineFastState.compose env18791 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound18791 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18792 : List Nat := [2,4,8,16,32,17,8,256,512,1024,309,260,268,1029,0,263,1044,17,1024,1,277,32,16,3,268,16,308,1045,261,16,1284,32,256,33,1028,513]

theorem envBound18792 : H12AffineFastState.Bounded env18792 := by
  intro p hp
  have h : env18792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18791_18792 : H12AffineEnvironment.transform 10 309 env18791 = env18792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env18791 == env18792) = true)

theorem identity18792 : scanCanonicalize (H12AffineFastState.compose env18792 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound18792 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18793 : List Nat := [2,4,8,16,32,17,8,256,512,785,309,260,268,788,0,263,773,17,785,1,277,32,16,3,268,16,308,772,261,16,533,32,256,33,789,513]

theorem envBound18793 : H12AffineFastState.Bounded env18793 := by
  intro p hp
  have h : env18793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18792_18793 : H12AffineEnvironment.transform 9 785 env18792 = env18793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env18792 == env18793) = true)

theorem identity18793 : scanCanonicalize (H12AffineFastState.compose env18793 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18793 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18794 : List Nat := [2,4,8,16,32,17,8,5,512,532,48,1,9,529,0,2,512,17,532,1,16,32,16,3,9,16,49,513,0,16,533,32,5,33,528,513]

theorem envBound18794 : H12AffineFastState.Bounded env18794 := by
  intro p hp
  have h : env18794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18793_18794 : H12AffineEnvironment.transform 7 5 env18793 = env18794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18793 == env18794) = true)

theorem identity18794 : scanCanonicalize (H12AffineFastState.compose env18794 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18794 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18795 : List Nat := [2,4,8,16,1,17,8,5,512,532,17,1,9,529,0,2,512,17,532,1,16,1,16,3,9,16,16,513,0,16,533,1,5,0,528,513]

theorem envBound18795 : H12AffineFastState.Bounded env18795 := by
  intro p hp
  have h : env18795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18794_18795 : H12AffineEnvironment.transform 4 1 env18794 = env18795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18794 == env18795) = true)

def env18796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,441659,8328,65,245139,115150,17664,10281,119042,329730,256,485830,493666,63189]

theorem envBound18796 : H12AffineFastState.Bounded env18796 := by
  intro p hp
  have h : env18796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18767_18796 : H12AffineEnvironment.transform 21 272513 env18767 = env18796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18767 == env18796) = true)

theorem identity18796 : scanCanonicalize (H12AffineFastState.compose env18796 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound18796 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396461,272513,400637,412143,8328,65,215367,79130,17664,10281,75222,329730,256,485830,490678,513]

theorem envBound18797 : H12AffineFastState.Bounded env18797 := by
  intro p hp
  have h : env18797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18796_18797 : H12AffineEnvironment.transform 14 29908 env18796 = env18797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env18796 == env18797) = true)

def env18798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396325,272393,400501,412007,8192,65,215367,79130,17664,10281,75102,329730,256,485710,490558,513]

theorem envBound18798 : H12AffineFastState.Bounded env18798 := by
  intro p hp
  have h : env18798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18797_18798 : H12AffineEnvironment.transform 6 8 env18797 = env18798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18797 == env18798) = true)

theorem identity18798 : scanCanonicalize (H12AffineFastState.compose env18798 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18798 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,140301,33,144477,155983,8192,65,215367,79130,17664,10281,75102,73770,256,213350,218134,513]

theorem envBound18799 : H12AffineFastState.Bounded env18799 := by
  intro p hp
  have h : env18799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18798_18799 : H12AffineEnvironment.transform 17 10280 env18798 = env18799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18798 == env18799) = true)

theorem identity18799 : scanCanonicalize (H12AffineFastState.compose env18799 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18799 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env18800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,140301,33,144477,144463,8192,65,203847,79130,4096,10281,75102,73770,256,201830,196886,513]

theorem envBound18800 : H12AffineFastState.Bounded env18800 := by
  intro p hp
  have h : env18800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18799_18800 : H12AffineEnvironment.transform 13 5376 env18799 = env18800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18799 == env18800) = true)

theorem identity18800 : scanCanonicalize (H12AffineFastState.compose env18800 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18800 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,5393,10280,1024,8541,12572,33,8524,8542,8192,65,67926,79130,4096,10281,75102,73770,256,65911,70663,513]

theorem envBound18801 : H12AffineFastState.Bounded env18801 := by
  intro p hp
  have h : env18801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18800_18801 : H12AffineEnvironment.transform 16 5393 env18800 = env18801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18800 == env18801) = true)

theorem identity18801 : scanCanonicalize (H12AffineFastState.compose env18801 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18801 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,65536,5393,2420,1024,1,4160,33,16,2,348,65,67926,70726,4096,2421,66562,65910,256,65911,70663,513]

theorem envBound18802 : H12AffineFastState.Bounded env18802 := by
  intro p hp
  have h : env18802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18801_18802 : H12AffineEnvironment.transform 12 348 env18801 = env18802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18801 == env18802) = true)

theorem identity18802 : scanCanonicalize (H12AffineFastState.compose env18802 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18802 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env18803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5393,2420,1024,1,4160,33,16,2,348,65,2049,5393,4096,2421,1365,33,256,32,5456,513]

theorem envBound18803 : H12AffineFastState.Bounded env18803 := by
  intro p hp
  have h : env18803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18802_18803 : H12AffineEnvironment.transform 15 343 env18802 = env18803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18802 == env18803) = true)

theorem identity18803 : scanCanonicalize (H12AffineFastState.compose env18803 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound18803 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18804 : List Nat := [2,4,8,16,32,64,8,256,512,565,2048,4096,348,4917,0,343,4900,2420,565,1,4160,33,16,2,348,65,2049,4900,4096,2421,864,33,256,32,4965,513]

theorem envBound18804 : H12AffineFastState.Bounded env18804 := by
  intro p hp
  have h : env18804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18803_18804 : H12AffineEnvironment.transform 9 565 env18803 = env18804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env18803 == env18804) = true)

theorem identity18804 : scanCanonicalize (H12AffineFastState.compose env18804 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18804 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18805 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,4096,269,4917,0,262,4900,2341,565,1,4113,33,16,2,269,16,2049,4900,4096,2340,817,33,256,32,4916,513]

theorem envBound18805 : H12AffineFastState.Bounded env18805 := by
  intro p hp
  have h : env18805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18804_18805 : H12AffineEnvironment.transform 5 17 env18804 = env18805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18804 == env18805) = true)

theorem identity18805 : scanCanonicalize (H12AffineFastState.compose env18805 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound18805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18806 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,513,269,308,0,262,293,2341,565,1,528,33,16,2,269,16,2049,293,513,2340,817,33,256,32,309,513]

theorem envBound18806 : H12AffineFastState.Bounded env18806 := by
  intro p hp
  have h : env18806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18805_18806 : H12AffineEnvironment.transform 11 513 env18805 = env18806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env18805 == env18806) = true)

theorem identity18806 : scanCanonicalize (H12AffineFastState.compose env18806 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound18806 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18807 : List Nat := [2,4,8,16,32,17,8,256,512,565,820,513,269,308,0,262,293,529,565,1,528,33,16,2,269,16,821,293,513,528,817,33,256,32,309,513]

theorem envBound18807 : H12AffineFastState.Bounded env18807 := by
  intro p hp
  have h : env18807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18806_18807 : H12AffineEnvironment.transform 10 820 env18806 = env18807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env18806 == env18807) = true)

theorem identity18807 : scanCanonicalize (H12AffineFastState.compose env18807 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound18807 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18808 : List Nat := [2,4,8,16,32,17,8,256,292,273,16,293,269,308,0,262,293,309,273,1,308,33,16,2,269,16,17,293,293,308,21,33,256,32,309,293]

theorem envBound18808 : H12AffineFastState.Bounded env18808 := by
  intro p hp
  have h : env18808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18807_18808 : H12AffineEnvironment.transform 8 292 env18807 = env18808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env18807 == env18808) = true)

theorem identity18808 : scanCanonicalize (H12AffineFastState.compose env18808 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18808 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18809 : List Nat := [2,4,8,16,16,17,8,256,276,273,16,277,269,260,0,262,277,261,273,1,260,17,16,2,269,16,17,277,277,260,21,17,256,16,261,277]

theorem envBound18809 : H12AffineFastState.Bounded env18809 := by
  intro p hp
  have h : env18809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18808_18809 : H12AffineEnvironment.transform 4 16 env18808 = env18809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18808 == env18809) = true)

theorem identity18809 : scanCanonicalize (H12AffineFastState.compose env18809 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18809 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18810 : List Nat := [2,4,8,16,16,17,8,21,1,4,16,0,24,17,0,19,0,16,4,1,17,17,16,2,24,16,17,0,0,17,21,17,21,16,16,0]

theorem envBound18810 : H12AffineFastState.Bounded env18810 := by
  intro p hp
  have h : env18810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18809_18810 : H12AffineEnvironment.transform 7 21 env18809 = env18810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18809 == env18810) = true)

def env18811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396324,272392,400500,412006,8193,65,215367,79130,17664,10281,75103,329730,256,485711,490559,513]

theorem envBound18811 : H12AffineFastState.Bounded env18811 := by
  intro p hp
  have h : env18811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18797_18811 : H12AffineEnvironment.transform 6 9 env18797 = env18811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18797 == env18811) = true)

theorem identity18811 : scanCanonicalize (H12AffineFastState.compose env18811 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound18811 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,355390,272392,359534,338300,8193,65,10589,79130,17664,10281,75103,329730,256,264533,269349,513]

theorem envBound18812 : H12AffineFastState.Bounded env18812 := by
  intro p hp
  have h : env18812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18811_18812 : H12AffineEnvironment.transform 16 90138 env18811 = env18812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env18811 == env18812) = true)

theorem identity18812 : scanCanonicalize (H12AffineFastState.compose env18812 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound18812 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21511,13341,262144,1024,29788,276537,272392,272489,294267,8193,65,10589,24861,17664,10281,29016,285701,256,264533,269349,513]

theorem envBound18813 : H12AffineFastState.Bounded env18813 := by
  intro p hp
  have h : env18813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18812_18813 : H12AffineEnvironment.transform 15 21511 env18812 = env18813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env18812 == env18813) = true)

theorem identity18813 : scanCanonicalize (H12AffineFastState.compose env18813 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 22592) := by decide +kernel

theorem selectedBound18813 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env18814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21511,13341,22592,1024,29788,24697,28744,28713,9531,8193,65,10589,24861,17664,10281,29016,1093,256,20757,17509,513]

theorem envBound18814 : H12AffineFastState.Bounded env18814 := by
  intro p hp
  have h : env18814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18813_18814 : H12AffineEnvironment.transform 17 22592 env18813 = env18814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22592 env18813 == env18814) = true)

theorem identity18814 : scanCanonicalize (H12AffineFastState.compose env18814 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound18814 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env18815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12345,1124,9278,13341,10361,1024,1125,4160,113,16,9531,8193,65,10589,4388,13625,10281,353,1093,256,8492,13404,513]

theorem envBound18815 : H12AffineFastState.Bounded env18815 := by
  intro p hp
  have h : env18815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18814_18815 : H12AffineEnvironment.transform 13 12345 env18814 = env18815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env18814 == env18815) = true)

theorem identity18815 : scanCanonicalize (H12AffineFastState.compose env18815 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound18815 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18816 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,12345,293,8575,12636,10361,321,292,4160,113,16,8314,8193,65,10589,4388,12408,10281,353,260,256,8492,12573,513]

theorem envBound18816 : H12AffineFastState.Bounded env18816 := by
  intro p hp
  have h : env18816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18815_18816 : H12AffineEnvironment.transform 9 321 env18815 = env18816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env18815 == env18816) = true)

theorem identity18816 : scanCanonicalize (H12AffineFastState.compose env18816 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18817 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,40,4113,293,343,4468,2129,321,292,4160,113,16,82,41,65,2421,4388,4176,2049,353,260,256,260,4405,513]

theorem envBound18817 : H12AffineFastState.Bounded env18817 := by
  intro p hp
  have h : env18817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18816_18817 : H12AffineEnvironment.transform 12 40 env18816 = env18817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18816 == env18817) = true)

theorem identity18817 : scanCanonicalize (H12AffineFastState.compose env18817 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound18817 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18818 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,513,40,528,293,343,885,2129,321,292,577,113,16,82,41,65,2421,805,593,2049,353,260,256,260,820,513]

theorem envBound18818 : H12AffineFastState.Bounded env18818 := by
  intro p hp
  have h : env18818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18817_18818 : H12AffineEnvironment.transform 11 513 env18817 = env18818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env18817 == env18818) = true)

theorem identity18818 : scanCanonicalize (H12AffineFastState.compose env18818 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound18818 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env18819 : List Nat := [2,4,8,16,32,64,9,256,512,321,17,513,40,528,293,343,885,64,321,292,577,113,16,82,41,65,356,805,593,16,353,260,256,260,820,513]

theorem envBound18819 : H12AffineFastState.Bounded env18819 := by
  intro p hp
  have h : env18819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18818_18819 : H12AffineEnvironment.transform 10 17 env18818 = env18819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env18818 == env18819) = true)

theorem identity18819 : scanCanonicalize (H12AffineFastState.compose env18819 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound18819 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env18820 : List Nat := [2,4,8,16,32,64,9,84,512,21,17,513,40,528,113,3,545,64,21,112,577,113,16,82,41,65,48,625,593,16,53,80,84,80,608,513]

theorem envBound18820 : H12AffineFastState.Bounded env18820 := by
  intro p hp
  have h : env18820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18819_18820 : H12AffineEnvironment.transform 7 84 env18819 = env18820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env18819 == env18820) = true)

theorem identity18820 : scanCanonicalize (H12AffineFastState.compose env18820 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18820 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18821 : List Nat := [2,4,8,16,32,16,9,4,512,21,17,513,40,528,33,3,545,16,21,32,529,33,16,2,41,17,48,545,513,16,53,0,4,0,560,513]

theorem envBound18821 : H12AffineFastState.Bounded env18821 := by
  intro p hp
  have h : env18821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18820_18821 : H12AffineEnvironment.transform 5 16 env18820 = env18821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18820 == env18821) = true)

theorem identity18821 : scanCanonicalize (H12AffineFastState.compose env18821 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound18821 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18822 : List Nat := [2,4,8,16,32,16,9,4,16,21,17,17,40,0,33,3,49,16,21,32,1,33,16,2,41,17,48,49,17,16,53,0,4,0,32,17]

theorem envBound18822 : H12AffineFastState.Bounded env18822 := by
  intro p hp
  have h : env18822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18821_18822 : H12AffineEnvironment.transform 8 16 env18821 = env18822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env18821 == env18822) = true)

theorem identity18822 : scanCanonicalize (H12AffineFastState.compose env18822 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18823 : List Nat := [2,4,8,0,32,0,9,4,0,5,1,1,40,0,33,3,33,0,5,32,1,33,0,2,41,1,32,33,1,0,37,0,4,0,32,1]

theorem envBound18823 : H12AffineFastState.Bounded env18823 := by
  intro p hp
  have h : env18823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18822_18823 : H12AffineEnvironment.transform 3 0 env18822 = env18823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18822 == env18823) = true)

def env18824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound18824 : H12AffineFastState.Bounded env18824 := by
  intro p hp
  have h : env18824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18594_18824 : H12AffineEnvironment.transform 18 1025 env18594 = env18824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18594 == env18824) = true)

theorem identity18824 : scanCanonicalize (H12AffineFastState.compose env18824 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347627) := by decide +kernel

theorem selectedBound18824 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,16777216,8328,65,29868033,17090918,8722619,8830977,25265168,21243946,257,25463111,25454818,25207750]

theorem envBound18825 : H12AffineFastState.Bounded env18825 := by
  intro p hp
  have h : env18825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18824_18825 : H12AffineEnvironment.transform 20 347627 env18824 = env18825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347627 env18824 == env18825) = true)

def env18826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392316,8328,65,12729469,79130,8722619,8830977,8681580,4314198,257,8484155,8492190,8740794]

theorem envBound18826 : H12AffineFastState.Bounded env18826 := by
  intro p hp
  have h : env18826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18825_18826 : H12AffineEnvironment.transform 23 392316 env18825 = env18826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392316 env18825 == env18826) = true)

def env18827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98780,8328,65,12729469,79130,8480027,8568225,8390092,4314198,257,8484155,8492190,8462874]

theorem envBound18827 : H12AffineFastState.Bounded env18827 := by
  intro p hp
  have h : env18827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18826_18827 : H12AffineEnvironment.transform 17 32160 env18826 = env18827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env18826 == env18827) = true)

def env18828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98780,8328,65,8546653,79130,8480027,8568225,8390092,98678,257,8484155,8492190,8462874]

theorem envBound18828 : H12AffineFastState.Bounded env18828 := by
  intro p hp
  have h : env18828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18827_18828 : H12AffineEnvironment.transform 21 21792 env18827 = env18828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env18827 == env18828) = true)

theorem identity18828 : scanCanonicalize (H12AffineFastState.compose env18828 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound18828 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,17,98780,8328,65,158028,79130,91402,179632,1501,98678,257,95530,103567,74251]

theorem envBound18829 : H12AffineFastState.Bounded env18829 := by
  intro p hp
  have h : env18829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18828_18829 : H12AffineEnvironment.transform 22 17 env18828 = env18829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env18828 == env18829) = true)

theorem identity18829 : scanCanonicalize (H12AffineFastState.compose env18829 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18829 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,17,41430,8328,65,158028,5392,17664,179632,1501,41340,257,21792,46213,513]

theorem envBound18830 : H12AffineFastState.Bounded env18830 := by
  intro p hp
  have h : env18830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18829_18830 : H12AffineEnvironment.transform 15 8202 env18829 = env18830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18829 == env18830) = true)

theorem identity18830 : scanCanonicalize (H12AffineFastState.compose env18830 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound18830 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env18831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,8202,131072,32160,1025,216,4161,21792,17,8463,8328,65,158028,5392,17664,146793,1501,8613,257,21792,13404,513]

theorem envBound18831 : H12AffineFastState.Bounded env18831 := by
  intro p hp
  have h : env18831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18830_18831 : H12AffineEnvironment.transform 14 217 env18830 = env18831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env18830 == env18831) = true)

theorem identity18831 : scanCanonicalize (H12AffineFastState.compose env18831 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18831 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env18832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,217,8202,131072,10400,1025,216,4161,32,17,8463,8328,65,146508,5392,4096,146793,1501,8613,257,32,13404,513]

theorem envBound18832 : H12AffineFastState.Bounded env18832 := by
  intro p hp
  have h : env18832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18831_18832 : H12AffineEnvironment.transform 13 5376 env18831 = env18832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18831 == env18832) = true)

theorem identity18832 : scanCanonicalize (H12AffineFastState.compose env18832 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound18832 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env18833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6476,5376,217,6470,131072,4588,1025,216,4161,32,17,6211,6596,65,132352,5392,4096,132133,1501,6377,257,32,3344,513]

theorem envBound18833 : H12AffineFastState.Bounded env18833 := by
  intro p hp
  have h : env18833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18832_18833 : H12AffineEnvironment.transform 12 6476 env18832 = env18833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env18832 == env18833) = true)

theorem identity18833 : scanCanonicalize (H12AffineFastState.compose env18833 (packedSelected [0,3,5,7,12,14,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound18833 : packedSelected [0,3,5,7,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env18834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3188,1336,2420,217,1330,131072,3480,1025,216,3125,32,17,1079,1456,65,132352,2404,3188,132133,1501,1181,257,32,3344,513]

theorem envBound18834 : H12AffineFastState.Bounded env18834 := by
  intro p hp
  have h : env18834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18833_18834 : H12AffineEnvironment.transform 11 3188 env18833 = env18834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env18833 == env18834) = true)

theorem identity18834 : scanCanonicalize (H12AffineFastState.compose env18834 (packedSelected [1,8,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound18834 : packedSelected [1,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env18835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,357,1336,1125,217,1330,131072,137,1025,216,292,32,17,1079,1456,65,132352,1141,357,132133,1501,1181,257,32,1,513]

theorem envBound18835 : H12AffineFastState.Bounded env18835 := by
  intro p hp
  have h : env18835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18834_18835 : H12AffineEnvironment.transform 10 1297 env18834 = env18835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env18834 == env18835) = true)

theorem identity18835 : scanCanonicalize (H12AffineFastState.compose env18835 (packedSelected [0,2,4,10,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 1281) := by decide +kernel

theorem selectedBound18835 : packedSelected [0,2,4,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,357,1336,1125,217,1330,1281,137,1025,216,292,32,17,1079,1456,65,1,1141,357,292,1501,1181,257,32,1,513]

theorem envBound18836 : H12AffineFastState.Bounded env18836 := by
  intro p hp
  have h : env18836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18835_18836 : H12AffineEnvironment.transform 16 1281 env18835 = env18836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1281 env18835 == env18836) = true)

theorem identity18836 : scanCanonicalize (H12AffineFastState.compose env18836 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18836 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env18837 : List Nat := [2,4,8,16,32,64,128,256,512,273,0,357,41,372,217,35,16,137,272,216,292,32,17,294,161,65,1,356,357,292,204,396,257,32,1,513]

theorem envBound18837 : H12AffineFastState.Bounded env18837 := by
  intro p hp
  have h : env18837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18836_18837 : H12AffineEnvironment.transform 9 273 env18836 = env18837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18836 == env18837) = true)

theorem identity18837 : scanCanonicalize (H12AffineFastState.compose env18837 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound18837 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18838 : List Nat := [2,4,8,16,32,64,128,253,512,236,0,152,41,137,217,35,16,137,237,216,217,32,17,219,161,65,1,153,152,217,204,113,252,32,1,513]

theorem envBound18838 : H12AffineFastState.Bounded env18838 := by
  intro p hp
  have h : env18838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18837_18838 : H12AffineEnvironment.transform 7 253 env18837 = env18838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env18837 == env18838) = true)

theorem identity18838 : scanCanonicalize (H12AffineFastState.compose env18838 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18838 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18839 : List Nat := [2,4,8,16,32,16,128,173,512,188,0,152,41,137,137,35,16,137,189,136,137,32,17,139,161,17,1,153,152,137,156,33,172,32,1,513]

theorem envBound18839 : H12AffineFastState.Bounded env18839 := by
  intro p hp
  have h : env18839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18838_18839 : H12AffineEnvironment.transform 5 16 env18838 = env18839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18838 == env18839) = true)

theorem identity18839 : scanCanonicalize (H12AffineFastState.compose env18839 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18839 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18840 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,41,1,1,35,16,1,53,0,1,32,17,3,41,17,1,17,16,1,20,33,36,32,1,513]

theorem envBound18840 : H12AffineFastState.Bounded env18840 := by
  intro p hp
  have h : env18840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18839_18840 : H12AffineEnvironment.transform 6 8 env18839 = env18840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18839 == env18840) = true)

theorem identity18840 : scanCanonicalize (H12AffineFastState.compose env18840 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound18840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18841 : List Nat := [2,4,8,16,5,16,8,0,512,17,0,16,12,1,1,6,16,1,16,0,1,5,17,3,12,17,1,17,16,1,20,4,1,5,1,513]

theorem envBound18841 : H12AffineFastState.Bounded env18841 := by
  intro p hp
  have h : env18841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18840_18841 : H12AffineEnvironment.transform 4 5 env18840 = env18841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env18840 == env18841) = true)

theorem identity18841 : scanCanonicalize (H12AffineFastState.compose env18841 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound18841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18842 : List Nat := [2,4,8,16,5,16,8,0,12,17,0,16,12,1,1,6,16,1,16,0,1,5,17,3,12,17,1,17,16,1,20,4,1,5,1,13]

theorem envBound18842 : H12AffineFastState.Bounded env18842 := by
  intro p hp
  have h : env18842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18841_18842 : H12AffineEnvironment.transform 8 12 env18841 = env18842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env18841 == env18842) = true)

theorem identity18842 : scanCanonicalize (H12AffineFastState.compose env18842 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18843 : List Nat := [2,4,8,0,5,0,8,0,12,1,0,0,12,1,1,6,0,1,0,0,1,5,1,3,12,1,1,1,0,1,4,4,1,5,1,13]

theorem envBound18843 : H12AffineFastState.Bounded env18843 := by
  intro p hp
  have h : env18843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18842_18843 : H12AffineEnvironment.transform 3 0 env18842 = env18843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18842 == env18843) = true)

theorem identity18843 : scanCanonicalize (H12AffineFastState.compose env18843 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18843 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18844 : List Nat := [2,4,2,0,5,0,2,0,6,1,0,0,6,1,1,6,0,1,0,0,1,5,1,3,6,1,1,1,0,1,4,4,1,5,1,7]

theorem envBound18844 : H12AffineFastState.Bounded env18844 := by
  intro p hp
  have h : env18844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18843_18844 : H12AffineEnvironment.transform 2 2 env18843 = env18844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18843 == env18844) = true)

theorem identity18844 : scanCanonicalize (H12AffineFastState.compose env18844 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound18844 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18845 : List Nat := [2,0,2,0,1,0,2,0,2,1,0,0,2,1,1,2,0,1,0,0,1,1,1,3,2,1,1,1,0,1,0,0,1,1,1,3]

theorem envBound18845 : H12AffineFastState.Bounded env18845 := by
  intro p hp
  have h : env18845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18844_18845 : H12AffineEnvironment.transform 1 0 env18844 = env18845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env18844 == env18845) = true)

def env18846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98780,8328,65,8546652,79130,8480027,8568225,8390092,98679,257,8484155,8492190,8462874]

theorem envBound18846 : H12AffineFastState.Bounded env18846 := by
  intro p hp
  have h : env18846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18827_18846 : H12AffineEnvironment.transform 21 21793 env18827 = env18846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env18827 == env18846) = true)

def env18847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21793,8388608,98644,8192,65,8546652,79130,8480027,8568105,8389956,98679,257,8484155,8492054,8462874]

theorem envBound18847 : H12AffineFastState.Bounded env18847 := by
  intro p hp
  have h : env18847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18846_18847 : H12AffineEnvironment.transform 6 8 env18846 = env18847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18846 == env18847) = true)

theorem identity18847 : scanCanonicalize (H12AffineFastState.compose env18847 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 221194) := by decide +kernel

theorem selectedBound18847 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env18848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21793,221194,98644,8192,65,67926,79130,132369,122147,222542,98679,257,136497,193564,147984]

theorem envBound18848 : H12AffineFastState.Bounded env18848 := by
  intro p hp
  have h : env18848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18847_18848 : H12AffineEnvironment.transform 22 221194 env18847 = env18848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 221194 env18847 == env18848) = true)

theorem identity18848 : scanCanonicalize (H12AffineFastState.compose env18848 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18848 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,77899,21793,221194,95497,8192,65,67926,79130,132369,76158,222542,95530,257,136497,131137,147984]

theorem envBound18849 : H12AffineFastState.Bounded env18849 := by
  intro p hp
  have h : env18849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18848_18849 : H12AffineEnvironment.transform 14 29789 env18848 = env18849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18848 == env18849) = true)

theorem identity18849 : scanCanonicalize (H12AffineFastState.compose env18849 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound18849 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env18850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5220,32040,1025,29788,77899,21793,95342,95497,8192,65,67926,79130,4469,76158,94506,95530,257,341,5157,22132]

theorem envBound18850 : H12AffineFastState.Bounded env18850 := by
  intro p hp
  have h : env18850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18849_18850 : H12AffineEnvironment.transform 16 5220 env18849 = env18850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env18849 == env18850) = true)

theorem identity18850 : scanCanonicalize (H12AffineFastState.compose env18850 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound18850 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env18851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,65536,5220,10589,1025,8233,77899,340,73755,74108,8192,65,67926,79130,4469,76158,75103,74079,257,341,5157,513]

theorem envBound18851 : H12AffineFastState.Bounded env18851 := by
  intro p hp
  have h : env18851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18850_18851 : H12AffineEnvironment.transform 13 5237 env18850 = env18851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env18850 == env18851) = true)

theorem identity18851 : scanCanonicalize (H12AffineFastState.compose env18851 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound18851 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,9499,5220,10589,1025,8233,5456,340,1280,1127,8192,65,11341,4097,4469,3173,68,1092,257,341,5157,513]

theorem envBound18852 : H12AffineFastState.Bounded env18852 := by
  intro p hp
  have h : env18852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18851_18852 : H12AffineEnvironment.transform 15 9499 env18851 = env18852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env18851 == env18852) = true)

theorem identity18852 : scanCanonicalize (H12AffineFastState.compose env18852 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound18852 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5237,1077,262,5220,3392,1025,1076,5456,340,1280,1127,1053,65,2128,4097,4469,3173,68,1092,257,341,5157,513]

theorem envBound18853 : H12AffineFastState.Bounded env18853 := by
  intro p hp
  have h : env18853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18852_18853 : H12AffineEnvironment.transform 12 1053 env18852 = env18853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env18852 == env18853) = true)

theorem identity18853 : scanCanonicalize (H12AffineFastState.compose env18853 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18853 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18854 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,5237,1077,115,5220,3125,1025,1076,5157,33,1141,1127,1053,65,2128,4097,4096,3173,68,1092,116,32,5157,513]

theorem envBound18854 : H12AffineFastState.Bounded env18854 := by
  intro p hp
  have h : env18854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18853_18854 : H12AffineEnvironment.transform 7 117 env18853 = env18854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18853 == env18854) = true)

theorem identity18854 : scanCanonicalize (H12AffineFastState.compose env18854 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18854 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env18855 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,1053,5156,1077,34,5173,3125,1025,1076,5157,33,1060,1078,1053,16,2049,4097,4096,3124,21,1045,37,32,5157,513]

theorem envBound18855 : H12AffineFastState.Bounded env18855 := by
  intro p hp
  have h : env18855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18854_18855 : H12AffineEnvironment.transform 5 17 env18854 = env18855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18854 == env18855) = true)

def env18856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77899,21793,8388608,98645,8193,65,8546652,79130,8480027,8568104,8389957,98679,257,8484155,8492055,8462874]

theorem envBound18856 : H12AffineFastState.Bounded env18856 := by
  intro p hp
  have h : env18856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18846_18856 : H12AffineEnvironment.transform 6 9 env18846 = env18856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18846 == env18856) = true)

def env18857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,77899,33,8388608,98645,8193,65,8535132,79130,8466459,8568104,8389957,98679,257,8462395,8492055,8462874]

theorem envBound18857 : H12AffineFastState.Bounded env18857 := by
  intro p hp
  have h : env18857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18856_18857 : H12AffineEnvironment.transform 13 5376 env18856 = env18857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18856 == env18857) = true)

theorem identity18857 : scanCanonicalize (H12AffineFastState.compose env18857 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18857 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,10281,1025,32769,4161,33,8388608,41311,8193,65,8535132,5392,8392721,8568104,8389957,41341,257,8388657,8434717,8389136]

theorem envBound18858 : H12AffineFastState.Bounded env18858 := by
  intro p hp
  have h : env18858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18857_18858 : H12AffineEnvironment.transform 15 8202 env18857 = env18858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18857 == env18858) = true)

theorem identity18858 : scanCanonicalize (H12AffineFastState.compose env18858 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound18858 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env18859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,293,8202,131072,10281,1025,292,4161,33,8388608,8314,8193,65,8535132,5392,8392721,8535053,8389957,8280,257,8388657,8402232,8389136]

theorem envBound18859 : H12AffineFastState.Bounded env18859 := by
  intro p hp
  have h : env18859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18858_18859 : H12AffineEnvironment.transform 14 293 env18858 = env18859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env18858 == env18859) = true)

theorem identity18859 : scanCanonicalize (H12AffineFastState.compose env18859 (packedSelected [0,2,3,6,7,10,11,18,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound18859 : packedSelected [0,2,3,6,7,10,11,18,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,293,8202,5392,10281,1025,292,4161,33,8388608,8314,8193,65,8399180,5392,8392721,8399133,8389957,8280,257,8388657,8402232,8389136]

theorem envBound18860 : H12AffineFastState.Bounded env18860 := by
  intro p hp
  have h : env18860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18859_18860 : H12AffineEnvironment.transform 16 5392 env18859 = env18860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env18859 == env18860) = true)

theorem identity18860 : scanCanonicalize (H12AffineFastState.compose env18860 (packedSelected [0,1,3,4,5,6,7,8,9,10,12,15,19] rootPS)) = affineNative (2^(22+1) ^^^ 1313) := by decide +kernel

theorem selectedBound18860 : packedSelected [0,1,3,4,5,6,7,8,9,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env18861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,293,8202,5392,10281,1025,292,4161,33,1313,8314,8193,65,11373,5392,5424,11324,100,8280,257,1296,12313,1841]

theorem envBound18861 : H12AffineFastState.Bounded env18861 := by
  intro p hp
  have h : env18861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18860_18861 : H12AffineEnvironment.transform 22 1313 env18860 = env18861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 1313 env18860 == env18861) = true)

theorem identity18861 : scanCanonicalize (H12AffineFastState.compose env18861 (packedSelected [0,2,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1352) := by decide +kernel

theorem selectedBound18861 : packedSelected [0,2,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env18862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1352,5376,293,1346,5392,3425,1025,292,4161,33,1313,1330,1353,65,2341,5392,5424,2420,100,1296,257,1296,5457,1841]

theorem envBound18862 : H12AffineFastState.Bounded env18862 := by
  intro p hp
  have h : env18862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18861_18862 : H12AffineEnvironment.transform 12 1352 env18861 = env18862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1352 env18861 == env18862) = true)

theorem identity18862 : scanCanonicalize (H12AffineFastState.compose env18862 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18862 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env18863 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1305,5376,293,1299,5392,3376,1025,292,4112,33,1313,1330,1304,16,2341,5392,5424,2341,53,1296,257,1296,5376,1841]

theorem envBound18863 : H12AffineFastState.Bounded env18863 := by
  intro p hp
  have h : env18863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18862_18863 : H12AffineEnvironment.transform 5 17 env18862 = env18863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18862 == env18863) = true)

theorem identity18863 : scanCanonicalize (H12AffineFastState.compose env18863 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18864 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,1052,5125,32,1046,5141,3125,1025,33,4112,33,1060,1079,1053,16,2080,5141,5173,2080,53,1045,4,1045,5125,1588]

theorem envBound18864 : H12AffineFastState.Bounded env18864 := by
  intro p hp
  have h : env18864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18863_18864 : H12AffineEnvironment.transform 7 5 env18863 = env18864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18863 == env18864) = true)

theorem identity18864 : scanCanonicalize (H12AffineFastState.compose env18864 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18864 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18865 : List Nat := [2,4,8,16,32,17,9,5,512,21,2048,4096,9,4112,32,3,4096,2080,20,33,4112,33,49,34,8,16,2080,4096,4128,2080,53,0,4,0,4112,545]

theorem envBound18865 : H12AffineFastState.Bounded env18865 := by
  intro p hp
  have h : env18865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18864_18865 : H12AffineEnvironment.transform 9 21 env18864 = env18865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18864 == env18865) = true)

theorem identity18865 : scanCanonicalize (H12AffineFastState.compose env18865 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound18865 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18866 : List Nat := [2,4,8,16,32,17,9,5,512,21,2048,0,9,16,32,3,0,2080,20,33,16,33,49,34,8,16,2080,0,32,2080,53,0,4,0,16,545]

theorem envBound18866 : H12AffineFastState.Bounded env18866 := by
  intro p hp
  have h : env18866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18865_18866 : H12AffineEnvironment.transform 11 0 env18865 = env18866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env18865 == env18866) = true)

theorem identity18866 : scanCanonicalize (H12AffineFastState.compose env18866 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18866 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18867 : List Nat := [2,4,8,16,32,17,9,5,1,21,2048,0,9,16,32,3,0,2080,20,33,16,33,49,34,8,16,2080,0,32,2080,53,0,4,0,16,32]

theorem envBound18867 : H12AffineFastState.Bounded env18867 := by
  intro p hp
  have h : env18867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18866_18867 : H12AffineEnvironment.transform 8 1 env18866 = env18867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18866 == env18867) = true)

theorem identity18867 : scanCanonicalize (H12AffineFastState.compose env18867 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18867 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env18868 : List Nat := [2,4,8,16,0,17,9,5,1,21,2048,0,9,16,0,3,0,2048,20,1,16,1,17,2,8,16,2048,0,0,2048,21,0,4,0,16,0]

theorem envBound18868 : H12AffineFastState.Bounded env18868 := by
  intro p hp
  have h : env18868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18867_18868 : H12AffineEnvironment.transform 4 0 env18867 = env18868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18867 == env18868) = true)

theorem identity18868 : scanCanonicalize (H12AffineFastState.compose env18868 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound18868 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18869 : List Nat := [2,4,8,16,0,17,9,5,1,21,17,0,9,16,0,3,0,17,20,1,16,1,17,2,8,16,17,0,0,17,21,0,4,0,16,0]

theorem envBound18869 : H12AffineFastState.Bounded env18869 := by
  intro p hp
  have h : env18869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18868_18869 : H12AffineEnvironment.transform 10 17 env18868 = env18869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env18868 == env18869) = true)

def env18870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77899,32,8388608,98645,8193,65,8535133,79130,8466458,8568104,8389957,98679,257,8462394,8492055,8462874]

theorem envBound18870 : H12AffineFastState.Bounded env18870 := by
  intro p hp
  have h : env18870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18856_18870 : H12AffineEnvironment.transform 13 5377 env18856 = env18870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18856 == env18870) = true)

theorem identity18870 : scanCanonicalize (H12AffineFastState.compose env18870 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound18870 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77899,32,73755,98645,8193,65,203846,79130,4097,236851,75102,98679,257,33,46092,513]

theorem envBound18871 : H12AffineFastState.Bounded env18871 := by
  intro p hp
  have h : env18871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18870_18871 : H12AffineEnvironment.transform 22 73755 env18870 = env18871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env18870 == env18871) = true)

theorem identity18871 : scanCanonicalize (H12AffineFastState.compose env18871 (packedSelected [0,2,3,4,5,6,7,9,11,14,15,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound18871 : packedSelected [0,2,3,4,5,6,7,9,11,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env18872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,70726,10280,1025,32769,77899,32,73755,98645,8193,65,2048,79130,4097,35189,75102,98679,257,33,46092,513]

theorem envBound18872 : H12AffineFastState.Bounded env18872 := by
  intro p hp
  have h : env18872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18871_18872 : H12AffineEnvironment.transform 16 70726 env18871 = env18872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env18871 == env18872) = true)

theorem identity18872 : scanCanonicalize (H12AffineFastState.compose env18872 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound18872 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env18873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,263,5441,10280,1025,32769,12620,32,8476,32850,8193,65,2048,13341,4097,35189,9305,32880,257,33,46092,513]

theorem envBound18873 : H12AffineFastState.Bounded env18873 := by
  intro p hp
  have h : env18873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18872_18873 : H12AffineEnvironment.transform 15 263 env18872 = env18873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env18872 == env18873) = true)

theorem identity18873 : scanCanonicalize (H12AffineFastState.compose env18873 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound18873 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env18874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,263,5441,10280,1025,8461,12620,32,8476,8542,8193,65,2048,13341,4097,10361,9305,8572,257,33,5376,513]

theorem envBound18874 : H12AffineFastState.Bounded env18874 := by
  intro p hp
  have h : env18874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18873_18874 : H12AffineEnvironment.transform 14 8460 env18873 = env18874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env18873 == env18874) = true)

theorem identity18874 : scanCanonicalize (H12AffineFastState.compose env18874 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18874 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18875 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,263,5393,10280,1025,8461,12572,32,8476,8462,8193,17,2048,13341,4097,10281,9225,8492,257,33,5376,513]

theorem envBound18875 : H12AffineFastState.Bounded env18875 := by
  intro p hp
  have h : env18875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18874_18875 : H12AffineEnvironment.transform 5 16 env18874 = env18875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18874 == env18875) = true)

theorem identity18875 : scanCanonicalize (H12AffineFastState.compose env18875 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18875 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18876 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1025,0,4113,32,17,3,268,17,2048,5392,4097,2340,1284,33,257,33,5376,513]

theorem envBound18876 : H12AffineFastState.Bounded env18876 := by
  intro p hp
  have h : env18876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18875_18876 : H12AffineEnvironment.transform 12 269 env18875 = env18876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18875 == env18876) = true)

theorem identity18876 : scanCanonicalize (H12AffineFastState.compose env18876 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18876 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18877 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5377,1,263,5393,2308,1025,0,4113,1,17,3,268,17,2048,5392,4097,2309,1284,0,257,0,5376,513]

theorem envBound18877 : H12AffineFastState.Bounded env18877 := by
  intro p hp
  have h : env18877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18876_18877 : H12AffineEnvironment.transform 4 1 env18876 = env18877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18876 == env18877) = true)

theorem identity18877 : scanCanonicalize (H12AffineFastState.compose env18877 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound18877 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18878 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1029,269,260,1,263,276,2308,1025,0,1044,1,17,3,268,17,2048,277,1028,2309,1284,0,257,0,261,513]

theorem envBound18878 : H12AffineFastState.Bounded env18878 := by
  intro p hp
  have h : env18878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18877_18878 : H12AffineEnvironment.transform 11 1029 env18877 = env18878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env18877 == env18878) = true)

theorem identity18878 : scanCanonicalize (H12AffineFastState.compose env18878 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound18878 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18879 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1557,1029,269,260,1,263,276,1809,1025,0,1044,1,17,3,268,17,1557,277,1028,1808,1284,0,257,0,261,513]

theorem envBound18879 : H12AffineFastState.Bounded env18879 := by
  intro p hp
  have h : env18879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18878_18879 : H12AffineEnvironment.transform 10 1557 env18878 = env18879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env18878 == env18879) = true)

theorem identity18879 : scanCanonicalize (H12AffineFastState.compose env18879 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound18879 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18880 : List Nat := [2,4,8,16,1,16,9,256,512,516,17,513,269,260,1,263,276,277,517,0,528,1,17,3,268,17,17,277,512,276,768,0,257,0,261,513]

theorem envBound18880 : H12AffineFastState.Bounded env18880 := by
  intro p hp
  have h : env18880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18879_18880 : H12AffineEnvironment.transform 9 516 env18879 = env18880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env18879 == env18880) = true)

theorem identity18880 : scanCanonicalize (H12AffineFastState.compose env18880 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18880 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18881 : List Nat := [2,4,8,16,1,16,9,256,0,4,17,1,269,260,1,263,276,277,5,0,16,1,17,3,268,17,17,277,0,276,256,0,257,0,261,1]

theorem envBound18881 : H12AffineFastState.Bounded env18881 := by
  intro p hp
  have h : env18881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18880_18881 : H12AffineEnvironment.transform 8 0 env18880 = env18881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18880 == env18881) = true)

theorem identity18881 : scanCanonicalize (H12AffineFastState.compose env18881 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18881 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env18882 : List Nat := [2,4,8,16,1,16,9,4,0,4,17,1,9,0,1,3,16,17,5,0,16,1,17,3,8,17,17,17,0,16,4,0,5,0,1,1]

theorem envBound18882 : H12AffineFastState.Bounded env18882 := by
  intro p hp
  have h : env18882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18881_18882 : H12AffineEnvironment.transform 7 4 env18881 = env18882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18881 == env18882) = true)

theorem identity18882 : scanCanonicalize (H12AffineFastState.compose env18882 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18883 : List Nat := [2,4,8,1,1,1,9,4,0,4,0,1,9,0,1,3,1,0,5,0,1,1,0,3,8,0,0,0,0,1,4,0,5,0,1,1]

theorem envBound18883 : H12AffineFastState.Bounded env18883 := by
  intro p hp
  have h : env18883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18882_18883 : H12AffineEnvironment.transform 3 1 env18882 = env18883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18882 == env18883) = true)

def env18884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98781,8328,65,12729469,79130,8480026,8568224,8390093,4314198,257,8484155,8492190,8462875]

theorem envBound18884 : H12AffineFastState.Bounded env18884 := by
  intro p hp
  have h : env18884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18826_18884 : H12AffineEnvironment.transform 17 32161 env18826 = env18884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env18826 == env18884) = true)

def env18885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98781,8328,65,8546653,79130,8480026,8568224,8390093,98678,257,8484155,8492190,8462875]

theorem envBound18885 : H12AffineFastState.Bounded env18885 := by
  intro p hp
  have h : env18885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18884_18885 : H12AffineEnvironment.transform 21 21792 env18884 = env18885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env18884 == env18885) = true)

theorem identity18885 : scanCanonicalize (H12AffineFastState.compose env18885 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18885 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32161,1025,29908,77898,21792,8388608,95496,8328,65,8546653,79130,8480026,8538485,8390093,95651,257,8484155,8478795,8462875]

theorem envBound18886 : H12AffineFastState.Bounded env18886 := by
  intro p hp
  have h : env18886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18885_18886 : H12AffineEnvironment.transform 14 29909 env18885 = env18886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18885 == env18886) = true)

def env18887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1025,8660,77898,32,8388608,73736,8328,65,8535133,79130,8466458,8526965,8390093,73891,257,8462395,8467787,8462875]

theorem envBound18887 : H12AffineFastState.Bounded env18887 := by
  intro p hp
  have h : env18887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18886_18887 : H12AffineEnvironment.transform 13 5376 env18886 = env18887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18886 == env18887) = true)

theorem identity18887 : scanCanonicalize (H12AffineFastState.compose env18887 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound18887 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1025,8660,77898,32,73875,73736,8328,65,203982,79130,4233,212198,75102,73891,257,168,5592,648]

theorem envBound18888 : H12AffineFastState.Bounded env18888 := by
  intro p hp
  have h : env18888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18887_18888 : H12AffineEnvironment.transform 22 73875 env18887 = env18888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env18887 == env18888) = true)

theorem identity18888 : scanCanonicalize (H12AffineFastState.compose env18888 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18888 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env18889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,65536,131072,2421,1025,0,70046,32,65863,66012,348,65,203982,70862,4233,204082,66698,65911,257,168,5592,648]

theorem envBound18889 : H12AffineFastState.Bounded env18889 := by
  intro p hp
  have h : env18889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18888_18889 : H12AffineEnvironment.transform 12 468 env18888 = env18889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18888 == env18889) = true)

theorem identity18889 : scanCanonicalize (H12AffineFastState.compose env18889 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound18889 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env18890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,65536,70862,2421,1025,0,70046,32,65863,66012,348,65,2048,70862,4233,2556,66698,65911,257,168,5592,648]

theorem envBound18890 : H12AffineFastState.Bounded env18890 := by
  intro p hp
  have h : env18890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18889_18890 : H12AffineEnvironment.transform 16 70862 env18889 = env18890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env18889 == env18890) = true)

theorem identity18890 : scanCanonicalize (H12AffineFastState.compose env18890 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18890 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,65536,70727,2421,1025,0,69911,32,65863,65877,348,65,2048,70727,4096,2421,66563,65911,257,33,5457,513]

theorem envBound18891 : H12AffineFastState.Bounded env18891 := by
  intro p hp
  have h : env18891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18890_18891 : H12AffineEnvironment.transform 6 9 env18890 = env18891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18890 == env18891) = true)

theorem identity18891 : scanCanonicalize (H12AffineFastState.compose env18891 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound18891 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5393,2421,1025,0,4161,32,17,3,348,65,2048,5393,4096,2421,1365,33,257,33,5457,513]

theorem envBound18892 : H12AffineFastState.Bounded env18892 := by
  intro p hp
  have h : env18892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18891_18892 : H12AffineEnvironment.transform 15 342 env18891 = env18892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env18891 == env18892) = true)

theorem identity18892 : scanCanonicalize (H12AffineFastState.compose env18892 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound18892 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18893 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,4096,349,4624,1,342,4609,2421,785,0,4161,32,17,3,348,65,2048,4609,4096,2421,581,33,257,33,4673,513]

theorem envBound18893 : H12AffineFastState.Bounded env18893 := by
  intro p hp
  have h : env18893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18892_18893 : H12AffineEnvironment.transform 9 784 env18892 = env18893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env18892 == env18893) = true)

theorem identity18893 : scanCanonicalize (H12AffineFastState.compose env18893 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 884) := by decide +kernel

theorem selectedBound18893 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18894 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,884,349,356,1,342,373,2421,785,0,821,32,17,3,348,65,2048,373,884,2421,581,33,257,33,309,513]

theorem envBound18894 : H12AffineFastState.Bounded env18894 := by
  intro p hp
  have h : env18894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18893_18894 : H12AffineEnvironment.transform 11 884 env18893 = env18894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 884 env18893 == env18894) = true)

theorem identity18894 : scanCanonicalize (H12AffineFastState.compose env18894 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18894 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18895 : List Nat := [2,4,8,16,32,64,9,116,512,612,2048,512,41,16,1,34,1,2049,613,0,577,32,17,3,40,65,2048,1,512,2049,581,33,117,33,65,513]

theorem envBound18895 : H12AffineFastState.Bounded env18895 := by
  intro p hp
  have h : env18895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18894_18895 : H12AffineEnvironment.transform 7 116 env18894 = env18895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18894 == env18895) = true)

theorem identity18895 : scanCanonicalize (H12AffineFastState.compose env18895 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound18895 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18896 : List Nat := [2,4,8,16,32,64,9,116,512,612,81,512,41,16,1,34,1,80,613,0,577,32,17,3,40,65,81,1,512,80,581,33,117,33,65,513]

theorem envBound18896 : H12AffineFastState.Bounded env18896 := by
  intro p hp
  have h : env18896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18895_18896 : H12AffineEnvironment.transform 10 81 env18895 = env18896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env18895 == env18896) = true)

theorem identity18896 : scanCanonicalize (H12AffineFastState.compose env18896 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound18896 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18897 : List Nat := [2,4,8,16,32,64,9,116,81,53,81,81,41,16,1,34,1,80,52,0,16,32,17,3,40,65,81,1,81,80,20,33,117,33,65,80]

theorem envBound18897 : H12AffineFastState.Bounded env18897 := by
  intro p hp
  have h : env18897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18896_18897 : H12AffineEnvironment.transform 8 81 env18896 = env18897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env18896 == env18897) = true)

theorem identity18897 : scanCanonicalize (H12AffineFastState.compose env18897 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18898 : List Nat := [2,4,8,1,32,64,9,101,64,36,64,64,41,1,1,34,1,65,37,0,1,32,0,3,40,65,64,1,64,65,5,33,100,33,65,65]

theorem envBound18898 : H12AffineFastState.Bounded env18898 := by
  intro p hp
  have h : env18898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18897_18898 : H12AffineEnvironment.transform 3 1 env18897 = env18898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18897 == env18898) = true)

theorem identity18898 : scanCanonicalize (H12AffineFastState.compose env18898 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound18898 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18899 : List Nat := [2,4,8,1,32,0,9,37,0,36,0,0,41,1,1,34,1,1,37,0,1,32,0,3,40,1,0,1,0,1,5,33,36,33,1,1]

theorem envBound18899 : H12AffineFastState.Bounded env18899 := by
  intro p hp
  have h : env18899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18898_18899 : H12AffineEnvironment.transform 5 0 env18898 = env18899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env18898 == env18899) = true)

theorem identity18899 : scanCanonicalize (H12AffineFastState.compose env18899 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18900 : List Nat := [2,4,3,1,32,0,2,37,0,36,0,0,34,1,1,34,1,1,37,0,1,32,0,3,35,1,0,1,0,1,5,33,36,33,1,1]

theorem envBound18900 : H12AffineFastState.Bounded env18900 := by
  intro p hp
  have h : env18900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18899_18900 : H12AffineEnvironment.transform 2 3 env18899 = env18900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18899 == env18900) = true)

def env18901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1025,8661,77898,33,8388608,73737,8328,65,8535132,79130,8466459,8526964,8390093,73890,257,8462394,8467786,8462875]

theorem envBound18901 : H12AffineFastState.Bounded env18901 := by
  intro p hp
  have h : env18901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18886_18901 : H12AffineEnvironment.transform 13 5377 env18886 = env18901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18886 == env18901) = true)

theorem identity18901 : scanCanonicalize (H12AffineFastState.compose env18901 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18901 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,131072,10400,1025,8661,4161,33,8388608,2,8328,65,8535132,5393,8392720,8526964,8390093,169,257,8388657,8394049,8389136]

theorem envBound18902 : H12AffineFastState.Bounded env18902 := by
  intro p hp
  have h : env18902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18901_18902 : H12AffineEnvironment.transform 15 8203 env18901 = env18902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18901 == env18902) = true)

theorem identity18902 : scanCanonicalize (H12AffineFastState.compose env18902 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(22+1) ^^^ 136449) := by decide +kernel

theorem selectedBound18902 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env18903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,131072,10400,1025,8661,4161,33,136449,2,8328,65,10589,5393,132369,2421,135372,169,257,136496,131136,136977]

theorem envBound18903 : H12AffineFastState.Bounded env18903 := by
  intro p hp
  have h : env18903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18902_18903 : H12AffineEnvironment.transform 22 136449 env18902 = env18903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env18902 == env18903) = true)

theorem identity18903 : scanCanonicalize (H12AffineFastState.compose env18903 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound18903 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18904 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5373,8232,8203,131072,10400,1025,8233,4161,33,136445,2,8328,65,10401,5357,132333,2185,135372,169,253,136396,131136,136941]

theorem envBound18904 : H12AffineFastState.Bounded env18904 := by
  intro p hp
  have h : env18904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18903_18904 : H12AffineEnvironment.transform 7 252 env18903 = env18904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env18903 == env18904) = true)

theorem identity18904 : scanCanonicalize (H12AffineFastState.compose env18904 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18904 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18905 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8232,8203,131072,10280,1025,8233,4161,33,136309,2,8192,65,10281,5221,132197,2049,135236,33,117,136260,131136,136805]

theorem envBound18905 : H12AffineFastState.Bounded env18905 := by
  intro p hp
  have h : env18905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18904_18905 : H12AffineEnvironment.transform 6 8 env18904 = env18905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18904 == env18905) = true)

theorem identity18905 : scanCanonicalize (H12AffineFastState.compose env18905 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound18905 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18906 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,1,34,131072,2049,1025,0,4161,33,136309,2,41,65,2048,5221,132197,2049,135236,33,117,136260,131136,136805]

theorem envBound18906 : H12AffineFastState.Bounded env18906 := by
  intro p hp
  have h : env18906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18905_18906 : H12AffineEnvironment.transform 12 41 env18905 = env18906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18905 == env18906) = true)

theorem identity18906 : scanCanonicalize (H12AffineFastState.compose env18906 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(16+1) ^^^ 6224) := by decide +kernel

theorem selectedBound18906 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env18907 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,1,34,6224,2049,1025,0,4161,33,3109,2,41,65,2048,5221,7221,2049,2068,33,117,3092,6160,3637]

theorem envBound18907 : H12AffineFastState.Bounded env18907 := by
  intro p hp
  have h : env18907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18906_18907 : H12AffineEnvironment.transform 16 6224 env18906 = env18907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6224 env18906 == env18907) = true)

theorem identity18907 : scanCanonicalize (H12AffineFastState.compose env18907 (packedSelected [0,1,2,3,5,6,7,8,20] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound18907 : packedSelected [0,1,2,3,5,6,7,8,20] rootPS < 2^1333 := by decide +kernel

def env18908 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1077,4096,41,5237,1,34,5221,1076,1025,0,4161,33,16,2,41,65,1077,5221,4096,1076,1057,33,117,33,5157,512]

theorem envBound18908 : H12AffineFastState.Bounded env18908 := by
  intro p hp
  have h : env18908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18907_18908 : H12AffineEnvironment.transform 10 1077 env18907 = env18908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env18907 == env18908) = true)

theorem identity18908 : scanCanonicalize (H12AffineFastState.compose env18908 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound18908 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18909 : List Nat := [2,4,8,16,32,48,8,4,512,1024,1077,4096,41,5125,1,34,5141,1076,1025,0,4145,33,16,2,41,49,1077,5141,4096,1076,1057,33,5,33,5157,512]

theorem envBound18909 : H12AffineFastState.Bounded env18909 := by
  intro p hp
  have h : env18909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18908_18909 : H12AffineEnvironment.transform 5 48 env18908 = env18909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env18908 == env18909) = true)

theorem identity18909 : scanCanonicalize (H12AffineFastState.compose env18909 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18909 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env18910 : List Nat := [2,4,8,16,32,48,8,4,512,21,32,4096,41,4112,1,34,4096,33,20,0,4145,33,16,2,41,49,32,4096,4096,33,52,33,5,33,4144,512]

theorem envBound18910 : H12AffineFastState.Bounded env18910 := by
  intro p hp
  have h : env18910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18909_18910 : H12AffineEnvironment.transform 9 21 env18909 = env18910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18909 == env18910) = true)

theorem identity18910 : scanCanonicalize (H12AffineFastState.compose env18910 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound18910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18911 : List Nat := [2,4,8,16,32,48,8,4,30,21,32,4096,41,4112,1,34,4096,33,20,0,4145,33,16,2,41,49,32,4096,4096,33,52,33,5,33,4144,30]

theorem envBound18911 : H12AffineFastState.Bounded env18911 := by
  intro p hp
  have h : env18911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18910_18911 : H12AffineEnvironment.transform 8 30 env18910 = env18911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env18910 == env18911) = true)

theorem identity18911 : scanCanonicalize (H12AffineFastState.compose env18911 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound18911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18912 : List Nat := [2,4,8,16,32,48,8,4,30,21,32,49,41,33,1,34,49,33,20,0,0,33,16,2,41,49,32,49,49,33,52,33,5,33,1,30]

theorem envBound18912 : H12AffineFastState.Bounded env18912 := by
  intro p hp
  have h : env18912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18911_18912 : H12AffineEnvironment.transform 11 49 env18911 = env18912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env18911 == env18912) = true)

theorem identity18912 : scanCanonicalize (H12AffineFastState.compose env18912 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound18912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18913 : List Nat := [2,4,8,16,30,14,8,4,30,21,30,15,23,31,1,28,15,31,20,0,0,31,16,2,23,15,30,15,15,31,10,31,5,31,1,30]

theorem envBound18913 : H12AffineFastState.Bounded env18913 := by
  intro p hp
  have h : env18913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18912_18913 : H12AffineEnvironment.transform 4 30 env18912 = env18913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env18912 == env18913) = true)

end H12CloudChart0