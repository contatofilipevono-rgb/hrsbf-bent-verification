import H12CloudChart0Data057

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans14567_14568 : H12AffineEnvironment.transform 20 290104 env14567 = env14568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290104 env14567 == env14568) = true)

theorem identity14568 : scanCanonicalize (H12AffineFastState.compose env14568 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound14568 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env14569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,290104,272393,41293,297335,8193,65,303145,16448,301348,270685,298017,297221,257,41260,16385,297845]

theorem envBound14569 : H12AffineFastState.Bounded env14569 := by
  intro p hp
  have h : env14569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14568_14569 : H12AffineEnvironment.transform 21 272393 env14568 = env14569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env14568 == env14569) = true)

theorem identity14569 : scanCanonicalize (H12AffineFastState.compose env14569 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14569 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env14570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,262144,1025,8541,290104,272393,17,272427,8193,65,262517,16448,276600,270685,273789,272473,257,112,16385,272937]

theorem envBound14570 : H12AffineFastState.Bounded env14570 := by
  intro p hp
  have h : env14570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14569_14570 : H12AffineEnvironment.transform 14 8540 env14569 = env14570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14569 == env14570) = true)

theorem identity14570 : scanCanonicalize (H12AffineFastState.compose env14570 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound14570 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env14571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10360,1025,8541,17728,113,17,83,8193,65,10509,16448,4096,2341,1285,33,257,112,16385,593]

theorem envBound14571 : H12AffineFastState.Bounded env14571 := by
  intro p hp
  have h : env14571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14570_14571 : H12AffineEnvironment.transform 17 10360 env14570 = env14571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env14570 == env14571) = true)

theorem identity14571 : scanCanonicalize (H12AffineFastState.compose env14571 (packedSelected [2,3,4,5,9,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound14571 : packedSelected [2,3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env14572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8540,8203,5221,10360,1025,8541,4405,113,17,83,8193,65,10509,5173,4096,2341,1285,33,257,112,5236,593]

theorem envBound14572 : H12AffineFastState.Bounded env14572 := by
  intro p hp
  have h : env14572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14571_14572 : H12AffineEnvironment.transform 13 5237 env14571 = env14572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env14571 == env14572) = true)

theorem identity14572 : scanCanonicalize (H12AffineFastState.compose env14572 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14572 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env14573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,0,343,5221,2340,1025,1,4405,113,17,83,349,65,2129,5173,4096,2341,1285,33,257,112,5236,593]

theorem envBound14573 : H12AffineFastState.Bounded env14573 := by
  intro p hp
  have h : env14573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14572_14573 : H12AffineEnvironment.transform 12 348 env14572 = env14573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14572 == env14573) = true)

theorem identity14573 : scanCanonicalize (H12AffineFastState.compose env14573 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14573 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env14574 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,348,4161,0,343,4177,2340,53,1,4405,113,17,83,349,65,2129,4097,4096,2341,305,33,257,112,4160,593]

theorem envBound14574 : H12AffineFastState.Bounded env14574 := by
  intro p hp
  have h : env14574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14573_14574 : H12AffineEnvironment.transform 9 52 env14573 = env14574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14573 == env14574) = true)

theorem identity14574 : scanCanonicalize (H12AffineFastState.compose env14574 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound14574 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env14575 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2064,348,2129,0,343,2113,2340,53,1,2341,113,17,83,349,65,2129,2065,2064,2341,305,33,257,112,2128,593]

theorem envBound14575 : H12AffineFastState.Bounded env14575 := by
  intro p hp
  have h : env14575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14574_14575 : H12AffineEnvironment.transform 11 2064 env14574 = env14575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env14574 == env14575) = true)

theorem identity14575 : scanCanonicalize (H12AffineFastState.compose env14575 (packedSelected [0,2,3,5,7,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14575 : packedSelected [0,2,3,5,7,17] rootPS < 2^1333 := by decide +kernel

def env14576 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2064,268,2049,0,263,2065,2340,53,1,2341,33,17,3,269,17,2049,2065,2064,2341,305,33,257,32,2048,513]

theorem envBound14576 : H12AffineFastState.Bounded env14576 := by
  intro p hp
  have h : env14576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14575_14576 : H12AffineEnvironment.transform 5 16 env14575 = env14576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14575 == env14576) = true)

theorem identity14576 : scanCanonicalize (H12AffineFastState.compose env14576 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound14576 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14577 : List Nat := [2,4,8,16,32,16,9,256,512,52,303,319,268,302,0,263,318,11,53,1,10,33,17,3,269,17,302,318,319,10,305,33,257,32,303,513]

theorem envBound14577 : H12AffineFastState.Bounded env14577 := by
  intro p hp
  have h : env14577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14576_14577 : H12AffineEnvironment.transform 10 303 env14576 = env14577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env14576 == env14577) = true)

def env14578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650855,2428275,10507601,8683537,8719719,6679615,257,10833234,10857599,8661560]

theorem envBound14578 : H12AffineFastState.Bounded env14578 := by
  intro p hp
  have h : env14578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14564_14578 : H12AffineEnvironment.transform 16 16401 env14564 = env14578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14564 == env14578) = true)

theorem identity14578 : scanCanonicalize (H12AffineFastState.compose env14578 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound14578 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env14579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,8388608,3,8193,65,12650855,2196487,10507601,8391013,8487955,6382923,257,10601510,10560779,8430412]

theorem envBound14579 : H12AffineFastState.Bounded env14579 := by
  intro p hp
  have h : env14579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14578_14579 : H12AffineEnvironment.transform 17 35188 env14578 = env14579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env14578 == env14579) = true)

theorem identity14579 : scanCanonicalize (H12AffineFastState.compose env14579 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 98631) := by decide +kernel

theorem selectedBound14579 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,98631,3,8193,65,4229152,2196487,2216982,100386,1364,6382923,257,2114913,2139212,74251]

theorem envBound14580 : H12AffineFastState.Bounded env14580 := by
  intro p hp
  have h : env14580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14579_14580 : H12AffineEnvironment.transform 22 98631 env14579 = env14580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98631 env14579 == env14580) = true)

theorem identity14580 : scanCanonicalize (H12AffineFastState.compose env14580 (packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound14580 : packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS < 2^1333 := by decide +kernel

def env14581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,73771,98631,3,8193,65,108555,2196487,2216982,100386,1364,2114912,257,2114913,2139212,74251]

theorem envBound14581 : H12AffineFastState.Bounded env14581 := by
  intro p hp
  have h : env14581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14580_14581 : H12AffineEnvironment.transform 21 73771 env14580 = env14581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env14580 == env14581) = true)

theorem identity14581 : scanCanonicalize (H12AffineFastState.compose env14581 (packedSelected [18,23] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound14581 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,25677,73771,98631,3,8193,65,108555,122954,110683,100386,1364,8493,257,8492,49153,74251]

theorem envBound14582 : H12AffineFastState.Bounded env14582 := by
  intro p hp
  have h : env14582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14581_14582 : H12AffineEnvironment.transform 20 25677 env14581 = env14582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env14581 == env14582) = true)

theorem identity14582 : scanCanonicalize (H12AffineFastState.compose env14582 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14582 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env14583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,25677,41341,17,3,8193,65,10589,24860,12557,2420,1364,8493,257,8492,49153,41821]

theorem envBound14583 : H12AffineFastState.Bounded env14583 := by
  intro p hp
  have h : env14583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14582_14583 : H12AffineEnvironment.transform 15 33110 env14582 = env14583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14582 == env14583) = true)

theorem identity14583 : scanCanonicalize (H12AffineFastState.compose env14583 (packedSelected [1,2,3,7,9,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14583 : packedSelected [1,2,3,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env14584 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8192,16384,32768,32851,16401,34929,1025,32769,25677,41080,17,3,8193,65,10328,24601,12296,2161,1105,8232,4,8233,49153,41560]

theorem envBound14584 : H12AffineFastState.Bounded env14584 := by
  intro p hp
  have h : env14584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14583_14584 : H12AffineEnvironment.transform 7 5 env14583 = env14584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14583 == env14584) = true)

theorem identity14584 : scanCanonicalize (H12AffineFastState.compose env14584 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound14584 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14585 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8192,16384,80,3,16401,2081,1025,81,25677,8232,17,3,8193,65,10328,24601,12296,2161,1105,8232,4,8233,16465,8712]

theorem envBound14585 : H12AffineFastState.Bounded env14585 := by
  intro p hp
  have h : env14585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14584_14585 : H12AffineEnvironment.transform 14 80 env14584 = env14585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env14584 == env14585) = true)

theorem identity14585 : scanCanonicalize (H12AffineFastState.compose env14585 (packedSelected [1,2,3,4,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound14585 : packedSelected [1,2,3,4,7,10,16] rootPS < 2^1333 := by decide +kernel

def env14586 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8,16384,80,3,16401,2081,1025,81,17477,32,17,3,9,65,2128,16401,4096,2161,1105,32,4,33,16465,512]

theorem envBound14586 : H12AffineFastState.Bounded env14586 := by
  intro p hp
  have h : env14586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14585_14586 : H12AffineEnvironment.transform 12 8 env14585 = env14586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env14585 == env14586) = true)

theorem identity14586 : scanCanonicalize (H12AffineFastState.compose env14586 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound14586 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14587 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8,16384,32,3,16401,2081,1025,33,17461,32,17,3,9,49,2080,16401,4096,2049,1057,32,4,33,16417,512]

theorem envBound14587 : H12AffineFastState.Bounded env14587 := by
  intro p hp
  have h : env14587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14586_14587 : H12AffineEnvironment.transform 5 48 env14586 = env14587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env14586 == env14587) = true)

theorem identity14587 : scanCanonicalize (H12AffineFastState.compose env14587 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound14587 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14588 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8,5124,32,3,5141,2081,1025,33,4145,32,17,3,9,49,2080,5141,4096,2049,1057,32,4,33,5157,512]

theorem envBound14588 : H12AffineFastState.Bounded env14588 := by
  intro p hp
  have h : env14588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14587_14588 : H12AffineEnvironment.transform 13 5124 env14587 = env14588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env14587 == env14588) = true)

theorem identity14588 : scanCanonicalize (H12AffineFastState.compose env14588 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14588 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env14589 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,1,3,5141,2048,1025,0,4112,1,17,3,9,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound14589 : H12AffineFastState.Bounded env14589 := by
  intro p hp
  have h : env14589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14588_14589 : H12AffineEnvironment.transform 4 1 env14588 = env14589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14588 == env14589) = true)

def env14590 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1044,1,3,1029,2048,1025,0,0,1,17,3,9,16,2049,1029,16,2049,1024,1,4,0,1044,512]

theorem envBound14590 : H12AffineFastState.Bounded env14590 := by
  intro p hp
  have h : env14590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14589_14590 : H12AffineEnvironment.transform 11 16 env14589 = env14590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14589 == env14590) = true)

def env14591 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,8,0,1,3,17,2048,21,0,0,1,17,3,9,16,2049,17,16,2049,20,1,4,0,0,512]

theorem envBound14591 : H12AffineFastState.Bounded env14591 := by
  intro p hp
  have h : env14591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14590_14591 : H12AffineEnvironment.transform 9 20 env14590 = env14591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14590 == env14591) = true)

theorem identity14591 : scanCanonicalize (H12AffineFastState.compose env14591 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound14591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14592 : List Nat := [2,4,8,16,1,17,9,5,512,20,543,16,8,0,1,3,17,543,21,0,0,1,17,3,9,16,542,17,16,542,20,1,4,0,0,512]

theorem envBound14592 : H12AffineFastState.Bounded env14592 := by
  intro p hp
  have h : env14592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14591_14592 : H12AffineEnvironment.transform 10 543 env14591 = env14592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env14591 == env14592) = true)

def leafEnv14592 : List Nat := [2,4,8,16,1,17,9,5,512,20,543,16,8,0,1,3,17,543,21,0,0,1,17,3,21,9,1,16,542,17,16,542,20,1,4,0,5,2,0,512,1,0,0]

def active14592 : List Nat := [0,1,2,3,8]

def tree14592 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14592 : H12WitnessSearch.Good tree14592 := H12GlobalWitnessIndex.good

theorem leafIdentity14592 : H12AffineFastState.composeSystem env14592 rootObs = leafEnv14592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14592 rootObs == leafEnv14592) = true)

theorem terminalChecked14592 : H12PackedTerminal.terminalCheckFast leafEnv14592 active14592 tree14592 = true := by decide +kernel

def env14593 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,1,1,3,16,2048,20,0,0,1,17,3,9,16,2049,16,16,2049,21,1,4,0,1,512]

theorem envBound14593 : H12AffineFastState.Bounded env14593 := by
  intro p hp
  have h : env14593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14590_14593 : H12AffineEnvironment.transform 9 21 env14590 = env14593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14590 == env14593) = true)

theorem identity14593 : scanCanonicalize (H12AffineFastState.compose env14593 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound14593 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14594 : List Nat := [2,4,8,16,1,17,9,5,512,21,20,16,8,1,1,3,16,20,20,0,0,1,17,3,9,16,21,16,16,21,21,1,4,0,1,512]

theorem envBound14594 : H12AffineFastState.Bounded env14594 := by
  intro p hp
  have h : env14594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14593_14594 : H12AffineEnvironment.transform 10 20 env14593 = env14594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env14593 == env14594) = true)

def leafEnv14594 : List Nat := [2,4,8,16,1,17,9,5,512,21,20,16,8,1,1,3,16,20,20,0,0,1,17,3,20,9,1,16,21,16,16,21,21,1,4,0,5,2,1,512,1,0,0]

def active14594 : List Nat := [0,1,2,3,8]

def tree14594 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14594 : H12WitnessSearch.Good tree14594 := H12GlobalWitnessIndex.good

theorem leafIdentity14594 : H12AffineFastState.composeSystem env14594 rootObs = leafEnv14594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14594 rootObs == leafEnv14594) = true)

theorem terminalChecked14594 : H12PackedTerminal.terminalCheckFast leafEnv14594 active14594 tree14594 = true := by decide +kernel

def env14595 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1045,1,3,1028,2048,1025,0,1,1,17,3,9,16,2049,1028,17,2049,1024,1,4,0,1045,512]

theorem envBound14595 : H12AffineFastState.Bounded env14595 := by
  intro p hp
  have h : env14595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14589_14595 : H12AffineEnvironment.transform 11 17 env14589 = env14595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14589 == env14595) = true)

theorem identity14595 : scanCanonicalize (H12AffineFastState.compose env14595 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound14595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14596 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,8,0,1,3,17,2048,20,0,1,1,17,3,9,16,2049,17,17,2049,21,1,4,0,0,512]

theorem envBound14596 : H12AffineFastState.Bounded env14596 := by
  intro p hp
  have h : env14596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14595_14596 : H12AffineEnvironment.transform 9 21 env14595 = env14596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14595 == env14596) = true)

theorem identity14596 : scanCanonicalize (H12AffineFastState.compose env14596 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound14596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14597 : List Nat := [2,4,8,16,1,17,9,5,512,21,21,17,8,0,1,3,17,21,20,0,1,1,17,3,9,16,20,17,17,20,21,1,4,0,0,512]

theorem envBound14597 : H12AffineFastState.Bounded env14597 := by
  intro p hp
  have h : env14597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14596_14597 : H12AffineEnvironment.transform 10 21 env14596 = env14597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env14596 == env14597) = true)

def leafEnv14597 : List Nat := [2,4,8,16,1,17,9,5,512,21,21,17,8,0,1,3,17,21,20,0,1,1,17,3,20,9,1,16,20,17,17,20,21,1,4,0,5,2,0,512,1,1,0]

def active14597 : List Nat := [0,1,2,3,8]

def tree14597 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14597 : H12WitnessSearch.Good tree14597 := H12GlobalWitnessIndex.good

theorem leafIdentity14597 : H12AffineFastState.composeSystem env14597 rootObs = leafEnv14597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14597 rootObs == leafEnv14597) = true)

theorem terminalChecked14597 : H12PackedTerminal.terminalCheckFast leafEnv14597 active14597 tree14597 = true := by decide +kernel

def env14598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound14598 : H12AffineFastState.Bounded env14598 := by
  intro p hp
  have h : env14598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14384_14598 : H12AffineEnvironment.transform 26 30393345 env14384 = env14598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env14384 == env14598) = true)

def env14599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound14599 : H12AffineFastState.Bounded env14599 := by
  intro p hp
  have h : env14599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14598_14599 : H12AffineEnvironment.transform 18 1024 env14598 = env14599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14598 == env14599) = true)

theorem identity14599 : scanCanonicalize (H12AffineFastState.compose env14599 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882102) := by decide +kernel

theorem selectedBound14599 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882102,8328,65,6409271,8882362,10507601,8830976,2590758,13068790,256,510106,469310,2535409]

theorem envBound14600 : H12AffineFastState.Bounded env14600 := by
  intro p hp
  have h : env14600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14599_14600 : H12AffineEnvironment.transform 23 10882102 env14599 = env14600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882102 env14599 == env14600) = true)

def env14601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412020,2114882,8328,65,6409271,115150,2497573,35188,2590758,4268162,256,510106,469310,2535409]

theorem envBound14601 : H12AffineFastState.Bounded env14601 := by
  intro p hp
  have h : env14601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14600_14601 : H12AffineEnvironment.transform 22 412020 env14600 = env14601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412020 env14600 == env14601) = true)

def env14602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412020,2114882,8328,65,215367,115150,2497573,35188,2590758,2336242,256,510106,469310,2535409]

theorem envBound14602 : H12AffineFastState.Bounded env14602 := by
  intro p hp
  have h : env14602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14601_14602 : H12AffineEnvironment.transform 21 2262384 env14601 = env14602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env14601 == env14602) = true)

def env14603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,21762,8328,65,215367,115150,396389,35188,497766,243122,256,510106,469310,442289]

theorem envBound14603 : H12AffineFastState.Bounded env14603 := by
  intro p hp
  have h : env14603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14602_14603 : H12AffineEnvironment.transform 20 4160 env14602 = env14603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14602 == env14603) = true)

theorem identity14603 : scanCanonicalize (H12AffineFastState.compose env14603 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound14603 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,169264,412020,21762,8328,65,171417,5392,396389,35188,412856,156012,256,400452,458208,442289]

theorem envBound14604 : H12AffineFastState.Bounded env14604 := by
  intro p hp
  have h : env14604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14603_14604 : H12AffineEnvironment.transform 15 54494 env14603 = env14604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env14603 == env14604) = true)

def env14605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4112,169264,411940,21762,8328,17,171417,5392,396341,35108,412856,155964,256,400404,458160,442289]

theorem envBound14605 : H12AffineFastState.Bounded env14605 := by
  intro p hp
  have h : env14605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14604_14605 : H12AffineEnvironment.transform 5 16 env14604 = env14605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14604 == env14605) = true)

theorem identity14605 : scanCanonicalize (H12AffineFastState.compose env14605 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound14605 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env14606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,57629,262144,1024,32769,4112,29741,305209,21762,8328,17,31876,5392,322856,35108,306597,32801,256,326921,269485,286380]

theorem envBound14606 : H12AffineFastState.Bounded env14606 := by
  intro p hp
  have h : env14606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14605_14606 : H12AffineEnvironment.transform 16 57629 env14605 = env14606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env14605 == env14606) = true)

theorem identity14606 : scanCanonicalize (H12AffineFastState.compose env14606 (packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound14606 : packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env14607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,57629,2341,1024,32769,4112,29741,41244,21762,8328,17,31876,5392,58381,35108,42112,32801,256,62508,5512,22409]

theorem envBound14607 : H12AffineFastState.Bounded env14607 := by
  intro p hp
  have h : env14607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14606_14607 : H12AffineEnvironment.transform 17 2341 env14606 = env14607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env14606 == env14607) = true)

theorem identity14607 : scanCanonicalize (H12AffineFastState.compose env14607 (packedSelected [0,1,3,5,8,9,10,16,17,19,20,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14607 : packedSelected [0,1,3,5,8,9,10,16,17,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env14608 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,57629,2341,1024,32769,4112,29741,41244,21762,8192,17,31756,5392,58381,35108,41992,32801,256,62508,5376,22273]

theorem envBound14608 : H12AffineFastState.Bounded env14608 := by
  intro p hp
  have h : env14608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14607_14608 : H12AffineEnvironment.transform 6 8 env14607 = env14608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14607 == env14608) = true)

def env14609 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4113,169264,411941,21762,8328,16,171417,5392,396340,35109,412856,155965,256,400405,458161,442289]

theorem envBound14609 : H12AffineFastState.Bounded env14609 := by
  intro p hp
  have h : env14609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14604_14609 : H12AffineEnvironment.transform 5 17 env14604 = env14609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14604 == env14609) = true)

theorem identity14609 : scanCanonicalize (H12AffineFastState.compose env14609 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 43169) := by decide +kernel

theorem selectedBound14609 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env14610 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,43169,1024,32769,4113,169264,188804,21762,8328,16,171417,5392,173205,35109,189465,155965,256,177332,152848,136976]

theorem envBound14610 : H12AffineFastState.Bounded env14610 := by
  intro p hp
  have h : env14610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14609_14610 : H12AffineEnvironment.transform 17 43169 env14609 = env14610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43169 env14609 == env14610) = true)

theorem identity14610 : scanCanonicalize (H12AffineFastState.compose env14610 (packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound14610 : packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env14611 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,57628,43169,1024,32769,4113,29740,152,21762,8328,16,31877,5392,17801,35109,1285,32801,256,21928,46092,62988]

theorem envBound14611 : H12AffineFastState.Bounded env14611 := by
  intro p hp
  have h : env14611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14610_14611 : H12AffineEnvironment.transform 16 57628 env14610 = env14611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env14610 == env14611) = true)

theorem identity14611 : scanCanonicalize (H12AffineFastState.compose env14611 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound14611 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env14612 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8322,5393,23724,1024,29708,4113,29740,152,21762,8328,16,31877,5392,17801,32040,1285,29740,256,21928,16385,513]

theorem envBound14612 : H12AffineFastState.Bounded env14612 := by
  intro p hp
  have h : env14612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14611_14612 : H12AffineEnvironment.transform 14 29709 env14611 = env14612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env14611 == env14612) = true)

theorem identity14612 : scanCanonicalize (H12AffineFastState.compose env14612 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14612 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env14613 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,1,8322,5393,10400,1024,0,4113,32,152,8462,8328,16,2185,5392,12677,2340,1285,32,256,8612,13325,513]

theorem envBound14613 : H12AffineFastState.Bounded env14613 := by
  intro p hp
  have h : env14613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14612_14613 : H12AffineEnvironment.transform 13 13324 env14612 = env14613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14612 == env14613) = true)

theorem identity14613 : scanCanonicalize (H12AffineFastState.compose env14613 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14613 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14614 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,12572,1,8322,4097,10400,272,0,4113,32,152,8462,8328,16,2185,4096,12677,2340,21,32,256,8612,12573,513]

theorem envBound14614 : H12AffineFastState.Bounded env14614 := by
  intro p hp
  have h : env14614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14613_14614 : H12AffineEnvironment.transform 9 272 env14613 = env14614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14613 == env14614) = true)

def env14615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,21763,8328,65,215367,115150,396388,35188,497767,243123,256,510106,469310,442288]

theorem envBound14615 : H12AffineFastState.Bounded env14615 := by
  intro p hp
  have h : env14615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14602_14615 : H12AffineEnvironment.transform 20 4161 env14602 = env14615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14602 == env14615) = true)

theorem identity14615 : scanCanonicalize (H12AffineFastState.compose env14615 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound14615 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169265,73754,21763,8328,65,215367,115150,91402,35188,61705,243123,256,41460,16464,120542]

theorem envBound14616 : H12AffineFastState.Bounded env14616 := by
  intro p hp
  have h : env14616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14615_14616 : H12AffineEnvironment.transform 17 223598 env14615 = env14616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env14615 == env14616) = true)

def env14617 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4113,169265,73754,21763,8328,17,215319,115102,91402,35108,61705,243123,256,41380,16384,120462]

theorem envBound14617 : H12AffineFastState.Bounded env14617 := by
  intro p hp
  have h : env14617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14616_14617 : H12AffineEnvironment.transform 5 16 env14616 = env14617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14616 == env14617) = true)

theorem identity14617 : scanCanonicalize (H12AffineFastState.compose env14617 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound14617 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14618 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,79130,23588,1024,32769,4113,106539,73754,21763,8328,17,31757,115102,91402,35108,61705,32937,256,41380,16384,120462]

theorem envBound14618 : H12AffineFastState.Bounded env14618 := by
  intro p hp
  have h : env14618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14617_14618 : H12AffineEnvironment.transform 16 79130 env14617 = env14618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env14617 == env14618) = true)

theorem identity14618 : scanCanonicalize (H12AffineFastState.compose env14618 (packedSelected [0,3,5,8,9,16,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound14618 : packedSelected [0,3,5,8,9,16,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env14619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,79130,23588,1024,8460,4113,65830,73754,21763,8328,17,31757,90259,91402,10281,20484,8612,256,169,16384,96131]

theorem envBound14619 : H12AffineFastState.Bounded env14619 := by
  intro p hp
  have h : env14619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14618_14619 : H12AffineEnvironment.transform 14 8461 env14618 = env14619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env14618 == env14619) = true)

theorem identity14619 : scanCanonicalize (H12AffineFastState.compose env14619 (packedSelected [1,3,5,8,10,16,17,20,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound14619 : packedSelected [1,3,5,8,10,16,17,20,26] rootPS < 2^1333 := by decide +kernel

def env14620 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8461,65536,79130,2477,1024,8460,4113,65830,73754,138,8328,17,10628,79130,77955,10281,1421,8612,256,169,5513,74250]

theorem envBound14620 : H12AffineFastState.Bounded env14620 := by
  intro p hp
  have h : env14620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14619_14620 : H12AffineEnvironment.transform 13 5513 env14619 = env14620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env14619 == env14620) = true)

theorem identity14620 : scanCanonicalize (H12AffineFastState.compose env14620 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1466) := by decide +kernel

theorem selectedBound14620 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env14621 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8461,1466,12448,2477,1024,8460,4113,1180,9632,138,8328,17,10628,12448,13625,10281,1421,8612,256,169,5513,10160]

theorem envBound14621 : H12AffineFastState.Bounded env14621 := by
  intro p hp
  have h : env14621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14620_14621 : H12AffineEnvironment.transform 15 1466 env14620 = env14621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1466 env14620 == env14621) = true)

theorem identity14621 : scanCanonicalize (H12AffineFastState.compose env14621 (packedSelected [0,1,3,5,8,9,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound14621 : packedSelected [0,1,3,5,8,9,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env14622 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1337,5513,1076,1466,5529,2477,1024,1077,4113,1180,153,138,1457,17,3261,5529,4096,3344,1421,1181,256,169,5513,649]

theorem envBound14622 : H12AffineFastState.Bounded env14622 := by
  intro p hp
  have h : env14622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14621_14622 : H12AffineEnvironment.transform 12 1337 env14621 = env14622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env14621 == env14622) = true)

theorem identity14622 : scanCanonicalize (H12AffineFastState.compose env14622 (packedSelected [3,4,5,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14622 : packedSelected [3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env14623 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,268,4540,1,399,4524,2477,53,0,4113,169,153,138,388,17,2184,4524,4096,2341,440,168,256,169,4540,649]

theorem envBound14623 : H12AffineFastState.Bounded env14623 := by
  intro p hp
  have h : env14623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14622_14623 : H12AffineEnvironment.transform 9 53 env14622 = env14623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14622 == env14623) = true)

theorem identity14623 : scanCanonicalize (H12AffineFastState.compose env14623 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14623 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env14624 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4404,1,263,4388,2341,53,0,4113,33,17,2,268,17,2048,4388,4096,2341,304,32,256,33,4404,513]

theorem envBound14624 : H12AffineFastState.Bounded env14624 := by
  intro p hp
  have h : env14624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14623_14624 : H12AffineEnvironment.transform 6 8 env14623 = env14624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14623 == env14624) = true)

def env14625 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4112,169265,73754,21763,8328,16,215318,115103,91402,35109,61705,243123,256,41381,16385,120463]

theorem envBound14625 : H12AffineFastState.Bounded env14625 := by
  intro p hp
  have h : env14625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14616_14625 : H12AffineEnvironment.transform 5 17 env14616 = env14625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14616 == env14625) = true)

theorem identity14625 : scanCanonicalize (H12AffineFastState.compose env14625 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound14625 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14626 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,97327,1024,32769,4112,32801,73754,21763,8328,16,89094,115103,91402,35109,61705,106659,256,41381,16385,120463]

theorem envBound14626 : H12AffineFastState.Bounded env14626 := by
  intro p hp
  have h : env14626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14625_14626 : H12AffineEnvironment.transform 16 5392 env14625 = env14626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env14625 == env14626) = true)

theorem identity14626 : scanCanonicalize (H12AffineFastState.compose env14626 (packedSelected [1,3,5,8,10,16,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14626 : packedSelected [1,3,5,8,10,16,20,26] rootPS < 2^1333 := by decide +kernel

def env14627 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,5392,2340,1024,32769,4112,32801,21777,21763,8328,16,10509,46228,4097,35109,61705,54696,256,41381,16385,41860]

theorem envBound14627 : H12AffineFastState.Bounded env14627 := by
  intro p hp
  have h : env14627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14626_14627 : H12AffineEnvironment.transform 15 29963 env14626 = env14627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14626 == env14627) = true)

theorem identity14627 : scanCanonicalize (H12AffineFastState.compose env14627 (packedSelected [0,9,18,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound14627 : packedSelected [0,9,18,22,23,27] rootPS < 2^1333 := by decide +kernel

def env14628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,29963,5392,2340,1024,29709,4112,29741,21777,21763,8328,16,10509,16536,4097,32041,1285,8612,256,21929,16385,22408]

theorem envBound14628 : H12AffineFastState.Bounded env14628 := by
  intro p hp
  have h : env14628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14627_14628 : H12AffineEnvironment.transform 14 29708 env14627 = env14628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env14627 == env14628) = true)

theorem identity14628 : scanCanonicalize (H12AffineFastState.compose env14628 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound14628 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env14629 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8581,8322,5392,2340,1024,8580,4112,8612,152,138,8328,16,10509,5393,4097,10400,1285,8612,256,32,5512,513]

theorem envBound14629 : H12AffineFastState.Bounded env14629 := by
  intro p hp
  have h : env14629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14628_14629 : H12AffineEnvironment.transform 13 5513 env14628 = env14629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env14628 == env14629) = true)

theorem identity14629 : scanCanonicalize (H12AffineFastState.compose env14629 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14629 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14630 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,1,262,5392,2340,1024,0,4112,32,152,138,268,16,2185,5393,4097,2340,1285,32,256,32,5512,513]

theorem envBound14630 : H12AffineFastState.Bounded env14630 := by
  intro p hp
  have h : env14630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14629_14630 : H12AffineEnvironment.transform 12 388 env14629 = env14630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14629 == env14630) = true)

theorem identity14630 : scanCanonicalize (H12AffineFastState.compose env14630 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound14630 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14631 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5156,1,171,5309,2185,1024,0,4112,32,152,138,161,16,2185,5308,4097,2185,1192,32,173,32,5157,513]

theorem envBound14631 : H12AffineFastState.Bounded env14631 := by
  intro p hp
  have h : env14631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14630_14631 : H12AffineEnvironment.transform 7 173 env14630 = env14631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env14630 == env14631) = true)

theorem identity14631 : scanCanonicalize (H12AffineFastState.compose env14631 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound14631 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14632 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,4096,41,4249,1,171,4096,2185,189,0,4112,32,152,138,161,16,2185,4097,4097,2185,21,32,173,32,4248,513]

theorem envBound14632 : H12AffineFastState.Bounded env14632 := by
  intro p hp
  have h : env14632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14631_14632 : H12AffineEnvironment.transform 9 189 env14631 = env14632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env14631 == env14632) = true)

theorem identity14632 : scanCanonicalize (H12AffineFastState.compose env14632 (packedSelected [0,1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound14632 : packedSelected [0,1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env14633 : List Nat := [2,4,8,16,32,17,128,173,512,189,649,4096,41,4249,1,171,4096,512,189,0,4112,32,152,138,161,16,512,4097,4097,512,21,32,173,32,4248,513]

theorem envBound14633 : H12AffineFastState.Bounded env14633 := by
  intro p hp
  have h : env14633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14632_14633 : H12AffineEnvironment.transform 10 649 env14632 = env14633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env14632 == env14633) = true)

theorem identity14633 : scanCanonicalize (H12AffineFastState.compose env14633 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound14633 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env14634 : List Nat := [2,4,8,16,32,17,128,173,512,189,649,152,41,1,1,171,152,512,189,0,136,32,152,138,161,16,512,153,153,512,21,32,173,32,0,513]

theorem envBound14634 : H12AffineFastState.Bounded env14634 := by
  intro p hp
  have h : env14634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14633_14634 : H12AffineEnvironment.transform 11 152 env14633 = env14634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env14633 == env14634) = true)

theorem identity14634 : scanCanonicalize (H12AffineFastState.compose env14634 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14634 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14635 : List Nat := [2,4,8,16,32,17,8,37,512,53,513,16,41,1,1,35,16,512,53,0,0,32,16,2,41,16,512,17,17,512,21,32,37,32,0,513]

theorem envBound14635 : H12AffineFastState.Bounded env14635 := by
  intro p hp
  have h : env14635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14634_14635 : H12AffineEnvironment.transform 6 8 env14634 = env14635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14634 == env14635) = true)

theorem identity14635 : scanCanonicalize (H12AffineFastState.compose env14635 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14636 : List Nat := [2,4,8,16,0,17,8,5,512,21,513,16,9,1,1,3,16,512,21,0,0,0,16,2,9,16,512,17,17,512,21,0,5,0,0,513]

theorem envBound14636 : H12AffineFastState.Bounded env14636 := by
  intro p hp
  have h : env14636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14635_14636 : H12AffineEnvironment.transform 4 0 env14635 = env14636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14635 == env14636) = true)

def env14637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412020,2114882,8328,65,215366,115150,2497573,35188,2590758,2336243,256,510106,469310,2535409]

theorem envBound14637 : H12AffineFastState.Bounded env14637 := by
  intro p hp
  have h : env14637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14601_14637 : H12AffineEnvironment.transform 21 2262385 env14601 = env14637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env14601 == env14637) = true)

def env14638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,21762,8328,65,215366,115150,396389,35188,497766,243123,256,510106,469310,442289]

theorem envBound14638 : H12AffineFastState.Bounded env14638 := by
  intro p hp
  have h : env14638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14637_14638 : H12AffineEnvironment.transform 20 4160 env14637 = env14638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14637 == env14638) = true)

theorem identity14638 : scanCanonicalize (H12AffineFastState.compose env14638 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound14638 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,4160,169265,120014,21762,8328,65,215366,115150,102879,35188,1500,243123,256,21792,46212,74251]

theorem envBound14639 : H12AffineFastState.Bounded env14639 := by
  intro p hp
  have h : env14639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14638_14639 : H12AffineEnvironment.transform 17 236986 env14638 = env14639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env14638 == env14639) = true)

def env14640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130174,1024,32769,4160,62709,120014,21762,8328,65,75906,115150,102879,35188,1500,119927,256,21792,46212,74251]

theorem envBound14640 : H12AffineFastState.Bounded env14640 := by
  intro p hp
  have h : env14640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14639_14640 : H12AffineEnvironment.transform 16 25028 env14639 = env14640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env14639 == env14640) = true)

theorem identity14640 : scanCanonicalize (H12AffineFastState.compose env14640 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound14640 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env14641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,25028,76158,1024,21761,4160,8693,65998,21762,8328,65,75906,70862,83167,23668,1500,65911,256,21792,24964,74251]

theorem envBound14641 : H12AffineFastState.Bounded env14641 := by
  intro p hp
  have h : env14641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14640_14641 : H12AffineEnvironment.transform 14 21760 env14640 = env14641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14640 == env14641) = true)

theorem identity14641 : scanCanonicalize (H12AffineFastState.compose env14641 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14641 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env14642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8202,25028,2420,1024,21761,4160,8693,8644,21762,8328,65,2184,13508,25813,23668,1500,8573,256,21792,24964,513]

theorem envBound14642 : H12AffineFastState.Bounded env14642 := by
  intro p hp
  have h : env14642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14641_14642 : H12AffineEnvironment.transform 15 8202 env14641 = env14642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14641 == env14642) = true)

theorem identity14642 : scanCanonicalize (H12AffineFastState.compose env14642 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound14642 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,479,16401,2420,1024,21761,4160,32,17,21762,349,65,2184,5393,17664,23668,1500,168,256,21792,16465,513]

theorem envBound14643 : H12AffineFastState.Bounded env14643 := by
  intro p hp
  have h : env14643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14642_14643 : H12AffineEnvironment.transform 12 469 env14642 = env14643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env14642 == env14643) = true)

theorem identity14643 : scanCanonicalize (H12AffineFastState.compose env14643 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound14643 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5457,81,479,5440,2420,1024,80,4160,32,17,83,349,65,2184,5393,4177,2341,1500,168,256,113,5376,513]

theorem envBound14644 : H12AffineFastState.Bounded env14644 := by
  intro p hp
  have h : env14644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14643_14644 : H12AffineEnvironment.transform 13 5457 env14643 = env14644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env14643 == env14644) = true)

theorem identity14644 : scanCanonicalize (H12AffineFastState.compose env14644 (packedSelected [2,5,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound14644 : packedSelected [2,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env14645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1637,469,820,81,479,805,2420,1024,80,1573,32,17,83,349,65,2184,884,1588,2341,1500,168,256,113,869,513]

theorem envBound14645 : H12AffineFastState.Bounded env14645 := by
  intro p hp
  have h : env14645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14644_14645 : H12AffineEnvironment.transform 11 1637 env14644 = env14645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env14644 == env14645) = true)

theorem identity14645 : scanCanonicalize (H12AffineFastState.compose env14645 (packedSelected [0,3,8,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound14645 : packedSelected [0,3,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env14646 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,869,469,820,81,479,805,2420,256,80,805,32,17,83,349,65,2184,884,820,2341,220,168,256,113,869,513]

theorem envBound14646 : H12AffineFastState.Bounded env14646 := by
  intro p hp
  have h : env14646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14645_14646 : H12AffineEnvironment.transform 9 256 env14645 = env14646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env14645 == env14646) = true)

theorem identity14646 : scanCanonicalize (H12AffineFastState.compose env14646 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound14646 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env14647 : List Nat := [2,4,8,16,32,64,128,236,512,236,2048,649,57,728,81,51,713,2200,236,80,713,32,17,83,177,65,2184,664,728,2249,220,168,236,113,649,513]

theorem envBound14647 : H12AffineFastState.Bounded env14647 := by
  intro p hp
  have h : env14647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14646_14647 : H12AffineEnvironment.transform 7 236 env14646 = env14647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env14646 == env14647) = true)

theorem identity14647 : scanCanonicalize (H12AffineFastState.compose env14647 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14647 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env14648 : List Nat := [2,4,8,16,32,64,88,52,512,52,2048,593,57,512,81,51,529,2112,52,80,529,32,17,83,105,65,2128,576,512,2065,4,112,52,113,593,513]

theorem envBound14648 : H12AffineFastState.Bounded env14648 := by
  intro p hp
  have h : env14648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14647_14648 : H12AffineEnvironment.transform 6 88 env14647 = env14648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14647 == env14648) = true)

theorem identity14648 : scanCanonicalize (H12AffineFastState.compose env14648 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14649 : List Nat := [2,4,8,16,32,16,8,52,512,52,2048,513,57,512,1,51,529,2064,52,0,529,32,17,3,57,17,2048,528,512,2065,4,32,52,33,513,513]

theorem envBound14649 : H12AffineFastState.Bounded env14649 := by
  intro p hp
  have h : env14649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14648_14649 : H12AffineEnvironment.transform 5 16 env14648 = env14649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14648 == env14649) = true)

def env14650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130175,1024,32769,4160,62708,120014,21762,8328,65,75907,115150,102879,35188,1500,119926,256,21792,46212,74251]

theorem envBound14650 : H12AffineFastState.Bounded env14650 := by
  intro p hp
  have h : env14650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14639_14650 : H12AffineEnvironment.transform 16 25029 env14639 = env14650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env14639 == env14650) = true)

theorem identity14650 : scanCanonicalize (H12AffineFastState.compose env14650 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound14650 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env14651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,25029,2420,1024,32769,4160,62708,8645,21762,8328,65,56712,13509,25812,35188,1500,8573,256,21792,46212,55040]

theorem envBound14651 : H12AffineFastState.Bounded env14651 := by
  intro p hp
  have h : env14651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14650_14651 : H12AffineEnvironment.transform 15 62731 env14650 = env14651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env14650 == env14651) = true)

def env14652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24909,2420,1024,32769,4160,62588,8525,21762,8192,65,56576,13389,25692,35188,1364,8573,256,21792,46092,55040]

theorem envBound14652 : H12AffineFastState.Bounded env14652 := by
  intro p hp
  have h : env14652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14651_14652 : H12AffineEnvironment.transform 6 8 env14651 = env14652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14651 == env14652) = true)

theorem identity14652 : scanCanonicalize (H12AffineFastState.compose env14652 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound14652 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,24909,2420,1024,21760,4160,8573,8525,21762,8192,65,2049,13389,25692,23669,1364,8573,256,21792,24845,513]

theorem envBound14653 : H12AffineFastState.Bounded env14653 := by
  intro p hp
  have h : env14653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14652_14653 : H12AffineEnvironment.transform 14 21761 env14652 = env14653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env14652 == env14653) = true)

theorem identity14653 : scanCanonicalize (H12AffineFastState.compose env14653 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14653 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,8202,5393,2420,1024,8540,4160,8573,8525,8542,8192,65,2049,13389,4096,10281,1364,8573,256,8572,5457,513]

theorem envBound14654 : H12AffineFastState.Bounded env14654 := by
  intro p hp
  have h : env14654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14653_14654 : H12AffineEnvironment.transform 13 13404 env14653 = env14654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14653 == env14654) = true)

theorem identity14654 : scanCanonicalize (H12AffineFastState.compose env14654 (packedSelected [0,2,3,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound14654 : packedSelected [0,2,3,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2048,8192,11356,8541,8202,3345,2420,1024,8540,2112,8573,8525,8542,8192,65,2049,11341,2048,10281,1364,8573,256,8572,3409,513]

theorem envBound14655 : H12AffineFastState.Bounded env14655 := by
  intro p hp
  have h : env14655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14654_14655 : H12AffineEnvironment.transform 11 2048 env14654 = env14655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env14654 == env14655) = true)

theorem identity14655 : scanCanonicalize (H12AffineFastState.compose env14655 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14655 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2048,269,3409,80,263,3345,2420,1024,81,2112,112,64,83,269,65,2049,3392,2048,2340,1364,112,256,113,3409,513]

theorem envBound14656 : H12AffineFastState.Bounded env14656 := by
  intro p hp
  have h : env14656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14655_14656 : H12AffineEnvironment.transform 12 269 env14655 = env14656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14655 == env14656) = true)

def env14657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,2420,1024,32769,4160,62589,8524,21762,8193,65,56577,13388,25693,35188,1365,8573,256,21792,46093,55040]

theorem envBound14657 : H12AffineFastState.Bounded env14657 := by
  intro p hp
  have h : env14657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14651_14657 : H12AffineEnvironment.transform 6 9 env14651 = env14657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14651 == env14657) = true)

theorem identity14657 : scanCanonicalize (H12AffineFastState.compose env14657 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14657 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,33111,5392,2420,1024,32769,4160,32801,8524,8542,8193,65,43357,13388,4097,35188,1365,8573,256,8572,46093,41820]

theorem envBound14658 : H12AffineFastState.Bounded env14658 := by
  intro p hp
  have h : env14658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14657_14658 : H12AffineEnvironment.transform 13 13404 env14657 = env14658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14657 == env14658) = true)

theorem identity14658 : scanCanonicalize (H12AffineFastState.compose env14658 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14658 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,343,5392,2420,1024,1,4160,33,8524,8542,8193,65,10589,13388,4097,2420,1365,8573,256,8572,13325,9052]

theorem envBound14659 : H12AffineFastState.Bounded env14659 := by
  intro p hp
  have h : env14659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14658_14659 : H12AffineEnvironment.transform 14 0 env14658 = env14659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14658 == env14659) = true)

theorem identity14659 : scanCanonicalize (H12AffineFastState.compose env14659 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound14659 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,8192,11624,0,343,3108,2420,1024,1,2420,33,8524,8542,8193,65,10589,11640,2357,2420,1365,8573,256,8572,11577,9052]

theorem envBound14660 : H12AffineFastState.Bounded env14660 := by
  intro p hp
  have h : env14660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14659_14660 : H12AffineEnvironment.transform 11 2356 env14659 = env14660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env14659 == env14660) = true)

theorem identity14660 : scanCanonicalize (H12AffineFastState.compose env14660 (packedSelected [1,3,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound14660 : packedSelected [1,3,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1101,2341,0,343,3108,2420,1024,1,2420,33,1281,1299,1100,65,3344,2357,2357,2420,1365,1328,256,1329,2420,1809]

theorem envBound14661 : H12AffineFastState.Bounded env14661 := by
  intro p hp
  have h : env14661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14660_14661 : H12AffineEnvironment.transform 12 1101 env14660 = env14661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env14660 == env14661) = true)

theorem identity14661 : scanCanonicalize (H12AffineFastState.compose env14661 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound14661 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env14662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,1360,1101,1345,0,343,64,1296,1024,1,1296,33,1281,1299,1100,65,372,1361,1361,1296,1365,1328,256,1329,1296,1809]

theorem envBound14662 : H12AffineFastState.Bounded env14662 := by
  intro p hp
  have h : env14662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14661_14662 : H12AffineEnvironment.transform 10 1124 env14661 = env14662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env14661 == env14662) = true)

theorem identity14662 : scanCanonicalize (H12AffineFastState.compose env14662 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14662 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14663 : List Nat := [2,4,8,16,32,64,9,256,512,52,80,356,121,373,0,343,64,292,52,1,292,33,309,295,120,65,372,357,357,292,353,260,256,261,292,805]

theorem envBound14663 : H12AffineFastState.Bounded env14663 := by
  intro p hp
  have h : env14663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14662_14663 : H12AffineEnvironment.transform 9 52 env14662 = env14663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14662 == env14663) = true)

theorem identity14663 : scanCanonicalize (H12AffineFastState.compose env14663 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14663 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env14664 : List Nat := [2,4,8,16,32,64,9,36,512,52,80,64,121,81,0,115,64,0,52,1,0,33,17,3,120,65,80,65,65,0,69,32,36,33,0,513]

theorem envBound14664 : H12AffineFastState.Bounded env14664 := by
  intro p hp
  have h : env14664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14663_14664 : H12AffineEnvironment.transform 7 36 env14663 = env14664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14663 == env14664) = true)

theorem identity14664 : scanCanonicalize (H12AffineFastState.compose env14664 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14665 : List Nat := [2,4,8,0,32,64,9,36,512,36,64,64,105,65,0,99,64,0,36,1,0,33,1,3,104,65,64,65,65,0,69,32,36,33,0,513]

theorem envBound14665 : H12AffineFastState.Bounded env14665 := by
  intro p hp
  have h : env14665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14664_14665 : H12AffineEnvironment.transform 3 0 env14664 = env14665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14664 == env14665) = true)

theorem identity14665 : scanCanonicalize (H12AffineFastState.compose env14665 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound14665 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14666 : List Nat := [2,4,8,0,32,64,9,36,10,36,64,64,105,65,0,99,64,0,36,1,0,33,1,3,104,65,64,65,65,0,69,32,36,33,0,11]

theorem envBound14666 : H12AffineFastState.Bounded env14666 := by
  intro p hp
  have h : env14666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14665_14666 : H12AffineEnvironment.transform 8 10 env14665 = env14666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env14665 == env14666) = true)

theorem identity14666 : scanCanonicalize (H12AffineFastState.compose env14666 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound14666 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14667 : List Nat := [2,4,8,0,32,11,9,36,10,36,11,11,34,10,0,40,11,0,36,1,0,33,1,3,35,10,11,10,10,0,14,32,36,33,0,11]

theorem envBound14667 : H12AffineFastState.Bounded env14667 := by
  intro p hp
  have h : env14667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14666_14667 : H12AffineEnvironment.transform 5 11 env14666 = env14667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env14666 == env14667) = true)

theorem identity14667 : scanCanonicalize (H12AffineFastState.compose env14667 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14668 : List Nat := [2,4,2,0,32,1,3,36,0,36,1,1,34,0,0,34,1,0,36,1,0,33,1,3,35,0,1,0,0,0,4,32,36,33,0,1]

theorem envBound14668 : H12AffineFastState.Bounded env14668 := by
  intro p hp
  have h : env14668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14667_14668 : H12AffineEnvironment.transform 2 2 env14667 = env14668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14667 == env14668) = true)

def env14669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,21763,8328,65,215366,115150,396388,35188,497767,243122,256,510106,469310,442288]

theorem envBound14669 : H12AffineFastState.Bounded env14669 := by
  intro p hp
  have h : env14669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14637_14669 : H12AffineEnvironment.transform 20 4161 env14637 = env14669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14637 == env14669) = true)

theorem identity14669 : scanCanonicalize (H12AffineFastState.compose env14669 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14669 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,169264,412020,21763,8328,65,158028,57796,396388,35188,440429,169400,256,452752,395572,442288]

theorem envBound14670 : H12AffineFastState.Bounded env14670 := by
  intro p hp
  have h : env14670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14669_14670 : H12AffineEnvironment.transform 15 8202 env14669 = env14670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14669 == env14670) = true)

theorem identity14670 : scanCanonicalize (H12AffineFastState.compose env14670 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound14670 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env14671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4161,169264,62661,21763,8328,65,158028,57796,45525,35188,1500,169400,256,21793,46213,513]

theorem envBound14671 : H12AffineFastState.Bounded env14671 := by
  intro p hp
  have h : env14671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14670_14671 : H12AffineEnvironment.transform 17 179633 env14670 = env14671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env14670 == env14671) = true)

theorem identity14671 : scanCanonicalize (H12AffineFastState.compose env14671 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound14671 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env14672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46277,2420,1024,32769,4161,8693,62661,21763,8328,65,56713,57796,45525,35188,1500,8573,256,21793,46213,513]

theorem envBound14672 : H12AffineFastState.Bounded env14672 := by
  intro p hp
  have h : env14672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14671_14672 : H12AffineEnvironment.transform 16 46277 env14671 = env14672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env14671 == env14672) = true)

theorem identity14672 : scanCanonicalize (H12AffineFastState.compose env14672 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14672 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env14673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,38296,2420,1024,32769,4161,168,54680,21763,469,65,56713,49305,37000,35188,1500,32,256,21793,38360,513]

theorem envBound14673 : H12AffineFastState.Bounded env14673 := by
  intro p hp
  have h : env14673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14672_14673 : H12AffineEnvironment.transform 12 349 env14672 = env14673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14672 == env14673) = true)

def env14674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412021,2114883,8328,65,6409271,115151,2497572,35189,2590758,4268163,256,510106,469310,2535409]

theorem envBound14674 : H12AffineFastState.Bounded env14674 := by
  intro p hp
  have h : env14674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14600_14674 : H12AffineEnvironment.transform 22 412021 env14600 = env14674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412021 env14600 == env14674) = true)

def env14675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412021,2114883,8328,65,215367,115151,2497572,35189,2590758,2336243,256,510106,469310,2535409]

theorem envBound14675 : H12AffineFastState.Bounded env14675 := by
  intro p hp
  have h : env14675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14674_14675 : H12AffineEnvironment.transform 21 2262384 env14674 = env14675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env14674 == env14675) = true)

def env14676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,21763,8328,65,215367,115151,396388,35189,497766,243123,256,510106,469310,442289]

theorem envBound14676 : H12AffineFastState.Bounded env14676 := by
  intro p hp
  have h : env14676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14675_14676 : H12AffineEnvironment.transform 20 4160 env14675 = env14676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14675 == env14676) = true)

def env14677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169264,155997,21763,8328,65,215367,115151,140364,35189,241742,243123,256,254130,196886,169881]

theorem envBound14677 : H12AffineFastState.Bounded env14677 := by
  intro p hp
  have h : env14677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14676_14677 : H12AffineEnvironment.transform 17 10280 env14676 = env14677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14676 == env14677) = true)

def env14678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21792,41293,21763,8328,65,100695,115151,58460,35189,94302,95651,256,73890,114950,22409]

theorem envBound14678 : H12AffineFastState.Bounded env14678 := by
  intro p hp
  have h : env14678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14677_14678 : H12AffineEnvironment.transform 16 49168 env14677 = env14678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14677 == env14678) = true)

theorem identity14678 : scanCanonicalize (H12AffineFastState.compose env14678 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound14678 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10280,1024,29789,4160,21792,21777,21763,8328,65,97547,79251,4096,32041,94302,95651,256,73890,79194,22409]

theorem envBound14679 : H12AffineFastState.Bounded env14679 := by
  intro p hp
  have h : env14679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14678_14679 : H12AffineEnvironment.transform 14 29788 env14678 = env14679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env14678 == env14679) = true)

theorem identity14679 : scanCanonicalize (H12AffineFastState.compose env14679 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound14679 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env14680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,9499,13388,10280,1024,29789,4160,21792,21777,21763,8328,65,22544,4232,4096,32041,21829,20664,256,1465,4161,22409]

theorem envBound14680 : H12AffineFastState.Bounded env14680 := by
  intro p hp
  have h : env14680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14679_14680 : H12AffineEnvironment.transform 15 9499 env14679 = env14680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env14679 == env14680) = true)

theorem identity14680 : scanCanonicalize (H12AffineFastState.compose env14680 (packedSelected [0,2,5,6,7,18,20,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound14680 : packedSelected [0,2,5,6,7,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env14681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8461,9499,13388,10280,1024,8460,4160,113,64,82,8328,65,3393,4232,4096,10360,20,1513,256,1465,4161,728]

theorem envBound14681 : H12AffineFastState.Bounded env14681 := by
  intro p hp
  have h : env14681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14680_14681 : H12AffineEnvironment.transform 13 5457 env14680 = env14681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env14680 == env14681) = true)

theorem identity14681 : scanCanonicalize (H12AffineFastState.compose env14681 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14681 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env14682 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,8192,4453,8461,8495,12408,10280,52,8460,4160,113,64,82,8328,65,2421,4232,4096,10360,20,477,256,397,4161,728]

theorem envBound14682 : H12AffineFastState.Bounded env14682 := by
  intro p hp
  have h : env14682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14681_14682 : H12AffineEnvironment.transform 9 52 env14681 = env14682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14681 == env14682) = true)

theorem identity14682 : scanCanonicalize (H12AffineFastState.compose env14682 (packedSelected [1,3,5,8,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound14682 : packedSelected [1,3,5,8,14,16] rootPS < 2^1333 := by decide +kernel

def env14683 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,2248,8192,2477,8461,8495,10416,10280,52,8460,2184,113,64,82,8328,65,2421,2112,2248,10360,20,477,256,397,2185,728]

theorem envBound14683 : H12AffineFastState.Bounded env14683 := by
  intro p hp
  have h : env14683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14682_14683 : H12AffineEnvironment.transform 11 2248 env14682 = env14683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env14682 == env14683) = true)

theorem identity14683 : scanCanonicalize (H12AffineFastState.compose env14683 (packedSelected [0,2,3,5,6,7,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 2517) := by decide +kernel

theorem selectedBound14683 : packedSelected [0,2,3,5,6,7,10,14] rootPS < 2^1333 := by decide +kernel

def env14684 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,2248,2517,2477,2264,2298,357,509,52,2265,2184,113,64,82,2397,65,2421,2112,2248,429,20,477,256,397,2185,728]

theorem envBound14684 : H12AffineFastState.Bounded env14684 := by
  intro p hp
  have h : env14684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14683_14684 : H12AffineEnvironment.transform 12 2517 env14683 = env14684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2517 env14683 == env14684) = true)

def env14685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21793,41292,21763,8328,65,100694,115151,58461,35189,94303,95650,256,73891,114951,22408]

theorem envBound14685 : H12AffineFastState.Bounded env14685 := by
  intro p hp
  have h : env14685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14677_14685 : H12AffineEnvironment.transform 16 49169 env14677 = env14685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14677 == env14685) = true)

theorem identity14685 : scanCanonicalize (H12AffineFastState.compose env14685 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound14685 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,10280,1024,29909,4160,21793,21912,21763,8328,65,97666,79131,4233,32161,94303,95650,256,73891,79315,22408]

theorem envBound14686 : H12AffineFastState.Bounded env14686 := by
  intro p hp
  have h : env14686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14685_14686 : H12AffineEnvironment.transform 14 29908 env14685 = env14686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env14685 == env14686) = true)

theorem identity14686 : scanCanonicalize (H12AffineFastState.compose env14686 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 1230) := by decide +kernel

theorem selectedBound14686 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,1230,13509,10280,1024,29909,4160,21793,21912,21763,8328,65,31052,12757,4233,32161,29841,29036,256,9325,12573,22408]

theorem envBound14687 : H12AffineFastState.Bounded env14687 := by
  intro p hp
  have h : env14687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14686_14687 : H12AffineEnvironment.transform 15 1230 env14686 = env14687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1230 env14686 == env14687) = true)

theorem identity14687 : scanCanonicalize (H12AffineFastState.compose env14687 (packedSelected [5,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound14687 : packedSelected [5,19,24] rootPS < 2^1333 := by decide +kernel

def env14688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4248,9292,1230,13509,10280,1024,9293,4160,1465,1280,1435,8328,65,10708,12757,4233,11577,9225,8692,256,9325,12573,1808]

theorem envBound14688 : H12AffineFastState.Bounded env14688 := by
  intro p hp
  have h : env14688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14687_14688 : H12AffineEnvironment.transform 13 4248 env14687 = env14688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env14687 == env14688) = true)

theorem identity14688 : scanCanonicalize (H12AffineFastState.compose env14688 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound14688 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env14689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,4248,1433,1230,5392,2557,1024,1432,4160,1465,1280,1435,349,65,2049,4096,4233,3308,1500,33,256,1464,4296,1808]

theorem envBound14689 : H12AffineFastState.Bounded env14689 := by
  intro p hp
  have h : env14689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14688_14689 : H12AffineEnvironment.transform 12 469 env14688 = env14689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env14688 == env14689) = true)

theorem identity14689 : scanCanonicalize (H12AffineFastState.compose env14689 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14689 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1297,1094,5392,2421,1024,1296,4160,1329,1280,1299,349,65,2049,4096,4097,3172,1364,33,256,1328,4160,1808]

theorem envBound14690 : H12AffineFastState.Bounded env14690 := by
  intro p hp
  have h : env14690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14689_14690 : H12AffineEnvironment.transform 6 8 env14689 = env14690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14689 == env14690) = true)

theorem identity14690 : scanCanonicalize (H12AffineFastState.compose env14690 (packedSelected [1,3,5,6,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14690 : packedSelected [1,3,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14691 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,88,4112,1044,1094,5141,2160,1024,1045,4160,1076,1029,1046,88,65,2049,4096,4097,3172,1105,33,5,1077,4160,1557]

theorem envBound14691 : H12AffineFastState.Bounded env14691 := by
  intro p hp
  have h : env14691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14690_14691 : H12AffineEnvironment.transform 7 5 env14690 = env14691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14690 == env14691) = true)

theorem identity14691 : scanCanonicalize (H12AffineFastState.compose env14691 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound14691 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14692 : List Nat := [2,4,8,16,32,49,8,5,512,1024,2048,4096,41,4112,1044,1079,5141,2049,1024,1045,4145,1076,1029,1046,41,48,2049,4096,4097,3093,1056,33,5,1077,4145,1557]

theorem envBound14692 : H12AffineFastState.Bounded env14692 := by
  intro p hp
  have h : env14692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14691_14692 : H12AffineEnvironment.transform 5 49 env14691 = env14692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env14691 == env14692) = true)

theorem identity14692 : scanCanonicalize (H12AffineFastState.compose env14692 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14692 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14693 : List Nat := [2,4,8,16,32,49,8,5,512,52,2048,4096,41,4112,32,3,4129,2049,52,33,4145,0,49,34,41,48,2049,4096,4097,2081,20,33,5,1,4145,545]

theorem envBound14693 : H12AffineFastState.Bounded env14693 := by
  intro p hp
  have h : env14693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14692_14693 : H12AffineEnvironment.transform 9 52 env14692 = env14693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14692 == env14693) = true)

theorem identity14693 : scanCanonicalize (H12AffineFastState.compose env14693 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound14693 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14694 : List Nat := [2,4,8,16,32,49,8,5,512,52,2048,560,41,544,32,3,529,2049,52,33,513,0,49,34,41,48,2049,560,561,2081,20,33,5,1,513,545]

theorem envBound14694 : H12AffineFastState.Bounded env14694 := by
  intro p hp
  have h : env14694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14693_14694 : H12AffineEnvironment.transform 11 560 env14693 = env14694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env14693 == env14694) = true)

def env14695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169264,155996,21763,8328,65,215367,115151,140365,35189,241743,243123,256,254131,196887,169880]

theorem envBound14695 : H12AffineFastState.Bounded env14695 := by
  intro p hp
  have h : env14695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14676_14695 : H12AffineEnvironment.transform 17 10281 env14676 = env14695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14676 == env14695) = true)

def env14696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21792,41292,21763,8328,65,100695,115151,58461,35189,94303,95651,256,73891,114951,22408]

theorem envBound14696 : H12AffineFastState.Bounded env14696 := by
  intro p hp
  have h : env14696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14695_14696 : H12AffineEnvironment.transform 16 49168 env14695 = env14696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14695 == env14696) = true)

theorem identity14696 : scanCanonicalize (H12AffineFastState.compose env14696 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound14696 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38297,10281,1024,32769,4160,169,41292,138,8328,65,100695,103494,45524,35189,75222,73770,256,73891,103566,513]

theorem envBound14697 : H12AffineFastState.Bounded env14697 := by
  intro p hp
  have h : env14697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14696_14697 : H12AffineEnvironment.transform 13 5513 env14696 = env14697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env14696 == env14697) = true)

theorem identity14697 : scanCanonicalize (H12AffineFastState.compose env14697 (packedSelected [0,1,7,8,9,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound14697 : packedSelected [0,1,7,8,9,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33111,38297,10281,1024,32769,4160,169,41292,138,8328,65,2048,5393,45524,35189,42113,41341,256,41460,5593,513]

theorem envBound14698 : H12AffineFastState.Bounded env14698 := by
  intro p hp
  have h : env14698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14697_14698 : H12AffineEnvironment.transform 15 33111 env14697 = env14698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env14697 == env14698) = true)

theorem identity14698 : scanCanonicalize (H12AffineFastState.compose env14698 (packedSelected [2,3,4,5,6,9,10,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14698 : packedSelected [2,3,4,5,6,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env14699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33030,38297,10281,1024,32769,4113,169,41245,138,8328,16,2048,5393,45445,35108,42113,41260,256,41381,5512,513]

theorem envBound14699 : H12AffineFastState.Bounded env14699 := by
  intro p hp
  have h : env14699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14698_14699 : H12AffineEnvironment.transform 5 17 env14698 = env14699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14698 == env14699) = true)

theorem identity14699 : scanCanonicalize (H12AffineFastState.compose env14699 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14699 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,32768,33030,38297,2341,1024,32769,4113,169,32785,138,388,16,2048,5393,37001,35108,34189,32800,256,32937,5512,513]

theorem envBound14700 : H12AffineFastState.Bounded env14700 := by
  intro p hp
  have h : env14700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14699_14700 : H12AffineEnvironment.transform 12 268 env14699 = env14700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14699 == env14700) = true)

theorem identity14700 : scanCanonicalize (H12AffineFastState.compose env14700 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14700 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14701 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,33030,38161,2341,1024,32769,4113,33,32785,2,268,16,2048,5393,36865,35108,34053,32800,256,32801,5376,513]

theorem envBound14701 : H12AffineFastState.Bounded env14701 := by
  intro p hp
  have h : env14701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14700_14701 : H12AffineEnvironment.transform 6 8 env14700 = env14701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14700 == env14701) = true)

theorem identity14701 : scanCanonicalize (H12AffineFastState.compose env14701 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14701 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14702 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1024,1,4113,33,17,2,268,16,2048,5393,4097,2340,1285,32,256,33,5376,513]

theorem envBound14702 : H12AffineFastState.Bounded env14702 := by
  intro p hp
  have h : env14702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14701_14702 : H12AffineEnvironment.transform 14 0 env14701 = env14702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14701 == env14702) = true)

theorem identity14702 : scanCanonicalize (H12AffineFastState.compose env14702 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound14702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14703 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1029,268,260,0,262,276,2341,1024,1,1044,33,17,2,268,16,2048,276,1028,2340,1285,32,256,33,261,513]

theorem envBound14703 : H12AffineFastState.Bounded env14703 := by
  intro p hp
  have h : env14703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14702_14703 : H12AffineEnvironment.transform 11 1029 env14702 = env14703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env14702 == env14703) = true)

theorem identity14703 : scanCanonicalize (H12AffineFastState.compose env14703 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1851) := by decide +kernel

theorem selectedBound14703 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14704 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1851,1029,268,260,0,262,276,1566,1024,1,1044,33,17,2,268,16,1851,276,1028,1567,1285,32,256,33,261,513]

theorem envBound14704 : H12AffineFastState.Bounded env14704 := by
  intro p hp
  have h : env14704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14703_14704 : H12AffineEnvironment.transform 10 1851 env14703 = env14704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1851 env14703 == env14704) = true)

theorem identity14704 : scanCanonicalize (H12AffineFastState.compose env14704 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound14704 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14705 : List Nat := [2,4,8,16,32,17,8,256,512,62,773,59,268,260,0,262,276,544,62,1,42,33,17,2,268,16,773,276,58,545,315,32,256,33,261,513]

theorem envBound14705 : H12AffineFastState.Bounded env14705 := by
  intro p hp
  have h : env14705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14704_14705 : H12AffineEnvironment.transform 9 62 env14704 = env14705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env14704 == env14705) = true)

theorem identity14705 : scanCanonicalize (H12AffineFastState.compose env14705 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound14705 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14706 : List Nat := [2,4,8,16,32,17,8,256,59,62,318,59,268,260,0,262,276,27,62,1,42,33,17,2,268,16,318,276,58,26,315,32,256,33,261,58]

theorem envBound14706 : H12AffineFastState.Bounded env14706 := by
  intro p hp
  have h : env14706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14705_14706 : H12AffineEnvironment.transform 8 59 env14705 = env14706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env14705 == env14706) = true)

theorem identity14706 : scanCanonicalize (H12AffineFastState.compose env14706 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound14706 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14707 : List Nat := [2,4,8,16,32,17,8,52,59,62,10,59,56,48,0,50,32,27,62,1,42,33,17,2,56,16,10,32,58,26,15,32,52,33,49,58]

theorem envBound14707 : H12AffineFastState.Bounded env14707 := by
  intro p hp
  have h : env14707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14706_14707 : H12AffineEnvironment.transform 7 52 env14706 = env14707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env14706 == env14707) = true)

theorem identity14707 : scanCanonicalize (H12AffineFastState.compose env14707 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound14707 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14708 : List Nat := [2,4,8,16,11,17,8,31,16,21,10,16,19,27,0,25,11,27,21,1,1,10,17,2,19,16,10,11,17,26,15,11,31,10,26,17]

theorem envBound14708 : H12AffineFastState.Bounded env14708 := by
  intro p hp
  have h : env14708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14707_14708 : H12AffineEnvironment.transform 4 11 env14707 = env14708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env14707 == env14708) = true)

theorem identity14708 : scanCanonicalize (H12AffineFastState.compose env14708 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound14708 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14709 : List Nat := [2,4,4,16,7,17,4,19,16,21,6,16,19,23,0,21,7,23,21,1,1,6,17,2,19,16,6,7,17,22,3,7,19,6,22,17]

theorem envBound14709 : H12AffineFastState.Bounded env14709 := by
  intro p hp
  have h : env14709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14708_14709 : H12AffineEnvironment.transform 2 4 env14708 = env14709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env14708 == env14709) = true)

theorem identity14709 : scanCanonicalize (H12AffineFastState.compose env14709 (packedSelected [0,9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound14709 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env14710 : List Nat := [2,2,2,16,1,17,2,19,16,19,0,16,19,17,0,19,1,17,19,1,1,0,17,2,19,16,0,1,17,16,3,1,19,0,16,17]

theorem envBound14710 : H12AffineFastState.Bounded env14710 := by
  intro p hp
  have h : env14710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14709_14710 : H12AffineEnvironment.transform 1 2 env14709 = env14710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env14709 == env14710) = true)

theorem identity14710 : scanCanonicalize (H12AffineFastState.compose env14710 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14711 : List Nat := [1,1,1,16,1,17,1,16,16,16,0,16,16,17,0,16,1,17,16,1,1,0,17,1,16,16,0,1,17,16,0,1,16,0,16,17]

theorem envBound14711 : H12AffineFastState.Bounded env14711 := by
  intro p hp
  have h : env14711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14710_14711 : H12AffineEnvironment.transform 0 1 env14710 = env14711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14710 == env14711) = true)

def env14712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21793,41293,21763,8328,65,100694,115151,58460,35189,94302,95650,256,73890,114950,22409]

theorem envBound14712 : H12AffineFastState.Bounded env14712 := by
  intro p hp
  have h : env14712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14695_14712 : H12AffineEnvironment.transform 16 49169 env14695 = env14712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14695 == env14712) = true)

theorem identity14712 : scanCanonicalize (H12AffineFastState.compose env14712 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14712 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10281,1024,32769,4160,33,41293,3,8328,65,100694,103631,45404,35189,75102,73890,256,73890,103430,649]

theorem envBound14713 : H12AffineFastState.Bounded env14713 := by
  intro p hp
  have h : env14713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14712_14713 : H12AffineEnvironment.transform 13 5376 env14712 = env14713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14712 == env14713) = true)

theorem identity14713 : scanCanonicalize (H12AffineFastState.compose env14713 (packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound14713 : packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS < 2^1333 := by decide +kernel

def env14714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,81,65536,5440,10281,1024,80,4160,33,8476,3,8328,65,67847,70814,12557,2340,75102,73890,256,73890,70743,649]

theorem envBound14714 : H12AffineFastState.Bounded env14714 := by
  intro p hp
  have h : env14714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14713_14714 : H12AffineEnvironment.transform 14 81 env14713 = env14714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env14713 == env14714) = true)

theorem identity14714 : scanCanonicalize (H12AffineFastState.compose env14714 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14714 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env14715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,81,8203,5440,10281,1024,80,4160,33,8476,3,8328,65,10508,13461,12557,2340,1365,169,256,169,13404,649]

theorem envBound14715 : H12AffineFastState.Bounded env14715 := by
  intro p hp
  have h : env14715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14714_14715 : H12AffineEnvironment.transform 15 8203 env14714 = env14715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14714 == env14715) = true)

theorem identity14715 : scanCanonicalize (H12AffineFastState.compose env14715 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14715 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,81,263,5440,2341,1024,80,4160,33,16,3,388,65,2048,5529,4097,2340,1365,169,256,169,5456,649]

theorem envBound14716 : H12AffineFastState.Bounded env14716 := by
  intro p hp
  have h : env14716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14715_14716 : H12AffineEnvironment.transform 12 268 env14715 = env14716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14715 == env14716) = true)

theorem identity14716 : scanCanonicalize (H12AffineFastState.compose env14716 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14716 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14717 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,121,5237,81,114,5173,2128,1024,80,4160,33,16,3,241,65,2048,5356,4097,2129,1056,169,117,169,5157,649]

theorem envBound14717 : H12AffineFastState.Bounded env14717 := by
  intro p hp
  have h : env14717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14716_14717 : H12AffineEnvironment.transform 7 117 env14716 = env14717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14716 == env14717) = true)

theorem identity14717 : scanCanonicalize (H12AffineFastState.compose env14717 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14717 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14718 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,81,114,5173,2128,1024,80,4160,33,16,3,120,65,2048,5221,4097,2129,1056,32,117,32,5157,512]

theorem envBound14718 : H12AffineFastState.Bounded env14718 := by
  intro p hp
  have h : env14718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14717_14718 : H12AffineEnvironment.transform 6 9 env14717 = env14718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14717 == env14718) = true)

theorem identity14718 : scanCanonicalize (H12AffineFastState.compose env14718 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3604) := by decide +kernel

theorem selectedBound14718 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14719 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3604,121,2657,81,114,2593,2128,1024,80,3668,33,16,3,120,65,2048,2673,3605,2129,1056,32,117,32,2609,512]

theorem envBound14719 : H12AffineFastState.Bounded env14719 := by
  intro p hp
  have h : env14719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14718_14719 : H12AffineEnvironment.transform 11 3604 env14718 = env14719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3604 env14718 == env14719) = true)

theorem identity14719 : scanCanonicalize (H12AffineFastState.compose env14719 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14719 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14720 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3604,88,2624,81,83,2560,2128,1024,80,3668,0,16,3,89,65,2048,2640,3605,2129,1025,1,84,1,2576,512]

theorem envBound14720 : H12AffineFastState.Bounded env14720 := by
  intro p hp
  have h : env14720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14719_14720 : H12AffineEnvironment.transform 4 1 env14719 = env14720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14719 == env14720) = true)

theorem identity14720 : scanCanonicalize (H12AffineFastState.compose env14720 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound14720 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14721 : List Nat := [2,4,8,16,1,64,9,84,512,1024,64,1620,88,512,81,83,576,16,1024,80,1556,0,16,3,89,65,64,528,1621,17,1025,1,84,1,592,512]

theorem envBound14721 : H12AffineFastState.Bounded env14721 := by
  intro p hp
  have h : env14721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14720_14721 : H12AffineEnvironment.transform 10 64 env14720 = env14721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env14720 == env14721) = true)

theorem identity14721 : scanCanonicalize (H12AffineFastState.compose env14721 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound14721 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14722 : List Nat := [2,4,8,16,1,64,9,84,512,581,64,17,88,512,81,83,576,16,581,80,81,0,16,3,89,65,64,528,16,17,580,1,84,1,592,512]

theorem envBound14722 : H12AffineFastState.Bounded env14722 := by
  intro p hp
  have h : env14722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14721_14722 : H12AffineEnvironment.transform 9 581 env14721 = env14722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env14721 == env14722) = true)

theorem identity14722 : scanCanonicalize (H12AffineFastState.compose env14722 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14722 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env14723 : List Nat := [2,4,8,16,1,17,9,5,512,532,17,17,9,512,0,2,529,16,532,1,0,0,16,3,8,16,17,528,16,17,533,1,5,1,513,512]

theorem envBound14723 : H12AffineFastState.Bounded env14723 := by
  intro p hp
  have h : env14723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14722_14723 : H12AffineEnvironment.transform 5 17 env14722 = env14723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14722 == env14723) = true)

def env14724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,21762,8328,65,215367,115151,396389,35189,497767,243122,256,510106,469310,442288]

theorem envBound14724 : H12AffineFastState.Bounded env14724 := by
  intro p hp
  have h : env14724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14675_14724 : H12AffineEnvironment.transform 20 4161 env14675 = env14724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14675 == env14724) = true)

theorem identity14724 : scanCanonicalize (H12AffineFastState.compose env14724 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound14724 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,169265,62660,21762,8328,65,215367,115151,45524,35189,75222,243122,256,95531,103567,513]

theorem envBound14725 : H12AffineFastState.Bounded env14725 := by
  intro p hp
  have h : env14725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14724_14725 : H12AffineEnvironment.transform 17 179633 env14724 = env14725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env14724 == env14725) = true)

def env14726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169265,62540,21762,8192,65,215367,115015,45404,35189,75102,243002,256,95531,103431,513]

theorem envBound14726 : H12AffineFastState.Bounded env14726 := by
  intro p hp
  have h : env14726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14725_14726 : H12AffineEnvironment.transform 6 8 env14725 = env14726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14725 == env14726) = true)

theorem identity14726 : scanCanonicalize (H12AffineFastState.compose env14726 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14726 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,33,62540,21762,8192,65,121943,115015,45404,35189,75102,73770,256,95531,103431,513]

theorem envBound14727 : H12AffineFastState.Bounded env14727 := by
  intro p hp
  have h : env14727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14726_14727 : H12AffineEnvironment.transform 16 38160 env14726 = env14727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14726 == env14727) = true)

theorem identity14727 : scanCanonicalize (H12AffineFastState.compose env14727 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound14727 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env14728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,65536,5440,10281,1024,81,4161,33,29724,21762,8192,65,89095,82199,12556,2341,75102,73770,256,95531,70743,513]

theorem envBound14728 : H12AffineFastState.Bounded env14728 := by
  intro p hp
  have h : env14728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14727_14728 : H12AffineEnvironment.transform 14 80 env14727 = env14728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env14727 == env14728) = true)

theorem identity14728 : scanCanonicalize (H12AffineFastState.compose env14728 (packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound14728 : packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env14729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,21510,5440,10281,1024,81,4161,33,29724,21762,8192,65,2049,5393,12556,2341,29016,29740,256,8493,16465,513]

theorem envBound14729 : H12AffineFastState.Bounded env14729 := by
  intro p hp
  have h : env14729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14728_14729 : H12AffineEnvironment.transform 15 21510 env14728 = env14729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env14728 == env14729) = true)

theorem identity14729 : scanCanonicalize (H12AffineFastState.compose env14729 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14729 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env14730 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,21510,5392,10281,1024,1,4113,33,29724,21762,8192,17,2049,5393,12556,2341,28936,29740,256,8493,16385,513]

theorem envBound14730 : H12AffineFastState.Bounded env14730 := by
  intro p hp
  have h : env14730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14729_14730 : H12AffineEnvironment.transform 5 16 env14729 = env14730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14729 == env14730) = true)

theorem identity14730 : scanCanonicalize (H12AffineFastState.compose env14730 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14730 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14731 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,8202,5392,10281,1024,1,4113,33,16,8462,8192,17,2049,5393,12556,2341,1284,32,256,8493,13325,513]

theorem envBound14731 : H12AffineFastState.Bounded env14731 := by
  intro p hp
  have h : env14731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14730_14731 : H12AffineEnvironment.transform 13 13324 env14730 = env14731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14730 == env14731) = true)

theorem identity14731 : scanCanonicalize (H12AffineFastState.compose env14731 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound14731 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env14732 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,8192,8761,0,8202,805,10281,1024,1,1572,33,16,8462,8192,17,2049,804,10041,2341,1284,32,256,8493,8760,513]

theorem envBound14732 : H12AffineFastState.Bounded env14732 := by
  intro p hp
  have h : env14732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14731_14732 : H12AffineEnvironment.transform 11 1589 env14731 = env14732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env14731 == env14732) = true)

theorem identity14732 : scanCanonicalize (H12AffineFastState.compose env14732 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14732 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14733 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,268,821,0,262,805,2341,1024,1,1572,33,16,2,268,17,2049,804,1589,2341,1284,32,256,33,820,513]

theorem envBound14733 : H12AffineFastState.Bounded env14733 := by
  intro p hp
  have h : env14733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14732_14733 : H12AffineEnvironment.transform 12 268 env14732 = env14733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14732 == env14733) = true)

theorem identity14733 : scanCanonicalize (H12AffineFastState.compose env14733 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14733 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14734 : List Nat := [2,4,8,16,32,16,8,21,512,1024,2048,1589,25,544,0,19,560,2096,1024,1,1572,33,16,2,25,17,2049,561,1589,2096,1041,32,21,33,545,513]

theorem envBound14734 : H12AffineFastState.Bounded env14734 := by
  intro p hp
  have h : env14734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14733_14734 : H12AffineEnvironment.transform 7 21 env14733 = env14734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14733 == env14734) = true)

theorem identity14734 : scanCanonicalize (H12AffineFastState.compose env14734 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound14734 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14735 : List Nat := [2,4,8,16,32,16,8,21,512,1024,539,1589,25,544,0,19,560,555,1024,1,1572,33,16,2,25,17,538,561,1589,555,1041,32,21,33,545,513]

theorem envBound14735 : H12AffineFastState.Bounded env14735 := by
  intro p hp
  have h : env14735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14734_14735 : H12AffineEnvironment.transform 10 539 env14734 = env14735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env14734 == env14735) = true)

theorem identity14735 : scanCanonicalize (H12AffineFastState.compose env14735 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound14735 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14736 : List Nat := [2,4,8,16,32,16,8,21,17,1024,10,1060,25,49,0,19,33,58,1024,1,1077,33,16,2,25,17,11,32,1060,58,1041,32,21,33,48,16]

theorem envBound14736 : H12AffineFastState.Bounded env14736 := by
  intro p hp
  have h : env14736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14735_14736 : H12AffineEnvironment.transform 8 17 env14735 = env14736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env14735 == env14736) = true)

theorem identity14736 : scanCanonicalize (H12AffineFastState.compose env14736 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound14736 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14737 : List Nat := [2,4,8,16,32,16,8,21,17,14,10,42,25,49,0,19,33,58,14,1,59,33,16,2,25,17,11,32,42,58,31,32,21,33,48,16]

theorem envBound14737 : H12AffineFastState.Bounded env14737 := by
  intro p hp
  have h : env14737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14736_14737 : H12AffineEnvironment.transform 9 14 env14736 = env14737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env14736 == env14737) = true)

theorem identity14737 : scanCanonicalize (H12AffineFastState.compose env14737 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14737 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14738 : List Nat := [2,4,8,16,10,16,8,21,17,14,10,0,25,27,0,19,11,16,14,1,17,11,16,2,25,17,11,10,0,16,31,10,21,11,26,16]

theorem envBound14738 : H12AffineFastState.Bounded env14738 := by
  intro p hp
  have h : env14738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14737_14738 : H12AffineEnvironment.transform 4 10 env14737 = env14738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14737 == env14738) = true)

theorem identity14738 : scanCanonicalize (H12AffineFastState.compose env14738 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound14738 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14739 : List Nat := [2,1,8,16,10,16,8,16,17,11,10,0,25,27,0,19,11,16,11,1,17,11,16,2,25,17,11,10,0,16,26,10,16,11,26,16]

theorem envBound14739 : H12AffineFastState.Bounded env14739 := by
  intro p hp
  have h : env14739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14738_14739 : H12AffineEnvironment.transform 1 1 env14738 = env14739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env14738 == env14739) = true)

theorem identity14739 : scanCanonicalize (H12AffineFastState.compose env14739 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14739 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14740 : List Nat := [1,1,8,16,9,16,8,16,17,8,9,0,25,24,0,16,8,16,8,1,17,8,16,1,25,17,8,9,0,16,25,9,16,8,25,16]

theorem envBound14740 : H12AffineFastState.Bounded env14740 := by
  intro p hp
  have h : env14740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14739_14740 : H12AffineEnvironment.transform 0 1 env14739 = env14740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14739 == env14740) = true)

theorem identity14740 : scanCanonicalize (H12AffineFastState.compose env14740 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound14740 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env14741 : List Nat := [1,1,1,16,0,16,1,16,17,1,0,0,16,17,0,16,1,16,1,1,17,1,16,1,16,17,1,0,0,16,16,0,16,1,16,16]

theorem envBound14741 : H12AffineFastState.Bounded env14741 := by
  intro p hp
  have h : env14741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14740_14741 : H12AffineEnvironment.transform 2 1 env14740 = env14741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env14740 == env14741) = true)

def env14742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169265,62541,21762,8193,65,215367,115014,45405,35189,75103,243003,256,95531,103430,513]

theorem envBound14742 : H12AffineFastState.Bounded env14742 := by
  intro p hp
  have h : env14742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14725_14742 : H12AffineEnvironment.transform 6 9 env14725 = env14742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14725 == env14742) = true)

theorem identity14742 : scanCanonicalize (H12AffineFastState.compose env14742 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14742 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122147,1024,32769,4161,128298,62541,21762,8193,65,10588,115014,45405,35189,75103,54560,256,95531,103430,513]

theorem envBound14743 : H12AffineFastState.Bounded env14743 := by
  intro p hp
  have h : env14743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14742_14743 : H12AffineEnvironment.transform 16 90139 env14742 = env14743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14742 == env14743) = true)

theorem identity14743 : scanCanonicalize (H12AffineFastState.compose env14743 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 34147) := by decide +kernel

theorem selectedBound14743 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env14744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,34147,58744,22592,1024,32769,4161,28745,62541,21762,8193,65,10588,17445,45405,35189,41020,54560,256,61512,4453,513]

theorem envBound14744 : H12AffineFastState.Bounded env14744 := by
  intro p hp
  have h : env14744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14743_14744 : H12AffineEnvironment.transform 15 34147 env14743 = env14744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34147 env14743 == env14744) = true)

theorem identity14744 : scanCanonicalize (H12AffineFastState.compose env14744 (packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound14744 : packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS < 2^1333 := by decide +kernel

def env14745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,30073,28698,4097,22592,1024,30072,4161,28745,308,21762,8193,65,10588,17445,17444,31756,21829,8281,256,1329,4453,513]

theorem envBound14745 : H12AffineFastState.Bounded env14745 := by
  intro p hp
  have h : env14745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14744_14745 : H12AffineEnvironment.transform 14 30073 env14744 = env14745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env14744 == env14745) = true)

theorem identity14745 : scanCanonicalize (H12AffineFastState.compose env14745 (packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound14745 : packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env14746 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,16384,28956,28698,4097,22592,101,28957,4161,28745,308,20839,8193,65,10588,16448,16449,30825,20768,8281,256,340,4453,513]

theorem envBound14746 : H12AffineFastState.Bounded env14746 := by
  intro p hp
  have h : env14746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14745_14746 : H12AffineEnvironment.transform 9 101 env14745 = env14746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env14745 == env14746) = true)

theorem identity14746 : scanCanonicalize (H12AffineFastState.compose env14746 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14746 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14747 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,8192,16384,28776,28698,4097,22592,101,28777,4161,28745,64,20499,8193,65,10280,16448,16449,30825,20564,8281,116,32,4113,513]

theorem envBound14747 : H12AffineFastState.Bounded env14747 := by
  intro p hp
  have h : env14747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14746_14747 : H12AffineEnvironment.transform 7 116 env14746 = env14747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14746 == env14747) = true)

theorem identity14747 : scanCanonicalize (H12AffineFastState.compose env14747 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14747 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14748 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,40,16384,20544,20530,4097,22592,101,20545,4161,20577,64,20499,41,65,2048,16448,16449,22593,20564,113,116,32,4113,513]

theorem envBound14748 : H12AffineFastState.Bounded env14748 := by
  intro p hp
  have h : env14748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14747_14748 : H12AffineEnvironment.transform 12 40 env14747 = env14748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14747 == env14748) = true)

theorem identity14748 : scanCanonicalize (H12AffineFastState.compose env14748 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14748 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env14749 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,16384,20497,20530,4097,22545,52,20496,4112,20528,17,20499,41,16,2048,16401,16400,22544,20485,32,37,32,4113,513]

theorem envBound14749 : H12AffineFastState.Bounded env14749 := by
  intro p hp
  have h : env14749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14748_14749 : H12AffineEnvironment.transform 5 17 env14748 = env14749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14748 == env14749) = true)

theorem identity14749 : scanCanonicalize (H12AffineFastState.compose env14749 (packedSelected [3,4] rootPS)) = affineNative (2^(13+1) ^^^ 6177) := by decide +kernel

theorem selectedBound14749 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env14750 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,6177,2096,2067,4097,48,52,2097,4112,2065,17,2098,41,16,2048,6192,6193,49,2084,32,37,32,4113,513]

theorem envBound14750 : H12AffineFastState.Bounded env14750 := by
  intro p hp
  have h : env14750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14749_14750 : H12AffineEnvironment.transform 13 6177 env14749 = env14750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6177 env14749 == env14750) = true)

theorem identity14750 : scanCanonicalize (H12AffineFastState.compose env14750 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound14750 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env14751 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2561,40,544,2096,2067,2560,48,52,2097,2577,2065,17,2098,41,16,2048,561,560,49,2084,32,37,32,2576,513]

theorem envBound14751 : H12AffineFastState.Bounded env14751 := by
  intro p hp
  have h : env14751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14750_14751 : H12AffineEnvironment.transform 11 2561 env14750 = env14751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env14750 == env14751) = true)

theorem identity14751 : scanCanonicalize (H12AffineFastState.compose env14751 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound14751 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env14752 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,16,40,544,545,514,17,48,52,544,0,512,17,547,41,16,529,561,560,49,565,32,37,32,1,513]

theorem envBound14752 : H12AffineFastState.Bounded env14752 := by
  intro p hp
  have h : env14752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14751_14752 : H12AffineEnvironment.transform 10 529 env14751 = env14752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env14751 == env14752) = true)

theorem identity14752 : scanCanonicalize (H12AffineFastState.compose env14752 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound14752 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14753 : List Nat := [2,4,8,16,32,17,9,37,17,52,0,16,40,49,48,19,17,48,52,49,0,17,17,50,41,16,0,32,33,49,36,32,37,32,1,16]

theorem envBound14753 : H12AffineFastState.Bounded env14753 := by
  intro p hp
  have h : env14753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14752_14753 : H12AffineEnvironment.transform 8 17 env14752 = env14753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env14752 == env14753) = true)

theorem identity14753 : scanCanonicalize (H12AffineFastState.compose env14753 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14753 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14754 : List Nat := [2,4,8,16,17,17,9,20,17,5,0,16,25,0,1,19,17,1,5,0,0,17,17,3,24,16,0,17,16,0,21,17,20,17,1,16]

theorem envBound14754 : H12AffineFastState.Bounded env14754 := by
  intro p hp
  have h : env14754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14753_14754 : H12AffineEnvironment.transform 4 17 env14753 = env14754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14753 == env14754) = true)

theorem identity14754 : scanCanonicalize (H12AffineFastState.compose env14754 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14755 : List Nat := [2,4,8,1,0,0,9,5,0,5,0,1,8,0,1,2,0,1,5,0,0,0,0,3,9,1,0,0,1,0,4,0,5,0,1,1]

theorem envBound14755 : H12AffineFastState.Bounded env14755 := by
  intro p hp
  have h : env14755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14754_14755 : H12AffineEnvironment.transform 3 1 env14754 = env14755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14754 == env14755) = true)

def env14756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412021,2114883,8328,65,215366,115151,2497572,35189,2590758,2336242,256,510106,469310,2535409]

theorem envBound14756 : H12AffineFastState.Bounded env14756 := by
  intro p hp
  have h : env14756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14674_14756 : H12AffineEnvironment.transform 21 2262385 env14674 = env14756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env14674 == env14756) = true)

def env14757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,21763,8328,65,215366,115151,396388,35189,497766,243122,256,510106,469310,442289]

theorem envBound14757 : H12AffineFastState.Bounded env14757 := by
  intro p hp
  have h : env14757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14756_14757 : H12AffineEnvironment.transform 20 4160 env14756 = env14757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14756 == env14757) = true)

theorem identity14757 : scanCanonicalize (H12AffineFastState.compose env14757 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound14757 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,21763,8328,65,215366,115151,17665,35189,119043,243122,256,98815,90203,63188]

theorem envBound14758 : H12AffineFastState.Bounded env14758 := by
  intro p hp
  have h : env14758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14757_14758 : H12AffineEnvironment.transform 17 149861 env14757 = env14758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env14757 == env14758) = true)

def env14759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,21763,8192,65,215366,115015,17665,35189,119043,243002,256,98679,90203,63068]

theorem envBound14759 : H12AffineFastState.Bounded env14759 := by
  intro p hp
  have h : env14759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14758_14759 : H12AffineEnvironment.transform 6 8 env14758 = env14759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14758 == env14759) = true)

theorem identity14759 : scanCanonicalize (H12AffineFastState.compose env14759 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound14759 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56436,1024,32769,4160,32,16,21763,8192,65,121943,115015,17665,35189,119043,73771,256,98679,90203,63068]

theorem envBound14760 : H12AffineFastState.Bounded env14760 := by
  intro p hp
  have h : env14760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14759_14760 : H12AffineEnvironment.transform 16 38161 env14759 = env14760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env14759 == env14760) = true)

theorem identity14760 : scanCanonicalize (H12AffineFastState.compose env14760 (packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound14760 : packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env14761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30043,38161,56436,1024,32769,4160,32,16,21763,8192,65,43276,46108,17665,35189,42072,21872,256,62508,5376,63068]

theorem envBound14761 : H12AffineFastState.Bounded env14761 := by
  intro p hp
  have h : env14761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14760_14761 : H12AffineEnvironment.transform 15 30043 env14760 = env14761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env14760 == env14761) = true)

theorem identity14761 : scanCanonicalize (H12AffineFastState.compose env14761 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14761 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env14762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,30043,5392,23669,1024,0,4160,32,16,21763,8192,65,10509,13341,17665,2420,9305,21872,256,29741,5376,30301]

theorem envBound14762 : H12AffineFastState.Bounded env14762 := by
  intro p hp
  have h : env14762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14761_14762 : H12AffineEnvironment.transform 14 1 env14761 = env14762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14761 == env14762) = true)

theorem identity14762 : scanCanonicalize (H12AffineFastState.compose env14762 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14762 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env14763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,263,5392,10281,1024,0,4160,32,16,8543,8192,65,10509,13341,12637,2420,9305,8492,256,113,5376,513]

theorem envBound14763 : H12AffineFastState.Bounded env14763 := by
  intro p hp
  have h : env14763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14762_14763 : H12AffineEnvironment.transform 13 13404 env14762 = env14763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14762 == env14763) = true)

theorem identity14763 : scanCanonicalize (H12AffineFastState.compose env14763 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14763 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,263,5392,2341,1024,0,4160,32,16,83,268,65,2049,5393,4177,2420,1365,32,256,113,5376,513]

theorem envBound14764 : H12AffineFastState.Bounded env14764 := by
  intro p hp
  have h : env14764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14763_14764 : H12AffineEnvironment.transform 12 268 env14763 = env14764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14763 == env14764) = true)

theorem identity14764 : scanCanonicalize (H12AffineFastState.compose env14764 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14764 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14765 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4112,32,16,3,268,17,2049,5393,4097,2340,1285,32,256,33,5376,513]

theorem envBound14765 : H12AffineFastState.Bounded env14765 := by
  intro p hp
  have h : env14765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14764_14765 : H12AffineEnvironment.transform 5 16 env14764 = env14765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14764 == env14765) = true)

theorem identity14765 : scanCanonicalize (H12AffineFastState.compose env14765 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound14765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14766 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1044,268,276,1,263,260,2341,1024,0,1028,32,16,3,268,17,2049,261,1045,2340,1285,32,256,33,276,513]

theorem envBound14766 : H12AffineFastState.Bounded env14766 := by
  intro p hp
  have h : env14766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14765_14766 : H12AffineEnvironment.transform 11 1044 env14765 = env14766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env14765 == env14766) = true)

theorem identity14766 : scanCanonicalize (H12AffineFastState.compose env14766 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound14766 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14767 : List Nat := [2,4,8,16,32,16,8,256,512,784,2048,772,268,276,1,263,260,2341,784,0,788,32,16,3,268,17,2049,261,773,2340,533,32,256,33,276,513]

theorem envBound14767 : H12AffineFastState.Bounded env14767 := by
  intro p hp
  have h : env14767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14766_14767 : H12AffineEnvironment.transform 9 784 env14766 = env14767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env14766 == env14767) = true)

theorem identity14767 : scanCanonicalize (H12AffineFastState.compose env14767 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound14767 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14768 : List Nat := [2,4,8,16,32,16,8,256,512,784,804,772,268,276,1,263,260,513,784,0,788,32,16,3,268,17,805,261,773,512,533,32,256,33,276,513]

theorem envBound14768 : H12AffineFastState.Bounded env14768 := by
  intro p hp
  have h : env14768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14767_14768 : H12AffineEnvironment.transform 10 804 env14767 = env14768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env14767 == env14768) = true)

theorem identity14768 : scanCanonicalize (H12AffineFastState.compose env14768 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14768 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14769 : List Nat := [2,4,8,1,32,1,8,256,512,769,804,772,268,261,1,263,260,513,769,0,773,32,1,3,268,0,805,261,773,512,516,32,256,33,261,513]

theorem envBound14769 : H12AffineFastState.Bounded env14769 := by
  intro p hp
  have h : env14769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14768_14769 : H12AffineEnvironment.transform 3 1 env14768 = env14769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14768 == env14769) = true)

def env14770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,21763,8193,65,215366,115014,17665,35189,119043,243003,256,98678,90203,63069]

theorem envBound14770 : H12AffineFastState.Bounded env14770 := by
  intro p hp
  have h : env14770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14758_14770 : H12AffineEnvironment.transform 6 9 env14758 = env14770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14758 == env14770) = true)

theorem identity14770 : scanCanonicalize (H12AffineFastState.compose env14770 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound14770 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,32041,1024,32769,4160,41341,16,21763,8193,65,97546,115014,17665,35189,119043,98679,256,98678,90203,63069]

theorem envBound14771 : H12AffineFastState.Bounded env14771 := by
  intro p hp
  have h : env14771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14770_14771 : H12AffineEnvironment.transform 16 13388 env14770 = env14771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env14770 == env14771) = true)

theorem identity14771 : scanCanonicalize (H12AffineFastState.compose env14771 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14771 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14772 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,32768,65536,13388,31756,1024,32769,4160,41048,16,21542,8193,65,97327,114787,17444,34896,118822,98386,37,98387,90203,63069]

theorem envBound14772 : H12AffineFastState.Bounded env14772 := by
  intro p hp
  have h : env14772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14771_14772 : H12AffineEnvironment.transform 7 37 env14771 = env14772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14771 == env14772) = true)

theorem identity14772 : scanCanonicalize (H12AffineFastState.compose env14772 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound14772 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env14773 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8312,65536,13388,31756,1024,8313,4160,32,16,21542,8193,65,97327,90139,17444,10280,94302,73770,37,73771,90203,22053]

theorem envBound14773 : H12AffineFastState.Bounded env14773 := by
  intro p hp
  have h : env14773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14772_14773 : H12AffineEnvironment.transform 14 8312 env14772 = env14773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env14772 == env14773) = true)

theorem identity14773 : scanCanonicalize (H12AffineFastState.compose env14773 (packedSelected [0,1,2,3,5,6,7,8,10,12,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound14773 : packedSelected [0,1,2,3,5,6,7,8,10,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env14774 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8312,8282,13388,31756,1024,8313,4160,32,16,21542,8193,65,23669,16449,17444,10280,20484,112,37,113,16385,22053]

theorem envBound14774 : H12AffineFastState.Bounded env14774 := by
  intro p hp
  have h : env14774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14773_14774 : H12AffineEnvironment.transform 15 8282 env14773 = env14774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env14773 == env14774) = true)

theorem identity14774 : scanCanonicalize (H12AffineFastState.compose env14774 (packedSelected [16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14774 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14775 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,8233,8203,13341,31756,1024,8232,4113,32,16,21542,8193,16,23588,16400,17444,10280,20484,33,37,32,16385,22053]

theorem envBound14775 : H12AffineFastState.Bounded env14775 := by
  intro p hp
  have h : env14775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14774_14775 : H12AffineEnvironment.transform 5 17 env14774 = env14775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14774 == env14775) = true)

theorem identity14775 : scanCanonicalize (H12AffineFastState.compose env14775 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14775 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14776 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8192,16384,8201,8203,13341,31756,1024,8200,4113,0,16,21510,8193,16,23556,16400,17412,10248,20484,1,5,0,16385,22021]

theorem envBound14776 : H12AffineFastState.Bounded env14776 := by
  intro p hp
  have h : env14776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14775_14776 : H12AffineEnvironment.transform 4 0 env14775 = env14776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14775 == env14776) = true)

theorem identity14776 : scanCanonicalize (H12AffineFastState.compose env14776 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound14776 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14777 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,9,16384,0,2,5140,23557,1024,1,4113,0,16,21510,8,16,23556,16400,17412,2049,20484,1,5,0,16385,22021]

theorem envBound14777 : H12AffineFastState.Bounded env14777 := by
  intro p hp
  have h : env14777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14776_14777 : H12AffineEnvironment.transform 12 9 env14776 = env14777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env14776 == env14777) = true)

theorem identity14777 : scanCanonicalize (H12AffineFastState.compose env14777 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound14777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14778 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,9,1028,0,2,5140,6145,1024,1,4113,0,16,4098,8,16,6144,1044,0,2049,5120,1,5,0,1029,4609]

theorem envBound14778 : H12AffineFastState.Bounded env14778 := by
  intro p hp
  have h : env14778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14777_14778 : H12AffineEnvironment.transform 13 1028 env14777 = env14778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env14777 == env14778) = true)

theorem identity14778 : scanCanonicalize (H12AffineFastState.compose env14778 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound14778 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14779 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,2561,9,1028,0,2,3605,512,1024,1,2576,0,16,2563,8,16,513,1044,0,2049,3585,1,5,0,1029,2048]

theorem envBound14779 : H12AffineFastState.Bounded env14779 := by
  intro p hp
  have h : env14779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14778_14779 : H12AffineEnvironment.transform 11 2561 env14778 = env14779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env14778 == env14779) = true)

theorem identity14779 : scanCanonicalize (H12AffineFastState.compose env14779 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound14779 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14780 : List Nat := [2,4,8,16,0,17,9,5,512,1024,513,0,9,1028,0,2,1044,512,1024,1,17,0,16,2,8,16,513,1044,0,512,1024,1,5,0,1029,513]

theorem envBound14780 : H12AffineFastState.Bounded env14780 := by
  intro p hp
  have h : env14780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14779_14780 : H12AffineEnvironment.transform 10 513 env14779 = env14780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env14779 == env14780) = true)

theorem identity14780 : scanCanonicalize (H12AffineFastState.compose env14780 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound14780 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14781 : List Nat := [2,4,8,16,0,17,9,5,512,532,513,0,9,528,0,2,512,512,532,1,17,0,16,2,8,16,513,512,0,512,532,1,5,0,529,513]

theorem envBound14781 : H12AffineFastState.Bounded env14781 := by
  intro p hp
  have h : env14781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14780_14781 : H12AffineEnvironment.transform 9 532 env14780 = env14781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env14780 == env14781) = true)

theorem identity14781 : scanCanonicalize (H12AffineFastState.compose env14781 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound14781 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14782 : List Nat := [2,4,8,16,0,17,9,5,16,4,17,0,9,0,0,2,16,16,4,1,17,0,16,2,8,16,17,16,0,16,4,1,5,0,1,17]

theorem envBound14782 : H12AffineFastState.Bounded env14782 := by
  intro p hp
  have h : env14782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14781_14782 : H12AffineEnvironment.transform 8 16 env14781 = env14782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env14781 == env14782) = true)

theorem identity14782 : scanCanonicalize (H12AffineFastState.compose env14782 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14782 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14783 : List Nat := [2,4,8,1,0,0,9,5,1,4,0,0,9,0,0,2,1,1,4,1,0,0,1,2,8,1,0,1,0,1,4,1,5,0,1,0]

theorem envBound14783 : H12AffineFastState.Bounded env14783 := by
  intro p hp
  have h : env14783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14782_14783 : H12AffineEnvironment.transform 3 1 env14782 = env14783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14782 == env14783) = true)

theorem identity14783 : scanCanonicalize (H12AffineFastState.compose env14783 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14783 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14784 : List Nat := [2,4,3,1,0,0,2,5,1,4,0,0,2,0,0,2,1,1,4,1,0,0,1,2,3,1,0,1,0,1,4,1,5,0,1,0]

theorem envBound14784 : H12AffineFastState.Bounded env14784 := by
  intro p hp
  have h : env14784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14783_14784 : H12AffineEnvironment.transform 2 3 env14783 = env14784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14783 == env14784) = true)

def env14785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,21762,8328,65,215366,115151,396389,35189,497767,243123,256,510106,469310,442288]

theorem envBound14785 : H12AffineFastState.Bounded env14785 := by
  intro p hp
  have h : env14785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14756_14785 : H12AffineEnvironment.transform 20 4161 env14756 = env14785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14756 == env14785) = true)

theorem identity14785 : scanCanonicalize (H12AffineFastState.compose env14785 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound14785 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,156132,412021,21762,8328,65,215366,79131,396389,32161,486579,213351,256,474190,469310,412516]

theorem envBound14786 : H12AffineFastState.Bounded env14786 := by
  intro p hp
  have h : env14786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14785_14786 : H12AffineEnvironment.transform 14 29908 env14785 = env14786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env14785 == env14786) = true)

def env14787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,4161,156132,156117,21762,8328,65,215366,79131,140485,32161,214035,213351,256,201966,197022,156612]

theorem envBound14787 : H12AffineFastState.Bounded env14787 := by
  intro p hp
  have h : env14787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14786_14787 : H12AffineEnvironment.transform 17 10400 env14786 = env14787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env14786 == env14787) = true)

theorem identity14787 : scanCanonicalize (H12AffineFastState.compose env14787 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound14787 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,65536,131072,10400,1024,136,4161,136633,136584,8543,8328,65,212251,79131,140485,2556,208974,210234,256,201966,197022,137113]

theorem envBound14788 : H12AffineFastState.Bounded env14788 := by
  intro p hp
  have h : env14788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14787_14788 : H12AffineEnvironment.transform 13 13405 env14787 = env14788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env14787 == env14788) = true)

theorem identity14788 : scanCanonicalize (H12AffineFastState.compose env14788 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14788 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env14789 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13405,137,65536,131072,10400,1024,136,4161,136396,136445,8234,8328,65,212078,78958,140485,2185,208974,209999,117,201966,196843,136940]

theorem envBound14789 : H12AffineFastState.Bounded env14789 := by
  intro p hp
  have h : env14789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14788_14789 : H12AffineEnvironment.transform 7 117 env14788 = env14789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14788 == env14789) = true)

theorem identity14789 : scanCanonicalize (H12AffineFastState.compose env14789 (packedSelected [2,6,7,9,11,17,18,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14789 : packedSelected [2,6,7,9,11,17,18,20,22,27] rootPS < 2^1333 := by decide +kernel

def env14790 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13405,137,171,131072,10400,1024,136,4161,136396,136445,8234,8328,65,146629,13509,140485,2185,143589,144612,117,136261,131136,136940]

theorem envBound14790 : H12AffineFastState.Bounded env14790 := by
  intro p hp
  have h : env14790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14789_14790 : H12AffineEnvironment.transform 15 171 env14789 = env14790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14789 == env14790) = true)

def env14791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,4161,156132,156116,21762,8328,65,215366,79131,140484,32161,214034,213351,256,201967,197023,156613]

theorem envBound14791 : H12AffineFastState.Bounded env14791 := by
  intro p hp
  have h : env14791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14786_14791 : H12AffineEnvironment.transform 17 10401 env14786 = env14791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env14786 == env14791) = true)

theorem identity14791 : scanCanonicalize (H12AffineFastState.compose env14791 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound14791 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25028,10401,1024,29909,4161,32,16,21762,8328,65,75906,79131,17664,32161,75222,73891,256,95531,90203,513]

theorem envBound14792 : H12AffineFastState.Bounded env14792 := by
  intro p hp
  have h : env14792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14791_14792 : H12AffineEnvironment.transform 16 25028 env14791 = env14792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env14791 == env14792) = true)

theorem identity14792 : scanCanonicalize (H12AffineFastState.compose env14792 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound14792 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env14793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,25028,10401,1024,29909,4161,32,16,21762,8328,65,23808,16537,17664,32161,20564,21793,256,169,5593,513]

theorem envBound14793 : H12AffineFastState.Bounded env14793 := by
  intro p hp
  have h : env14793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14792_14793 : H12AffineEnvironment.transform 15 30082 env14792 = env14793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env14792 == env14793) = true)

theorem identity14793 : scanCanonicalize (H12AffineFastState.compose env14793 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14793 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env14794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,30082,24980,10401,1024,29829,4113,32,16,21762,8328,17,23808,16537,17664,32161,20484,21793,256,169,5513,513]

theorem envBound14794 : H12AffineFastState.Bounded env14794 := by
  intro p hp
  have h : env14794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14793_14794 : H12AffineEnvironment.transform 5 16 env14793 = env14794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14793 == env14794) = true)

theorem identity14794 : scanCanonicalize (H12AffineFastState.compose env14794 (packedSelected [0,1,2,6,7,8,10,12,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14794 : packedSelected [0,1,2,6,7,8,10,12,14,17,18] rootPS < 2^1333 := by decide +kernel

def env14795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,21510,16400,2341,1024,21761,4113,32,16,21762,268,17,23808,16537,17664,23589,20484,21793,256,169,5513,513]

theorem envBound14795 : H12AffineFastState.Bounded env14795 := by
  intro p hp
  have h : env14795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14794_14795 : H12AffineEnvironment.transform 12 388 env14794 = env14795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14794 == env14795) = true)

theorem identity14795 : scanCanonicalize (H12AffineFastState.compose env14795 (packedSelected [2,6,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14795 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env14796 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,21510,16400,2341,1024,21761,4113,32,16,21762,268,17,23808,16401,17664,23589,20484,21793,256,33,5377,513]

theorem envBound14796 : H12AffineFastState.Bounded env14796 := by
  intro p hp
  have h : env14796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14795_14796 : H12AffineEnvironment.transform 6 8 env14795 = env14796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14795 == env14796) = true)

theorem identity14796 : scanCanonicalize (H12AffineFastState.compose env14796 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14796 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14797 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2341,1024,1,4113,32,16,2,268,17,2048,5393,4096,2341,1284,33,256,33,5377,513]

theorem envBound14797 : H12AffineFastState.Bounded env14797 := by
  intro p hp
  have h : env14797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14796_14797 : H12AffineEnvironment.transform 13 5376 env14796 = env14797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14796 == env14797) = true)

theorem identity14797 : scanCanonicalize (H12AffineFastState.compose env14797 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14798 : List Nat := [2,4,8,0,32,0,8,256,512,1024,2048,4096,268,5376,0,262,5376,2341,1024,1,4097,32,0,2,268,1,2048,5377,4096,2341,1284,33,256,33,5377,513]

theorem envBound14798 : H12AffineFastState.Bounded env14798 := by
  intro p hp
  have h : env14798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14797_14798 : H12AffineEnvironment.transform 3 0 env14797 = env14798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14797 == env14798) = true)

theorem identity14798 : scanCanonicalize (H12AffineFastState.compose env14798 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound14798 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14799 : List Nat := [2,4,8,0,32,0,8,256,512,1024,1070,4096,268,5376,0,262,5376,1291,1024,1,4097,32,0,2,268,1,1070,5377,4096,1291,1284,33,256,33,5377,513]

theorem envBound14799 : H12AffineFastState.Bounded env14799 := by
  intro p hp
  have h : env14799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14798_14799 : H12AffineEnvironment.transform 10 1070 env14798 = env14799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env14798 == env14799) = true)

theorem identity14799 : scanCanonicalize (H12AffineFastState.compose env14799 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14799 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14800 : List Nat := [2,4,8,0,0,0,8,256,512,1024,1038,4096,268,5376,0,262,5376,1291,1024,1,4097,0,0,2,268,1,1038,5377,4096,1291,1284,1,256,1,5377,513]

theorem envBound14800 : H12AffineFastState.Bounded env14800 := by
  intro p hp
  have h : env14800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14799_14800 : H12AffineEnvironment.transform 4 0 env14799 = env14800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14799 == env14800) = true)

theorem identity14800 : scanCanonicalize (H12AffineFastState.compose env14800 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14800 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14801 : List Nat := [2,4,3,0,0,0,3,256,512,1024,1029,4096,263,5376,0,262,5376,1280,1024,1,4097,0,0,2,263,1,1029,5377,4096,1280,1284,1,256,1,5377,513]

theorem envBound14801 : H12AffineFastState.Bounded env14801 := by
  intro p hp
  have h : env14801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14800_14801 : H12AffineEnvironment.transform 2 3 env14800 = env14801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14800 == env14801) = true)

theorem identity14801 : scanCanonicalize (H12AffineFastState.compose env14801 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound14801 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14802 : List Nat := [2,4,3,0,0,0,3,256,512,1024,1029,1029,263,261,0,262,261,1280,1024,1,1028,0,0,2,263,1,1029,260,1029,1280,1284,1,256,1,260,513]

theorem envBound14802 : H12AffineFastState.Bounded env14802 := by
  intro p hp
  have h : env14802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14801_14802 : H12AffineEnvironment.transform 11 1029 env14801 = env14802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env14801 == env14802) = true)

theorem identity14802 : scanCanonicalize (H12AffineFastState.compose env14802 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound14802 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14803 : List Nat := [2,4,3,0,0,0,3,256,512,256,261,261,263,261,0,262,261,0,256,1,260,0,0,2,263,1,261,260,261,0,4,1,256,1,260,513]

theorem envBound14803 : H12AffineFastState.Bounded env14803 := by
  intro p hp
  have h : env14803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14802_14803 : H12AffineEnvironment.transform 9 256 env14802 = env14803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env14802 == env14803) = true)

theorem identity14803 : scanCanonicalize (H12AffineFastState.compose env14803 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 262) := by decide +kernel

theorem selectedBound14803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14804 : List Nat := [2,4,3,0,0,0,3,256,262,256,261,261,263,261,0,262,261,0,256,1,260,0,0,2,263,1,261,260,261,0,4,1,256,1,260,263]

theorem envBound14804 : H12AffineFastState.Bounded env14804 := by
  intro p hp
  have h : env14804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14803_14804 : H12AffineEnvironment.transform 8 262 env14803 = env14804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 262 env14803 == env14804) = true)

theorem identity14804 : scanCanonicalize (H12AffineFastState.compose env14804 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14804 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env14805 : List Nat := [2,4,3,0,0,0,3,5,3,5,0,0,2,0,0,3,0,0,5,1,1,0,0,2,2,1,0,1,0,0,4,1,5,1,1,2]

theorem envBound14805 : H12AffineFastState.Bounded env14805 := by
  intro p hp
  have h : env14805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14804_14805 : H12AffineEnvironment.transform 7 5 env14804 = env14805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14804 == env14805) = true)

theorem identity14805 : scanCanonicalize (H12AffineFastState.compose env14805 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound14805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14806 : List Nat := [2,1,3,0,0,0,3,0,3,0,0,0,2,0,0,3,0,0,0,1,1,0,0,2,2,1,0,1,0,0,1,1,0,1,1,2]

theorem envBound14806 : H12AffineFastState.Bounded env14806 := by
  intro p hp
  have h : env14806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14805_14806 : H12AffineEnvironment.transform 1 1 env14805 = env14806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env14805 == env14806) = true)

def env14807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound14807 : H12AffineFastState.Bounded env14807 := by
  intro p hp
  have h : env14807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14598_14807 : H12AffineEnvironment.transform 18 1025 env14598 = env14807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14598 == env14807) = true)

theorem identity14807 : scanCanonicalize (H12AffineFastState.compose env14807 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388279) := by decide +kernel

theorem selectedBound14807 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,4194304,8388608,16777216,8328,65,29868032,17066042,8763878,8830977,25265168,21268855,257,25438234,25479615,25207750]

theorem envBound14808 : H12AffineFastState.Bounded env14808 := by
  intro p hp
  have h : env14808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14807_14808 : H12AffineEnvironment.transform 20 388279 env14807 = env14808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388279 env14807 == env14808) = true)

def env14809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,4194304,8388608,351520,8328,65,12754208,79130,8763878,8830977,8706352,4314199,257,8484154,8492191,8781542]

theorem envBound14809 : H12AffineFastState.Bounded env14809 := by
  intro p hp
  have h : env14809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14808_14809 : H12AffineEnvironment.transform 23 351520 env14808 = env14809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351520 env14808 == env14809) = true)

def env14810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,8388608,95496,8328,65,12754208,79130,8491470,8579113,8450328,4314199,257,8484154,8492191,8509134]

theorem envBound14810 : H12AffineFastState.Bounded env14810 := by
  intro p hp
  have h : env14810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14809_14810 : H12AffineEnvironment.transform 17 10280 env14809 = env14810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14809 == env14810) = true)

def env14811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,16,95496,8328,65,4365616,79130,102878,190521,61704,4314199,257,95530,103567,120542]

theorem envBound14811 : H12AffineFastState.Bounded env14811 := by
  intro p hp
  have h : env14811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14810_14811 : H12AffineEnvironment.transform 22 16 env14810 = env14811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14810 == env14811) = true)

theorem identity14811 : scanCanonicalize (H12AffineFastState.compose env14811 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound14811 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,73891,16,95496,8328,65,245139,79130,102878,190521,61704,62708,257,95530,103567,120542]

theorem envBound14812 : H12AffineFastState.Bounded env14812 := by
  intro p hp
  have h : env14812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14811_14812 : H12AffineEnvironment.transform 21 73891 env14811 = env14812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env14811 == env14812) = true)

theorem identity14812 : scanCanonicalize (H12AffineFastState.compose env14812 (packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 103631) := by decide +kernel

theorem selectedBound14812 : packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env14813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103631,10280,1025,32769,115871,73891,16,95496,8328,65,10588,79130,102878,97526,61704,62708,257,95530,103567,120542]

theorem envBound14813 : H12AffineFastState.Bounded env14813 := by
  intro p hp
  have h : env14813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14812_14813 : H12AffineEnvironment.transform 16 103631 env14812 = env14813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103631 env14812 == env14813) = true)

def env14814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103495,10280,1025,32769,115735,73771,16,95496,8192,65,10588,79130,102742,97406,61704,62588,257,95530,103431,120406]

theorem envBound14814 : H12AffineFastState.Bounded env14814 := by
  intro p hp
  have h : env14814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14813_14814 : H12AffineEnvironment.transform 6 8 env14813 = env14814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14813 == env14814) = true)

theorem identity14814 : scanCanonicalize (H12AffineFastState.compose env14814 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14814 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,57676,10280,1025,32769,45340,21792,16,3,8192,65,10588,16401,58461,2421,61704,62588,257,33,57612,41821]

theorem envBound14815 : H12AffineFastState.Bounded env14815 := by
  intro p hp
  have h : env14815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14814_14815 : H12AffineEnvironment.transform 15 29963 env14814 = env14815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14814 == env14815) = true)

theorem identity14815 : scanCanonicalize (H12AffineFastState.compose env14815 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound14815 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,5392,10280,1025,29789,17728,21792,16,3,8192,65,10588,16401,4097,2421,1364,32,257,33,5456,22273]

theorem envBound14816 : H12AffineFastState.Bounded env14816 := by
  intro p hp
  have h : env14816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14815_14816 : H12AffineEnvironment.transform 14 29788 env14815 = env14816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env14815 == env14816) = true)

theorem identity14816 : scanCanonicalize (H12AffineFastState.compose env14816 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14816 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env14817 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,29822,5221,10280,1025,29789,17461,21589,16,3,8192,65,10281,16401,4097,2048,1057,32,116,33,5157,22132]

theorem envBound14817 : H12AffineFastState.Bounded env14817 := by
  intro p hp
  have h : env14817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14816_14817 : H12AffineEnvironment.transform 7 117 env14816 = env14817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14816 == env14817) = true)

theorem identity14817 : scanCanonicalize (H12AffineFastState.compose env14817 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound14817 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env14818 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,3148,16384,22544,22578,5221,1124,1025,22545,17461,21589,16,3,3148,65,1125,16401,4097,2048,1057,32,116,33,5157,22132]

theorem envBound14818 : H12AffineFastState.Bounded env14818 := by
  intro p hp
  have h : env14818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14817_14818 : H12AffineEnvironment.transform 12 3148 env14817 = env14818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env14817 == env14818) = true)

theorem identity14818 : scanCanonicalize (H12AffineFastState.compose env14818 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1124) := by decide +kernel

theorem selectedBound14818 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env14819 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,3148,1124,7284,7254,5221,1124,1025,7285,81,4145,16,3,3148,65,1125,1141,4097,2048,1057,32,116,33,5157,4624]

theorem envBound14819 : H12AffineFastState.Bounded env14819 := by
  intro p hp
  have h : env14819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14818_14819 : H12AffineEnvironment.transform 13 1124 env14818 = env14819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1124 env14818 == env14819) = true)

theorem identity14819 : scanCanonicalize (H12AffineFastState.compose env14819 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound14819 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env14820 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,4096,121,1124,4161,4195,5221,1124,1025,4160,81,4145,16,3,121,65,1125,1141,4097,1077,1057,32,116,33,5157,4624]

theorem envBound14820 : H12AffineFastState.Bounded env14820 := by
  intro p hp
  have h : env14820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14819_14820 : H12AffineEnvironment.transform 10 1077 env14819 = env14820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env14819 == env14820) = true)

theorem identity14820 : scanCanonicalize (H12AffineFastState.compose env14820 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound14820 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env14821 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,17,121,1124,80,114,1140,1124,1025,81,81,32,16,3,121,65,1125,1141,16,1077,1057,32,116,33,1076,513]

theorem envBound14821 : H12AffineFastState.Bounded env14821 := by
  intro p hp
  have h : env14821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14820_14821 : H12AffineEnvironment.transform 11 17 env14820 = env14821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14820 == env14821) = true)

theorem identity14821 : scanCanonicalize (H12AffineFastState.compose env14821 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound14821 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14822 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,17,121,1,80,114,17,1,100,81,81,32,16,3,121,65,0,16,16,80,68,32,116,33,81,513]

theorem envBound14822 : H12AffineFastState.Bounded env14822 := by
  intro p hp
  have h : env14822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14821_14822 : H12AffineEnvironment.transform 9 101 env14821 = env14822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env14821 == env14822) = true)

theorem identity14822 : scanCanonicalize (H12AffineFastState.compose env14822 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound14822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14823 : List Nat := [2,4,8,16,32,64,8,117,81,101,80,17,121,1,80,114,17,1,100,81,81,32,16,3,121,65,0,16,16,80,68,32,116,33,81,80]

end H12CloudChart0