import H12CloudChart0Data099

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans25309_25310 : H12AffineEnvironment.transform 5 16 env25309 = env25310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25309 == env25310) = true)

def env25311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4160,73771,119879,21763,8193,64,64604,115014,102743,35189,1365,32,257,21793,46092,74251]

theorem envBound25311 : H12AffineFastState.Bounded env25311 := by
  intro p hp
  have h : env25311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25302_25311 : H12AffineEnvironment.transform 6 9 env25302 = env25311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25302 == env25311) = true)

theorem identity25311 : scanCanonicalize (H12AffineFastState.compose env25311 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1025,32769,4160,33,62541,21763,8193,64,64604,57676,45405,35189,1365,32,257,21793,46092,513]

theorem envBound25312 : H12AffineFastState.Bounded env25312 := by
  intro p hp
  have h : env25312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25311_25312 : H12AffineEnvironment.transform 15 8202 env25311 = env25312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25311 == env25312) = true)

theorem identity25312 : scanCanonicalize (H12AffineFastState.compose env25312 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25312 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env25313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,38161,2420,1025,32769,4160,33,54544,21763,348,64,56577,49169,36864,35189,1365,32,257,21793,38225,513]

theorem envBound25313 : H12AffineFastState.Bounded env25313 := by
  intro p hp
  have h : env25313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25312_25313 : H12AffineEnvironment.transform 12 349 env25312 = env25313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25312 == env25313) = true)

theorem identity25313 : scanCanonicalize (H12AffineFastState.compose env25313 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound25313 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,16400,2420,1025,21760,4160,33,17,21763,348,64,2048,5392,17665,23668,1365,32,257,21793,16464,513]

theorem envBound25314 : H12AffineFastState.Bounded env25314 := by
  intro p hp
  have h : env25314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25313_25314 : H12AffineEnvironment.transform 14 21761 env25313 = env25314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25313 == env25314) = true)

theorem identity25314 : scanCanonicalize (H12AffineFastState.compose env25314 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25314 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25315 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,263,16400,2340,1025,21760,4112,33,17,21763,268,16,2048,5392,17665,23588,1285,32,257,21793,16384,513]

theorem envBound25315 : H12AffineFastState.Bounded env25315 := by
  intro p hp
  have h : env25315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25314_25315 : H12AffineEnvironment.transform 5 16 env25314 = env25315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25314 == env25315) = true)

theorem identity25315 : scanCanonicalize (H12AffineFastState.compose env25315 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound25315 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25316 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,2048,7425,263,2064,2340,1025,7424,4112,33,17,7427,268,16,2048,5392,3329,5156,1285,32,257,7457,2048,513]

theorem envBound25316 : H12AffineFastState.Bounded env25316 := by
  intro p hp
  have h : env25316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25315_25316 : H12AffineEnvironment.transform 13 2048 env25315 = env25316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env25315 == env25316) = true)

theorem identity25316 : scanCanonicalize (H12AffineFastState.compose env25316 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound25316 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env25317 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1819,4096,269,1819,4634,263,1803,1599,1025,4635,4112,33,17,4632,268,16,1819,5392,538,5156,1285,32,257,4666,1819,513]

theorem envBound25317 : H12AffineFastState.Bounded env25317 := by
  intro p hp
  have h : env25317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25316_25317 : H12AffineEnvironment.transform 10 1819 env25316 = env25317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env25316 == env25317) = true)

theorem identity25317 : scanCanonicalize (H12AffineFastState.compose env25317 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25317 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env25318 : List Nat := [2,4,8,16,32,16,9,256,512,52,815,4096,269,815,4634,263,831,523,53,4635,4112,33,17,4632,268,16,815,4388,538,4112,305,32,257,4666,815,513]

theorem envBound25318 : H12AffineFastState.Bounded env25318 := by
  intro p hp
  have h : env25318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25317_25318 : H12AffineEnvironment.transform 9 52 env25317 = env25318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25317 == env25318) = true)

theorem identity25318 : scanCanonicalize (H12AffineFastState.compose env25318 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 830) := by decide +kernel

theorem selectedBound25318 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25319 : List Nat := [2,4,8,16,32,16,9,256,512,52,815,830,269,815,292,263,831,523,53,293,814,33,17,294,268,16,815,538,538,814,305,32,257,260,815,513]

theorem envBound25319 : H12AffineFastState.Bounded env25319 := by
  intro p hp
  have h : env25319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25318_25319 : H12AffineEnvironment.transform 11 830 env25318 = env25319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 830 env25318 == env25319) = true)

theorem identity25319 : scanCanonicalize (H12AffineFastState.compose env25319 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound25319 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25320 : List Nat := [2,4,8,16,32,16,9,256,42,52,261,276,269,261,292,263,277,33,53,293,260,33,17,294,268,16,261,48,48,260,305,32,257,260,261,43]

theorem envBound25320 : H12AffineFastState.Bounded env25320 := by
  intro p hp
  have h : env25320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25319_25320 : H12AffineEnvironment.transform 8 42 env25319 = env25320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env25319 == env25320) = true)

theorem identity25320 : scanCanonicalize (H12AffineFastState.compose env25320 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound25320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25321 : List Nat := [2,4,8,16,32,16,9,6,42,52,3,18,11,3,34,1,19,33,53,35,2,33,17,32,10,16,3,48,48,2,55,32,7,2,3,43]

theorem envBound25321 : H12AffineFastState.Bounded env25321 := by
  intro p hp
  have h : env25321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25320_25321 : H12AffineEnvironment.transform 7 6 env25320 = env25321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env25320 == env25321) = true)

theorem identity25321 : scanCanonicalize (H12AffineFastState.compose env25321 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound25321 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env25322 : List Nat := [2,4,8,16,2,16,9,6,8,22,3,18,11,3,0,1,19,3,23,1,2,3,17,2,10,16,3,18,18,2,21,2,7,2,3,9]

theorem envBound25322 : H12AffineFastState.Bounded env25322 := by
  intro p hp
  have h : env25322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25321_25322 : H12AffineEnvironment.transform 4 2 env25321 = env25322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env25321 == env25322) = true)

theorem identity25322 : scanCanonicalize (H12AffineFastState.compose env25322 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound25322 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25323 : List Nat := [2,4,8,15,2,15,9,6,8,9,3,13,11,3,0,1,12,3,8,1,2,3,14,2,10,15,3,13,13,2,10,2,7,2,3,9]

theorem envBound25323 : H12AffineFastState.Bounded env25323 := by
  intro p hp
  have h : env25323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25322_25323 : H12AffineEnvironment.transform 3 15 env25322 = env25323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env25322 == env25323) = true)

theorem identity25323 : scanCanonicalize (H12AffineFastState.compose env25323 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound25323 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25324 : List Nat := [0,4,8,13,0,13,9,4,8,9,1,13,9,1,0,1,12,1,8,1,0,1,12,0,8,13,1,13,13,0,8,0,5,0,1,9]

theorem envBound25324 : H12AffineFastState.Bounded env25324 := by
  intro p hp
  have h : env25324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25323_25324 : H12AffineEnvironment.transform 0 0 env25323 = env25324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env25323 == env25324) = true)

def env25325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10401,1025,32769,4160,73770,120014,21763,8328,64,64604,115151,102878,35188,1500,168,257,21793,46213,74251]

theorem envBound25325 : H12AffineFastState.Bounded env25325 := by
  intro p hp
  have h : env25325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25301_25325 : H12AffineEnvironment.transform 17 10401 env25301 = env25325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env25301 == env25325) = true)

def env25326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4160,73770,119878,21763,8192,64,64604,115015,102742,35188,1364,32,257,21793,46093,74251]

theorem envBound25326 : H12AffineFastState.Bounded env25326 := by
  intro p hp
  have h : env25326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25325_25326 : H12AffineEnvironment.transform 6 8 env25325 = env25326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25325 == env25326) = true)

theorem identity25326 : scanCanonicalize (H12AffineFastState.compose env25326 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111899,10281,1025,32769,4160,73770,98631,2,8192,64,43357,103494,102742,35188,1364,32,257,32,46093,74251]

theorem envBound25327 : H12AffineFastState.Bounded env25327 := by
  intro p hp
  have h : env25327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25326_25327 : H12AffineEnvironment.transform 13 5377 env25326 = env25327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25326 == env25327) = true)

theorem identity25327 : scanCanonicalize (H12AffineFastState.compose env25327 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25327 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,32768,65536,103730,2048,1025,32769,4160,65539,98631,2,41,64,35188,103494,102742,35188,1364,32,257,32,37924,66082]

theorem envBound25328 : H12AffineFastState.Bounded env25328 := by
  intro p hp
  have h : env25328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25327_25328 : H12AffineEnvironment.transform 12 41 env25327 = env25328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25327 == env25328) = true)

theorem identity25328 : scanCanonicalize (H12AffineFastState.compose env25328 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound25328 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env25329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,0,65536,70962,2048,1025,1,4160,65539,65863,2,41,64,2420,70726,69974,2420,1364,32,257,32,5156,66082]

theorem envBound25329 : H12AffineFastState.Bounded env25329 := by
  intro p hp
  have h : env25329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25328_25329 : H12AffineEnvironment.transform 14 0 env25328 = env25329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env25328 == env25329) = true)

theorem identity25329 : scanCanonicalize (H12AffineFastState.compose env25329 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound25329 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,0,35,5393,2048,1025,1,4160,32,356,2,41,64,2420,5221,4469,2420,1364,32,257,32,5156,513]

theorem envBound25330 : H12AffineFastState.Bounded env25330 := by
  intro p hp
  have h : env25330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25329_25330 : H12AffineEnvironment.transform 15 35 env25329 = env25330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env25329 == env25330) = true)

theorem identity25330 : scanCanonicalize (H12AffineFastState.compose env25330 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25330 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env25331 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1025,1,4160,32,64,2,41,64,2128,5221,4177,2128,1136,32,37,32,5156,513]

theorem envBound25331 : H12AffineFastState.Bounded env25331 := by
  intro p hp
  have h : env25331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25330_25331 : H12AffineEnvironment.transform 7 36 env25330 = env25331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25330 == env25331) = true)

theorem identity25331 : scanCanonicalize (H12AffineFastState.compose env25331 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25331 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25332 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1025,1,4112,32,16,2,41,16,2048,5173,4097,2048,1056,32,37,32,5156,513]

theorem envBound25332 : H12AffineFastState.Bounded env25332 := by
  intro p hp
  have h : env25332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25331_25332 : H12AffineEnvironment.transform 5 16 env25331 = env25332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25331 == env25332) = true)

theorem identity25332 : scanCanonicalize (H12AffineFastState.compose env25332 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound25332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25333 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,0,41,1061,0,35,1077,2048,1025,1,16,32,16,2,41,16,2048,1077,1,2048,1056,32,37,32,1060,513]

theorem envBound25333 : H12AffineFastState.Bounded env25333 := by
  intro p hp
  have h : env25333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25332_25333 : H12AffineEnvironment.transform 11 0 env25332 = env25333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env25332 == env25333) = true)

theorem identity25333 : scanCanonicalize (H12AffineFastState.compose env25333 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound25333 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25334 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1087,0,41,1061,0,35,1077,1087,1025,1,16,32,16,2,41,16,1087,1077,1,1087,1056,32,37,32,1060,513]

theorem envBound25334 : H12AffineFastState.Bounded env25334 := by
  intro p hp
  have h : env25334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25333_25334 : H12AffineEnvironment.transform 10 1087 env25333 = env25334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env25333 == env25334) = true)

theorem identity25334 : scanCanonicalize (H12AffineFastState.compose env25334 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25334 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25335 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1055,0,9,1029,0,3,1045,1055,1025,1,16,0,16,2,9,16,1055,1045,1,1055,1024,0,5,0,1028,513]

theorem envBound25335 : H12AffineFastState.Bounded env25335 := by
  intro p hp
  have h : env25335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25334_25335 : H12AffineEnvironment.transform 4 0 env25334 = env25335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25334 == env25335) = true)

theorem identity25335 : scanCanonicalize (H12AffineFastState.compose env25335 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound25335 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25336 : List Nat := [2,4,8,16,0,16,8,4,512,20,11,0,9,17,0,3,1,11,21,1,16,0,16,2,9,16,11,1,1,11,20,0,5,0,16,513]

theorem envBound25336 : H12AffineFastState.Bounded env25336 := by
  intro p hp
  have h : env25336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25335_25336 : H12AffineEnvironment.transform 9 20 env25335 = env25336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env25335 == env25336) = true)

theorem identity25336 : scanCanonicalize (H12AffineFastState.compose env25336 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25337 : List Nat := [2,4,6,16,0,16,6,4,512,20,5,0,7,17,0,3,1,5,21,1,16,0,16,2,7,16,5,1,1,5,20,0,5,0,16,513]

theorem envBound25337 : H12AffineFastState.Bounded env25337 := by
  intro p hp
  have h : env25337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25336_25337 : H12AffineEnvironment.transform 2 6 env25336 = env25337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25336 == env25337) = true)

theorem identity25337 : scanCanonicalize (H12AffineFastState.compose env25337 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound25337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25338 : List Nat := [2,4,6,16,0,16,6,4,7,20,5,0,7,17,0,3,1,5,21,1,16,0,16,2,7,16,5,1,1,5,20,0,5,0,16,6]

theorem envBound25338 : H12AffineFastState.Bounded env25338 := by
  intro p hp
  have h : env25338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25337_25338 : H12AffineEnvironment.transform 8 7 env25337 = env25338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env25337 == env25338) = true)

theorem identity25338 : scanCanonicalize (H12AffineFastState.compose env25338 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25338 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env25339 : List Nat := [2,4,6,1,0,1,6,4,7,5,5,0,7,0,0,3,1,5,4,1,1,0,1,2,7,1,5,1,1,5,5,0,5,0,1,6]

theorem envBound25339 : H12AffineFastState.Bounded env25339 := by
  intro p hp
  have h : env25339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25338_25339 : H12AffineEnvironment.transform 3 1 env25338 = env25339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25338 == env25339) = true)

theorem identity25339 : scanCanonicalize (H12AffineFastState.compose env25339 (packedSelected [12] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25339 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env25340 : List Nat := [2,0,2,1,0,1,2,0,3,1,1,0,3,0,0,3,1,1,0,1,1,0,1,2,3,1,1,1,1,1,1,0,1,0,1,2]

theorem envBound25340 : H12AffineFastState.Bounded env25340 := by
  intro p hp
  have h : env25340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25339_25340 : H12AffineEnvironment.transform 1 0 env25339 = env25340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25339 == env25340) = true)

def env25341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4160,73770,119879,21763,8193,64,64604,115014,102743,35188,1365,33,257,21793,46092,74251]

theorem envBound25341 : H12AffineFastState.Bounded env25341 := by
  intro p hp
  have h : env25341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25325_25341 : H12AffineEnvironment.transform 6 9 env25325 = env25341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25325 == env25341) = true)

theorem identity25341 : scanCanonicalize (H12AffineFastState.compose env25341 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound25341 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,82246,10280,1025,29788,4160,73770,73754,21763,8193,64,2049,79131,91402,32041,1365,33,257,21793,16465,74251]

theorem envBound25342 : H12AffineFastState.Bounded env25342 := by
  intro p hp
  have h : env25342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25341_25342 : H12AffineEnvironment.transform 14 29789 env25341 = env25342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env25341 == env25342) = true)

theorem identity25342 : scanCanonicalize (H12AffineFastState.compose env25342 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25342 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env25343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,65536,82246,2421,1025,21761,4160,65911,65863,21763,348,64,2049,70726,83031,23668,1365,33,257,21793,16465,66390]

theorem envBound25343 : H12AffineFastState.Bounded env25343 := by
  intro p hp
  have h : env25343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25342_25343 : H12AffineEnvironment.transform 12 349 env25342 = env25343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25342 == env25343) = true)

theorem identity25343 : scanCanonicalize (H12AffineFastState.compose env25343 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25343 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1297,65536,69975,2421,1025,1296,4160,65911,65863,1298,348,64,2049,70726,70726,3173,1365,33,257,1328,4160,66390]

theorem envBound25344 : H12AffineFastState.Bounded env25344 := by
  intro p hp
  have h : env25344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25343_25344 : H12AffineEnvironment.transform 13 4113 env25343 = env25344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25343 == env25344) = true)

theorem identity25344 : scanCanonicalize (H12AffineFastState.compose env25344 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound25344 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env25345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1297,343,4096,2421,1025,1296,4160,32,16,1298,348,64,2049,5393,5393,3173,1365,33,257,1328,4160,513]

theorem envBound25345 : H12AffineFastState.Bounded env25345 := by
  intro p hp
  have h : env25345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25344_25345 : H12AffineEnvironment.transform 15 343 env25344 = env25345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env25344 == env25345) = true)

theorem identity25345 : scanCanonicalize (H12AffineFastState.compose env25345 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25346 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,4113,0,343,4096,2421,272,1,4160,32,16,3,348,64,2049,4096,4096,2420,68,33,257,33,4160,513]

theorem envBound25346 : H12AffineFastState.Bounded env25346 := by
  intro p hp
  have h : env25346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25345_25346 : H12AffineEnvironment.transform 9 273 env25345 = env25346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25345 == env25346) = true)

theorem identity25346 : scanCanonicalize (H12AffineFastState.compose env25346 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25347 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,4096,121,4113,0,115,4096,2129,52,1,4160,32,16,3,120,64,2049,4096,4096,2128,68,33,37,33,4160,513]

theorem envBound25347 : H12AffineFastState.Bounded env25347 := by
  intro p hp
  have h : env25347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25346_25347 : H12AffineEnvironment.transform 7 36 env25346 = env25347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25346 == env25347) = true)

theorem identity25347 : scanCanonicalize (H12AffineFastState.compose env25347 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25347 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25348 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,40,4113,0,34,4096,2048,52,1,4113,32,16,3,41,17,2049,4096,4096,2049,21,33,37,33,4113,513]

theorem envBound25348 : H12AffineFastState.Bounded env25348 := by
  intro p hp
  have h : env25348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25347_25348 : H12AffineEnvironment.transform 5 17 env25347 = env25348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25347 == env25348) = true)

theorem identity25348 : scanCanonicalize (H12AffineFastState.compose env25348 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound25348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25349 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,0,40,17,0,34,0,2048,52,1,17,32,16,3,41,17,2049,0,0,2049,21,33,37,33,17,513]

theorem envBound25349 : H12AffineFastState.Bounded env25349 := by
  intro p hp
  have h : env25349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25348_25349 : H12AffineEnvironment.transform 11 0 env25348 = env25349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env25348 == env25349) = true)

theorem identity25349 : scanCanonicalize (H12AffineFastState.compose env25349 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound25349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25350 : List Nat := [2,4,8,16,32,17,9,36,42,53,2048,0,40,17,0,34,0,2048,52,1,17,32,16,3,41,17,2049,0,0,2049,21,33,37,33,17,43]

theorem envBound25350 : H12AffineFastState.Bounded env25350 := by
  intro p hp
  have h : env25350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25349_25350 : H12AffineEnvironment.transform 8 42 env25349 = env25350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env25349 == env25350) = true)

theorem identity25350 : scanCanonicalize (H12AffineFastState.compose env25350 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25350 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25351 : List Nat := [2,4,8,16,32,17,9,36,42,53,1,0,40,17,0,34,0,1,52,1,17,32,16,3,41,17,0,0,0,0,21,33,37,33,17,43]

theorem envBound25351 : H12AffineFastState.Bounded env25351 := by
  intro p hp
  have h : env25351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25350_25351 : H12AffineEnvironment.transform 10 1 env25350 = env25351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25350 == env25351) = true)

theorem identity25351 : scanCanonicalize (H12AffineFastState.compose env25351 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25351 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25352 : List Nat := [2,4,8,0,32,1,9,36,42,37,1,0,40,1,0,34,0,1,36,1,1,32,0,3,41,1,0,0,0,0,5,33,37,33,1,43]

theorem envBound25352 : H12AffineFastState.Bounded env25352 := by
  intro p hp
  have h : env25352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25351_25352 : H12AffineEnvironment.transform 3 0 env25351 = env25352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25351 == env25352) = true)

def env25353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,253976,8328,64,64605,160981,140485,303572,1501,272392,257,21793,46213,74250]

theorem envBound25353 : H12AffineFastState.Bounded env25353 := by
  intro p hp
  have h : env25353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25299_25353 : H12AffineEnvironment.transform 20 4161 env25299 = env25353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25299 == env25353) = true)

theorem identity25353 : scanCanonicalize (H12AffineFastState.compose env25353 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25353 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,441744,156116,180243,8328,64,64605,160981,140485,303572,1501,272392,257,21793,46213,513]

theorem envBound25354 : H12AffineFastState.Bounded env25354 := by
  intro p hp
  have h : env25354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25353_25354 : H12AffineEnvironment.transform 15 8203 env25353 = env25354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25353 == env25354) = true)

def env25355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,327040,8644,32771,8328,64,64605,13509,25813,303572,1501,272392,257,21793,46213,513]

theorem envBound25355 : H12AffineFastState.Bounded env25355 := by
  intro p hp
  have h : env25355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25354_25355 : H12AffineEnvironment.transform 16 16400 env25354 = env25355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25354 == env25355) = true)

def env25356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,326920,8524,32771,8192,64,64605,13389,25693,303452,1365,272392,257,21793,46093,513]

theorem envBound25356 : H12AffineFastState.Bounded env25356 := by
  intro p hp
  have h : env25356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25355_25356 : H12AffineEnvironment.transform 6 8 env25355 = env25356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25355 == env25356) = true)

theorem identity25356 : scanCanonicalize (H12AffineFastState.compose env25356 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound25356 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env25357 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,8203,12636,262144,1025,32769,4161,298052,8524,32771,8192,64,36113,13389,5393,303452,1365,272392,257,9325,46093,513]

theorem envBound25357 : H12AffineFastState.Bounded env25357 := by
  intro p hp
  have h : env25357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25356_25357 : H12AffineEnvironment.transform 13 12620 env25356 = env25357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env25356 == env25357) = true)

theorem identity25357 : scanCanonicalize (H12AffineFastState.compose env25357 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25357 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env25358 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8541,8203,12636,262144,1025,8540,4161,273689,8524,8542,8192,64,11340,13389,5393,262145,1365,272392,257,9325,5456,513]

theorem envBound25358 : H12AffineFastState.Bounded env25358 := by
  intro p hp
  have h : env25358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25357_25358 : H12AffineEnvironment.transform 14 8541 env25357 = env25358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25357 == env25358) = true)

theorem identity25358 : scanCanonicalize (H12AffineFastState.compose env25358 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound25358 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8541,8203,12636,10280,1025,8540,4161,1329,8524,8542,8192,64,11340,13389,5393,10281,1365,32,257,9325,5456,513]

theorem envBound25359 : H12AffineFastState.Bounded env25359 := by
  intro p hp
  have h : env25359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25358_25359 : H12AffineEnvironment.transform 17 10280 env25358 = env25359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25358 == env25359) = true)

theorem identity25359 : scanCanonicalize (H12AffineFastState.compose env25359 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound25359 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6428,2128,6209,6423,2112,4404,1025,6208,4161,1329,6224,6210,6428,64,5456,3409,5393,4405,1365,32,257,7537,5456,513]

theorem envBound25360 : H12AffineFastState.Bounded env25360 := by
  intro p hp
  have h : env25360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25359_25360 : H12AffineEnvironment.transform 12 6428 env25359 = env25360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env25359 == env25360) = true)

theorem identity25360 : scanCanonicalize (H12AffineFastState.compose env25360 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound25360 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,1336,2128,1125,1331,2112,3344,1025,1124,3173,1329,1140,1126,1336,64,2420,3409,2357,3345,1365,32,257,341,2420,513]

theorem envBound25361 : H12AffineFastState.Bounded env25361 := by
  intro p hp
  have h : env25361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25360_25361 : H12AffineEnvironment.transform 11 3108 env25360 = env25361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env25360 == env25361) = true)

theorem identity25361 : scanCanonicalize (H12AffineFastState.compose env25361 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25361 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env25362 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3108,1052,2128,1125,1047,2112,3124,1025,1124,3173,1045,1140,1126,1052,64,2128,3189,2065,3125,1137,32,37,113,2128,513]

theorem envBound25362 : H12AffineFastState.Bounded env25362 := by
  intro p hp
  have h : env25362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25361_25362 : H12AffineEnvironment.transform 7 36 env25361 = env25362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25361 == env25362) = true)

theorem identity25362 : scanCanonicalize (H12AffineFastState.compose env25362 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25362 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25363 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,1052,2048,1077,1047,2064,3124,1025,1076,3125,1045,1060,1078,1052,16,2048,3109,2065,3125,1057,32,37,33,2048,513]

theorem envBound25363 : H12AffineFastState.Bounded env25363 := by
  intro p hp
  have h : env25363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25362_25363 : H12AffineEnvironment.transform 5 16 env25362 = env25363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25362 == env25363) = true)

theorem identity25363 : scanCanonicalize (H12AffineFastState.compose env25363 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound25363 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25364 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1567,571,1052,1567,1077,1047,1551,555,1025,1076,554,1045,1060,1078,1052,16,1567,570,1550,554,1057,32,37,33,1567,513]

theorem envBound25364 : H12AffineFastState.Bounded env25364 := by
  intro p hp
  have h : env25364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25363_25364 : H12AffineEnvironment.transform 10 1567 env25363 = env25364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env25363 == env25364) = true)

theorem identity25364 : scanCanonicalize (H12AffineFastState.compose env25364 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25364 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25365 : List Nat := [2,4,8,16,32,16,8,36,512,52,555,571,40,555,1,35,571,555,53,0,554,33,16,2,40,16,555,570,570,554,21,32,37,33,555,513]

theorem envBound25365 : H12AffineFastState.Bounded env25365 := by
  intro p hp
  have h : env25365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25364_25365 : H12AffineEnvironment.transform 9 52 env25364 = env25365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25364 == env25365) = true)

theorem identity25365 : scanCanonicalize (H12AffineFastState.compose env25365 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound25365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25366 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,16,40,0,1,35,16,0,53,0,1,33,16,2,40,16,0,17,17,1,21,32,37,33,0,42]

theorem envBound25366 : H12AffineFastState.Bounded env25366 := by
  intro p hp
  have h : env25366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25365_25366 : H12AffineEnvironment.transform 8 43 env25365 = env25366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env25365 == env25366) = true)

theorem identity25366 : scanCanonicalize (H12AffineFastState.compose env25366 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25367 : List Nat := [2,4,8,16,16,16,8,20,27,4,0,16,24,0,1,19,16,0,5,0,1,17,16,2,24,16,0,17,17,1,21,16,21,17,0,26]

theorem envBound25367 : H12AffineFastState.Bounded env25367 := by
  intro p hp
  have h : env25367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25366_25367 : H12AffineEnvironment.transform 4 16 env25366 = env25367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25366 == env25367) = true)

theorem identity25367 : scanCanonicalize (H12AffineFastState.compose env25367 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25367 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25368 : List Nat := [2,4,8,11,11,11,8,15,0,4,0,11,3,0,1,8,11,0,5,0,1,10,11,2,3,11,0,10,10,1,14,11,14,10,0,1]

theorem envBound25368 : H12AffineFastState.Bounded env25368 := by
  intro p hp
  have h : env25368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25367_25368 : H12AffineEnvironment.transform 3 11 env25367 = env25368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25367 == env25368) = true)

theorem identity25368 : scanCanonicalize (H12AffineFastState.compose env25368 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound25368 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25369 : List Nat := [2,4,2,1,1,1,2,5,0,4,0,1,3,0,1,2,1,0,5,0,1,0,1,2,3,1,0,0,0,1,4,1,4,0,0,1]

theorem envBound25369 : H12AffineFastState.Bounded env25369 := by
  intro p hp
  have h : env25369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25368_25369 : H12AffineEnvironment.transform 2 2 env25368 = env25369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env25368 == env25369) = true)

def env25370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,326921,8525,32771,8193,64,64605,13388,25692,303453,1364,272392,257,21793,46092,513]

theorem envBound25370 : H12AffineFastState.Bounded env25370 := by
  intro p hp
  have h : env25370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25355_25370 : H12AffineEnvironment.transform 6 9 env25355 = env25370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25355 == env25370) = true)

def env25371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,327041,8645,32770,8328,64,64605,13508,25812,303572,1501,272392,257,21793,46213,513]

theorem envBound25371 : H12AffineFastState.Bounded env25371 := by
  intro p hp
  have h : env25371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25354_25371 : H12AffineEnvironment.transform 16 16401 env25354 = env25371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env25354 == env25371) = true)

theorem identity25371 : scanCanonicalize (H12AffineFastState.compose env25371 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound25371 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16401,262144,1025,32769,4161,318549,17,32770,348,64,56713,5392,17664,294912,1501,264668,257,21793,38225,513]

theorem envBound25372 : H12AffineFastState.Bounded env25372 := by
  intro p hp
  have h : env25372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25371_25372 : H12AffineEnvironment.transform 12 468 env25371 = env25372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env25371 == env25372) = true)

theorem identity25372 : scanCanonicalize (H12AffineFastState.compose env25372 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound25372 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16401,56572,1025,32769,4161,169,17,32770,348,64,56713,5392,17664,23804,1501,54560,257,21793,38225,513]

theorem envBound25373 : H12AffineFastState.Bounded env25373 := by
  intro p hp
  have h : env25373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25372_25373 : H12AffineEnvironment.transform 17 56572 env25372 = env25373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env25372 == env25373) = true)

theorem identity25373 : scanCanonicalize (H12AffineFastState.compose env25373 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25373 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env25374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,342,16401,56437,1025,32769,4161,32,17,32770,348,64,56576,5392,17664,23669,1364,54560,257,21793,38225,513]

theorem envBound25374 : H12AffineFastState.Bounded env25374 := by
  intro p hp
  have h : env25374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25373_25374 : H12AffineEnvironment.transform 6 9 env25373 = env25374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25373 == env25374) = true)

theorem identity25374 : scanCanonicalize (H12AffineFastState.compose env25374 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound25374 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,342,16401,2420,1025,21760,4161,32,17,21763,348,64,2049,5392,17664,23669,1364,33,257,21793,16464,513]

theorem envBound25375 : H12AffineFastState.Bounded env25375 := by
  intro p hp
  have h : env25375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25374_25375 : H12AffineEnvironment.transform 14 21761 env25374 = env25375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25374 == env25375) = true)

theorem identity25375 : scanCanonicalize (H12AffineFastState.compose env25375 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound25375 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env25376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,80,342,5440,2420,1025,81,4161,32,17,82,348,64,2049,5392,4177,2340,1364,33,257,112,5377,513]

theorem envBound25376 : H12AffineFastState.Bounded env25376 := by
  intro p hp
  have h : env25376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25375_25376 : H12AffineEnvironment.transform 13 5457 env25375 = env25376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env25375 == env25376) = true)

theorem identity25376 : scanCanonicalize (H12AffineFastState.compose env25376 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1102) := by decide +kernel

theorem selectedBound25376 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env25377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1102,349,287,80,342,270,2420,1025,81,1039,32,17,82,348,64,2049,350,1055,2340,1364,33,257,112,335,513]

theorem envBound25377 : H12AffineFastState.Bounded env25377 := by
  intro p hp
  have h : env25377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25376_25377 : H12AffineEnvironment.transform 11 1102 env25376 = env25377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1102 env25376 == env25377) = true)

theorem identity25377 : scanCanonicalize (H12AffineFastState.compose env25377 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound25377 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env25378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,271,1102,349,287,80,342,270,123,1025,81,1039,32,17,82,348,64,270,350,1055,43,1364,33,257,112,335,513]

theorem envBound25378 : H12AffineFastState.Bounded env25378 := by
  intro p hp
  have h : env25378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25377_25378 : H12AffineEnvironment.transform 10 271 env25377 = env25378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env25377 == env25378) = true)

theorem identity25378 : scanCanonicalize (H12AffineFastState.compose env25378 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound25378 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env25379 : List Nat := [2,4,8,16,32,64,9,53,512,1024,58,1102,104,42,80,99,59,123,1025,81,1039,32,17,82,105,64,59,107,1055,43,1121,33,52,112,122,513]

theorem envBound25379 : H12AffineFastState.Bounded env25379 := by
  intro p hp
  have h : env25379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25378_25379 : H12AffineEnvironment.transform 7 53 env25378 = env25379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env25378 == env25379) = true)

theorem identity25379 : scanCanonicalize (H12AffineFastState.compose env25379 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound25379 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env25380 : List Nat := [2,4,8,16,32,64,9,53,512,100,58,42,104,42,80,99,59,123,101,81,107,32,17,82,105,64,59,107,123,43,5,33,52,112,122,513]

theorem envBound25380 : H12AffineFastState.Bounded env25380 := by
  intro p hp
  have h : env25380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25379_25380 : H12AffineEnvironment.transform 9 100 env25379 = env25380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env25379 == env25380) = true)

theorem identity25380 : scanCanonicalize (H12AffineFastState.compose env25380 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound25380 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env25381 : List Nat := [2,4,8,16,32,27,9,53,512,63,58,42,51,42,11,56,59,32,62,10,48,32,17,9,50,27,59,48,32,43,5,33,52,43,33,513]

theorem envBound25381 : H12AffineFastState.Bounded env25381 := by
  intro p hp
  have h : env25381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25380_25381 : H12AffineEnvironment.transform 5 27 env25380 = env25381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env25380 == env25381) = true)

theorem identity25381 : scanCanonicalize (H12AffineFastState.compose env25381 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound25381 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env25382 : List Nat := [2,4,2,16,32,17,3,53,512,53,48,32,51,32,1,50,49,32,52,0,48,32,17,3,50,17,49,48,32,33,5,33,52,33,33,513]

theorem envBound25382 : H12AffineFastState.Bounded env25382 := by
  intro p hp
  have h : env25382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25381_25382 : H12AffineEnvironment.transform 2 2 env25381 = env25382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env25381 == env25382) = true)

theorem identity25382 : scanCanonicalize (H12AffineFastState.compose env25382 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound25382 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25383 : List Nat := [2,4,2,16,32,17,3,53,54,53,48,32,51,32,1,50,49,32,52,0,48,32,17,3,50,17,49,48,32,33,5,33,52,33,33,55]

theorem envBound25383 : H12AffineFastState.Bounded env25383 := by
  intro p hp
  have h : env25383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25382_25383 : H12AffineEnvironment.transform 8 54 env25382 = env25383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env25382 == env25383) = true)

theorem identity25383 : scanCanonicalize (H12AffineFastState.compose env25383 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25383 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25384 : List Nat := [2,4,2,0,32,1,3,37,38,37,32,32,35,32,1,34,33,32,36,0,32,32,1,3,34,1,33,32,32,33,5,33,36,33,33,39]

theorem envBound25384 : H12AffineFastState.Bounded env25384 := by
  intro p hp
  have h : env25384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25383_25384 : H12AffineEnvironment.transform 3 0 env25383 = env25384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25383 == env25384) = true)

theorem identity25384 : scanCanonicalize (H12AffineFastState.compose env25384 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound25384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25385 : List Nat := [2,4,2,0,5,1,3,0,3,0,5,5,6,5,1,7,4,5,1,0,5,5,1,3,7,1,4,5,5,4,5,4,1,4,4,2]

theorem envBound25385 : H12AffineFastState.Bounded env25385 := by
  intro p hp
  have h : env25385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25384_25385 : H12AffineEnvironment.transform 4 5 env25384 = env25385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env25384 == env25385) = true)

theorem identity25385 : scanCanonicalize (H12AffineFastState.compose env25385 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25385 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25386 : List Nat := [2,1,2,0,0,1,3,0,3,0,0,0,3,0,1,2,1,0,1,0,0,0,1,3,2,1,1,0,0,1,0,1,1,1,1,2]

theorem envBound25386 : H12AffineFastState.Bounded env25386 := by
  intro p hp
  have h : env25386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25385_25386 : H12AffineEnvironment.transform 1 1 env25385 = env25386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25385 == env25386) = true)

def env25387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257301,253976,8328,64,2157597,2253972,140485,2404757,2102684,2373704,257,21793,46213,2175563]

theorem envBound25387 : H12AffineFastState.Bounded env25387 := by
  intro p hp
  have h : env25387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25298_25387 : H12AffineEnvironment.transform 21 441745 env25298 = env25387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env25298 == env25387) = true)

def env25388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,253976,8328,64,64605,160980,140485,303573,1500,272392,257,21793,46213,74251]

theorem envBound25388 : H12AffineFastState.Bounded env25388 := by
  intro p hp
  have h : env25388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25387_25388 : H12AffineEnvironment.transform 20 4160 env25387 = env25388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25387 == env25388) = true)

theorem identity25388 : scanCanonicalize (H12AffineFastState.compose env25388 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound25388 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,441745,156117,144583,8328,64,64605,160980,140485,303573,1500,272392,257,21793,46213,63188]

theorem envBound25389 : H12AffineFastState.Bounded env25389 := by
  intro p hp
  have h : env25389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25388_25389 : H12AffineEnvironment.transform 15 54495 env25388 = env25389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env25388 == env25389) = true)

def env25390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4112,441745,156037,144535,8328,16,64525,160900,140437,303493,1420,272392,257,21793,46213,63108]

theorem envBound25390 : H12AffineFastState.Bounded env25390 := by
  intro p hp
  have h : env25390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25389_25390 : H12AffineEnvironment.transform 5 16 env25389 = env25390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25389 == env25390) = true)

theorem identity25390 : scanCanonicalize (H12AffineFastState.compose env25390 (packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 171196) := by decide +kernel

theorem selectedBound25390 : packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS < 2^1333 := by decide +kernel

def env25391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,171196,1025,32769,4112,8493,156037,144535,8328,16,64525,160900,140437,146745,1420,177332,257,21793,46213,63108]

theorem envBound25391 : H12AffineFastState.Bounded env25391 := by
  intro p hp
  have h : env25391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25390_25391 : H12AffineEnvironment.transform 17 171196 env25390 = env25391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171196 env25390 == env25391) = true)

theorem identity25391 : scanCanonicalize (H12AffineFastState.compose env25391 (packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound25391 : packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env25392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,5529,35109,1025,32769,4112,8493,29724,8462,8328,16,64525,24861,12556,10400,1420,41261,257,21793,46213,63108]

theorem envBound25392 : H12AffineFastState.Bounded env25392 := by
  intro p hp
  have h : env25392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25391_25392 : H12AffineEnvironment.transform 16 5529 env25391 = env25392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env25391 == env25392) = true)

theorem identity25392 : scanCanonicalize (H12AffineFastState.compose env25392 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound25392 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env25393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8202,5529,32160,1025,29828,4112,8493,29724,8462,8328,16,2184,24861,12556,10400,1420,21928,257,21793,16384,513]

theorem envBound25393 : H12AffineFastState.Bounded env25393 := by
  intro p hp
  have h : env25393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25392_25393 : H12AffineEnvironment.transform 14 29829 env25392 = env25393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env25392 == env25393) = true)

theorem identity25393 : scanCanonicalize (H12AffineFastState.compose env25393 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25393 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,8202,5529,10400,1025,8580,4112,8493,8476,8462,8328,16,2184,13341,12556,10400,1420,168,257,33,5376,513]

theorem envBound25394 : H12AffineFastState.Bounded env25394 := by
  intro p hp
  have h : env25394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25393_25394 : H12AffineEnvironment.transform 13 5376 env25393 = env25394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25393 == env25394) = true)

theorem identity25394 : scanCanonicalize (H12AffineFastState.compose env25394 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound25394 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env25395 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3244,8192,2476,8581,8202,2357,10400,1025,8580,3260,8493,8476,8462,8328,16,2184,10417,11680,10400,1420,168,257,33,2476,513]

theorem envBound25395 : H12AffineFastState.Bounded env25395 := by
  intro p hp
  have h : env25395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25394_25395 : H12AffineEnvironment.transform 11 3244 env25394 = env25395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env25394 == env25395) = true)

theorem identity25395 : scanCanonicalize (H12AffineFastState.compose env25395 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25395 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25396 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,8192,2340,8461,8202,2357,10280,1025,8460,3124,8493,8476,8462,8192,16,2048,10297,11560,10280,1284,32,257,33,2340,513]

theorem envBound25396 : H12AffineFastState.Bounded env25396 := by
  intro p hp
  have h : env25396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25395_25396 : H12AffineEnvironment.transform 6 8 env25395 = env25396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25395 == env25396) = true)

theorem identity25396 : scanCanonicalize (H12AffineFastState.compose env25396 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound25396 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env25397 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,1052,2340,1297,1046,2357,3124,1025,1296,3124,1329,1280,1298,1052,16,2048,3109,2356,3124,1284,32,257,33,2340,513]

theorem envBound25397 : H12AffineFastState.Bounded env25397 := by
  intro p hp
  have h : env25397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25396_25397 : H12AffineEnvironment.transform 12 1052 env25396 = env25397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env25396 == env25397) = true)

theorem identity25397 : scanCanonicalize (H12AffineFastState.compose env25397 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25397 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25398 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2356,268,2340,1,262,2357,2340,273,0,2340,33,16,2,268,16,2048,2357,2356,2340,20,32,257,33,2340,513]

theorem envBound25398 : H12AffineFastState.Bounded env25398 := by
  intro p hp
  have h : env25398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25397_25398 : H12AffineEnvironment.transform 9 272 env25397 = env25398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25397 == env25398) = true)

theorem identity25398 : scanCanonicalize (H12AffineFastState.compose env25398 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25398 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25399 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,40,2048,1,34,2065,2048,53,0,2048,33,16,2,40,16,2048,2065,2064,2048,20,32,37,33,2048,513]

theorem envBound25399 : H12AffineFastState.Bounded env25399 := by
  intro p hp
  have h : env25399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25398_25399 : H12AffineEnvironment.transform 7 36 env25398 = env25399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25398 == env25399) = true)

theorem identity25399 : scanCanonicalize (H12AffineFastState.compose env25399 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound25399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25400 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,40,48,1,34,33,48,53,0,48,33,16,2,40,16,48,33,32,48,20,32,37,33,48,513]

theorem envBound25400 : H12AffineFastState.Bounded env25400 := by
  intro p hp
  have h : env25400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25399_25400 : H12AffineEnvironment.transform 10 48 env25399 = env25400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env25399 == env25400) = true)

theorem identity25400 : scanCanonicalize (H12AffineFastState.compose env25400 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound25400 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25401 : List Nat := [2,4,8,16,32,16,8,36,49,52,48,32,40,48,1,34,33,48,53,0,48,33,16,2,40,16,48,33,32,48,20,32,37,33,48,48]

theorem envBound25401 : H12AffineFastState.Bounded env25401 := by
  intro p hp
  have h : env25401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25400_25401 : H12AffineEnvironment.transform 8 49 env25400 = env25401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env25400 == env25401) = true)

def env25402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4113,441745,156036,144534,8328,17,64524,160901,140436,303492,1421,272392,257,21793,46213,63109]

theorem envBound25402 : H12AffineFastState.Bounded env25402 := by
  intro p hp
  have h : env25402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25389_25402 : H12AffineEnvironment.transform 5 17 env25389 = env25402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25389 == env25402) = true)

theorem identity25402 : scanCanonicalize (H12AffineFastState.compose env25402 (packedSelected [1,5,8,11,16,17,20,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound25402 : packedSelected [1,5,8,11,16,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env25403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33030,131072,262144,1025,32769,4113,441745,144396,144534,8328,17,43396,139533,140436,303492,1421,272392,257,169,46213,41741]

theorem envBound25403 : H12AffineFastState.Bounded env25403 := by
  intro p hp
  have h : env25403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25402_25403 : H12AffineEnvironment.transform 13 5512 env25402 = env25403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env25402 == env25403) = true)

theorem identity25403 : scanCanonicalize (H12AffineFastState.compose env25403 (packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound25403 : packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env25404 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33030,131072,35109,1025,32769,4113,144564,144396,144534,8328,17,43396,139533,140436,10401,1421,41261,257,169,46213,41741]

theorem envBound25404 : H12AffineFastState.Bounded env25404 := by
  intro p hp
  have h : env25404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25403_25404 : H12AffineEnvironment.transform 17 35109 env25403 = env25404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env25403 == env25404) = true)

theorem identity25404 : scanCanonicalize (H12AffineFastState.compose env25404 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25404 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env25405 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,32768,33030,131072,35109,1025,32769,4113,144444,144396,144414,8192,17,43276,139533,140316,10281,1285,41261,257,33,46093,41741]

theorem envBound25405 : H12AffineFastState.Bounded env25405 := by
  intro p hp
  have h : env25405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25404_25405 : H12AffineEnvironment.transform 6 8 env25404 = env25405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25404 == env25405) = true)

theorem identity25405 : scanCanonicalize (H12AffineFastState.compose env25405 (packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 13608) := by decide +kernel

theorem selectedBound25405 : packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env25406 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,13608,13358,131072,15373,1025,13609,4113,144444,144396,144414,8192,17,7204,139533,140316,10281,1285,5125,257,33,293,5669]

theorem envBound25406 : H12AffineFastState.Bounded env25406 := by
  intro p hp
  have h : env25406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25405_25406 : H12AffineEnvironment.transform 14 13608 env25405 = env25406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13608 env25405 == env25406) = true)

theorem identity25406 : scanCanonicalize (H12AffineFastState.compose env25406 (packedSelected [0,2,3,4,5,6,7,9,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 10297) := by decide +kernel

theorem selectedBound25406 : packedSelected [0,2,3,4,5,6,7,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env25407 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,13608,13358,10297,15373,1025,13609,4113,7173,7221,7207,8192,17,7204,2356,3109,10281,1285,5125,257,33,293,5669]

theorem envBound25407 : H12AffineFastState.Bounded env25407 := by
  intro p hp
  have h : env25407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25406_25407 : H12AffineEnvironment.transform 16 10297 env25406 = env25407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10297 env25406 == env25407) = true)

theorem identity25407 : scanCanonicalize (H12AffineFastState.compose env25407 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25407 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env25408 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,4096,8192,5376,13608,13358,8249,13325,1025,13609,4113,5125,5173,5159,8192,17,5156,308,1061,8233,1285,5125,257,33,293,5669]

theorem envBound25408 : H12AffineFastState.Bounded env25408 := by
  intro p hp
  have h : env25408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25407_25408 : H12AffineEnvironment.transform 10 0 env25407 = env25408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25407 == env25408) = true)

theorem identity25408 : scanCanonicalize (H12AffineFastState.compose env25408 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound25408 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env25409 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,276,8192,1044,9276,9530,8249,9497,1025,9277,261,1297,1313,1331,8192,17,1328,308,1061,8233,1285,1297,257,33,293,1841]

theorem envBound25409 : H12AffineFastState.Bounded env25409 := by
  intro p hp
  have h : env25409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25408_25409 : H12AffineEnvironment.transform 11 276 env25408 = env25409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env25408 == env25409) = true)

theorem identity25409 : scanCanonicalize (H12AffineFastState.compose env25409 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound25409 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env25410 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,276,1084,1044,0,262,1029,293,1025,1,261,1297,1313,1331,1084,17,1328,308,1061,1045,1285,1297,257,33,293,1841]

theorem envBound25410 : H12AffineFastState.Bounded env25410 := by
  intro p hp
  have h : env25410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25409_25410 : H12AffineEnvironment.transform 12 1084 env25409 = env25410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env25409 == env25410) = true)

theorem identity25410 : scanCanonicalize (H12AffineFastState.compose env25410 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound25410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25411 : List Nat := [2,4,8,16,32,17,8,256,512,4,0,276,56,16,0,262,1,293,5,1,261,277,293,311,56,17,308,308,33,17,257,277,257,33,293,821]

theorem envBound25411 : H12AffineFastState.Bounded env25411 := by
  intro p hp
  have h : env25411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25410_25411 : H12AffineEnvironment.transform 9 4 env25410 = env25411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env25410 == env25411) = true)

theorem identity25411 : scanCanonicalize (H12AffineFastState.compose env25411 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25411 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env25412 : List Nat := [2,4,8,16,16,17,8,256,512,4,0,276,8,16,0,262,1,277,5,1,261,277,277,263,8,17,260,260,17,17,257,277,257,17,277,773]

theorem envBound25412 : H12AffineFastState.Bounded env25412 := by
  intro p hp
  have h : env25412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25411_25412 : H12AffineEnvironment.transform 4 16 env25411 = env25412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25411 == env25412) = true)

theorem identity25412 : scanCanonicalize (H12AffineFastState.compose env25412 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound25412 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25413 : List Nat := [2,4,8,16,16,17,8,256,16,4,0,276,8,16,0,262,1,277,5,1,261,277,277,263,8,17,260,260,17,17,257,277,257,17,277,277]

theorem envBound25413 : H12AffineFastState.Bounded env25413 := by
  intro p hp
  have h : env25413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25412_25413 : H12AffineEnvironment.transform 8 16 env25412 = env25413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env25412 == env25413) = true)

theorem identity25413 : scanCanonicalize (H12AffineFastState.compose env25413 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25414 : List Nat := [2,4,8,16,16,17,8,20,16,4,0,0,8,16,0,18,1,1,5,1,17,1,1,19,8,17,16,16,17,17,21,1,21,17,1,1]

theorem envBound25414 : H12AffineFastState.Bounded env25414 := by
  intro p hp
  have h : env25414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25413_25414 : H12AffineEnvironment.transform 7 20 env25413 = env25414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25413 == env25414) = true)

theorem identity25414 : scanCanonicalize (H12AffineFastState.compose env25414 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25414 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25415 : List Nat := [2,4,8,1,1,0,8,5,1,4,0,0,8,1,0,3,1,1,5,1,0,1,1,2,8,0,1,1,0,0,4,1,4,0,1,1]

theorem envBound25415 : H12AffineFastState.Bounded env25415 := by
  intro p hp
  have h : env25415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25414_25415 : H12AffineEnvironment.transform 3 1 env25414 = env25415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25414 == env25415) = true)

theorem identity25415 : scanCanonicalize (H12AffineFastState.compose env25415 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25416 : List Nat := [2,0,8,1,1,0,8,1,1,0,0,0,8,1,0,3,1,1,1,1,0,1,1,2,8,0,1,1,0,0,0,1,0,0,1,1]

theorem envBound25416 : H12AffineFastState.Bounded env25416 := by
  intro p hp
  have h : env25416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25415_25416 : H12AffineEnvironment.transform 1 0 env25415 = env25416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25415 == env25416) = true)

def env25417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,253976,8328,64,64604,160981,140485,303572,1501,272393,257,21793,46213,74250]

theorem envBound25417 : H12AffineFastState.Bounded env25417 := by
  intro p hp
  have h : env25417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25387_25417 : H12AffineEnvironment.transform 20 4161 env25387 = env25417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25387 == env25417) = true)

theorem identity25417 : scanCanonicalize (H12AffineFastState.compose env25417 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound25417 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,4161,392287,73754,41430,8328,64,64604,79131,91403,303572,1501,272393,257,21793,46213,74250]

theorem envBound25418 : H12AffineFastState.Bounded env25418 := by
  intro p hp
  have h : env25418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25417_25418 : H12AffineEnvironment.transform 16 82382 env25417 = env25418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env25417 == env25418) = true)

def env25419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4161,392287,73754,41310,8192,64,64604,79131,91403,303452,1365,272393,257,21793,46093,74250]

theorem envBound25419 : H12AffineFastState.Bounded env25419 := by
  intro p hp
  have h : env25419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25418_25419 : H12AffineEnvironment.transform 6 8 env25418 = env25419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25418 == env25419) = true)

theorem identity25419 : scanCanonicalize (H12AffineFastState.compose env25419 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound25419 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env25420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29743,13673,262144,1025,32769,4161,297072,21557,41310,8192,64,64604,16692,4388,303452,1365,272393,257,21793,46093,22053]

theorem envBound25420 : H12AffineFastState.Bounded env25420 := by
  intro p hp
  have h : env25420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25419_25420 : H12AffineEnvironment.transform 15 29743 env25419 = env25420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env25419 == env25420) = true)

theorem identity25420 : scanCanonicalize (H12AffineFastState.compose env25420 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound25420 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env25421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,29743,13673,262144,1025,21761,4161,286064,21557,29790,8192,64,10588,16692,4388,291932,1365,272393,257,21793,24845,22053]

theorem envBound25421 : H12AffineFastState.Bounded env25421 := by
  intro p hp
  have h : env25421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25420_25421 : H12AffineEnvironment.transform 14 21760 env25420 = env25421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env25420 == env25421) = true)

theorem identity25421 : scanCanonicalize (H12AffineFastState.compose env25421 (packedSelected [2,3,4,6,8,11,12,15,16,18,19,22,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound25421 : packedSelected [2,3,4,6,8,11,12,15,16,18,19,22,24,28] rootPS < 2^1333 := by decide +kernel

def env25422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,29743,13673,2049,1025,21761,4161,21873,21557,29790,8192,64,10588,16692,4388,31837,1365,8200,257,21793,24845,22053]

theorem envBound25422 : H12AffineFastState.Bounded env25422 := by
  intro p hp
  have h : env25422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25421_25422 : H12AffineEnvironment.transform 17 2049 env25421 = env25422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env25421 == env25422) = true)

theorem identity25422 : scanCanonicalize (H12AffineFastState.compose env25422 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound25422 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env25423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21760,21591,5393,2049,1025,21761,4161,21873,21557,21542,120,64,2340,16692,4388,23589,1365,112,257,21793,16757,22053]

theorem envBound25423 : H12AffineFastState.Bounded env25423 := by
  intro p hp
  have h : env25423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25422_25423 : H12AffineEnvironment.transform 12 120 env25422 = env25423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env25422 == env25423) = true)

theorem identity25423 : scanCanonicalize (H12AffineFastState.compose env25423 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound25423 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env25424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5156,292,115,5393,2049,1025,293,4161,341,17,2,120,64,2340,5392,4388,2049,1365,112,257,261,5457,513]

theorem envBound25424 : H12AffineFastState.Bounded env25424 := by
  intro p hp
  have h : env25424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25423_25424 : H12AffineEnvironment.transform 13 5156 env25423 = env25424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env25423 == env25424) = true)

theorem identity25424 : scanCanonicalize (H12AffineFastState.compose env25424 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound25424 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25425 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,120,4161,292,115,4468,2049,100,293,4161,341,17,2,120,64,2340,4469,4388,2049,304,112,257,261,4404,513]

theorem envBound25425 : H12AffineFastState.Bounded env25425 := by
  intro p hp
  have h : env25425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25424_25425 : H12AffineEnvironment.transform 9 101 env25424 = env25425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env25424 == env25425) = true)

theorem identity25425 : scanCanonicalize (H12AffineFastState.compose env25425 (packedSelected [1,4,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 112) := by decide +kernel

theorem selectedBound25425 : packedSelected [1,4,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env25426 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,112,120,49,292,115,260,2049,100,293,49,341,17,2,120,64,2340,261,340,2049,304,112,257,261,324,513]

theorem envBound25426 : H12AffineFastState.Bounded env25426 := by
  intro p hp
  have h : env25426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25425_25426 : H12AffineEnvironment.transform 11 112 env25425 = env25426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 112 env25425 == env25426) = true)

theorem identity25426 : scanCanonicalize (H12AffineFastState.compose env25426 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound25426 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25427 : List Nat := [2,4,8,16,32,64,8,52,512,101,2048,112,120,49,16,115,48,2049,100,17,49,97,17,2,120,64,2064,49,96,2049,4,112,53,49,112,513]

theorem envBound25427 : H12AffineFastState.Bounded env25427 := by
  intro p hp
  have h : env25427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25426_25427 : H12AffineEnvironment.transform 7 52 env25426 = env25427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env25426 == env25427) = true)

theorem identity25427 : scanCanonicalize (H12AffineFastState.compose env25427 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound25427 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env25428 : List Nat := [2,4,8,16,32,64,8,52,512,101,16,112,120,49,16,115,48,17,100,17,49,97,17,2,120,64,0,49,96,17,4,112,53,49,112,513]

theorem envBound25428 : H12AffineFastState.Bounded env25428 := by
  intro p hp
  have h : env25428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25427_25428 : H12AffineEnvironment.transform 10 16 env25427 = env25428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env25427 == env25428) = true)

theorem identity25428 : scanCanonicalize (H12AffineFastState.compose env25428 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25428 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env25429 : List Nat := [2,4,8,0,32,64,8,36,512,101,0,96,104,33,0,99,32,1,100,1,33,97,1,2,104,64,0,33,96,1,4,96,37,33,96,513]

theorem envBound25429 : H12AffineFastState.Bounded env25429 := by
  intro p hp
  have h : env25429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25428_25429 : H12AffineEnvironment.transform 3 0 env25428 = env25429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25428 == env25429) = true)

def env25430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,392287,73754,41311,8193,64,64604,79131,91403,303453,1364,272393,257,21793,46092,74250]

theorem envBound25430 : H12AffineFastState.Bounded env25430 := by
  intro p hp
  have h : env25430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25418_25430 : H12AffineEnvironment.transform 6 9 env25418 = env25430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25418 == env25430) = true)

theorem identity25430 : scanCanonicalize (H12AffineFastState.compose env25430 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound25430 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env25431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,79130,262144,1025,32769,4161,362498,73754,41311,8193,64,34817,79131,69974,303453,1364,272393,257,8572,46092,74250]

theorem envBound25431 : H12AffineFastState.Bounded env25431 := by
  intro p hp
  have h : env25431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25430_25431 : H12AffineEnvironment.transform 13 13405 env25430 = env25431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env25430 == env25431) = true)

theorem identity25431 : scanCanonicalize (H12AffineFastState.compose env25431 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25431 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env25432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,65536,70727,262144,1025,32769,4161,362498,65863,32770,348,64,34817,70726,69974,294912,1364,264532,257,33,38225,66391]

theorem envBound25432 : H12AffineFastState.Bounded env25432 := by
  intro p hp
  have h : env25432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25431_25432 : H12AffineEnvironment.transform 12 349 env25431 = env25432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25431 == env25432) = true)

theorem identity25432 : scanCanonicalize (H12AffineFastState.compose env25432 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound25432 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env25433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,65536,70727,67618,1025,32769,4161,32800,65863,32770,348,64,34817,70726,69974,100386,1364,65910,257,33,38225,66391]

theorem envBound25433 : H12AffineFastState.Bounded env25433 := by
  intro p hp
  have h : env25433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25432_25433 : H12AffineEnvironment.transform 17 67618 env25432 = env25433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env25432 == env25433) = true)

theorem identity25433 : scanCanonicalize (H12AffineFastState.compose env25433 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound25433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,342,5393,2420,1025,32769,4161,32800,17,32770,348,64,34817,5392,4096,35188,1364,32,257,33,38225,513]

theorem envBound25434 : H12AffineFastState.Bounded env25434 := by
  intro p hp
  have h : env25434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25433_25434 : H12AffineEnvironment.transform 15 342 env25433 = env25434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env25433 == env25434) = true)

theorem identity25434 : scanCanonicalize (H12AffineFastState.compose env25434 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound25434 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5393,2420,1025,1,4161,32,17,2,348,64,2049,5392,4096,2420,1364,32,257,33,5457,513]

theorem envBound25435 : H12AffineFastState.Bounded env25435 := by
  intro p hp
  have h : env25435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25434_25435 : H12AffineEnvironment.transform 14 0 env25434 = env25435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env25434 == env25435) = true)

theorem identity25435 : scanCanonicalize (H12AffineFastState.compose env25435 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound25435 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3118,349,2350,0,342,2367,2420,1025,1,3183,32,17,2,348,64,2049,2366,3118,2420,1364,32,257,33,2431,513]

theorem envBound25436 : H12AffineFastState.Bounded env25436 := by
  intro p hp
  have h : env25436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25435_25436 : H12AffineEnvironment.transform 11 3118 env25435 = env25436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env25435 == env25436) = true)

theorem identity25436 : scanCanonicalize (H12AffineFastState.compose env25436 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound25436 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25437 : List Nat := [2,4,8,16,32,64,9,256,512,46,2048,2048,349,2350,0,342,2367,2420,47,1,2113,32,17,2,348,64,2049,2366,2048,2420,378,32,257,33,2431,513]

theorem envBound25437 : H12AffineFastState.Bounded env25437 := by
  intro p hp
  have h : env25437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25436_25437 : H12AffineEnvironment.transform 9 46 env25436 = env25437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env25436 == env25437) = true)

def env25438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound25438 : H12AffineFastState.Bounded env25438 := by
  intro p hp
  have h : env25438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25090_25438 : H12AffineEnvironment.transform 26 30393345 env25090 = env25438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env25090 == env25438) = true)

def env25439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound25439 : H12AffineFastState.Bounded env25439 := by
  intro p hp
  have h : env25439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25438_25439 : H12AffineEnvironment.transform 18 1024 env25438 = env25439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25438 == env25439) = true)

theorem identity25439 : scanCanonicalize (H12AffineFastState.compose env25439 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577240) := by decide +kernel

theorem selectedBound25439 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577240,8328,64,6727001,8446421,10507600,8830976,2154825,12583064,256,41460,16464,2213535]

theorem envBound25440 : H12AffineFastState.Bounded env25440 := by
  intro p hp
  have h : env25440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25439_25440 : H12AffineEnvironment.transform 23 10577240 env25439 = env25440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577240 env25439 == env25440) = true)

def env25441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,4194304,8388608,10577240,8328,64,6705549,8393985,10507600,8795348,2102685,12583064,256,21792,16464,2175563]

theorem envBound25441 : H12AffineFastState.Bounded env25441 := by
  intro p hp
  have h : env25441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25440_25441 : H12AffineEnvironment.transform 14 29908 env25440 = env25441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env25440 == env25441) = true)

def env25442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272512,8388608,10577240,8328,64,2259213,8393985,10507600,8795348,2102685,8661016,256,21792,16464,2175563]

theorem envBound25442 : H12AffineFastState.Bounded env25442 := by
  intro p hp
  have h : env25442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25441_25442 : H12AffineEnvironment.transform 21 272512 env25441 = env25442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25441 == env25442) = true)

theorem identity25442 : scanCanonicalize (H12AffineFastState.compose env25442 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound25442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,77898,272512,8388608,8410386,8328,64,215367,8393985,8480026,8795348,75223,8661016,256,21792,16464,513]

theorem envBound25443 : H12AffineFastState.Bounded env25443 := by
  intro p hp
  have h : env25443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25442_25443 : H12AffineEnvironment.transform 20 77898 env25442 = env25443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env25442 == env25443) = true)

def env25444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77898,272392,8388608,8410386,8192,64,215367,8393985,8480026,8795228,75103,8661016,256,21792,16464,513]

theorem envBound25444 : H12AffineFastState.Bounded env25444 := by
  intro p hp
  have h : env25444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25443_25444 : H12AffineEnvironment.transform 6 8 env25443 = env25444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25443 == env25444) = true)

theorem identity25444 : scanCanonicalize (H12AffineFastState.compose env25444 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound25444 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,77898,272392,8388608,8410386,8192,64,10588,8393985,8480026,8737863,75103,8661016,256,21792,16464,513]

theorem envBound25445 : H12AffineFastState.Bounded env25445 := by
  intro p hp
  have h : env25445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25444_25445 : H12AffineEnvironment.transform 16 90139 env25444 = env25445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env25444 == env25445) = true)

def env25446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,77898,272392,16,21762,8192,64,10588,5393,91402,349271,75103,272392,256,21792,16464,513]

theorem envBound25446 : H12AffineFastState.Bounded env25446 := by
  intro p hp
  have h : env25446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25445_25446 : H12AffineEnvironment.transform 22 16 env25445 = env25446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25445 == env25446) = true)

theorem identity25446 : scanCanonicalize (H12AffineFastState.compose env25446 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25446 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,79131,262144,1024,8541,77898,272392,16,2,8192,64,10588,5393,77834,328023,75103,272392,256,32,5456,513]

theorem envBound25447 : H12AffineFastState.Bounded env25447 := by
  intro p hp
  have h : env25447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25446_25447 : H12AffineEnvironment.transform 13 5376 env25446 = env25447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25446 == env25447) = true)

theorem identity25447 : scanCanonicalize (H12AffineFastState.compose env25447 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound25447 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9499,4096,262144,1024,8541,5457,272392,16,2,8192,64,10588,5393,5393,271436,68,272392,256,32,5456,513]

theorem envBound25448 : H12AffineFastState.Bounded env25448 := by
  intro p hp
  have h : env25448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25447_25448 : H12AffineEnvironment.transform 15 9499 env25447 = env25448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env25447 == env25448) = true)

theorem identity25448 : scanCanonicalize (H12AffineFastState.compose env25448 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound25448 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env25449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9499,4096,10281,1024,8541,5457,33,16,2,8192,64,10588,5393,5393,3173,68,33,256,32,5456,513]

theorem envBound25449 : H12AffineFastState.Bounded env25449 := by
  intro p hp
  have h : env25449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25448_25449 : H12AffineEnvironment.transform 17 10281 env25448 = env25449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25448 == env25449) = true)

theorem identity25449 : scanCanonicalize (H12AffineFastState.compose env25449 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound25449 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env25450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,5376,8540,9499,4096,9292,1024,8541,5457,33,16,2,8192,64,9529,5393,5393,0,68,33,256,32,5456,513]

theorem envBound25450 : H12AffineFastState.Bounded env25450 := by
  intro p hp
  have h : env25450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25449_25450 : H12AffineEnvironment.transform 10 1125 env25449 = env25450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env25449 == env25450) = true)

theorem identity25450 : scanCanonicalize (H12AffineFastState.compose env25450 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5212) := by decide +kernel

theorem selectedBound25450 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env25451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,5212,5376,5376,4423,4096,4112,1024,5377,5457,33,16,2,5212,64,4453,5393,5393,0,68,33,256,32,5456,513]

theorem envBound25451 : H12AffineFastState.Bounded env25451 := by
  intro p hp
  have h : env25451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25450_25451 : H12AffineEnvironment.transform 12 5212 env25450 = env25451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5212 env25450 == env25451) = true)

theorem identity25451 : scanCanonicalize (H12AffineFastState.compose env25451 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25451 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env25452 : List Nat := [2,4,8,16,32,0,8,256,512,1024,1061,4096,5148,5376,5376,4359,4096,4112,1024,5377,5393,33,16,2,5148,0,4389,5393,5393,0,4,33,256,32,5392,513]

theorem envBound25452 : H12AffineFastState.Bounded env25452 := by
  intro p hp
  have h : env25452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25451_25452 : H12AffineEnvironment.transform 5 0 env25451 = env25452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25451 == env25452) = true)

theorem identity25452 : scanCanonicalize (H12AffineFastState.compose env25452 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound25452 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env25453 : List Nat := [2,4,8,16,32,0,8,256,512,1024,1061,1589,553,821,821,1842,1589,1573,1024,820,804,33,16,2,553,0,1808,804,804,0,4,33,256,32,805,513]

theorem envBound25453 : H12AffineFastState.Bounded env25453 := by
  intro p hp
  have h : env25453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25452_25453 : H12AffineEnvironment.transform 11 1589 env25452 = env25453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env25452 == env25453) = true)

theorem identity25453 : scanCanonicalize (H12AffineFastState.compose env25453 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound25453 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25454 : List Nat := [2,4,8,16,32,0,8,256,32,1024,1061,1045,9,277,277,1298,1045,1029,1024,276,260,33,16,2,9,0,1328,260,260,0,4,33,256,32,261,33]

theorem envBound25454 : H12AffineFastState.Bounded env25454 := by
  intro p hp
  have h : env25454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25453_25454 : H12AffineEnvironment.transform 8 32 env25453 = env25454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env25453 == env25454) = true)

def env25455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,77898,272392,17,21763,8192,64,10588,5392,91403,349270,75103,272393,256,21792,16464,513]

theorem envBound25455 : H12AffineFastState.Bounded env25455 := by
  intro p hp
  have h : env25455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25445_25455 : H12AffineEnvironment.transform 22 17 env25445 = env25455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25445 == env25455) = true)

theorem identity25455 : scanCanonicalize (H12AffineFastState.compose env25455 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound25455 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,32040,1024,29789,77898,21792,17,21763,8192,64,10588,5392,91403,76158,75103,21793,256,21792,16464,513]

theorem envBound25456 : H12AffineFastState.Bounded env25456 := by
  intro p hp
  have h : env25456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25455_25456 : H12AffineEnvironment.transform 17 32040 env25455 = env25456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env25455 == env25456) = true)

theorem identity25456 : scanCanonicalize (H12AffineFastState.compose env25456 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25456 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25457 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,29004,65536,90139,30776,272,29005,77898,20528,17,20499,8192,64,10588,4096,90139,76158,73807,20529,256,20528,16464,513]

theorem envBound25457 : H12AffineFastState.Bounded env25457 := by
  intro p hp
  have h : env25457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25456_25457 : H12AffineEnvironment.transform 9 272 env25456 = env25457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25456 == env25457) = true)

def env25458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77898,272393,8388608,8410386,8193,64,215367,8393985,8480026,8795229,75102,8661016,256,21792,16464,513]

theorem envBound25458 : H12AffineFastState.Bounded env25458 := by
  intro p hp
  have h : env25458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25443_25458 : H12AffineEnvironment.transform 6 9 env25443 = env25458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25443 == env25458) = true)

def env25459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77898,272393,16,21762,8193,64,215367,5393,91402,406605,75102,272392,256,21792,16464,513]

theorem envBound25459 : H12AffineFastState.Bounded env25459 := by
  intro p hp
  have h : env25459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25458_25459 : H12AffineEnvironment.transform 22 16 env25458 = env25459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25458 == env25459) = true)

def env25460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,77898,272393,16,2,8193,64,203847,5393,77834,406605,75102,272392,256,32,5456,513]

theorem envBound25460 : H12AffineFastState.Bounded env25460 := by
  intro p hp
  have h : env25460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25459_25460 : H12AffineEnvironment.transform 13 5376 env25459 = env25460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25459 == env25460) = true)

theorem identity25460 : scanCanonicalize (H12AffineFastState.compose env25460 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound25460 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env25461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13389,262144,1024,8540,77898,272393,16,2,8193,64,75786,5393,77834,262144,75102,272392,256,32,5456,513]

theorem envBound25461 : H12AffineFastState.Bounded env25461 := by
  intro p hp
  have h : env25461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25460_25461 : H12AffineEnvironment.transform 16 13389 env25460 = env25461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env25460 == env25461) = true)

theorem identity25461 : scanCanonicalize (H12AffineFastState.compose env25461 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound25461 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env25462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13389,10281,1024,8540,77898,32,16,2,8193,64,75786,5393,77834,10281,75102,33,256,32,5456,513]

theorem envBound25462 : H12AffineFastState.Bounded env25462 := by
  intro p hp
  have h : env25462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25461_25462 : H12AffineEnvironment.transform 17 10281 env25461 = env25462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25461 == env25462) = true)

theorem identity25462 : scanCanonicalize (H12AffineFastState.compose env25462 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25462 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,65536,5392,2420,1024,1,69911,32,16,2,348,64,67927,5393,69975,2420,66563,33,256,32,5456,513]

theorem envBound25463 : H12AffineFastState.Bounded env25463 := by
  intro p hp
  have h : env25463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25462_25463 : H12AffineEnvironment.transform 12 349 env25462 = env25463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25462 == env25463) = true)

theorem identity25463 : scanCanonicalize (H12AffineFastState.compose env25463 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound25463 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1024,1,4161,32,16,2,348,64,2049,5393,4097,2420,1365,33,256,32,5456,513]

theorem envBound25464 : H12AffineFastState.Bounded env25464 := by
  intro p hp
  have h : env25464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25463_25464 : H12AffineEnvironment.transform 15 342 env25463 = env25464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env25463 == env25464) = true)

theorem identity25464 : scanCanonicalize (H12AffineFastState.compose env25464 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound25464 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1573,349,805,0,342,821,2420,1024,1,1636,32,16,2,348,64,2049,820,1572,2420,1365,33,256,32,885,513]

theorem envBound25465 : H12AffineFastState.Bounded env25465 := by
  intro p hp
  have h : env25465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25464_25465 : H12AffineEnvironment.transform 11 1573 env25464 = env25465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env25464 == env25465) = true)

theorem identity25465 : scanCanonicalize (H12AffineFastState.compose env25465 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound25465 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1572,1573,349,805,0,342,821,1872,1024,1,1636,32,16,2,348,64,1573,820,1572,1872,1365,33,256,32,885,513]

theorem envBound25466 : H12AffineFastState.Bounded env25466 := by
  intro p hp
  have h : env25466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25465_25466 : H12AffineEnvironment.transform 10 1572 env25465 = env25466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env25465 == env25466) = true)

def env25467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,272393,16,3,8193,64,203846,5393,77835,406605,75102,272392,256,33,5457,513]

theorem envBound25467 : H12AffineFastState.Bounded env25467 := by
  intro p hp
  have h : env25467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25459_25467 : H12AffineEnvironment.transform 13 5377 env25459 = env25467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25459 == env25467) = true)

theorem identity25467 : scanCanonicalize (H12AffineFastState.compose env25467 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound25467 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,262144,1024,8541,77898,272393,16,3,8193,64,10588,5393,77835,328023,75102,272392,256,33,5457,513]

theorem envBound25468 : H12AffineFastState.Bounded env25468 := by
  intro p hp
  have h : env25468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25467_25468 : H12AffineEnvironment.transform 16 79130 env25467 = env25468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env25467 == env25468) = true)

theorem identity25468 : scanCanonicalize (H12AffineFastState.compose env25468 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25468 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env25469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5392,262144,1024,8541,4160,272393,16,3,8193,64,10588,5393,4097,270685,1364,272392,256,33,5457,513]

theorem envBound25469 : H12AffineFastState.Bounded env25469 := by
  intro p hp
  have h : env25469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25468_25469 : H12AffineEnvironment.transform 15 8202 env25468 = env25469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25468 == env25469) = true)

theorem identity25469 : scanCanonicalize (H12AffineFastState.compose env25469 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25469 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25470 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,5392,262144,1024,8460,4113,272393,16,3,8193,17,10509,5393,4097,270604,1285,272392,256,33,5376,513]

theorem envBound25470 : H12AffineFastState.Bounded env25470 := by
  intro p hp
  have h : env25470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25469_25470 : H12AffineEnvironment.transform 5 17 env25469 = env25470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25469 == env25470) = true)

theorem identity25470 : scanCanonicalize (H12AffineFastState.compose env25470 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound25470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25471 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,300,5377,33,294,5392,262144,1024,32,4113,264485,16,3,301,17,2081,5393,4097,262176,1285,264484,256,33,5376,513]

theorem envBound25471 : H12AffineFastState.Bounded env25471 := by
  intro p hp
  have h : env25471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25470_25471 : H12AffineEnvironment.transform 12 300 env25470 = env25471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env25470 == env25471) = true)

theorem identity25471 : scanCanonicalize (H12AffineFastState.compose env25471 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25471 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25472 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,9,5156,33,3,5173,262144,1024,32,4113,264192,16,3,8,17,2081,5172,4097,262176,1056,264193,37,33,5157,513]

theorem envBound25472 : H12AffineFastState.Bounded env25472 := by
  intro p hp
  have h : env25472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25471_25472 : H12AffineEnvironment.transform 7 37 env25471 = env25472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25471 == env25472) = true)

theorem identity25472 : scanCanonicalize (H12AffineFastState.compose env25472 (packedSelected [14] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound25472 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25473 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,9,5156,33,3,5173,2080,1024,32,4113,32,16,3,8,17,2081,5172,4097,2048,1056,33,37,33,5157,513]

theorem envBound25473 : H12AffineFastState.Bounded env25473 := by
  intro p hp
  have h : env25473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25472_25473 : H12AffineEnvironment.transform 17 2080 env25472 = env25473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env25472 == env25473) = true)

theorem identity25473 : scanCanonicalize (H12AffineFastState.compose env25473 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound25473 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25474 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,4096,9,5156,33,3,5173,1044,1024,32,4113,32,16,3,8,17,1045,5172,4097,1076,1056,33,37,33,5157,513]

theorem envBound25474 : H12AffineFastState.Bounded env25474 := by
  intro p hp
  have h : env25474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25473_25474 : H12AffineEnvironment.transform 10 1076 env25473 = env25474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env25473 == env25474) = true)

theorem identity25474 : scanCanonicalize (H12AffineFastState.compose env25474 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25474 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25475 : List Nat := [2,4,8,16,32,17,9,37,1,1024,1076,4096,9,5156,33,3,5173,1044,1024,32,4113,32,16,3,8,17,1045,5172,4097,1076,1056,33,37,33,5157,0]

theorem envBound25475 : H12AffineFastState.Bounded env25475 := by
  intro p hp
  have h : env25475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25474_25475 : H12AffineEnvironment.transform 8 1 env25474 = env25475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25474 == env25475) = true)

def env25476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77898,272393,17,21763,8193,64,215367,5392,91403,406604,75102,272393,256,21792,16464,513]

theorem envBound25476 : H12AffineFastState.Bounded env25476 := by
  intro p hp
  have h : env25476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25458_25476 : H12AffineEnvironment.transform 22 17 env25458 = env25476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25458 == env25476) = true)

theorem identity25476 : scanCanonicalize (H12AffineFastState.compose env25476 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound25476 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,77898,272393,17,21763,8193,64,10588,5392,91403,349271,75102,272393,256,21792,16464,513]

theorem envBound25477 : H12AffineFastState.Bounded env25477 := by
  intro p hp
  have h : env25477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25476_25477 : H12AffineEnvironment.transform 16 90139 env25476 = env25477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env25476 == env25477) = true)

theorem identity25477 : scanCanonicalize (H12AffineFastState.compose env25477 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound25477 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10281,1024,29788,77898,32,17,21763,8193,64,10588,5392,91403,97406,75102,32,256,21792,16464,513]

theorem envBound25478 : H12AffineFastState.Bounded env25478 := by
  intro p hp
  have h : env25478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25477_25478 : H12AffineEnvironment.transform 17 10281 env25477 = env25478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25477 == env25478) = true)

theorem identity25478 : scanCanonicalize (H12AffineFastState.compose env25478 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound25478 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,5392,10281,1024,29788,17729,32,17,21763,8193,64,10588,5392,4096,2421,20565,32,256,21792,16464,513]

theorem envBound25479 : H12AffineFastState.Bounded env25479 := by
  intro p hp
  have h : env25479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25478_25479 : H12AffineEnvironment.transform 15 29963 env25478 = env25479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env25478 == env25479) = true)

theorem identity25479 : scanCanonicalize (H12AffineFastState.compose env25479 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25479 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21591,5392,2421,1024,21760,17729,32,17,21763,349,64,2048,5392,4096,2421,20565,32,256,21792,16464,513]

theorem envBound25480 : H12AffineFastState.Bounded env25480 := by
  intro p hp
  have h : env25480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25479_25480 : H12AffineEnvironment.transform 12 348 env25479 = env25480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25479 == env25480) = true)

theorem identity25480 : scanCanonicalize (H12AffineFastState.compose env25480 (packedSelected [4,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound25480 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env25481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,80,262,5392,2421,1024,81,4112,32,17,82,349,64,2048,5392,4096,2421,1284,32,256,113,5377,513]

theorem envBound25481 : H12AffineFastState.Bounded env25481 := by
  intro p hp
  have h : env25481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25480_25481 : H12AffineEnvironment.transform 13 5457 env25480 = env25481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env25480 == env25481) = true)

def env25482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,8388608,10577240,8328,64,2259212,8393985,10507600,8795348,2102685,8661017,256,21792,16464,2175563]

theorem envBound25482 : H12AffineFastState.Bounded env25482 := by
  intro p hp
  have h : env25482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25441_25482 : H12AffineEnvironment.transform 21 272513 env25441 = env25482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25441 == env25482) = true)

theorem identity25482 : scanCanonicalize (H12AffineFastState.compose env25482 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 2175066) := by decide +kernel

theorem selectedBound25482 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,2175066,21762,8328,64,2259212,2172251,91402,2557070,2102685,2431043,256,21792,16464,2175563]

theorem envBound25483 : H12AffineFastState.Bounded env25483 := by
  intro p hp
  have h : env25483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25482_25483 : H12AffineEnvironment.transform 22 2175066 env25482 = env25483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175066 env25482 == env25483) = true)

def env25484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,2097152,33,2175066,21762,8328,64,2259212,2172251,91402,2305070,2102685,2175203,256,21792,16464,2175563]

theorem envBound25484 : H12AffineFastState.Bounded env25484 := by
  intro p hp
  have h : env25484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25483_25484 : H12AffineEnvironment.transform 17 10400 env25483 = env25484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env25483 == env25484) = true)

theorem identity25484 : scanCanonicalize (H12AffineFastState.compose env25484 (packedSelected [1,11,17,18,19,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound25484 : packedSelected [1,11,17,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env25485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,77898,33,16,21762,8328,64,215366,5393,91402,138340,75223,169,256,21792,16464,513]

theorem envBound25485 : H12AffineFastState.Bounded env25485 := by
  intro p hp
  have h : env25485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25484_25485 : H12AffineEnvironment.transform 20 77898 env25484 = env25485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env25484 == env25485) = true)

def env25486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,77898,33,16,2,8328,64,203846,5393,77834,138340,75223,169,256,32,5456,513]

theorem envBound25486 : H12AffineFastState.Bounded env25486 := by
  intro p hp
  have h : env25486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25485_25486 : H12AffineEnvironment.transform 13 5376 env25485 = env25486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25485 == env25486) = true)

theorem identity25486 : scanCanonicalize (H12AffineFastState.compose env25486 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound25486 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env25487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79250,10400,1024,8661,77898,33,16,2,8328,64,10708,5393,77834,76278,75223,169,256,32,5456,513]

theorem envBound25487 : H12AffineFastState.Bounded env25487 := by
  intro p hp
  have h : env25487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25486_25487 : H12AffineEnvironment.transform 16 79250 env25486 = env25487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env25486 == env25487) = true)

theorem identity25487 : scanCanonicalize (H12AffineFastState.compose env25487 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25487 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10281,1024,8540,77898,33,16,2,8193,64,10589,5393,77834,76159,75102,32,256,32,5456,513]

theorem envBound25488 : H12AffineFastState.Bounded env25488 := by
  intro p hp
  have h : env25488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25487_25488 : H12AffineEnvironment.transform 6 9 env25487 = env25488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25487 == env25488) = true)

def env25489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1024,8660,77898,33,16,3,8328,64,203847,5393,77835,138340,75223,169,256,33,5457,513]

theorem envBound25489 : H12AffineFastState.Bounded env25489 := by
  intro p hp
  have h : env25489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25485_25489 : H12AffineEnvironment.transform 13 5377 env25485 = env25489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25485 == env25489) = true)

theorem identity25489 : scanCanonicalize (H12AffineFastState.compose env25489 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25489 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77898,33,16,3,8193,64,203847,5393,77835,138340,75102,32,256,33,5457,513]

theorem envBound25490 : H12AffineFastState.Bounded env25490 := by
  intro p hp
  have h : env25490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25489_25490 : H12AffineEnvironment.transform 6 9 env25489 = env25490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25489 == env25490) = true)

theorem identity25490 : scanCanonicalize (H12AffineFastState.compose env25490 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound25490 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env25491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70678,10281,1024,8541,77898,33,16,3,8193,64,2129,5393,77835,67698,75102,32,256,33,5457,513]

theorem envBound25491 : H12AffineFastState.Bounded env25491 := by
  intro p hp
  have h : env25491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25490_25491 : H12AffineEnvironment.transform 16 70678 env25490 = env25491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env25490 == env25491) = true)

theorem identity25491 : scanCanonicalize (H12AffineFastState.compose env25491 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25491 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,13340,10281,1024,8541,4160,33,16,3,8193,64,2129,5393,4097,10360,1364,32,256,33,5457,513]

theorem envBound25492 : H12AffineFastState.Bounded env25492 := by
  intro p hp
  have h : env25492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25491_25492 : H12AffineEnvironment.transform 15 8202 env25491 = env25492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25491 == env25492) = true)

theorem identity25492 : scanCanonicalize (H12AffineFastState.compose env25492 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25492 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5441,2420,1024,0,4160,33,16,3,348,64,2129,5393,4097,2341,1364,32,256,33,5457,513]

theorem envBound25493 : H12AffineFastState.Bounded env25493 := by
  intro p hp
  have h : env25493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25492_25493 : H12AffineEnvironment.transform 12 349 env25492 = env25493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25492 == env25493) = true)

theorem identity25493 : scanCanonicalize (H12AffineFastState.compose env25493 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25493 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25494 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,349,4404,1,343,4468,2420,53,0,4160,33,16,3,348,64,2129,4388,4097,2341,353,32,256,33,4452,513]

theorem envBound25494 : H12AffineFastState.Bounded env25494 := by
  intro p hp
  have h : env25494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25493_25494 : H12AffineEnvironment.transform 9 53 env25493 = env25494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25493 == env25494) = true)

theorem identity25494 : scanCanonicalize (H12AffineFastState.compose env25494 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25494 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25495 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,1,114,4177,2129,53,0,4160,33,16,3,121,64,2129,4097,4097,2048,68,32,37,33,4161,513]

theorem envBound25495 : H12AffineFastState.Bounded env25495 := by
  intro p hp
  have h : env25495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25494_25495 : H12AffineEnvironment.transform 7 37 env25494 = env25495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25494 == env25495) = true)

theorem identity25495 : scanCanonicalize (H12AffineFastState.compose env25495 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25495 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25496 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,1,35,4096,2048,53,0,4113,33,16,3,40,17,2048,4097,4097,2048,21,32,37,33,4112,513]

theorem envBound25496 : H12AffineFastState.Bounded env25496 := by
  intro p hp
  have h : env25496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25495_25496 : H12AffineEnvironment.transform 5 17 env25495 = env25496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25495 == env25496) = true)

theorem identity25496 : scanCanonicalize (H12AffineFastState.compose env25496 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound25496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25497 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2609,41,2592,1,35,2609,2048,53,0,2592,33,16,3,40,17,2048,2608,2608,2048,21,32,37,33,2593,513]

theorem envBound25497 : H12AffineFastState.Bounded env25497 := by
  intro p hp
  have h : env25497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25496_25497 : H12AffineEnvironment.transform 11 2609 env25496 = env25497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env25496 == env25497) = true)

theorem identity25497 : scanCanonicalize (H12AffineFastState.compose env25497 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound25497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25498 : List Nat := [2,4,8,16,32,17,9,37,512,53,16,545,41,560,1,35,545,16,53,0,560,33,16,3,40,17,16,544,544,16,21,32,37,33,561,513]

theorem envBound25498 : H12AffineFastState.Bounded env25498 := by
  intro p hp
  have h : env25498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25497_25498 : H12AffineEnvironment.transform 10 16 env25497 = env25498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env25497 == env25498) = true)

def env25499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,2097152,32,2175066,21762,8328,64,2259212,2172251,91402,2305071,2102685,2175202,256,21792,16464,2175563]

theorem envBound25499 : H12AffineFastState.Bounded env25499 := by
  intro p hp
  have h : env25499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25483_25499 : H12AffineEnvironment.transform 17 10401 env25483 = env25499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env25483 == env25499) = true)

theorem identity25499 : scanCanonicalize (H12AffineFastState.compose env25499 (packedSelected [1,11,17,18,19,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound25499 : packedSelected [1,11,17,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env25500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,131072,10401,1024,29909,2097152,32,2115032,21762,8328,64,2259212,2117849,4232,2251181,2102685,2114912,256,21792,16464,2115529]

theorem envBound25500 : H12AffineFastState.Bounded env25500 := by
  intro p hp
  have h : env25500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25499_25500 : H12AffineEnvironment.transform 15 30082 env25499 = env25500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env25499 == env25500) = true)

theorem identity25500 : scanCanonicalize (H12AffineFastState.compose env25500 (packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound25500 : packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env25501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8202,131072,10401,1024,8541,2097152,32,2101328,138,8328,64,2239620,2098513,4232,2231333,2102685,2101480,256,168,5592,2101825]

theorem envBound25501 : H12AffineFastState.Bounded env25501 := by
  intro p hp
  have h : env25501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25500_25501 : H12AffineEnvironment.transform 13 5512 env25500 = env25501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env25500 == env25501) = true)

theorem identity25501 : scanCanonicalize (H12AffineFastState.compose env25501 (packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 13745) := by decide +kernel

theorem selectedBound25501 : packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env25502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8202,13745,10401,1024,8541,2097152,32,2101328,138,8328,64,2103605,2098513,4232,2111892,2102685,2101480,256,168,5592,2101825]

theorem envBound25502 : H12AffineFastState.Bounded env25502 := by
  intro p hp
  have h : env25502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25501_25502 : H12AffineEnvironment.transform 16 13745 env25501 = env25502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env25501 == env25502) = true)

theorem identity25502 : scanCanonicalize (H12AffineFastState.compose env25502 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound25502 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env25503 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5237,8353,8202,13388,10401,1024,8352,2097152,32,2101328,138,8328,64,2103496,2098348,4232,2111593,2102368,2101480,253,168,5157,2101825]

theorem envBound25503 : H12AffineFastState.Bounded env25503 := by
  intro p hp
  have h : env25503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25502_25503 : H12AffineEnvironment.transform 7 253 env25502 = env25503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env25502 == env25503) = true)

theorem identity25503 : scanCanonicalize (H12AffineFastState.compose env25503 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound25503 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25504 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5237,8353,8202,13388,10401,1024,8352,12392,32,8248,138,8328,64,10400,13508,4232,2049,9224,8320,253,168,5157,8745]

theorem envBound25504 : H12AffineFastState.Bounded env25504 := by
  intro p hp
  have h : env25504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25503_25504 : H12AffineEnvironment.transform 20 12392 env25503 = env25504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env25503 == env25504) = true)

theorem identity25504 : scanCanonicalize (H12AffineFastState.compose env25504 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound25504 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env25505 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,241,5237,80,251,5309,2128,1024,81,4249,32,201,138,121,64,2129,5173,4232,2049,1273,113,253,168,5157,728]

theorem envBound25505 : H12AffineFastState.Bounded env25505 := by
  intro p hp
  have h : env25505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25504_25505 : H12AffineEnvironment.transform 12 241 env25504 = env25505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env25504 == env25505) = true)

theorem identity25505 : scanCanonicalize (H12AffineFastState.compose env25505 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25505 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env25506 : List Nat := [2,4,8,16,32,64,128,253,512,52,2048,4096,241,4161,80,251,4233,2128,52,81,4249,32,201,138,121,64,2129,4097,4232,2049,205,113,253,168,4113,728]

theorem envBound25506 : H12AffineFastState.Bounded env25506 := by
  intro p hp
  have h : env25506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25505_25506 : H12AffineEnvironment.transform 9 52 env25505 = env25506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25505 == env25506) = true)

def env25507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,4194304,8388608,10577240,8328,64,6705548,8393984,10507600,8795349,2102684,12583064,256,21793,16464,2175562]

theorem envBound25507 : H12AffineFastState.Bounded env25507 := by
  intro p hp
  have h : env25507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25440_25507 : H12AffineEnvironment.transform 14 29909 env25440 = env25507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env25440 == env25507) = true)

def env25508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272512,8388608,10577240,8328,64,2259212,8393984,10507600,8795349,2102684,8661016,256,21793,16464,2175562]

theorem envBound25508 : H12AffineFastState.Bounded env25508 := by
  intro p hp
  have h : env25508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25507_25508 : H12AffineEnvironment.transform 21 272512 env25507 = env25508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25507 == env25508) = true)

def env25509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,272512,8388608,10563672,8328,64,2239500,8393984,10485840,8795349,2102684,8661016,256,33,5456,2175562]

theorem envBound25509 : H12AffineFastState.Bounded env25509 := by
  intro p hp
  have h : env25509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25508_25509 : H12AffineEnvironment.transform 13 5376 env25508 = env25509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25508 == env25509) = true)

def env25510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,2097152,32,8388608,10563672,8328,64,2239500,8393984,10485840,8526965,2102684,8388792,256,33,5456,2175562]

theorem envBound25510 : H12AffineFastState.Bounded env25510 := by
  intro p hp
  have h : env25510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25509_25510 : H12AffineEnvironment.transform 17 10400 env25509 = env25510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env25509 == env25510) = true)

theorem identity25510 : scanCanonicalize (H12AffineFastState.compose env25510 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound25510 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,78018,32,8388608,8388762,8328,64,203982,8393984,8466578,8526965,75102,8388792,256,33,5456,648]

theorem envBound25511 : H12AffineFastState.Bounded env25511 := by
  intro p hp
  have h : env25511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25510_25511 : H12AffineEnvironment.transform 20 78018 env25510 = env25511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env25510 == env25511) = true)

theorem identity25511 : scanCanonicalize (H12AffineFastState.compose env25511 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25511 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env25512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,77899,32,8388608,8388627,8193,64,203847,8393984,8466459,8526965,75102,8388657,256,33,5456,513]

theorem envBound25512 : H12AffineFastState.Bounded env25512 := by
  intro p hp
  have h : env25512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25511_25512 : H12AffineEnvironment.transform 6 9 env25511 = env25512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25511 == env25512) = true)

theorem identity25512 : scanCanonicalize (H12AffineFastState.compose env25512 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(22+1) ^^^ 210266) := by decide +kernel

theorem selectedBound25512 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env25513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,77899,32,210266,210249,8193,64,203847,204890,132417,76079,75102,210283,256,33,5456,513]

theorem envBound25513 : H12AffineFastState.Bounded env25513 := by
  intro p hp
  have h : env25513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25512_25513 : H12AffineEnvironment.transform 22 210266 env25512 = env25513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 210266 env25512 == env25513) = true)

theorem identity25513 : scanCanonicalize (H12AffineFastState.compose env25513 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound25513 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env25514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,70678,10281,1024,8541,77899,32,8524,8543,8193,64,2129,13388,69975,76079,75102,8573,256,33,5456,513]

theorem envBound25514 : H12AffineFastState.Bounded env25514 := by
  intro p hp
  have h : env25514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25513_25514 : H12AffineEnvironment.transform 16 70678 env25513 = env25514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env25513 == env25514) = true)

theorem identity25514 : scanCanonicalize (H12AffineFastState.compose env25514 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25514 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,13341,10281,1024,8541,4160,32,8524,8543,8193,64,2129,13388,12636,2340,1365,8573,256,33,5456,513]

theorem envBound25515 : H12AffineFastState.Bounded env25515 := by
  intro p hp
  have h : env25515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25514_25515 : H12AffineEnvironment.transform 15 8203 env25514 = env25515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25514 == env25515) = true)

theorem identity25515 : scanCanonicalize (H12AffineFastState.compose env25515 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25515 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5441,2421,1024,1,4160,32,16,3,349,64,2129,5392,4096,2340,1365,33,256,33,5456,513]

theorem envBound25516 : H12AffineFastState.Bounded env25516 := by
  intro p hp
  have h : env25516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25515_25516 : H12AffineEnvironment.transform 12 348 env25515 = env25516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25515 == env25516) = true)

theorem identity25516 : scanCanonicalize (H12AffineFastState.compose env25516 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25516 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,348,3344,0,343,3409,2421,1024,1,2128,32,16,3,349,64,2129,3328,2064,2340,1365,33,256,33,3392,513]

theorem envBound25517 : H12AffineFastState.Bounded env25517 := by
  intro p hp
  have h : env25517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25516_25517 : H12AffineEnvironment.transform 11 2064 env25516 = env25517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25516 == env25517) = true)

theorem identity25517 : scanCanonicalize (H12AffineFastState.compose env25517 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25517 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25518 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2064,41,3173,0,34,3108,2048,1024,1,2128,32,16,3,40,64,2129,3189,2064,2129,1056,33,117,33,3125,513]

theorem envBound25518 : H12AffineFastState.Bounded env25518 := by
  intro p hp
  have h : env25518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25517_25518 : H12AffineEnvironment.transform 7 117 env25517 = env25518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25517 == env25518) = true)

theorem identity25518 : scanCanonicalize (H12AffineFastState.compose env25518 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25518 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env25519 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2064,41,3125,0,34,3108,2048,1024,1,2048,32,16,3,40,16,2049,3109,2064,2049,1056,33,37,33,3125,513]

theorem envBound25519 : H12AffineFastState.Bounded env25519 := by
  intro p hp
  have h : env25519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25518_25519 : H12AffineEnvironment.transform 5 16 env25518 = env25519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25518 == env25519) = true)

theorem identity25519 : scanCanonicalize (H12AffineFastState.compose env25519 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25520 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,16,41,1077,0,34,1060,0,1024,1,0,32,16,3,40,16,1,1061,16,1,1056,33,37,33,1077,513]

theorem envBound25520 : H12AffineFastState.Bounded env25520 := by
  intro p hp
  have h : env25520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25519_25520 : H12AffineEnvironment.transform 10 0 env25519 = env25520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25519 == env25520) = true)

theorem identity25520 : scanCanonicalize (H12AffineFastState.compose env25520 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound25520 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25521 : List Nat := [2,4,8,16,32,16,9,37,11,1024,0,16,41,1077,0,34,1060,0,1024,1,0,32,16,3,40,16,1,1061,16,1,1056,33,37,33,1077,10]

theorem envBound25521 : H12AffineFastState.Bounded env25521 := by
  intro p hp
  have h : env25521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25520_25521 : H12AffineEnvironment.transform 8 11 env25520 = env25521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env25520 == env25521) = true)

theorem identity25521 : scanCanonicalize (H12AffineFastState.compose env25521 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 56) := by decide +kernel

theorem selectedBound25521 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25522 : List Nat := [2,4,8,16,32,16,9,37,11,56,0,16,41,13,0,34,28,0,56,1,0,32,16,3,40,16,1,29,16,1,24,33,37,33,13,10]

theorem envBound25522 : H12AffineFastState.Bounded env25522 := by
  intro p hp
  have h : env25522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25521_25522 : H12AffineEnvironment.transform 9 56 env25521 = env25522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 56 env25521 == env25522) = true)

theorem identity25522 : scanCanonicalize (H12AffineFastState.compose env25522 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound25522 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25523 : List Nat := [2,4,8,16,12,16,9,9,11,20,0,16,5,13,0,14,28,0,20,1,0,12,16,3,4,16,1,29,16,1,24,13,9,13,13,10]

theorem envBound25523 : H12AffineFastState.Bounded env25523 := by
  intro p hp
  have h : env25523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25522_25523 : H12AffineEnvironment.transform 4 12 env25522 = env25523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env25522 == env25523) = true)

theorem identity25523 : scanCanonicalize (H12AffineFastState.compose env25523 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound25523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25524 : List Nat := [2,4,8,9,12,9,9,9,11,13,0,9,5,13,0,14,5,0,13,1,0,12,9,3,4,9,1,4,9,1,1,13,9,13,13,10]

theorem envBound25524 : H12AffineFastState.Bounded env25524 := by
  intro p hp
  have h : env25524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25523_25524 : H12AffineEnvironment.transform 3 9 env25523 = env25524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env25523 == env25524) = true)

theorem identity25524 : scanCanonicalize (H12AffineFastState.compose env25524 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25524 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25525 : List Nat := [2,4,5,4,1,4,4,4,6,0,0,4,5,0,0,3,5,0,0,1,0,1,4,3,4,4,1,4,4,1,1,0,4,0,0,7]

theorem envBound25525 : H12AffineFastState.Bounded env25525 := by
  intro p hp
  have h : env25525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25524_25525 : H12AffineEnvironment.transform 2 5 env25524 = env25525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25524 == env25525) = true)

def env25526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,2097152,33,8388608,10563672,8328,64,2239500,8393984,10485840,8526964,2102684,8388793,256,33,5456,2175562]

theorem envBound25526 : H12AffineFastState.Bounded env25526 := by
  intro p hp
  have h : env25526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25509_25526 : H12AffineEnvironment.transform 17 10401 env25509 = env25526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env25509 == env25526) = true)

theorem identity25526 : scanCanonicalize (H12AffineFastState.compose env25526 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 2175186) := by decide +kernel

theorem selectedBound25526 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,2097152,33,2175186,138,8328,64,2239500,2172370,77954,2305190,2102684,2175083,256,33,5456,2175562]

theorem envBound25527 : H12AffineFastState.Bounded env25527 := by
  intro p hp
  have h : env25527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25526_25527 : H12AffineEnvironment.transform 22 2175186 env25526 = env25527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175186 env25526 == env25527) = true)

theorem identity25527 : scanCanonicalize (H12AffineFastState.compose env25527 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound25527 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env25528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1024,8660,77899,33,153,138,8328,64,203847,5529,77954,138477,75223,32,256,33,5456,513]

theorem envBound25528 : H12AffineFastState.Bounded env25528 := by
  intro p hp
  have h : env25528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25527_25528 : H12AffineEnvironment.transform 20 77899 env25527 = env25528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env25527 == env25528) = true)

theorem identity25528 : scanCanonicalize (H12AffineFastState.compose env25528 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound25528 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79131,10401,1024,8660,77899,33,153,138,8328,64,10588,5529,77954,76278,75223,32,256,33,5456,513]

theorem envBound25529 : H12AffineFastState.Bounded env25529 := by
  intro p hp
  have h : env25529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25528_25529 : H12AffineEnvironment.transform 16 79131 env25528 = env25529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env25528 == env25529) = true)

theorem identity25529 : scanCanonicalize (H12AffineFastState.compose env25529 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9618) := by decide +kernel

theorem selectedBound25529 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,9618,4233,10401,1024,8660,5593,33,153,138,8328,64,10588,5529,5392,3172,69,32,256,33,5456,513]

theorem envBound25530 : H12AffineFastState.Bounded env25530 := by
  intro p hp
  have h : env25530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25529_25530 : H12AffineEnvironment.transform 15 9618 env25529 = env25530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9618 env25529 == env25530) = true)

theorem identity25530 : scanCanonicalize (H12AffineFastState.compose env25530 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound25530 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env25531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2200,8192,3480,8661,9618,2065,10401,1024,8660,3393,33,153,138,8328,64,10588,3329,3464,3172,69,32,256,33,3528,513]

theorem envBound25531 : H12AffineFastState.Bounded env25531 := by
  intro p hp
  have h : env25531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25530_25531 : H12AffineEnvironment.transform 11 2200 env25530 = env25531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env25530 == env25531) = true)

theorem identity25531 : scanCanonicalize (H12AffineFastState.compose env25531 (packedSelected [0,1,3,4,5,7,8,9,11,12,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound25531 : packedSelected [0,1,3,4,5,7,8,9,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env25532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1124,1276,8192,508,8661,9618,1141,9413,1024,8660,293,33,153,138,8328,64,9528,357,492,0,69,32,256,33,428,513]

theorem envBound25532 : H12AffineFastState.Bounded env25532 := by
  intro p hp
  have h : env25532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25531_25532 : H12AffineEnvironment.transform 10 1124 env25531 = env25532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env25531 == env25532) = true)

theorem identity25532 : scanCanonicalize (H12AffineFastState.compose env25532 (packedSelected [0,1,8,10,14,15,27] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound25532 : packedSelected [0,1,8,10,14,15,27] rootPS < 2^1333 := by decide +kernel

def env25533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1124,1276,1505,508,1076,115,1141,292,1024,1077,293,33,153,138,1385,64,217,357,492,0,69,32,256,33,428,513]

theorem envBound25533 : H12AffineFastState.Bounded env25533 := by
  intro p hp
  have h : env25533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25532_25533 : H12AffineEnvironment.transform 12 1505 env25532 = env25533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env25532 == env25533) = true)

theorem identity25533 : scanCanonicalize (H12AffineFastState.compose env25533 (packedSelected [0,1,2,3,5,6,7,8,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25533 : packedSelected [0,1,2,3,5,6,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env25534 : List Nat := [2,4,8,16,32,64,128,256,512,272,372,492,241,508,292,115,357,292,272,293,293,33,153,138,121,64,217,357,492,0,69,32,256,33,428,513]

theorem envBound25534 : H12AffineFastState.Bounded env25534 := by
  intro p hp
  have h : env25534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25533_25534 : H12AffineEnvironment.transform 9 272 env25533 = env25534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25533 == env25534) = true)

theorem identity25534 : scanCanonicalize (H12AffineFastState.compose env25534 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25534 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25535 : List Nat := [2,4,8,16,32,64,9,256,512,272,372,357,120,373,292,115,357,292,272,293,293,33,16,3,121,64,80,357,357,0,69,32,256,33,293,513]

theorem envBound25535 : H12AffineFastState.Bounded env25535 := by
  intro p hp
  have h : env25535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25534_25535 : H12AffineEnvironment.transform 6 9 env25534 = env25535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25534 == env25535) = true)

theorem identity25535 : scanCanonicalize (H12AffineFastState.compose env25535 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25535 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25536 : List Nat := [2,4,8,16,32,1,9,256,512,272,309,292,57,308,292,50,292,292,272,293,293,33,16,3,56,1,17,292,292,0,4,32,256,33,293,513]

theorem envBound25536 : H12AffineFastState.Bounded env25536 := by
  intro p hp
  have h : env25536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25535_25536 : H12AffineEnvironment.transform 5 1 env25535 = env25536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25535 == env25536) = true)

theorem identity25536 : scanCanonicalize (H12AffineFastState.compose env25536 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25536 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25537 : List Nat := [2,4,8,16,1,1,9,256,512,272,276,261,24,277,261,19,261,261,272,260,260,0,16,3,25,1,17,261,261,0,4,1,256,0,260,513]

theorem envBound25537 : H12AffineFastState.Bounded env25537 := by
  intro p hp
  have h : env25537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25536_25537 : H12AffineEnvironment.transform 4 1 env25536 = env25537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25536 == env25537) = true)

theorem identity25537 : scanCanonicalize (H12AffineFastState.compose env25537 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound25537 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25538 : List Nat := [2,4,8,16,1,1,9,21,512,5,1,16,24,0,16,19,16,16,5,17,17,0,16,3,25,1,17,16,16,0,4,1,21,0,17,513]

theorem envBound25538 : H12AffineFastState.Bounded env25538 := by
  intro p hp
  have h : env25538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25537_25538 : H12AffineEnvironment.transform 7 21 env25537 = env25538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env25537 == env25538) = true)

theorem identity25538 : scanCanonicalize (H12AffineFastState.compose env25538 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25538 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25539 : List Nat := [2,4,8,0,1,1,9,5,512,5,1,0,8,0,0,3,0,0,5,1,1,0,0,3,9,1,1,0,0,0,4,1,5,0,1,513]

theorem envBound25539 : H12AffineFastState.Bounded env25539 := by
  intro p hp
  have h : env25539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25538_25539 : H12AffineEnvironment.transform 3 0 env25538 = env25539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25538 == env25539) = true)

theorem identity25539 : scanCanonicalize (H12AffineFastState.compose env25539 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25539 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25540 : List Nat := [2,4,8,0,1,1,9,5,1,5,1,0,8,0,0,3,0,0,5,1,1,0,0,3,9,1,1,0,0,0,4,1,5,0,1,0]

theorem envBound25540 : H12AffineFastState.Bounded env25540 := by
  intro p hp
  have h : env25540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25539_25540 : H12AffineEnvironment.transform 8 1 env25539 = env25540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25539 == env25540) = true)

def env25541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,272512,8388608,10563673,8328,64,2239501,8393984,10485841,8795349,2102684,8661016,256,32,5457,2175562]

theorem envBound25541 : H12AffineFastState.Bounded env25541 := by
  intro p hp
  have h : env25541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25508_25541 : H12AffineEnvironment.transform 13 5377 env25508 = env25541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25508 == env25541) = true)

def env25542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1024,8661,2097152,32,8388608,10563673,8328,64,2239501,8393984,10485841,8526965,2102684,8388792,256,32,5457,2175562]

theorem envBound25542 : H12AffineFastState.Bounded env25542 := by
  intro p hp
  have h : env25542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25541_25542 : H12AffineEnvironment.transform 17 10400 env25541 = env25542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env25541 == env25542) = true)

theorem identity25542 : scanCanonicalize (H12AffineFastState.compose env25542 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound25542 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1024,8661,77899,32,8388608,8388626,8328,64,203846,8393984,8466458,8526965,75223,8388792,256,32,5457,513]

theorem envBound25543 : H12AffineFastState.Bounded env25543 := by
  intro p hp
  have h : env25543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25542_25543 : H12AffineEnvironment.transform 20 77899 env25542 = env25543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env25542 == env25543) = true)

def env25544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8660,65536,131072,10400,1024,8661,77131,32,8388608,8388626,8328,64,196934,8390656,8465690,8520053,75223,8388792,256,32,2129,513]

theorem envBound25544 : H12AffineFastState.Bounded env25544 := by
  intro p hp
  have h : env25544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25543_25544 : H12AffineEnvironment.transform 11 3328 env25543 = env25544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env25543 == env25544) = true)

theorem identity25544 : scanCanonicalize (H12AffineFastState.compose env25544 (packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 65815) := by decide +kernel

theorem selectedBound25544 : packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env25545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8660,65536,131072,10400,1024,8661,77131,32,65815,65797,8328,64,196934,67863,11277,196706,75223,65967,256,32,2129,513]

theorem envBound25545 : H12AffineFastState.Bounded env25545 := by
  intro p hp
  have h : env25545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25544_25545 : H12AffineEnvironment.transform 22 65815 env25544 = env25545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65815 env25544 == env25545) = true)

theorem identity25545 : scanCanonicalize (H12AffineFastState.compose env25545 (packedSelected [1,2,3,6,7,11,16,20,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 2112) := by decide +kernel

theorem selectedBound25545 : packedSelected [1,2,3,6,7,11,16,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env25546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8660,65536,2112,10400,1024,8661,77131,32,65815,65797,8328,64,67846,67863,11277,67618,75223,65967,256,32,2129,513]

theorem envBound25546 : H12AffineFastState.Bounded env25546 := by
  intro p hp
  have h : env25546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25545_25546 : H12AffineEnvironment.transform 16 2112 env25545 = env25546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2112 env25545 == env25546) = true)

theorem identity25546 : scanCanonicalize (H12AffineFastState.compose env25546 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound25546 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env25547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8660,479,2112,10400,1024,8661,11412,32,200,218,8328,64,2265,2248,11277,2557,9224,112,256,32,2129,513]

theorem envBound25547 : H12AffineFastState.Bounded env25547 := by
  intro p hp
  have h : env25547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25546_25547 : H12AffineEnvironment.transform 15 479 env25546 = env25547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env25546 == env25547) = true)

theorem identity25547 : scanCanonicalize (H12AffineFastState.compose env25547 (packedSelected [0,7,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound25547 : packedSelected [0,7,12,14] rootPS < 2^1333 := by decide +kernel

def env25548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,1173,2049,1345,479,2112,3125,1024,1344,2049,32,200,218,1053,64,2265,2248,2200,2557,157,112,256,32,2129,513]

theorem envBound25548 : H12AffineFastState.Bounded env25548 := by
  intro p hp
  have h : env25548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25547_25548 : H12AffineEnvironment.transform 12 1173 env25547 = env25548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env25547 == env25548) = true)

theorem identity25548 : scanCanonicalize (H12AffineFastState.compose env25548 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25548 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25549 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3328,1173,2049,1296,398,2065,3125,1024,1297,2049,32,153,139,1053,17,2184,2201,2200,2476,157,33,256,32,2048,513]

theorem envBound25549 : H12AffineFastState.Bounded env25549 := by
  intro p hp
  have h : env25549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25548_25549 : H12AffineEnvironment.transform 5 17 env25548 = env25549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25548 == env25549) = true)

theorem identity25549 : scanCanonicalize (H12AffineFastState.compose env25549 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound25549 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env25550 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,2493,40,2049,429,398,2065,2184,189,428,2049,32,153,139,160,17,2184,2201,2200,2476,157,33,256,32,2048,513]

theorem envBound25550 : H12AffineFastState.Bounded env25550 := by
  intro p hp
  have h : env25550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25549_25550 : H12AffineEnvironment.transform 9 189 env25549 = env25550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env25549 == env25550) = true)

theorem identity25550 : scanCanonicalize (H12AffineFastState.compose env25550 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25550 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env25551 : List Nat := [2,4,8,16,32,17,128,36,512,189,2048,2201,40,2049,137,170,2065,2184,189,136,2049,32,153,139,160,17,2184,2201,2200,2184,157,33,36,32,2048,513]

theorem envBound25551 : H12AffineFastState.Bounded env25551 := by
  intro p hp
  have h : env25551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25550_25551 : H12AffineEnvironment.transform 7 36 env25550 = env25551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25550 == env25551) = true)

theorem identity25551 : scanCanonicalize (H12AffineFastState.compose env25551 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound25551 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env25552 : List Nat := [2,4,8,16,32,17,128,36,512,189,16,137,40,17,137,170,1,152,189,136,17,32,153,139,160,17,152,137,136,152,157,33,36,32,16,513]

theorem envBound25552 : H12AffineFastState.Bounded env25552 := by
  intro p hp
  have h : env25552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25551_25552 : H12AffineEnvironment.transform 10 16 env25551 = env25552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env25551 == env25552) = true)

theorem identity25552 : scanCanonicalize (H12AffineFastState.compose env25552 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25552 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25553 : List Nat := [2,4,8,16,32,17,9,36,512,52,16,0,40,17,0,35,1,17,52,1,17,32,16,2,41,17,17,0,1,17,20,33,36,32,16,513]

theorem envBound25553 : H12AffineFastState.Bounded env25553 := by
  intro p hp
  have h : env25553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25552_25553 : H12AffineEnvironment.transform 6 9 env25552 = env25553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25552 == env25553) = true)

theorem identity25553 : scanCanonicalize (H12AffineFastState.compose env25553 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25554 : List Nat := [2,4,8,16,32,17,9,36,1,52,16,0,40,17,0,35,1,17,52,1,17,32,16,2,41,17,17,0,1,17,20,33,36,32,16,0]

theorem envBound25554 : H12AffineFastState.Bounded env25554 := by
  intro p hp
  have h : env25554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25553_25554 : H12AffineEnvironment.transform 8 1 env25553 = env25554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25553 == env25554) = true)

theorem identity25554 : scanCanonicalize (H12AffineFastState.compose env25554 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound25554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25555 : List Nat := [2,4,8,16,10,17,9,14,1,30,16,0,2,17,0,9,1,17,30,1,17,10,16,2,3,17,17,0,1,17,20,11,14,10,16,0]

theorem envBound25555 : H12AffineFastState.Bounded env25555 := by
  intro p hp
  have h : env25555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25554_25555 : H12AffineEnvironment.transform 4 10 env25554 = env25555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env25554 == env25555) = true)

theorem identity25555 : scanCanonicalize (H12AffineFastState.compose env25555 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25555 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25556 : List Nat := [2,4,8,0,10,1,9,14,1,14,0,0,2,1,0,9,1,1,14,1,1,10,0,2,3,1,1,0,1,1,4,11,14,10,0,0]

theorem envBound25556 : H12AffineFastState.Bounded env25556 := by
  intro p hp
  have h : env25556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25555_25556 : H12AffineEnvironment.transform 3 0 env25555 = env25556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25555 == env25556) = true)

def env25557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8660,65536,131072,10400,1024,8661,77130,32,8388608,8388626,8328,64,196935,8390657,8465691,8520052,75223,8388792,256,32,2128,513]

theorem envBound25557 : H12AffineFastState.Bounded env25557 := by
  intro p hp
  have h : env25557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25543_25557 : H12AffineEnvironment.transform 11 3329 env25543 = env25557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env25543 == env25557) = true)

theorem identity25557 : scanCanonicalize (H12AffineFastState.compose env25557 (packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 65950) := by decide +kernel

theorem selectedBound25557 : packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env25558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8660,65536,131072,10400,1024,8661,77130,32,65950,65932,8328,64,196935,67999,11397,196842,75223,65830,256,32,2128,513]

theorem envBound25558 : H12AffineFastState.Bounded env25558 := by
  intro p hp
  have h : env25558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25557_25558 : H12AffineEnvironment.transform 22 65950 env25557 = env25558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65950 env25557 == env25558) = true)

theorem identity25558 : scanCanonicalize (H12AffineFastState.compose env25558 (packedSelected [1,2,4,5,6,8,9,11,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound25558 : packedSelected [1,2,4,5,6,8,9,11,16,20,24] rootPS < 2^1333 := by decide +kernel

def env25559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8660,479,131072,10400,1024,8661,11413,32,65,83,8328,64,131224,2112,11397,131381,9224,249,256,32,2128,513]

theorem envBound25559 : H12AffineFastState.Bounded env25559 := by
  intro p hp
  have h : env25559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25558_25559 : H12AffineEnvironment.transform 15 479 env25558 = env25559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env25558 == env25559) = true)

theorem identity25559 : scanCanonicalize (H12AffineFastState.compose env25559 (packedSelected [0,1,7,8,10,11,12,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 2113) := by decide +kernel

theorem selectedBound25559 : packedSelected [0,1,7,8,10,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env25560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8660,479,2113,10400,1024,8661,11413,32,65,83,8328,64,2265,2112,11397,2420,9224,249,256,32,2128,513]

theorem envBound25560 : H12AffineFastState.Bounded env25560 := by
  intro p hp
  have h : env25560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25559_25560 : H12AffineEnvironment.transform 16 2113 env25559 = env25560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env25559 == env25560) = true)

theorem identity25560 : scanCanonicalize (H12AffineFastState.compose env25560 (packedSelected [0,2,4,6,7,9,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25560 : packedSelected [0,2,4,6,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25561 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2065,8192,2048,8660,479,2113,10400,272,8661,10629,32,65,83,8328,64,2265,2112,10645,2420,8472,249,256,32,2128,513]

theorem envBound25561 : H12AffineFastState.Bounded env25561 := by
  intro p hp
  have h : env25561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25560_25561 : H12AffineEnvironment.transform 9 272 env25560 = env25561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25560 == env25561) = true)

theorem identity25561 : scanCanonicalize (H12AffineFastState.compose env25561 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25561 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25562 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2065,8192,2048,8581,398,2064,10400,272,8580,10629,32,16,2,8328,17,2184,2065,10645,2341,8472,168,256,32,2049,513]

theorem envBound25562 : H12AffineFastState.Bounded env25562 := by
  intro p hp
  have h : env25562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25561_25562 : H12AffineEnvironment.transform 5 17 env25561 = env25562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25561 == env25562) = true)

theorem identity25562 : scanCanonicalize (H12AffineFastState.compose env25562 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25562 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25563 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2065,268,2048,137,398,2064,2476,272,136,2185,32,16,2,388,17,2184,2065,2201,2341,20,168,256,32,2049,513]

theorem envBound25563 : H12AffineFastState.Bounded env25563 := by
  intro p hp
  have h : env25563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25562_25563 : H12AffineEnvironment.transform 12 268 env25562 = env25563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25562 == env25563) = true)

theorem identity25563 : scanCanonicalize (H12AffineFastState.compose env25563 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25563 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env25564 : List Nat := [2,4,8,1,32,0,128,256,512,257,2048,2048,268,2048,137,398,2049,2476,257,136,2185,32,1,2,388,0,2184,2048,2184,2341,5,168,256,32,2049,513]

theorem envBound25564 : H12AffineFastState.Bounded env25564 := by
  intro p hp
  have h : env25564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25563_25564 : H12AffineEnvironment.transform 3 1 env25563 = env25564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25563 == env25564) = true)

theorem identity25564 : scanCanonicalize (H12AffineFastState.compose env25564 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25564 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env25565 : List Nat := [2,4,8,1,32,0,128,256,512,257,1,1,268,1,137,398,0,429,257,136,136,32,1,2,388,0,137,1,137,292,5,168,256,32,0,513]

theorem envBound25565 : H12AffineFastState.Bounded env25565 := by
  intro p hp
  have h : env25565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25564_25565 : H12AffineEnvironment.transform 10 1 env25564 = env25565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25564 == env25565) = true)

theorem identity25565 : scanCanonicalize (H12AffineFastState.compose env25565 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound25565 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env25566 : List Nat := [2,4,8,1,32,0,128,172,512,173,1,1,160,1,137,34,0,1,173,136,136,32,1,2,40,0,137,1,137,136,5,168,172,32,0,513]

theorem envBound25566 : H12AffineFastState.Bounded env25566 := by
  intro p hp
  have h : env25566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25565_25566 : H12AffineEnvironment.transform 7 172 env25565 = env25566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25565 == env25566) = true)

theorem identity25566 : scanCanonicalize (H12AffineFastState.compose env25566 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25566 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env25567 : List Nat := [2,4,8,1,32,0,9,37,512,36,1,1,41,1,0,34,0,1,36,1,1,32,1,2,40,0,0,1,0,1,5,33,37,32,0,513]

end H12CloudChart0