import H12CloudChart0Data216

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity54941 : scanCanonicalize (H12AffineFastState.compose env54941 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54941 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env54942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,65536,70863,2421,1025,0,69910,169,17,138,469,65,2048,5393,70110,67619,66698,33,257,168,5592,513]

theorem envBound54942 : H12AffineFastState.Bounded env54942 := by
  intro p hp
  have h : env54942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54941_54942 : H12AffineEnvironment.transform 12 349 env54941 = env54942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54941 == env54942) = true)

theorem identity54942 : scanCanonicalize (H12AffineFastState.compose env54942 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound54942 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env54943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,479,5392,2421,1025,0,4297,169,17,138,469,65,2048,5393,4097,2556,1365,33,257,168,5592,513]

theorem envBound54943 : H12AffineFastState.Bounded env54943 := by
  intro p hp
  have h : env54943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54942_54943 : H12AffineEnvironment.transform 15 479 env54942 = env54943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env54942 == env54943) = true)

theorem identity54943 : scanCanonicalize (H12AffineFastState.compose env54943 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54943 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env54944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5392,2421,1025,0,4161,33,17,2,349,65,2048,5393,4097,2420,1365,33,257,32,5456,513]

theorem envBound54944 : H12AffineFastState.Bounded env54944 := by
  intro p hp
  have h : env54944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54943_54944 : H12AffineEnvironment.transform 6 8 env54943 = env54944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54943 == env54944) = true)

theorem identity54944 : scanCanonicalize (H12AffineFastState.compose env54944 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound54944 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,349,1124,1,343,1141,2421,1025,0,292,33,17,2,349,65,2048,1140,356,2420,1365,33,257,32,1077,513]

theorem envBound54945 : H12AffineFastState.Bounded env54945 := by
  intro p hp
  have h : env54945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54944_54945 : H12AffineEnvironment.transform 11 357 env54944 = env54945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env54944 == env54945) = true)

theorem identity54945 : scanCanonicalize (H12AffineFastState.compose env54945 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54946 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,308,268,1077,1,262,1060,2340,1025,0,292,33,17,2,268,16,2048,1061,309,2341,1284,33,257,32,1077,513]

theorem envBound54946 : H12AffineFastState.Bounded env54946 := by
  intro p hp
  have h : env54946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54945_54946 : H12AffineEnvironment.transform 5 17 env54945 = env54946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54945 == env54946) = true)

theorem identity54946 : scanCanonicalize (H12AffineFastState.compose env54946 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54947 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,49,9,1077,1,3,1060,2081,1025,0,33,33,17,2,9,16,2048,1061,48,2080,1025,33,4,32,1077,513]

theorem envBound54947 : H12AffineFastState.Bounded env54947 := by
  intro p hp
  have h : env54947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54946_54947 : H12AffineEnvironment.transform 7 5 env54946 = env54947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54946 == env54947) = true)

theorem identity54947 : scanCanonicalize (H12AffineFastState.compose env54947 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound54947 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54948 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1557,49,9,1077,1,3,1060,1588,1025,0,33,33,17,2,9,16,1557,1061,48,1589,1025,33,4,32,1077,513]

theorem envBound54948 : H12AffineFastState.Bounded env54948 := by
  intro p hp
  have h : env54948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54947_54948 : H12AffineEnvironment.transform 10 1557 env54947 = env54948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env54947 == env54948) = true)

theorem identity54948 : scanCanonicalize (H12AffineFastState.compose env54948 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54948 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54949 : List Nat := [2,4,8,1,32,0,8,5,512,1024,1540,32,9,1060,1,3,1060,1573,1025,0,33,33,0,2,9,1,1540,1061,33,1572,1025,33,4,32,1060,513]

theorem envBound54949 : H12AffineFastState.Bounded env54949 := by
  intro p hp
  have h : env54949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54948_54949 : H12AffineEnvironment.transform 3 1 env54948 = env54949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54948 == env54949) = true)

theorem identity54949 : scanCanonicalize (H12AffineFastState.compose env54949 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54949 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54950 : List Nat := [2,4,8,1,0,0,8,5,512,1024,1540,0,9,1028,1,3,1028,1541,1025,0,1,1,0,2,9,1,1540,1029,1,1540,1025,1,4,0,1028,513]

theorem envBound54950 : H12AffineFastState.Bounded env54950 := by
  intro p hp
  have h : env54950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54949_54950 : H12AffineEnvironment.transform 4 0 env54949 = env54950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54949 == env54950) = true)

theorem identity54950 : scanCanonicalize (H12AffineFastState.compose env54950 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound54950 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env54951 : List Nat := [2,4,8,1,0,0,8,5,512,516,0,0,9,512,1,3,512,1,517,0,1,1,0,2,9,1,0,513,1,0,517,1,4,0,512,513]

theorem envBound54951 : H12AffineFastState.Bounded env54951 := by
  intro p hp
  have h : env54951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54950_54951 : H12AffineEnvironment.transform 9 516 env54950 = env54951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env54950 == env54951) = true)

theorem identity54951 : scanCanonicalize (H12AffineFastState.compose env54951 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound54951 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54952 : List Nat := [2,4,8,1,0,0,8,5,0,4,0,0,9,0,1,3,0,1,5,0,1,1,0,2,9,1,0,1,1,0,5,1,4,0,0,1]

theorem envBound54952 : H12AffineFastState.Bounded env54952 := by
  intro p hp
  have h : env54952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54951_54952 : H12AffineEnvironment.transform 8 0 env54951 = env54952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env54951 == env54952) = true)

def env54953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318700,466225,8328,65,4456925,313836,449005,138476,148941,4466848,257,21793,46212,221723]

theorem envBound54953 : H12AffineFastState.Bounded env54953 := by
  intro p hp
  have h : env54953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54876_54953 : H12AffineEnvironment.transform 20 151633 env54876 = env54953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env54876 == env54953) = true)

theorem identity54953 : scanCanonicalize (H12AffineFastState.compose env54953 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90259) := by decide +kernel

theorem selectedBound54953 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env54954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90259,262144,1025,32769,78018,4194304,318700,294306,8328,65,4456925,313836,375166,97407,75102,4466848,257,21793,46212,648]

theorem envBound54954 : H12AffineFastState.Bounded env54954 := by
  intro p hp
  have h : env54954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54953_54954 : H12AffineEnvironment.transform 16 90259 env54953 = env54954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90259 env54953 == env54954) = true)

def env54955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77898,4194304,318564,294186,8192,65,4456789,313700,375166,97407,75102,4466728,257,21793,46092,512]

theorem envBound54955 : H12AffineFastState.Bounded env54955 := by
  intro p hp
  have h : env54955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54954_54955 : H12AffineEnvironment.transform 6 8 env54954 = env54955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54954 == env54955) = true)

theorem identity54955 : scanCanonicalize (H12AffineFastState.compose env54955 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 130315) := by decide +kernel

theorem selectedBound54955 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,130315,1025,32769,77898,4194304,74095,98337,8192,65,4324446,78959,17525,97407,75102,4314403,257,21793,46092,512]

theorem envBound54956 : H12AffineFastState.Bounded env54956 := by
  intro p hp
  have h : env54956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54955_54956 : H12AffineEnvironment.transform 17 130315 env54955 = env54956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130315 env54955 == env54956) = true)

theorem identity54956 : scanCanonicalize (H12AffineFastState.compose env54956 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound54956 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5393,34817,1025,32769,17728,4194304,21605,62763,8192,65,4229460,16741,17525,2421,20564,4235305,257,21793,46092,512]

theorem envBound54957 : H12AffineFastState.Bounded env54957 := by
  intro p hp
  have h : env54957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54956_54957 : H12AffineEnvironment.transform 15 29962 env54956 = env54957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env54956 == env54957) = true)

theorem identity54957 : scanCanonicalize (H12AffineFastState.compose env54957 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 373) := by decide +kernel

theorem selectedBound54957 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env54958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5393,34817,1025,32769,17728,373,21605,62763,8192,65,34849,16741,17525,2421,20564,41308,257,21793,46092,512]

theorem envBound54958 : H12AffineFastState.Bounded env54958 := by
  intro p hp
  have h : env54958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54957_54958 : H12AffineEnvironment.transform 21 373 env54957 = env54958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 373 env54957 == env54958) = true)

theorem identity54958 : scanCanonicalize (H12AffineFastState.compose env54958 (packedSelected [9,14,22] rootPS)) = affineNative (2^(14+1) ^^^ 29820) := by decide +kernel

theorem selectedBound54958 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env54959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29820,29962,5393,31869,1025,29821,17728,373,21605,343,8192,65,31837,16741,17525,2421,20564,21792,257,21793,16496,512]

theorem envBound54959 : H12AffineFastState.Bounded env54959 := by
  intro p hp
  have h : env54959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54958_54959 : H12AffineEnvironment.transform 14 29820 env54958 = env54959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29820 env54958 == env54959) = true)

theorem identity54959 : scanCanonicalize (H12AffineFastState.compose env54959 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound54959 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env54960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8200,8574,5393,10249,1025,8201,4404,373,17,343,8192,65,10281,5393,4097,2421,1056,340,257,341,5124,512]

theorem envBound54960 : H12AffineFastState.Bounded env54960 := by
  intro p hp
  have h : env54960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54959_54960 : H12AffineEnvironment.transform 13 5236 env54959 = env54960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env54959 == env54960) = true)

theorem identity54960 : scanCanonicalize (H12AffineFastState.compose env54960 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54960 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,33,343,5393,2080,1025,32,4404,373,17,343,41,65,2048,5393,4097,2421,1056,340,257,341,5124,512]

theorem envBound54961 : H12AffineFastState.Bounded env54961 := by
  intro p hp
  have h : env54961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54960_54961 : H12AffineEnvironment.transform 12 41 env54960 = env54961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54960 == env54961) = true)

def env54962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77899,4194304,318565,294187,8193,65,4456788,313701,375166,97407,75102,4466729,257,21793,46093,513]

theorem envBound54962 : H12AffineFastState.Bounded env54962 := by
  intro p hp
  have h : env54962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54954_54962 : H12AffineEnvironment.transform 6 9 env54954 = env54962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54954 == env54962) = true)

theorem identity54962 : scanCanonicalize (H12AffineFastState.compose env54962 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound54962 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56436,1025,32769,77899,4194304,17,41311,8193,65,4250912,5393,91402,97407,75102,4256861,257,21793,46093,513]

theorem envBound54963 : H12AffineFastState.Bounded env54963 := by
  intro p hp
  have h : env54963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54962_54963 : H12AffineEnvironment.transform 17 56436 env54962 = env54963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env54962 == env54963) = true)

theorem identity54963 : scanCanonicalize (H12AffineFastState.compose env54963 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54963 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env54964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,35189,1025,32769,77899,4194304,17,41311,8193,65,4229153,5393,77835,76158,75102,4235612,257,32,46093,513]

theorem envBound54964 : H12AffineFastState.Bounded env54964 := by
  intro p hp
  have h : env54964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54963_54964 : H12AffineEnvironment.transform 13 5377 env54963 = env54964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54963 == env54964) = true)

theorem identity54964 : scanCanonicalize (H12AffineFastState.compose env54964 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54964 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env54965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79131,10280,1025,8540,77899,4194304,17,2,8193,65,4204924,5393,77835,76158,75102,4194305,257,32,5456,513]

theorem envBound54965 : H12AffineFastState.Bounded env54965 := by
  intro p hp
  have h : env54965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54964_54965 : H12AffineEnvironment.transform 14 8541 env54964 = env54965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54964 == env54965) = true)

theorem identity54965 : scanCanonicalize (H12AffineFastState.compose env54965 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54965 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,65536,70727,2420,1025,0,69911,4194304,17,2,349,65,4196384,5393,69975,67618,66562,4194305,257,32,5456,513]

theorem envBound54966 : H12AffineFastState.Bounded env54966 := by
  intro p hp
  have h : env54966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54965_54966 : H12AffineEnvironment.transform 12 348 env54965 = env54966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54965 == env54966) = true)

theorem identity54966 : scanCanonicalize (H12AffineFastState.compose env54966 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound54966 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env54967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5393,2420,1025,0,4161,4194304,17,2,349,65,4196384,5393,4097,2420,1364,4194305,257,32,5456,513]

theorem envBound54967 : H12AffineFastState.Bounded env54967 := by
  intro p hp
  have h : env54967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54966_54967 : H12AffineEnvironment.transform 15 342 env54966 = env54967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env54966 == env54967) = true)

theorem identity54967 : scanCanonicalize (H12AffineFastState.compose env54967 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound54967 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5393,2420,1025,0,4161,113,17,2,349,65,2129,5393,4097,2420,1364,112,257,32,5456,513]

theorem envBound54968 : H12AffineFastState.Bounded env54968 := by
  intro p hp
  have h : env54968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54967_54968 : H12AffineEnvironment.transform 21 113 env54967 = env54968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env54967 == env54968) = true)

theorem identity54968 : scanCanonicalize (H12AffineFastState.compose env54968 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54968 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54969 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1025,0,4113,33,17,2,269,17,2049,5393,4097,2340,1284,32,257,32,5376,513]

theorem envBound54969 : H12AffineFastState.Bounded env54969 := by
  intro p hp
  have h : env54969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54968_54969 : H12AffineEnvironment.transform 5 16 env54968 = env54969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54968 == env54969) = true)

theorem identity54969 : scanCanonicalize (H12AffineFastState.compose env54969 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound54969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54970 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,268,1280,1,262,1296,2340,1025,0,16,33,17,2,269,17,2049,1296,0,2340,1284,32,257,32,1281,513]

theorem envBound54970 : H12AffineFastState.Bounded env54970 := by
  intro p hp
  have h : env54970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54969_54970 : H12AffineEnvironment.transform 11 1 env54969 = env54970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env54969 == env54970) = true)

theorem identity54970 : scanCanonicalize (H12AffineFastState.compose env54970 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound54970 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54971 : List Nat := [2,4,8,16,32,16,9,256,512,1024,318,1,268,1280,1,262,1296,26,1025,0,16,33,17,2,269,17,319,1296,0,26,1284,32,257,32,1281,513]

theorem envBound54971 : H12AffineFastState.Bounded env54971 := by
  intro p hp
  have h : env54971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54970_54971 : H12AffineEnvironment.transform 10 318 env54970 = env54971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env54970 == env54971) = true)

theorem identity54971 : scanCanonicalize (H12AffineFastState.compose env54971 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound54971 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54972 : List Nat := [2,4,8,16,32,16,9,256,512,20,318,1,268,276,1,262,260,26,21,0,16,33,17,2,269,17,319,260,0,26,272,32,257,32,277,513]

theorem envBound54972 : H12AffineFastState.Bounded env54972 := by
  intro p hp
  have h : env54972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54971_54972 : H12AffineEnvironment.transform 9 20 env54971 = env54972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env54971 == env54972) = true)

theorem identity54972 : scanCanonicalize (H12AffineFastState.compose env54972 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound54972 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54973 : List Nat := [2,4,8,16,32,16,9,53,512,20,11,1,57,33,1,51,49,26,21,0,16,33,17,2,56,17,10,49,0,26,37,32,52,32,32,513]

theorem envBound54973 : H12AffineFastState.Bounded env54973 := by
  intro p hp
  have h : env54973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54972_54973 : H12AffineEnvironment.transform 7 53 env54972 = env54973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env54972 == env54973) = true)

theorem identity54973 : scanCanonicalize (H12AffineFastState.compose env54973 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound54973 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54974 : List Nat := [2,4,8,16,26,16,9,15,512,20,11,1,3,27,1,9,11,26,21,0,16,27,17,2,2,17,10,11,0,26,31,26,14,26,26,513]

theorem envBound54974 : H12AffineFastState.Bounded env54974 := by
  intro p hp
  have h : env54974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54973_54974 : H12AffineEnvironment.transform 4 26 env54973 = env54974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env54973 == env54974) = true)

theorem identity54974 : scanCanonicalize (H12AffineFastState.compose env54974 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54974 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54975 : List Nat := [2,4,3,16,17,16,2,4,512,20,0,1,3,16,1,2,0,17,21,0,16,16,17,2,2,17,1,0,0,17,20,17,5,17,17,513]

theorem envBound54975 : H12AffineFastState.Bounded env54975 := by
  intro p hp
  have h : env54975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54974_54975 : H12AffineEnvironment.transform 2 3 env54974 = env54975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54974 == env54975) = true)

theorem identity54975 : scanCanonicalize (H12AffineFastState.compose env54975 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54976 : List Nat := [1,4,0,16,17,16,1,4,512,20,0,1,0,16,1,1,0,17,21,0,16,16,17,1,1,17,1,0,0,17,20,17,5,17,17,513]

theorem envBound54976 : H12AffineFastState.Bounded env54976 := by
  intro p hp
  have h : env54976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54975_54976 : H12AffineEnvironment.transform 0 1 env54975 = env54976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54975 == env54976) = true)

theorem identity54976 : scanCanonicalize (H12AffineFastState.compose env54976 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54976 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env54977 : List Nat := [1,4,0,1,0,1,1,4,512,5,0,1,0,1,1,1,0,0,4,0,1,1,0,1,1,0,1,0,0,0,5,0,5,0,0,513]

theorem envBound54977 : H12AffineFastState.Bounded env54977 := by
  intro p hp
  have h : env54977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54976_54977 : H12AffineEnvironment.transform 3 1 env54976 = env54977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54976 == env54977) = true)

theorem identity54977 : scanCanonicalize (H12AffineFastState.compose env54977 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound54977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54978 : List Nat := [1,1,0,1,0,1,1,1,512,0,0,1,0,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,0,0,0,0,0,0,0,513]

theorem envBound54978 : H12AffineFastState.Bounded env54978 := by
  intro p hp
  have h : env54978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54977_54978 : H12AffineEnvironment.transform 1 1 env54977 = env54978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env54977 == env54978) = true)

def env54979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318701,2444640,8328,65,6705549,313836,2394557,138477,2102685,4466848,257,21792,46213,2175563]

theorem envBound54979 : H12AffineFastState.Bounded env54979 := by
  intro p hp
  have h : env54979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54875_54979 : H12AffineEnvironment.transform 22 318701 env54875 = env54979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318701 env54875 == env54979) = true)

def env54980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318701,466224,8328,65,4456925,313836,449005,138477,148941,4466848,257,21792,46213,221723]

theorem envBound54980 : H12AffineFastState.Bounded env54980 := by
  intro p hp
  have h : env54980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54979_54980 : H12AffineEnvironment.transform 20 151632 env54979 = env54980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env54979 == env54980) = true)

theorem identity54980 : scanCanonicalize (H12AffineFastState.compose env54980 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54980 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env54981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318564,466224,8193,65,4456788,313701,448868,138340,148804,4466729,257,21792,46092,221723]

theorem envBound54981 : H12AffineFastState.Bounded env54981 := by
  intro p hp
  have h : env54981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54980_54981 : H12AffineEnvironment.transform 6 9 env54980 = env54981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54980 == env54981) = true)

def env54982 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,262144,273,32769,151632,4194304,317812,464928,8193,65,4456788,313701,448868,137588,147540,4466729,257,20528,45340,221723]

theorem envBound54982 : H12AffineFastState.Bounded env54982 := by
  intro p hp
  have h : env54982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54981_54982 : H12AffineEnvironment.transform 9 272 env54981 = env54982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54981 == env54982) = true)

theorem identity54982 : scanCanonicalize (H12AffineFastState.compose env54982 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 63545) := by decide +kernel

theorem selectedBound54982 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env54983 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63545,273,32769,151632,4194304,8525,253977,8193,65,4258157,12636,139613,137588,147540,4247568,257,20528,45340,221723]

theorem envBound54983 : H12AffineFastState.Bounded env54983 := by
  intro p hp
  have h : env54983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54982_54983 : H12AffineEnvironment.transform 17 63545 env54982 = env54983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63545 env54982 == env54983) = true)

def env54984 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63545,273,32769,151552,4194304,8477,253977,8193,17,4258109,12556,139533,137508,147460,4247568,257,20528,45340,221723]

theorem envBound54984 : H12AffineFastState.Bounded env54984 := by
  intro p hp
  have h : env54984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54983_54984 : H12AffineEnvironment.transform 5 16 env54983 = env54984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54983 == env54984) = true)

theorem identity54984 : scanCanonicalize (H12AffineFastState.compose env54984 (packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS)) = affineNative (2^(21+1) ^^^ 241707) := by decide +kernel

theorem selectedBound54984 : packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env54985 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63545,273,32769,151552,241707,8477,253977,8193,17,215318,12556,139533,137508,147460,221243,257,20528,45340,221723]

theorem envBound54985 : H12AffineFastState.Bounded env54985 := by
  intro p hp
  have h : env54985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54984_54985 : H12AffineEnvironment.transform 21 241707 env54984 = env54985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 241707 env54984 == env54985) = true)

theorem identity54985 : scanCanonicalize (H12AffineFastState.compose env54985 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,14,15,16,17,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound54985 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,14,15,16,17,20,24] rootPS < 2^1333 := by decide +kernel

def env54986 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,32768,65536,82198,63545,273,32769,69910,61757,8477,41231,8193,17,2048,12556,90139,88114,65810,8493,257,20528,45340,8973]

theorem envBound54986 : H12AffineFastState.Bounded env54986 := by
  intro p hp
  have h : env54986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54985_54986 : H12AffineEnvironment.transform 16 82198 env54985 = env54986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env54985 == env54986) = true)

theorem identity54986 : scanCanonicalize (H12AffineFastState.compose env54986 (packedSelected [2,3,4,5,6,10,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54986 : packedSelected [2,3,4,5,6,10,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env54987 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,0,65536,82198,30777,273,1,69910,28989,8477,8463,8193,17,2048,12556,90139,88114,65810,8493,257,20528,12572,8973]

theorem envBound54987 : H12AffineFastState.Bounded env54987 := by
  intro p hp
  have h : env54987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54986_54987 : H12AffineEnvironment.transform 14 0 env54986 = env54987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54986 == env54987) = true)

theorem identity54987 : scanCanonicalize (H12AffineFastState.compose env54987 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54987 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env54988 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,0,8202,24860,30777,273,1,12572,28989,8477,8463,8193,17,2048,12556,16401,30776,8472,8493,257,20528,12572,8973]

theorem envBound54988 : H12AffineFastState.Bounded env54988 := by
  intro p hp
  have h : env54988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54987_54988 : H12AffineEnvironment.transform 15 8202 env54987 = env54988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54987 == env54988) = true)

theorem identity54988 : scanCanonicalize (H12AffineFastState.compose env54988 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54988 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54989 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,16384,0,262,16400,22837,273,1,4112,20529,17,3,269,17,2048,4096,16401,22836,20,33,257,20528,4112,513]

theorem envBound54989 : H12AffineFastState.Bounded env54989 := by
  intro p hp
  have h : env54989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54988_54989 : H12AffineEnvironment.transform 12 268 env54988 = env54989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54988 == env54989) = true)

theorem identity54989 : scanCanonicalize (H12AffineFastState.compose env54989 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 49) := by decide +kernel

theorem selectedBound54989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54990 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,49,0,262,33,6404,273,1,4112,4096,17,3,269,17,2048,4096,32,6405,20,33,257,4097,4112,513]

theorem envBound54990 : H12AffineFastState.Bounded env54990 := by
  intro p hp
  have h : env54990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54989_54990 : H12AffineEnvironment.transform 13 49 env54989 = env54990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 49 env54989 == env54990) = true)

theorem identity54990 : scanCanonicalize (H12AffineFastState.compose env54990 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound54990 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54991 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,33,268,49,0,262,33,2341,273,1,49,33,17,3,269,17,2048,33,32,2340,20,33,257,32,49,513]

theorem envBound54991 : H12AffineFastState.Bounded env54991 := by
  intro p hp
  have h : env54991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54990_54991 : H12AffineEnvironment.transform 11 33 env54990 = env54991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env54990 == env54991) = true)

theorem identity54991 : scanCanonicalize (H12AffineFastState.compose env54991 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound54991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54992 : List Nat := [2,4,8,16,32,16,9,256,512,272,286,33,268,49,0,262,33,59,273,1,49,33,17,3,269,17,286,33,32,58,20,33,257,32,49,513]

theorem envBound54992 : H12AffineFastState.Bounded env54992 := by
  intro p hp
  have h : env54992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54991_54992 : H12AffineEnvironment.transform 10 286 env54991 = env54992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env54991 == env54992) = true)

theorem identity54992 : scanCanonicalize (H12AffineFastState.compose env54992 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound54992 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54993 : List Nat := [2,4,8,16,32,16,9,256,271,272,286,33,268,49,0,262,33,59,273,1,49,33,17,3,269,17,286,33,32,58,20,33,257,32,49,270]

theorem envBound54993 : H12AffineFastState.Bounded env54993 := by
  intro p hp
  have h : env54993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54992_54993 : H12AffineEnvironment.transform 8 271 env54992 = env54993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env54992 == env54993) = true)

theorem identity54993 : scanCanonicalize (H12AffineFastState.compose env54993 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54993 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54994 : List Nat := [2,4,8,13,32,13,9,256,271,269,259,33,268,44,0,262,33,38,268,1,44,33,12,3,269,12,259,33,32,39,9,33,257,32,44,270]

theorem envBound54994 : H12AffineFastState.Bounded env54994 := by
  intro p hp
  have h : env54994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54993_54994 : H12AffineEnvironment.transform 3 13 env54993 = env54994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54993 == env54994) = true)

theorem identity54994 : scanCanonicalize (H12AffineFastState.compose env54994 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound54994 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env54995 : List Nat := [2,4,8,13,32,13,9,2,13,15,1,33,14,44,0,4,33,38,14,1,44,33,12,3,15,12,1,33,32,39,9,33,3,32,44,12]

theorem envBound54995 : H12AffineFastState.Bounded env54995 := by
  intro p hp
  have h : env54995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54994_54995 : H12AffineEnvironment.transform 7 2 env54994 = env54995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env54994 == env54995) = true)

theorem identity54995 : scanCanonicalize (H12AffineFastState.compose env54995 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54995 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54996 : List Nat := [2,3,8,10,32,10,9,2,10,8,1,33,9,43,0,3,33,33,9,1,43,33,11,3,8,11,1,33,32,32,9,33,3,32,43,11]

theorem envBound54996 : H12AffineFastState.Bounded env54996 := by
  intro p hp
  have h : env54996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54995_54996 : H12AffineEnvironment.transform 1 3 env54995 = env54996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54995 == env54996) = true)

theorem identity54996 : scanCanonicalize (H12AffineFastState.compose env54996 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54996 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env54997 : List Nat := [2,3,8,10,10,10,9,2,10,8,1,11,9,1,0,3,11,11,9,1,1,11,11,3,8,11,1,11,10,10,9,11,3,10,1,11]

theorem envBound54997 : H12AffineFastState.Bounded env54997 := by
  intro p hp
  have h : env54997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54996_54997 : H12AffineEnvironment.transform 4 10 env54996 = env54997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54996 == env54997) = true)

theorem identity54997 : scanCanonicalize (H12AffineFastState.compose env54997 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54997 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54998 : List Nat := [1,0,8,9,9,9,9,1,9,8,1,8,9,1,0,0,8,8,9,1,1,8,8,0,8,8,1,8,9,9,9,8,0,9,1,8]

theorem envBound54998 : H12AffineFastState.Bounded env54998 := by
  intro p hp
  have h : env54998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54997_54998 : H12AffineEnvironment.transform 0 1 env54997 = env54998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54997 == env54998) = true)

def env54999 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63545,273,32769,151553,4194304,8476,253977,8193,16,4258108,12557,139532,137509,147461,4247568,257,20528,45340,221723]

theorem envBound54999 : H12AffineFastState.Bounded env54999 := by
  intro p hp
  have h : env54999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54983_54999 : H12AffineEnvironment.transform 5 17 env54983 = env54999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54983 == env54999) = true)

theorem identity54999 : scanCanonicalize (H12AffineFastState.compose env54999 (packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound54999 : packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env55000 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,16384,32768,65536,4096,63545,273,32769,16385,4194304,8476,127001,8193,16,4258108,12557,12556,2341,20485,4247568,257,20528,45340,94747]

theorem envBound55000 : H12AffineFastState.Bounded env55000 := by
  intro p hp
  have h : env55000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54999_55000 : H12AffineEnvironment.transform 16 4096 env54999 = env55000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env54999 == env55000) = true)

theorem identity55000 : scanCanonicalize (H12AffineFastState.compose env55000 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound55000 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env55001 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,16384,32768,28698,4096,63545,273,32769,16385,4194304,8476,32771,8193,16,4258108,12557,12556,2341,20485,4247568,257,20528,45340,513]

theorem envBound55001 : H12AffineFastState.Bounded env55001 := by
  intro p hp
  have h : env55001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55000_55001 : H12AffineEnvironment.transform 15 28698 env55000 = env55001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env55000 == env55001) = true)

theorem identity55001 : scanCanonicalize (H12AffineFastState.compose env55001 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55001 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55002 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,32768,20759,4096,55604,273,32769,16385,4194304,17,32771,268,16,4249649,4096,4097,2341,20485,4247568,257,20528,36881,513]

theorem envBound55002 : H12AffineFastState.Bounded env55002 := by
  intro p hp
  have h : env55002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55001_55002 : H12AffineEnvironment.transform 12 269 env55001 = env55002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55001 == env55002) = true)

theorem identity55002 : scanCanonicalize (H12AffineFastState.compose env55002 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound55002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55003 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,32768,20759,4096,55604,273,32769,16385,32,17,32771,268,16,55313,4096,4097,2341,20485,53296,257,20528,36881,513]

theorem envBound55003 : H12AffineFastState.Bounded env55003 := by
  intro p hp
  have h : env55003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55002_55003 : H12AffineEnvironment.transform 21 32 env55002 = env55003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55002 == env55003) = true)

def env55004 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,32768,65536,131072,262144,272,32769,151632,4194304,317813,464929,8193,65,4456788,313701,448868,137589,147541,4466729,257,20529,45341,221723]

theorem envBound55004 : H12AffineFastState.Bounded env55004 := by
  intro p hp
  have h : env55004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54981_55004 : H12AffineEnvironment.transform 9 273 env54981 = env55004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54981 == env55004) = true)

theorem identity55004 : scanCanonicalize (H12AffineFastState.compose env55004 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 20496) := by decide +kernel

theorem selectedBound55004 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env55005 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,20496,65536,131072,262144,272,20497,151632,4194304,264549,464929,8193,65,4456788,268661,395636,137589,147541,4466729,257,20529,24845,221723]

theorem envBound55005 : H12AffineFastState.Bounded env55005 := by
  intro p hp
  have h : env55005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55004_55005 : H12AffineEnvironment.transform 14 20496 env55004 = env55005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20496 env55004 == env55005) = true)

def env55006 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20496,65536,131072,262144,272,20497,151552,4194304,264501,464929,8193,17,4456708,268581,395556,137509,147461,4466729,257,20529,24845,221723]

theorem envBound55006 : H12AffineFastState.Bounded env55006 := by
  intro p hp
  have h : env55006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55005_55006 : H12AffineEnvironment.transform 5 16 env55005 = env55006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55005 == env55006) = true)

theorem identity55006 : scanCanonicalize (H12AffineFastState.compose env55006 (packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 477202) := by decide +kernel

theorem selectedBound55006 : packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55007 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20496,65536,131072,262144,272,20497,151552,477202,264501,464929,8193,17,215318,268581,395556,137509,147461,221243,257,20529,24845,221723]

theorem envBound55007 : H12AffineFastState.Bounded env55007 := by
  intro p hp
  have h : env55007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55006_55007 : H12AffineEnvironment.transform 21 477202 env55006 = env55007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477202 env55006 == env55007) = true)

theorem identity55007 : scanCanonicalize (H12AffineFastState.compose env55007 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,17,18,22,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 30776) := by decide +kernel

theorem selectedBound55007 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,17,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env55008 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20496,65536,131072,30776,272,20497,151552,208938,28941,221209,8193,17,215318,24861,160028,137509,147461,221243,257,20529,24845,221723]

theorem envBound55008 : H12AffineFastState.Bounded env55008 := by
  intro p hp
  have h : env55008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55007_55008 : H12AffineEnvironment.transform 17 30776 env55007 = env55008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30776 env55007 == env55008) = true)

theorem identity55008 : scanCanonicalize (H12AffineFastState.compose env55008 (packedSelected [0,2,4,6,7,9,12,14,15,16,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound55008 : packedSelected [0,2,4,6,7,9,12,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env55009 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20496,262,131072,30776,272,20497,151552,143660,28941,155935,8193,17,149520,24861,160028,137509,147461,155965,257,20529,24845,156445]

theorem envBound55009 : H12AffineFastState.Bounded env55009 := by
  intro p hp
  have h : env55009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55008_55009 : H12AffineEnvironment.transform 15 262 env55008 = env55009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env55008 == env55009) = true)

theorem identity55009 : scanCanonicalize (H12AffineFastState.compose env55009 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound55009 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55010 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,4112,0,262,131072,10280,272,1,131088,143660,8477,143631,8193,17,137216,12557,139532,137509,135189,143661,257,33,12573,144141]

theorem envBound55010 : H12AffineFastState.Bounded env55010 := by
  intro p hp
  have h : env55010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55009_55010 : H12AffineEnvironment.transform 13 4112 env55009 = env55010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env55009 == env55010) = true)

theorem identity55010 : scanCanonicalize (H12AffineFastState.compose env55010 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 10297) := by decide +kernel

theorem selectedBound55010 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55011 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,4112,0,262,10297,10280,272,1,10281,6421,8477,6454,8193,17,12345,12557,2357,12572,14380,6420,257,33,12573,6964]

theorem envBound55011 : H12AffineFastState.Bounded env55011 := by
  intro p hp
  have h : env55011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55010_55011 : H12AffineEnvironment.transform 16 10297 env55010 = env55011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10297 env55010 == env55011) = true)

theorem identity55011 : scanCanonicalize (H12AffineFastState.compose env55011 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55011 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55012 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,4096,8192,4112,0,262,8249,8232,272,1,8233,4373,8477,4406,8193,17,12345,12557,309,12572,12332,4372,257,33,12573,4916]

theorem envBound55012 : H12AffineFastState.Bounded env55012 := by
  intro p hp
  have h : env55012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55011_55012 : H12AffineEnvironment.transform 10 0 env55011 = env55012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55011 == env55012) = true)

theorem identity55012 : scanCanonicalize (H12AffineFastState.compose env55012 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 4374) := by decide +kernel

theorem selectedBound55012 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env55013 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,4096,4374,4112,0,262,4399,4414,272,1,4415,4373,4107,4406,4375,17,303,27,309,10,314,4372,257,33,11,4916]

theorem envBound55013 : H12AffineFastState.Bounded env55013 := by
  intro p hp
  have h : env55013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55012_55013 : H12AffineEnvironment.transform 12 4374 env55012 = env55013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4374 env55012 == env55013) = true)

theorem identity55013 : scanCanonicalize (H12AffineFastState.compose env55013 (packedSelected [1,3,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound55013 : packedSelected [1,3,11,12] rootPS < 2^1333 := by decide +kernel

def env55014 : List Nat := [2,4,8,16,32,16,9,47,512,62,0,4096,4153,4112,0,41,4096,4113,63,1,4112,4154,4107,4121,4152,17,0,27,26,10,21,4155,46,33,11,4635]

theorem envBound55014 : H12AffineFastState.Bounded env55014 := by
  intro p hp
  have h : env55014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55013_55014 : H12AffineEnvironment.transform 7 47 env55013 = env55014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env55013 == env55014) = true)

theorem identity55014 : scanCanonicalize (H12AffineFastState.compose env55014 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound55014 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55015 : List Nat := [2,4,8,16,32,16,9,47,512,62,0,561,520,545,0,41,561,544,63,1,545,523,570,552,521,17,0,27,26,10,21,522,46,33,11,42]

theorem envBound55015 : H12AffineFastState.Bounded env55015 := by
  intro p hp
  have h : env55015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55014_55015 : H12AffineEnvironment.transform 11 561 env55014 = env55015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env55014 == env55015) = true)

theorem identity55015 : scanCanonicalize (H12AffineFastState.compose env55015 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound55015 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env55016 : List Nat := [2,4,8,16,32,16,9,47,33,62,0,16,41,0,0,41,16,1,63,1,0,42,27,9,40,17,0,27,26,10,21,43,46,33,11,42]

theorem envBound55016 : H12AffineFastState.Bounded env55016 := by
  intro p hp
  have h : env55016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55015_55016 : H12AffineEnvironment.transform 8 33 env55015 = env55016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env55015 == env55016) = true)

theorem identity55016 : scanCanonicalize (H12AffineFastState.compose env55016 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound55016 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55017 : List Nat := [2,4,8,15,32,15,9,47,33,33,0,15,41,0,0,41,15,1,32,1,0,42,4,9,40,14,0,4,5,10,10,43,46,33,11,42]

theorem envBound55017 : H12AffineFastState.Bounded env55017 := by
  intro p hp
  have h : env55017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55016_55017 : H12AffineEnvironment.transform 3 15 env55016 = env55017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env55016 == env55017) = true)

theorem identity55017 : scanCanonicalize (H12AffineFastState.compose env55017 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound55017 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env55018 : List Nat := [2,4,8,15,15,15,9,0,14,14,0,15,6,0,0,6,15,1,15,1,0,5,4,9,7,14,0,4,5,10,10,4,1,14,11,5]

theorem envBound55018 : H12AffineFastState.Bounded env55018 := by
  intro p hp
  have h : env55018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55017_55018 : H12AffineEnvironment.transform 4 15 env55017 = env55018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env55017 == env55018) = true)

theorem identity55018 : scanCanonicalize (H12AffineFastState.compose env55018 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55019 : List Nat := [2,3,8,8,8,8,9,0,9,9,0,8,1,0,0,1,8,1,8,1,0,2,3,9,0,9,0,3,2,10,10,3,1,9,11,2]

theorem envBound55019 : H12AffineFastState.Bounded env55019 := by
  intro p hp
  have h : env55019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55018_55019 : H12AffineEnvironment.transform 1 3 env55018 = env55019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55018 == env55019) = true)

theorem identity55019 : scanCanonicalize (H12AffineFastState.compose env55019 (packedSelected [0,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55019 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55020 : List Nat := [1,0,8,8,8,8,9,0,9,9,0,8,1,0,0,1,8,1,8,1,0,1,0,9,0,9,0,0,1,9,9,0,1,9,8,1]

theorem envBound55020 : H12AffineFastState.Bounded env55020 := by
  intro p hp
  have h : env55020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55019_55020 : H12AffineEnvironment.transform 0 1 env55019 = env55020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55019 == env55020) = true)

theorem identity55020 : scanCanonicalize (H12AffineFastState.compose env55020 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound55020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55021 : List Nat := [1,0,0,0,0,0,1,0,1,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,1,0,1,1,0,1]

theorem envBound55021 : H12AffineFastState.Bounded env55021 := by
  intro p hp
  have h : env55021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55020_55021 : H12AffineEnvironment.transform 2 0 env55020 = env55021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env55020 == env55021) = true)

def env55022 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,20496,65536,131072,262144,272,20497,151553,4194304,264500,464929,8193,16,4456709,268580,395557,137508,147460,4466729,257,20529,24845,221723]

theorem envBound55022 : H12AffineFastState.Bounded env55022 := by
  intro p hp
  have h : env55022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55005_55022 : H12AffineEnvironment.transform 5 17 env55005 = env55022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55005 == env55022) = true)

theorem identity55022 : scanCanonicalize (H12AffineFastState.compose env55022 (packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound55022 : packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55023 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,20496,65536,4097,262144,272,20497,16384,4194304,264500,329760,8193,16,4456709,268580,268580,2341,20485,4466729,257,20529,24845,94746]

theorem envBound55023 : H12AffineFastState.Bounded env55023 := by
  intro p hp
  have h : env55023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55022_55023 : H12AffineEnvironment.transform 16 4097 env55022 = env55023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env55022 == env55023) = true)

theorem identity55023 : scanCanonicalize (H12AffineFastState.compose env55023 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound55023 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env55024 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,20496,28699,4097,262144,272,20497,16384,4194304,264500,292923,8193,16,4456709,268580,268580,2341,20485,4466729,257,20529,24845,513]

theorem envBound55024 : H12AffineFastState.Bounded env55024 := by
  intro p hp
  have h : env55024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55023_55024 : H12AffineEnvironment.transform 15 28699 env55023 = env55024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env55023 == env55024) = true)

theorem identity55024 : scanCanonicalize (H12AffineFastState.compose env55024 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound55024 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55025 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,8460,263,4097,262144,272,8461,12572,4194304,264500,264487,8193,16,4456709,268580,268580,2341,8473,4466729,257,8493,4113,513]

theorem envBound55025 : H12AffineFastState.Bounded env55025 := by
  intro p hp
  have h : env55025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55024_55025 : H12AffineEnvironment.transform 13 12572 env55024 = env55025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env55024 == env55025) = true)

theorem identity55025 : scanCanonicalize (H12AffineFastState.compose env55025 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound55025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55026 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,8460,263,4097,262144,272,8461,12572,8493,264500,264487,8193,16,270376,268580,268580,2341,8473,264452,257,8493,4113,513]

theorem envBound55026 : H12AffineFastState.Bounded env55026 := by
  intro p hp
  have h : env55026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55025_55026 : H12AffineEnvironment.transform 21 8493 env55025 = env55026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env55025 == env55026) = true)

theorem identity55026 : scanCanonicalize (H12AffineFastState.compose env55026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55027 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,1,263,4097,262144,272,0,4113,32,264500,264487,268,16,262437,268580,268580,2341,20,264452,257,32,4113,513]

theorem envBound55027 : H12AffineFastState.Bounded env55027 := by
  intro p hp
  have h : env55027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55026_55027 : H12AffineEnvironment.transform 12 269 env55026 = env55027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55026 == env55027) = true)

def env55028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318701,466225,8328,65,4456924,313836,449004,138477,148940,4466848,257,21792,46213,221722]

theorem envBound55028 : H12AffineFastState.Bounded env55028 := by
  intro p hp
  have h : env55028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54979_55028 : H12AffineEnvironment.transform 20 151633 env54979 = env55028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env54979 == env55028) = true)

def env55029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,147640,318701,466225,8328,65,409956,313836,449004,138477,148940,419864,257,21792,46213,221722]

theorem envBound55029 : H12AffineFastState.Bounded env55029 := by
  intro p hp
  have h : env55029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55028_55029 : H12AffineEnvironment.transform 21 147640 env55028 = env55029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147640 env55028 == env55029) = true)

def env55030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4161,168,318701,351521,8328,65,262516,313836,301564,23805,1500,272392,257,21792,46213,74250]

theorem envBound55030 : H12AffineFastState.Bounded env55030 := by
  intro p hp
  have h : env55030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55029_55030 : H12AffineEnvironment.transform 16 16400 env55029 = env55030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55029 == env55030) = true)

theorem identity55030 : scanCanonicalize (H12AffineFastState.compose env55030 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound55030 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16400,262144,1025,32769,4161,168,318701,297470,8328,65,262516,313836,301564,23805,1500,272392,257,21792,46213,63189]

theorem envBound55031 : H12AffineFastState.Bounded env55031 := by
  intro p hp
  have h : env55031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55030_55031 : H12AffineEnvironment.transform 15 54495 env55030 = env55031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env55030 == env55031) = true)

theorem identity55031 : scanCanonicalize (H12AffineFastState.compose env55031 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound55031 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env55032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16400,262144,1025,29909,4161,168,272441,294186,8328,65,262516,277816,290088,23805,1500,272392,257,21792,16465,513]

theorem envBound55032 : H12AffineFastState.Bounded env55032 := by
  intro p hp
  have h : env55032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55031_55032 : H12AffineEnvironment.transform 14 29908 env55031 = env55032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env55031 == env55032) = true)

theorem identity55032 : scanCanonicalize (H12AffineFastState.compose env55032 (packedSelected [7,11,14,18,20,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound55032 : packedSelected [7,11,14,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env55033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16400,32040,1025,29909,4161,168,21777,2,8328,65,31836,16400,4096,23805,1500,21792,257,21792,16465,513]

theorem envBound55033 : H12AffineFastState.Bounded env55033 := by
  intro p hp
  have h : env55033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55032_55033 : H12AffineEnvironment.transform 17 32040 env55032 = env55033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env55032 == env55033) = true)

theorem identity55033 : scanCanonicalize (H12AffineFastState.compose env55033 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55033 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,5392,10280,1025,8661,4161,168,17,2,8328,65,10588,5392,4096,2557,1500,32,257,32,5457,513]

theorem envBound55034 : H12AffineFastState.Bounded env55034 := by
  intro p hp
  have h : env55034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55033_55034 : H12AffineEnvironment.transform 13 5376 env55033 = env55034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55033 == env55034) = true)

theorem identity55034 : scanCanonicalize (H12AffineFastState.compose env55034 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound55034 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,129,5376,341,138,5392,2217,1025,340,4161,168,17,2,9,65,2525,5392,4096,2557,1500,32,257,32,5457,513]

theorem envBound55035 : H12AffineFastState.Bounded env55035 := by
  intro p hp
  have h : env55035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55034_55035 : H12AffineEnvironment.transform 12 129 env55034 = env55035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env55034 == env55035) = true)

theorem identity55035 : scanCanonicalize (H12AffineFastState.compose env55035 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound55035 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55036 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,129,5340,137,138,5324,2217,1025,136,4161,168,17,2,9,65,2049,5324,4096,2081,1024,32,221,32,5261,513]

theorem envBound55036 : H12AffineFastState.Bounded env55036 := by
  intro p hp
  have h : env55036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55035_55036 : H12AffineEnvironment.transform 7 220 env55035 = env55036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env55035 == env55036) = true)

def env55037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4160,169,318701,351520,8328,65,262517,313836,301565,23804,1501,272393,257,21792,46213,74251]

theorem envBound55037 : H12AffineFastState.Bounded env55037 := by
  intro p hp
  have h : env55037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55029_55037 : H12AffineEnvironment.transform 16 16401 env55029 = env55037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55029 == env55037) = true)

theorem identity55037 : scanCanonicalize (H12AffineFastState.compose env55037 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 130294) := by decide +kernel

theorem selectedBound55037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,130294,1025,32769,4160,169,73755,41430,8328,65,130435,79130,91403,23804,1501,120063,257,21792,46213,74251]

theorem envBound55038 : H12AffineFastState.Bounded env55038 := by
  intro p hp
  have h : env55038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55037_55038 : H12AffineEnvironment.transform 17 130294 env55037 = env55038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130294 env55037 == env55038) = true)

def env55039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,130174,1025,32769,4160,33,73755,41310,8192,65,130315,79130,91403,23668,1365,119927,257,21792,46093,74251]

theorem envBound55039 : H12AffineFastState.Bounded env55039 := by
  intro p hp
  have h : env55039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55038_55039 : H12AffineEnvironment.transform 6 8 env55038 = env55039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55038 == env55039) = true)

theorem identity55039 : scanCanonicalize (H12AffineFastState.compose env55039 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound55039 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16401,32040,1025,32769,4160,33,41293,41310,8192,65,31837,46156,58461,23668,1365,21793,257,21792,46093,41821]

theorem envBound55040 : H12AffineFastState.Bounded env55040 := by
  intro p hp
  have h : env55040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55039_55040 : H12AffineEnvironment.transform 15 33110 env55039 = env55040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env55039 == env55040) = true)

theorem identity55040 : scanCanonicalize (H12AffineFastState.compose env55040 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound55040 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,33110,13673,2128,1025,32769,4160,33,41293,41310,8192,65,2341,46156,37157,10508,1365,8281,257,8280,46093,41821]

theorem envBound55041 : H12AffineFastState.Bounded env55041 := by
  intro p hp
  have h : env55041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55040_55041 : H12AffineEnvironment.transform 13 13688 env55040 = env55041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env55040 == env55041) = true)

theorem identity55041 : scanCanonicalize (H12AffineFastState.compose env55041 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound55041 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env55042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,293,115,13673,2128,1025,292,4160,33,8296,8315,8192,65,2341,13673,4096,10508,1365,8281,257,8280,13608,8824]

theorem envBound55042 : H12AffineFastState.Bounded env55042 := by
  intro p hp
  have h : env55042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55041_55042 : H12AffineEnvironment.transform 14 293 env55041 = env55042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env55041 == env55042) = true)

theorem identity55042 : scanCanonicalize (H12AffineFastState.compose env55042 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound55042 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,293,115,5393,2128,1025,292,4160,33,16,3,120,65,2341,5393,4096,2420,1365,33,257,32,5456,512]

theorem envBound55043 : H12AffineFastState.Bounded env55043 := by
  intro p hp
  have h : env55043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55042_55043 : H12AffineEnvironment.transform 12 120 env55042 = env55043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env55042 == env55043) = true)

theorem identity55043 : scanCanonicalize (H12AffineFastState.compose env55043 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound55043 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55044 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,120,5205,112,115,5188,2128,1025,113,4160,33,16,3,120,65,2160,5188,4096,2081,1024,33,84,32,5125,512]

theorem envBound55044 : H12AffineFastState.Bounded env55044 := by
  intro p hp
  have h : env55044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55043_55044 : H12AffineEnvironment.transform 7 85 env55043 = env55044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env55043 == env55044) = true)

theorem identity55044 : scanCanonicalize (H12AffineFastState.compose env55044 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55044 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55045 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,89,5205,81,82,5188,2128,1025,80,4160,0,16,3,89,65,2129,5188,4096,2048,1024,0,84,1,5125,512]

theorem envBound55045 : H12AffineFastState.Bounded env55045 := by
  intro p hp
  have h : env55045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55044_55045 : H12AffineEnvironment.transform 4 1 env55044 = env55045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55044 == env55045) = true)

theorem identity55045 : scanCanonicalize (H12AffineFastState.compose env55045 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound55045 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55046 : List Nat := [2,4,8,16,1,64,8,85,512,1024,81,4096,89,5205,81,82,5188,1,1025,80,4160,0,16,3,89,65,0,5188,4096,81,1024,0,84,1,5125,512]

theorem envBound55046 : H12AffineFastState.Bounded env55046 := by
  intro p hp
  have h : env55046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55045_55046 : H12AffineEnvironment.transform 10 81 env55045 = env55046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env55045 == env55046) = true)

def env55047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,130175,1025,32769,4160,32,73755,41311,8193,65,130314,79130,91403,23669,1364,119926,257,21792,46092,74251]

theorem envBound55047 : H12AffineFastState.Bounded env55047 := by
  intro p hp
  have h : env55047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55038_55047 : H12AffineEnvironment.transform 6 9 env55038 = env55047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55038 == env55047) = true)

theorem identity55047 : scanCanonicalize (H12AffineFastState.compose env55047 (packedSelected [3,4,5,9,10,12,14,16,17,38] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55047 : packedSelected [3,4,5,9,10,12,14,16,17,38] rootPS < 2^1333 := by decide +kernel

def env55048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,108927,1025,32769,4160,32,73755,41311,8193,65,108554,79130,77835,2421,1364,98678,257,32,46092,74251]

theorem envBound55048 : H12AffineFastState.Bounded env55048 := by
  intro p hp
  have h : env55048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55047_55048 : H12AffineEnvironment.transform 13 5376 env55047 = env55048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55047 == env55048) = true)

theorem identity55048 : scanCanonicalize (H12AffineFastState.compose env55048 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55048 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,65536,5393,76158,1025,0,4160,32,73755,8542,8193,65,75787,79130,77835,2421,1364,65911,257,32,13325,74251]

theorem envBound55049 : H12AffineFastState.Bounded env55049 := by
  intro p hp
  have h : env55049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55048_55049 : H12AffineEnvironment.transform 14 1 env55048 = env55049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55048 == env55049) = true)

theorem identity55049 : scanCanonicalize (H12AffineFastState.compose env55049 (packedSelected [1,2,3,4,6,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound55049 : packedSelected [1,2,3,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env55050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,5376,1,65536,5393,68679,1025,0,4160,32,66850,1127,1336,65,68914,69667,70962,2421,1364,65911,257,32,4404,67378]

theorem envBound55050 : H12AffineFastState.Bounded env55050 := by
  intro p hp
  have h : env55050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55049_55050 : H12AffineEnvironment.transform 12 1337 env55049 = env55050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env55049 == env55050) = true)

theorem identity55050 : scanCanonicalize (H12AffineFastState.compose env55050 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55050 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55051 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1337,5376,1,65536,5393,68630,1025,0,4113,32,66850,1078,1336,16,68914,69667,70962,2340,1285,65830,257,32,4404,67378]

theorem envBound55051 : H12AffineFastState.Bounded env55051 := by
  intro p hp
  have h : env55051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55050_55051 : H12AffineEnvironment.transform 5 17 env55050 = env55051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55050 == env55051) = true)

theorem identity55051 : scanCanonicalize (H12AffineFastState.compose env55051 (packedSelected [1,2,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55051 : packedSelected [1,2,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55052 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1337,5376,1,263,5393,3345,1025,0,4113,32,1061,1078,1336,16,3125,4388,5173,2340,1285,33,257,32,4404,1589]

theorem envBound55052 : H12AffineFastState.Bounded env55052 := by
  intro p hp
  have h : env55052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55051_55052 : H12AffineEnvironment.transform 15 263 env55051 = env55052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55051 == env55052) = true)

theorem identity55052 : scanCanonicalize (H12AffineFastState.compose env55052 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55052 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env55053 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4112,1,263,4097,2049,273,0,4113,32,309,294,40,16,2341,4388,4389,2340,21,33,257,32,4404,805]

theorem envBound55053 : H12AffineFastState.Bounded env55053 := by
  intro p hp
  have h : env55053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55052_55053 : H12AffineEnvironment.transform 9 272 env55052 = env55053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55052 == env55053) = true)

theorem identity55053 : scanCanonicalize (H12AffineFastState.compose env55053 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55053 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env55054 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4112,1,35,4097,2049,53,0,4113,32,17,2,40,16,2049,4096,4097,2048,21,33,37,32,4112,513]

theorem envBound55054 : H12AffineFastState.Bounded env55054 := by
  intro p hp
  have h : env55054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55053_55054 : H12AffineEnvironment.transform 7 36 env55053 = env55054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55053 == env55054) = true)

theorem identity55054 : scanCanonicalize (H12AffineFastState.compose env55054 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound55054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55055 : List Nat := [2,4,8,16,32,17,9,36,512,52,512,4096,41,4112,1,35,4097,513,53,0,4113,32,17,2,40,16,513,4096,4097,512,21,33,37,32,4112,513]

theorem envBound55055 : H12AffineFastState.Bounded env55055 := by
  intro p hp
  have h : env55055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55054_55055 : H12AffineEnvironment.transform 10 512 env55054 = env55055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env55054 == env55055) = true)

theorem identity55055 : scanCanonicalize (H12AffineFastState.compose env55055 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55055 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55056 : List Nat := [2,4,8,11,32,10,9,36,512,47,512,4096,41,4107,1,35,4097,513,46,0,4106,32,10,2,40,11,513,4096,4097,512,14,33,37,32,4107,513]

theorem envBound55056 : H12AffineFastState.Bounded env55056 := by
  intro p hp
  have h : env55056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55055_55056 : H12AffineEnvironment.transform 3 11 env55055 = env55056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55055 == env55056) = true)

theorem identity55056 : scanCanonicalize (H12AffineFastState.compose env55056 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55057 : List Nat := [2,4,8,11,0,10,9,4,512,15,512,4096,9,4107,1,3,4097,513,14,0,4106,0,10,2,8,11,513,4096,4097,512,14,1,5,0,4107,513]

theorem envBound55057 : H12AffineFastState.Bounded env55057 := by
  intro p hp
  have h : env55057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55056_55057 : H12AffineEnvironment.transform 4 0 env55056 = env55057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55056 == env55057) = true)

theorem identity55057 : scanCanonicalize (H12AffineFastState.compose env55057 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55057 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55058 : List Nat := [2,4,2,1,0,0,3,4,512,5,512,4096,3,4097,1,3,4097,513,4,0,4096,0,0,2,2,1,513,4096,4097,512,4,1,5,0,4097,513]

theorem envBound55058 : H12AffineFastState.Bounded env55058 := by
  intro p hp
  have h : env55058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55057_55058 : H12AffineEnvironment.transform 2 2 env55057 = env55058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55057 == env55058) = true)

def env55059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,147641,318701,466225,8328,65,409957,313836,449004,138477,148940,419865,257,21792,46213,221722]

theorem envBound55059 : H12AffineFastState.Bounded env55059 := by
  intro p hp
  have h : env55059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55028_55059 : H12AffineEnvironment.transform 21 147641 env55028 = env55059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147641 env55028 == env55059) = true)

def env55060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4161,169,318701,351521,8328,65,262517,313836,301564,23805,1500,272393,257,21792,46213,74250]

theorem envBound55060 : H12AffineFastState.Bounded env55060 := by
  intro p hp
  have h : env55060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55059_55060 : H12AffineEnvironment.transform 16 16400 env55059 = env55060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55059 == env55060) = true)

theorem identity55060 : scanCanonicalize (H12AffineFastState.compose env55060 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound55060 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,67619,1025,32769,4161,169,120014,21762,8328,65,67926,115151,102879,23805,1500,73770,257,21792,46213,74250]

theorem envBound55061 : H12AffineFastState.Bounded env55061 := by
  intro p hp
  have h : env55061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55060_55061 : H12AffineEnvironment.transform 17 67619 env55060 = env55061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env55060 == env55061) = true)

theorem identity55061 : scanCanonicalize (H12AffineFastState.compose env55061 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55061 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env55062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,67619,1025,32769,4161,32,119879,21762,8193,65,67926,115014,102742,23668,1365,73770,257,21792,46092,74250]

theorem envBound55062 : H12AffineFastState.Bounded env55062 := by
  intro p hp
  have h : env55062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55061_55062 : H12AffineEnvironment.transform 6 9 env55061 = env55062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55061 == env55062) = true)

theorem identity55062 : scanCanonicalize (H12AffineFastState.compose env55062 (packedSelected [0,1,3,4,5,8,9,14,15,17,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound55062 : packedSelected [0,1,3,4,5,8,9,14,15,17,23,27] rootPS < 2^1333 := by decide +kernel

def env55063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33030,16400,35109,1025,32769,4161,32,21825,21762,8193,65,34896,16448,4176,23668,1365,41260,257,21792,46092,41740]

theorem envBound55063 : H12AffineFastState.Bounded env55063 := by
  intro p hp
  have h : env55063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55062_55063 : H12AffineEnvironment.transform 15 33030 env55062 = env55063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env55062 == env55063) = true)

theorem identity55063 : scanCanonicalize (H12AffineFastState.compose env55063 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55063 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env55064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33030,16400,35109,1025,32769,4161,32,21825,21762,348,65,34896,16448,4176,23668,1365,32881,257,21792,38225,33361]

theorem envBound55064 : H12AffineFastState.Bounded env55064 := by
  intro p hp
  have h : env55064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55063_55064 : H12AffineEnvironment.transform 12 349 env55063 = env55064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55063 == env55064) = true)

theorem identity55064 : scanCanonicalize (H12AffineFastState.compose env55064 (packedSelected [0,3,4,5,6,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55064 : packedSelected [0,3,4,5,6,12,14] rootPS < 2^1333 := by decide +kernel

def env55065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,262,16400,2341,1025,1,4161,32,21825,21762,348,65,2128,16448,4176,23668,1365,113,257,21792,5457,593]

theorem envBound55065 : H12AffineFastState.Bounded env55065 := by
  intro p hp
  have h : env55065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55064_55065 : H12AffineEnvironment.transform 14 0 env55064 = env55065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55064 == env55065) = true)

theorem identity55065 : scanCanonicalize (H12AffineFastState.compose env55065 (packedSelected [1,4,6,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55065 : packedSelected [1,4,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55066 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,16400,2341,1025,1,4112,32,21776,21762,269,16,2049,16401,4097,23589,1284,32,257,21792,5376,512]

theorem envBound55066 : H12AffineFastState.Bounded env55066 := by
  intro p hp
  have h : env55066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55065_55066 : H12AffineEnvironment.transform 5 17 env55065 = env55066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55065 == env55066) = true)

theorem identity55066 : scanCanonicalize (H12AffineFastState.compose env55066 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55066 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55067 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,16384,0,262,16400,2309,1025,1,4112,0,21776,21762,269,16,2049,16401,4097,23557,1284,0,257,21760,5376,512]

theorem envBound55067 : H12AffineFastState.Bounded env55067 := by
  intro p hp
  have h : env55067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55066_55067 : H12AffineEnvironment.transform 4 0 env55066 = env55067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55066 == env55067) = true)

theorem identity55067 : scanCanonicalize (H12AffineFastState.compose env55067 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 6420) := by decide +kernel

theorem selectedBound55067 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env55068 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,6420,0,262,6404,2309,1025,1,4112,0,3076,3094,269,16,2049,6405,4097,1297,1284,0,257,3092,5376,512]

theorem envBound55068 : H12AffineFastState.Bounded env55068 := by
  intro p hp
  have h : env55068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55067_55068 : H12AffineEnvironment.transform 13 6420 env55067 = env55068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6420 env55067 == env55068) = true)

theorem identity55068 : scanCanonicalize (H12AffineFastState.compose env55068 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound55068 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55069 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,277,268,2049,0,262,2065,2309,1025,1,261,0,3076,3094,269,16,2049,2064,276,1297,1284,0,257,3092,1045,512]

theorem envBound55069 : H12AffineFastState.Bounded env55069 := by
  intro p hp
  have h : env55069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55068_55069 : H12AffineEnvironment.transform 11 277 env55068 = env55069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env55068 == env55069) = true)

theorem identity55069 : scanCanonicalize (H12AffineFastState.compose env55069 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55069 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55070 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,16,9,2049,0,3,2065,2048,1025,1,0,0,3076,3094,8,16,2049,2064,17,1044,1025,0,4,3092,1045,512]

theorem envBound55070 : H12AffineFastState.Bounded env55070 := by
  intro p hp
  have h : env55070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55069_55070 : H12AffineEnvironment.transform 7 5 env55069 = env55070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55069 == env55070) = true)

theorem identity55070 : scanCanonicalize (H12AffineFastState.compose env55070 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound55070 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55071 : List Nat := [2,4,8,16,0,17,9,5,512,1024,1045,16,9,1044,0,3,1028,1045,1025,1,0,0,17,3,8,16,1044,1029,17,1044,1025,0,4,1,1045,512]

theorem envBound55071 : H12AffineFastState.Bounded env55071 := by
  intro p hp
  have h : env55071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55070_55071 : H12AffineEnvironment.transform 10 1045 env55070 = env55071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env55070 == env55071) = true)

theorem identity55071 : scanCanonicalize (H12AffineFastState.compose env55071 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55071 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55072 : List Nat := [2,4,8,16,0,17,9,5,512,21,0,16,9,1,0,3,17,0,20,1,0,0,17,3,8,16,1,16,17,1,20,0,4,1,0,512]

theorem envBound55072 : H12AffineFastState.Bounded env55072 := by
  intro p hp
  have h : env55072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55071_55072 : H12AffineEnvironment.transform 9 21 env55071 = env55072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55071 == env55072) = true)

theorem identity55072 : scanCanonicalize (H12AffineFastState.compose env55072 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound55072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55073 : List Nat := [2,4,8,16,0,17,9,5,14,21,0,16,9,1,0,3,17,0,20,1,0,0,17,3,8,16,1,16,17,1,20,0,4,1,0,14]

theorem envBound55073 : H12AffineFastState.Bounded env55073 := by
  intro p hp
  have h : env55073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55072_55073 : H12AffineEnvironment.transform 8 14 env55072 = env55073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env55072 == env55073) = true)

def env55074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4160,168,318701,351520,8328,65,262516,313836,301565,23804,1501,272392,257,21792,46213,74251]

theorem envBound55074 : H12AffineFastState.Bounded env55074 := by
  intro p hp
  have h : env55074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55059_55074 : H12AffineEnvironment.transform 16 16401 env55059 = env55074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55059 == env55074) = true)

theorem identity55074 : scanCanonicalize (H12AffineFastState.compose env55074 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55074 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,168,318701,294186,8328,65,262516,313836,301565,23804,1501,272392,257,21792,46213,513]

theorem envBound55075 : H12AffineFastState.Bounded env55075 := by
  intro p hp
  have h : env55075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55074_55075 : H12AffineEnvironment.transform 15 8202 env55074 = env55075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55074 == env55075) = true)

def env55076 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4112,168,318653,294186,8328,17,262436,313788,301485,23724,1421,272392,257,21792,46213,513]

theorem envBound55076 : H12AffineFastState.Bounded env55076 := by
  intro p hp
  have h : env55076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55075_55076 : H12AffineEnvironment.transform 5 16 env55075 = env55076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55075 == env55076) = true)

theorem identity55076 : scanCanonicalize (H12AffineFastState.compose env55076 (packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound55076 : packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env55077 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35244,1025,32769,4112,168,21777,62598,8328,17,34952,16400,4097,23724,1421,41380,257,21792,46213,513]

theorem envBound55077 : H12AffineFastState.Bounded env55077 := by
  intro p hp
  have h : env55077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55076_55077 : H12AffineEnvironment.transform 17 35244 env55076 = env55077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env55076 == env55077) = true)

theorem identity55077 : scanCanonicalize (H12AffineFastState.compose env55077 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound55077 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env55078 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8202,16401,32160,1025,29709,4112,168,21777,138,8328,17,31876,16400,4097,23724,1421,21928,257,21792,16521,513]

theorem envBound55078 : H12AffineFastState.Bounded env55078 := by
  intro p hp
  have h : env55078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55077_55078 : H12AffineEnvironment.transform 14 29708 env55077 = env55078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env55077 == env55078) = true)

theorem identity55078 : scanCanonicalize (H12AffineFastState.compose env55078 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound55078 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55079 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8580,8202,5529,10280,1025,8581,4112,168,153,138,8328,17,10508,5528,4097,2340,1421,32,257,168,5377,513]

theorem envBound55079 : H12AffineFastState.Bounded env55079 := by
  intro p hp
  have h : env55079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55078_55079 : H12AffineEnvironment.transform 13 5512 env55078 = env55079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env55078 == env55079) = true)

theorem identity55079 : scanCanonicalize (H12AffineFastState.compose env55079 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55079 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55080 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,5393,10280,1025,8461,4112,32,17,2,8192,17,10508,5392,4097,2340,1285,32,257,32,5377,513]

theorem envBound55080 : H12AffineFastState.Bounded env55080 := by
  intro p hp
  have h : env55080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55079_55080 : H12AffineEnvironment.transform 6 8 env55079 = env55080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55079 == env55080) = true)

theorem identity55080 : scanCanonicalize (H12AffineFastState.compose env55080 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55081 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8192,4112,8460,8202,4097,10280,273,8461,4112,32,17,2,8192,17,10508,4096,4097,2340,21,32,257,32,4113,513]

theorem envBound55081 : H12AffineFastState.Bounded env55081 := by
  intro p hp
  have h : env55081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55080_55081 : H12AffineEnvironment.transform 9 272 env55080 = env55081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55080 == env55081) = true)

theorem identity55081 : scanCanonicalize (H12AffineFastState.compose env55081 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55081 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55082 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,8192,4112,8233,8202,4097,10280,52,8232,4112,32,17,2,8192,17,10281,4096,4097,2049,21,32,36,32,4113,513]

theorem envBound55082 : H12AffineFastState.Bounded env55082 := by
  intro p hp
  have h : env55082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55081_55082 : H12AffineEnvironment.transform 7 37 env55081 = env55082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55081 == env55082) = true)

theorem identity55082 : scanCanonicalize (H12AffineFastState.compose env55082 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound55082 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55083 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,552,4112,513,546,4097,2560,52,512,4112,32,17,2,552,17,2561,4096,4097,2049,21,32,36,32,4113,513]

theorem envBound55083 : H12AffineFastState.Bounded env55083 := by
  intro p hp
  have h : env55083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55082_55083 : H12AffineEnvironment.transform 12 552 env55082 = env55083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env55082 == env55083) = true)

theorem identity55083 : scanCanonicalize (H12AffineFastState.compose env55083 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound55083 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55084 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,571,552,555,513,546,570,2560,52,512,555,32,17,2,552,17,2561,571,570,2049,21,32,36,32,554,513]

theorem envBound55084 : H12AffineFastState.Bounded env55084 := by
  intro p hp
  have h : env55084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55083_55084 : H12AffineEnvironment.transform 11 571 env55083 = env55084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env55083 == env55084) = true)

def env55085 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4113,168,318652,294186,8328,16,262437,313789,301484,23725,1420,272392,257,21792,46213,513]

theorem envBound55085 : H12AffineFastState.Bounded env55085 := by
  intro p hp
  have h : env55085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55075_55085 : H12AffineEnvironment.transform 5 17 env55075 = env55085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55075 == env55085) = true)

theorem identity55085 : scanCanonicalize (H12AffineFastState.compose env55085 (packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound55085 : packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env55086 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,56356,1025,32769,4113,168,152,41230,8328,16,56577,5529,17800,23725,1420,62508,257,21792,46213,513]

theorem envBound55086 : H12AffineFastState.Bounded env55086 := by
  intro p hp
  have h : env55086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55085_55086 : H12AffineEnvironment.transform 17 56356 env55085 = env55086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env55085 == env55086) = true)

theorem identity55086 : scanCanonicalize (H12AffineFastState.compose env55086 (packedSelected [1,2,4,5,6,8,9,14,15,20,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55086 : packedSelected [1,2,4,5,6,8,9,14,15,20,24,38] rootPS < 2^1333 := by decide +kernel

def env55087 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,32768,263,16401,56356,1025,32769,4113,168,152,32771,389,16,56577,5529,17800,23725,1420,54561,257,21792,38280,513]

theorem envBound55087 : H12AffineFastState.Bounded env55087 := by
  intro p hp
  have h : env55087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55086_55087 : H12AffineEnvironment.transform 12 269 env55086 = env55087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55086 == env55087) = true)

theorem identity55087 : scanCanonicalize (H12AffineFastState.compose env55087 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55087 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55088 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,0,263,16401,23588,1025,1,4113,168,152,3,389,16,23809,5529,17800,23725,1420,21793,257,21792,5512,513]

theorem envBound55088 : H12AffineFastState.Bounded env55088 := by
  intro p hp
  have h : env55088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55087_55088 : H12AffineEnvironment.transform 14 0 env55087 = env55088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55087 == env55088) = true)

theorem identity55088 : scanCanonicalize (H12AffineFastState.compose env55088 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55088 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env55089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1025,1,4113,168,152,3,389,16,2048,5529,4233,2476,1420,32,257,33,5512,513]

theorem envBound55089 : H12AffineFastState.Bounded env55089 := by
  intro p hp
  have h : env55089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55088_55089 : H12AffineEnvironment.transform 13 5377 env55088 = env55089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55088 == env55089) = true)

theorem identity55089 : scanCanonicalize (H12AffineFastState.compose env55089 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55089 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55090 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1025,1,4113,33,17,3,268,16,2048,5392,4096,2341,1285,32,257,33,5377,513]

theorem envBound55090 : H12AffineFastState.Bounded env55090 := by
  intro p hp
  have h : env55090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55089_55090 : H12AffineEnvironment.transform 6 9 env55089 = env55090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55089 == env55090) = true)

theorem identity55090 : scanCanonicalize (H12AffineFastState.compose env55090 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55091 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5172,2049,1025,1,4113,33,17,3,40,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound55091 : H12AffineFastState.Bounded env55091 := by
  intro p hp
  have h : env55091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55090_55091 : H12AffineEnvironment.transform 7 36 env55090 = env55091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55090 == env55091) = true)

def env55092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374097,145662401,525568,140903597,27337992,25733063]

theorem envBound55092 : H12AffineFastState.Bounded env55092 := by
  intro p hp
  have h : env55092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53269_55092 : H12AffineEnvironment.transform 29 155254785 env53269 = env55092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env53269 == env55092) = true)

def env55093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265169,145662401,525568,140903597,27337992,25733063]

theorem envBound55093 : H12AffineFastState.Bounded env55093 := by
  intro p hp
  have h : env55093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55092_55093 : H12AffineEnvironment.transform 25 64 env55092 = env55093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env55092 == env55093) = true)

def env55094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound55094 : H12AffineFastState.Bounded env55094 := by
  intro p hp
  have h : env55094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55093_55094 : H12AffineEnvironment.transform 26 30393344 env55093 = env55094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env55093 == env55094) = true)

def env55095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound55095 : H12AffineFastState.Bounded env55095 := by
  intro p hp
  have h : env55095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55094_55095 : H12AffineEnvironment.transform 18 1024 env55094 = env55095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env55094 == env55095) = true)

theorem identity55095 : scanCanonicalize (H12AffineFastState.compose env55095 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound55095 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8328,64,21479440,18973837,2118977,442385,16876545,23160257,256,18990269,18949400,16819159]

theorem envBound55096 : H12AffineFastState.Bounded env55096 := by
  intro p hp
  have h : env55096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55095_55096 : H12AffineEnvironment.transform 22 16 env55095 = env55096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55095 == env55096) = true)

def env55097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479440,18973701,2118977,442385,16876545,23160137,256,18990133,18949400,16819039]

theorem envBound55097 : H12AffineFastState.Bounded env55097 := by
  intro p hp
  have h : env55097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55096_55097 : H12AffineEnvironment.transform 6 8 env55096 = env55097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55096 == env55097) = true)

theorem identity55097 : scanCanonicalize (H12AffineFastState.compose env55097 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55097 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env55098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,16,16777216,8192,64,21455180,18949465,2118977,418125,16852317,23160137,256,18965865,18949400,16777731]

theorem envBound55098 : H12AffineFastState.Bounded env55098 := by
  intro p hp
  have h : env55098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55097_55098 : H12AffineEnvironment.transform 14 8540 env55097 = env55098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55097 == env55098) = true)

def env55099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1024,8541,2097152,4194304,16,16777216,8192,64,21307740,18949465,2118977,270685,16852317,23160137,256,18965865,18949400,16777731]

theorem envBound55099 : H12AffineFastState.Bounded env55099 := by
  intro p hp
  have h : env55099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55098_55099 : H12AffineEnvironment.transform 16 16400 env55098 = env55099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55098 == env55099) = true)

theorem identity55099 : scanCanonicalize (H12AffineFastState.compose env55099 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound55099 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1024,8541,2097152,4194304,16,2,8192,64,4530526,2172251,2118977,270685,75103,6382923,256,2188651,2172186,513]

theorem envBound55100 : H12AffineFastState.Bounded env55100 := by
  intro p hp
  have h : env55100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55099_55100 : H12AffineEnvironment.transform 23 2 env55099 = env55100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env55099 == env55100) = true)

theorem identity55100 : scanCanonicalize (H12AffineFastState.compose env55100 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound55100 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1024,8541,5457,4194304,16,2,8192,64,4530526,77834,16400,270685,75103,4288538,256,94266,77899,513]

theorem envBound55101 : H12AffineFastState.Bounded env55101 := by
  intro p hp
  have h : env55101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55100_55101 : H12AffineEnvironment.transform 20 5457 env55100 = env55101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env55100 == env55101) = true)

theorem identity55101 : scanCanonicalize (H12AffineFastState.compose env55101 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55101 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env55102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,262144,1024,8541,5457,4194304,16,2,8192,64,4456788,4096,16400,270685,1365,4214800,256,20528,4161,513]

theorem envBound55102 : H12AffineFastState.Bounded env55102 := by
  intro p hp
  have h : env55102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55101_55102 : H12AffineEnvironment.transform 15 8202 env55101 = env55102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55101 == env55102) = true)

theorem identity55102 : scanCanonicalize (H12AffineFastState.compose env55102 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 292937) := by decide +kernel

theorem selectedBound55102 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,262144,1024,8541,5457,292937,16,2,8192,64,31005,4096,16400,270685,1365,272473,256,20528,4161,513]

theorem envBound55103 : H12AffineFastState.Bounded env55103 := by
  intro p hp
  have h : env55103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55102_55103 : H12AffineEnvironment.transform 21 292937 env55102 = env55103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292937 env55102 == env55103) = true)

theorem identity55103 : scanCanonicalize (H12AffineFastState.compose env55103 (packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS)) = affineNative (2^(17+1) ^^^ 30824) := by decide +kernel

theorem selectedBound55103 : packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS < 2^1333 := by decide +kernel

def env55104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,30824,1024,8541,5457,33,16,2,8192,64,31005,4096,16400,22837,1365,20529,256,20528,4161,513]

theorem envBound55104 : H12AffineFastState.Bounded env55104 := by
  intro p hp
  have h : env55104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55103_55104 : H12AffineEnvironment.transform 17 30824 env55103 = env55104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30824 env55103 == env55104) = true)

theorem identity55104 : scanCanonicalize (H12AffineFastState.compose env55104 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55104 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55105 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,30776,1024,8461,5377,33,16,2,8192,16,31005,4096,16400,22837,1285,20529,256,20528,4113,513]

theorem envBound55105 : H12AffineFastState.Bounded env55105 := by
  intro p hp
  have h : env55105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55104_55105 : H12AffineEnvironment.transform 5 16 env55104 = env55105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55104 == env55105) = true)

theorem identity55105 : scanCanonicalize (H12AffineFastState.compose env55105 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound55105 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55106 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5157,8460,8202,5173,11293,1024,8461,5377,33,16,2,8192,16,11576,4096,5173,3344,1285,1044,256,1045,4113,513]

theorem envBound55106 : H12AffineFastState.Bounded env55106 := by
  intro p hp
  have h : env55106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55105_55106 : H12AffineEnvironment.transform 13 5157 env55105 = env55106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env55105 == env55106) = true)

theorem identity55106 : scanCanonicalize (H12AffineFastState.compose env55106 (packedSelected [0,4,7,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55106 : packedSelected [0,4,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env55107 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,8192,4112,8460,8202,4096,10280,53,8461,4404,33,16,2,8192,16,10509,4096,4096,2341,304,33,256,32,4113,513]

theorem envBound55107 : H12AffineFastState.Bounded env55107 := by
  intro p hp
  have h : env55107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55106_55107 : H12AffineEnvironment.transform 9 53 env55106 = env55107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55106 == env55107) = true)

theorem identity55107 : scanCanonicalize (H12AffineFastState.compose env55107 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55108 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,8192,4112,8233,8202,4096,10280,53,8232,4113,33,16,2,8192,16,10280,4096,4096,2048,21,33,37,32,4113,513]

theorem envBound55108 : H12AffineFastState.Bounded env55108 := by
  intro p hp
  have h : env55108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55107_55108 : H12AffineEnvironment.transform 7 37 env55107 = env55108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55107 == env55108) = true)

theorem identity55108 : scanCanonicalize (H12AffineFastState.compose env55108 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound55108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55109 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,4096,8192,4112,8233,8202,4096,8217,53,8232,4113,33,16,2,8192,16,8217,4096,4096,49,21,33,37,32,4113,513]

theorem envBound55109 : H12AffineFastState.Bounded env55109 := by
  intro p hp
  have h : env55109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55108_55109 : H12AffineEnvironment.transform 10 49 env55108 = env55109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env55108 == env55109) = true)

theorem identity55109 : scanCanonicalize (H12AffineFastState.compose env55109 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55109 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55110 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,4096,41,4112,0,35,4096,48,53,1,4113,33,16,2,41,16,48,4096,4096,49,21,33,37,32,4113,513]

theorem envBound55110 : H12AffineFastState.Bounded env55110 := by
  intro p hp
  have h : env55110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55109_55110 : H12AffineEnvironment.transform 12 41 env55109 = env55110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55109 == env55110) = true)

theorem identity55110 : scanCanonicalize (H12AffineFastState.compose env55110 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound55110 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55111 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,41,49,0,35,33,48,53,1,48,33,16,2,41,16,48,33,33,49,21,33,37,32,48,513]

theorem envBound55111 : H12AffineFastState.Bounded env55111 := by
  intro p hp
  have h : env55111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55110_55111 : H12AffineEnvironment.transform 11 33 env55110 = env55111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env55110 == env55111) = true)

def leafEnv55111 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,41,49,0,35,33,48,53,1,48,33,16,2,21,41,1,16,48,33,33,49,21,33,37,32,4,35,48,513,1,49,0]

def active55111 : List Nat := [0,1,2,3,4,8]

def tree55111 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55111 : H12WitnessSearch.Good tree55111 := H12GlobalWitnessIndex.good

theorem leafIdentity55111 : H12AffineFastState.composeSystem env55111 rootObs = leafEnv55111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55111 rootObs == leafEnv55111) = true)

theorem terminalChecked55111 : H12PackedTerminal.terminalCheckFast leafEnv55111 active55111 tree55111 = true := by decide +kernel

def env55112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,2097152,4194304,16,16777216,8192,64,21307741,18949465,2118977,270684,16852317,23160137,256,18965865,18949400,16777731]

theorem envBound55112 : H12AffineFastState.Bounded env55112 := by
  intro p hp
  have h : env55112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55098_55112 : H12AffineEnvironment.transform 16 16401 env55098 = env55112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55098 == env55112) = true)

theorem identity55112 : scanCanonicalize (H12AffineFastState.compose env55112 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound55112 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env55113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,2097152,33,16,16777216,8192,64,17113468,18949465,2118977,270684,16852317,18965864,256,18965865,18949400,16777731]

theorem envBound55113 : H12AffineFastState.Bounded env55113 := by
  intro p hp
  have h : env55113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55112_55113 : H12AffineEnvironment.transform 21 33 env55112 = env55113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55112 == env55113) = true)

theorem identity55113 : scanCanonicalize (H12AffineFastState.compose env55113 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound55113 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,2097152,33,16,272426,8192,64,67926,2428275,2118977,270684,331127,2444610,256,2444611,2428210,272937]

theorem envBound55114 : H12AffineFastState.Bounded env55114 := by
  intro p hp
  have h : env55114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55113_55114 : H12AffineEnvironment.transform 23 272426 env55113 = env55114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env55113 == env55114) = true)

theorem identity55114 : scanCanonicalize (H12AffineFastState.compose env55114 (packedSelected [0,2,3,4,5,6,9,10,11,12,15,20,23,27] rootPS)) = affineNative (2^(20+1) ^^^ 355438) := by decide +kernel

theorem selectedBound55114 : packedSelected [0,2,3,4,5,6,9,10,11,12,15,20,23,27] rootPS < 2^1333 := by decide +kernel

def env55115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,355438,33,16,272426,8192,64,67926,24861,342319,270684,331127,8492,256,8493,24924,272937]

theorem envBound55115 : H12AffineFastState.Bounded env55115 := by
  intro p hp
  have h : env55115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55114_55115 : H12AffineEnvironment.transform 20 355438 env55114 = env55115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 355438 env55114 == env55115) = true)

theorem identity55115 : scanCanonicalize (H12AffineFastState.compose env55115 (packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55115 : packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env55116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,83015,33,16,3,8192,64,67926,24861,69894,2421,75102,8492,256,8493,24924,512]

theorem envBound55116 : H12AffineFastState.Bounded env55116 := by
  intro p hp
  have h : env55116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55115_55116 : H12AffineEnvironment.transform 17 10281 env55115 = env55116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55115 == env55116) = true)

theorem identity55116 : scanCanonicalize (H12AffineFastState.compose env55116 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 21543) := by decide +kernel

theorem selectedBound55116 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env55117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21543,16401,10281,1024,8541,4192,33,16,3,8192,64,23921,24861,17697,2421,29049,8492,256,8493,24924,512]

theorem envBound55117 : H12AffineFastState.Bounded env55117 := by
  intro p hp
  have h : env55117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55116_55117 : H12AffineEnvironment.transform 15 21543 env55116 = env55117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21543 env55116 == env55117) = true)

theorem identity55117 : scanCanonicalize (H12AffineFastState.compose env55117 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55117 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8314,13388,10281,1024,8541,4192,33,16,3,8192,64,10540,5440,12668,2421,1316,8492,256,8493,5377,512]

theorem envBound55118 : H12AffineFastState.Bounded env55118 := by
  intro p hp
  have h : env55118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55117_55118 : H12AffineEnvironment.transform 13 13405 env55117 = env55118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55117 == env55118) = true)

theorem identity55118 : scanCanonicalize (H12AffineFastState.compose env55118 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55118 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55119 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13405,8312,8314,13388,10281,1024,8313,4192,33,16,3,8192,64,10248,5220,12376,2129,1024,8200,36,8201,5157,512]

theorem envBound55119 : H12AffineFastState.Bounded env55119 := by
  intro p hp
  have h : env55119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55118_55119 : H12AffineEnvironment.transform 7 36 env55118 = env55119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55118 == env55119) = true)

def env55120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21479440,18973700,2118977,442385,16876545,23160136,256,18990132,18949400,16819038]

theorem envBound55120 : H12AffineFastState.Bounded env55120 := by
  intro p hp
  have h : env55120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55096_55120 : H12AffineEnvironment.transform 6 9 env55096 = env55120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55096 == env55120) = true)

def env55121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331968,18973700,2118977,294913,16876545,23160136,256,18990132,18949400,16819038]

theorem envBound55121 : H12AffineFastState.Bounded env55121 := by
  intro p hp
  have h : env55121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55120_55121 : H12AffineEnvironment.transform 16 16400 env55120 = env55121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55120 == env55121) = true)

theorem identity55121 : scanCanonicalize (H12AffineFastState.compose env55121 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound55121 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,41311,8193,64,4530527,2172251,2118977,294913,75102,6407191,256,2188651,2196551,513]

theorem envBound55122 : H12AffineFastState.Bounded env55122 := by
  intro p hp
  have h : env55122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55121_55122 : H12AffineEnvironment.transform 23 41311 env55121 = env55122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env55121 == env55122) = true)

def env55123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41311,8193,64,4530527,115015,45405,294913,75102,4268043,256,98679,90203,513]

theorem envBound55123 : H12AffineFastState.Bounded env55123 := by
  intro p hp
  have h : env55123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55122_55123 : H12AffineEnvironment.transform 20 58396 env55122 = env55123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env55122 == env55123) = true)

theorem identity55123 : scanCanonicalize (H12AffineFastState.compose env55123 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55123 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,58396,4194304,16,41311,8193,64,4456789,57677,45405,294913,1364,4194305,256,41341,16465,513]

theorem envBound55124 : H12AffineFastState.Bounded env55124 := by
  intro p hp
  have h : env55124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55123_55124 : H12AffineEnvironment.transform 15 8202 env55123 = env55124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55123 == env55124) = true)

theorem identity55124 : scanCanonicalize (H12AffineFastState.compose env55124 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272473) := by decide +kernel

theorem selectedBound55124 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,58396,272473,16,41311,8193,64,10508,57677,45405,294913,1364,272472,256,41341,16465,513]

theorem envBound55125 : H12AffineFastState.Bounded env55125 := by
  intro p hp
  have h : env55125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55124_55125 : H12AffineEnvironment.transform 21 272473 env55124 = env55125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272473 env55124 == env55125) = true)

theorem identity55125 : scanCanonicalize (H12AffineFastState.compose env55125 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound55125 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env55126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,58396,32881,16,41311,8193,64,10508,57677,45405,10281,1364,32880,256,41341,16465,513]

theorem envBound55126 : H12AffineFastState.Bounded env55126 := by
  intro p hp
  have h : env55126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55125_55126 : H12AffineEnvironment.transform 17 43048 env55125 = env55126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env55125 == env55126) = true)

theorem identity55126 : scanCanonicalize (H12AffineFastState.compose env55126 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55126 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env55127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,2420,1024,8541,17728,8493,16,3,8193,64,10508,16401,4097,10281,1364,8492,256,33,16465,513]

theorem envBound55127 : H12AffineFastState.Bounded env55127 := by
  intro p hp
  have h : env55127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55126_55127 : H12AffineEnvironment.transform 14 8540 env55126 = env55127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55126 == env55127) = true)

theorem identity55127 : scanCanonicalize (H12AffineFastState.compose env55127 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55127 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55128 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8202,16400,2341,1024,8460,17681,8493,16,3,8193,17,10508,16401,4097,10281,1285,8492,256,33,16384,513]

theorem envBound55128 : H12AffineFastState.Bounded env55128 := by
  intro p hp
  have h : env55128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55127_55128 : H12AffineEnvironment.transform 5 17 env55127 = env55128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55127 == env55128) = true)

theorem identity55128 : scanCanonicalize (H12AffineFastState.compose env55128 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound55128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55129 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,8461,8202,5173,2341,1024,8460,4404,8493,16,3,8193,17,10508,5172,4097,10281,1285,8492,256,33,5157,513]

theorem envBound55129 : H12AffineFastState.Bounded env55129 := by
  intro p hp
  have h : env55129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55128_55129 : H12AffineEnvironment.transform 13 5157 env55128 = env55129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env55128 == env55129) = true)

theorem identity55129 : scanCanonicalize (H12AffineFastState.compose env55129 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55129 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55130 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5157,1,262,5173,2341,1024,0,4404,33,16,3,269,17,2048,5172,4097,2341,1285,32,256,33,5157,513]

theorem envBound55130 : H12AffineFastState.Bounded env55130 := by
  intro p hp
  have h : env55130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55129_55130 : H12AffineEnvironment.transform 12 268 env55129 = env55130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55129 == env55130) = true)

def env55131 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2837,1,262,2821,2341,1024,0,3588,33,16,3,269,17,2048,2820,3889,2341,1285,32,256,33,2837,513]

theorem envBound55131 : H12AffineFastState.Bounded env55131 := by
  intro p hp
  have h : env55131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55130_55131 : H12AffineEnvironment.transform 11 3888 env55130 = env55131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env55130 == env55131) = true)

def env55132 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1045,1,262,1029,1573,1024,0,260,33,16,3,269,17,1792,1028,49,1573,1285,32,256,33,1045,513]

theorem envBound55132 : H12AffineFastState.Bounded env55132 := by
  intro p hp
  have h : env55132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55131_55132 : H12AffineEnvironment.transform 10 1792 env55131 = env55132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env55131 == env55132) = true)

def env55133 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,48,268,33,1,262,49,529,52,0,260,33,16,3,269,17,820,48,49,529,305,32,256,33,33,513]

theorem envBound55133 : H12AffineFastState.Bounded env55133 := by
  intro p hp
  have h : env55133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55132_55133 : H12AffineEnvironment.transform 9 52 env55132 = env55133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55132 == env55133) = true)

theorem identity55133 : scanCanonicalize (H12AffineFastState.compose env55133 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound55133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55134 : List Nat := [2,4,8,16,32,17,9,256,271,52,59,48,268,33,1,262,49,286,52,0,260,33,16,3,269,17,59,48,49,286,305,32,256,33,33,270]

theorem envBound55134 : H12AffineFastState.Bounded env55134 := by
  intro p hp
  have h : env55134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55133_55134 : H12AffineEnvironment.transform 8 271 env55133 = env55134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env55133 == env55134) = true)

def leafEnv55134 : List Nat := [2,4,8,16,32,17,9,256,271,52,59,48,268,33,1,262,49,286,52,0,260,33,16,3,305,269,1,17,59,48,49,286,305,32,256,33,4,263,33,270,1,260,0]

def active55134 : List Nat := [0,1,2,3,4,7]

def tree55134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55134 : H12WitnessSearch.Good tree55134 := H12GlobalWitnessIndex.good

theorem leafIdentity55134 : H12AffineFastState.composeSystem env55134 rootObs = leafEnv55134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55134 rootObs == leafEnv55134) = true)

theorem terminalChecked55134 : H12PackedTerminal.terminalCheckFast leafEnv55134 active55134 tree55134 = true := by decide +kernel

def env55135 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,48,268,32,1,262,48,528,53,0,260,33,16,3,269,17,821,49,49,528,304,32,256,33,32,513]

theorem envBound55135 : H12AffineFastState.Bounded env55135 := by
  intro p hp
  have h : env55135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55132_55135 : H12AffineEnvironment.transform 9 53 env55132 = env55135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55132 == env55135) = true)

def env55136 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1044,1,262,1028,1572,1024,0,261,33,16,3,269,17,1793,1029,48,1572,1285,32,256,33,1044,513]

theorem envBound55136 : H12AffineFastState.Bounded env55136 := by
  intro p hp
  have h : env55136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55131_55136 : H12AffineEnvironment.transform 10 1793 env55131 = env55136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env55131 == env55136) = true)

theorem identity55136 : scanCanonicalize (H12AffineFastState.compose env55136 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55136 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55137 : List Nat := [2,4,8,16,32,17,9,256,512,272,529,49,268,260,1,262,276,820,272,0,261,33,16,3,269,17,529,277,48,820,21,32,256,33,260,513]

theorem envBound55137 : H12AffineFastState.Bounded env55137 := by
  intro p hp
  have h : env55137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55136_55137 : H12AffineEnvironment.transform 9 272 env55136 = env55137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55136 == env55137) = true)

def env55138 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,32,1,34,48,528,52,0,33,33,16,3,41,17,529,49,48,528,21,32,36,33,32,513]

theorem envBound55138 : H12AffineFastState.Bounded env55138 := by
  intro p hp
  have h : env55138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55137_55138 : H12AffineEnvironment.transform 7 36 env55137 = env55138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55137 == env55138) = true)

theorem identity55138 : scanCanonicalize (H12AffineFastState.compose env55138 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55139 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,49,40,32,1,34,48,58,52,0,33,33,16,3,41,17,59,49,48,58,21,32,36,33,32,43]

theorem envBound55139 : H12AffineFastState.Bounded env55139 := by
  intro p hp
  have h : env55139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55138_55139 : H12AffineEnvironment.transform 8 42 env55138 = env55139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55138 == env55139) = true)

def leafEnv55139 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,49,40,32,1,34,48,58,52,0,33,33,16,3,21,41,1,17,59,49,48,58,21,32,36,33,4,35,32,43,1,33,0]

def active55139 : List Nat := [0,1,2,3,4]

def tree55139 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55139 : H12WitnessSearch.Good tree55139 := H12GlobalWitnessIndex.good

theorem leafIdentity55139 : H12AffineFastState.composeSystem env55139 rootObs = leafEnv55139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55139 rootObs == leafEnv55139) = true)

theorem terminalChecked55139 : H12PackedTerminal.terminalCheckFast leafEnv55139 active55139 tree55139 = true := by decide +kernel

def env55140 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,49,41,33,1,35,49,529,53,0,32,33,16,3,40,17,529,48,48,529,21,32,37,33,33,513]

theorem envBound55140 : H12AffineFastState.Bounded env55140 := by
  intro p hp
  have h : env55140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55137_55140 : H12AffineEnvironment.transform 7 37 env55137 = env55140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55137 == env55140) = true)

def env55141 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2836,1,262,2820,2341,1024,0,3589,33,16,3,269,17,2048,2821,3888,2341,1285,32,256,33,2836,513]

theorem envBound55141 : H12AffineFastState.Bounded env55141 := by
  intro p hp
  have h : env55141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55130_55141 : H12AffineEnvironment.transform 11 3889 env55130 = env55141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env55130 == env55141) = true)

def env55142 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1044,1,262,1028,1573,1024,0,261,33,16,3,269,17,1792,1029,48,1573,1285,32,256,33,1044,513]

theorem envBound55142 : H12AffineFastState.Bounded env55142 := by
  intro p hp
  have h : env55142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55141_55142 : H12AffineEnvironment.transform 10 1792 env55141 = env55142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env55141 == env55142) = true)

theorem identity55142 : scanCanonicalize (H12AffineFastState.compose env55142 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55143 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,49,268,32,1,262,48,529,52,0,261,33,16,3,269,17,820,49,48,529,305,32,256,33,32,513]

theorem envBound55143 : H12AffineFastState.Bounded env55143 := by
  intro p hp
  have h : env55143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55142_55143 : H12AffineEnvironment.transform 9 52 env55142 = env55143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55142 == env55143) = true)

theorem identity55143 : scanCanonicalize (H12AffineFastState.compose env55143 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound55143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55144 : List Nat := [2,4,8,16,32,17,9,256,270,52,58,49,268,32,1,262,48,287,52,0,261,33,16,3,269,17,58,49,48,287,305,32,256,33,32,271]

theorem envBound55144 : H12AffineFastState.Bounded env55144 := by
  intro p hp
  have h : env55144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55143_55144 : H12AffineEnvironment.transform 8 270 env55143 = env55144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env55143 == env55144) = true)

def leafEnv55144 : List Nat := [2,4,8,16,32,17,9,256,270,52,58,49,268,32,1,262,48,287,52,0,261,33,16,3,305,269,1,17,58,49,48,287,305,32,256,33,4,263,32,271,1,261,0]

def active55144 : List Nat := [0,1,2,3,4,7]

def tree55144 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55144 : H12WitnessSearch.Good tree55144 := H12GlobalWitnessIndex.good

theorem leafIdentity55144 : H12AffineFastState.composeSystem env55144 rootObs = leafEnv55144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55144 rootObs == leafEnv55144) = true)

theorem terminalChecked55144 : H12PackedTerminal.terminalCheckFast leafEnv55144 active55144 tree55144 = true := by decide +kernel

def env55145 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1045,1,262,1029,1572,1024,0,260,33,16,3,269,17,1793,1028,49,1572,1285,32,256,33,1045,513]

theorem envBound55145 : H12AffineFastState.Bounded env55145 := by
  intro p hp
  have h : env55145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55141_55145 : H12AffineEnvironment.transform 10 1793 env55141 = env55145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env55141 == env55145) = true)

theorem identity55145 : scanCanonicalize (H12AffineFastState.compose env55145 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55146 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,48,40,1045,1,34,1029,1572,1024,0,32,33,16,3,41,17,1573,1028,49,1572,1057,32,36,33,1045,513]

theorem envBound55146 : H12AffineFastState.Bounded env55146 := by
  intro p hp
  have h : env55146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55145_55146 : H12AffineEnvironment.transform 7 36 env55145 = env55146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55145 == env55146) = true)

def env55147 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,40,33,1,34,49,528,52,0,32,33,16,3,41,17,529,48,49,528,21,32,36,33,33,513]

theorem envBound55147 : H12AffineFastState.Bounded env55147 := by
  intro p hp
  have h : env55147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55146_55147 : H12AffineEnvironment.transform 9 52 env55146 = env55147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55146 == env55147) = true)

theorem identity55147 : scanCanonicalize (H12AffineFastState.compose env55147 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55148 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,48,40,33,1,34,49,59,52,0,32,33,16,3,41,17,58,48,49,59,21,32,36,33,33,42]

theorem envBound55148 : H12AffineFastState.Bounded env55148 := by
  intro p hp
  have h : env55148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55147_55148 : H12AffineEnvironment.transform 8 43 env55147 = env55148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55147 == env55148) = true)

def leafEnv55148 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,48,40,33,1,34,49,59,52,0,32,33,16,3,21,41,1,17,58,48,49,59,21,32,36,33,4,35,33,42,1,32,0]

def active55148 : List Nat := [0,1,2,3,4]

def tree55148 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55148 : H12WitnessSearch.Good tree55148 := H12GlobalWitnessIndex.good

theorem leafIdentity55148 : H12AffineFastState.composeSystem env55148 rootObs = leafEnv55148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55148 rootObs == leafEnv55148) = true)

theorem terminalChecked55148 : H12PackedTerminal.terminalCheckFast leafEnv55148 active55148 tree55148 = true := by decide +kernel

def env55149 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,32,1,34,48,529,53,0,32,33,16,3,41,17,528,49,49,529,20,32,36,33,32,513]

theorem envBound55149 : H12AffineFastState.Bounded env55149 := by
  intro p hp
  have h : env55149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55146_55149 : H12AffineEnvironment.transform 9 53 env55146 = env55149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55146 == env55149) = true)

def env55150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41311,8193,64,4530527,115014,45404,294913,75102,4268042,256,98678,90202,513]

theorem envBound55150 : H12AffineFastState.Bounded env55150 := by
  intro p hp
  have h : env55150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55122_55150 : H12AffineEnvironment.transform 20 58397 env55122 = env55150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env55122 == env55150) = true)

def env55151 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41231,8193,16,4530447,114966,45324,294913,75022,4268042,256,98598,90122,513]

theorem envBound55151 : H12AffineFastState.Bounded env55151 := by
  intro p hp
  have h : env55151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55150_55151 : H12AffineEnvironment.transform 5 16 env55150 = env55151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55150 == env55151) = true)

theorem identity55151 : scanCanonicalize (H12AffineFastState.compose env55151 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound55151 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55152 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,272393,16,41231,8193,16,67846,114966,45324,294913,75022,329731,256,98598,90122,513]

theorem envBound55152 : H12AffineFastState.Bounded env55152 := by
  intro p hp
  have h : env55152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55151_55152 : H12AffineEnvironment.transform 21 272393 env55151 = env55152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env55151 == env55152) = true)

theorem identity55152 : scanCanonicalize (H12AffineFastState.compose env55152 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound55152 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55153 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33031,16400,262144,1024,32769,58397,272393,16,41231,8193,16,34817,16401,45324,294913,41993,297220,256,33,57613,513]

theorem envBound55153 : H12AffineFastState.Bounded env55153 := by
  intro p hp
  have h : env55153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55152_55153 : H12AffineEnvironment.transform 15 33031 env55152 = env55153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env55152 == env55153) = true)

theorem identity55153 : scanCanonicalize (H12AffineFastState.compose env55153 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound55153 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55154 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33031,16400,2341,1024,32769,58397,8492,16,41231,8193,16,34817,16401,45324,35108,41993,32801,256,33,57613,513]

theorem envBound55154 : H12AffineFastState.Bounded env55154 := by
  intro p hp
  have h : env55154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55153_55154 : H12AffineEnvironment.transform 17 2341 env55153 = env55154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env55153 == env55154) = true)

theorem identity55154 : scanCanonicalize (H12AffineFastState.compose env55154 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound55154 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55155 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,2341,1024,8461,17681,8492,16,3,8193,16,10509,16401,4096,10280,1285,8493,256,33,16385,513]

theorem envBound55155 : H12AffineFastState.Bounded env55155 := by
  intro p hp
  have h : env55155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55154_55155 : H12AffineEnvironment.transform 14 8460 env55154 = env55155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env55154 == env55155) = true)

theorem identity55155 : scanCanonicalize (H12AffineFastState.compose env55155 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound55155 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55156 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,4380,16384,4112,4375,16400,2341,1024,4113,17681,4144,16,3,4381,16,6161,16401,4096,6452,1285,4145,256,33,16385,513]

theorem envBound55156 : H12AffineFastState.Bounded env55156 := by
  intro p hp
  have h : env55156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55155_55156 : H12AffineEnvironment.transform 12 4380 env55155 = env55156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env55155 == env55156) = true)

theorem identity55156 : scanCanonicalize (H12AffineFastState.compose env55156 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55156 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55157 : List Nat := [2,4,8,16,32,16,9,256,512,1024,32,4096,4380,16384,4112,4375,16400,261,1024,4113,17681,4144,16,3,4381,16,4145,16401,4096,4372,1285,4145,256,33,16385,513]

theorem envBound55157 : H12AffineFastState.Bounded env55157 := by
  intro p hp
  have h : env55157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55156_55157 : H12AffineEnvironment.transform 10 32 env55156 = env55157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55156 == env55157) = true)

theorem identity55157 : scanCanonicalize (H12AffineFastState.compose env55157 (packedSelected [3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound55157 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env55158 : List Nat := [2,4,8,16,32,16,9,256,512,1024,32,1582,1842,16384,1598,1849,16400,261,1024,1599,17681,1566,16,3,1843,16,1567,16401,1582,1850,1285,1567,256,33,16385,513]

theorem envBound55158 : H12AffineFastState.Bounded env55158 := by
  intro p hp
  have h : env55158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55157_55158 : H12AffineEnvironment.transform 11 1582 env55157 = env55158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env55157 == env55158) = true)

theorem identity55158 : scanCanonicalize (H12AffineFastState.compose env55158 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55158 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55159 : List Nat := [2,4,8,16,32,16,9,36,512,1024,32,1582,1558,16384,1598,1565,16400,33,1024,1599,17461,1566,16,3,1559,16,1567,16401,1582,1566,1057,1567,36,33,16385,513]

theorem envBound55159 : H12AffineFastState.Bounded env55159 := by
  intro p hp
  have h : env55159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55158_55159 : H12AffineEnvironment.transform 7 36 env55158 = env55159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55158 == env55159) = true)

theorem identity55159 : scanCanonicalize (H12AffineFastState.compose env55159 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound55159 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55160 : List Nat := [2,4,8,16,32,16,9,36,512,1024,32,1582,1558,1076,1598,1565,1060,33,1024,1599,1,1566,16,3,1559,16,1567,1061,1582,1566,1057,1567,36,33,1077,513]

theorem envBound55160 : H12AffineFastState.Bounded env55160 := by
  intro p hp
  have h : env55160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55159_55160 : H12AffineEnvironment.transform 13 1076 env55159 = env55160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env55159 == env55160) = true)

theorem identity55160 : scanCanonicalize (H12AffineFastState.compose env55160 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound55160 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55161 : List Nat := [2,4,8,16,32,16,9,36,22,1024,32,1080,1024,1076,1064,1035,1060,33,1024,1065,1,1032,16,3,1025,16,1033,1061,1080,1032,1057,1033,36,33,1077,23]

theorem envBound55161 : H12AffineFastState.Bounded env55161 := by
  intro p hp
  have h : env55161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55160_55161 : H12AffineEnvironment.transform 8 22 env55160 = env55161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env55160 == env55161) = true)

theorem identity55161 : scanCanonicalize (H12AffineFastState.compose env55161 (packedSelected [0,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound55161 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env55162 : List Nat := [2,4,8,16,29,16,9,25,22,1024,29,1029,1024,1033,1045,1035,1049,28,1024,1044,1,1032,16,3,1025,16,1033,1048,1029,1032,1052,1033,25,28,1032,23]

theorem envBound55162 : H12AffineFastState.Bounded env55162 := by
  intro p hp
  have h : env55162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55161_55162 : H12AffineEnvironment.transform 4 29 env55161 = env55162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env55161 == env55162) = true)

theorem identity55162 : scanCanonicalize (H12AffineFastState.compose env55162 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55162 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env55163 : List Nat := [2,4,8,13,0,13,9,4,11,1024,0,1029,1024,1033,1032,1035,1028,1,1024,1033,1,1032,13,3,1025,13,1033,1029,1029,1032,1025,1033,4,1,1032,10]

theorem envBound55163 : H12AffineFastState.Bounded env55163 := by
  intro p hp
  have h : env55163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55162_55163 : H12AffineEnvironment.transform 3 13 env55162 = env55163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55162 == env55163) = true)

theorem identity55163 : scanCanonicalize (H12AffineFastState.compose env55163 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound55163 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env55164 : List Nat := [2,4,8,13,0,13,9,4,11,8,0,13,8,1,0,3,12,1,8,1,1,0,13,3,9,13,1,13,13,0,9,1,4,1,0,10]

theorem envBound55164 : H12AffineFastState.Bounded env55164 := by
  intro p hp
  have h : env55164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55163_55164 : H12AffineEnvironment.transform 9 8 env55163 = env55164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env55163 == env55164) = true)

theorem identity55164 : scanCanonicalize (H12AffineFastState.compose env55164 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55164 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55165 : List Nat := [1,4,8,13,0,13,9,4,8,8,0,13,8,1,0,0,12,1,8,1,1,0,13,0,9,13,1,13,13,0,9,1,4,1,0,9]

theorem envBound55165 : H12AffineFastState.Bounded env55165 := by
  intro p hp
  have h : env55165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55164_55165 : H12AffineEnvironment.transform 0 1 env55164 = env55165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55164 == env55165) = true)

def env55166 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41230,8193,17,4530446,114967,45325,294913,75023,4268042,256,98599,90123,513]

theorem envBound55166 : H12AffineFastState.Bounded env55166 := by
  intro p hp
  have h : env55166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55150_55166 : H12AffineEnvironment.transform 5 17 env55150 = env55166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55150 == env55166) = true)

theorem identity55166 : scanCanonicalize (H12AffineFastState.compose env55166 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329730) := by decide +kernel

theorem selectedBound55166 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55167 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,329730,16,41230,8193,17,10508,114967,45325,294913,75023,272392,256,98599,90123,513]

theorem envBound55167 : H12AffineFastState.Bounded env55167 := by
  intro p hp
  have h : env55167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55166_55167 : H12AffineEnvironment.transform 21 329730 env55166 = env55167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329730 env55166 == env55167) = true)

theorem identity55167 : scanCanonicalize (H12AffineFastState.compose env55167 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55167 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env55168 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16400,262144,1024,32769,50449,329730,16,32770,269,17,2048,114967,36865,294913,66563,264452,256,98599,82183,513]

theorem envBound55168 : H12AffineFastState.Bounded env55168 := by
  intro p hp
  have h : env55168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55167_55168 : H12AffineEnvironment.transform 12 268 env55167 = env55168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55167 == env55168) = true)

theorem identity55168 : scanCanonicalize (H12AffineFastState.compose env55168 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound55168 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55169 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16400,35109,1024,32769,50449,98599,16,32770,269,17,2048,114967,36865,2340,66563,32801,256,98599,82183,513]

theorem envBound55169 : H12AffineFastState.Bounded env55169 := by
  intro p hp
  have h : env55169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55168_55169 : H12AffineEnvironment.transform 17 35109 env55168 = env55169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env55168 == env55169) = true)

theorem identity55169 : scanCanonicalize (H12AffineFastState.compose env55169 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55169 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55170 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,263,16400,35109,1024,32769,50449,32800,16,32770,269,17,2048,49168,36865,2340,1284,32801,256,32800,16384,513]

theorem envBound55170 : H12AffineFastState.Bounded env55170 := by
  intro p hp
  have h : env55170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55169_55170 : H12AffineEnvironment.transform 15 263 env55169 = env55170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55169 == env55170) = true)

theorem identity55170 : scanCanonicalize (H12AffineFastState.compose env55170 (packedSelected [2,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 5408) := by decide +kernel

theorem selectedBound55170 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env55171 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,5408,263,16400,7173,1024,5409,20529,5376,16,5410,269,17,2048,21808,1313,2340,1284,5377,256,5376,16384,513]

theorem envBound55171 : H12AffineFastState.Bounded env55171 := by
  intro p hp
  have h : env55171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55170_55171 : H12AffineEnvironment.transform 14 5408 env55170 = env55171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5408 env55170 == env55171) = true)

theorem identity55171 : scanCanonicalize (H12AffineFastState.compose env55171 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55171 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env55172 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,16384,4144,263,16400,6421,272,4145,20529,4112,16,4146,269,17,2048,20512,49,2340,20,4113,256,4112,16384,513]

theorem envBound55172 : H12AffineFastState.Bounded env55172 := by
  intro p hp
  have h : env55172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55171_55172 : H12AffineEnvironment.transform 9 272 env55171 = env55172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55171 == env55172) = true)

theorem identity55172 : scanCanonicalize (H12AffineFastState.compose env55172 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55172 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env55173 : List Nat := [2,4,8,16,32,17,9,256,43,272,2048,4096,268,16384,4144,263,16400,6421,272,4145,20529,4112,16,4146,269,17,2048,20512,49,2340,20,4113,256,4112,16384,42]

theorem envBound55173 : H12AffineFastState.Bounded env55173 := by
  intro p hp
  have h : env55173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55172_55173 : H12AffineEnvironment.transform 8 43 env55172 = env55173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55172 == env55173) = true)

theorem identity55173 : scanCanonicalize (H12AffineFastState.compose env55173 (packedSelected [0,9] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound55173 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env55174 : List Nat := [2,4,8,16,32,17,9,256,43,272,2048,309,268,16384,261,263,16400,2080,272,260,16644,293,16,263,269,17,2048,16661,49,2340,20,292,256,293,16384,42]

theorem envBound55174 : H12AffineFastState.Bounded env55174 := by
  intro p hp
  have h : env55174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55173_55174 : H12AffineEnvironment.transform 11 309 env55173 = env55174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env55173 == env55174) = true)

theorem identity55174 : scanCanonicalize (H12AffineFastState.compose env55174 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound55174 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env55175 : List Nat := [2,4,8,16,32,17,9,256,43,272,2048,309,268,2308,261,263,2324,2080,272,260,2048,293,16,263,269,17,2048,2065,49,2340,20,292,256,293,2308,42]

theorem envBound55175 : H12AffineFastState.Bounded env55175 := by
  intro p hp
  have h : env55175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55174_55175 : H12AffineEnvironment.transform 13 2308 env55174 = env55175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env55174 == env55175) = true)

theorem identity55175 : scanCanonicalize (H12AffineFastState.compose env55175 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound55175 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55176 : List Nat := [2,4,8,16,32,17,9,256,43,272,292,309,268,32,261,263,48,260,272,260,292,293,16,263,269,17,292,309,49,0,20,292,256,293,32,42]

theorem envBound55176 : H12AffineFastState.Bounded env55176 := by
  intro p hp
  have h : env55176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55175_55176 : H12AffineEnvironment.transform 10 292 env55175 = env55176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env55175 == env55176) = true)

def env55177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331969,18973700,2118977,294912,16876545,23160136,256,18990132,18949400,16819038]

theorem envBound55177 : H12AffineFastState.Bounded env55177 := by
  intro p hp
  have h : env55177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55120_55177 : H12AffineEnvironment.transform 16 16401 env55120 = env55177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55120 == env55177) = true)

def env55178 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331969,18973700,2118709,294912,16876545,23159868,116,18990132,18949228,16818730]

theorem envBound55178 : H12AffineFastState.Bounded env55178 := by
  intro p hp
  have h : env55178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55177_55178 : H12AffineEnvironment.transform 7 116 env55177 = env55178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55177 == env55178) = true)

theorem identity55178 : scanCanonicalize (H12AffineFastState.compose env55178 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2444308) := by decide +kernel

theorem selectedBound55178 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env55179 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,2444308,8193,64,6343701,313360,2118709,294912,2410517,4466728,116,296992,288888,2485822]

theorem envBound55179 : H12AffineFastState.Bounded env55179 := by
  intro p hp
  have h : env55179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55178_55179 : H12AffineEnvironment.transform 23 2444308 env55178 = env55179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444308 env55178 == env55179) = true)

def env55180 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56436,1024,32769,2097152,4194304,16,2199648,8193,64,6343701,5220,2118709,23668,2102369,4256860,116,21588,46092,2175562]

theorem envBound55180 : H12AffineFastState.Bounded env55180 := by
  intro p hp
  have h : env55180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55179_55180 : H12AffineEnvironment.transform 17 56436 env55179 = env55180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env55179 == env55180) = true)

theorem identity55180 : scanCanonicalize (H12AffineFastState.compose env55180 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound55180 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env55181 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56436,1024,32769,77899,4194304,16,41003,8193,64,4324446,5220,91262,23668,74794,4256860,116,21588,46092,513]

theorem envBound55181 : H12AffineFastState.Bounded env55181 := by
  intro p hp
  have h : env55181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55180_55181 : H12AffineEnvironment.transform 20 77899 env55180 = env55181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env55180 == env55181) = true)

theorem identity55181 : scanCanonicalize (H12AffineFastState.compose env55181 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound55181 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env55182 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,65536,16401,10281,1024,29788,77899,4194304,16,21622,8193,64,4261891,5220,91262,23668,74794,4194305,116,21588,16465,513]

theorem envBound55182 : H12AffineFastState.Bounded env55182 := by
  intro p hp
  have h : env55182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55181_55182 : H12AffineEnvironment.transform 14 29789 env55181 = env55182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env55181 == env55182) = true)

theorem identity55182 : scanCanonicalize (H12AffineFastState.compose env55182 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound55182 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env55183 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,65536,16401,10281,1024,29788,77899,8201,16,21622,8193,64,75786,5220,91262,23668,74794,8200,116,21588,16465,513]

theorem envBound55183 : H12AffineFastState.Bounded env55183 := by
  intro p hp
  have h : env55183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55182_55183 : H12AffineEnvironment.transform 21 8201 env55182 = env55183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env55182 == env55183) = true)

theorem identity55183 : scanCanonicalize (H12AffineFastState.compose env55183 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound55183 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env55184 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,21590,16401,10281,1024,29788,25629,8201,16,21622,8193,64,31836,5220,12328,23668,28796,8200,116,21588,16465,513]

theorem envBound55184 : H12AffineFastState.Bounded env55184 := by
  intro p hp
  have h : env55184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55183_55184 : H12AffineEnvironment.transform 15 21590 env55183 = env55184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env55183 == env55184) = true)

theorem identity55184 : scanCanonicalize (H12AffineFastState.compose env55184 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55184 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55185 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,29709,21510,16401,10281,1024,29708,25629,8201,16,21542,8193,16,31756,5172,12328,23588,28716,8200,36,21508,16385,513]

theorem envBound55185 : H12AffineFastState.Bounded env55185 := by
  intro p hp
  have h : env55185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55184_55185 : H12AffineEnvironment.transform 5 16 env55184 = env55185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55184 == env55185) = true)

theorem identity55185 : scanCanonicalize (H12AffineFastState.compose env55185 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55185 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55186 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,16384,21540,21510,16401,2048,1024,21541,17460,32,16,21542,40,16,23589,5172,4097,23588,20485,33,36,21508,16385,513]

theorem envBound55186 : H12AffineFastState.Bounded env55186 := by
  intro p hp
  have h : env55186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55185_55186 : H12AffineEnvironment.transform 12 41 env55185 = env55186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55185 == env55186) = true)

theorem identity55186 : scanCanonicalize (H12AffineFastState.compose env55186 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound55186 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55187 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4112,32,16,2,40,16,2049,5172,4097,2048,1057,33,36,32,5157,513]

theorem envBound55187 : H12AffineFastState.Bounded env55187 := by
  intro p hp
  have h : env55187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55186_55187 : H12AffineEnvironment.transform 13 5156 env55186 = env55187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env55186 == env55187) = true)

theorem identity55187 : scanCanonicalize (H12AffineFastState.compose env55187 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound55187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55188 : List Nat := [2,4,8,16,32,16,9,36,512,37,2048,4096,41,4097,0,34,4112,2048,37,1,4112,32,16,2,40,16,2049,4113,4097,2048,4,33,36,32,4096,513]

theorem envBound55188 : H12AffineFastState.Bounded env55188 := by
  intro p hp
  have h : env55188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55187_55188 : H12AffineEnvironment.transform 9 37 env55187 = env55188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env55187 == env55188) = true)

theorem identity55188 : scanCanonicalize (H12AffineFastState.compose env55188 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound55188 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55189 : List Nat := [2,4,8,16,32,16,9,36,512,37,2048,512,41,513,0,34,528,2048,37,1,528,32,16,2,40,16,2049,529,513,2048,4,33,36,32,512,513]

theorem envBound55189 : H12AffineFastState.Bounded env55189 := by
  intro p hp
  have h : env55189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55188_55189 : H12AffineEnvironment.transform 11 512 env55188 = env55189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env55188 == env55189) = true)

theorem identity55189 : scanCanonicalize (H12AffineFastState.compose env55189 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55189 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55190 : List Nat := [2,4,8,16,32,16,9,36,1,37,2048,1,41,0,0,34,17,2048,37,1,17,32,16,2,40,16,2049,16,0,2048,4,33,36,32,1,0]

theorem envBound55190 : H12AffineFastState.Bounded env55190 := by
  intro p hp
  have h : env55190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55189_55190 : H12AffineEnvironment.transform 8 1 env55189 = env55190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55189 == env55190) = true)

theorem identity55190 : scanCanonicalize (H12AffineFastState.compose env55190 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55190 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55191 : List Nat := [2,4,8,0,32,0,9,36,1,37,2048,1,41,0,0,34,1,2048,37,1,1,32,0,2,40,0,2049,0,0,2048,4,33,36,32,1,0]

theorem envBound55191 : H12AffineFastState.Bounded env55191 := by
  intro p hp
  have h : env55191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55190_55191 : H12AffineEnvironment.transform 3 0 env55190 = env55191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55190 == env55191) = true)

theorem identity55191 : scanCanonicalize (H12AffineFastState.compose env55191 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55191 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55192 : List Nat := [2,4,8,0,32,0,9,36,1,37,32,1,41,0,0,34,1,32,37,1,1,32,0,2,40,0,33,0,0,32,4,33,36,32,1,0]

theorem envBound55192 : H12AffineFastState.Bounded env55192 := by
  intro p hp
  have h : env55192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55191_55192 : H12AffineEnvironment.transform 10 32 env55191 = env55192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55191 == env55192) = true)

theorem identity55192 : scanCanonicalize (H12AffineFastState.compose env55192 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55193 : List Nat := [2,4,8,0,0,0,9,4,1,5,0,1,9,0,0,2,1,0,5,1,1,0,0,2,8,0,1,0,0,0,4,1,4,0,1,0]

theorem envBound55193 : H12AffineFastState.Bounded env55193 := by
  intro p hp
  have h : env55193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55192_55193 : H12AffineEnvironment.transform 4 0 env55192 = env55193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55192 == env55193) = true)

def env55194 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56437,1024,32769,2097152,4194304,16,2199649,8193,64,6343701,5221,2118709,23669,2102368,4256861,116,21589,46093,2175563]

theorem envBound55194 : H12AffineFastState.Bounded env55194 := by
  intro p hp
  have h : env55194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55179_55194 : H12AffineEnvironment.transform 17 56437 env55179 = env55194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env55179 == env55194) = true)

def env55195 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56437,1024,32769,4160,4194304,16,98337,8193,64,4250709,5221,17525,23669,1056,4256861,116,21589,46093,74251]

theorem envBound55195 : H12AffineFastState.Bounded env55195 := by
  intro p hp
  have h : env55195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55194_55195 : H12AffineEnvironment.transform 20 4160 env55194 = env55195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55194 == env55195) = true)

theorem identity55195 : scanCanonicalize (H12AffineFastState.compose env55195 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55195 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55196 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,8202,16401,56437,1024,32769,4160,4194304,16,41003,8193,64,4250709,5221,17525,23669,1056,4256861,116,21589,46093,513]

theorem envBound55196 : H12AffineFastState.Bounded env55196 := by
  intro p hp
  have h : env55196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0