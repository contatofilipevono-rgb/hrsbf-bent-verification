import H12CloudChart0Data022

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound5693 : H12AffineFastState.Bounded env5693 := by
  intro p hp
  have h : env5693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5692_5693 : H12AffineEnvironment.transform 17 8713 env5692 = env5693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8713 env5692 == env5693) = true)

theorem identity5693 : scanCanonicalize (H12AffineFastState.compose env5693 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 3598) := by decide +kernel

theorem selectedBound5693 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5694 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,3598,8201,15909,4097,8713,1025,8201,4097,5156,5124,35,8224,5125,15398,3599,3599,5679,6670,7694,5,7694,1028,5636]

theorem envBound5694 : H12AffineFastState.Bounded env5694 := by
  intro p hp
  have h : env5694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5693_5694 : H12AffineEnvironment.transform 13 3598 env5693 = env5694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3598 env5693 == env5694) = true)

theorem identity5694 : scanCanonicalize (H12AffineFastState.compose env5694 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound5694 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5695 : List Nat := [2,4,8,0,32,1,41,4,512,1024,523,4096,8192,1029,8201,13358,4097,8713,1025,8201,4097,5156,5124,35,8224,5125,13869,1028,1028,5679,4101,5125,5,5125,1028,5636]

theorem envBound5695 : H12AffineFastState.Bounded env5695 := by
  intro p hp
  have h : env5695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5694_5695 : H12AffineEnvironment.transform 10 523 env5694 = env5695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env5694 == env5695) = true)

theorem identity5695 : scanCanonicalize (H12AffineFastState.compose env5695 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound5695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5696 : List Nat := [2,4,8,0,32,1,41,4,512,558,523,4096,8192,555,8201,12800,4097,8713,559,8201,4097,4618,4650,35,8224,4651,12291,554,554,4097,4101,4651,5,4651,554,4138]

theorem envBound5696 : H12AffineFastState.Bounded env5696 := by
  intro p hp
  have h : env5696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5695_5696 : H12AffineEnvironment.transform 9 558 env5695 = env5696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env5695 == env5696) = true)

theorem identity5696 : scanCanonicalize (H12AffineFastState.compose env5696 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4136) := by decide +kernel

theorem selectedBound5696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5697 : List Nat := [2,4,8,0,32,1,41,4,512,558,523,4096,4136,555,4129,552,4097,4641,559,4129,4097,4618,4650,35,4104,4651,43,554,554,4097,4101,4651,5,4651,554,4138]

theorem envBound5697 : H12AffineFastState.Bounded env5697 := by
  intro p hp
  have h : env5697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5696_5697 : H12AffineEnvironment.transform 12 4136 env5696 = env5697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4136 env5696 == env5697) = true)

theorem identity5697 : scanCanonicalize (H12AffineFastState.compose env5697 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound5697 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5698 : List Nat := [2,4,8,0,32,1,41,4,11,37,0,4096,4136,32,4129,35,4097,4138,36,4129,4097,4097,4129,35,4104,4128,43,33,33,4097,4101,4128,5,4128,33,4138]

theorem envBound5698 : H12AffineFastState.Bounded env5698 := by
  intro p hp
  have h : env5698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5697_5698 : H12AffineEnvironment.transform 8 11 env5697 = env5698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env5697 == env5698) = true)

theorem identity5698 : scanCanonicalize (H12AffineFastState.compose env5698 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound5698 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5699 : List Nat := [2,4,8,0,32,1,41,4,11,37,0,11,35,32,42,35,10,33,36,42,10,10,42,35,3,43,43,33,33,10,14,43,5,43,33,33]

theorem envBound5699 : H12AffineFastState.Bounded env5699 := by
  intro p hp
  have h : env5699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5698_5699 : H12AffineEnvironment.transform 11 11 env5698 = env5699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env5698 == env5699) = true)

def env5700 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,46212,8388608,41002,8329,8388609,323713,16385,16384,22561,62625,8406020,173,20480,1028,8389120]

theorem envBound5700 : H12AffineFastState.Bounded env5700 := by
  intro p hp
  have h : env5700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5688_5700 : H12AffineEnvironment.transform 3 1 env5688 = env5700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5688 == env5700) = true)

def env5701 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28714,4096,262144,1025,8352,4097,5156,8388608,138,8329,8388609,282657,16385,16384,22561,21505,8406020,173,20480,1028,8389120]

theorem envBound5701 : H12AffineFastState.Bounded env5701 := by
  intro p hp
  have h : env5701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5700_5701 : H12AffineEnvironment.transform 14 8352 env5700 = env5701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5700 == env5701) = true)

theorem identity5701 : scanCanonicalize (H12AffineFastState.compose env5701 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 284704) := by decide +kernel

theorem selectedBound5701 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5702 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28714,4096,262144,1025,8352,4097,5156,284704,138,8329,284705,282657,16385,16384,22561,21505,269348,173,20480,1028,285216]

theorem envBound5702 : H12AffineFastState.Bounded env5702 := by
  intro p hp
  have h : env5702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5701_5702 : H12AffineEnvironment.transform 22 284704 env5701 = env5702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284704 env5701 == env5702) = true)

theorem identity5702 : scanCanonicalize (H12AffineFastState.compose env5702 (packedSelected [2,3,5,9,10,13,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 680) := by decide +kernel

theorem selectedBound5702 : packedSelected [2,3,5,9,10,13,20,22] rootPS < 2^1333 := by decide +kernel

def env5703 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,680,8352,12930,4096,262144,1025,8352,4097,5156,268936,138,8329,268937,266889,681,680,6793,5801,269348,173,4776,1028,268424]

theorem envBound5703 : H12AffineFastState.Bounded env5703 := by
  intro p hp
  have h : env5703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5702_5703 : H12AffineEnvironment.transform 13 680 env5702 = env5703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 680 env5702 == env5703) = true)

theorem identity5703 : scanCanonicalize (H12AffineFastState.compose env5703 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(17+1) ^^^ 13350) := by decide +kernel

theorem selectedBound5703 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5704 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,680,8352,12930,4096,13350,1025,8352,4097,5156,11950,138,8329,11951,9903,681,680,6793,5801,10242,173,4776,1028,11438]

theorem envBound5704 : H12AffineFastState.Bounded env5704 := by
  intro p hp
  have h : env5704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5703_5704 : H12AffineEnvironment.transform 17 13350 env5703 = env5704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13350 env5703 == env5704) = true)

theorem identity5704 : scanCanonicalize (H12AffineFastState.compose env5704 (packedSelected [0,1,2,3,7,8,10,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 7342) := by decide +kernel

theorem selectedBound5704 : packedSelected [0,1,2,3,7,8,10,17,24] rootPS < 2^1333 := by decide +kernel

def env5705 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,7342,680,7182,3628,4096,2184,1025,7182,4097,5156,4608,138,7207,4609,6657,681,680,6793,5801,5292,173,4776,1028,4096]

theorem envBound5705 : H12AffineFastState.Bounded env5705 := by
  intro p hp
  have h : env5705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5704_5705 : H12AffineEnvironment.transform 12 7342 env5704 = env5705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7342 env5704 == env5705) = true)

theorem identity5705 : scanCanonicalize (H12AffineFastState.compose env5705 (packedSelected [2,6,13] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound5705 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env5706 : List Nat := [2,4,8,1,32,0,128,172,512,516,2048,4096,6826,680,6666,2088,4096,2184,517,6666,4097,4640,4608,138,6691,4609,6657,681,680,6793,4269,4776,173,4776,512,4096]

theorem envBound5706 : H12AffineFastState.Bounded env5706 := by
  intro p hp
  have h : env5706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5705_5706 : H12AffineEnvironment.transform 9 516 env5705 = env5706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env5705 == env5706) = true)

theorem identity5706 : scanCanonicalize (H12AffineFastState.compose env5706 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound5706 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5707 : List Nat := [2,4,8,1,32,0,128,172,512,516,2048,42,2688,680,2592,2088,42,2184,517,2592,43,522,554,138,2569,555,2603,681,680,2723,135,642,173,642,512,42]

theorem envBound5707 : H12AffineFastState.Bounded env5707 := by
  intro p hp
  have h : env5707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5706_5707 : H12AffineEnvironment.transform 11 42 env5706 = env5707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env5706 == env5707) = true)

theorem identity5707 : scanCanonicalize (H12AffineFastState.compose env5707 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound5707 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5708 : List Nat := [2,4,8,1,32,0,128,172,512,516,554,42,170,680,10,514,42,674,517,10,43,522,554,138,35,555,1,681,680,137,135,642,173,642,512,42]

theorem envBound5708 : H12AffineFastState.Bounded env5708 := by
  intro p hp
  have h : env5708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5707_5708 : H12AffineEnvironment.transform 10 554 env5707 = env5708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env5707 == env5708) = true)

theorem identity5708 : scanCanonicalize (H12AffineFastState.compose env5708 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound5708 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5709 : List Nat := [2,4,8,1,32,0,128,172,10,14,32,42,170,162,10,8,42,168,15,10,43,0,32,138,35,33,1,163,162,137,135,136,173,136,10,42]

theorem envBound5709 : H12AffineFastState.Bounded env5709 := by
  intro p hp
  have h : env5709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5708_5709 : H12AffineEnvironment.transform 8 10 env5708 = env5709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env5708 == env5709) = true)

def env5710 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28715,4096,262144,1025,8353,4097,5157,8388608,139,8329,8388609,282656,16385,16384,22561,21504,8406020,173,20480,1028,8389120]

theorem envBound5710 : H12AffineFastState.Bounded env5710 := by
  intro p hp
  have h : env5710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5700_5710 : H12AffineEnvironment.transform 14 8353 env5700 = env5710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5700 == env5710) = true)

theorem identity5710 : scanCanonicalize (H12AffineFastState.compose env5710 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 7309) := by decide +kernel

theorem selectedBound5710 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5711 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28715,4096,7309,1025,8353,4097,5157,8388608,139,8329,8388609,19629,16385,16384,22561,21504,8406020,173,20480,1028,8389120]

theorem envBound5711 : H12AffineFastState.Bounded env5711 := by
  intro p hp
  have h : env5711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5710_5711 : H12AffineEnvironment.transform 17 7309 env5710 = env5711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7309 env5710 == env5711) = true)

theorem identity5711 : scanCanonicalize (H12AffineFastState.compose env5711 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(22+1) ^^^ 6306) := by decide +kernel

theorem selectedBound5711 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5712 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28715,4096,7309,1025,8353,4097,5157,6306,139,8329,6307,19629,16385,16384,22561,21504,23718,173,20480,1028,6818]

theorem envBound5712 : H12AffineFastState.Bounded env5712 := by
  intro p hp
  have h : env5712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5711_5712 : H12AffineEnvironment.transform 22 6306 env5711 = env5712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6306 env5711 == env5712) = true)

theorem identity5712 : scanCanonicalize (H12AffineFastState.compose env5712 (packedSelected [1,3,4,8,10,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 7814) := by decide +kernel

theorem selectedBound5712 : packedSelected [1,3,4,8,10,20,22,24] rootPS < 2^1333 := by decide +kernel

def env5713 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,7814,8353,11949,4096,7309,1025,8353,4097,5157,6306,139,8329,6307,4651,7815,7814,1703,2694,544,173,3718,1028,6818]

theorem envBound5713 : H12AffineFastState.Bounded env5713 := by
  intro p hp
  have h : env5713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5712_5713 : H12AffineEnvironment.transform 13 7814 env5712 = env5713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7814 env5712 == env5713) = true)

theorem identity5713 : scanCanonicalize (H12AffineFastState.compose env5713 (packedSelected [0,1,2,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound5713 : packedSelected [0,1,2,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env5714 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,2602,8353,11949,1196,2081,1025,8353,1197,137,3086,139,8329,3087,1671,2603,2602,1703,2694,544,173,3718,1028,3598]

theorem envBound5714 : H12AffineFastState.Bounded env5714 := by
  intro p hp
  have h : env5714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5713_5714 : H12AffineEnvironment.transform 11 1196 env5713 = env5714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env5713 == env5714) = true)

def env5715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,134217728,76039249,76039597,134523040,75572347,147588588,525568,134520961,82355408,8914925]

theorem envBound5715 : H12AffineFastState.Bounded env5715 := by
  intro p hp
  have h : env5715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4827_5715 : H12AffineEnvironment.transform 27 76039249 env4827 = env5715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 76039249 env4827 == env5715) = true)

def env5716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,77914240,76039249,76039597,77613088,75572347,73983340,525568,77611009,82355408,8914925]

theorem envBound5716 : H12AffineFastState.Bounded env5716 := by
  intro p hp
  have h : env5716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5715_5716 : H12AffineEnvironment.transform 26 77914240 env5715 = env5716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914240 env5715 == env5716) = true)

def env5717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914000,2942160,16385,16893,2641008,598059,14737724,525568,2638929,6332544,8914925]

theorem envBound5717 : H12AffineFastState.Bounded env5717 := by
  intro p hp
  have h : env5717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5716_5717 : H12AffineEnvironment.transform 25 8914000 env5716 = env5717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env5716 == env5717) = true)

def env5718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849104,16385,16893,547952,598059,12644668,525568,545873,4239488,8914925]

theorem envBound5718 : H12AffineFastState.Bounded env5718 := by
  intro p hp
  have h : env5718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5717_5718 : H12AffineEnvironment.transform 20 4096 env5717 = env5718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5717 == env5718) = true)

def env5719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323792,16385,16893,22640,74795,12644668,256,20561,4239488,8389613]

theorem envBound5719 : H12AffineFastState.Bounded env5719 := by
  intro p hp
  have h : env5719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5718_5719 : H12AffineEnvironment.transform 18 1024 env5718 = env5719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5718 == env5719) = true)

theorem identity5719 : scanCanonicalize (H12AffineFastState.compose env5719 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound5719 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,25914,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323792,16385,16893,22640,16657,12644668,256,20561,4239488,8389613]

theorem envBound5720 : H12AffineFastState.Bounded env5720 := by
  intro p hp
  have h : env5720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5719_5720 : H12AffineEnvironment.transform 15 25914 env5719 = env5720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env5719 == env5720) = true)

def env5721 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4096,4194304,8388608,41002,8329,8388608,323712,16385,16813,22560,16657,12644668,256,20481,4239488,8389565]

theorem envBound5721 : H12AffineFastState.Bounded env5721 := by
  intro p hp
  have h : env5721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5720_5721 : H12AffineEnvironment.transform 5 16 env5720 = env5721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5720 == env5721) = true)

def env5722 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4096,4194304,4240784,41002,8329,4240784,323712,16385,16813,22560,16657,17580,256,20481,4239488,4240941]

theorem envBound5722 : H12AffineFastState.Bounded env5722 := by
  intro p hp
  have h : env5722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5721_5722 : H12AffineEnvironment.transform 22 4240784 env5721 = env5722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240784 env5721 == env5722) = true)

theorem identity5722 : scanCanonicalize (H12AffineFastState.compose env5722 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound5722 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5723 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13340,25914,4525,262144,1024,13340,4096,4194304,4194700,5174,8329,4194700,279708,16385,16813,22560,16657,17580,256,20481,4195484,4194865]

theorem envBound5723 : H12AffineFastState.Bounded env5723 := by
  intro p hp
  have h : env5723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5722_5723 : H12AffineEnvironment.transform 14 13340 env5722 = env5723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env5722 == env5723) = true)

def env5724 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1280,8192,16384,8476,25914,1197,262144,1024,8476,1280,4194304,4194700,310,8329,4194700,279708,16385,16813,19744,16657,17580,256,17665,4195484,4194865]

theorem envBound5724 : H12AffineFastState.Bounded env5724 := by
  intro p hp
  have h : env5724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5723_5724 : H12AffineEnvironment.transform 11 1280 env5723 = env5724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env5723 == env5724) = true)

theorem identity5724 : scanCanonicalize (H12AffineFastState.compose env5724 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5724 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5725 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1197,8192,16384,8369,25751,1197,262144,1024,8369,1197,4194304,4194337,155,8329,4194337,279708,16385,16384,19597,16572,17580,173,17580,4195484,4194865]

theorem envBound5725 : H12AffineFastState.Bounded env5725 := by
  intro p hp
  have h : env5725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5724_5725 : H12AffineEnvironment.transform 7 173 env5724 = env5725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5724 == env5725) = true)

theorem identity5725 : scanCanonicalize (H12AffineFastState.compose env5725 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5725 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5726 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,16384,8216,25662,1028,262144,1024,8216,1028,4194304,4194337,50,8224,4194337,279605,16385,16384,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound5726 : H12AffineFastState.Bounded env5726 := by
  intro p hp
  have h : env5726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5725_5726 : H12AffineEnvironment.transform 6 41 env5725 = env5726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5725 == env5726) = true)

theorem identity5726 : scanCanonicalize (H12AffineFastState.compose env5726 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound5726 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5727 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,16384,8216,25662,1028,19508,1024,8216,1028,4194304,4194337,50,8224,4194337,2049,16385,16384,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound5727 : H12AffineFastState.Bounded env5727 := by
  intro p hp
  have h : env5727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5726_5727 : H12AffineEnvironment.transform 17 19508 env5726 = env5727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env5726 == env5727) = true)

theorem identity5727 : scanCanonicalize (H12AffineFastState.compose env5727 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 24601) := by decide +kernel

theorem selectedBound5727 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env5728 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,16384,8216,25662,1028,19508,1024,8216,1028,24601,24632,50,8224,24632,2049,16385,16384,19492,16405,17413,4,17413,25644,25128]

theorem envBound5728 : H12AffineFastState.Bounded env5728 := by
  intro p hp
  have h : env5728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5727_5728 : H12AffineEnvironment.transform 21 24601 env5727 = env5728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 24601 env5727 == env5728) = true)

theorem identity5728 : scanCanonicalize (H12AffineFastState.compose env5728 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(13+1) ^^^ 8738) := by decide +kernel

theorem selectedBound5728 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env5729 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,8738,8216,1564,1028,11798,1024,8216,1028,571,538,50,8224,538,2049,8739,8738,11782,8759,9767,4,9767,1550,10]

theorem envBound5729 : H12AffineFastState.Bounded env5729 := by
  intro p hp
  have h : env5729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5728_5729 : H12AffineEnvironment.transform 13 8738 env5728 = env5729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8738 env5728 == env5729) = true)

theorem identity5729 : scanCanonicalize (H12AffineFastState.compose env5729 (packedSelected [0,2,3,4,5,6,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 1575) := by decide +kernel

theorem selectedBound5729 : packedSelected [0,2,3,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env5730 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,1575,1029,1599,1564,1028,2097,1024,1599,1028,571,538,50,1543,538,2049,1028,1029,2081,1040,0,4,0,1550,10]

theorem envBound5730 : H12AffineFastState.Bounded env5730 := by
  intro p hp
  have h : env5730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5729_5730 : H12AffineEnvironment.transform 12 1575 env5729 = env5730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1575 env5729 == env5730) = true)

theorem identity5730 : scanCanonicalize (H12AffineFastState.compose env5730 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5730 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5731 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1540,1028,1575,1029,1599,1564,1028,1589,1024,1599,1028,571,538,50,1543,538,1541,1028,1029,1573,1040,0,4,0,1550,10]

theorem envBound5731 : H12AffineFastState.Bounded env5731 := by
  intro p hp
  have h : env5731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5730_5731 : H12AffineEnvironment.transform 10 1540 env5730 = env5731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env5730 == env5731) = true)

theorem identity5731 : scanCanonicalize (H12AffineFastState.compose env5731 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5731 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5732 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1060,1028,1031,1029,1055,1084,1028,1045,1024,1055,1028,27,58,50,1063,58,1061,1028,1029,1029,1040,0,4,0,1070,10]

theorem envBound5732 : H12AffineFastState.Bounded env5732 := by
  intro p hp
  have h : env5732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5731_5732 : H12AffineEnvironment.transform 8 32 env5731 = env5732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5731 == env5732) = true)

theorem identity5732 : scanCanonicalize (H12AffineFastState.compose env5732 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5732 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5733 : List Nat := [2,4,8,0,32,0,41,4,32,1024,1060,1028,1031,1029,1039,1068,1028,1029,1024,1039,1028,11,42,34,1063,42,1061,1028,1029,1029,1024,0,4,0,1070,10]

theorem envBound5733 : H12AffineFastState.Bounded env5733 := by
  intro p hp
  have h : env5733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5732_5733 : H12AffineEnvironment.transform 3 0 env5732 = env5733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5732 == env5733) = true)

theorem identity5733 : scanCanonicalize (H12AffineFastState.compose env5733 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5734 : List Nat := [2,4,8,0,32,0,41,4,32,36,0,32,35,33,43,8,32,33,36,43,32,11,42,34,3,42,1,32,33,33,36,0,4,0,10,10]

theorem envBound5734 : H12AffineFastState.Bounded env5734 := by
  intro p hp
  have h : env5734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5733_5734 : H12AffineEnvironment.transform 9 36 env5733 = env5734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5733 == env5734) = true)

theorem identity5734 : scanCanonicalize (H12AffineFastState.compose env5734 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5734 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5735 : List Nat := [2,4,8,0,10,0,3,4,10,14,0,10,9,11,1,8,10,11,14,1,10,11,0,8,3,0,1,10,11,11,14,0,4,0,10,10]

theorem envBound5735 : H12AffineFastState.Bounded env5735 := by
  intro p hp
  have h : env5735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5734_5735 : H12AffineEnvironment.transform 4 10 env5734 = env5735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5734 == env5735) = true)

theorem identity5735 : scanCanonicalize (H12AffineFastState.compose env5735 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5736 : List Nat := [2,4,3,0,1,0,3,4,1,5,0,1,2,0,1,3,1,0,5,1,1,0,0,3,3,0,1,1,0,0,5,0,4,0,1,1]

theorem envBound5736 : H12AffineFastState.Bounded env5736 := by
  intro p hp
  have h : env5736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5735_5736 : H12AffineEnvironment.transform 2 3 env5735 = env5736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5735 == env5736) = true)

def env5737 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1281,8192,16384,8477,25914,1196,262144,1024,8477,1281,4194304,4194700,311,8329,4194700,279708,16385,16813,19745,16657,17580,256,17664,4195484,4194865]

theorem envBound5737 : H12AffineFastState.Bounded env5737 := by
  intro p hp
  have h : env5737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5723_5737 : H12AffineEnvironment.transform 11 1281 env5723 = env5737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env5723 == env5737) = true)

theorem identity5737 : scanCanonicalize (H12AffineFastState.compose env5737 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2460) := by decide +kernel

theorem selectedBound5737 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env5738 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1281,8192,16384,8477,25914,1196,2460,1024,8477,1281,4194304,4194700,311,8329,4194700,19712,16385,16813,19745,16657,17580,256,17664,4195484,4194865]

theorem envBound5738 : H12AffineFastState.Bounded env5738 := by
  intro p hp
  have h : env5738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5737_5738 : H12AffineEnvironment.transform 17 2460 env5737 = env5738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2460 env5737 == env5738) = true)

theorem identity5738 : scanCanonicalize (H12AffineFastState.compose env5738 (packedSelected [0,4,7,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5738 : packedSelected [0,4,7,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5739 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,8192,16384,8477,25914,1029,2357,1024,8477,1281,4194304,4194597,311,8224,4194597,19712,16385,16644,19745,16657,17413,256,17664,4195381,4194865]

theorem envBound5739 : H12AffineFastState.Bounded env5739 := by
  intro p hp
  have h : env5739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5738_5739 : H12AffineEnvironment.transform 6 41 env5738 = env5739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5738 == env5739) = true)

theorem identity5739 : scanCanonicalize (H12AffineFastState.compose env5739 (packedSelected [2,6,7,9,10,11,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 17712) := by decide +kernel

theorem selectedBound5739 : packedSelected [2,6,7,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env5740 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,8192,16384,8477,25914,1029,2357,1024,8477,1281,17712,17429,311,8224,17429,19712,16385,16644,19745,16657,17413,256,17664,16645,18177]

theorem envBound5740 : H12AffineFastState.Bounded env5740 := by
  intro p hp
  have h : env5740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5739_5740 : H12AffineEnvironment.transform 21 17712 env5739 = env5740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17712 env5739 == env5740) = true)

theorem identity5740 : scanCanonicalize (H12AffineFastState.compose env5740 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1816) := by decide +kernel

theorem selectedBound5740 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env5741 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,1816,16384,1541,16930,1029,2357,1024,1541,1281,17712,17429,311,1848,17429,19712,16385,16644,19745,16657,17413,256,17664,16645,18177]

theorem envBound5741 : H12AffineFastState.Bounded env5741 := by
  intro p hp
  have h : env5741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5740_5741 : H12AffineEnvironment.transform 12 1816 env5740 = env5741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1816 env5740 == env5741) = true)

theorem identity5741 : scanCanonicalize (H12AffineFastState.compose env5741 (packedSelected [1,3,6,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 1819) := by decide +kernel

theorem selectedBound5741 : packedSelected [1,3,6,10,12] rootPS < 2^1333 := by decide +kernel

def env5742 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,1816,1819,1541,1337,1029,2357,1024,1541,1281,555,782,311,1848,782,2587,1818,1567,2618,1546,798,256,539,1566,26]

theorem envBound5742 : H12AffineFastState.Bounded env5742 := by
  intro p hp
  have h : env5742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5741_5742 : H12AffineEnvironment.transform 13 1819 env5741 = env5742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1819 env5741 == env5742) = true)

theorem identity5742 : scanCanonicalize (H12AffineFastState.compose env5742 (packedSelected [0,1,2,5,9,10,17] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5742 : packedSelected [0,1,2,5,9,10,17] rootPS < 2^1333 := by decide +kernel

def env5743 : List Nat := [2,4,8,16,27,16,18,256,512,1024,2048,1281,1816,1819,1541,1282,1029,2318,1024,1541,1281,528,782,268,1795,782,2587,1818,1567,2561,1546,798,256,539,1566,26]

theorem envBound5743 : H12AffineFastState.Bounded env5743 := by
  intro p hp
  have h : env5743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5742_5743 : H12AffineEnvironment.transform 4 27 env5742 = env5743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5742 == env5743) = true)

theorem identity5743 : scanCanonicalize (H12AffineFastState.compose env5743 (packedSelected [2,3,8,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound5743 : packedSelected [2,3,8,10,20] rootPS < 2^1333 := by decide +kernel

def env5744 : List Nat := [2,4,8,16,27,16,18,20,512,1024,2048,1045,1548,1551,1541,1046,1029,2074,1024,1541,1045,528,538,24,1559,538,2587,1550,1567,2561,1546,522,20,539,1566,26]

theorem envBound5744 : H12AffineFastState.Bounded env5744 := by
  intro p hp
  have h : env5744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5743_5744 : H12AffineEnvironment.transform 7 20 env5743 = env5744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env5743 == env5744) = true)

theorem identity5744 : scanCanonicalize (H12AffineFastState.compose env5744 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5745 : List Nat := [2,4,8,16,27,16,18,20,512,1024,1038,1045,1548,1551,1541,1046,1029,1044,1024,1541,1045,528,538,24,1559,538,1557,1550,1567,1551,1546,522,20,539,1566,26]

theorem envBound5745 : H12AffineFastState.Bounded env5745 := by
  intro p hp
  have h : env5745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5744_5745 : H12AffineEnvironment.transform 10 1038 env5744 = env5745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env5744 == env5745) = true)

theorem identity5745 : scanCanonicalize (H12AffineFastState.compose env5745 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5745 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env5746 : List Nat := [2,4,8,16,27,16,18,20,0,1024,1038,1045,1036,1039,1029,1046,1029,1044,1024,1029,1045,16,26,24,1047,26,1045,1038,1055,1039,1034,10,20,27,1054,26]

theorem envBound5746 : H12AffineFastState.Bounded env5746 := by
  intro p hp
  have h : env5746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5745_5746 : H12AffineEnvironment.transform 8 0 env5745 = env5746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5745 == env5746) = true)

def env5747 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4096,4194304,4240785,41002,8329,4240785,323712,16385,16813,22560,16657,17581,256,20481,4239488,4240940]

theorem envBound5747 : H12AffineFastState.Bounded env5747 := by
  intro p hp
  have h : env5747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5721_5747 : H12AffineEnvironment.transform 22 4240785 env5721 = env5747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240785 env5721 == env5747) = true)

theorem identity5747 : scanCanonicalize (H12AffineFastState.compose env5747 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13729) := by decide +kernel

theorem selectedBound5747 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5748 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13729,25914,4525,262144,1024,13729,4096,4194304,4194352,5515,8329,4194352,279841,16385,16813,22560,16657,17581,256,20481,4195617,4195213]

theorem envBound5748 : H12AffineFastState.Bounded env5748 := by
  intro p hp
  have h : env5748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5747_5748 : H12AffineEnvironment.transform 14 13729 env5747 = env5748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13729 env5747 == env5748) = true)

def env5749 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,4096,8192,16384,13729,25898,4525,262144,1024,13729,4096,4194304,4194336,5515,8329,4194336,279841,16385,16813,22560,16641,17581,256,20481,4195617,4195213]

theorem envBound5749 : H12AffineFastState.Bounded env5749 := by
  intro p hp
  have h : env5749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5748_5749 : H12AffineEnvironment.transform 3 0 env5748 = env5749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5748 == env5749) = true)

def env5750 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1280,8192,16384,8353,25898,1197,262144,1024,8353,1280,4194304,4194336,139,8329,4194336,279841,16385,16813,19744,16641,17581,256,17665,4195617,4195213]

theorem envBound5750 : H12AffineFastState.Bounded env5750 := by
  intro p hp
  have h : env5750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5749_5750 : H12AffineEnvironment.transform 11 1280 env5749 = env5750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env5749 == env5750) = true)

theorem identity5750 : scanCanonicalize (H12AffineFastState.compose env5750 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 264453) := by decide +kernel

theorem selectedBound5750 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5751 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1280,8192,16384,8353,25898,1197,262144,1024,8353,1280,264453,264485,139,8329,264485,279841,16385,16813,19744,16641,17581,256,17665,265252,264840]

theorem envBound5751 : H12AffineFastState.Bounded env5751 := by
  intro p hp
  have h : env5751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5750_5751 : H12AffineEnvironment.transform 21 264453 env5750 = env5751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264453 env5750 == env5751) = true)

theorem identity5751 : scanCanonicalize (H12AffineFastState.compose env5751 (packedSelected [0,6,7,9,11,17,20,22,23] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5751 : packedSelected [0,6,7,9,11,17,20,22,23] rootPS < 2^1333 := by decide +kernel

def env5752 : List Nat := [2,4,8,0,32,0,128,256,512,1024,1038,1280,8192,16384,8353,25898,1197,262144,1024,8353,1280,263435,263467,139,8329,263467,279841,16385,16813,16686,16641,17581,256,17665,262186,263814]

theorem envBound5752 : H12AffineFastState.Bounded env5752 := by
  intro p hp
  have h : env5752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5751_5752 : H12AffineEnvironment.transform 10 1038 env5751 = env5752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env5751 == env5752) = true)

theorem identity5752 : scanCanonicalize (H12AffineFastState.compose env5752 (packedSelected [1,3,4,8,10,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 1928) := by decide +kernel

theorem selectedBound5752 : packedSelected [1,3,4,8,10,20,22,24] rootPS < 2^1333 := by decide +kernel

def env5753 : List Nat := [2,4,8,0,32,0,128,256,512,1024,1038,1280,8192,1928,8353,8866,1197,262144,1024,8353,1280,263435,263467,139,8329,263467,262825,1929,1573,1702,1673,805,256,649,262186,263814]

theorem envBound5753 : H12AffineFastState.Bounded env5753 := by
  intro p hp
  have h : env5753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5752_5753 : H12AffineEnvironment.transform 13 1928 env5752 = env5753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1928 env5752 == env5753) = true)

theorem identity5753 : scanCanonicalize (H12AffineFastState.compose env5753 (packedSelected [0,1,2,4,5,6,7,9,10,12,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 1322) := by decide +kernel

theorem selectedBound5753 : packedSelected [0,1,2,4,5,6,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env5754 : List Nat := [2,4,8,0,32,0,128,256,512,1024,1038,1280,8192,1928,8353,8866,1197,1322,1024,8353,1280,33,1,139,8329,1,1923,1929,1573,1702,1673,805,256,649,1280,940]

theorem envBound5754 : H12AffineFastState.Bounded env5754 := by
  intro p hp
  have h : env5754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5753_5754 : H12AffineEnvironment.transform 17 1322 env5753 = env5754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1322 env5753 == env5754) = true)

theorem identity5754 : scanCanonicalize (H12AffineFastState.compose env5754 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound5754 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5755 : List Nat := [2,4,8,0,32,0,128,256,396,1024,1038,1280,8192,1028,8353,8494,1197,1322,1024,8353,1280,33,1,139,8329,1,1039,1029,1449,1322,1285,169,256,261,1280,32]

theorem envBound5755 : H12AffineFastState.Bounded env5755 := by
  intro p hp
  have h : env5755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5754_5755 : H12AffineEnvironment.transform 8 396 env5754 = env5755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env5754 == env5755) = true)

theorem identity5755 : scanCanonicalize (H12AffineFastState.compose env5755 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound5755 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env5756 : List Nat := [2,4,8,0,32,0,8,256,260,1024,1038,1280,8192,1028,8233,8494,1061,1322,1024,8233,1280,33,1,3,8193,1,1039,1029,1313,1322,1285,33,256,261,1280,32]

theorem envBound5756 : H12AffineFastState.Bounded env5756 := by
  intro p hp
  have h : env5756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5755_5756 : H12AffineEnvironment.transform 6 8 env5755 = env5756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env5755 == env5756) = true)

theorem identity5756 : scanCanonicalize (H12AffineFastState.compose env5756 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5756 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env5757 : List Nat := [2,4,8,0,32,0,8,256,260,1024,1038,1280,1062,1028,1039,1288,1061,1322,1024,1039,1280,33,1,3,1063,1,1039,1029,1313,1322,1285,33,256,261,1280,32]

theorem envBound5757 : H12AffineFastState.Bounded env5757 := by
  intro p hp
  have h : env5757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5756_5757 : H12AffineEnvironment.transform 12 1062 env5756 = env5757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5756 == env5757) = true)

theorem identity5757 : scanCanonicalize (H12AffineFastState.compose env5757 (packedSelected [0,2,6] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound5757 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env5758 : List Nat := [2,4,8,0,32,0,8,256,260,266,260,10,300,270,261,2,303,32,266,261,10,33,1,3,301,1,261,271,43,32,15,33,256,261,10,32]

theorem envBound5758 : H12AffineFastState.Bounded env5758 := by
  intro p hp
  have h : env5758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5757_5758 : H12AffineEnvironment.transform 9 266 env5757 = env5758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env5757 == env5758) = true)

theorem identity5758 : scanCanonicalize (H12AffineFastState.compose env5758 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5758 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env5759 : List Nat := [2,4,8,0,32,0,8,5,1,15,1,10,41,11,0,2,42,32,15,0,10,33,1,3,40,1,0,10,43,32,15,33,5,0,10,32]

theorem envBound5759 : H12AffineFastState.Bounded env5759 := by
  intro p hp
  have h : env5759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5758_5759 : H12AffineEnvironment.transform 7 5 env5758 = env5759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5758 == env5759) = true)

theorem identity5759 : scanCanonicalize (H12AffineFastState.compose env5759 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5759 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5760 : List Nat := [2,4,8,0,11,0,8,5,1,15,1,10,2,11,0,2,1,11,15,0,10,10,1,3,3,1,0,10,0,11,15,10,5,0,10,11]

theorem envBound5760 : H12AffineFastState.Bounded env5760 := by
  intro p hp
  have h : env5760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5759_5760 : H12AffineEnvironment.transform 4 11 env5759 = env5760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5759 == env5760) = true)

theorem identity5760 : scanCanonicalize (H12AffineFastState.compose env5760 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5760 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5761 : List Nat := [2,4,2,0,1,0,2,5,1,5,1,0,2,1,0,2,1,1,5,0,0,0,1,3,3,1,0,0,0,1,5,0,5,0,0,1]

theorem envBound5761 : H12AffineFastState.Bounded env5761 := by
  intro p hp
  have h : env5761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5760_5761 : H12AffineEnvironment.transform 2 2 env5760 = env5761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5760 == env5761) = true)

def env5762 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,16384,8352,25898,1196,262144,1024,8352,1281,4194304,4194336,138,8329,4194336,279841,16385,16813,19745,16641,17581,256,17664,4195617,4195213]

theorem envBound5762 : H12AffineFastState.Bounded env5762 := by
  intro p hp
  have h : env5762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5749_5762 : H12AffineEnvironment.transform 11 1281 env5749 = env5762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env5749 == env5762) = true)

theorem identity5762 : scanCanonicalize (H12AffineFastState.compose env5762 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 281856) := by decide +kernel

theorem selectedBound5762 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5763 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,16384,8352,25898,1196,262144,1024,8352,1281,281856,281888,138,8329,281888,279841,16385,16813,19745,16641,17581,256,17664,280609,282253]

theorem envBound5763 : H12AffineFastState.Bounded env5763 := by
  intro p hp
  have h : env5763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5762_5763 : H12AffineEnvironment.transform 21 281856 env5762 = env5763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281856 env5762 == env5763) = true)

theorem identity5763 : scanCanonicalize (H12AffineFastState.compose env5763 (packedSelected [0,6,7,9,11,13,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 11522) := by decide +kernel

theorem selectedBound5763 : packedSelected [0,6,7,9,11,13,20,22,23] rootPS < 2^1333 := by decide +kernel

def env5764 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,11522,8352,2088,1196,262144,1024,8352,1281,270338,270370,138,8329,270370,272419,11523,11439,8227,11267,10671,256,10242,271651,271247]

theorem envBound5764 : H12AffineFastState.Bounded env5764 := by
  intro p hp
  have h : env5764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5763_5764 : H12AffineEnvironment.transform 13 11522 env5763 = env5764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11522 env5763 == env5764) = true)

theorem identity5764 : scanCanonicalize (H12AffineFastState.compose env5764 (packedSelected [0,1,4,5,7,8,13,17,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound5764 : packedSelected [0,1,4,5,7,8,13,17,22,24] rootPS < 2^1333 := by decide +kernel

def env5765 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,11522,8352,2088,1196,2184,1024,8352,1281,10378,10410,138,8329,10410,8363,11523,11439,8227,11267,10671,256,10242,11691,11015]

theorem envBound5765 : H12AffineFastState.Bounded env5765 := by
  intro p hp
  have h : env5765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5764_5765 : H12AffineEnvironment.transform 17 2184 env5764 = env5765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env5764 == env5765) = true)

theorem identity5765 : scanCanonicalize (H12AffineFastState.compose env5765 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5765 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5766 : List Nat := [2,4,8,0,32,0,128,256,33,1024,2048,1281,8192,11522,8352,2088,1196,2184,1024,8352,1281,10378,10410,138,8329,10410,8363,11523,11439,8227,11267,10671,256,10242,11691,10534]

theorem envBound5766 : H12AffineFastState.Bounded env5766 := by
  intro p hp
  have h : env5766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5765_5766 : H12AffineEnvironment.transform 8 33 env5765 = env5766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5765 == env5766) = true)

theorem identity5766 : scanCanonicalize (H12AffineFastState.compose env5766 (packedSelected [3,5,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 386) := by decide +kernel

theorem selectedBound5766 : packedSelected [3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env5767 : List Nat := [2,4,8,0,32,0,128,256,33,386,2048,131,8192,10368,8352,2088,302,2184,386,8352,131,10378,10410,138,8329,10410,8363,10369,10541,8227,10625,10671,256,10242,10281,10534]

theorem envBound5767 : H12AffineFastState.Bounded env5767 := by
  intro p hp
  have h : env5767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5766_5767 : H12AffineEnvironment.transform 9 386 env5766 = env5767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 386 env5766 == env5767) = true)

theorem identity5767 : scanCanonicalize (H12AffineFastState.compose env5767 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 34) := by decide +kernel

theorem selectedBound5767 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env5768 : List Nat := [2,4,8,0,32,0,128,256,33,386,2048,131,34,2210,130,2088,302,2184,386,130,131,2216,2184,138,171,2184,137,2211,2319,1,2467,2445,256,2080,2059,2308]

theorem envBound5768 : H12AffineFastState.Bounded env5768 := by
  intro p hp
  have h : env5768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5767_5768 : H12AffineEnvironment.transform 12 34 env5767 = env5768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 34 env5767 == env5768) = true)

theorem identity5768 : scanCanonicalize (H12AffineFastState.compose env5768 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound5768 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env5769 : List Nat := [2,4,8,0,32,0,128,14,33,140,2048,131,34,2210,130,2088,32,2184,140,130,131,2216,2184,138,171,2184,137,2211,2049,1,2221,2179,14,2080,2059,2058]

theorem envBound5769 : H12AffineFastState.Bounded env5769 := by
  intro p hp
  have h : env5769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5768_5769 : H12AffineEnvironment.transform 7 14 env5768 = env5769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env5768 == env5769) = true)

theorem identity5769 : scanCanonicalize (H12AffineFastState.compose env5769 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound5769 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env5770 : List Nat := [2,4,8,0,32,0,2,14,33,14,2048,1,34,2080,0,2088,32,2058,14,0,1,2090,2058,8,41,2058,11,2081,2049,1,2095,2049,14,2080,2059,2058]

theorem envBound5770 : H12AffineFastState.Bounded env5770 := by
  intro p hp
  have h : env5770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5769_5770 : H12AffineEnvironment.transform 6 2 env5769 = env5770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env5769 == env5770) = true)

theorem identity5770 : scanCanonicalize (H12AffineFastState.compose env5770 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5770 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5771 : List Nat := [2,4,8,0,10,0,2,14,11,14,2048,1,8,2058,0,2050,10,2058,14,0,1,2048,2058,8,3,2058,11,2059,2049,1,2053,2049,14,2058,2059,2058]

theorem envBound5771 : H12AffineFastState.Bounded env5771 := by
  intro p hp
  have h : env5771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5770_5771 : H12AffineEnvironment.transform 4 10 env5770 = env5771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5770 == env5771) = true)

theorem identity5771 : scanCanonicalize (H12AffineFastState.compose env5771 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound5771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5772 : List Nat := [2,4,8,0,10,0,2,14,11,14,0,1,8,10,0,2,10,10,14,0,1,0,10,8,3,10,11,11,1,1,5,1,14,10,11,10]

theorem envBound5772 : H12AffineFastState.Bounded env5772 := by
  intro p hp
  have h : env5772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5771_5772 : H12AffineEnvironment.transform 10 0 env5771 = env5772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env5771 == env5772) = true)

theorem identity5772 : scanCanonicalize (H12AffineFastState.compose env5772 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5773 : List Nat := [2,4,7,0,5,0,2,1,4,1,0,1,7,5,0,2,5,5,1,0,1,0,5,7,3,5,4,4,1,1,5,1,1,5,4,5]

theorem envBound5773 : H12AffineFastState.Bounded env5773 := by
  intro p hp
  have h : env5773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5772_5773 : H12AffineEnvironment.transform 2 7 env5772 = env5773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5772 == env5773) = true)

def env5774 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,4096,8192,16384,13729,25899,4525,262144,1024,13729,4096,4194304,4194337,5515,8329,4194337,279841,16385,16813,22560,16640,17581,256,20481,4195617,4195213]

theorem envBound5774 : H12AffineFastState.Bounded env5774 := by
  intro p hp
  have h : env5774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5748_5774 : H12AffineEnvironment.transform 3 1 env5748 = env5774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5748 == env5774) = true)

theorem identity5774 : scanCanonicalize (H12AffineFastState.compose env5774 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound5774 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5775 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1196,8192,16384,8461,25899,1281,262144,1024,8461,1196,4194304,4194337,295,8329,4194337,279841,16385,16813,19596,16640,17581,256,17581,4195617,4195213]

theorem envBound5775 : H12AffineFastState.Bounded env5775 := by
  intro p hp
  have h : env5775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5774_5775 : H12AffineEnvironment.transform 11 1196 env5774 = env5775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env5774 == env5775) = true)

theorem identity5775 : scanCanonicalize (H12AffineFastState.compose env5775 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5775 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5776 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,8201,25647,1029,262144,1024,8201,1196,4194304,4194337,35,8329,4194337,279589,16385,16553,19596,16388,17581,4,17581,4195365,4194953]

theorem envBound5776 : H12AffineFastState.Bounded env5776 := by
  intro p hp
  have h : env5776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5775_5776 : H12AffineEnvironment.transform 7 4 env5775 = env5776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5775 == env5776) = true)

theorem identity5776 : scanCanonicalize (H12AffineFastState.compose env5776 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound5776 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5777 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,8201,25647,1029,2185,1024,8201,1196,4194304,4194337,35,8329,4194337,19628,16385,16553,19596,16388,17581,4,17581,4195365,4194953]

theorem envBound5777 : H12AffineFastState.Bounded env5777 := by
  intro p hp
  have h : env5777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5776_5777 : H12AffineEnvironment.transform 17 2185 env5776 = env5777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env5776 == env5777) = true)

theorem identity5777 : scanCanonicalize (H12AffineFastState.compose env5777 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5777 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env5778 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,8192,16384,8201,25614,1029,2185,1024,8201,1165,4194304,4194304,2,8329,4194304,19597,16385,16520,19596,16388,17548,4,17548,4195332,4194953]

theorem envBound5778 : H12AffineFastState.Bounded env5778 := by
  intro p hp
  have h : env5778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5777_5778 : H12AffineEnvironment.transform 4 1 env5777 = env5778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5777 == env5778) = true)

theorem identity5778 : scanCanonicalize (H12AffineFastState.compose env5778 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 27654) := by decide +kernel

theorem selectedBound5778 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env5779 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,8192,16384,8201,25614,1029,2185,1024,8201,1165,27654,27654,2,8329,27654,19597,16385,16520,19596,16388,17548,4,17548,26626,28303]

theorem envBound5779 : H12AffineFastState.Bounded env5779 := by
  intro p hp
  have h : env5779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5778_5779 : H12AffineEnvironment.transform 21 27654 env5778 = env5779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 27654 env5778 == env5779) = true)

theorem identity5779 : scanCanonicalize (H12AffineFastState.compose env5779 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 11396) := by decide +kernel

theorem selectedBound5779 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env5780 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,8192,11396,8201,2186,1029,2185,1024,8201,1165,130,130,2,8329,130,8201,11397,11276,8200,11392,10248,4,10248,1158,523]

theorem envBound5780 : H12AffineFastState.Bounded env5780 := by
  intro p hp
  have h : env5780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5779_5780 : H12AffineEnvironment.transform 13 11396 env5779 = env5780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11396 env5779 == env5780) = true)

theorem identity5780 : scanCanonicalize (H12AffineFastState.compose env5780 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound5780 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env5781 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,2056,1164,2049,2186,1029,2185,1024,2049,1165,130,130,2,2177,130,2049,1165,1028,2048,1160,0,4,0,1158,523]

theorem envBound5781 : H12AffineFastState.Bounded env5781 := by
  intro p hp
  have h : env5781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5780_5781 : H12AffineEnvironment.transform 12 2056 env5780 = env5781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env5780 == env5781) = true)

theorem identity5781 : scanCanonicalize (H12AffineFastState.compose env5781 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound5781 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env5782 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1029,2056,1028,2049,2050,1029,2049,1024,2049,1029,10,10,2,2057,10,2049,1029,1028,2048,1024,0,4,0,1038,523]

theorem envBound5782 : H12AffineFastState.Bounded env5782 := by
  intro p hp
  have h : env5782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5781_5782 : H12AffineEnvironment.transform 6 8 env5781 = env5782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env5781 == env5782) = true)

theorem identity5782 : scanCanonicalize (H12AffineFastState.compose env5782 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5783 : List Nat := [2,4,8,1,1,1,8,4,512,1024,1038,1029,1030,1028,1039,1036,1029,1039,1024,1039,1029,10,10,2,1031,10,1039,1029,1028,1038,1024,0,4,0,1038,523]

theorem envBound5783 : H12AffineFastState.Bounded env5783 := by
  intro p hp
  have h : env5783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5782_5783 : H12AffineEnvironment.transform 10 1038 env5782 = env5783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env5782 == env5783) = true)

theorem identity5783 : scanCanonicalize (H12AffineFastState.compose env5783 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound5783 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5784 : List Nat := [2,4,8,1,1,1,8,4,10,1024,1038,1029,1030,1028,1039,1036,1029,1039,1024,1039,1029,10,10,2,1031,10,1039,1029,1028,1038,1024,0,4,0,1038,1]

theorem envBound5784 : H12AffineFastState.Bounded env5784 := by
  intro p hp
  have h : env5784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5783_5784 : H12AffineEnvironment.transform 8 10 env5783 = env5784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env5783 == env5784) = true)

def env5785 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4096,4194304,8388608,41002,8329,8388609,323713,16385,16812,22561,16657,12644668,256,20480,4239488,8389564]

theorem envBound5785 : H12AffineFastState.Bounded env5785 := by
  intro p hp
  have h : env5785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5720_5785 : H12AffineEnvironment.transform 5 17 env5720 = env5785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5720 == env5785) = true)

theorem identity5785 : scanCanonicalize (H12AffineFastState.compose env5785 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5785 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5786 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4096,4194304,444,41002,8329,445,323713,16385,16812,22561,16657,4255872,256,20480,4239488,512]

theorem envBound5786 : H12AffineFastState.Bounded env5786 := by
  intro p hp
  have h : env5786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5785_5786 : H12AffineEnvironment.transform 22 444 env5785 = env5786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5785 == env5786) = true)

theorem identity5786 : scanCanonicalize (H12AffineFastState.compose env5786 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5786 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5787 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4096,41348,444,41002,8329,445,323713,16385,16812,22561,16657,20740,256,20480,4356,512]

theorem envBound5787 : H12AffineFastState.Bounded env5787 := by
  intro p hp
  have h : env5787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5786_5787 : H12AffineEnvironment.transform 21 41348 env5786 = env5787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5786 == env5787) = true)

theorem identity5787 : scanCanonicalize (H12AffineFastState.compose env5787 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5787 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5788 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25914,4524,262144,1024,26261,4096,18193,444,18111,8329,445,267796,16385,16812,22561,16657,20740,256,20480,4356,512]

theorem envBound5788 : H12AffineFastState.Bounded env5788 := by
  intro p hp
  have h : env5788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5787_5788 : H12AffineEnvironment.transform 14 26261 env5787 = env5788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5787 == env5788) = true)

theorem identity5788 : scanCanonicalize (H12AffineFastState.compose env5788 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound5788 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5789 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25914,1044,262144,1024,26261,1464,18193,444,18111,8329,445,263084,16385,16812,19865,16657,17596,256,17848,1212,512]

theorem envBound5789 : H12AffineFastState.Bounded env5789 := by
  intro p hp
  have h : env5789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5788_5789 : H12AffineEnvironment.transform 11 1464 env5788 = env5789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env5788 == env5789) = true)

theorem identity5789 : scanCanonicalize (H12AffineFastState.compose env5789 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound5789 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env5790 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25914,1044,2340,1024,26261,1464,18193,444,18111,8329,445,2696,16385,16812,19865,16657,17596,256,17848,1212,512]

theorem envBound5790 : H12AffineFastState.Bounded env5790 := by
  intro p hp
  have h : env5790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5789_5790 : H12AffineEnvironment.transform 17 2340 env5789 = env5790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env5789 == env5790) = true)

theorem identity5790 : scanCanonicalize (H12AffineFastState.compose env5790 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1944) := by decide +kernel

theorem selectedBound5790 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5791 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,1944,8461,8866,1044,2340,1024,8461,1464,137,444,295,8329,445,2696,1945,1588,2561,1673,804,256,544,1212,512]

theorem envBound5791 : H12AffineFastState.Bounded env5791 := by
  intro p hp
  have h : env5791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5790_5791 : H12AffineEnvironment.transform 13 1944 env5790 = env5791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1944 env5790 == env5791) = true)

theorem identity5791 : scanCanonicalize (H12AffineFastState.compose env5791 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5791 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env5792 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1296,8192,1840,8461,8714,1044,2340,1024,8461,1296,33,276,295,8225,277,2592,1841,1588,2561,1569,804,256,544,1044,512]

theorem envBound5792 : H12AffineFastState.Bounded env5792 := by
  intro p hp
  have h : env5792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5791_5792 : H12AffineEnvironment.transform 6 40 env5791 = env5792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5791 == env5792) = true)

theorem identity5792 : scanCanonicalize (H12AffineFastState.compose env5792 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5792 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5793 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,8192,1588,8201,8714,1044,2080,1024,8201,1044,33,16,35,8225,17,2592,1589,1588,2561,1569,544,4,544,1044,512]

theorem envBound5793 : H12AffineFastState.Bounded env5793 := by
  intro p hp
  have h : env5793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5792_5793 : H12AffineEnvironment.transform 7 4 env5792 = env5793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5792 == env5793) = true)

theorem identity5793 : scanCanonicalize (H12AffineFastState.compose env5793 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5793 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5794 : List Nat := [2,4,8,16,32,17,40,4,33,1024,2048,1044,8192,1045,8201,8235,1044,2080,1024,8201,1044,33,16,35,8225,17,2049,1044,1045,2080,1024,1,4,1,1044,33]

theorem envBound5794 : H12AffineFastState.Bounded env5794 := by
  intro p hp
  have h : env5794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5793_5794 : H12AffineEnvironment.transform 8 33 env5793 = env5794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5793 == env5794) = true)

theorem identity5794 : scanCanonicalize (H12AffineFastState.compose env5794 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound5794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5795 : List Nat := [2,4,8,16,32,17,40,4,33,1024,2048,1044,2098,1045,2107,2073,1044,2080,1024,2107,1044,33,16,35,2067,17,2049,1044,1045,2080,1024,1,4,1,1044,33]

theorem envBound5795 : H12AffineFastState.Bounded env5795 := by
  intro p hp
  have h : env5795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5794_5795 : H12AffineEnvironment.transform 12 2098 env5794 = env5795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env5794 == env5795) = true)

theorem identity5795 : scanCanonicalize (H12AffineFastState.compose env5795 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5795 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5796 : List Nat := [2,4,8,16,27,17,19,4,26,1024,2048,1044,2057,1045,2048,2073,1044,2075,1024,2048,1044,26,16,24,2067,17,2049,1044,1045,2075,1024,1,4,1,1044,26]

theorem envBound5796 : H12AffineFastState.Bounded env5796 := by
  intro p hp
  have h : env5796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5795_5796 : H12AffineEnvironment.transform 4 27 env5795 = env5796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5795 == env5796) = true)

theorem identity5796 : scanCanonicalize (H12AffineFastState.compose env5796 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound5796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5797 : List Nat := [2,4,8,16,27,17,19,4,26,21,2048,1,2057,0,2048,2073,1,2075,21,2048,1,26,16,24,2067,17,2049,1,0,2075,21,1,4,1,1,26]

theorem envBound5797 : H12AffineFastState.Bounded env5797 := by
  intro p hp
  have h : env5797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5796_5797 : H12AffineEnvironment.transform 9 21 env5796 = env5797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env5796 == env5797) = true)

theorem identity5797 : scanCanonicalize (H12AffineFastState.compose env5797 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound5797 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5798 : List Nat := [2,4,8,16,27,17,19,4,26,21,26,1,19,0,26,3,1,1,21,26,1,26,16,24,9,17,27,1,0,1,21,1,4,1,1,26]

theorem envBound5798 : H12AffineFastState.Bounded env5798 := by
  intro p hp
  have h : env5798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5797_5798 : H12AffineEnvironment.transform 10 26 env5797 = env5798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env5797 == env5798) = true)

theorem identity5798 : scanCanonicalize (H12AffineFastState.compose env5798 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5798 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5799 : List Nat := [2,4,8,10,1,11,9,4,0,15,0,1,9,0,0,3,1,1,15,0,1,0,10,2,9,11,1,1,0,1,15,1,4,1,1,0]

theorem envBound5799 : H12AffineFastState.Bounded env5799 := by
  intro p hp
  have h : env5799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5798_5799 : H12AffineEnvironment.transform 3 10 env5798 = env5799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5798 == env5799) = true)

def env5800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323793,16385,16893,22641,74794,12644668,257,20560,4239488,8389612]

theorem envBound5800 : H12AffineFastState.Bounded env5800 := by
  intro p hp
  have h : env5800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5718_5800 : H12AffineEnvironment.transform 18 1025 env5718 = env5800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5718 == env5800) = true)

theorem identity5800 : scanCanonicalize (H12AffineFastState.compose env5800 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73786) := by decide +kernel

theorem selectedBound5800 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,73786,41002,8329,73835,323793,16385,16893,22641,74794,4313350,257,20560,4239488,74710]

theorem envBound5801 : H12AffineFastState.Bounded env5801 := by
  intro p hp
  have h : env5801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5800_5801 : H12AffineEnvironment.transform 22 73786 env5800 = env5801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73786 env5800 == env5801) = true)

def env5802 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,73786,41002,8329,73787,323713,16385,16813,22561,74794,4313350,257,20480,4239488,74630]

theorem envBound5802 : H12AffineFastState.Bounded env5802 := by
  intro p hp
  have h : env5802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5801_5802 : H12AffineEnvironment.transform 5 16 env5801 = env5802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5801 == env5802) = true)

theorem identity5802 : scanCanonicalize (H12AffineFastState.compose env5802 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound5802 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5803 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4525,262144,1025,32768,4096,4194304,444,41002,8329,445,323713,16385,16813,22561,1452,4255872,257,20480,4239488,512]

theorem envBound5803 : H12AffineFastState.Bounded env5803 := by
  intro p hp
  have h : env5803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5802_5803 : H12AffineEnvironment.transform 15 8582 env5802 = env5803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env5802 == env5803) = true)

theorem identity5803 : scanCanonicalize (H12AffineFastState.compose env5803 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5803 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5804 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4525,262144,1025,32768,4096,41349,444,41002,8329,445,323713,16385,16813,22561,1452,20741,257,20480,4357,512]

theorem envBound5804 : H12AffineFastState.Bounded env5804 := by
  intro p hp
  have h : env5804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5803_5804 : H12AffineEnvironment.transform 21 41349 env5803 = env5804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5803 == env5804) = true)

theorem identity5804 : scanCanonicalize (H12AffineFastState.compose env5804 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5804 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5805 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8582,4525,262144,1025,26260,4096,18193,444,18110,8329,445,267797,16385,16813,22561,1452,20741,257,20480,4357,512]

theorem envBound5805 : H12AffineFastState.Bounded env5805 := by
  intro p hp
  have h : env5805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5804_5805 : H12AffineEnvironment.transform 14 26260 env5804 = env5805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5804 == env5805) = true)

theorem identity5805 : scanCanonicalize (H12AffineFastState.compose env5805 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound5805 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5806 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,14224,8582,4525,262144,1025,14224,4096,5653,444,6074,8329,445,267797,4357,4265,2341,1452,1,257,260,4357,512]

theorem envBound5806 : H12AffineFastState.Bounded env5806 := by
  intro p hp
  have h : env5806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5805_5806 : H12AffineEnvironment.transform 13 4356 env5805 = env5806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env5805 == env5806) = true)

theorem identity5806 : scanCanonicalize (H12AffineFastState.compose env5806 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5806 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env5807 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,8322,4265,262144,1025,13972,4096,5653,184,5822,8329,185,267797,4097,4265,2081,1192,1,5,0,4097,512]

theorem envBound5807 : H12AffineFastState.Bounded env5807 := by
  intro p hp
  have h : env5807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5806_5807 : H12AffineEnvironment.transform 7 4 env5806 = env5807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5806 == env5807) = true)

theorem identity5807 : scanCanonicalize (H12AffineFastState.compose env5807 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound5807 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5808 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,8322,4265,7868,1025,13972,4096,5653,184,5822,8329,185,2217,4097,4265,2081,1192,1,5,0,4097,512]

theorem envBound5808 : H12AffineFastState.Bounded env5808 := by
  intro p hp
  have h : env5808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5807_5808 : H12AffineEnvironment.transform 17 7868 env5807 = env5808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env5807 == env5808) = true)

theorem identity5808 : scanCanonicalize (H12AffineFastState.compose env5808 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound5808 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5809 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1589,8192,1589,8353,8322,1692,2185,1025,8353,1589,32,184,139,8329,185,2217,1588,1692,2081,1192,1,5,0,1588,512]

theorem envBound5809 : H12AffineFastState.Bounded env5809 := by
  intro p hp
  have h : env5809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5808_5809 : H12AffineEnvironment.transform 11 1589 env5808 = env5809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env5808 == env5809) = true)

theorem identity5809 : scanCanonicalize (H12AffineFastState.compose env5809 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 155) := by decide +kernel

theorem selectedBound5809 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5810 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1589,155,1589,58,25,1692,2185,1025,58,1589,32,184,139,18,185,2217,1588,1692,2081,1192,1,5,0,1588,512]

theorem envBound5810 : H12AffineFastState.Bounded env5810 := by
  intro p hp
  have h : env5810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5809_5810 : H12AffineEnvironment.transform 12 155 env5809 = env5810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 155 env5809 == env5810) = true)

theorem identity5810 : scanCanonicalize (H12AffineFastState.compose env5810 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 690) := by decide +kernel

theorem selectedBound5810 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env5811 : List Nat := [2,4,8,16,32,16,128,4,512,1024,690,1589,155,1589,58,25,1692,571,1025,58,1589,32,184,139,18,185,539,1588,1692,659,1192,1,5,0,1588,512]

theorem envBound5811 : H12AffineFastState.Bounded env5811 := by
  intro p hp
  have h : env5811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5810_5811 : H12AffineEnvironment.transform 10 690 env5810 = env5811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 690 env5810 == env5811) = true)

theorem identity5811 : scanCanonicalize (H12AffineFastState.compose env5811 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5811 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env5812 : List Nat := [2,4,8,10,32,10,128,4,512,1024,680,1583,129,1583,32,3,1670,545,1025,32,1583,32,162,139,8,163,513,1582,1670,649,1192,1,5,0,1582,512]

theorem envBound5812 : H12AffineFastState.Bounded env5812 := by
  intro p hp
  have h : env5812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5811_5812 : H12AffineEnvironment.transform 3 10 env5811 = env5812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5811 == env5812) = true)

theorem identity5812 : scanCanonicalize (H12AffineFastState.compose env5812 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5812 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5813 : List Nat := [2,4,8,10,0,10,128,4,512,1024,648,1551,129,1551,0,3,1670,513,1025,0,1551,0,130,139,8,131,513,1550,1670,649,1160,1,5,0,1550,512]

theorem envBound5813 : H12AffineFastState.Bounded env5813 := by
  intro p hp
  have h : env5813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5812_5813 : H12AffineEnvironment.transform 4 0 env5812 = env5813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5812 == env5813) = true)

theorem identity5813 : scanCanonicalize (H12AffineFastState.compose env5813 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound5813 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env5814 : List Nat := [2,4,8,10,0,10,128,4,136,1024,0,1159,129,1159,0,3,1038,137,1025,0,1159,0,130,139,8,131,137,1158,1038,1,1160,1,5,0,1158,136]

theorem envBound5814 : H12AffineFastState.Bounded env5814 := by
  intro p hp
  have h : env5814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5813_5814 : H12AffineEnvironment.transform 8 136 env5813 = env5814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env5813 == env5814) = true)

theorem identity5814 : scanCanonicalize (H12AffineFastState.compose env5814 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound5814 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5815 : List Nat := [2,4,8,10,0,10,8,4,0,1024,0,1039,9,1039,0,3,1038,1,1025,0,1039,0,10,3,8,11,1,1038,1038,1,1024,1,5,0,1038,0]

theorem envBound5815 : H12AffineFastState.Bounded env5815 := by
  intro p hp
  have h : env5815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5814_5815 : H12AffineEnvironment.transform 6 8 env5814 = env5815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env5814 == env5815) = true)

theorem identity5815 : scanCanonicalize (H12AffineFastState.compose env5815 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5816 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1028,2,1028,0,3,1029,1,1025,0,1028,0,1,3,3,0,1,1029,1029,1,1024,1,5,0,1029,0]

theorem envBound5816 : H12AffineFastState.Bounded env5816 := by
  intro p hp
  have h : env5816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5815_5816 : H12AffineEnvironment.transform 2 3 env5815 = env5816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5815 == env5816) = true)

def leafEnv5816 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1028,2,1028,0,3,1029,1,1025,0,1028,0,1,3,1025,3,1,0,1,1029,1029,1,1024,1,5,0,5,3,1029,0,1,1028,0]

def active5816 : List Nat := [0,1,9]

def tree5816 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5816 : H12WitnessSearch.Good tree5816 := H12GlobalWitnessIndex.good

theorem leafIdentity5816 : H12AffineFastState.composeSystem env5816 rootObs = leafEnv5816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5816 rootObs == leafEnv5816) = true)

theorem terminalChecked5816 : H12PackedTerminal.terminalCheckFast leafEnv5816 active5816 tree5816 = true := by decide +kernel

def env5817 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,73786,41002,8329,73786,323712,16385,16812,22560,74794,4313350,257,20481,4239488,74631]

theorem envBound5817 : H12AffineFastState.Bounded env5817 := by
  intro p hp
  have h : env5817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5801_5817 : H12AffineEnvironment.transform 5 17 env5801 = env5817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5801 == env5817) = true)

def env5818 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,41088,73786,41002,8329,73786,323712,16385,16812,22560,74794,94598,257,20481,4096,74631]

theorem envBound5818 : H12AffineFastState.Bounded env5818 := by
  intro p hp
  have h : env5818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5817_5818 : H12AffineEnvironment.transform 21 41088 env5817 = env5818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5817 == env5818) = true)

theorem identity5818 : scanCanonicalize (H12AffineFastState.compose env5818 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5818 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5819 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1025,32768,4096,41088,73786,41002,8329,73786,323712,16385,16553,22560,74794,94339,4,20481,4096,74370]

theorem envBound5819 : H12AffineFastState.Bounded env5819 := by
  intro p hp
  have h : env5819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5818_5819 : H12AffineEnvironment.transform 7 5 env5818 = env5819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5818 == env5819) = true)

theorem identity5819 : scanCanonicalize (H12AffineFastState.compose env5819 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 100355) := by decide +kernel

theorem selectedBound5819 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5820 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4265,100355,1025,32768,4096,41088,73786,41002,8329,73786,96387,16385,16553,22560,74794,94339,4,20481,4096,74370]

theorem envBound5820 : H12AffineFastState.Bounded env5820 := by
  intro p hp
  have h : env5820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5819_5820 : H12AffineEnvironment.transform 17 100355 env5819 = env5820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100355 env5819 == env5820) = true)

theorem identity5820 : scanCanonicalize (H12AffineFastState.compose env5820 (packedSelected [0,7,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 50711) := by decide +kernel

theorem selectedBound5820 : packedSelected [0,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env5821 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,50711,4265,19988,1025,32768,4096,41088,58925,41002,8329,58925,48788,16385,16553,22560,57917,46740,4,20481,4096,58517]

theorem envBound5821 : H12AffineFastState.Bounded env5821 := by
  intro p hp
  have h : env5821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5820_5821 : H12AffineEnvironment.transform 15 50711 env5820 = env5821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50711 env5820 == env5821) = true)

theorem identity5821 : scanCanonicalize (H12AffineFastState.compose env5821 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5821 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

def env5822 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1692,8192,16384,32768,50711,1589,19988,1025,32768,1692,41088,58925,41002,8329,58925,43016,16385,16553,20156,57917,40968,4,18077,1692,58517]

theorem envBound5822 : H12AffineFastState.Bounded env5822 := by
  intro p hp
  have h : env5822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5821_5822 : H12AffineEnvironment.transform 11 1692 env5821 = env5822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env5821 == env5822) = true)

theorem identity5822 : scanCanonicalize (H12AffineFastState.compose env5822 (packedSelected [0,1,8,10,11,15,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5822 : packedSelected [0,1,8,10,11,15,20,27] rootPS < 2^1333 := by decide +kernel

def env5823 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1692,8192,16384,26261,8322,1589,19988,1025,26261,1692,17941,184,18111,8329,184,20125,16385,16553,20156,1192,18077,4,18077,1692,512]

theorem envBound5823 : H12AffineFastState.Bounded env5823 := by
  intro p hp
  have h : env5823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5822_5823 : H12AffineEnvironment.transform 14 26261 env5822 = env5823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5822 == env5823) = true)

theorem identity5823 : scanCanonicalize (H12AffineFastState.compose env5823 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound5823 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5824 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1692,8192,1693,8200,8322,1589,2185,1025,8200,1692,136,184,34,8329,184,2048,1692,1588,2081,1192,0,4,0,1692,512]

theorem envBound5824 : H12AffineFastState.Bounded env5824 := by
  intro p hp
  have h : env5824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5823_5824 : H12AffineEnvironment.transform 13 1693 env5823 = env5824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env5823 == env5824) = true)

def env5825 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,41089,73786,41002,8329,73786,323712,16385,16812,22560,74794,94599,257,20481,4097,74631]

theorem envBound5825 : H12AffineFastState.Bounded env5825 := by
  intro p hp
  have h : env5825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5817_5825 : H12AffineEnvironment.transform 21 41089 env5817 = env5825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5817 == env5825) = true)

theorem identity5825 : scanCanonicalize (H12AffineFastState.compose env5825 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound5825 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5826 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,4524,262144,1025,32768,4096,41089,185,41002,8329,185,323712,16385,16812,22560,1193,20740,257,20481,4097,772]

theorem envBound5826 : H12AffineFastState.Bounded env5826 := by
  intro p hp
  have h : env5826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5825_5826 : H12AffineEnvironment.transform 15 8323 env5825 = env5826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env5825 == env5826) = true)

theorem identity5826 : scanCanonicalize (H12AffineFastState.compose env5826 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 61361) := by decide +kernel

theorem selectedBound5826 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5827 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,4524,61361,1025,32768,4096,41089,185,41002,8329,185,7985,16385,16812,22560,1193,20740,257,20481,4097,772]

theorem envBound5827 : H12AffineFastState.Bounded env5827 := by
  intro p hp
  have h : env5827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5826_5827 : H12AffineEnvironment.transform 17 61361 env5826 = env5827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61361 env5826 == env5827) = true)

theorem identity5827 : scanCanonicalize (H12AffineFastState.compose env5827 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound5827 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5828 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,8192,16384,32768,8323,1588,61361,1025,32768,1944,41089,185,41002,8329,185,2217,16385,16812,20408,1193,18076,257,18329,1945,772]

theorem envBound5828 : H12AffineFastState.Bounded env5828 := by
  intro p hp
  have h : env5828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5827_5828 : H12AffineEnvironment.transform 11 1944 env5827 = env5828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env5827 == env5828) = true)

theorem identity5828 : scanCanonicalize (H12AffineFastState.compose env5828 (packedSelected [1,4,5,7,8,9,13,21,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5828 : packedSelected [1,4,5,7,8,9,13,21,24,27] rootPS < 2^1333 := by decide +kernel

def env5829 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,8192,16384,26261,8323,1588,2340,1025,26261,1944,17940,185,18111,8329,185,2217,16385,16812,20408,1193,18076,257,18329,1945,772]

theorem envBound5829 : H12AffineFastState.Bounded env5829 := by
  intro p hp
  have h : env5829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5828_5829 : H12AffineEnvironment.transform 14 26261 env5828 = env5829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5828 == env5829) = true)

theorem identity5829 : scanCanonicalize (H12AffineFastState.compose env5829 (packedSelected [0,1,2,6,7,8,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound5829 : packedSelected [0,1,2,6,7,8,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5830 : List Nat := [2,4,8,16,32,17,18,256,512,1024,2048,1802,8192,16384,26119,8209,1588,2340,1025,26119,1802,17940,43,17965,8219,43,2107,16385,16702,20266,1083,17934,257,18187,1803,772]

theorem envBound5830 : H12AffineFastState.Bounded env5830 := by
  intro p hp
  have h : env5830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5829_5830 : H12AffineEnvironment.transform 6 18 env5829 = env5830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env5829 == env5830) = true)

theorem identity5830 : scanCanonicalize (H12AffineFastState.compose env5830 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound5830 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env5831 : List Nat := [2,4,8,16,32,17,18,256,512,1024,2048,1802,8192,1840,8503,8209,1588,2340,1025,8503,1802,292,43,285,8219,43,2107,1841,1550,2074,1083,318,257,59,1803,772]

theorem envBound5831 : H12AffineFastState.Bounded env5831 := by
  intro p hp
  have h : env5831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5830_5831 : H12AffineEnvironment.transform 13 1840 env5830 = env5831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env5830 == env5831) = true)

theorem identity5831 : scanCanonicalize (H12AffineFastState.compose env5831 (packedSelected [2,3,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound5831 : packedSelected [2,3,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env5832 : List Nat := [2,4,8,16,32,17,18,46,512,1024,2048,1572,8192,1566,8217,8209,1588,2058,1025,8217,1572,10,43,51,8219,43,2107,1567,1550,2074,1083,16,47,59,1573,554]

theorem envBound5832 : H12AffineFastState.Bounded env5832 := by
  intro p hp
  have h : env5832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5831_5832 : H12AffineEnvironment.transform 7 46 env5831 = env5832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env5831 == env5832) = true)

theorem identity5832 : scanCanonicalize (H12AffineFastState.compose env5832 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5832 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env5833 : List Nat := [2,4,8,1,32,0,3,46,512,1024,2048,1572,8192,1551,8200,8192,1573,2058,1025,8200,1572,10,43,34,8202,43,2090,1550,1550,2059,1066,1,47,42,1573,554]

theorem envBound5833 : H12AffineFastState.Bounded env5833 := by
  intro p hp
  have h : env5833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5832_5833 : H12AffineEnvironment.transform 3 1 env5832 = env5833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5832 == env5833) = true)

theorem identity5833 : scanCanonicalize (H12AffineFastState.compose env5833 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2595) := by decide +kernel

theorem selectedBound5833 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5834 : List Nat := [2,4,8,1,32,0,3,46,512,1024,2048,1572,2595,1551,2603,2595,1573,2058,1025,2603,1572,10,43,34,2601,43,2090,1550,1550,2059,1066,1,47,42,1573,554]

theorem envBound5834 : H12AffineFastState.Bounded env5834 := by
  intro p hp
  have h : env5834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5833_5834 : H12AffineEnvironment.transform 12 2595 env5833 = env5834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2595 env5833 == env5834) = true)

def env5835 : List Nat := [2,4,8,1,32,0,3,46,512,1024,1572,1572,1031,1551,1039,1031,1573,1582,1025,1039,1572,10,43,34,1037,43,1550,1550,1550,1583,1066,1,47,42,1573,554]

theorem envBound5835 : H12AffineFastState.Bounded env5835 := by
  intro p hp
  have h : env5835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5834_5835 : H12AffineEnvironment.transform 10 1572 env5834 = env5835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env5834 == env5835) = true)

theorem identity5835 : scanCanonicalize (H12AffineFastState.compose env5835 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5835 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5836 : List Nat := [2,4,8,1,10,0,3,4,512,1024,1550,1550,1031,1551,1039,1031,1551,1540,1025,1039,1550,10,1,8,1037,1,1550,1550,1550,1541,1024,1,5,0,1551,512]

theorem envBound5836 : H12AffineFastState.Bounded env5836 := by
  intro p hp
  have h : env5836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5835_5836 : H12AffineEnvironment.transform 4 10 env5835 = env5836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5835 == env5836) = true)

theorem identity5836 : scanCanonicalize (H12AffineFastState.compose env5836 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5836 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env5837 : List Nat := [2,4,2,1,0,0,3,4,512,1024,1540,1540,1031,1541,1029,1031,1541,1540,1025,1029,1540,0,1,2,1031,1,1540,1540,1540,1541,1024,1,5,0,1541,512]

theorem envBound5837 : H12AffineFastState.Bounded env5837 := by
  intro p hp
  have h : env5837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5836_5837 : H12AffineEnvironment.transform 2 2 env5836 = env5837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5836 == env5837) = true)

theorem identity5837 : scanCanonicalize (H12AffineFastState.compose env5837 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5838 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1028,1028,1031,1029,1029,1031,1029,1028,1025,1029,1028,0,1,2,1031,1,1028,1028,1028,1029,1024,1,5,0,1029,0]

theorem envBound5838 : H12AffineFastState.Bounded env5838 := by
  intro p hp
  have h : env5838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5837_5838 : H12AffineEnvironment.transform 8 0 env5837 = env5838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5837 == env5838) = true)

theorem identity5838 : scanCanonicalize (H12AffineFastState.compose env5838 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound5838 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5839 : List Nat := [2,4,2,1,0,0,3,4,0,5,1,1,2,0,0,2,0,1,4,0,1,0,1,2,2,1,1,1,1,0,5,1,5,0,0,0]

theorem envBound5839 : H12AffineFastState.Bounded env5839 := by
  intro p hp
  have h : env5839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5838_5839 : H12AffineEnvironment.transform 9 5 env5838 = env5839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env5838 == env5839) = true)

def leafEnv5839 : List Nat := [2,4,2,1,0,0,3,4,0,5,1,1,2,0,0,2,0,1,4,0,1,0,1,2,4,2,1,1,1,1,1,0,5,1,5,0,5,3,0,0,1,0,0]

def active5839 : List Nat := [0,1]

def tree5839 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5839 : H12WitnessSearch.Good tree5839 := H12GlobalWitnessIndex.good

theorem leafIdentity5839 : H12AffineFastState.composeSystem env5839 rootObs = leafEnv5839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5839 rootObs == leafEnv5839) = true)

theorem terminalChecked5839 : H12PackedTerminal.terminalCheckFast leafEnv5839 active5839 tree5839 = true := by decide +kernel

def env5840 : List Nat := [2,4,8,1,32,0,3,46,512,1024,1573,1572,1030,1551,1038,1030,1573,1583,1025,1038,1572,10,43,34,1036,43,1551,1550,1550,1582,1066,1,47,42,1573,554]

theorem envBound5840 : H12AffineFastState.Bounded env5840 := by
  intro p hp
  have h : env5840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5834_5840 : H12AffineEnvironment.transform 10 1573 env5834 = env5840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env5834 == env5840) = true)

def env5841 : List Nat := [2,4,8,1,32,0,3,46,0,1024,1061,1060,1030,1039,1038,1030,1061,1071,1025,1038,1060,10,43,34,1036,43,1039,1038,1038,1070,1066,1,47,42,1061,42]

theorem envBound5841 : H12AffineFastState.Bounded env5841 := by
  intro p hp
  have h : env5841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5840_5841 : H12AffineEnvironment.transform 8 0 env5840 = env5841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5840 == env5841) = true)

theorem identity5841 : scanCanonicalize (H12AffineFastState.compose env5841 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound5841 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5842 : List Nat := [2,4,8,1,32,0,3,46,0,46,11,10,40,33,32,40,11,1,47,32,10,10,43,34,34,43,33,32,32,0,4,1,47,42,11,42]

theorem envBound5842 : H12AffineFastState.Bounded env5842 := by
  intro p hp
  have h : env5842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5841_5842 : H12AffineEnvironment.transform 9 46 env5841 = env5842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env5841 == env5842) = true)

theorem identity5842 : scanCanonicalize (H12AffineFastState.compose env5842 (packedSelected [0,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5842 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env5843 : List Nat := [2,4,8,1,10,0,3,4,0,4,11,10,2,11,10,2,11,1,5,10,10,10,1,8,8,1,11,10,10,0,4,1,5,0,11,0]

theorem envBound5843 : H12AffineFastState.Bounded env5843 := by
  intro p hp
  have h : env5843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5842_5843 : H12AffineEnvironment.transform 4 10 env5842 = env5843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5842 == env5843) = true)

theorem identity5843 : scanCanonicalize (H12AffineFastState.compose env5843 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5844 : List Nat := [2,4,2,1,0,0,3,4,0,4,1,0,2,1,0,2,1,1,5,0,0,0,1,2,2,1,1,0,0,0,4,1,5,0,1,0]

theorem envBound5844 : H12AffineFastState.Bounded env5844 := by
  intro p hp
  have h : env5844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5843_5844 : H12AffineEnvironment.transform 2 2 env5843 = env5844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5843 == env5844) = true)

def leafEnv5844 : List Nat := [2,4,2,1,0,0,3,4,0,4,1,0,2,1,0,2,1,1,5,0,0,0,1,2,5,2,1,1,1,0,0,0,4,1,5,0,5,3,1,0,1,1,0]

def active5844 : List Nat := [0,1]

def tree5844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5844 : H12WitnessSearch.Good tree5844 := H12GlobalWitnessIndex.good

theorem leafIdentity5844 : H12AffineFastState.composeSystem env5844 rootObs = leafEnv5844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5844 rootObs == leafEnv5844) = true)

theorem terminalChecked5844 : H12PackedTerminal.terminalCheckFast leafEnv5844 active5844 tree5844 = true := by decide +kernel

def env5845 : List Nat := [2,4,8,1,32,0,3,46,1,1024,1060,1061,1030,1038,1038,1030,1060,1070,1025,1038,1061,10,43,34,1036,43,1038,1039,1039,1071,1066,1,47,42,1060,43]

theorem envBound5845 : H12AffineFastState.Bounded env5845 := by
  intro p hp
  have h : env5845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5840_5845 : H12AffineEnvironment.transform 8 1 env5840 = env5845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5840 == env5845) = true)

theorem identity5845 : scanCanonicalize (H12AffineFastState.compose env5845 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound5845 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5846 : List Nat := [2,4,8,1,32,0,3,46,1,37,1,0,35,43,43,35,1,11,36,43,0,10,43,34,41,43,43,42,42,10,15,1,47,42,1,43]

theorem envBound5846 : H12AffineFastState.Bounded env5846 := by
  intro p hp
  have h : env5846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5845_5846 : H12AffineEnvironment.transform 9 37 env5845 = env5846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env5845 == env5846) = true)

theorem identity5846 : scanCanonicalize (H12AffineFastState.compose env5846 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5846 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5847 : List Nat := [2,4,8,1,11,0,3,5,1,14,1,0,8,0,0,8,1,11,15,0,0,10,0,9,2,0,0,1,1,10,15,1,4,1,1,0]

theorem envBound5847 : H12AffineFastState.Bounded env5847 := by
  intro p hp
  have h : env5847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5846_5847 : H12AffineEnvironment.transform 4 11 env5846 = env5847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5846 == env5847) = true)

theorem identity5847 : scanCanonicalize (H12AffineFastState.compose env5847 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5848 : List Nat := [2,0,8,1,11,0,3,1,1,10,1,0,8,0,0,8,1,11,11,0,0,10,0,9,2,0,0,1,1,10,11,1,0,1,1,0]

theorem envBound5848 : H12AffineFastState.Bounded env5848 := by
  intro p hp
  have h : env5848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5847_5848 : H12AffineEnvironment.transform 1 0 env5847 = env5848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5847 == env5848) = true)

def leafEnv5848 : List Nat := [2,0,8,1,11,0,3,1,1,10,1,0,8,0,0,8,1,11,11,0,0,10,0,9,10,2,1,0,0,1,1,10,11,1,0,1,1,2,1,0,1,1,0]

def active5848 : List Nat := [0,2]

def tree5848 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5848 : H12WitnessSearch.Good tree5848 := H12GlobalWitnessIndex.good

theorem leafIdentity5848 : H12AffineFastState.composeSystem env5848 rootObs = leafEnv5848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5848 rootObs == leafEnv5848) = true)

theorem terminalChecked5848 : H12PackedTerminal.terminalCheckFast leafEnv5848 active5848 tree5848 = true := by decide +kernel

def env5849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849105,16385,16893,547953,598059,12644669,525568,545872,4239489,8914925]

theorem envBound5849 : H12AffineFastState.Bounded env5849 := by
  intro p hp
  have h : env5849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5717_5849 : H12AffineEnvironment.transform 20 4097 env5717 = env5849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5717 == env5849) = true)

def env5850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323793,16385,16893,22641,74795,12644669,256,20560,4239489,8389613]

theorem envBound5850 : H12AffineFastState.Bounded env5850 := by
  intro p hp
  have h : env5850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5849_5850 : H12AffineEnvironment.transform 18 1024 env5849 = env5850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5849 == env5850) = true)

theorem identity5850 : scanCanonicalize (H12AffineFastState.compose env5850 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310442) := by decide +kernel

theorem selectedBound5850 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4310442,41002,8329,4310522,323793,16385,16893,22641,74795,78999,256,20560,4239489,4310599]

theorem envBound5851 : H12AffineFastState.Bounded env5851 := by
  intro p hp
  have h : env5851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5850_5851 : H12AffineEnvironment.transform 22 4310442 env5850 = env5851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310442 env5850 == env5851) = true)

def env5852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4310442,41002,8329,4310442,323713,16385,16813,22561,74795,78999,256,20480,4239489,4310551]

theorem envBound5852 : H12AffineFastState.Bounded env5852 := by
  intro p hp
  have h : env5852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5851_5852 : H12AffineEnvironment.transform 5 16 env5851 = env5852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5851 == env5852) = true)

theorem identity5852 : scanCanonicalize (H12AffineFastState.compose env5852 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115735) := by decide +kernel

theorem selectedBound5852 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5853 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115735,445,41002,8329,445,323713,16385,16813,22561,74795,78999,256,20480,95382,512]

theorem envBound5853 : H12AffineFastState.Bounded env5853 := by
  intro p hp
  have h : env5853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5852_5853 : H12AffineEnvironment.transform 21 115735 env5852 = env5853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115735 env5852 == env5853) = true)

theorem identity5853 : scanCanonicalize (H12AffineFastState.compose env5853 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound5853 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5854 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1024,32768,4097,41349,445,41002,8329,445,323713,16385,16813,22561,16825,20741,256,20480,4356,512]

theorem envBound5854 : H12AffineFastState.Bounded env5854 := by
  intro p hp
  have h : env5854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5853_5854 : H12AffineEnvironment.transform 15 26002 env5853 = env5854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env5853 == env5854) = true)

theorem identity5854 : scanCanonicalize (H12AffineFastState.compose env5854 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5854 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5855 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26002,4525,262144,1024,26260,4097,18193,445,18110,8329,445,267797,16385,16813,22561,16825,20741,256,20480,4356,512]

theorem envBound5855 : H12AffineFastState.Bounded env5855 := by
  intro p hp
  have h : env5855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5854_5855 : H12AffineEnvironment.transform 14 26260 env5854 = env5855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5854 == env5855) = true)

theorem identity5855 : scanCanonicalize (H12AffineFastState.compose env5855 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound5855 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5856 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26002,1213,262144,1024,26260,1297,18193,445,18110,8329,445,262917,16385,16813,19761,16825,17429,256,17680,1044,512]

theorem envBound5856 : H12AffineFastState.Bounded env5856 := by
  intro p hp
  have h : env5856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5855_5856 : H12AffineEnvironment.transform 11 1296 env5855 = env5856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env5855 == env5856) = true)

theorem identity5856 : scanCanonicalize (H12AffineFastState.compose env5856 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5856 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env5857 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1841,8613,8867,1213,262144,1024,8613,1297,32,445,399,8329,445,262917,1840,1692,2560,1672,804,256,545,1044,512]

theorem envBound5857 : H12AffineFastState.Bounded env5857 := by
  intro p hp
  have h : env5857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5856_5857 : H12AffineEnvironment.transform 13 1841 env5856 = env5857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env5856 == env5857) = true)

theorem identity5857 : scanCanonicalize (H12AffineFastState.compose env5857 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5857 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5858 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8200,8867,1213,262144,1024,8200,1212,32,16,34,8329,16,262824,1693,1692,2560,1672,649,173,545,1044,512]

theorem envBound5858 : H12AffineFastState.Bounded env5858 := by
  intro p hp
  have h : env5858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5857_5858 : H12AffineEnvironment.transform 7 173 env5857 = env5858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5857 == env5858) = true)

theorem identity5858 : scanCanonicalize (H12AffineFastState.compose env5858 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound5858 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5859 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8200,8867,1213,1582,1024,8200,1212,32,16,34,8329,16,1158,1693,1692,2560,1672,649,173,545,1044,512]

theorem envBound5859 : H12AffineFastState.Bounded env5859 := by
  intro p hp
  have h : env5859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5858_5859 : H12AffineEnvironment.transform 17 1582 env5858 = env5859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env5858 == env5859) = true)

def env5860 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4310442,41002,8329,4310443,323712,16385,16812,22560,74795,78999,256,20481,4239489,4310550]

theorem envBound5860 : H12AffineFastState.Bounded env5860 := by
  intro p hp
  have h : env5860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5851_5860 : H12AffineEnvironment.transform 5 17 env5851 = env5860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5851 == env5860) = true)

def env5861 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,65536,1196,262144,1024,32768,1281,4194304,4310442,41002,8329,4310443,320896,16385,16812,19744,74795,74135,256,17665,4236673,4310550]

theorem envBound5861 : H12AffineFastState.Bounded env5861 := by
  intro p hp
  have h : env5861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5860_5861 : H12AffineEnvironment.transform 11 1280 env5860 = env5861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env5860 == env5861) = true)

theorem identity5861 : scanCanonicalize (H12AffineFastState.compose env5861 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50215) := by decide +kernel

theorem selectedBound5861 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5862 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,50215,1196,262144,1024,32768,1281,4194304,4194701,41002,8329,4194700,320896,16385,16812,19744,57356,58800,256,17665,4236673,4194865]

theorem envBound5862 : H12AffineFastState.Bounded env5862 := by
  intro p hp
  have h : env5862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5861_5862 : H12AffineEnvironment.transform 15 50215 env5861 = env5862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50215 env5861 == env5862) = true)

def env5863 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50215,1196,262144,1024,32768,1281,4194304,4194701,41002,8329,4194700,320896,16385,16812,19744,57356,58784,256,17665,4236673,4194849]

theorem envBound5863 : H12AffineFastState.Bounded env5863 := by
  intro p hp
  have h : env5863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5862_5863 : H12AffineEnvironment.transform 3 0 env5862 = env5863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5862 == env5863) = true)

theorem identity5863 : scanCanonicalize (H12AffineFastState.compose env5863 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5863 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5864 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8201,25646,1196,262144,1024,8201,1281,4194304,4194701,35,8329,4194700,279945,16385,16812,19744,16389,17833,256,17665,4195720,4194849]

theorem envBound5864 : H12AffineFastState.Bounded env5864 := by
  intro p hp
  have h : env5864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5863_5864 : H12AffineEnvironment.transform 14 8201 env5863 = env5864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5863 == env5864) = true)

theorem identity5864 : scanCanonicalize (H12AffineFastState.compose env5864 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound5864 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5865 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8201,25646,1196,262144,1024,8201,1281,32,429,35,8329,428,279945,16385,16812,19744,16389,17833,256,17665,1448,513]

theorem envBound5865 : H12AffineFastState.Bounded env5865 := by
  intro p hp
  have h : env5865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5864_5865 : H12AffineEnvironment.transform 21 32 env5864 = env5865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env5864 == env5865) = true)

theorem identity5865 : scanCanonicalize (H12AffineFastState.compose env5865 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound5865 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5866 : List Nat := [2,4,8,0,32,1,128,256,292,1024,2048,1280,8192,16384,8201,25646,1196,262144,1024,8201,1281,32,429,35,8329,428,279945,16385,16812,19744,16389,17833,256,17665,1448,293]

theorem envBound5866 : H12AffineFastState.Bounded env5866 := by
  intro p hp
  have h : env5866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5865_5866 : H12AffineEnvironment.transform 8 292 env5865 = env5866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env5865 == env5866) = true)

theorem identity5866 : scanCanonicalize (H12AffineFastState.compose env5866 (packedSelected [1,2,3,11,12,15,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5866 : packedSelected [1,2,3,11,12,15,17,18,21] rootPS < 2^1333 := by decide +kernel

def env5867 : List Nat := [2,4,8,0,32,1,128,5,33,1024,2048,1029,8192,16384,8201,25646,1196,262144,1024,8201,1028,32,168,35,8329,169,279692,16385,16553,19493,16389,17580,5,17412,1197,32]

theorem envBound5867 : H12AffineFastState.Bounded env5867 := by
  intro p hp
  have h : env5867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5866_5867 : H12AffineEnvironment.transform 7 5 env5866 = env5867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5866 == env5867) = true)

theorem identity5867 : scanCanonicalize (H12AffineFastState.compose env5867 (packedSelected [0,1,4,6,7,9,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 3203) := by decide +kernel

theorem selectedBound5867 : packedSelected [0,1,4,6,7,9,13,15] rootPS < 2^1333 := by decide +kernel

def env5868 : List Nat := [2,4,8,0,32,1,128,5,33,1024,2048,1029,8192,3203,8201,10413,1196,262144,1024,8201,1028,32,168,35,8329,169,264207,3202,3114,166,3206,2095,5,2183,1197,32]

theorem envBound5868 : H12AffineFastState.Bounded env5868 := by
  intro p hp
  have h : env5868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5867_5868 : H12AffineEnvironment.transform 13 3203 env5867 = env5868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3203 env5867 == env5868) = true)

theorem identity5868 : scanCanonicalize (H12AffineFastState.compose env5868 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound5868 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5869 : List Nat := [2,4,8,0,32,1,128,5,33,1024,2048,1029,8192,3203,8201,10413,1196,2185,1024,8201,1028,32,168,35,8329,169,134,3202,3114,166,3206,2095,5,2183,1197,32]

theorem envBound5869 : H12AffineFastState.Bounded env5869 := by
  intro p hp
  have h : env5869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5868_5869 : H12AffineEnvironment.transform 17 2185 env5868 = env5869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env5868 == env5869) = true)

theorem identity5869 : scanCanonicalize (H12AffineFastState.compose env5869 (packedSelected [0,1,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 143) := by decide +kernel

theorem selectedBound5869 : packedSelected [0,1,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env5870 : List Nat := [2,4,8,0,32,1,128,5,33,1024,2048,1029,143,3203,134,2082,1196,2185,1024,134,1028,32,168,35,6,169,134,3202,3114,166,3206,2095,5,2183,1197,32]

theorem envBound5870 : H12AffineFastState.Bounded env5870 := by
  intro p hp
  have h : env5870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5869_5870 : H12AffineEnvironment.transform 12 143 env5869 = env5870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 143 env5869 == env5870) = true)

theorem identity5870 : scanCanonicalize (H12AffineFastState.compose env5870 (packedSelected [2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound5870 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5871 : List Nat := [2,4,8,0,32,1,128,5,33,135,2048,130,143,2052,134,2082,43,2185,135,134,131,32,168,35,6,169,134,2053,2221,166,2049,2095,5,2183,42,32]

theorem envBound5871 : H12AffineFastState.Bounded env5871 := by
  intro p hp
  have h : env5871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5870_5871 : H12AffineEnvironment.transform 9 135 env5870 = env5871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env5870 == env5871) = true)

theorem identity5871 : scanCanonicalize (H12AffineFastState.compose env5871 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound5871 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env5872 : List Nat := [2,4,8,0,32,1,35,5,33,36,2048,33,44,2052,37,2082,43,2090,36,37,32,32,11,35,6,10,37,2053,2062,5,2049,2095,5,2084,42,32]

theorem envBound5872 : H12AffineFastState.Bounded env5872 := by
  intro p hp
  have h : env5872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5871_5872 : H12AffineEnvironment.transform 6 35 env5871 = env5872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env5871 == env5872) = true)

theorem identity5872 : scanCanonicalize (H12AffineFastState.compose env5872 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound5872 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env5873 : List Nat := [2,4,8,0,32,1,35,5,33,36,42,33,44,46,37,8,43,0,36,37,32,32,11,35,6,10,37,47,36,5,43,5,5,14,42,32]

theorem envBound5873 : H12AffineFastState.Bounded env5873 := by
  intro p hp
  have h : env5873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5872_5873 : H12AffineEnvironment.transform 10 42 env5872 = env5873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env5872 == env5873) = true)

theorem identity5873 : scanCanonicalize (H12AffineFastState.compose env5873 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5873 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env5874 : List Nat := [2,4,3,0,32,1,35,5,33,36,33,33,39,37,37,3,32,0,36,37,32,32,0,35,6,1,37,36,36,5,32,5,5,5,33,32]

theorem envBound5874 : H12AffineFastState.Bounded env5874 := by
  intro p hp
  have h : env5874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5873_5874 : H12AffineEnvironment.transform 2 3 env5873 = env5874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5873 == env5874) = true)

theorem identity5874 : scanCanonicalize (H12AffineFastState.compose env5874 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound5874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5875 : List Nat := [2,4,3,0,4,1,7,5,5,0,5,5,3,1,1,3,4,0,0,1,4,4,0,7,6,1,1,0,0,5,4,5,5,5,5,4]

theorem envBound5875 : H12AffineFastState.Bounded env5875 := by
  intro p hp
  have h : env5875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5874_5875 : H12AffineEnvironment.transform 4 4 env5874 = env5875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env5874 == env5875) = true)

def leafEnv5875 : List Nat := [2,4,3,0,4,1,7,5,5,0,5,5,3,1,1,3,4,0,0,1,4,4,0,7,5,6,1,1,1,0,0,5,4,5,5,5,5,7,5,4,1,1,0]

def active5875 : List Nat := [0,1]

def tree5875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5875 : H12WitnessSearch.Good tree5875 := H12GlobalWitnessIndex.good

theorem leafIdentity5875 : H12AffineFastState.composeSystem env5875 rootObs = leafEnv5875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5875 rootObs == leafEnv5875) = true)

theorem terminalChecked5875 : H12PackedTerminal.terminalCheckFast leafEnv5875 active5875 tree5875 = true := by decide +kernel

def env5876 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1280,8192,16384,32768,50215,1196,262144,1024,32768,1281,4194304,4194701,41002,8329,4194700,320896,16385,16812,19744,57356,58785,256,17665,4236673,4194848]

theorem envBound5876 : H12AffineFastState.Bounded env5876 := by
  intro p hp
  have h : env5876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5862_5876 : H12AffineEnvironment.transform 3 1 env5862 = env5876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5862 == env5876) = true)

theorem identity5876 : scanCanonicalize (H12AffineFastState.compose env5876 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5876 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5877 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,32768,50215,1196,262144,1024,32768,1029,4194304,4194441,41002,8329,4194440,320644,16385,16552,19492,57356,58533,4,17413,4236421,4194848]

theorem envBound5877 : H12AffineFastState.Bounded env5877 := by
  intro p hp
  have h : env5877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5876_5877 : H12AffineEnvironment.transform 7 4 env5876 = env5877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5876 == env5877) = true)

theorem identity5877 : scanCanonicalize (H12AffineFastState.compose env5877 (packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5877 : packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS < 2^1333 := by decide +kernel

def env5878 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,32768,50215,1196,2081,1024,32768,1029,4194304,4194441,41002,8329,4194440,60581,16385,16552,19492,57356,58533,4,17413,4236421,4194848]

theorem envBound5878 : H12AffineFastState.Bounded env5878 := by
  intro p hp
  have h : env5878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5877_5878 : H12AffineEnvironment.transform 17 2081 env5877 = env5878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5877 == env5878) = true)

theorem identity5878 : scanCanonicalize (H12AffineFastState.compose env5878 (packedSelected [1,2,4,6,8,9,13,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 59906) := by decide +kernel

theorem selectedBound5878 : packedSelected [1,2,4,6,8,9,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5879 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,32768,50215,1196,2081,1024,32768,1029,59906,60043,41002,8329,60042,60581,16385,16552,19492,57356,58533,4,17413,20103,59426]

theorem envBound5879 : H12AffineFastState.Bounded env5879 := by
  intro p hp
  have h : env5879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5878_5879 : H12AffineEnvironment.transform 21 59906 env5878 = env5879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 59906 env5878 == env5879) = true)

theorem identity5879 : scanCanonicalize (H12AffineFastState.compose env5879 (packedSelected [1,2,4,6,8,9,17,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5879 : packedSelected [1,2,4,6,8,9,17,21,23] rootPS < 2^1333 := by decide +kernel

def env5880 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,8200,25647,1196,2081,1024,8200,1029,18954,19075,34,8329,19074,19629,16385,16552,19492,16388,17581,4,17413,20103,18474]

theorem envBound5880 : H12AffineFastState.Bounded env5880 := by
  intro p hp
  have h : env5880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5879_5880 : H12AffineEnvironment.transform 14 8200 env5879 = env5880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5879 == env5880) = true)

theorem identity5880 : scanCanonicalize (H12AffineFastState.compose env5880 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound5880 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5881 : List Nat := [2,4,8,1,32,0,128,4,512,1024,1583,1028,8192,16384,8200,25647,1196,1550,1024,8200,1029,17445,17580,34,8329,17581,17026,16385,16552,16907,16388,17581,4,17413,16552,17925]

theorem envBound5881 : H12AffineFastState.Bounded env5881 := by
  intro p hp
  have h : env5881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5880_5881 : H12AffineEnvironment.transform 10 1583 env5880 = env5881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env5880 == env5881) = true)

theorem identity5881 : scanCanonicalize (H12AffineFastState.compose env5881 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 8739) := by decide +kernel

theorem selectedBound5881 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5882 : List Nat := [2,4,8,1,32,0,128,4,512,1024,1583,1028,8192,8739,8200,1548,1196,1550,1024,8200,1029,9734,9871,34,8329,9870,8353,8738,8843,8232,8743,9870,4,9766,8843,9254]

theorem envBound5882 : H12AffineFastState.Bounded env5882 := by
  intro p hp
  have h : env5882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5881_5882 : H12AffineEnvironment.transform 13 8739 env5881 = env5882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8739 env5881 == env5882) = true)

theorem identity5882 : scanCanonicalize (H12AffineFastState.compose env5882 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1549) := by decide +kernel

theorem selectedBound5882 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env5883 : List Nat := [2,4,8,1,32,0,128,4,512,1024,1583,1028,1549,1070,1541,1548,1196,1550,1024,1541,1029,11,130,34,1668,131,1708,1071,1158,1573,1066,131,4,43,1158,555]

theorem envBound5883 : H12AffineFastState.Bounded env5883 := by
  intro p hp
  have h : env5883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5882_5883 : H12AffineEnvironment.transform 12 1549 env5882 = env5883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1549 env5882 == env5883) = true)

theorem identity5883 : scanCanonicalize (H12AffineFastState.compose env5883 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5883 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5884 : List Nat := [2,4,8,1,32,0,128,4,512,14,545,10,515,32,523,514,162,512,14,523,11,11,130,34,650,131,674,33,136,555,36,131,4,43,136,555]

theorem envBound5884 : H12AffineFastState.Bounded env5884 := by
  intro p hp
  have h : env5884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5883_5884 : H12AffineEnvironment.transform 9 14 env5883 = env5884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5883 == env5884) = true)

theorem identity5884 : scanCanonicalize (H12AffineFastState.compose env5884 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5884 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env5885 : List Nat := [2,4,8,1,11,0,128,4,512,14,522,10,515,11,523,514,137,512,14,523,11,11,130,9,650,131,649,10,136,512,15,131,4,0,136,512]

theorem envBound5885 : H12AffineFastState.Bounded env5885 := by
  intro p hp
  have h : env5885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5884_5885 : H12AffineEnvironment.transform 4 11 env5884 = env5885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5884 == env5885) = true)

theorem identity5885 : scanCanonicalize (H12AffineFastState.compose env5885 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5885 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5886 : List Nat := [2,4,8,1,11,0,3,4,512,14,522,10,515,11,523,514,10,512,14,523,11,11,1,9,521,0,522,10,11,512,15,0,4,0,11,512]

theorem envBound5886 : H12AffineFastState.Bounded env5886 := by
  intro p hp
  have h : env5886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5885_5886 : H12AffineEnvironment.transform 6 3 env5885 = env5886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5885 == env5886) = true)

def env5887 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,65536,1197,262144,1024,32768,1280,4194304,4310442,41002,8329,4310443,320897,16385,16812,19745,74795,74134,256,17664,4236672,4310550]

theorem envBound5887 : H12AffineFastState.Bounded env5887 := by
  intro p hp
  have h : env5887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5860_5887 : H12AffineEnvironment.transform 11 1281 env5860 = env5887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env5860 == env5887) = true)

theorem identity5887 : scanCanonicalize (H12AffineFastState.compose env5887 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50586) := by decide +kernel

theorem selectedBound5887 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5888 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,50586,1197,262144,1024,32768,1280,4194304,4194352,41002,8329,4194353,320897,16385,16812,19745,57777,58380,256,17664,4236672,4195212]

theorem envBound5888 : H12AffineFastState.Bounded env5888 := by
  intro p hp
  have h : env5888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5887_5888 : H12AffineEnvironment.transform 15 50586 env5887 = env5888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50586 env5887 == env5888) = true)

def env5889 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50570,1197,262144,1024,32768,1280,4194304,4194336,41002,8329,4194337,320897,16385,16812,19745,57761,58380,256,17664,4236672,4195212]

theorem envBound5889 : H12AffineFastState.Bounded env5889 := by
  intro p hp
  have h : env5889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5888_5889 : H12AffineEnvironment.transform 3 0 env5888 = env5889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5888 == env5889) = true)

def env5890 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50570,1197,262144,1024,32768,1280,41088,41120,41002,8329,41121,320897,16385,16812,19745,57761,58380,256,17664,1280,41740]

theorem envBound5890 : H12AffineFastState.Bounded env5890 := by
  intro p hp
  have h : env5890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5889_5890 : H12AffineEnvironment.transform 21 41088 env5889 = env5890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5889 == env5890) = true)

theorem identity5890 : scanCanonicalize (H12AffineFastState.compose env5890 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5890 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5891 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,16384,32768,50319,1197,262144,1024,32768,1029,41088,41120,41002,8329,41121,320644,16385,16553,19492,57508,58380,5,17413,1029,41481]

theorem envBound5891 : H12AffineFastState.Bounded env5891 := by
  intro p hp
  have h : env5891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5890_5891 : H12AffineEnvironment.transform 7 5 env5890 = env5891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5890 == env5891) = true)

theorem identity5891 : scanCanonicalize (H12AffineFastState.compose env5891 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound5891 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5892 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,1676,32768,33283,1197,262144,1024,32768,1029,41088,41120,41002,8329,41121,303624,1677,1573,2728,42536,41600,5,649,1029,41481]

theorem envBound5892 : H12AffineFastState.Bounded env5892 := by
  intro p hp
  have h : env5892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5891_5892 : H12AffineEnvironment.transform 13 1676 env5891 = env5892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env5891 == env5892) = true)

theorem identity5892 : scanCanonicalize (H12AffineFastState.compose env5892 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5892 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env5893 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,1676,8201,8714,1197,262144,1024,8201,1029,137,169,35,8329,168,262657,1677,1573,2728,1569,649,5,649,1029,512]

theorem envBound5893 : H12AffineFastState.Bounded env5893 := by
  intro p hp
  have h : env5893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5892_5893 : H12AffineEnvironment.transform 14 8201 env5892 = env5893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5892 == env5893) = true)

theorem identity5893 : scanCanonicalize (H12AffineFastState.compose env5893 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 11428) := by decide +kernel

theorem selectedBound5893 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env5894 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,1676,8201,8714,1197,11428,1024,8201,1029,137,169,35,8329,168,11941,1677,1573,2728,1569,649,5,649,1029,512]

theorem envBound5894 : H12AffineFastState.Bounded env5894 := by
  intro p hp
  have h : env5894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5893_5894 : H12AffineEnvironment.transform 17 11428 env5893 = env5894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11428 env5893 == env5894) = true)

theorem identity5894 : scanCanonicalize (H12AffineFastState.compose env5894 (packedSelected [0,4,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2594) := by decide +kernel

theorem selectedBound5894 : packedSelected [0,4,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env5895 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,2594,1676,2603,2088,1197,1670,1024,2603,1029,137,169,35,2731,168,1159,1677,1573,2728,1569,649,5,649,1029,512]

theorem envBound5895 : H12AffineFastState.Bounded env5895 := by
  intro p hp
  have h : env5895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5894_5895 : H12AffineEnvironment.transform 12 2594 env5894 = env5895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2594 env5894 == env5895) = true)

def env5896 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50570,1197,262144,1024,32768,1280,41089,41121,41002,8329,41120,320897,16385,16812,19745,57761,58380,256,17664,1281,41741]

theorem envBound5896 : H12AffineFastState.Bounded env5896 := by
  intro p hp
  have h : env5896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5889_5896 : H12AffineEnvironment.transform 21 41089 env5889 = env5896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5889 == env5896) = true)

theorem identity5896 : scanCanonicalize (H12AffineFastState.compose env5896 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5896 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5897 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8201,25987,1197,262144,1024,8201,1280,136,168,35,8329,169,279944,16385,16812,19745,16808,17413,256,17664,1281,772]

theorem envBound5897 : H12AffineFastState.Bounded env5897 := by
  intro p hp
  have h : env5897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5896_5897 : H12AffineEnvironment.transform 14 8201 env5896 = env5897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5896 == env5897) = true)

theorem identity5897 : scanCanonicalize (H12AffineFastState.compose env5897 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20141) := by decide +kernel

theorem selectedBound5897 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5898 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8201,25987,1197,20141,1024,8201,1280,136,168,35,8329,169,2853,16385,16812,19745,16808,17413,256,17664,1281,772]

theorem envBound5898 : H12AffineFastState.Bounded env5898 := by
  intro p hp
  have h : env5898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5897_5898 : H12AffineEnvironment.transform 17 20141 env5897 = env5898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20141 env5897 == env5898) = true)

theorem identity5898 : scanCanonicalize (H12AffineFastState.compose env5898 (packedSelected [1,5,10,12,13,15,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5898 : packedSelected [1,5,10,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env5899 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,1029,8192,16384,8201,25735,1197,20141,1024,8201,1028,136,168,35,8329,169,2593,16385,16552,19493,16556,17413,4,17412,1029,512]

theorem envBound5899 : H12AffineFastState.Bounded env5899 := by
  intro p hp
  have h : env5899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5898_5899 : H12AffineEnvironment.transform 7 4 env5898 = env5899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5898 == env5899) = true)

theorem identity5899 : scanCanonicalize (H12AffineFastState.compose env5899 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 3716) := by decide +kernel

theorem selectedBound5899 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env5900 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,1029,3716,16384,3725,18947,1197,20141,1024,3725,1028,136,168,35,3597,169,2593,16385,16552,19493,16556,17413,4,17412,1029,512]

theorem envBound5900 : H12AffineFastState.Bounded env5900 := by
  intro p hp
  have h : env5900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5899_5900 : H12AffineEnvironment.transform 12 3716 env5899 = env5900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3716 env5899 == env5900) = true)

theorem identity5900 : scanCanonicalize (H12AffineFastState.compose env5900 (packedSelected [0,2,3,4,7,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 3718) := by decide +kernel

theorem selectedBound5900 : packedSelected [0,2,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env5901 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,1029,3716,3718,3725,1157,1197,43,1024,3725,1028,136,168,35,3597,169,2593,3719,3630,675,3626,2691,4,2690,1029,512]

theorem envBound5901 : H12AffineFastState.Bounded env5901 := by
  intro p hp
  have h : env5901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5900_5901 : H12AffineEnvironment.transform 13 3718 env5900 = env5901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3718 env5900 == env5901) = true)

theorem identity5901 : scanCanonicalize (H12AffineFastState.compose env5901 (packedSelected [2,3,6,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound5901 : packedSelected [2,3,6,10,17] rootPS < 2^1333 := by decide +kernel

def env5902 : List Nat := [2,4,8,0,32,1,128,4,512,1024,10,1029,1678,1676,1671,1157,1197,43,1024,1671,1028,136,168,35,1543,169,555,1677,1572,675,1568,649,4,648,1029,512]

theorem envBound5902 : H12AffineFastState.Bounded env5902 := by
  intro p hp
  have h : env5902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5901_5902 : H12AffineEnvironment.transform 10 10 env5901 = env5902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env5901 == env5902) = true)

theorem identity5902 : scanCanonicalize (H12AffineFastState.compose env5902 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound5902 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env5903 : List Nat := [2,4,8,0,32,1,128,4,512,5,10,0,651,649,642,128,168,43,5,642,1,136,168,35,514,169,555,648,545,675,549,649,4,648,0,512]

theorem envBound5903 : H12AffineFastState.Bounded env5903 := by
  intro p hp
  have h : env5903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5902_5903 : H12AffineEnvironment.transform 9 5 env5902 = env5903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env5902 == env5903) = true)

theorem identity5903 : scanCanonicalize (H12AffineFastState.compose env5903 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5903 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5904 : List Nat := [2,4,8,0,32,1,3,4,512,5,10,0,520,522,513,3,43,43,5,513,1,11,43,35,514,42,555,523,545,544,549,522,4,523,0,512]

theorem envBound5904 : H12AffineFastState.Bounded env5904 := by
  intro p hp
  have h : env5904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5903_5904 : H12AffineEnvironment.transform 6 3 env5903 = env5904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5903 == env5904) = true)

theorem identity5904 : scanCanonicalize (H12AffineFastState.compose env5904 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound5904 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env5905 : List Nat := [2,4,8,0,32,1,3,4,42,5,10,0,34,32,43,3,43,43,5,43,1,11,43,35,40,42,1,33,11,10,15,32,4,33,0,42]

theorem envBound5905 : H12AffineFastState.Bounded env5905 := by
  intro p hp
  have h : env5905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5904_5905 : H12AffineEnvironment.transform 8 42 env5904 = env5905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env5904 == env5905) = true)

def env5906 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1281,8192,16384,32768,50571,1197,262144,1024,32768,1280,4194304,4194337,41002,8329,4194336,320897,16385,16812,19745,57760,58380,256,17664,4236672,4195212]

theorem envBound5906 : H12AffineFastState.Bounded env5906 := by
  intro p hp
  have h : env5906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5888_5906 : H12AffineEnvironment.transform 3 1 env5888 = env5906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5888 == env5906) = true)

theorem identity5906 : scanCanonicalize (H12AffineFastState.compose env5906 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound5906 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5907 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1281,8192,16384,8460,25735,1197,262144,1024,8460,1280,4194304,4194337,294,8329,4194336,279693,16385,16812,19745,16556,17664,256,17664,4195468,4195212]

theorem envBound5907 : H12AffineFastState.Bounded env5907 := by
  intro p hp
  have h : env5907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5906_5907 : H12AffineEnvironment.transform 14 8460 env5906 = env5907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env5906 == env5907) = true)

theorem identity5907 : scanCanonicalize (H12AffineFastState.compose env5907 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5907 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5908 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8201,25735,1197,262144,1024,8201,1029,4194304,4194337,35,8329,4194336,279693,16385,16553,19492,16556,17413,5,17413,4195468,4194953]

theorem envBound5908 : H12AffineFastState.Bounded env5908 := by
  intro p hp
  have h : env5908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5907_5908 : H12AffineEnvironment.transform 7 5 env5907 = env5908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5907 == env5908) = true)

theorem identity5908 : scanCanonicalize (H12AffineFastState.compose env5908 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound5908 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5909 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8201,25735,1197,2184,1024,8201,1029,4194304,4194337,35,8329,4194336,19461,16385,16553,19492,16556,17413,5,17413,4195468,4194953]

theorem envBound5909 : H12AffineFastState.Bounded env5909 := by
  intro p hp
  have h : env5909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5908_5909 : H12AffineEnvironment.transform 17 2184 env5908 = env5909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env5908 == env5909) = true)

theorem identity5909 : scanCanonicalize (H12AffineFastState.compose env5909 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5909 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env5910 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8201,25735,1165,2184,1024,8201,1029,4194304,4194305,3,8329,4194304,19461,16385,16521,19460,16524,17413,5,17413,4195468,4194953]

theorem envBound5910 : H12AffineFastState.Bounded env5910 := by
  intro p hp
  have h : env5910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5909_5910 : H12AffineEnvironment.transform 4 0 env5909 = env5910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5909 == env5910) = true)

theorem identity5910 : scanCanonicalize (H12AffineFastState.compose env5910 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 10378) := by decide +kernel

theorem selectedBound5910 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env5911 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8201,25735,1165,2184,1024,8201,1029,10378,10379,3,8329,10378,19461,16385,16521,19460,16524,17413,5,17413,11270,10755]

theorem envBound5911 : H12AffineFastState.Bounded env5911 := by
  intro p hp
  have h : env5911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5910_5911 : H12AffineEnvironment.transform 21 10378 env5910 = env5911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10378 env5910 == env5911) = true)

theorem identity5911 : scanCanonicalize (H12AffineFastState.compose env5911 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound5911 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env5912 : List Nat := [2,4,8,1,0,0,9,5,512,1024,2048,1028,8192,16384,8201,25614,1028,2049,1024,8201,1029,10243,10242,3,8192,10243,19461,16385,16384,19460,16389,17413,5,17413,11270,10755]

theorem envBound5912 : H12AffineFastState.Bounded env5912 := by
  intro p hp
  have h : env5912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5911_5912 : H12AffineEnvironment.transform 6 9 env5911 = env5912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env5911 == env5912) = true)

theorem identity5912 : scanCanonicalize (H12AffineFastState.compose env5912 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound5912 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5913 : List Nat := [2,4,8,1,0,0,9,5,512,1024,2048,1028,2562,16384,2571,19980,1028,2049,1024,2571,1029,513,512,3,2562,513,19461,16385,16384,19460,16389,17413,5,17413,1540,1]

theorem envBound5913 : H12AffineFastState.Bounded env5913 := by
  intro p hp
  have h : env5913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5912_5913 : H12AffineEnvironment.transform 12 2562 env5912 = env5913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env5912 == env5913) = true)

theorem identity5913 : scanCanonicalize (H12AffineFastState.compose env5913 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound5913 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5914 : List Nat := [2,4,8,1,0,0,9,5,512,1024,2048,1028,2562,1029,2571,2569,1028,2049,1024,2571,1029,513,512,3,2562,513,2048,1028,1029,2049,1024,0,5,0,1540,1]

theorem envBound5914 : H12AffineFastState.Bounded env5914 := by
  intro p hp
  have h : env5914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5913_5914 : H12AffineEnvironment.transform 13 1029 env5913 = env5914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env5913 == env5914) = true)

theorem identity5914 : scanCanonicalize (H12AffineFastState.compose env5914 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5915 : List Nat := [2,4,8,1,0,0,9,5,512,1024,1540,1028,1030,1029,1039,1037,1028,1541,1024,1039,1029,513,512,3,1030,513,1540,1028,1029,1541,1024,0,5,0,1540,1]

theorem envBound5915 : H12AffineFastState.Bounded env5915 := by
  intro p hp
  have h : env5915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5914_5915 : H12AffineEnvironment.transform 10 1540 env5914 = env5915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env5914 == env5915) = true)

theorem identity5915 : scanCanonicalize (H12AffineFastState.compose env5915 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound5915 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5916 : List Nat := [2,4,8,1,0,0,9,5,512,527,11,523,521,522,512,514,523,10,527,512,522,513,512,3,521,513,11,523,522,10,527,0,5,0,11,1]

theorem envBound5916 : H12AffineFastState.Bounded env5916 := by
  intro p hp
  have h : env5916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5915_5916 : H12AffineEnvironment.transform 9 527 env5915 = env5916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env5915 == env5916) = true)

theorem identity5916 : scanCanonicalize (H12AffineFastState.compose env5916 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5916 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env5917 : List Nat := [2,4,2,1,0,0,3,5,512,517,1,513,515,512,512,514,513,0,517,512,512,513,512,3,515,513,1,513,512,0,517,0,5,0,1,1]

theorem envBound5917 : H12AffineFastState.Bounded env5917 := by
  intro p hp
  have h : env5917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5916_5917 : H12AffineEnvironment.transform 2 2 env5916 = env5917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5916 == env5917) = true)

theorem identity5917 : scanCanonicalize (H12AffineFastState.compose env5917 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5917 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env5918 : List Nat := [2,4,2,1,0,0,3,5,1,4,1,0,2,1,1,3,0,0,4,1,1,0,1,3,2,0,1,0,1,0,4,0,5,0,1,1]

theorem envBound5918 : H12AffineFastState.Bounded env5918 := by
  intro p hp
  have h : env5918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5917_5918 : H12AffineEnvironment.transform 8 1 env5917 = env5918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5917 == env5918) = true)

def env5919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323792,16385,16893,22640,74794,12644669,257,20561,4239489,8389612]

theorem envBound5919 : H12AffineFastState.Bounded env5919 := by
  intro p hp
  have h : env5919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5849_5919 : H12AffineEnvironment.transform 18 1025 env5849 = env5919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5849 == env5919) = true)

theorem identity5919 : scanCanonicalize (H12AffineFastState.compose env5919 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98475) := by decide +kernel

theorem selectedBound5919 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,98475,8388608,41002,8329,8388689,323792,16385,16893,22640,74794,8483222,257,20561,77866,8389612]

theorem envBound5920 : H12AffineFastState.Bounded env5920 := by
  intro p hp
  have h : env5920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5919_5920 : H12AffineEnvironment.transform 21 98475 env5919 = env5920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98475 env5919 == env5920) = true)

def env5921 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98475,8388608,41002,8329,8388609,323712,16385,16813,22560,74794,8483222,257,20481,77866,8389564]

theorem envBound5921 : H12AffineFastState.Bounded env5921 := by
  intro p hp
  have h : env5921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5920_5921 : H12AffineEnvironment.transform 5 16 env5920 = env5921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5920 == env5921) = true)

def env5922 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98307,8388608,41002,8225,8388609,323624,16385,16645,22560,74794,8483134,257,20481,77866,8389396]

theorem envBound5922 : H12AffineFastState.Bounded env5922 := by
  intro p hp
  have h : env5922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5921_5922 : H12AffineEnvironment.transform 6 40 env5921 = env5922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5921 == env5922) = true)

theorem identity5922 : scanCanonicalize (H12AffineFastState.compose env5922 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 284980) := by decide +kernel

theorem selectedBound5922 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env5923 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98307,284980,41002,8225,284981,323624,16385,16645,22560,74794,337930,257,20481,77866,285216]

theorem envBound5923 : H12AffineFastState.Bounded env5923 := by
  intro p hp
  have h : env5923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5922_5923 : H12AffineEnvironment.transform 22 284980 env5922 = env5923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284980 env5922 == env5923) = true)

theorem identity5923 : scanCanonicalize (H12AffineFastState.compose env5923 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5923 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env5924 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,2080,1025,32768,4097,98307,20756,41002,8225,20757,63496,16385,16645,22560,74794,73770,257,20481,77866,20992]

theorem envBound5924 : H12AffineFastState.Bounded env5924 := by
  intro p hp
  have h : env5924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5923_5924 : H12AffineEnvironment.transform 17 2080 env5923 = env5924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5923 == env5924) = true)

theorem identity5924 : scanCanonicalize (H12AffineFastState.compose env5924 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound5924 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5925 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8460,65536,4357,2080,1025,8460,4097,73999,20756,294,8225,20757,22788,16385,16645,22560,74794,73770,257,20481,77866,20992]

theorem envBound5925 : H12AffineFastState.Bounded env5925 := by
  intro p hp
  have h : env5925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5924_5925 : H12AffineEnvironment.transform 14 8460 env5924 = env5925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env5924 == env5925) = true)

theorem identity5925 : scanCanonicalize (H12AffineFastState.compose env5925 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11545) := by decide +kernel

theorem selectedBound5925 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5926 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,11545,8460,65536,4357,2080,1025,8460,4097,73999,15373,294,8225,15372,13341,11544,11292,13625,74794,73770,257,15640,77866,16153]

theorem envBound5926 : H12AffineFastState.Bounded env5926 := by
  intro p hp
  have h : env5926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5925_5926 : H12AffineEnvironment.transform 13 11545 env5925 = env5926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11545 env5925 == env5926) = true)

theorem identity5926 : scanCanonicalize (H12AffineFastState.compose env5926 (packedSelected [1,2,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 7960) := by decide +kernel

theorem selectedBound5926 : packedSelected [1,2,5,11] rootPS < 2^1333 := by decide +kernel

def env5927 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,7960,4609,7700,65536,4357,2080,1025,7700,4097,73239,789,294,7993,788,2821,4608,4868,2593,72498,73522,257,512,69426,1]

theorem envBound5927 : H12AffineFastState.Bounded env5927 := by
  intro p hp
  have h : env5927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5926_5927 : H12AffineEnvironment.transform 12 7960 env5926 = env5927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7960 env5926 == env5927) = true)

theorem identity5927 : scanCanonicalize (H12AffineFastState.compose env5927 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5927 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env5928 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1588,2348,1077,2080,65536,1841,2080,1025,2080,1589,67619,789,294,2317,788,2821,1076,1328,2593,68870,67846,257,512,69426,1]

theorem envBound5928 : H12AffineFastState.Bounded env5928 := by
  intro p hp
  have h : env5928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5927_5928 : H12AffineEnvironment.transform 11 1588 env5927 = env5928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env5927 == env5928) = true)

theorem identity5928 : scanCanonicalize (H12AffineFastState.compose env5928 (packedSelected [0,1,2,5,6,9] rootPS)) = affineNative (2^(15+1) ^^^ 2822) := by decide +kernel

theorem selectedBound5928 : packedSelected [0,1,2,5,6,9] rootPS < 2^1333 := by decide +kernel

def env5929 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1588,2348,1077,2080,2822,1841,2080,1025,2080,1589,805,789,294,2317,788,2821,1076,1328,2593,1536,512,257,512,1076,1]

theorem envBound5929 : H12AffineFastState.Bounded env5929 := by
  intro p hp
  have h : env5929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5928_5929 : H12AffineEnvironment.transform 15 2822 env5928 = env5929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2822 env5928 == env5929) = true)

theorem identity5929 : scanCanonicalize (H12AffineFastState.compose env5929 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1291) := by decide +kernel

theorem selectedBound5929 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5930 : List Nat := [2,4,8,16,32,16,40,256,512,1024,1291,1588,1063,1077,1323,1549,1841,1323,1025,1323,1589,805,789,294,1030,788,1550,1076,1328,1834,1536,512,257,512,1076,1]

theorem envBound5930 : H12AffineFastState.Bounded env5930 := by
  intro p hp
  have h : env5930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5929_5930 : H12AffineEnvironment.transform 10 1291 env5929 = env5930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1291 env5929 == env5930) = true)

theorem identity5930 : scanCanonicalize (H12AffineFastState.compose env5930 (packedSelected [0,4,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5930 : packedSelected [0,4,10,13] rootPS < 2^1333 := by decide +kernel

def env5931 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1039,1588,1063,1077,1071,1549,1589,1071,1025,1071,1589,545,529,34,1030,528,1550,1076,1076,1582,1536,512,5,512,1076,1]

theorem envBound5931 : H12AffineFastState.Bounded env5931 := by
  intro p hp
  have h : env5931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5930_5931 : H12AffineEnvironment.transform 7 4 env5930 = env5931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5930 == env5931) = true)

theorem identity5931 : scanCanonicalize (H12AffineFastState.compose env5931 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound5931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5932 : List Nat := [2,4,8,16,32,16,40,4,512,565,570,1,530,512,538,56,0,538,564,538,0,545,529,34,563,528,59,513,513,27,53,512,5,512,513,1]

theorem envBound5932 : H12AffineFastState.Bounded env5932 := by
  intro p hp
  have h : env5932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5931_5932 : H12AffineEnvironment.transform 9 565 env5931 = env5932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env5931 == env5932) = true)

theorem identity5932 : scanCanonicalize (H12AffineFastState.compose env5932 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound5932 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5933 : List Nat := [2,4,8,16,32,16,40,4,27,46,33,1,9,27,1,56,0,1,47,1,0,58,10,34,40,11,59,26,26,27,53,27,5,27,26,1]

theorem envBound5933 : H12AffineFastState.Bounded env5933 := by
  intro p hp
  have h : env5933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5932_5933 : H12AffineEnvironment.transform 8 27 env5932 = env5933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env5932 == env5933) = true)

def env5934 : List Nat := [2,4,8,4,32,4,40,4,15,46,33,1,9,15,1,44,0,1,47,1,0,46,10,34,40,11,47,14,14,15,33,15,5,15,14,1]

theorem envBound5934 : H12AffineFastState.Bounded env5934 := by
  intro p hp
  have h : env5934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5933_5934 : H12AffineEnvironment.transform 3 4 env5933 = env5934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5933 == env5934) = true)

def env5935 : List Nat := [2,4,8,5,32,5,40,4,14,46,33,1,9,14,1,45,0,1,47,1,0,47,10,34,40,11,46,15,15,14,32,14,5,14,15,1]

theorem envBound5935 : H12AffineFastState.Bounded env5935 := by
  intro p hp
  have h : env5935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5933_5935 : H12AffineEnvironment.transform 3 5 env5933 = env5935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5933 == env5935) = true)

theorem identity5935 : scanCanonicalize (H12AffineFastState.compose env5935 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5936 : List Nat := [2,4,6,5,32,5,38,4,0,32,33,1,7,0,1,35,0,1,33,1,0,33,4,34,38,5,32,1,1,0,32,0,5,0,1,1]

theorem envBound5936 : H12AffineFastState.Bounded env5936 := by
  intro p hp
  have h : env5936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5935_5936 : H12AffineEnvironment.transform 2 6 env5935 = env5936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5935 == env5936) = true)

theorem identity5936 : scanCanonicalize (H12AffineFastState.compose env5936 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5936 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5937 : List Nat := [2,0,2,1,32,1,34,0,0,32,33,1,3,0,1,35,0,1,33,1,0,33,0,34,34,1,32,1,1,0,32,0,1,0,1,1]

theorem envBound5937 : H12AffineFastState.Bounded env5937 := by
  intro p hp
  have h : env5937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5936_5937 : H12AffineEnvironment.transform 1 0 env5936 = env5937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5936 == env5937) = true)

def leafEnv5937 : List Nat := [2,0,2,1,32,1,34,0,0,32,33,1,3,0,1,35,0,1,33,1,0,33,0,34,33,34,1,1,32,1,1,0,32,0,1,0,1,2,1,1,1,1,0]

def active5937 : List Nat := [0,4]

def tree5937 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5937 : H12WitnessSearch.Good tree5937 := H12GlobalWitnessIndex.good

theorem leafIdentity5937 : H12AffineFastState.composeSystem env5937 rootObs = leafEnv5937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5937 rootObs == leafEnv5937) = true)

theorem terminalChecked5937 : H12PackedTerminal.terminalCheckFast leafEnv5937 active5937 tree5937 = true := by decide +kernel

def env5938 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98306,8388608,41002,8224,8388609,323625,16385,16644,22560,74794,8483135,257,20481,77866,8389397]

theorem envBound5938 : H12AffineFastState.Bounded env5938 := by
  intro p hp
  have h : env5938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5921_5938 : H12AffineEnvironment.transform 6 41 env5921 = env5938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5921 == env5938) = true)

theorem identity5938 : scanCanonicalize (H12AffineFastState.compose env5938 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 74046) := by decide +kernel

theorem selectedBound5938 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env5939 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98306,74046,41002,8224,74047,323625,16385,16644,22560,74794,20481,257,20481,77866,74283]

theorem envBound5939 : H12AffineFastState.Bounded env5939 := by
  intro p hp
  have h : env5939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5938_5939 : H12AffineEnvironment.transform 22 74046 env5938 = env5939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 74046 env5938 == env5939) = true)

theorem identity5939 : scanCanonicalize (H12AffineFastState.compose env5939 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5939 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5940 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4097,98306,73786,41002,8224,73787,323625,16385,16384,22560,74794,20481,5,20481,77866,74283]

theorem envBound5940 : H12AffineFastState.Bounded env5940 := by
  intro p hp
  have h : env5940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5939_5940 : H12AffineEnvironment.transform 7 4 env5939 = env5940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5939 == env5940) = true)

theorem identity5940 : scanCanonicalize (H12AffineFastState.compose env5940 (packedSelected [7,13,17,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 120834) := by decide +kernel

theorem selectedBound5940 : packedSelected [7,13,17,20,27] rootPS < 2^1333 := by decide +kernel

def env5941 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4096,120834,1025,32768,4097,98306,73786,41002,8224,73787,75819,16385,16384,22560,74794,20481,5,20481,77866,74283]

theorem envBound5941 : H12AffineFastState.Bounded env5941 := by
  intro p hp
  have h : env5941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5940_5941 : H12AffineEnvironment.transform 17 120834 env5940 = env5941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 120834 env5940 == env5941) = true)

theorem identity5941 : scanCanonicalize (H12AffineFastState.compose env5941 (packedSelected [2,3,5,6,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5941 : packedSelected [2,3,5,6,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5942 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,1550,65536,4096,89612,1025,1550,4097,67084,73786,9764,8224,73787,75819,16385,16384,22560,74794,20481,5,20481,77866,74283]

theorem envBound5942 : H12AffineFastState.Bounded env5942 := by
  intro p hp
  have h : env5942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5941_5942 : H12AffineEnvironment.transform 14 1550 env5941 = env5942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1550 env5941 == env5942) = true)

theorem identity5942 : scanCanonicalize (H12AffineFastState.compose env5942 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 22060) := by decide +kernel

theorem selectedBound5942 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5943 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,1550,22060,4096,2080,1025,1550,4097,20512,30230,9764,8224,30231,32263,16385,16384,22560,29190,20481,5,20481,26118,29703]

theorem envBound5943 : H12AffineFastState.Bounded env5943 := by
  intro p hp
  have h : env5943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5942_5943 : H12AffineEnvironment.transform 15 22060 env5942 = env5943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 22060 env5942 == env5943) = true)

theorem identity5943 : scanCanonicalize (H12AffineFastState.compose env5943 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound5943 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0