import H12CloudChart0Data154

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound39297 : H12AffineFastState.Bounded env39297 := by
  intro p hp
  have h : env39297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39296_39297 : H12AffineEnvironment.transform 15 30042 env39296 = env39297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env39296 == env39297) = true)

theorem identity39297 : scanCanonicalize (H12AffineFastState.compose env39297 (packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound39297 : packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,38209,35188,1024,32769,4161,8573,16,62479,8192,65,31756,5392,17665,56356,1365,54560,256,21793,46092,22352]

theorem envBound39298 : H12AffineFastState.Bounded env39298 := by
  intro p hp
  have h : env39298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39297_39298 : H12AffineEnvironment.transform 21 8573 env39297 = env39298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env39297 == env39298) = true)

theorem identity39298 : scanCanonicalize (H12AffineFastState.compose env39298 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound39298 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,30042,16401,23588,1024,21841,4161,8573,16,8543,8192,65,31756,5392,17665,2420,1365,112,256,21793,24924,22352]

theorem envBound39299 : H12AffineFastState.Bounded env39299 := by
  intro p hp
  have h : env39299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39298_39299 : H12AffineEnvironment.transform 14 21840 env39298 = env39299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env39298 == env39299) = true)

theorem identity39299 : scanCanonicalize (H12AffineFastState.compose env39299 (packedSelected [3,4,5,6,7,12,14,15,16,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound39299 : packedSelected [3,4,5,6,7,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env39300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1557,4096,8192,16384,21840,30042,16401,21041,1024,21841,4161,8573,16,8543,8192,65,29209,5392,17665,1889,1365,112,256,21793,24924,22352]

theorem envBound39300 : H12AffineFastState.Bounded env39300 := by
  intro p hp
  have h : env39300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39299_39300 : H12AffineEnvironment.transform 10 1557 env39299 = env39300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env39299 == env39300) = true)

theorem identity39300 : scanCanonicalize (H12AffineFastState.compose env39300 (packedSelected [0,4,5,8,10,11,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13853) := by decide +kernel

theorem selectedBound39300 : packedSelected [0,4,5,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env39301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1557,4096,8192,13853,9037,839,13836,9260,1024,9036,4161,8573,16,8543,8192,65,1028,5392,13084,1889,1365,112,256,9020,5953,8525]

theorem envBound39301 : H12AffineFastState.Bounded env39301 := by
  intro p hp
  have h : env39301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39300_39301 : H12AffineEnvironment.transform 13 13853 env39300 = env39301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13853 env39300 == env39301) = true)

theorem identity39301 : scanCanonicalize (H12AffineFastState.compose env39301 (packedSelected [0,2,5,6,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 341) := by decide +kernel

theorem selectedBound39301 : packedSelected [0,2,5,6,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env39302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1557,341,8192,10056,9037,839,10073,9260,1024,9036,276,8573,16,8543,8192,65,1028,1093,8777,1889,1365,112,256,9020,1556,8525]

theorem envBound39302 : H12AffineFastState.Bounded env39302 := by
  intro p hp
  have h : env39302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39301_39302 : H12AffineEnvironment.transform 11 341 env39301 = env39302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 341 env39301 == env39302) = true)

theorem identity39302 : scanCanonicalize (H12AffineFastState.compose env39302 (packedSelected [4,5,6,7,8,10,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound39302 : packedSelected [4,5,6,7,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env39303 : List Nat := [2,4,8,16,32,64,8,256,512,68,593,341,8192,8972,9037,839,8989,8296,68,9036,276,8573,16,8543,8192,65,64,1,8777,805,273,112,256,9020,592,8525]

theorem envBound39303 : H12AffineFastState.Bounded env39303 := by
  intro p hp
  have h : env39303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39302_39303 : H12AffineEnvironment.transform 9 68 env39302 = env39303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env39302 == env39303) = true)

theorem identity39303 : scanCanonicalize (H12AffineFastState.compose env39303 (packedSelected [1,2,3,4,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound39303 : packedSelected [1,2,3,4,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39304 : List Nat := [2,4,8,16,32,64,8,256,512,68,593,341,381,625,560,839,608,277,68,561,276,0,16,34,381,65,64,1,820,805,273,112,256,577,592,48]

theorem envBound39304 : H12AffineFastState.Bounded env39304 := by
  intro p hp
  have h : env39304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39303_39304 : H12AffineEnvironment.transform 12 381 env39303 = env39304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env39303 == env39304) = true)

theorem identity39304 : scanCanonicalize (H12AffineFastState.compose env39304 (packedSelected [0,1,4,6,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound39304 : packedSelected [0,1,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env39305 : List Nat := [2,4,8,16,32,64,8,256,356,68,309,341,381,277,340,35,260,277,68,341,276,0,16,34,381,65,64,1,80,65,273,112,256,293,308,48]

theorem envBound39305 : H12AffineFastState.Bounded env39305 := by
  intro p hp
  have h : env39305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39304_39305 : H12AffineEnvironment.transform 8 356 env39304 = env39305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env39304 == env39305) = true)

theorem identity39305 : scanCanonicalize (H12AffineFastState.compose env39305 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound39305 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39306 : List Nat := [2,4,8,16,32,33,8,256,261,37,309,308,284,277,309,35,260,277,37,308,276,0,16,34,284,32,33,1,49,32,273,17,256,293,308,48]

theorem envBound39306 : H12AffineFastState.Bounded env39306 := by
  intro p hp
  have h : env39306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39305_39306 : H12AffineEnvironment.transform 5 33 env39305 = env39306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env39305 == env39306) = true)

theorem identity39306 : scanCanonicalize (H12AffineFastState.compose env39306 (packedSelected [0,2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39306 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env39307 : List Nat := [2,4,8,16,32,33,8,5,0,37,48,49,25,16,48,35,1,16,37,49,17,0,16,34,25,32,33,1,49,32,20,17,5,32,49,48]

theorem envBound39307 : H12AffineFastState.Bounded env39307 := by
  intro p hp
  have h : env39307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39306_39307 : H12AffineEnvironment.transform 7 5 env39306 = env39307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39306 == env39307) = true)

theorem identity39307 : scanCanonicalize (H12AffineFastState.compose env39307 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39308 : List Nat := [2,4,8,16,1,0,8,5,0,4,17,16,25,16,17,2,1,16,4,16,17,0,16,3,25,1,0,1,16,1,20,17,5,1,16,17]

theorem envBound39308 : H12AffineFastState.Bounded env39308 := by
  intro p hp
  have h : env39308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39307_39308 : H12AffineEnvironment.transform 4 1 env39307 = env39308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39307 == env39308) = true)

theorem identity39308 : scanCanonicalize (H12AffineFastState.compose env39308 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39308 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39309 : List Nat := [2,4,8,0,1,0,8,5,0,4,1,0,9,0,1,2,1,0,4,0,1,0,0,3,9,1,0,1,0,1,4,1,5,1,0,1]

theorem envBound39309 : H12AffineFastState.Bounded env39309 := by
  intro p hp
  have h : env39309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39308_39309 : H12AffineEnvironment.transform 3 0 env39308 = env39309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39308 == env39309) = true)

theorem identity39309 : scanCanonicalize (H12AffineFastState.compose env39309 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39309 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39310 : List Nat := [2,4,3,0,1,0,3,5,0,4,1,0,2,0,1,2,1,0,4,0,1,0,0,3,2,1,0,1,0,1,4,1,5,1,0,1]

theorem envBound39310 : H12AffineFastState.Bounded env39310 := by
  intro p hp
  have h : env39310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39309_39310 : H12AffineEnvironment.transform 2 3 env39309 = env39310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39309 == env39310) = true)

def env39311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,16,98644,8193,65,4270123,5392,17665,108927,1364,4256861,256,21793,46093,74250]

theorem envBound39311 : H12AffineFastState.Bounded env39311 := by
  intro p hp
  have h : env39311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39294_39311 : H12AffineEnvironment.transform 6 9 env39294 = env39311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39294 == env39311) = true)

theorem identity39311 : scanCanonicalize (H12AffineFastState.compose env39311 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound39311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4161,4194304,16,98644,8193,65,4270123,5392,17665,108927,1364,4256861,256,21793,46093,74250]

theorem envBound39312 : H12AffineFastState.Bounded env39312 := by
  intro p hp
  have h : env39312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39311_39312 : H12AffineEnvironment.transform 16 82246 env39311 = env39312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env39311 == env39312) = true)

theorem identity39312 : scanCanonicalize (H12AffineFastState.compose env39312 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound39312 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env39313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4161,8573,16,98644,8193,65,67926,5392,17665,108927,1364,54560,256,21793,46093,74250]

theorem envBound39313 : H12AffineFastState.Bounded env39313 := by
  intro p hp
  have h : env39313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39312_39313 : H12AffineEnvironment.transform 21 8573 env39312 = env39313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env39312 == env39313) = true)

theorem identity39313 : scanCanonicalize (H12AffineFastState.compose env39313 (packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound39313 : packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env39314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,5392,10280,1024,32769,4161,8573,16,54530,8193,65,23808,5392,17665,64809,1364,54560,256,21793,46093,30300]

theorem envBound39314 : H12AffineFastState.Bounded env39314 := by
  intro p hp
  have h : env39314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39313_39314 : H12AffineEnvironment.transform 15 21590 env39313 = env39314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env39313 == env39314) = true)

theorem identity39314 : scanCanonicalize (H12AffineFastState.compose env39314 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound39314 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env39315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,5392,10280,1024,29789,4161,8573,16,8542,8193,65,23808,5392,17665,2421,1364,8572,256,21793,16465,30300]

theorem envBound39315 : H12AffineFastState.Bounded env39315 := by
  intro p hp
  have h : env39315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39314_39315 : H12AffineEnvironment.transform 14 29788 env39314 = env39315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env39314 == env39315) = true)

theorem identity39315 : scanCanonicalize (H12AffineFastState.compose env39315 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound39315 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,5392,10280,1024,0,4161,8573,16,8542,8193,65,10589,5392,12636,2421,1364,8572,256,8572,13324,513]

theorem envBound39316 : H12AffineFastState.Bounded env39316 := by
  intro p hp
  have h : env39316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39315_39316 : H12AffineEnvironment.transform 13 13405 env39315 = env39316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env39315 == env39316) = true)

theorem identity39316 : scanCanonicalize (H12AffineFastState.compose env39316 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39316 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env39317 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8203,5392,10280,1024,0,4112,8492,16,8463,8193,16,10508,5392,12557,2340,1285,8493,256,8493,13324,513]

theorem envBound39317 : H12AffineFastState.Bounded env39317 := by
  intro p hp
  have h : env39317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39316_39317 : H12AffineEnvironment.transform 5 17 env39316 = env39317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39316 == env39317) = true)

theorem identity39317 : scanCanonicalize (H12AffineFastState.compose env39317 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound39317 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39318 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,2316,7424,1,2311,5392,292,1024,0,4112,2080,16,2051,2317,16,0,5392,6145,2340,1285,2081,256,2081,7424,513]

theorem envBound39318 : H12AffineFastState.Bounded env39318 := by
  intro p hp
  have h : env39318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39317_39318 : H12AffineEnvironment.transform 12 2316 env39317 = env39318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env39317 == env39318) = true)

theorem identity39318 : scanCanonicalize (H12AffineFastState.compose env39318 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39318 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39319 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,4096,269,5377,1,262,5392,292,1024,0,4112,33,16,2,268,16,0,5392,4096,293,1285,32,256,32,5377,513]

theorem envBound39319 : H12AffineFastState.Bounded env39319 := by
  intro p hp
  have h : env39319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39318_39319 : H12AffineEnvironment.transform 10 1 env39318 = env39319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39318 == env39319) = true)

theorem identity39319 : scanCanonicalize (H12AffineFastState.compose env39319 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound39319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39320 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1313,269,32,1,262,49,292,1024,0,1329,33,16,2,268,16,0,49,1313,293,1285,32,256,32,32,513]

theorem envBound39320 : H12AffineFastState.Bounded env39320 := by
  intro p hp
  have h : env39320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39319_39320 : H12AffineEnvironment.transform 11 1313 env39319 = env39320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env39319 == env39320) = true)

theorem identity39320 : scanCanonicalize (H12AffineFastState.compose env39320 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39320 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39321 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,1029,41,32,1,34,49,0,1024,0,1045,33,16,2,40,16,0,49,1029,1,1057,32,36,32,32,513]

theorem envBound39321 : H12AffineFastState.Bounded env39321 := by
  intro p hp
  have h : env39321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39320_39321 : H12AffineEnvironment.transform 7 36 env39320 = env39321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39320 == env39321) = true)

theorem identity39321 : scanCanonicalize (H12AffineFastState.compose env39321 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound39321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39322 : List Nat := [2,4,8,16,32,17,9,36,48,1024,1,1029,41,32,1,34,49,0,1024,0,1045,33,16,2,40,16,0,49,1029,1,1057,32,36,32,32,49]

theorem envBound39322 : H12AffineFastState.Bounded env39322 := by
  intro p hp
  have h : env39322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39321_39322 : H12AffineEnvironment.transform 8 48 env39321 = env39322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env39321 == env39322) = true)

theorem identity39322 : scanCanonicalize (H12AffineFastState.compose env39322 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39322 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39323 : List Nat := [2,4,8,16,17,17,9,21,1,1024,1,1029,24,17,1,19,0,0,1024,0,1045,16,16,2,25,16,0,0,1029,1,1040,17,21,17,17,0]

theorem envBound39323 : H12AffineFastState.Bounded env39323 := by
  intro p hp
  have h : env39323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39322_39323 : H12AffineEnvironment.transform 4 17 env39322 = env39323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39322 == env39323) = true)

theorem identity39323 : scanCanonicalize (H12AffineFastState.compose env39323 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound39323 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39324 : List Nat := [2,4,8,16,17,17,9,21,1,20,1,17,24,17,1,19,0,0,20,0,1,16,16,2,25,16,0,0,17,1,4,17,21,17,17,0]

theorem envBound39324 : H12AffineFastState.Bounded env39324 := by
  intro p hp
  have h : env39324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39323_39324 : H12AffineEnvironment.transform 9 20 env39323 = env39324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env39323 == env39324) = true)

theorem identity39324 : scanCanonicalize (H12AffineFastState.compose env39324 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39324 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39325 : List Nat := [2,4,8,1,0,0,9,4,1,5,1,0,9,0,1,2,0,0,5,0,1,1,1,2,8,1,0,0,0,1,4,0,4,0,0,0]

theorem envBound39325 : H12AffineFastState.Bounded env39325 := by
  intro p hp
  have h : env39325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39324_39325 : H12AffineEnvironment.transform 3 1 env39324 = env39325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39324 == env39325) = true)

def env39326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760059,5393,10507600,8497638,10491277,4256860,256,8410416,8434837,10564186]

theorem envBound39326 : H12AffineFastState.Bounded env39326 := by
  intro p hp
  have h : env39326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39213_39326 : H12AffineEnvironment.transform 23 2199965 env39213 = env39326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env39213 == env39326) = true)

def env39327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270123,5393,17664,2210230,1501,4256860,256,2114912,2139333,74250]

theorem envBound39327 : H12AffineFastState.Bounded env39327 := by
  intro p hp
  have h : env39327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39326_39327 : H12AffineEnvironment.transform 22 2101328 env39326 = env39327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env39326 == env39327) = true)

def env39328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,16,98781,8328,65,4270123,5393,17664,109046,1501,4256860,256,21792,46213,74250]

theorem envBound39328 : H12AffineFastState.Bounded env39328 := by
  intro p hp
  have h : env39328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39327_39328 : H12AffineEnvironment.transform 20 4160 env39327 = env39328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39327 == env39328) = true)

theorem identity39328 : scanCanonicalize (H12AffineFastState.compose env39328 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39328 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4160,4194304,16,41430,8328,65,4196384,5393,17664,35325,1501,4256860,256,21792,46213,513]

theorem envBound39329 : H12AffineFastState.Bounded env39329 := by
  intro p hp
  have h : env39329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39328_39329 : H12AffineEnvironment.transform 15 8203 env39328 = env39329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39328 == env39329) = true)

theorem identity39329 : scanCanonicalize (H12AffineFastState.compose env39329 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound39329 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4160,8573,16,41430,8328,65,10589,5393,17664,35325,1501,54561,256,21792,46213,513]

theorem envBound39330 : H12AffineFastState.Bounded env39330 := by
  intro p hp
  have h : env39330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39329_39330 : H12AffineEnvironment.transform 21 8573 env39329 = env39330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env39329 == env39330) = true)

theorem identity39330 : scanCanonicalize (H12AffineFastState.compose env39330 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39330 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env39331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4160,8573,16,41311,8193,65,10589,5393,17664,35188,1364,54561,256,21792,46092,513]

theorem envBound39331 : H12AffineFastState.Bounded env39331 := by
  intro p hp
  have h : env39331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39330_39331 : H12AffineEnvironment.transform 6 9 env39330 = env39331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39330 == env39331) = true)

theorem identity39331 : scanCanonicalize (H12AffineFastState.compose env39331 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound39331 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,10280,1024,32769,4160,8573,16,41311,8193,65,10589,5393,17664,35188,1364,54561,256,21792,46092,513]

theorem envBound39332 : H12AffineFastState.Bounded env39332 := by
  intro p hp
  have h : env39332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39331_39332 : H12AffineEnvironment.transform 16 24909 env39331 = env39332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env39331 == env39332) = true)

theorem identity39332 : scanCanonicalize (H12AffineFastState.compose env39332 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39332 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env39333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,10280,1024,8540,4160,8573,16,2,8193,65,10589,5393,17664,10281,1364,29820,256,21792,5457,513]

theorem envBound39333 : H12AffineFastState.Bounded env39333 := by
  intro p hp
  have h : env39333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39332_39333 : H12AffineEnvironment.transform 14 8541 env39332 = env39333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39332 == env39333) = true)

theorem identity39333 : scanCanonicalize (H12AffineFastState.compose env39333 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound39333 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8203,5393,10280,1024,8540,4160,8573,16,2,8193,65,10589,5393,12636,10281,1364,32,256,8572,5457,513]

theorem envBound39334 : H12AffineFastState.Bounded env39334 := by
  intro p hp
  have h : env39334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39333_39334 : H12AffineEnvironment.transform 13 13404 env39333 = env39334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env39333 == env39334) = true)

theorem identity39334 : scanCanonicalize (H12AffineFastState.compose env39334 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39334 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39335 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8460,8203,5393,10280,1024,8461,4113,8492,16,2,8193,16,10508,5393,12557,10281,1285,32,256,8493,5376,513]

theorem envBound39335 : H12AffineFastState.Bounded env39335 := by
  intro p hp
  have h : env39335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39334_39335 : H12AffineEnvironment.transform 5 17 env39334 = env39335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39334 == env39335) = true)

theorem identity39335 : scanCanonicalize (H12AffineFastState.compose env39335 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39335 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39336 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,262,5393,2341,1024,0,4113,33,16,2,268,16,2049,5393,4096,2340,1285,32,256,32,5376,513]

theorem envBound39336 : H12AffineFastState.Bounded env39336 := by
  intro p hp
  have h : env39336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39335_39336 : H12AffineEnvironment.transform 12 269 env39335 = env39336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39335 == env39336) = true)

theorem identity39336 : scanCanonicalize (H12AffineFastState.compose env39336 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound39336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39337 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1312,269,32,1,262,49,2341,1024,0,1329,33,16,2,268,16,2049,49,1312,2340,1285,32,256,32,32,513]

theorem envBound39337 : H12AffineFastState.Bounded env39337 := by
  intro p hp
  have h : env39337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39336_39337 : H12AffineEnvironment.transform 11 1312 env39336 = env39337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env39336 == env39337) = true)

theorem identity39337 : scanCanonicalize (H12AffineFastState.compose env39337 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39337 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39338 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,1028,41,32,1,34,49,2049,1024,0,1045,33,16,2,40,16,2049,49,1028,2048,1057,32,36,32,32,513]

theorem envBound39338 : H12AffineFastState.Bounded env39338 := by
  intro p hp
  have h : env39338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39337_39338 : H12AffineEnvironment.transform 7 36 env39337 = env39338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39337 == env39338) = true)

theorem identity39338 : scanCanonicalize (H12AffineFastState.compose env39338 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound39338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39339 : List Nat := [2,4,8,16,32,17,9,36,512,1024,545,1028,41,32,1,34,49,544,1024,0,1045,33,16,2,40,16,544,49,1028,545,1057,32,36,32,32,513]

theorem envBound39339 : H12AffineFastState.Bounded env39339 := by
  intro p hp
  have h : env39339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39338_39339 : H12AffineEnvironment.transform 10 545 env39338 = env39339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env39338 == env39339) = true)

theorem identity39339 : scanCanonicalize (H12AffineFastState.compose env39339 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39339 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39340 : List Nat := [2,4,8,16,1,17,9,5,512,1024,512,1028,8,1,1,3,16,513,1024,0,1045,0,16,2,9,16,513,16,1028,512,1024,1,5,1,1,513]

theorem envBound39340 : H12AffineFastState.Bounded env39340 := by
  intro p hp
  have h : env39340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39339_39340 : H12AffineEnvironment.transform 4 1 env39339 = env39340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39339 == env39340) = true)

theorem identity39340 : scanCanonicalize (H12AffineFastState.compose env39340 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound39340 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39341 : List Nat := [2,4,8,16,1,17,9,5,512,516,512,512,8,1,1,3,16,513,516,0,529,0,16,2,9,16,513,16,512,512,516,1,5,1,1,513]

theorem envBound39341 : H12AffineFastState.Bounded env39341 := by
  intro p hp
  have h : env39341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39340_39341 : H12AffineEnvironment.transform 9 516 env39340 = env39341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env39340 == env39341) = true)

theorem identity39341 : scanCanonicalize (H12AffineFastState.compose env39341 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound39341 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39342 : List Nat := [2,4,8,16,1,17,9,5,17,21,17,17,8,1,1,3,16,16,21,0,0,0,16,2,9,16,16,16,17,17,21,1,5,1,1,16]

theorem envBound39342 : H12AffineFastState.Bounded env39342 := by
  intro p hp
  have h : env39342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39341_39342 : H12AffineEnvironment.transform 8 17 env39341 = env39342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env39341 == env39342) = true)

theorem identity39342 : scanCanonicalize (H12AffineFastState.compose env39342 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39342 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39343 : List Nat := [2,4,3,16,1,17,2,5,17,21,17,17,3,1,1,3,16,16,21,0,0,0,16,2,2,16,16,16,17,17,21,1,5,1,1,16]

theorem envBound39343 : H12AffineFastState.Bounded env39343 := by
  intro p hp
  have h : env39343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39342_39343 : H12AffineEnvironment.transform 2 3 env39342 = env39343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39342 == env39343) = true)

theorem identity39343 : scanCanonicalize (H12AffineFastState.compose env39343 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39343 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env39344 : List Nat := [2,4,3,1,1,0,2,5,0,4,0,0,3,1,1,3,1,1,4,0,0,0,1,2,2,1,1,1,0,0,4,1,5,1,1,1]

theorem envBound39344 : H12AffineFastState.Bounded env39344 := by
  intro p hp
  have h : env39344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39343_39344 : H12AffineEnvironment.transform 3 1 env39343 = env39344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39343 == env39344) = true)

def env39345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,17,98780,8328,65,4270123,5393,17664,109047,1501,4256860,256,21793,46212,74250]

theorem envBound39345 : H12AffineFastState.Bounded env39345 := by
  intro p hp
  have h : env39345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39327_39345 : H12AffineEnvironment.transform 20 4161 env39327 = env39345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39327 == env39345) = true)

theorem identity39345 : scanCanonicalize (H12AffineFastState.compose env39345 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243122) := by decide +kernel

theorem selectedBound39345 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,243122,17,98780,8328,65,171417,5393,17664,109047,1501,213486,256,21793,46212,74250]

theorem envBound39346 : H12AffineFastState.Bounded env39346 := by
  intro p hp
  have h : env39346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39345_39346 : H12AffineEnvironment.transform 21 243122 env39345 = env39346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243122 env39345 == env39346) = true)

def env39347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243002,17,98644,8192,65,171281,5393,17664,108927,1365,213350,256,21793,46092,74250]

theorem envBound39347 : H12AffineFastState.Bounded env39347 := by
  intro p hp
  have h : env39347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39346_39347 : H12AffineEnvironment.transform 6 8 env39346 = env39347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39346 == env39347) = true)

theorem identity39347 : scanCanonicalize (H12AffineFastState.compose env39347 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39347 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223599,1024,8540,4161,201831,17,73737,8192,65,146508,5393,17664,67618,1365,213350,256,21793,5457,74250]

theorem envBound39348 : H12AffineFastState.Bounded env39348 := by
  intro p hp
  have h : env39348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39347_39348 : H12AffineEnvironment.transform 14 8541 env39347 = env39348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39347 == env39348) = true)

theorem identity39348 : scanCanonicalize (H12AffineFastState.compose env39348 (packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound39348 : packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS < 2^1333 := by decide +kernel

def env39349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,114,131072,157981,1024,8540,4161,136213,17,8315,8192,65,146508,5393,17664,2128,1365,147732,256,21793,5457,8824]

theorem envBound39349 : H12AffineFastState.Bounded env39349 := by
  intro p hp
  have h : env39349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39348_39349 : H12AffineEnvironment.transform 15 114 env39348 = env39349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env39348 == env39349) = true)

theorem identity39349 : scanCanonicalize (H12AffineFastState.compose env39349 (packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39349 : packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env39350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,114,5393,31756,1024,8540,4161,260,17,8315,8192,65,10589,5393,17664,2128,1365,21509,256,21793,5457,8824]

theorem envBound39350 : H12AffineFastState.Bounded env39350 := by
  intro p hp
  have h : env39350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39349_39350 : H12AffineEnvironment.transform 16 5393 env39349 = env39350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39349 == env39350) = true)

theorem identity39350 : scanCanonicalize (H12AffineFastState.compose env39350 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39350 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env39351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,114,5393,23889,1024,1,4161,260,17,294,349,65,2048,5393,17664,2128,1365,21509,256,21793,5457,805]

theorem envBound39351 : H12AffineFastState.Bounded env39351 := by
  intro p hp
  have h : env39351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39350_39351 : H12AffineEnvironment.transform 12 349 env39350 = env39351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39350 == env39351) = true)

theorem identity39351 : scanCanonicalize (H12AffineFastState.compose env39351 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound39351 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5157,0,114,5393,2420,1024,1,4161,260,17,294,349,65,2048,5393,4389,2128,1365,32,256,260,5457,805]

theorem envBound39352 : H12AffineFastState.Bounded env39352 := by
  intro p hp
  have h : env39352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39351_39352 : H12AffineEnvironment.transform 13 5157 env39351 = env39352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env39351 == env39352) = true)

def env39353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,243003,17,98645,8193,65,171280,5393,17664,108926,1364,213351,256,21793,46093,74250]

theorem envBound39353 : H12AffineFastState.Bounded env39353 := by
  intro p hp
  have h : env39353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39346_39353 : H12AffineEnvironment.transform 6 9 env39346 = env39353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39346 == env39353) = true)

theorem identity39353 : scanCanonicalize (H12AffineFastState.compose env39353 (packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound39353 : packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env39354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,131072,223598,1024,21760,4161,221242,17,87124,8193,65,149521,5393,17664,97407,1364,213351,256,21793,24844,74250]

theorem envBound39354 : H12AffineFastState.Bounded env39354 := by
  intro p hp
  have h : env39354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39353_39354 : H12AffineEnvironment.transform 14 21761 env39353 = env39354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env39353 == env39354) = true)

theorem identity39354 : scanCanonicalize (H12AffineFastState.compose env39354 (packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound39354 : packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env39355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,79131,23669,1024,21760,4161,21793,17,87124,8193,65,97546,5393,17664,97407,1364,29820,256,21793,24844,74250]

theorem envBound39355 : H12AffineFastState.Bounded env39355 := by
  intro p hp
  have h : env39355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39354_39355 : H12AffineEnvironment.transform 16 79131 env39354 = env39355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env39354 == env39355) = true)

theorem identity39355 : scanCanonicalize (H12AffineFastState.compose env39355 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39355 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env39356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,70727,23669,1024,21760,4161,21793,17,87124,349,65,89174,5393,17664,89379,1364,21792,256,21793,16464,66390]

theorem envBound39356 : H12AffineFastState.Bounded env39356 := by
  intro p hp
  have h : env39356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39355_39356 : H12AffineEnvironment.transform 12 348 env39355 = env39356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39355 == env39356) = true)

theorem identity39356 : scanCanonicalize (H12AffineFastState.compose env39356 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39356 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env39357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,263,5440,23669,1024,21760,4161,21793,17,21843,349,65,23889,5393,17664,23588,1364,21792,256,21793,16464,593]

theorem envBound39357 : H12AffineFastState.Bounded env39357 := by
  intro p hp
  have h : env39357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39356_39357 : H12AffineEnvironment.transform 15 263 env39356 = env39357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39356 == env39357) = true)

theorem identity39357 : scanCanonicalize (H12AffineFastState.compose env39357 (packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound39357 : packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1297,263,5440,3173,1024,1296,4161,1329,17,1347,349,65,3393,5393,5392,3124,1364,1328,256,1329,4160,593]

theorem envBound39358 : H12AffineFastState.Bounded env39358 := by
  intro p hp
  have h : env39358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39357_39358 : H12AffineEnvironment.transform 13 4112 env39357 = env39358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env39357 == env39358) = true)

theorem identity39358 : scanCanonicalize (H12AffineFastState.compose env39358 (packedSelected [0,3,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound39358 : packedSelected [0,3,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,348,3345,1297,263,2113,3173,1024,1296,3392,1329,17,1347,349,65,3393,2064,2065,3124,1364,1328,256,1329,3393,593]

theorem envBound39359 : H12AffineFastState.Bounded env39359 := by
  intro p hp
  have h : env39359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39358_39359 : H12AffineEnvironment.transform 11 3329 env39358 = env39359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env39358 == env39359) = true)

def env39360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270122,5393,17665,2210231,1500,4256860,256,2114913,2139332,74251]

theorem envBound39360 : H12AffineFastState.Bounded env39360 := by
  intro p hp
  have h : env39360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39326_39360 : H12AffineEnvironment.transform 22 2101329 env39326 = env39360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env39326 == env39360) = true)

def env39361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,17,98781,8328,65,4270122,5393,17665,109047,1500,4256860,256,21793,46212,74251]

theorem envBound39361 : H12AffineFastState.Bounded env39361 := by
  intro p hp
  have h : env39361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39360_39361 : H12AffineEnvironment.transform 20 4160 env39360 = env39361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39360 == env39361) = true)

theorem identity39361 : scanCanonicalize (H12AffineFastState.compose env39361 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213351) := by decide +kernel

theorem selectedBound39361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,213351,17,98781,8328,65,158029,5393,17665,109047,1500,243003,256,21793,46212,74251]

theorem envBound39362 : H12AffineFastState.Bounded env39362 := by
  intro p hp
  have h : env39362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39361_39362 : H12AffineEnvironment.transform 21 213351 env39361 = env39362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213351 env39361 == env39362) = true)

theorem identity39362 : scanCanonicalize (H12AffineFastState.compose env39362 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39362 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env39363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149997,1024,32769,4160,156013,17,41431,8328,65,158029,5393,17665,35325,1500,169265,256,21793,46212,513]

theorem envBound39363 : H12AffineFastState.Bounded env39363 := by
  intro p hp
  have h : env39363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39362_39363 : H12AffineEnvironment.transform 15 8202 env39362 = env39363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39362 == env39363) = true)

theorem identity39363 : scanCanonicalize (H12AffineFastState.compose env39363 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound39363 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,2557,1024,32769,4160,8573,17,41431,8328,65,10589,5393,17665,35325,1500,54561,256,21793,46212,513]

theorem envBound39364 : H12AffineFastState.Bounded env39364 := by
  intro p hp
  have h : env39364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39363_39364 : H12AffineEnvironment.transform 16 16400 env39363 = env39364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39363 == env39364) = true)

theorem identity39364 : scanCanonicalize (H12AffineFastState.compose env39364 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound39364 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env39365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,16400,2557,1024,29708,4160,8573,17,21978,8328,65,10589,5393,17665,32240,1500,8492,256,21793,16521,513]

theorem envBound39365 : H12AffineFastState.Bounded env39365 := by
  intro p hp
  have h : env39365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39364_39365 : H12AffineEnvironment.transform 14 29709 env39364 = env39365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env39364 == env39365) = true)

theorem identity39365 : scanCanonicalize (H12AffineFastState.compose env39365 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39365 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env39366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8202,16400,2421,1024,29708,4160,8573,17,21842,8192,65,10589,5393,17665,32120,1364,8492,256,21793,16385,513]

theorem envBound39366 : H12AffineFastState.Bounded env39366 := by
  intro p hp
  have h : env39366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39365_39366 : H12AffineEnvironment.transform 6 8 env39365 = env39366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39365 == env39366) = true)

theorem identity39366 : scanCanonicalize (H12AffineFastState.compose env39366 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound39366 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env39367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4453,9576,8202,4469,2421,1024,9577,4160,8573,17,1079,8192,65,10589,5393,5220,11293,1364,8492,256,1092,4452,513]

theorem envBound39367 : H12AffineFastState.Bounded env39367 := by
  intro p hp
  have h : env39367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39366_39367 : H12AffineEnvironment.transform 13 4453 env39366 = env39367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env39366 == env39367) = true)

theorem identity39367 : scanCanonicalize (H12AffineFastState.compose env39367 (packedSelected [0,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound39367 : packedSelected [0,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4453,0,1378,4469,2421,1024,1,4160,1045,17,1079,1384,65,3125,5393,5220,2421,1364,1092,256,1092,4452,513]

theorem envBound39368 : H12AffineFastState.Bounded env39368 := by
  intro p hp
  have h : env39368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39367_39368 : H12AffineEnvironment.transform 12 1384 env39367 = env39368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env39367 == env39368) = true)

theorem identity39368 : scanCanonicalize (H12AffineFastState.compose env39368 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39369 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,120,4453,0,114,4469,2421,272,1,4160,261,17,295,120,65,2341,4097,4468,2421,68,340,256,340,4452,513]

theorem envBound39369 : H12AffineFastState.Bounded env39369 := by
  intro p hp
  have h : env39369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39368_39369 : H12AffineEnvironment.transform 9 272 env39368 = env39369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39368 == env39369) = true)

theorem identity39369 : scanCanonicalize (H12AffineFastState.compose env39369 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound39369 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39370 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,120,2048,0,114,2064,2421,272,1,2341,261,17,295,120,65,2341,2404,2065,2421,68,340,256,340,2049,513]

theorem envBound39370 : H12AffineFastState.Bounded env39370 := by
  intro p hp
  have h : env39370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39369_39370 : H12AffineEnvironment.transform 11 2405 env39369 = env39370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env39369 == env39370) = true)

theorem identity39370 : scanCanonicalize (H12AffineFastState.compose env39370 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39370 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39371 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2357,40,2048,0,34,2064,2341,272,1,2341,261,17,295,40,17,2341,2356,2065,2341,20,260,256,260,2049,513]

theorem envBound39371 : H12AffineFastState.Bounded env39371 := by
  intro p hp
  have h : env39371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39370_39371 : H12AffineEnvironment.transform 5 16 env39370 = env39371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39370 == env39371) = true)

theorem identity39371 : scanCanonicalize (H12AffineFastState.compose env39371 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39372 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,309,40,0,0,34,16,293,272,1,293,261,17,295,40,17,293,308,17,293,20,260,256,260,1,513]

theorem envBound39372 : H12AffineFastState.Bounded env39372 := by
  intro p hp
  have h : env39372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39371_39372 : H12AffineEnvironment.transform 10 0 env39371 = env39372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39371 == env39372) = true)

def env39373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,16,98780,8328,65,4270122,5393,17665,109046,1500,4256860,256,21792,46213,74251]

theorem envBound39373 : H12AffineFastState.Bounded env39373 := by
  intro p hp
  have h : env39373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39360_39373 : H12AffineEnvironment.transform 20 4161 env39360 = env39373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39360 == env39373) = true)

theorem identity39373 : scanCanonicalize (H12AffineFastState.compose env39373 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound39373 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179513,1024,32769,4161,4194304,16,21762,8328,65,4259060,5393,17665,32040,1500,4256860,256,21792,46213,63189]

theorem envBound39374 : H12AffineFastState.Bounded env39374 := by
  intro p hp
  have h : env39374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39373_39374 : H12AffineEnvironment.transform 15 54494 env39373 = env39374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env39373 == env39374) = true)

def env39375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4161,4194304,16,21762,8192,65,4258940,5393,17665,32040,1364,4256860,256,21792,46093,63069]

theorem envBound39375 : H12AffineFastState.Bounded env39375 := by
  intro p hp
  have h : env39375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39374_39375 : H12AffineEnvironment.transform 6 8 env39374 = env39375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39374 == env39375) = true)

theorem identity39375 : scanCanonicalize (H12AffineFastState.compose env39375 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound39375 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,35188,1024,32769,4161,4194304,16,21762,8192,65,4258940,5393,17665,32040,1364,4256860,256,21792,46093,63069]

theorem envBound39376 : H12AffineFastState.Bounded env39376 := by
  intro p hp
  have h : env39376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39375_39376 : H12AffineEnvironment.transform 16 13389 env39375 = env39376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env39375 == env39376) = true)

theorem identity39376 : scanCanonicalize (H12AffineFastState.compose env39376 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound39376 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env39377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,35188,1024,32769,4161,62588,16,21762,8192,65,2048,5393,17665,32040,1364,32,256,21792,46093,63069]

theorem envBound39377 : H12AffineFastState.Bounded env39377 := by
  intro p hp
  have h : env39377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39376_39377 : H12AffineEnvironment.transform 21 62588 env39376 = env39377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env39376 == env39377) = true)

theorem identity39377 : scanCanonicalize (H12AffineFastState.compose env39377 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39377 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env39378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,13389,10281,1024,8540,4161,21793,16,21762,8192,65,2048,5393,17665,32040,1364,32,256,21792,5456,22272]

theorem envBound39378 : H12AffineFastState.Bounded env39378 := by
  intro p hp
  have h : env39378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39377_39378 : H12AffineEnvironment.transform 14 8541 env39377 = env39378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39377 == env39378) = true)

theorem identity39378 : scanCanonicalize (H12AffineFastState.compose env39378 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1132) := by decide +kernel

theorem selectedBound39378 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env39379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1132,16384,1329,20839,4129,3141,1024,1328,4161,21793,16,21762,1132,65,2048,5393,17665,22852,1364,32,256,21792,5456,22272]

theorem envBound39379 : H12AffineFastState.Bounded env39379 := by
  intro p hp
  have h : env39379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39378_39379 : H12AffineEnvironment.transform 12 1132 env39378 = env39379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1132 env39378 == env39379) = true)

theorem identity39379 : scanCanonicalize (H12AffineFastState.compose env39379 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39379 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env39380 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,381,16384,32,20839,4129,2388,273,33,4161,20528,16,20499,381,65,2048,4096,16400,22852,69,32,256,20529,4161,21009]

theorem envBound39380 : H12AffineFastState.Bounded env39380 := by
  intro p hp
  have h : env39380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39379_39380 : H12AffineEnvironment.transform 9 273 env39379 = env39380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39379 == env39380) = true)

theorem identity39380 : scanCanonicalize (H12AffineFastState.compose env39380 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound39380 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39381 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,381,4373,32,114,4129,2388,273,33,4161,293,16,262,381,65,2048,4096,4357,2129,69,32,256,292,4161,772]

theorem envBound39381 : H12AffineFastState.Bounded env39381 := by
  intro p hp
  have h : env39381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39380_39381 : H12AffineEnvironment.transform 13 4373 env39380 = env39381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env39380 == env39381) = true)

theorem identity39381 : scanCanonicalize (H12AffineFastState.compose env39381 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39381 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39382 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,89,4145,32,114,4129,2160,53,33,4161,1,16,34,89,65,2048,4096,4129,2129,69,32,36,0,4161,544]

theorem envBound39382 : H12AffineFastState.Bounded env39382 := by
  intro p hp
  have h : env39382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39381_39382 : H12AffineEnvironment.transform 7 36 env39381 = env39382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39381 == env39382) = true)

theorem identity39382 : scanCanonicalize (H12AffineFastState.compose env39382 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound39382 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39383 : List Nat := [2,4,8,16,32,48,8,36,512,53,2048,4096,41,4145,32,2,4129,2048,53,33,4145,1,16,34,41,49,2048,4096,4129,2081,53,32,36,0,4145,544]

theorem envBound39383 : H12AffineFastState.Bounded env39383 := by
  intro p hp
  have h : env39383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39382_39383 : H12AffineEnvironment.transform 5 48 env39382 = env39383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env39382 == env39383) = true)

theorem identity39383 : scanCanonicalize (H12AffineFastState.compose env39383 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39383 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39384 : List Nat := [2,4,8,16,32,48,8,36,0,53,2048,4096,41,4145,32,2,4129,2048,53,33,4145,1,16,34,41,49,2048,4096,4129,2081,53,32,36,0,4145,32]

theorem envBound39384 : H12AffineFastState.Bounded env39384 := by
  intro p hp
  have h : env39384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39383_39384 : H12AffineEnvironment.transform 8 0 env39383 = env39384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39383 == env39384) = true)

theorem identity39384 : scanCanonicalize (H12AffineFastState.compose env39384 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39384 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env39385 : List Nat := [2,4,8,16,32,48,8,36,0,53,0,4096,41,4145,32,2,4129,0,53,33,4145,1,16,34,41,49,0,4096,4129,33,53,32,36,0,4145,32]

theorem envBound39385 : H12AffineFastState.Bounded env39385 := by
  intro p hp
  have h : env39385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39384_39385 : H12AffineEnvironment.transform 10 0 env39384 = env39385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39384 == env39385) = true)

theorem identity39385 : scanCanonicalize (H12AffineFastState.compose env39385 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound39385 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env39386 : List Nat := [2,4,8,16,32,48,8,36,0,53,0,33,41,16,32,2,0,0,53,33,16,1,16,34,41,49,0,33,0,33,53,32,36,0,16,32]

theorem envBound39386 : H12AffineFastState.Bounded env39386 := by
  intro p hp
  have h : env39386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39385_39386 : H12AffineEnvironment.transform 11 33 env39385 = env39386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env39385 == env39386) = true)

theorem identity39386 : scanCanonicalize (H12AffineFastState.compose env39386 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39387 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,9,16,0,2,0,0,21,1,16,1,16,2,9,17,0,1,0,1,21,0,4,0,16,0]

theorem envBound39387 : H12AffineFastState.Bounded env39387 := by
  intro p hp
  have h : env39387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39386_39387 : H12AffineEnvironment.transform 4 0 env39386 = env39387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39386 == env39387) = true)

theorem identity39387 : scanCanonicalize (H12AffineFastState.compose env39387 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound39387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39388 : List Nat := [2,4,7,16,0,16,7,4,0,21,0,1,6,16,0,2,0,0,21,1,16,1,16,2,6,17,0,1,0,1,21,0,4,0,16,0]

theorem envBound39388 : H12AffineFastState.Bounded env39388 := by
  intro p hp
  have h : env39388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39387_39388 : H12AffineEnvironment.transform 2 7 env39387 = env39388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env39387 == env39388) = true)

theorem identity39388 : scanCanonicalize (H12AffineFastState.compose env39388 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39389 : List Nat := [2,4,7,1,0,1,7,4,0,4,0,1,6,1,0,2,0,0,4,1,1,1,1,2,6,0,0,1,0,1,4,0,4,0,1,0]

theorem envBound39389 : H12AffineFastState.Bounded env39389 := by
  intro p hp
  have h : env39389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39388_39389 : H12AffineEnvironment.transform 3 1 env39388 = env39389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39388 == env39389) = true)

def env39390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4161,4194304,16,21762,8193,65,4258941,5393,17665,32040,1365,4256860,256,21792,46092,63068]

theorem envBound39390 : H12AffineFastState.Bounded env39390 := by
  intro p hp
  have h : env39390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39374_39390 : H12AffineEnvironment.transform 6 9 env39374 = env39390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39374 == env39390) = true)

theorem identity39390 : scanCanonicalize (H12AffineFastState.compose env39390 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound39390 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10280,1024,32769,4161,4194304,16,21762,8193,65,4258941,5393,17665,32040,1365,4256860,256,21792,46092,63068]

theorem envBound39391 : H12AffineFastState.Bounded env39391 := by
  intro p hp
  have h : env39391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39390_39391 : H12AffineEnvironment.transform 16 38161 env39390 = env39391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39390 == env39391) = true)

theorem identity39391 : scanCanonicalize (H12AffineFastState.compose env39391 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound39391 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env39392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10280,1024,32769,4161,21872,16,21762,8193,65,43277,5393,17665,32040,1365,41260,256,21792,46092,63068]

theorem envBound39392 : H12AffineFastState.Bounded env39392 := by
  intro p hp
  have h : env39392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39391_39392 : H12AffineEnvironment.transform 21 21872 env39391 = env39392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env39391 == env39392) = true)

theorem identity39392 : scanCanonicalize (H12AffineFastState.compose env39392 (packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39392 : packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,13388,10280,1024,8540,4161,21872,16,21762,8193,65,2128,5393,17665,32040,1365,113,256,21792,5457,22273]

theorem envBound39393 : H12AffineFastState.Bounded env39393 := by
  intro p hp
  have h : env39393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39392_39393 : H12AffineEnvironment.transform 14 8541 env39392 = env39393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39392 == env39393) = true)

theorem identity39393 : scanCanonicalize (H12AffineFastState.compose env39393 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound39393 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env39394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,342,13388,10280,1024,8540,4161,8492,16,8542,8193,65,2128,5393,12637,2420,1365,113,256,8572,5457,9053]

theorem envBound39394 : H12AffineFastState.Bounded env39394 := by
  intro p hp
  have h : env39394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39393_39394 : H12AffineEnvironment.transform 13 13404 env39393 = env39394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env39393 == env39394) = true)

def env39395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound39395 : H12AffineFastState.Bounded env39395 := by
  intro p hp
  have h : env39395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39211_39395 : H12AffineEnvironment.transform 18 1025 env39211 = env39395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env39211 == env39395) = true)

theorem identity39395 : scanCanonicalize (H12AffineFastState.compose env39395 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8685927) := by decide +kernel

theorem selectedBound39395 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8328,65,4409703,10817002,10507600,8830976,331127,15068326,257,2444747,2468975,273057]

theorem envBound39396 : H12AffineFastState.Bounded env39396 := by
  intro p hp
  have h : env39396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39395_39396 : H12AffineEnvironment.transform 23 8685927 env39395 = env39396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8685927 env39395 == env39396) = true)

def env39397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4409703,10816866,10507600,8830976,331127,15068206,257,2444611,2468975,272937]

theorem envBound39397 : H12AffineFastState.Bounded env39397 := by
  intro p hp
  have h : env39397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39396_39397 : H12AffineEnvironment.transform 6 8 env39396 = env39397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39396 == env39397) = true)

def env39398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4262263,10816866,10507600,8683536,331127,15068206,257,2444611,2468975,272937]

theorem envBound39398 : H12AffineFastState.Bounded env39398 := by
  intro p hp
  have h : env39398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39397_39398 : H12AffineEnvironment.transform 16 16400 env39397 = env39398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39397 == env39398) = true)

def env39399 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685879,8192,17,4262183,10816818,10507520,8683536,331047,15068206,257,2444563,2468927,272937]

theorem envBound39399 : H12AffineFastState.Bounded env39399 := by
  intro p hp
  have h : env39399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39398_39399 : H12AffineEnvironment.transform 5 16 env39398 = env39399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39398 == env39399) = true)

def env39400 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685879,8192,17,4262183,10815490,10506288,8683536,329751,15067422,257,2443299,2468111,272937]

theorem envBound39400 : H12AffineFastState.Bounded env39400 := by
  intro p hp
  have h : env39400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39399_39400 : H12AffineEnvironment.transform 9 304 env39399 = env39400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env39399 == env39400) = true)

theorem identity39400 : scanCanonicalize (H12AffineFastState.compose env39400 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4491540) := by decide +kernel

theorem selectedBound39400 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39401 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4491540,4194339,8192,17,4262183,6390038,6609188,4196612,329751,2187274,257,2443299,2468111,272937]

theorem envBound39401 : H12AffineFastState.Bounded env39401 := by
  intro p hp
  have h : env39401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39400_39401 : H12AffineEnvironment.transform 22 4491540 env39400 = env39401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4491540 env39400 == env39401) = true)

theorem identity39401 : scanCanonicalize (H12AffineFastState.compose env39401 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound39401 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env39402 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4235580,4194339,8192,17,4262183,6390038,6353164,4196612,73791,2187274,257,2187275,2195751,513]

theorem envBound39402 : H12AffineFastState.Bounded env39402 := by
  intro p hp
  have h : env39402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39401_39402 : H12AffineEnvironment.transform 17 10280 env39401 = env39402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39401 == env39402) = true)

theorem identity39402 : scanCanonicalize (H12AffineFastState.compose env39402 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound39402 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env39403 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,33031,16400,10280,305,32769,2097152,4194304,4235580,4194339,8192,17,4229152,6291473,6353164,4196612,41272,2154765,257,2154764,2097184,513]

theorem envBound39403 : H12AffineFastState.Bounded env39403 := by
  intro p hp
  have h : env39403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39402_39403 : H12AffineEnvironment.transform 15 33031 env39402 = env39403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env39402 == env39403) = true)

theorem identity39403 : scanCanonicalize (H12AffineFastState.compose env39403 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound39403 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39404 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,33031,16400,10280,305,32769,2097152,32,41244,3,8192,17,34816,2097201,2158892,2340,41272,2154765,257,2154764,2097184,513]

theorem envBound39404 : H12AffineFastState.Bounded env39404 := by
  intro p hp
  have h : env39404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39403_39404 : H12AffineEnvironment.transform 21 32 env39403 = env39404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39403 == env39404) = true)

theorem identity39404 : scanCanonicalize (H12AffineFastState.compose env39404 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39404 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39405 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,33031,16400,2341,305,32769,2097152,32,32785,3,269,17,34816,2097201,2150433,2340,32821,2146304,257,2146305,2097184,513]

theorem envBound39405 : H12AffineFastState.Bounded env39405 := by
  intro p hp
  have h : env39405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39404_39405 : H12AffineEnvironment.transform 12 269 env39404 = env39405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39404 == env39405) = true)

theorem identity39405 : scanCanonicalize (H12AffineFastState.compose env39405 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39405 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39406 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,0,263,16400,2341,305,1,2097152,32,17,3,269,17,2048,2097201,2117665,2340,53,2113536,257,2113537,2097184,513]

theorem envBound39406 : H12AffineFastState.Bounded env39406 := by
  intro p hp
  have h : env39406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39405_39406 : H12AffineEnvironment.transform 14 0 env39405 = env39406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39405 == env39406) = true)

theorem identity39406 : scanCanonicalize (H12AffineFastState.compose env39406 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6964) := by decide +kernel

theorem selectedBound39406 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39407 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,0,263,16400,2341,305,1,6964,32,17,3,269,17,2048,6917,19221,2340,53,23348,257,23349,6932,513]

theorem envBound39407 : H12AffineFastState.Bounded env39407 := by
  intro p hp
  have h : env39407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39406_39407 : H12AffineEnvironment.transform 20 6964 env39406 = env39407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6964 env39406 == env39407) = true)

theorem identity39407 : scanCanonicalize (H12AffineFastState.compose env39407 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6932) := by decide +kernel

theorem selectedBound39407 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39408 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,6932,0,263,6916,2341,305,1,6964,32,17,3,269,17,2048,6917,4097,2340,53,32,257,33,6932,513]

theorem envBound39408 : H12AffineFastState.Bounded env39408 := by
  intro p hp
  have h : env39408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39407_39408 : H12AffineEnvironment.transform 13 6932 env39407 = env39408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6932 env39407 == env39408) = true)

theorem identity39408 : scanCanonicalize (H12AffineFastState.compose env39408 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound39408 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39409 : List Nat := [2,4,8,16,32,16,8,256,512,304,529,4096,269,4357,0,263,4373,820,305,1,4389,32,17,3,269,17,529,4372,4097,821,53,32,257,33,4357,513]

theorem envBound39409 : H12AffineFastState.Bounded env39409 := by
  intro p hp
  have h : env39409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39408_39409 : H12AffineEnvironment.transform 10 529 env39408 = env39409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env39408 == env39409) = true)

theorem identity39409 : scanCanonicalize (H12AffineFastState.compose env39409 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound39409 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39410 : List Nat := [2,4,8,16,32,16,8,256,512,304,529,512,269,773,0,263,789,820,305,1,805,32,17,3,269,17,529,788,513,821,53,32,257,33,773,513]

theorem envBound39410 : H12AffineFastState.Bounded env39410 := by
  intro p hp
  have h : env39410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39409_39410 : H12AffineEnvironment.transform 11 512 env39409 = env39410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env39409 == env39410) = true)

theorem identity39410 : scanCanonicalize (H12AffineFastState.compose env39410 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound39410 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39411 : List Nat := [2,4,8,16,32,16,8,256,17,304,0,17,269,276,0,263,260,293,305,1,308,32,17,3,269,17,0,261,16,292,53,32,257,33,276,16]

theorem envBound39411 : H12AffineFastState.Bounded env39411 := by
  intro p hp
  have h : env39411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39410_39411 : H12AffineEnvironment.transform 8 17 env39410 = env39411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env39410 == env39411) = true)

theorem identity39411 : scanCanonicalize (H12AffineFastState.compose env39411 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound39411 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39412 : List Nat := [2,4,8,16,32,16,8,21,17,37,0,17,24,1,0,18,17,48,36,1,33,32,17,3,24,17,0,16,16,49,53,32,20,33,1,16]

theorem envBound39412 : H12AffineFastState.Bounded env39412 := by
  intro p hp
  have h : env39412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39411_39412 : H12AffineEnvironment.transform 7 21 env39411 = env39412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env39411 == env39412) = true)

theorem identity39412 : scanCanonicalize (H12AffineFastState.compose env39412 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39413 : List Nat := [2,4,8,1,32,1,8,4,0,37,0,0,9,1,0,3,0,33,36,1,33,32,0,3,9,0,0,1,1,32,36,32,5,33,1,1]

theorem envBound39413 : H12AffineFastState.Bounded env39413 := by
  intro p hp
  have h : env39413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39412_39413 : H12AffineEnvironment.transform 3 1 env39412 = env39413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39412 == env39413) = true)

theorem identity39413 : scanCanonicalize (H12AffineFastState.compose env39413 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39414 : List Nat := [2,4,8,1,1,1,8,4,0,4,0,0,9,1,0,3,0,0,5,1,0,1,0,3,9,0,0,1,1,1,5,1,5,0,1,1]

theorem envBound39414 : H12AffineFastState.Bounded env39414 := by
  intro p hp
  have h : env39414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39413_39414 : H12AffineEnvironment.transform 4 1 env39413 = env39414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39413 == env39414) = true)

def env39415 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685879,8192,17,4262183,10815491,10506289,8683536,329750,15067423,257,2443298,2468110,272937]

theorem envBound39415 : H12AffineFastState.Bounded env39415 := by
  intro p hp
  have h : env39415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39399_39415 : H12AffineEnvironment.transform 9 305 env39399 = env39415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env39399 == env39415) = true)

theorem identity39415 : scanCanonicalize (H12AffineFastState.compose env39415 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235580) := by decide +kernel

theorem selectedBound39415 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39416 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4235580,4466699,8192,17,4262183,6662463,6353165,4464940,329750,2443299,257,2443298,2468110,272937]

theorem envBound39416 : H12AffineFastState.Bounded env39416 := by
  intro p hp
  have h : env39416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39415_39416 : H12AffineEnvironment.transform 22 4235580 env39415 = env39416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235580 env39415 == env39416) = true)

def env39417 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,4194304,4235580,4194339,8192,17,4262183,6390039,6353165,4196612,73790,2187275,257,2187274,2195750,513]

theorem envBound39417 : H12AffineFastState.Bounded env39417 := by
  intro p hp
  have h : env39417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39416_39417 : H12AffineEnvironment.transform 17 10280 env39416 = env39417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39416 == env39417) = true)

theorem identity39417 : scanCanonicalize (H12AffineFastState.compose env39417 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound39417 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env39418 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,33031,16400,10280,304,32769,2097152,4194304,4235580,4194339,8192,17,4229152,6291472,6353165,4196612,41273,2154764,257,2154765,2097185,513]

theorem envBound39418 : H12AffineFastState.Bounded env39418 := by
  intro p hp
  have h : env39418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39417_39418 : H12AffineEnvironment.transform 15 33031 env39417 = env39418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env39417 == env39418) = true)

theorem identity39418 : scanCanonicalize (H12AffineFastState.compose env39418 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound39418 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39419 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,33031,16400,10280,304,32769,2097152,32,41244,3,8192,17,34816,2097200,2158893,2340,41273,2154764,257,2154765,2097185,513]

theorem envBound39419 : H12AffineFastState.Bounded env39419 := by
  intro p hp
  have h : env39419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39418_39419 : H12AffineEnvironment.transform 21 32 env39418 = env39419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39418 == env39419) = true)

theorem identity39419 : scanCanonicalize (H12AffineFastState.compose env39419 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39419 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39420 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,16384,32768,33031,16400,2341,304,32769,2097152,32,32785,3,269,17,34816,2097200,2150432,2340,32820,2146305,257,2146304,2097185,513]

theorem envBound39420 : H12AffineFastState.Bounded env39420 := by
  intro p hp
  have h : env39420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39419_39420 : H12AffineEnvironment.transform 12 269 env39419 = env39420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39419 == env39420) = true)

theorem identity39420 : scanCanonicalize (H12AffineFastState.compose env39420 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39420 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39421 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,16384,0,263,16400,2341,304,1,2097152,32,17,3,269,17,2048,2097200,2117664,2340,52,2113537,257,2113536,2097185,513]

theorem envBound39421 : H12AffineFastState.Bounded env39421 := by
  intro p hp
  have h : env39421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39420_39421 : H12AffineEnvironment.transform 14 0 env39420 = env39421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39420 == env39421) = true)

theorem identity39421 : scanCanonicalize (H12AffineFastState.compose env39421 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6964) := by decide +kernel

theorem selectedBound39421 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39422 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,16384,0,263,16400,2341,304,1,6964,32,17,3,269,17,2048,6916,19220,2340,52,23349,257,23348,6933,513]

theorem envBound39422 : H12AffineFastState.Bounded env39422 := by
  intro p hp
  have h : env39422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39421_39422 : H12AffineEnvironment.transform 20 6964 env39421 = env39422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6964 env39421 == env39422) = true)

theorem identity39422 : scanCanonicalize (H12AffineFastState.compose env39422 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6933) := by decide +kernel

theorem selectedBound39422 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39423 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,6933,0,263,6917,2341,304,1,6964,32,17,3,269,17,2048,6916,4097,2340,52,32,257,33,6933,513]

theorem envBound39423 : H12AffineFastState.Bounded env39423 := by
  intro p hp
  have h : env39423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39422_39423 : H12AffineEnvironment.transform 13 6933 env39422 = env39423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6933 env39422 == env39423) = true)

theorem identity39423 : scanCanonicalize (H12AffineFastState.compose env39423 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound39423 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39424 : List Nat := [2,4,8,16,32,16,8,256,512,305,529,4096,269,4356,0,263,4372,820,304,1,4389,32,17,3,269,17,529,4373,4097,821,52,32,257,33,4356,513]

theorem envBound39424 : H12AffineFastState.Bounded env39424 := by
  intro p hp
  have h : env39424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39423_39424 : H12AffineEnvironment.transform 10 529 env39423 = env39424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env39423 == env39424) = true)

theorem identity39424 : scanCanonicalize (H12AffineFastState.compose env39424 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound39424 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39425 : List Nat := [2,4,8,16,32,16,8,256,512,305,529,512,269,772,0,263,788,820,304,1,805,32,17,3,269,17,529,789,513,821,52,32,257,33,772,513]

theorem envBound39425 : H12AffineFastState.Bounded env39425 := by
  intro p hp
  have h : env39425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39424_39425 : H12AffineEnvironment.transform 11 512 env39424 = env39425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env39424 == env39425) = true)

theorem identity39425 : scanCanonicalize (H12AffineFastState.compose env39425 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound39425 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39426 : List Nat := [2,4,8,16,32,16,8,256,17,305,0,17,269,277,0,263,261,293,304,1,308,32,17,3,269,17,0,260,16,292,52,32,257,33,277,16]

theorem envBound39426 : H12AffineFastState.Bounded env39426 := by
  intro p hp
  have h : env39426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39425_39426 : H12AffineEnvironment.transform 8 17 env39425 = env39426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env39425 == env39426) = true)

theorem identity39426 : scanCanonicalize (H12AffineFastState.compose env39426 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39426 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39427 : List Nat := [2,4,8,16,32,16,8,20,17,37,0,17,25,1,0,19,17,49,36,1,32,32,17,3,25,17,0,16,16,48,52,32,21,33,1,16]

theorem envBound39427 : H12AffineFastState.Bounded env39427 := by
  intro p hp
  have h : env39427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39426_39427 : H12AffineEnvironment.transform 7 20 env39426 = env39427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39426 == env39427) = true)

theorem identity39427 : scanCanonicalize (H12AffineFastState.compose env39427 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39428 : List Nat := [2,4,8,0,32,0,8,4,1,37,0,1,9,1,0,3,1,33,36,1,32,32,1,3,9,1,0,0,0,32,36,32,5,33,1,0]

theorem envBound39428 : H12AffineFastState.Bounded env39428 := by
  intro p hp
  have h : env39428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39427_39428 : H12AffineEnvironment.transform 3 0 env39427 = env39428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39427 == env39428) = true)

theorem identity39428 : scanCanonicalize (H12AffineFastState.compose env39428 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39429 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,1,9,1,0,3,1,0,5,1,1,1,1,3,9,1,0,0,0,1,5,1,5,0,1,0]

theorem envBound39429 : H12AffineFastState.Bounded env39429 := by
  intro p hp
  have h : env39429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39428_39429 : H12AffineEnvironment.transform 4 1 env39428 = env39429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39428 == env39429) = true)

def env39430 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,2097152,4194304,4235580,4194338,8192,17,4262183,6390038,6353165,4196613,73791,2187274,257,2187275,2195751,512]

theorem envBound39430 : H12AffineFastState.Bounded env39430 := by
  intro p hp
  have h : env39430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39416_39430 : H12AffineEnvironment.transform 17 10281 env39416 = env39430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39416 == env39430) = true)

theorem identity39430 : scanCanonicalize (H12AffineFastState.compose env39430 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 100386) := by decide +kernel

theorem selectedBound39430 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env39431 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,100386,4194304,4235580,4194338,8192,17,4262183,4196660,4290863,4196613,73791,59432,257,59433,2309,512]

theorem envBound39431 : H12AffineFastState.Bounded env39431 := by
  intro p hp
  have h : env39431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39430_39431 : H12AffineEnvironment.transform 20 100386 env39430 = env39431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 100386 env39430 == env39431) = true)

theorem identity39431 : scanCanonicalize (H12AffineFastState.compose env39431 (packedSelected [1,3,4,5,8,9,11,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 80190) := by decide +kernel

theorem selectedBound39431 : packedSelected [1,3,4,5,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env39432 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,100386,80190,104450,80156,8192,17,12313,77834,16401,77883,73791,59432,257,59433,2309,512]

theorem envBound39432 : H12AffineFastState.Bounded env39432 := by
  intro p hp
  have h : env39432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39431_39432 : H12AffineEnvironment.transform 21 80190 env39431 = env39432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80190 env39431 == env39432) = true)

theorem identity39432 : scanCanonicalize (H12AffineFastState.compose env39432 (packedSelected [1,3,4,5,8,9,11,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 38931) := by decide +kernel

theorem selectedBound39432 : packedSelected [1,3,4,5,8,9,11,15,21] rootPS < 2^1333 := by decide +kernel

def env39433 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,38931,16400,10281,304,32769,4145,41261,17,41231,8192,17,12313,43033,16401,43048,47148,59432,257,59433,2309,512]

theorem envBound39433 : H12AffineFastState.Bounded env39433 := by
  intro p hp
  have h : env39433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39432_39433 : H12AffineEnvironment.transform 15 38931 env39432 = env39433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38931 env39432 == env39433) = true)

theorem identity39433 : scanCanonicalize (H12AffineFastState.compose env39433 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound39433 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39434 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,2081,32768,38931,2097,10281,304,32769,4145,41261,17,41231,8192,17,12313,43033,2096,43048,47148,40969,257,40968,2309,512]

theorem envBound39434 : H12AffineFastState.Bounded env39434 := by
  intro p hp
  have h : env39434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39433_39434 : H12AffineEnvironment.transform 13 2081 env39433 = env39434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env39433 == env39434) = true)

theorem identity39434 : scanCanonicalize (H12AffineFastState.compose env39434 (packedSelected [0,2,3,5,6,7,10,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound39434 : packedSelected [0,2,3,5,6,7,10,14,18] rootPS < 2^1333 := by decide +kernel

def env39435 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,2081,292,6455,2097,10281,304,293,4145,8201,17,8235,8192,17,12313,10557,2096,10508,14600,8493,257,8492,2309,512]

theorem envBound39435 : H12AffineFastState.Bounded env39435 := by
  intro p hp
  have h : env39435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39434_39435 : H12AffineEnvironment.transform 14 292 env39434 = env39435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env39434 == env39435) = true)

theorem identity39435 : scanCanonicalize (H12AffineFastState.compose env39435 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound39435 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39436 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,6428,2081,292,6455,2097,4405,304,293,4145,6421,17,6455,6428,17,2309,4129,2096,4112,20,6193,257,6192,2309,512]

theorem envBound39436 : H12AffineFastState.Bounded env39436 := by
  intro p hp
  have h : env39436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39435_39436 : H12AffineEnvironment.transform 12 6428 env39435 = env39436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env39435 == env39436) = true)

theorem identity39436 : scanCanonicalize (H12AffineFastState.compose env39436 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound39436 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env39437 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,2064,268,2081,292,295,2097,2341,304,293,2081,261,17,295,268,17,2309,2097,2096,2048,20,33,257,32,2309,512]

theorem envBound39437 : H12AffineFastState.Bounded env39437 := by
  intro p hp
  have h : env39437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39436_39437 : H12AffineEnvironment.transform 11 2064 env39436 = env39437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env39436 == env39437) = true)

theorem identity39437 : scanCanonicalize (H12AffineFastState.compose env39437 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39437 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39438 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,2064,8,2081,32,35,2097,2081,52,33,2081,1,17,35,8,17,2049,2097,2096,2048,20,33,5,32,2049,512]

theorem envBound39438 : H12AffineFastState.Bounded env39438 := by
  intro p hp
  have h : env39438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39437_39438 : H12AffineEnvironment.transform 7 4 env39437 = env39438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39437 == env39438) = true)

theorem identity39438 : scanCanonicalize (H12AffineFastState.compose env39438 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound39438 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39439 : List Nat := [2,4,8,16,32,16,8,4,32,53,2048,2064,8,2081,32,35,2097,2081,52,33,2081,1,17,35,8,17,2049,2097,2096,2048,20,33,5,32,2049,32]

theorem envBound39439 : H12AffineFastState.Bounded env39439 := by
  intro p hp
  have h : env39439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39438_39439 : H12AffineEnvironment.transform 8 32 env39438 = env39439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env39438 == env39439) = true)

theorem identity39439 : scanCanonicalize (H12AffineFastState.compose env39439 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound39439 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39440 : List Nat := [2,4,8,16,32,16,8,4,32,53,16,0,8,49,32,35,33,49,52,33,49,1,17,35,8,17,17,33,32,16,20,33,5,32,17,32]

theorem envBound39440 : H12AffineFastState.Bounded env39440 := by
  intro p hp
  have h : env39440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39439_39440 : H12AffineEnvironment.transform 10 16 env39439 = env39440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env39439 == env39440) = true)

theorem identity39440 : scanCanonicalize (H12AffineFastState.compose env39440 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39440 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39441 : List Nat := [2,4,8,16,1,16,8,4,1,20,16,0,8,16,1,2,0,16,21,0,16,1,17,2,8,17,17,0,1,16,20,0,5,1,17,1]

theorem envBound39441 : H12AffineFastState.Bounded env39441 := by
  intro p hp
  have h : env39441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39440_39441 : H12AffineEnvironment.transform 4 1 env39440 = env39441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39440 == env39441) = true)

theorem identity39441 : scanCanonicalize (H12AffineFastState.compose env39441 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39442 : List Nat := [2,1,8,16,1,16,8,1,1,17,16,0,8,16,1,2,0,16,16,0,16,1,17,2,8,17,17,0,1,16,17,0,0,1,17,1]

theorem envBound39442 : H12AffineFastState.Bounded env39442 := by
  intro p hp
  have h : env39442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39441_39442 : H12AffineEnvironment.transform 1 1 env39441 = env39442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39441 == env39442) = true)

theorem identity39442 : scanCanonicalize (H12AffineFastState.compose env39442 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39443 : List Nat := [2,1,0,16,1,16,0,1,1,17,16,0,0,16,1,2,0,16,16,0,16,1,17,2,0,17,17,0,1,16,17,0,0,1,17,1]

theorem envBound39443 : H12AffineFastState.Bounded env39443 := by
  intro p hp
  have h : env39443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39442_39443 : H12AffineEnvironment.transform 2 0 env39442 = env39443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39442 == env39443) = true)

theorem identity39443 : scanCanonicalize (H12AffineFastState.compose env39443 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39444 : List Nat := [2,1,0,1,1,1,0,1,1,0,1,0,0,1,1,2,0,1,1,0,1,1,0,2,0,0,0,0,1,1,0,0,0,1,0,1]

theorem envBound39444 : H12AffineFastState.Bounded env39444 := by
  intro p hp
  have h : env39444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39443_39444 : H12AffineEnvironment.transform 3 1 env39443 = env39444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39443 == env39444) = true)

theorem identity39444 : scanCanonicalize (H12AffineFastState.compose env39444 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39444 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39445 : List Nat := [0,1,0,1,1,1,0,1,1,0,1,0,0,1,1,0,0,1,1,0,1,1,0,0,0,0,0,0,1,1,0,0,0,1,0,1]

theorem envBound39445 : H12AffineFastState.Bounded env39445 := by
  intro p hp
  have h : env39445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39444_39445 : H12AffineEnvironment.transform 0 0 env39444 = env39445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39444 == env39445) = true)

def env39446 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685878,8192,16,4262182,10816819,10507521,8683536,331046,15068206,257,2444562,2468926,272937]

theorem envBound39446 : H12AffineFastState.Bounded env39446 := by
  intro p hp
  have h : env39446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39398_39446 : H12AffineEnvironment.transform 5 17 env39398 = env39446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39398 == env39446) = true)

def env39447 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685878,8192,16,4262182,10815491,10506289,8683536,329750,15067422,257,2443298,2468110,272937]

theorem envBound39447 : H12AffineFastState.Bounded env39447 := by
  intro p hp
  have h : env39447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39446_39447 : H12AffineEnvironment.transform 9 304 env39446 = env39447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env39446 == env39447) = true)

theorem identity39447 : scanCanonicalize (H12AffineFastState.compose env39447 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4565279) := by decide +kernel

theorem selectedBound39447 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39448 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4565279,4268073,8192,16,4262182,6332700,6682926,4270351,329750,2113537,257,2443298,2468110,272937]

theorem envBound39448 : H12AffineFastState.Bounded env39448 := by
  intro p hp
  have h : env39448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39447_39448 : H12AffineEnvironment.transform 22 4565279 env39447 = env39448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4565279 env39447 == env39448) = true)

def env39449 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4292919,4268073,8192,16,4262182,6332700,6410502,4270351,73790,2113537,257,2187274,2195750,513]

theorem envBound39449 : H12AffineFastState.Bounded env39449 := by
  intro p hp
  have h : env39449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39448_39449 : H12AffineEnvironment.transform 17 10280 env39448 = env39449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39448 == env39449) = true)

theorem identity39449 : scanCanonicalize (H12AffineFastState.compose env39449 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound39449 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env39450 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,41260,73755,98565,8192,16,108554,2097200,2191402,100387,73790,2113537,257,2187274,2195750,513]

theorem envBound39450 : H12AffineFastState.Bounded env39450 := by
  intro p hp
  have h : env39450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39449_39450 : H12AffineEnvironment.transform 21 41260 env39449 = env39450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env39449 == env39450) = true)

theorem identity39450 : scanCanonicalize (H12AffineFastState.compose env39450 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39450 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39451 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,8202,16400,10280,305,32769,2097152,41260,17,41231,8192,16,34816,2097200,2117664,43049,52,2113537,257,2113536,2138412,513]

theorem envBound39451 : H12AffineFastState.Bounded env39451 := by
  intro p hp
  have h : env39451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39450_39451 : H12AffineEnvironment.transform 15 8202 env39450 = env39451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39450 == env39451) = true)

theorem identity39451 : scanCanonicalize (H12AffineFastState.compose env39451 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39451 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39452 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,0,8202,16400,10280,305,1,2097152,8492,17,8463,8192,16,2048,2097200,2117664,10281,52,2113537,257,2113536,2105644,513]

theorem envBound39452 : H12AffineFastState.Bounded env39452 := by
  intro p hp
  have h : env39452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39451_39452 : H12AffineEnvironment.transform 14 0 env39451 = env39452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39451 == env39452) = true)

theorem identity39452 : scanCanonicalize (H12AffineFastState.compose env39452 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39453 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,0,262,16400,2340,305,1,2097152,32,17,3,268,16,2048,2097200,2117664,2341,52,2113537,257,2113536,2097184,513]

theorem envBound39453 : H12AffineFastState.Bounded env39453 := by
  intro p hp
  have h : env39453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39452_39453 : H12AffineEnvironment.transform 12 268 env39452 = env39453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39452 == env39453) = true)

theorem identity39453 : scanCanonicalize (H12AffineFastState.compose env39453 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6673) := by decide +kernel

theorem selectedBound39453 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39454 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,0,262,16400,2340,305,1,6673,32,17,3,268,16,2048,6689,18993,2341,52,23056,257,23057,6705,513]

theorem envBound39454 : H12AffineFastState.Bounded env39454 := by
  intro p hp
  have h : env39454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39453_39454 : H12AffineEnvironment.transform 20 6673 env39453 = env39454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6673 env39453 == env39454) = true)

theorem identity39454 : scanCanonicalize (H12AffineFastState.compose env39454 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6704) := by decide +kernel

theorem selectedBound39454 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39455 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,6704,0,262,6688,2340,305,1,6673,32,17,3,268,16,2048,6689,4097,2341,52,32,257,33,6705,513]

theorem envBound39455 : H12AffineFastState.Bounded env39455 := by
  intro p hp
  have h : env39455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39454_39455 : H12AffineEnvironment.transform 13 6704 env39454 = env39455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6704 env39454 == env39455) = true)

theorem identity39455 : scanCanonicalize (H12AffineFastState.compose env39455 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound39455 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39456 : List Nat := [2,4,8,16,32,17,8,256,512,304,789,4096,268,4389,0,262,4405,561,305,1,4356,32,17,3,268,16,789,4404,4097,560,52,32,257,33,4388,513]

theorem envBound39456 : H12AffineFastState.Bounded env39456 := by
  intro p hp
  have h : env39456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39455_39456 : H12AffineEnvironment.transform 10 789 env39455 = env39456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env39455 == env39456) = true)

theorem identity39456 : scanCanonicalize (H12AffineFastState.compose env39456 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound39456 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39457 : List Nat := [2,4,8,16,32,17,8,256,512,304,789,545,268,772,0,262,788,561,305,1,805,32,17,3,268,16,789,789,544,560,52,32,257,33,773,513]

theorem envBound39457 : H12AffineFastState.Bounded env39457 := by
  intro p hp
  have h : env39457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39456_39457 : H12AffineEnvironment.transform 11 545 env39456 = env39457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env39456 == env39457) = true)

theorem identity39457 : scanCanonicalize (H12AffineFastState.compose env39457 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39457 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39458 : List Nat := [2,4,8,16,32,17,8,5,512,53,528,545,9,513,0,3,529,561,52,1,544,32,17,3,9,16,528,528,544,560,52,32,4,33,512,513]

theorem envBound39458 : H12AffineFastState.Bounded env39458 := by
  intro p hp
  have h : env39458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39457_39458 : H12AffineEnvironment.transform 7 5 env39457 = env39458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39457 == env39458) = true)

theorem identity39458 : scanCanonicalize (H12AffineFastState.compose env39458 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39458 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39459 : List Nat := [2,4,8,16,17,17,8,5,512,4,528,528,9,513,0,3,529,512,5,1,529,17,17,3,9,16,528,528,529,513,5,17,4,16,512,513]

theorem envBound39459 : H12AffineFastState.Bounded env39459 := by
  intro p hp
  have h : env39459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39458_39459 : H12AffineEnvironment.transform 4 17 env39458 = env39459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39458 == env39459) = true)

theorem identity39459 : scanCanonicalize (H12AffineFastState.compose env39459 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound39459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39460 : List Nat := [2,4,8,16,17,17,8,5,16,4,0,0,9,17,0,3,1,16,5,1,1,17,17,3,9,16,0,0,1,17,5,17,4,16,16,17]

theorem envBound39460 : H12AffineFastState.Bounded env39460 := by
  intro p hp
  have h : env39460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39459_39460 : H12AffineEnvironment.transform 8 16 env39459 = env39460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env39459 == env39460) = true)

theorem identity39460 : scanCanonicalize (H12AffineFastState.compose env39460 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39461 : List Nat := [2,4,3,16,17,17,3,5,16,4,0,0,2,17,0,3,1,16,5,1,1,17,17,3,2,16,0,0,1,17,5,17,4,16,16,17]

theorem envBound39461 : H12AffineFastState.Bounded env39461 := by
  intro p hp
  have h : env39461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39460_39461 : H12AffineEnvironment.transform 2 3 env39460 = env39461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39460 == env39461) = true)

def env39462 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10281,305,32769,2097152,4194304,4292918,4268073,8192,16,4262182,6332700,6410503,4270351,73791,2113537,257,2187275,2195751,512]

theorem envBound39462 : H12AffineFastState.Bounded env39462 := by
  intro p hp
  have h : env39462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39448_39462 : H12AffineEnvironment.transform 17 10281 env39448 = env39462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39448 == env39462) = true)

theorem identity39462 : scanCanonicalize (H12AffineFastState.compose env39462 (packedSelected [0,7,16] rootPS)) = affineNative (2^(20+1) ^^^ 110618) := by decide +kernel

theorem selectedBound39462 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env39463 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10281,305,32769,110618,4194304,4292918,4268073,8192,16,4262182,4264198,4219165,4270351,73791,127003,257,53265,12605,512]

theorem envBound39463 : H12AffineFastState.Bounded env39463 := by
  intro p hp
  have h : env39463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39462_39463 : H12AffineEnvironment.transform 20 110618 env39462 = env39463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110618 env39462 == env39463) = true)

theorem identity39463 : scanCanonicalize (H12AffineFastState.compose env39463 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(14+1) ^^^ 14620) := by decide +kernel

theorem selectedBound39463 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env39464 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,14620,65536,16400,10281,305,14621,67846,4194304,4274218,4268073,8192,16,4262182,4264198,4219165,4270351,73791,84231,257,26893,12605,512]

theorem envBound39464 : H12AffineFastState.Bounded env39464 := by
  intro p hp
  have h : env39464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39463_39464 : H12AffineEnvironment.transform 14 14620 env39463 = env39464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14620 env39463 == env39464) = true)

theorem identity39464 : scanCanonicalize (H12AffineFastState.compose env39464 (packedSelected [1,3,5,8,11,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound39464 : packedSelected [1,3,5,8,11,14,15,20] rootPS < 2^1333 := by decide +kernel

def env39465 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,2341,14620,65536,2357,10281,305,14621,67846,4194304,4274218,4268073,8192,16,4262182,4264198,4204600,4270351,73791,65570,257,8232,12605,512]

theorem envBound39465 : H12AffineFastState.Bounded env39465 := by
  intro p hp
  have h : env39465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39464_39465 : H12AffineEnvironment.transform 13 2341 env39464 = env39465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env39464 == env39465) = true)

theorem identity39465 : scanCanonicalize (H12AffineFastState.compose env39465 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 79931) := by decide +kernel

theorem selectedBound39465 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env39466 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,2341,14620,65536,2357,10281,305,14621,67846,79931,17,6162,8192,16,12573,10557,69635,4404,73791,65570,257,8232,12605,512]

theorem envBound39466 : H12AffineFastState.Bounded env39466 := by
  intro p hp
  have h : env39466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39465_39466 : H12AffineEnvironment.transform 21 79931 env39465 = env39466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 79931 env39465 == env39466) = true)

theorem identity39466 : scanCanonicalize (H12AffineFastState.compose env39466 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 6460) := by decide +kernel

theorem selectedBound39466 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39467 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,6460,2341,32,65536,2357,4373,305,33,67846,65799,17,6162,6460,16,2081,4097,69635,4404,71939,65570,257,6420,2049,512]

theorem envBound39467 : H12AffineFastState.Bounded env39467 := by
  intro p hp
  have h : env39467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39466_39467 : H12AffineEnvironment.transform 12 6460 env39466 = env39467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6460 env39466 == env39467) = true)

theorem identity39467 : scanCanonicalize (H12AffineFastState.compose env39467 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound39467 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39468 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,6460,2341,32,262,2357,4373,305,33,2048,1,17,6162,6460,16,2081,4097,4357,4404,6149,292,257,6420,2049,512]

theorem envBound39468 : H12AffineFastState.Bounded env39468 := by
  intro p hp
  have h : env39468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39467_39468 : H12AffineEnvironment.transform 15 262 env39467 = env39468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env39467 == env39468) = true)

theorem identity39468 : scanCanonicalize (H12AffineFastState.compose env39468 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39468 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env39469 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,4096,6200,2081,32,2,2097,4113,53,33,2048,1,17,6162,6200,16,2081,4097,4097,4144,6149,32,5,6160,2049,512]

theorem envBound39469 : H12AffineFastState.Bounded env39469 := by
  intro p hp
  have h : env39469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39468_39469 : H12AffineEnvironment.transform 7 4 env39468 = env39469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39468 == env39469) = true)

theorem identity39469 : scanCanonicalize (H12AffineFastState.compose env39469 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39469 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39470 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,4096,6169,2048,1,2,2064,4113,20,0,2048,1,17,6162,6169,16,2048,4097,4097,4113,6149,1,5,6160,2049,512]

theorem envBound39470 : H12AffineFastState.Bounded env39470 := by
  intro p hp
  have h : env39470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39469_39470 : H12AffineEnvironment.transform 4 1 env39469 = env39470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39469 == env39470) = true)

theorem identity39470 : scanCanonicalize (H12AffineFastState.compose env39470 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound39470 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39471 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,9,2048,1,2,2064,2049,20,0,2048,1,17,2,9,16,2048,2065,2065,2049,21,1,5,0,2049,512]

theorem envBound39471 : H12AffineFastState.Bounded env39471 := by
  intro p hp
  have h : env39471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39470_39471 : H12AffineEnvironment.transform 11 2064 env39470 = env39471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env39470 == env39471) = true)

theorem identity39471 : scanCanonicalize (H12AffineFastState.compose env39471 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39471 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39472 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,2064,9,2048,1,2,2064,2049,20,0,2048,1,17,2,9,16,2048,2065,2065,2049,21,1,5,0,2049,0]

theorem envBound39472 : H12AffineFastState.Bounded env39472 := by
  intro p hp
  have h : env39472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39471_39472 : H12AffineEnvironment.transform 8 0 env39471 = env39472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39471 == env39472) = true)

theorem identity39472 : scanCanonicalize (H12AffineFastState.compose env39472 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound39472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39473 : List Nat := [2,4,8,4,1,5,8,4,0,1,2048,2052,9,2048,1,2,2052,2049,0,0,2048,1,5,2,9,4,2048,2053,2053,2049,1,1,5,0,2049,0]

theorem envBound39473 : H12AffineFastState.Bounded env39473 := by
  intro p hp
  have h : env39473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39472_39473 : H12AffineEnvironment.transform 3 4 env39472 = env39473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env39472 == env39473) = true)

def leafEnv39473 : List Nat := [2,4,8,4,1,5,8,4,0,1,2048,2052,9,2048,1,2,2052,2049,0,0,2048,1,5,2,0,9,1,4,2048,2053,2053,2049,1,1,5,0,5,2,2049,0,1,2049,0]

def active39473 : List Nat := [0,1,2,10]

def tree39473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39473 : H12WitnessSearch.Good tree39473 := H12GlobalWitnessIndex.good

theorem leafIdentity39473 : H12AffineFastState.composeSystem env39473 rootObs = leafEnv39473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39473 rootObs == leafEnv39473) = true)

theorem terminalChecked39473 : H12PackedTerminal.terminalCheckFast leafEnv39473 active39473 tree39473 = true := by decide +kernel

def env39474 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685878,8192,16,4262182,10815490,10506288,8683536,329751,15067423,257,2443299,2468111,272937]

theorem envBound39474 : H12AffineFastState.Bounded env39474 := by
  intro p hp
  have h : env39474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39446_39474 : H12AffineEnvironment.transform 9 305 env39446 = env39474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env39446 == env39474) = true)

theorem identity39474 : scanCanonicalize (H12AffineFastState.compose env39474 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4292919) := by decide +kernel

theorem selectedBound39474 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39475 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4292919,4524033,8192,16,4262182,6588725,6410503,4522279,329751,2385960,257,2443299,2468111,272937]

theorem envBound39475 : H12AffineFastState.Bounded env39475 := by
  intro p hp
  have h : env39475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39474_39475 : H12AffineEnvironment.transform 22 4292919 env39474 = env39475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292919 env39474 == env39475) = true)

theorem identity39475 : scanCanonicalize (H12AffineFastState.compose env39475 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound39475 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39476 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,4194304,4292919,4268073,8192,16,4262182,6332701,6410503,4270351,73791,2113536,257,2187275,2195751,513]

theorem envBound39476 : H12AffineFastState.Bounded env39476 := by
  intro p hp
  have h : env39476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39475_39476 : H12AffineEnvironment.transform 17 10280 env39475 = env39476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39475 == env39476) = true)

theorem identity39476 : scanCanonicalize (H12AffineFastState.compose env39476 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound39476 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env39477 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,41260,73755,98565,8192,16,108554,2097201,2191403,100387,73791,2113536,257,2187275,2195751,513]

theorem envBound39477 : H12AffineFastState.Bounded env39477 := by
  intro p hp
  have h : env39477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39476_39477 : H12AffineEnvironment.transform 21 41260 env39476 = env39477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env39476 == env39477) = true)

theorem identity39477 : scanCanonicalize (H12AffineFastState.compose env39477 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39477 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39478 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,8202,16400,10280,304,32769,2097152,41260,17,41231,8192,16,34816,2097201,2117665,43049,53,2113536,257,2113537,2138413,513]

theorem envBound39478 : H12AffineFastState.Bounded env39478 := by
  intro p hp
  have h : env39478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39477_39478 : H12AffineEnvironment.transform 15 8202 env39477 = env39478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39477 == env39478) = true)

theorem identity39478 : scanCanonicalize (H12AffineFastState.compose env39478 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39478 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39479 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,0,8202,16400,10280,304,1,2097152,8492,17,8463,8192,16,2048,2097201,2117665,10281,53,2113536,257,2113537,2105645,513]

theorem envBound39479 : H12AffineFastState.Bounded env39479 := by
  intro p hp
  have h : env39479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39478_39479 : H12AffineEnvironment.transform 14 0 env39478 = env39479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39478 == env39479) = true)

theorem identity39479 : scanCanonicalize (H12AffineFastState.compose env39479 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39479 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39480 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,268,16384,0,262,16400,2340,304,1,2097152,32,17,3,268,16,2048,2097201,2117665,2341,53,2113536,257,2113537,2097185,513]

theorem envBound39480 : H12AffineFastState.Bounded env39480 := by
  intro p hp
  have h : env39480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39479_39480 : H12AffineEnvironment.transform 12 268 env39479 = env39480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39479 == env39480) = true)

theorem identity39480 : scanCanonicalize (H12AffineFastState.compose env39480 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6673) := by decide +kernel

theorem selectedBound39480 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39481 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,268,16384,0,262,16400,2340,304,1,6673,32,17,3,268,16,2048,6688,18992,2341,53,23057,257,23056,6704,513]

theorem envBound39481 : H12AffineFastState.Bounded env39481 := by
  intro p hp
  have h : env39481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39480_39481 : H12AffineEnvironment.transform 20 6673 env39480 = env39481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6673 env39480 == env39481) = true)

theorem identity39481 : scanCanonicalize (H12AffineFastState.compose env39481 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6705) := by decide +kernel

theorem selectedBound39481 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39482 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,268,6705,0,262,6689,2340,304,1,6673,32,17,3,268,16,2048,6688,4097,2341,53,32,257,33,6704,513]

theorem envBound39482 : H12AffineFastState.Bounded env39482 := by
  intro p hp
  have h : env39482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39481_39482 : H12AffineEnvironment.transform 13 6705 env39481 = env39482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6705 env39481 == env39482) = true)

theorem identity39482 : scanCanonicalize (H12AffineFastState.compose env39482 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound39482 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39483 : List Nat := [2,4,8,16,32,17,8,256,512,305,788,4096,268,4389,0,262,4405,560,304,1,4357,32,17,3,268,16,788,4404,4097,561,53,32,257,33,4388,513]

theorem envBound39483 : H12AffineFastState.Bounded env39483 := by
  intro p hp
  have h : env39483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39482_39483 : H12AffineEnvironment.transform 10 788 env39482 = env39483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env39482 == env39483) = true)

theorem identity39483 : scanCanonicalize (H12AffineFastState.compose env39483 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound39483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39484 : List Nat := [2,4,8,16,32,17,8,256,512,305,788,544,268,773,0,262,789,560,304,1,805,32,17,3,268,16,788,788,545,561,53,32,257,33,772,513]

theorem envBound39484 : H12AffineFastState.Bounded env39484 := by
  intro p hp
  have h : env39484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39483_39484 : H12AffineEnvironment.transform 11 544 env39483 = env39484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env39483 == env39484) = true)

theorem identity39484 : scanCanonicalize (H12AffineFastState.compose env39484 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39484 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39485 : List Nat := [2,4,8,16,32,17,8,4,512,53,528,544,8,513,0,2,529,560,52,1,545,32,17,3,8,16,528,528,545,561,53,32,5,33,512,513]

theorem envBound39485 : H12AffineFastState.Bounded env39485 := by
  intro p hp
  have h : env39485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39484_39485 : H12AffineEnvironment.transform 7 4 env39484 = env39485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39484 == env39485) = true)

theorem identity39485 : scanCanonicalize (H12AffineFastState.compose env39485 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39485 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39486 : List Nat := [2,4,8,16,16,17,8,4,512,5,528,528,8,513,0,2,529,512,4,1,529,16,17,3,8,16,528,528,529,513,5,16,5,17,512,513]

theorem envBound39486 : H12AffineFastState.Bounded env39486 := by
  intro p hp
  have h : env39486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39485_39486 : H12AffineEnvironment.transform 4 16 env39485 = env39486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39485 == env39486) = true)

theorem identity39486 : scanCanonicalize (H12AffineFastState.compose env39486 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound39486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39487 : List Nat := [2,4,8,16,16,17,8,4,16,5,0,0,8,17,0,2,1,16,4,1,1,16,17,3,8,16,0,0,1,17,5,16,5,17,16,17]

theorem envBound39487 : H12AffineFastState.Bounded env39487 := by
  intro p hp
  have h : env39487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39486_39487 : H12AffineEnvironment.transform 8 16 env39486 = env39487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env39486 == env39487) = true)

theorem identity39487 : scanCanonicalize (H12AffineFastState.compose env39487 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39487 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39488 : List Nat := [2,4,2,16,16,17,2,4,16,5,0,0,2,17,0,2,1,16,4,1,1,16,17,3,2,16,0,0,1,17,5,16,5,17,16,17]

theorem envBound39488 : H12AffineFastState.Bounded env39488 := by
  intro p hp
  have h : env39488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39487_39488 : H12AffineEnvironment.transform 2 2 env39487 = env39488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39487 == env39488) = true)

def env39489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4262262,10816866,10507600,8683537,331127,15068206,257,2444611,2468975,272937]

theorem envBound39489 : H12AffineFastState.Bounded env39489 := by
  intro p hp
  have h : env39489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39397_39489 : H12AffineEnvironment.transform 16 16401 env39397 = env39489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39397 == env39489) = true)

theorem identity39489 : scanCanonicalize (H12AffineFastState.compose env39489 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound39489 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429903,8192,65,4262262,10560842,10507600,8431673,75103,14795782,257,2188651,2196551,513]

theorem envBound39490 : H12AffineFastState.Bounded env39490 := by
  intro p hp
  have h : env39490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39489_39490 : H12AffineEnvironment.transform 17 10280 env39489 = env39490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39489 == env39490) = true)

def env39491 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429855,8192,17,4262182,10560794,10507520,8431673,75023,14795782,257,2188603,2196503,513]

theorem envBound39491 : H12AffineFastState.Bounded env39491 := by
  intro p hp
  have h : env39491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39490_39491 : H12AffineEnvironment.transform 5 16 env39490 = env39491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39490 == env39491) = true)

theorem identity39491 : scanCanonicalize (H12AffineFastState.compose env39491 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4268091) := by decide +kernel

theorem selectedBound39491 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39492 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4268091,4292900,8192,17,4262182,6292769,6387003,4294658,75023,2155581,257,2188603,2196503,513]

theorem envBound39492 : H12AffineFastState.Bounded env39492 := by
  intro p hp
  have h : env39492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39491_39492 : H12AffineEnvironment.transform 22 4268091 env39491 = env39492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268091 env39491 == env39492) = true)

theorem identity39492 : scanCanonicalize (H12AffineFastState.compose env39492 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(20+1) ^^^ 91419) := by decide +kernel

theorem selectedBound39492 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env39493 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,91419,4194304,4268091,4292900,8192,17,4262182,4284474,4198432,4294658,75023,98598,257,32,57612,513]

theorem envBound39493 : H12AffineFastState.Bounded env39493 := by
  intro p hp
  have h : env39493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39492_39493 : H12AffineEnvironment.transform 20 91419 env39492 = env39493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91419 env39492 == env39493) = true)

theorem identity39493 : scanCanonicalize (H12AffineFastState.compose env39493 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39493 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env39494 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,16401,10280,1025,32769,25628,4194304,4202812,4227107,8192,17,4196385,4219197,4198432,4229381,9224,32801,257,32,57612,513]

theorem envBound39494 : H12AffineFastState.Bounded env39494 := by
  intro p hp
  have h : env39494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39493_39494 : H12AffineEnvironment.transform 15 263 env39493 = env39494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39493 == env39494) = true)

theorem identity39494 : scanCanonicalize (H12AffineFastState.compose env39494 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound39494 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39495 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,16401,10280,1025,32769,25628,41261,32785,8462,8192,17,43276,49168,45325,10280,9224,32801,257,32,57612,513]

theorem envBound39495 : H12AffineFastState.Bounded env39495 := by
  intro p hp
  have h : env39495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39494_39495 : H12AffineEnvironment.transform 21 41261 env39494 = env39495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env39494 == env39495) = true)

theorem identity39495 : scanCanonicalize (H12AffineFastState.compose env39495 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39495 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39496 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16401,2340,1025,32769,17680,32801,32785,2,268,17,34816,49168,36865,2340,1284,32801,257,32,49152,513]

theorem envBound39496 : H12AffineFastState.Bounded env39496 := by
  intro p hp
  have h : env39496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39495_39496 : H12AffineEnvironment.transform 12 268 env39495 = env39496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39495 == env39496) = true)

theorem identity39496 : scanCanonicalize (H12AffineFastState.compose env39496 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39496 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39497 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16401,2340,1025,1,17680,33,17,2,268,17,2048,16400,4097,2340,1284,33,257,32,16384,513]

theorem envBound39497 : H12AffineFastState.Bounded env39497 := by
  intro p hp
  have h : env39497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39496_39497 : H12AffineEnvironment.transform 14 0 env39496 = env39497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39496 == env39497) = true)

theorem identity39497 : scanCanonicalize (H12AffineFastState.compose env39497 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound39497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39498 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5156,0,263,5173,2340,1025,1,4404,33,17,2,268,17,2048,5172,4097,2340,1284,33,257,32,5156,513]

theorem envBound39498 : H12AffineFastState.Bounded env39498 := by
  intro p hp
  have h : env39498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39497_39498 : H12AffineEnvironment.transform 13 5156 env39497 = env39498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env39497 == env39498) = true)

def env39499 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,268,2836,0,263,2821,2340,1025,1,3588,33,17,2,268,17,2048,2820,3889,2340,1284,33,257,32,2836,513]

theorem envBound39499 : H12AffineFastState.Bounded env39499 := by
  intro p hp
  have h : env39499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39498_39499 : H12AffineEnvironment.transform 11 3888 env39498 = env39499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env39498 == env39499) = true)

def env39500 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,268,1044,0,263,1029,1572,1025,1,260,33,17,2,268,17,1792,1028,49,1572,1284,33,257,32,1044,513]

theorem envBound39500 : H12AffineFastState.Bounded env39500 := by
  intro p hp
  have h : env39500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39499_39500 : H12AffineEnvironment.transform 10 1792 env39499 = env39500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env39499 == env39500) = true)

theorem identity39500 : scanCanonicalize (H12AffineFastState.compose env39500 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound39500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39501 : List Nat := [2,4,8,16,32,16,8,256,512,801,33,48,268,821,0,263,804,261,800,1,260,33,17,2,268,17,33,805,49,261,549,33,257,32,821,513]

theorem envBound39501 : H12AffineFastState.Bounded env39501 := by
  intro p hp
  have h : env39501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39500_39501 : H12AffineEnvironment.transform 9 801 env39500 = env39501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env39500 == env39501) = true)

def env39502 : List Nat := [2,4,8,16,32,16,8,256,276,53,33,48,268,33,0,263,48,261,52,1,260,33,17,2,268,17,33,49,49,261,305,33,257,32,33,277]

theorem envBound39502 : H12AffineFastState.Bounded env39502 := by
  intro p hp
  have h : env39502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39501_39502 : H12AffineEnvironment.transform 8 276 env39501 = env39502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env39501 == env39502) = true)

def env39503 : List Nat := [2,4,8,16,32,16,8,256,277,52,33,48,268,32,0,263,49,261,53,1,260,33,17,2,268,17,33,48,49,261,304,33,257,32,32,276]

theorem envBound39503 : H12AffineFastState.Bounded env39503 := by
  intro p hp
  have h : env39503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39501_39503 : H12AffineEnvironment.transform 8 277 env39501 = env39503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env39501 == env39503) = true)

theorem identity39503 : scanCanonicalize (H12AffineFastState.compose env39503 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39504 : List Nat := [2,4,8,11,32,11,8,256,270,47,33,43,268,32,0,263,42,261,46,1,260,33,10,2,268,10,33,43,42,261,299,33,257,32,32,271]

theorem envBound39504 : H12AffineFastState.Bounded env39504 := by
  intro p hp
  have h : env39504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39503_39504 : H12AffineEnvironment.transform 3 11 env39503 = env39504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39503 == env39504) = true)

def leafEnv39504 : List Nat := [2,4,8,11,32,11,8,256,270,47,33,43,268,32,0,263,42,261,46,1,260,33,10,2,298,268,1,10,33,43,42,261,299,33,257,32,5,263,32,271,1,260,0]

def active39504 : List Nat := [0,1,2,4,7]

def tree39504 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39504 : H12WitnessSearch.Good tree39504 := H12GlobalWitnessIndex.good

theorem leafIdentity39504 : H12AffineFastState.composeSystem env39504 rootObs = leafEnv39504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39504 rootObs == leafEnv39504) = true)

theorem terminalChecked39504 : H12PackedTerminal.terminalCheckFast leafEnv39504 active39504 tree39504 = true := by decide +kernel

def env39505 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,268,1045,0,263,1028,1573,1025,1,261,33,17,2,268,17,1793,1029,48,1573,1284,33,257,32,1045,513]

theorem envBound39505 : H12AffineFastState.Bounded env39505 := by
  intro p hp
  have h : env39505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39499_39505 : H12AffineEnvironment.transform 10 1793 env39499 = env39505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env39499 == env39505) = true)

theorem identity39505 : scanCanonicalize (H12AffineFastState.compose env39505 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound39505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39506 : List Nat := [2,4,8,16,32,16,8,256,49,1024,1328,49,268,1045,0,263,1028,1044,1025,1,261,33,17,2,268,17,1328,1029,48,1044,1284,33,257,32,1045,48]

theorem envBound39506 : H12AffineFastState.Bounded env39506 := by
  intro p hp
  have h : env39506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39505_39506 : H12AffineEnvironment.transform 8 49 env39505 = env39506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env39505 == env39506) = true)

def env39507 : List Nat := [2,4,8,16,32,16,8,256,49,52,260,49,268,33,0,263,48,32,53,1,261,33,17,2,268,17,260,49,48,32,304,33,257,32,33,48]

theorem envBound39507 : H12AffineFastState.Bounded env39507 := by
  intro p hp
  have h : env39507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39506_39507 : H12AffineEnvironment.transform 9 52 env39506 = env39507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39506 == env39507) = true)

theorem identity39507 : scanCanonicalize (H12AffineFastState.compose env39507 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound39507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39508 : List Nat := [2,4,8,16,32,16,8,62,49,52,58,49,50,33,0,57,48,32,53,1,59,33,17,2,50,17,58,49,48,32,14,33,63,32,33,48]

theorem envBound39508 : H12AffineFastState.Bounded env39508 := by
  intro p hp
  have h : env39508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39507_39508 : H12AffineEnvironment.transform 7 62 env39507 = env39508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env39507 == env39508) = true)

def leafEnv39508 : List Nat := [2,4,8,16,32,16,8,62,49,52,58,49,50,33,0,57,48,32,53,1,59,33,17,2,15,50,1,17,58,49,48,32,14,33,63,32,5,57,33,48,1,59,0]

def active39508 : List Nat := [0,1,2,3,4]

def tree39508 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39508 : H12WitnessSearch.Good tree39508 := H12GlobalWitnessIndex.good

theorem leafIdentity39508 : H12AffineFastState.composeSystem env39508 rootObs = leafEnv39508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39508 rootObs == leafEnv39508) = true)

theorem terminalChecked39508 : H12PackedTerminal.terminalCheckFast leafEnv39508 active39508 tree39508 = true := by decide +kernel

def env39509 : List Nat := [2,4,8,16,32,16,8,256,49,53,261,49,268,32,0,263,49,33,52,1,261,33,17,2,268,17,261,48,48,33,305,33,257,32,32,48]

theorem envBound39509 : H12AffineFastState.Bounded env39509 := by
  intro p hp
  have h : env39509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39506_39509 : H12AffineEnvironment.transform 9 53 env39506 = env39509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39506 == env39509) = true)

def env39510 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,268,2837,0,263,2820,2340,1025,1,3589,33,17,2,268,17,2048,2821,3888,2340,1284,33,257,32,2837,513]

theorem envBound39510 : H12AffineFastState.Bounded env39510 := by
  intro p hp
  have h : env39510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39498_39510 : H12AffineEnvironment.transform 11 3889 env39498 = env39510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env39498 == env39510) = true)

def env39511 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,268,1045,0,263,1028,1572,1025,1,261,33,17,2,268,17,1792,1029,48,1572,1284,33,257,32,1045,513]

theorem envBound39511 : H12AffineFastState.Bounded env39511 := by
  intro p hp
  have h : env39511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39510_39511 : H12AffineEnvironment.transform 10 1792 env39510 = env39511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env39510 == env39511) = true)

theorem identity39511 : scanCanonicalize (H12AffineFastState.compose env39511 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound39511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39512 : List Nat := [2,4,8,16,32,16,8,256,276,1024,1044,49,268,1045,0,263,1028,1328,1025,1,261,33,17,2,268,17,1044,1029,48,1328,1284,33,257,32,1045,277]

theorem envBound39512 : H12AffineFastState.Bounded env39512 := by
  intro p hp
  have h : env39512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39511_39512 : H12AffineEnvironment.transform 8 276 env39511 = env39512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env39511 == env39512) = true)

def env39513 : List Nat := [2,4,8,16,32,16,8,256,276,52,32,49,268,33,0,263,48,260,53,1,261,33,17,2,268,17,32,49,48,260,304,33,257,32,33,277]

theorem envBound39513 : H12AffineFastState.Bounded env39513 := by
  intro p hp
  have h : env39513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39512_39513 : H12AffineEnvironment.transform 9 52 env39512 = env39513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39512 == env39513) = true)

theorem identity39513 : scanCanonicalize (H12AffineFastState.compose env39513 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39514 : List Nat := [2,4,8,11,32,11,8,256,271,47,32,42,268,33,0,263,43,260,46,1,261,33,10,2,268,10,32,42,43,260,299,33,257,32,33,270]

theorem envBound39514 : H12AffineFastState.Bounded env39514 := by
  intro p hp
  have h : env39514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39513_39514 : H12AffineEnvironment.transform 3 11 env39513 = env39514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39513 == env39514) = true)

def leafEnv39514 : List Nat := [2,4,8,11,32,11,8,256,271,47,32,42,268,33,0,263,43,260,46,1,261,33,10,2,298,268,1,10,32,42,43,260,299,33,257,32,5,263,33,270,1,261,0]

def active39514 : List Nat := [0,1,2,4,7]

def tree39514 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39514 : H12WitnessSearch.Good tree39514 := H12GlobalWitnessIndex.good

theorem leafIdentity39514 : H12AffineFastState.composeSystem env39514 rootObs = leafEnv39514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39514 rootObs == leafEnv39514) = true)

theorem terminalChecked39514 : H12PackedTerminal.terminalCheckFast leafEnv39514 active39514 tree39514 = true := by decide +kernel

def env39515 : List Nat := [2,4,8,16,32,16,8,256,276,53,33,49,268,32,0,263,49,261,52,1,261,33,17,2,268,17,33,48,48,261,305,33,257,32,32,277]

theorem envBound39515 : H12AffineFastState.Bounded env39515 := by
  intro p hp
  have h : env39515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39512_39515 : H12AffineEnvironment.transform 9 53 env39512 = env39515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39512 == env39515) = true)

def env39516 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,268,1044,0,263,1029,1573,1025,1,260,33,17,2,268,17,1793,1028,49,1573,1284,33,257,32,1044,513]

theorem envBound39516 : H12AffineFastState.Bounded env39516 := by
  intro p hp
  have h : env39516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39510_39516 : H12AffineEnvironment.transform 10 1793 env39510 = env39516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env39510 == env39516) = true)

theorem identity39516 : scanCanonicalize (H12AffineFastState.compose env39516 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound39516 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39517 : List Nat := [2,4,8,16,32,16,8,256,512,516,261,48,268,528,0,263,513,33,517,1,260,33,17,2,268,17,261,512,49,33,768,33,257,32,528,513]

theorem envBound39517 : H12AffineFastState.Bounded env39517 := by
  intro p hp
  have h : env39517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39516_39517 : H12AffineEnvironment.transform 9 516 env39516 = env39517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env39516 == env39517) = true)

def env39518 : List Nat := [2,4,8,16,32,16,8,256,48,52,261,48,268,32,0,263,49,33,53,1,260,33,17,2,268,17,261,48,49,33,304,33,257,32,32,49]

theorem envBound39518 : H12AffineFastState.Bounded env39518 := by
  intro p hp
  have h : env39518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39517_39518 : H12AffineEnvironment.transform 8 48 env39517 = env39518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env39517 == env39518) = true)

theorem identity39518 : scanCanonicalize (H12AffineFastState.compose env39518 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound39518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39519 : List Nat := [2,4,8,16,32,16,8,62,48,52,59,48,50,32,0,57,49,33,53,1,58,33,17,2,50,17,59,48,49,33,14,33,63,32,32,49]

theorem envBound39519 : H12AffineFastState.Bounded env39519 := by
  intro p hp
  have h : env39519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39518_39519 : H12AffineEnvironment.transform 7 62 env39518 = env39519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env39518 == env39519) = true)

def leafEnv39519 : List Nat := [2,4,8,16,32,16,8,62,48,52,59,48,50,32,0,57,49,33,53,1,58,33,17,2,15,50,1,17,59,48,49,33,14,33,63,32,5,57,32,49,1,58,0]

def active39519 : List Nat := [0,1,2,3,4]

def tree39519 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39519 : H12WitnessSearch.Good tree39519 := H12GlobalWitnessIndex.good

theorem leafIdentity39519 : H12AffineFastState.composeSystem env39519 rootObs = leafEnv39519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39519 rootObs == leafEnv39519) = true)

theorem terminalChecked39519 : H12PackedTerminal.terminalCheckFast leafEnv39519 active39519 tree39519 = true := by decide +kernel

def env39520 : List Nat := [2,4,8,16,32,16,8,256,49,53,261,48,268,33,0,263,48,33,52,1,260,33,17,2,268,17,261,49,49,33,305,33,257,32,33,48]

theorem envBound39520 : H12AffineFastState.Bounded env39520 := by
  intro p hp
  have h : env39520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39517_39520 : H12AffineEnvironment.transform 8 49 env39517 = env39520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env39517 == env39520) = true)

def env39521 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429854,8192,16,4262183,10560795,10507521,8431673,75022,14795782,257,2188602,2196502,513]

theorem envBound39521 : H12AffineFastState.Bounded env39521 := by
  intro p hp
  have h : env39521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39490_39521 : H12AffineEnvironment.transform 5 17 env39490 = env39521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39490 == env39521) = true)

theorem identity39521 : scanCanonicalize (H12AffineFastState.compose env39521 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound39521 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39522 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4194353,4235567,8192,16,4262183,6366506,6313264,4237320,75022,2212919,257,2188602,2196502,513]

theorem envBound39522 : H12AffineFastState.Bounded env39522 := by
  intro p hp
  have h : env39522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39521_39522 : H12AffineEnvironment.transform 22 4194353 env39521 = env39522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env39521 == env39522) = true)

theorem identity39522 : scanCanonicalize (H12AffineFastState.compose env39522 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 2122812) := by decide +kernel

theorem selectedBound39522 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env39523 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,2122812,2122765,2147603,8192,16,2190619,82198,12556,2149428,75022,2212919,257,2188602,2196502,513]

theorem envBound39523 : H12AffineFastState.Bounded env39523 := by
  intro p hp
  have h : env39523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39522_39523 : H12AffineEnvironment.transform 21 2122812 env39522 = env39523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122812 env39522 == env39523) = true)

theorem identity39523 : scanCanonicalize (H12AffineFastState.compose env39523 (packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39523 : packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env39524 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,65536,16401,2340,1025,32769,2097152,2114864,2114817,2147603,268,16,2182167,82198,4096,2149428,66562,2212919,257,2180150,2196502,513]

theorem envBound39524 : H12AffineFastState.Bounded env39524 := by
  intro p hp
  have h : env39524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39523_39524 : H12AffineEnvironment.transform 12 268 env39523 = env39524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39523 == env39524) = true)

theorem identity39524 : scanCanonicalize (H12AffineFastState.compose env39524 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39524 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env39525 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,65536,16401,2340,1025,1,2097152,2114864,2114817,2114835,268,16,2182167,82198,4096,2116660,66562,2180151,257,2180150,2163734,513]

theorem envBound39525 : H12AffineFastState.Bounded env39525 := by
  intro p hp
  have h : env39525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39524_39525 : H12AffineEnvironment.transform 14 0 env39524 = env39525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39524 == env39525) = true)

theorem identity39525 : scanCanonicalize (H12AffineFastState.compose env39525 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39526 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16401,2340,1025,1,2097152,2114864,2114817,2114835,268,16,2116880,16401,4096,2116660,1285,2114864,257,2114865,2098449,513]

theorem envBound39526 : H12AffineFastState.Bounded env39526 := by
  intro p hp
  have h : env39526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39525_39526 : H12AffineEnvironment.transform 15 263 env39525 = env39526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39525 == env39526) = true)

theorem identity39526 : scanCanonicalize (H12AffineFastState.compose env39526 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound39526 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env39527 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1572,4096,268,16384,0,263,16401,1792,1025,1,2097152,2114864,2114817,2114835,268,16,2114356,16401,4096,2114064,1285,2114864,257,2114865,2098449,513]

theorem envBound39527 : H12AffineFastState.Bounded env39527 := by
  intro p hp
  have h : env39527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39526_39527 : H12AffineEnvironment.transform 10 1572 env39526 = env39527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env39526 == env39527) = true)

theorem identity39527 : scanCanonicalize (H12AffineFastState.compose env39527 (packedSelected [4,7] rootPS)) = affineNative (2^(20+1) ^^^ 21009) := by decide +kernel

theorem selectedBound39527 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env39528 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1572,4096,268,16384,0,263,16401,1792,1025,1,21009,5921,5904,5890,268,16,4389,16401,4096,4097,1285,5921,257,5920,22272,513]

theorem envBound39528 : H12AffineFastState.Bounded env39528 := by
  intro p hp
  have h : env39528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39527_39528 : H12AffineEnvironment.transform 20 21009 env39527 = env39528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 21009 env39527 == env39528) = true)

theorem identity39528 : scanCanonicalize (H12AffineFastState.compose env39528 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound39528 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env39529 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1572,4096,268,5157,0,263,5172,1792,1025,1,1588,5921,5904,5890,268,16,4389,5172,4096,4097,1285,5921,257,5920,805,513]

theorem envBound39529 : H12AffineFastState.Bounded env39529 := by
  intro p hp
  have h : env39529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39528_39529 : H12AffineEnvironment.transform 13 5157 env39528 = env39529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env39528 == env39529) = true)

theorem identity39529 : scanCanonicalize (H12AffineFastState.compose env39529 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39529 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39530 : List Nat := [2,4,8,16,32,17,8,256,512,272,820,4096,268,4405,0,263,4388,528,273,1,804,4657,4608,4626,268,16,4389,4388,4096,4097,21,4657,257,4656,805,513]

theorem envBound39530 : H12AffineFastState.Bounded env39530 := by
  intro p hp
  have h : env39530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39529_39530 : H12AffineEnvironment.transform 9 272 env39529 = env39530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39529 == env39530) = true)

theorem identity39530 : scanCanonicalize (H12AffineFastState.compose env39530 (packedSelected [1,3,10] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound39530 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env39531 : List Nat := [2,4,8,16,32,17,8,256,512,272,820,529,268,804,0,263,821,528,273,1,804,32,17,3,268,16,820,821,529,528,21,32,257,33,805,513]

theorem envBound39531 : H12AffineFastState.Bounded env39531 := by
  intro p hp
  have h : env39531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39530_39531 : H12AffineEnvironment.transform 11 529 env39530 = env39531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env39530 == env39531) = true)

theorem identity39531 : scanCanonicalize (H12AffineFastState.compose env39531 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39532 : List Nat := [2,4,8,16,32,17,8,5,512,21,561,529,9,545,0,2,560,528,20,1,545,32,17,3,9,16,561,560,529,528,21,32,4,33,544,513]

theorem envBound39532 : H12AffineFastState.Bounded env39532 := by
  intro p hp
  have h : env39532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39531_39532 : H12AffineEnvironment.transform 7 5 env39531 = env39532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39531 == env39532) = true)

theorem identity39532 : scanCanonicalize (H12AffineFastState.compose env39532 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39532 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39533 : List Nat := [2,4,8,16,0,17,8,5,512,21,529,529,9,513,0,2,528,528,20,1,513,0,17,3,9,16,529,528,529,528,21,0,4,1,512,513]

theorem envBound39533 : H12AffineFastState.Bounded env39533 := by
  intro p hp
  have h : env39533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39532_39533 : H12AffineEnvironment.transform 4 0 env39532 = env39533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39532 == env39533) = true)

def env39534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4409703,10816867,10507600,8830976,331127,15068207,257,2444610,2468975,272936]

theorem envBound39534 : H12AffineFastState.Bounded env39534 := by
  intro p hp
  have h : env39534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39396_39534 : H12AffineEnvironment.transform 6 9 env39396 = env39534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39396 == env39534) = true)

theorem identity39534 : scanCanonicalize (H12AffineFastState.compose env39534 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 4415530) := by decide +kernel

theorem selectedBound39534 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env39535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,4415530,4712781,8193,65,4409703,6712649,6501754,4562986,331127,2526213,257,2444610,2468975,272936]

theorem envBound39535 : H12AffineFastState.Bounded env39535 := by
  intro p hp
  have h : env39535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39534_39535 : H12AffineEnvironment.transform 22 4415530 env39534 = env39535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4415530 env39534 == env39535) = true)

def env39536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,4268090,4565341,8193,65,4262263,6565209,6387050,4562986,331127,2411541,257,2444610,2468975,272936]

theorem envBound39536 : H12AffineFastState.Bounded env39536 := by
  intro p hp
  have h : env39536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39535_39536 : H12AffineEnvironment.transform 16 16400 env39535 = env39536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39535 == env39536) = true)

theorem identity39536 : scanCanonicalize (H12AffineFastState.compose env39536 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39536 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1025,8541,2097152,4194304,4268090,4524033,8193,65,4262263,6565209,6387050,4522358,331127,2387273,257,2444610,2428211,272936]

theorem envBound39537 : H12AffineFastState.Bounded env39537 := by
  intro p hp
  have h : env39537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39536_39537 : H12AffineEnvironment.transform 14 8540 env39536 = env39537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39536 == env39537) = true)

theorem identity39537 : scanCanonicalize (H12AffineFastState.compose env39537 (packedSelected [1,3,5,8,10,16,19,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 272392) := by decide +kernel

theorem selectedBound39537 : packedSelected [1,3,5,8,10,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env39538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1025,8541,2097152,272392,329778,73737,8193,65,336255,2098513,2448738,76158,331127,2387273,257,2444610,2428211,272936]

theorem envBound39538 : H12AffineFastState.Bounded env39538 := by
  intro p hp
  have h : env39538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39537_39538 : H12AffineEnvironment.transform 21 272392 env39537 = env39538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272392 env39537 == env39538) = true)

theorem identity39538 : scanCanonicalize (H12AffineFastState.compose env39538 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound39538 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env39539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,23809,1025,8541,2097152,29961,87347,73737,8193,65,97406,2098513,2162787,76158,86134,2109512,257,2166851,2183218,30505]

theorem envBound39539 : H12AffineFastState.Bounded env39539 := by
  intro p hp
  have h : env39539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39538_39539 : H12AffineEnvironment.transform 17 23809 env39538 = env39539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env39538 == env39539) = true)

theorem identity39539 : scanCanonicalize (H12AffineFastState.compose env39539 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39539 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,23809,1025,8541,2097152,29961,30009,3,8193,65,23668,2098513,2105449,2420,28796,2109512,257,2109513,2125880,30505]

theorem envBound39540 : H12AffineFastState.Bounded env39540 := by
  intro p hp
  have h : env39540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39539_39540 : H12AffineEnvironment.transform 15 8202 env39539 = env39540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39539 == env39540) = true)

theorem identity39540 : scanCanonicalize (H12AffineFastState.compose env39540 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound39540 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,23809,1025,8541,17728,29961,30009,3,8193,65,23668,16401,25897,2420,28796,29960,257,29961,13688,30505]

theorem envBound39541 : H12AffineFastState.Bounded env39541 := by
  intro p hp
  have h : env39541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39540_39541 : H12AffineEnvironment.transform 20 17728 env39540 = env39541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env39540 == env39541) = true)

theorem identity39541 : scanCanonicalize (H12AffineFastState.compose env39541 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound39541 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env39542 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,16384,8492,8202,16400,23809,1025,8493,17712,29961,30009,3,8193,49,23556,16401,25897,2308,28684,29960,257,29961,13576,30505]

theorem envBound39542 : H12AffineFastState.Bounded env39542 := by
  intro p hp
  have h : env39542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39541_39542 : H12AffineEnvironment.transform 5 48 env39541 = env39542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env39541 == env39542) = true)

theorem identity39542 : scanCanonicalize (H12AffineFastState.compose env39542 (packedSelected [0,1,3,4,5,7,8,9,11,12,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13577) := by decide +kernel

theorem selectedBound39542 : packedSelected [0,1,3,4,5,7,8,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env39543 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,13577,8492,8202,13593,10248,1025,8493,12345,0,48,3,8193,49,10509,13592,4128,2308,1285,1,257,0,13576,544]

theorem envBound39543 : H12AffineFastState.Bounded env39543 := by
  intro p hp
  have h : env39543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39542_39543 : H12AffineEnvironment.transform 13 13577 env39542 = env39543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13577 env39542 == env39543) = true)

theorem identity39543 : scanCanonicalize (H12AffineFastState.compose env39543 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound39543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39544 : List Nat := [2,4,8,16,32,48,9,53,512,1024,2048,4096,8192,13372,8217,8202,13356,10248,1025,8216,12345,0,48,3,8193,49,10296,13357,4128,2097,1072,1,52,0,13373,544]

theorem envBound39544 : H12AffineFastState.Bounded env39544 := by
  intro p hp
  have h : env39544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39543_39544 : H12AffineEnvironment.transform 7 53 env39543 = env39544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env39543 == env39544) = true)

theorem identity39544 : scanCanonicalize (H12AffineFastState.compose env39544 (packedSelected [0,1,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39544 : packedSelected [0,1,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39545 : List Nat := [2,4,8,16,1,17,9,20,512,1024,2048,4096,8192,13341,8217,8202,13325,10248,1025,8216,12312,0,17,3,8193,16,10265,13324,4097,2064,1041,1,21,0,13340,513]

theorem envBound39545 : H12AffineFastState.Bounded env39545 := by
  intro p hp
  have h : env39545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39544_39545 : H12AffineEnvironment.transform 4 1 env39544 = env39545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39544 == env39545) = true)

theorem identity39545 : scanCanonicalize (H12AffineFastState.compose env39545 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound39545 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39546 : List Nat := [2,4,8,16,1,17,9,20,512,1024,529,4096,8192,13341,8217,8202,13325,8729,1025,8216,12312,0,17,3,8193,16,8712,13324,4097,513,1041,1,21,0,13340,513]

theorem envBound39546 : H12AffineFastState.Bounded env39546 := by
  intro p hp
  have h : env39546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39545_39546 : H12AffineEnvironment.transform 10 529 env39545 = env39546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env39545 == env39546) = true)

theorem identity39546 : scanCanonicalize (H12AffineFastState.compose env39546 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound39546 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39547 : List Nat := [2,4,8,16,1,17,9,20,512,1024,529,4096,1037,4112,1044,1031,4096,1556,1025,1045,5141,0,17,3,1036,16,1541,4097,4097,513,1041,1,21,0,4113,513]

theorem envBound39547 : H12AffineFastState.Bounded env39547 := by
  intro p hp
  have h : env39547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39546_39547 : H12AffineEnvironment.transform 12 1037 env39546 = env39547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env39546 == env39547) = true)

theorem identity39547 : scanCanonicalize (H12AffineFastState.compose env39547 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound39547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39548 : List Nat := [2,4,8,16,1,17,9,20,512,1024,529,529,1037,513,1044,1031,529,1556,1025,1045,1540,0,17,3,1036,16,1541,528,528,513,1041,1,21,0,512,513]

theorem envBound39548 : H12AffineFastState.Bounded env39548 := by
  intro p hp
  have h : env39548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39547_39548 : H12AffineEnvironment.transform 11 529 env39547 = env39548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env39547 == env39548) = true)

theorem identity39548 : scanCanonicalize (H12AffineFastState.compose env39548 (packedSelected [3,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

end H12CloudChart0