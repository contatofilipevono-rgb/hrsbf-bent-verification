import H12CloudChart0Data136

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity34769 : scanCanonicalize (H12AffineFastState.compose env34769 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34769 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34770 : List Nat := [2,4,3,16,16,16,2,21,512,21,2048,2064,19,2065,1,19,2048,2049,20,0,2049,16,16,2,18,17,2048,2048,2065,2048,5,17,20,16,2065,513]

theorem envBound34770 : H12AffineFastState.Bounded env34770 := by
  intro p hp
  have h : env34770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34769_34770 : H12AffineEnvironment.transform 2 3 env34769 = env34770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34769 == env34770) = true)

def env34771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431209,8328,65,2609266,302180,333994,2330106,119042,2373704,257,2199998,2191387,63188]

theorem envBound34771 : H12AffineFastState.Bounded env34771 := by
  intro p hp
  have h : env34771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34731_34771 : H12AffineEnvironment.transform 23 2431209 env34731 = env34771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env34731 == env34771) = true)

def env34772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329897,8328,65,507954,302180,333994,236986,119042,272392,257,98814,90203,63188]

theorem envBound34772 : H12AffineFastState.Bounded env34772 := by
  intro p hp
  have h : env34772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34771_34772 : H12AffineEnvironment.transform 20 4160 env34771 = env34772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34771 == env34772) = true)

theorem identity34772 : scanCanonicalize (H12AffineFastState.compose env34772 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound34772 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,21792,73755,95497,8328,65,245138,57796,91402,236986,119042,21928,257,98814,90203,63188]

theorem envBound34773 : H12AffineFastState.Bounded env34773 := by
  intro p hp
  have h : env34773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34772_34773 : H12AffineEnvironment.transform 17 32160 env34772 = env34773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env34772 == env34773) = true)

def env34774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10400,1025,32769,4160,32,73755,73737,8328,65,245138,46276,77834,236986,99330,168,257,98814,79195,41940]

theorem envBound34774 : H12AffineFastState.Bounded env34774 := by
  intro p hp
  have h : env34774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34773_34774 : H12AffineEnvironment.transform 13 5376 env34773 = env34774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34773 == env34774) = true)

theorem identity34774 : scanCanonicalize (H12AffineFastState.compose env34774 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34774 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env34775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,4160,32,73755,73737,8193,65,245019,46157,77834,236851,99330,33,257,98679,79195,41821]

theorem envBound34775 : H12AffineFastState.Bounded env34775 := by
  intro p hp
  have h : env34775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34774_34775 : H12AffineEnvironment.transform 6 9 env34774 = env34775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34774 == env34775) = true)

theorem identity34775 : scanCanonicalize (H12AffineFastState.compose env34775 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound34775 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env34776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,13340,10281,1025,32769,4160,32,73755,73737,8193,65,100615,46157,77834,108847,99330,33,257,98679,79195,41821]

theorem envBound34776 : H12AffineFastState.Bounded env34776 := by
  intro p hp
  have h : env34776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34775_34776 : H12AffineEnvironment.transform 16 13340 env34775 = env34776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env34775 == env34776) = true)

theorem identity34776 : scanCanonicalize (H12AffineFastState.compose env34776 (packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34776 : packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env34777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13340,10281,1025,8540,4160,32,73755,73737,8193,65,75866,5392,77834,67698,75103,33,257,73770,79195,512]

theorem envBound34777 : H12AffineFastState.Bounded env34777 := by
  intro p hp
  have h : env34777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34776_34777 : H12AffineEnvironment.transform 14 8541 env34776 = env34777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34776 == env34777) = true)

theorem identity34777 : scanCanonicalize (H12AffineFastState.compose env34777 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound34777 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env34778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,5376,2421,65536,7220,1,1025,2420,4160,32,67635,67617,2089,65,65650,5392,71714,67698,68983,33,257,67586,73075,512]

theorem envBound34778 : H12AffineFastState.Bounded env34778 := by
  intro p hp
  have h : env34778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34777_34778 : H12AffineEnvironment.transform 12 2088 env34777 = env34778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env34777 == env34778) = true)

theorem identity34778 : scanCanonicalize (H12AffineFastState.compose env34778 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 4114) := by decide +kernel

theorem selectedBound34778 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env34779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,5376,2421,4114,7220,1,1025,2420,4160,32,6177,6195,2089,65,4192,5392,2096,6240,7525,33,257,6160,3425,512]

theorem envBound34779 : H12AffineFastState.Bounded env34779 := by
  intro p hp
  have h : env34779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34778_34779 : H12AffineEnvironment.transform 15 4114 env34778 = env34779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4114 env34778 == env34779) = true)

theorem identity34779 : scanCanonicalize (H12AffineFastState.compose env34779 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound34779 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env34780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,33,4096,9,5376,340,4114,5141,1,1025,341,4160,32,4096,4114,8,65,4192,5392,17,4161,5444,33,257,4145,1344,512]

theorem envBound34780 : H12AffineFastState.Bounded env34780 := by
  intro p hp
  have h : env34780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34779_34780 : H12AffineEnvironment.transform 10 33 env34779 = env34780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env34779 == env34780) = true)

theorem identity34780 : scanCanonicalize (H12AffineFastState.compose env34780 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound34780 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env34781 : List Nat := [2,4,8,16,32,64,9,256,512,21,33,4096,9,4373,340,4114,4096,1,20,341,4160,32,4096,4114,8,65,4192,4357,17,4161,4433,33,257,4145,341,512]

theorem envBound34781 : H12AffineFastState.Bounded env34781 := by
  intro p hp
  have h : env34781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34780_34781 : H12AffineEnvironment.transform 9 21 env34780 = env34781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34780 == env34781) = true)

theorem identity34781 : scanCanonicalize (H12AffineFastState.compose env34781 (packedSelected [0,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound34781 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env34782 : List Nat := [2,4,8,16,32,64,9,256,512,21,33,309,9,32,340,295,309,1,20,341,373,32,309,295,8,65,341,48,17,372,100,33,257,260,341,512]

theorem envBound34782 : H12AffineFastState.Bounded env34782 := by
  intro p hp
  have h : env34782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34781_34782 : H12AffineEnvironment.transform 11 309 env34781 = env34782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env34781 == env34782) = true)

theorem identity34782 : scanCanonicalize (H12AffineFastState.compose env34782 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound34782 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34783 : List Nat := [2,4,8,16,32,64,9,85,512,21,33,96,9,32,1,114,96,1,20,0,32,32,96,114,8,65,0,48,17,33,100,33,84,81,0,512]

theorem envBound34783 : H12AffineFastState.Bounded env34783 := by
  intro p hp
  have h : env34783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34782_34783 : H12AffineEnvironment.transform 7 85 env34782 = env34783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env34782 == env34783) = true)

theorem identity34783 : scanCanonicalize (H12AffineFastState.compose env34783 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34783 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34784 : List Nat := [2,4,8,16,32,49,9,36,512,21,33,17,9,32,1,3,17,1,20,0,32,32,17,3,8,48,0,48,17,33,21,33,37,32,0,512]

theorem envBound34784 : H12AffineFastState.Bounded env34784 := by
  intro p hp
  have h : env34784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34783_34784 : H12AffineEnvironment.transform 5 49 env34783 = env34784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34783 == env34784) = true)

theorem identity34784 : scanCanonicalize (H12AffineFastState.compose env34784 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34784 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34785 : List Nat := [2,4,8,16,32,49,9,36,0,21,33,17,9,32,1,3,17,1,20,0,32,32,17,3,8,48,0,48,17,33,21,33,37,32,0,0]

theorem envBound34785 : H12AffineFastState.Bounded env34785 := by
  intro p hp
  have h : env34785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34784_34785 : H12AffineEnvironment.transform 8 0 env34784 = env34785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34784 == env34785) = true)

theorem identity34785 : scanCanonicalize (H12AffineFastState.compose env34785 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34785 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34786 : List Nat := [2,4,8,16,16,1,9,20,0,21,17,17,9,16,1,3,17,1,20,0,16,16,17,3,8,0,0,0,17,17,21,17,21,16,0,0]

theorem envBound34786 : H12AffineFastState.Bounded env34786 := by
  intro p hp
  have h : env34786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34785_34786 : H12AffineEnvironment.transform 4 16 env34785 = env34786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34785 == env34786) = true)

theorem identity34786 : scanCanonicalize (H12AffineFastState.compose env34786 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34786 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34787 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,1,9,0,1,3,1,1,4,0,0,0,1,3,8,0,0,0,1,1,5,1,5,0,0,0]

theorem envBound34787 : H12AffineFastState.Bounded env34787 := by
  intro p hp
  have h : env34787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34786_34787 : H12AffineEnvironment.transform 3 0 env34786 = env34787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34786 == env34787) = true)

theorem identity34787 : scanCanonicalize (H12AffineFastState.compose env34787 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound34787 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34788 : List Nat := [2,0,8,0,0,1,9,0,0,1,1,1,9,0,1,3,1,1,0,0,0,0,1,3,8,0,0,0,1,1,1,1,1,0,0,0]

theorem envBound34788 : H12AffineFastState.Bounded env34788 := by
  intro p hp
  have h : env34788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34787_34788 : H12AffineEnvironment.transform 1 0 env34787 = env34788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env34787 == env34788) = true)

theorem identity34788 : scanCanonicalize (H12AffineFastState.compose env34788 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound34788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34789 : List Nat := [2,0,1,0,0,1,0,0,0,1,1,1,0,0,1,3,1,1,0,0,0,0,1,3,1,0,0,0,1,1,1,1,1,0,0,0]

theorem envBound34789 : H12AffineFastState.Bounded env34789 := by
  intro p hp
  have h : env34789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34788_34789 : H12AffineEnvironment.transform 2 1 env34788 = env34789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env34788 == env34789) = true)

theorem identity34789 : scanCanonicalize (H12AffineFastState.compose env34789 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34789 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34790 : List Nat := [0,0,1,0,0,1,0,0,0,1,1,1,0,0,1,1,1,1,0,0,0,0,1,1,1,0,0,0,1,1,1,1,1,0,0,0]

theorem envBound34790 : H12AffineFastState.Bounded env34790 := by
  intro p hp
  have h : env34790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34789_34790 : H12AffineEnvironment.transform 0 0 env34789 = env34790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34789 == env34790) = true)

def env34791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10401,1025,32769,4160,33,73755,73736,8328,65,245138,46277,77835,236986,99331,169,257,98814,79194,41941]

theorem envBound34791 : H12AffineFastState.Bounded env34791 := by
  intro p hp
  have h : env34791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34773_34791 : H12AffineEnvironment.transform 13 5377 env34773 = env34791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34773 == env34791) = true)

theorem identity34791 : scanCanonicalize (H12AffineFastState.compose env34791 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound34791 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env34792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,5392,10401,1025,32769,4160,33,73755,73736,8328,65,108674,46277,77835,100522,99331,169,257,98814,79194,41941]

theorem envBound34792 : H12AffineFastState.Bounded env34792 := by
  intro p hp
  have h : env34792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34791_34792 : H12AffineEnvironment.transform 16 5392 env34791 = env34792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env34791 == env34792) = true)

theorem identity34792 : scanCanonicalize (H12AffineFastState.compose env34792 (packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34792 : packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env34793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,5392,10401,1025,8540,4160,33,73755,73736,8328,65,68063,5528,77835,76279,75102,169,257,73891,79194,648]

theorem envBound34793 : H12AffineFastState.Bounded env34793 := by
  intro p hp
  have h : env34793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34792_34793 : H12AffineEnvironment.transform 14 8541 env34792 = env34793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34792 == env34793) = true)

theorem identity34793 : scanCanonicalize (H12AffineFastState.compose env34793 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound34793 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8323,5392,10401,1025,8540,4160,33,152,139,8328,65,10588,5528,4232,2420,1501,169,257,32,5593,648]

theorem envBound34794 : H12AffineFastState.Bounded env34794 := by
  intro p hp
  have h : env34794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34793_34794 : H12AffineEnvironment.transform 15 8323 env34793 = env34794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env34793 == env34794) = true)

theorem identity34794 : scanCanonicalize (H12AffineFastState.compose env34794 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34794 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env34795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5392,10280,1025,8540,4160,33,17,2,8193,65,10588,5393,4097,2420,1364,32,257,32,5456,513]

theorem envBound34795 : H12AffineFastState.Bounded env34795 := by
  intro p hp
  have h : env34795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34794_34795 : H12AffineEnvironment.transform 6 9 env34794 = env34795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34794 == env34795) = true)

theorem identity34795 : scanCanonicalize (H12AffineFastState.compose env34795 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34795 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,263,5392,2341,1025,81,4160,33,17,2,268,65,2129,5393,4097,2420,1364,32,257,32,5456,513]

theorem envBound34796 : H12AffineFastState.Bounded env34796 := by
  intro p hp
  have h : env34796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34795_34796 : H12AffineEnvironment.transform 12 269 env34795 = env34796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34795 == env34796) = true)

theorem identity34796 : scanCanonicalize (H12AffineFastState.compose env34796 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound34796 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34797 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,269,4145,80,263,4128,2341,305,81,4160,33,17,2,268,65,2129,4129,4097,2420,100,32,257,32,4192,513]

theorem envBound34797 : H12AffineFastState.Bounded env34797 := by
  intro p hp
  have h : env34797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34796_34797 : H12AffineEnvironment.transform 9 304 env34796 = env34797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env34796 == env34797) = true)

theorem identity34797 : scanCanonicalize (H12AffineFastState.compose env34797 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound34797 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34798 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,773,269,820,80,263,805,2341,305,81,837,33,17,2,268,65,2129,804,772,2420,100,32,257,32,869,513]

theorem envBound34798 : H12AffineFastState.Bounded env34798 := by
  intro p hp
  have h : env34798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34797_34798 : H12AffineEnvironment.transform 11 773 env34797 = env34798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env34797 == env34798) = true)

theorem identity34798 : scanCanonicalize (H12AffineFastState.compose env34798 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34798 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env34799 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,773,269,820,0,263,805,2341,305,1,789,33,17,2,268,17,2049,804,772,2340,52,32,257,32,821,513]

theorem envBound34799 : H12AffineFastState.Bounded env34799 := by
  intro p hp
  have h : env34799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34798_34799 : H12AffineEnvironment.transform 5 16 env34798 = env34799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34798 == env34799) = true)

theorem identity34799 : scanCanonicalize (H12AffineFastState.compose env34799 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34799 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34800 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,513,9,560,0,3,545,2081,53,1,529,33,17,2,8,17,2049,544,512,2080,52,32,5,32,561,513]

theorem envBound34800 : H12AffineFastState.Bounded env34800 := by
  intro p hp
  have h : env34800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34799_34800 : H12AffineEnvironment.transform 7 4 env34799 = env34800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34799 == env34800) = true)

theorem identity34800 : scanCanonicalize (H12AffineFastState.compose env34800 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound34800 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34801 : List Nat := [2,4,8,16,32,16,9,4,512,52,17,513,9,560,0,3,545,48,53,1,529,33,17,2,8,17,16,544,512,49,52,32,5,32,561,513]

theorem envBound34801 : H12AffineFastState.Bounded env34801 := by
  intro p hp
  have h : env34801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34800_34801 : H12AffineEnvironment.transform 10 17 env34800 = env34801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env34800 == env34801) = true)

theorem identity34801 : scanCanonicalize (H12AffineFastState.compose env34801 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound34801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34802 : List Nat := [2,4,8,16,32,16,9,4,48,52,17,49,9,0,0,3,17,48,53,1,33,33,17,2,8,17,16,16,48,49,52,32,5,32,1,49]

theorem envBound34802 : H12AffineFastState.Bounded env34802 := by
  intro p hp
  have h : env34802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34801_34802 : H12AffineEnvironment.transform 8 48 env34801 = env34802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34801 == env34802) = true)

theorem identity34802 : scanCanonicalize (H12AffineFastState.compose env34802 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34802 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env34803 : List Nat := [2,4,8,16,0,16,9,4,16,20,17,17,9,0,0,3,17,16,21,1,1,1,17,2,8,17,16,16,16,17,20,0,5,0,1,17]

theorem envBound34803 : H12AffineFastState.Bounded env34803 := by
  intro p hp
  have h : env34803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34802_34803 : H12AffineEnvironment.transform 4 0 env34802 = env34803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34802 == env34803) = true)

theorem identity34803 : scanCanonicalize (H12AffineFastState.compose env34803 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34804 : List Nat := [2,4,8,1,0,1,9,4,1,5,0,0,9,0,0,3,0,1,4,1,1,1,0,2,8,0,1,1,1,0,5,0,5,0,1,0]

theorem envBound34804 : H12AffineFastState.Bounded env34804 := by
  intro p hp
  have h : env34804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34803_34804 : H12AffineEnvironment.transform 3 1 env34803 = env34804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34803 == env34804) = true)

def env34805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329896,8328,65,507955,302180,333994,236987,119042,272393,257,98815,90202,63188]

theorem envBound34805 : H12AffineFastState.Bounded env34805 := by
  intro p hp
  have h : env34805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34771_34805 : H12AffineEnvironment.transform 20 4161 env34771 = env34805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34771 == env34805) = true)

def env34806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,21793,95514,73736,8328,65,256147,46276,77834,236987,119042,169,257,98815,90202,63188]

theorem envBound34806 : H12AffineFastState.Bounded env34806 := by
  intro p hp
  have h : env34806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34805_34806 : H12AffineEnvironment.transform 17 10400 env34805 = env34806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env34805 == env34806) = true)

theorem identity34806 : scanCanonicalize (H12AffineFastState.compose env34806 (packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34806 : packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1025,29908,4161,21793,95514,73736,8328,65,203846,16401,77834,223598,75223,169,257,95530,90202,513]

theorem envBound34807 : H12AffineFastState.Bounded env34807 := by
  intro p hp
  have h : env34807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34806_34807 : H12AffineEnvironment.transform 14 29909 env34806 = env34807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34806 == env34807) = true)

def env34808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1025,8660,4161,33,73754,73736,8328,65,203846,5393,77834,212078,75223,169,257,73770,79194,513]

theorem envBound34808 : H12AffineFastState.Bounded env34808 := by
  intro p hp
  have h : env34808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34807_34808 : H12AffineEnvironment.transform 13 5376 env34807 = env34808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34807 == env34808) = true)

theorem identity34808 : scanCanonicalize (H12AffineFastState.compose env34808 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34808 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1025,8541,4161,33,73754,73736,8193,65,203846,5393,77834,212078,75102,32,257,73770,79194,513]

theorem envBound34809 : H12AffineFastState.Bounded env34809 := by
  intro p hp
  have h : env34809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34808_34809 : H12AffineEnvironment.transform 6 9 env34808 = env34809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34808 == env34809) = true)

theorem identity34809 : scanCanonicalize (H12AffineFastState.compose env34809 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34809 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env34810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10281,1025,8541,4161,33,16,2,8193,65,146508,5393,4096,138340,1364,32,257,32,5456,513]

theorem envBound34810 : H12AffineFastState.Bounded env34810 := by
  intro p hp
  have h : env34810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34809_34810 : H12AffineEnvironment.transform 15 8202 env34809 = env34810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34809 == env34810) = true)

theorem identity34810 : scanCanonicalize (H12AffineFastState.compose env34810 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound34810 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13388,10281,1025,8541,4161,33,16,2,8193,65,2048,5393,4096,10280,1364,32,257,32,5456,513]

theorem envBound34811 : H12AffineFastState.Bounded env34811 := by
  intro p hp
  have h : env34811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34810_34811 : H12AffineEnvironment.transform 16 13388 env34810 = env34811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env34810 == env34811) = true)

theorem identity34811 : scanCanonicalize (H12AffineFastState.compose env34811 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound34811 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,293,115,5173,2128,1025,292,4161,33,16,2,120,65,2048,5393,4096,2129,1364,32,257,32,5456,513]

theorem envBound34812 : H12AffineFastState.Bounded env34812 := by
  intro p hp
  have h : env34812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34811_34812 : H12AffineEnvironment.transform 12 121 env34811 = env34812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env34811 == env34812) = true)

theorem identity34812 : scanCanonicalize (H12AffineFastState.compose env34812 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound34812 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,17,121,1297,293,115,1060,2128,1025,292,80,33,16,2,120,65,2048,1280,17,2129,1364,32,257,32,1345,513]

theorem envBound34813 : H12AffineFastState.Bounded env34813 := by
  intro p hp
  have h : env34813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34812_34813 : H12AffineEnvironment.transform 11 17 env34812 = env34813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34812 == env34813) = true)

def env34814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1025,8661,4161,32,73755,73736,8328,65,203846,5392,77834,212079,75223,169,257,73771,79195,513]

theorem envBound34814 : H12AffineFastState.Bounded env34814 := by
  intro p hp
  have h : env34814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34807_34814 : H12AffineEnvironment.transform 13 5377 env34807 = env34814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34807 == env34814) = true)

theorem identity34814 : scanCanonicalize (H12AffineFastState.compose env34814 (packedSelected [0,3,5,7,12,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound34814 : packedSelected [0,3,5,7,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env34815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,10400,1025,8661,4161,32,73755,73736,8328,65,75787,5392,77834,67618,75223,169,257,73771,79195,513]

theorem envBound34815 : H12AffineFastState.Bounded env34815 := by
  intro p hp
  have h : env34815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34814_34815 : H12AffineEnvironment.transform 16 13389 env34814 = env34815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env34814 == env34815) = true)

theorem identity34815 : scanCanonicalize (H12AffineFastState.compose env34815 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound34815 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8403,13389,10400,1025,8661,4161,32,200,219,8328,65,2264,5392,4313,10481,1284,169,257,248,5512,513]

theorem envBound34816 : H12AffineFastState.Bounded env34816 := by
  intro p hp
  have h : env34816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34815_34816 : H12AffineEnvironment.transform 15 8403 env34815 = env34816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env34815 == env34816) = true)

theorem identity34816 : scanCanonicalize (H12AffineFastState.compose env34816 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34816 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env34817 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,8322,13340,10400,1025,8580,4112,32,153,138,8328,16,2185,5392,4232,10400,1284,169,257,169,5512,513]

theorem envBound34817 : H12AffineFastState.Bounded env34817 := by
  intro p hp
  have h : env34817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34816_34817 : H12AffineEnvironment.transform 5 17 env34816 = env34817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34816 == env34817) = true)

theorem identity34817 : scanCanonicalize (H12AffineFastState.compose env34817 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 6548) := by decide +kernel

theorem selectedBound34817 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env34818 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,6548,5377,6161,6422,3464,4404,1025,6160,4112,32,153,138,6428,16,2185,5392,4232,4404,1284,169,257,169,5512,513]

theorem envBound34818 : H12AffineFastState.Bounded env34818 := by
  intro p hp
  have h : env34818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34817_34818 : H12AffineEnvironment.transform 12 6548 env34817 = env34818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6548 env34817 == env34818) = true)

theorem identity34818 : scanCanonicalize (H12AffineFastState.compose env34818 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34818 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env34819 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6429,5377,6161,6422,3329,4404,1025,6160,4112,32,16,3,6428,16,2048,5392,4097,4404,1284,32,257,32,5377,513]

theorem envBound34819 : H12AffineFastState.Bounded env34819 := by
  intro p hp
  have h : env34819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34818_34819 : H12AffineEnvironment.transform 6 9 env34818 = env34819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34818 == env34819) = true)

theorem identity34819 : scanCanonicalize (H12AffineFastState.compose env34819 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound34819 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34820 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2064,269,3345,1,262,3329,2340,1025,0,2048,32,16,3,268,16,2048,3328,2065,2340,1284,32,257,32,3345,513]

theorem envBound34820 : H12AffineFastState.Bounded env34820 := by
  intro p hp
  have h : env34820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34819_34820 : H12AffineEnvironment.transform 11 2064 env34819 = env34820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env34819 == env34820) = true)

theorem identity34820 : scanCanonicalize (H12AffineFastState.compose env34820 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34820 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34821 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,17,269,1296,1,262,1280,293,1025,0,1,32,16,3,268,16,1,1281,16,293,1284,32,257,32,1296,513]

theorem envBound34821 : H12AffineFastState.Bounded env34821 := by
  intro p hp
  have h : env34821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34820_34821 : H12AffineEnvironment.transform 10 1 env34820 = env34821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34820 == env34821) = true)

theorem identity34821 : scanCanonicalize (H12AffineFastState.compose env34821 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound34821 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34822 : List Nat := [2,4,8,16,32,17,9,256,512,273,1,17,269,1,1,262,17,293,272,0,1,32,16,3,268,16,1,16,16,293,21,32,257,32,1,513]

theorem envBound34822 : H12AffineFastState.Bounded env34822 := by
  intro p hp
  have h : env34822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34821_34822 : H12AffineEnvironment.transform 9 273 env34821 = env34822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34821 == env34822) = true)

theorem identity34822 : scanCanonicalize (H12AffineFastState.compose env34822 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34822 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34823 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,17,41,1,1,34,17,1,52,0,1,32,16,3,40,16,1,16,16,1,21,32,37,32,1,513]

theorem envBound34823 : H12AffineFastState.Bounded env34823 := by
  intro p hp
  have h : env34823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34822_34823 : H12AffineEnvironment.transform 7 36 env34822 = env34823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34822 == env34823) = true)

theorem identity34823 : scanCanonicalize (H12AffineFastState.compose env34823 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound34823 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34824 : List Nat := [2,4,8,16,32,17,9,36,17,53,1,17,41,1,1,34,17,1,52,0,1,32,16,3,40,16,1,16,16,1,21,32,37,32,1,16]

theorem envBound34824 : H12AffineFastState.Bounded env34824 := by
  intro p hp
  have h : env34824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34823_34824 : H12AffineEnvironment.transform 8 17 env34823 = env34824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env34823 == env34824) = true)

theorem identity34824 : scanCanonicalize (H12AffineFastState.compose env34824 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34825 : List Nat := [2,4,8,16,11,17,9,15,17,30,1,17,2,1,1,9,17,1,31,0,1,11,16,3,3,16,1,16,16,1,21,11,14,11,1,16]

theorem envBound34825 : H12AffineFastState.Bounded env34825 := by
  intro p hp
  have h : env34825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34824_34825 : H12AffineEnvironment.transform 4 11 env34824 = env34825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34824 == env34825) = true)

def env34826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,21793,95515,73737,8328,65,256146,46277,77835,236987,119042,168,257,98815,90202,63188]

theorem envBound34826 : H12AffineFastState.Bounded env34826 := by
  intro p hp
  have h : env34826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34805_34826 : H12AffineEnvironment.transform 17 10401 env34805 = env34826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env34805 == env34826) = true)

theorem identity34826 : scanCanonicalize (H12AffineFastState.compose env34826 (packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound34826 : packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5529,10401,1025,32769,4161,21793,95515,73737,8328,65,130315,46277,77835,100386,119042,168,257,98815,90202,63188]

theorem envBound34827 : H12AffineFastState.Bounded env34827 := by
  intro p hp
  have h : env34827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34826_34827 : H12AffineEnvironment.transform 16 5529 env34826 = env34827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env34826 == env34827) = true)

theorem identity34827 : scanCanonicalize (H12AffineFastState.compose env34827 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34827 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env34828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,5529,10401,1025,8540,4161,21793,95515,73737,8328,65,89174,5528,77835,76159,94303,168,257,73890,90202,22409]

theorem envBound34828 : H12AffineFastState.Bounded env34828 := by
  intro p hp
  have h : env34828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34827_34828 : H12AffineEnvironment.transform 14 8541 env34827 = env34828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34827 == env34828) = true)

theorem identity34828 : scanCanonicalize (H12AffineFastState.compose env34828 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound34828 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30083,5529,10401,1025,8540,4161,21793,152,21898,8328,65,10709,5528,17800,23804,1500,168,257,21793,5593,22409]

theorem envBound34829 : H12AffineFastState.Bounded env34829 := by
  intro p hp
  have h : env34829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34828_34829 : H12AffineEnvironment.transform 15 30083 env34828 = env34829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env34828 == env34829) = true)

theorem identity34829 : scanCanonicalize (H12AffineFastState.compose env34829 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34829 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env34830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,5393,10281,1025,8540,4161,21793,16,21762,8192,65,10589,5392,17664,23668,1364,32,257,21793,5457,22273]

theorem envBound34830 : H12AffineFastState.Bounded env34830 := by
  intro p hp
  have h : env34830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34829_34830 : H12AffineEnvironment.transform 6 8 env34829 = env34830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34829 == env34830) = true)

theorem identity34830 : scanCanonicalize (H12AffineFastState.compose env34830 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound34830 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env34831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8541,34,5393,10281,1025,8540,4161,8200,16,8235,8192,65,10589,5392,12329,10589,1364,32,257,8200,5457,8744]

theorem envBound34831 : H12AffineFastState.Bounded env34831 := by
  intro p hp
  have h : env34831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34830_34831 : H12AffineEnvironment.transform 13 13609 env34830 = env34831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env34830 == env34831) = true)

theorem identity34831 : scanCanonicalize (H12AffineFastState.compose env34831 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound34831 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env34832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2420,8192,11357,8541,34,3173,10281,1025,8540,2357,8200,16,8235,8192,65,10589,3172,10589,10589,1364,32,257,8200,3109,8744]

theorem envBound34832 : H12AffineFastState.Bounded env34832 := by
  intro p hp
  have h : env34832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34831_34832 : H12AffineEnvironment.transform 11 2420 env34831 = env34832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env34831 == env34832) = true)

theorem identity34832 : scanCanonicalize (H12AffineFastState.compose env34832 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34832 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env34833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2420,349,3328,0,34,3173,2420,1025,1,2357,341,16,374,349,65,2048,3172,2048,2048,1364,32,257,341,3109,885]

theorem envBound34833 : H12AffineFastState.Bounded env34833 := by
  intro p hp
  have h : env34833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34832_34833 : H12AffineEnvironment.transform 12 349 env34832 = env34833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34832 == env34833) = true)

theorem identity34833 : scanCanonicalize (H12AffineFastState.compose env34833 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34833 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34834 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2049,40,3189,0,34,3173,2049,1025,1,2112,32,16,3,40,65,2048,3172,2048,2048,1057,32,116,32,3109,512]

theorem envBound34834 : H12AffineFastState.Bounded env34834 := by
  intro p hp
  have h : env34834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34833_34834 : H12AffineEnvironment.transform 7 117 env34833 = env34834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34833 == env34834) = true)

theorem identity34834 : scanCanonicalize (H12AffineFastState.compose env34834 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound34834 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34835 : List Nat := [2,4,8,16,32,64,8,117,512,1024,609,608,40,1556,0,34,1540,608,1025,1,545,32,16,3,40,65,609,1541,609,609,1057,32,116,32,1604,512]

theorem envBound34835 : H12AffineFastState.Bounded env34835 := by
  intro p hp
  have h : env34835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34834_34835 : H12AffineEnvironment.transform 10 609 env34834 = env34835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env34834 == env34835) = true)

theorem identity34835 : scanCanonicalize (H12AffineFastState.compose env34835 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34835 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34836 : List Nat := [2,4,8,16,0,64,8,85,512,1024,577,576,8,1556,0,2,1540,576,1025,1,513,0,16,3,8,65,577,1541,577,577,1025,0,84,0,1604,512]

theorem envBound34836 : H12AffineFastState.Bounded env34836 := by
  intro p hp
  have h : env34836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34835_34836 : H12AffineEnvironment.transform 4 0 env34835 = env34836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34835 == env34836) = true)

theorem identity34836 : scanCanonicalize (H12AffineFastState.compose env34836 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34836 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34837 : List Nat := [2,4,8,16,0,17,8,4,512,1024,528,529,8,1556,0,2,1540,529,1025,1,513,0,16,3,8,16,528,1541,528,528,1025,0,5,0,1557,512]

theorem envBound34837 : H12AffineFastState.Bounded env34837 := by
  intro p hp
  have h : env34837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34836_34837 : H12AffineEnvironment.transform 5 17 env34836 = env34837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34836 == env34837) = true)

theorem identity34837 : scanCanonicalize (H12AffineFastState.compose env34837 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound34837 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34838 : List Nat := [2,4,8,16,0,17,8,4,17,1024,1,0,8,1029,0,2,1045,0,1025,1,16,0,16,3,8,16,1,1044,1,1,1025,0,5,0,1028,17]

theorem envBound34838 : H12AffineFastState.Bounded env34838 := by
  intro p hp
  have h : env34838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34837_34838 : H12AffineEnvironment.transform 8 17 env34837 = env34838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env34837 == env34838) = true)

theorem identity34838 : scanCanonicalize (H12AffineFastState.compose env34838 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34838 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34839 : List Nat := [2,4,8,16,0,17,8,4,17,4,1,0,8,1,0,2,17,0,5,1,16,0,16,3,8,16,1,16,1,1,5,0,5,0,0,17]

theorem envBound34839 : H12AffineFastState.Bounded env34839 := by
  intro p hp
  have h : env34839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34838_34839 : H12AffineEnvironment.transform 9 4 env34838 = env34839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34838 == env34839) = true)

def env34840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,16777216,8328,65,16959642,18973837,333994,2330106,19188203,16851104,257,17074519,17066226,19263037]

theorem envBound34840 : H12AffineFastState.Bounded env34840 := by
  intro p hp
  have h : env34840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34730_34840 : H12AffineEnvironment.transform 21 2114913 env34730 = env34840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env34730 == env34840) = true)

def env34841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431208,8328,65,2609266,302181,333994,2330106,119043,2373704,257,2199999,2191386,63189]

theorem envBound34841 : H12AffineFastState.Bounded env34841 := by
  intro p hp
  have h : env34841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34840_34841 : H12AffineEnvironment.transform 23 2431208 env34840 = env34841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env34840 == env34841) = true)

def env34842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329896,8328,65,507954,302181,333994,236986,119043,272392,257,98815,90202,63189]

theorem envBound34842 : H12AffineFastState.Bounded env34842 := by
  intro p hp
  have h : env34842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34841_34842 : H12AffineEnvironment.transform 20 4160 env34841 = env34842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34841 == env34842) = true)

theorem identity34842 : scanCanonicalize (H12AffineFastState.compose env34842 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound34842 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108926,1025,32769,4160,21793,62661,41430,8328,65,158028,79131,45524,236986,119043,98678,257,98815,90202,63189]

theorem envBound34843 : H12AffineFastState.Bounded env34843 := by
  intro p hp
  have h : env34843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34842_34843 : H12AffineEnvironment.transform 17 108926 env34842 = env34843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env34842 == env34843) = true)

theorem identity34843 : scanCanonicalize (H12AffineFastState.compose env34843 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound34843 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,89514,1025,29909,4160,21793,17,21762,8328,65,158028,79131,17664,223598,75223,95650,257,95531,90202,513]

theorem envBound34844 : H12AffineFastState.Bounded env34844 := by
  intro p hp
  have h : env34844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34843_34844 : H12AffineEnvironment.transform 14 29908 env34843 = env34844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env34843 == env34844) = true)

theorem identity34844 : scanCanonicalize (H12AffineFastState.compose env34844 (packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34844 : packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env34845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,65536,131072,89514,1025,21897,4160,21793,17,21762,468,65,149520,70727,17664,215090,66699,87294,257,87159,82182,513]

theorem envBound34845 : H12AffineFastState.Bounded env34845 := by
  intro p hp
  have h : env34845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34844_34845 : H12AffineEnvironment.transform 12 348 env34844 = env34845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34844 == env34845) = true)

theorem identity34845 : scanCanonicalize (H12AffineFastState.compose env34845 (packedSelected [1,2,3,7,8,10,11,12,15,18,19,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 71099) := by decide +kernel

theorem selectedBound34845 : packedSelected [1,2,3,7,8,10,11,12,15,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,65536,71099,89514,1025,21897,4160,21793,17,21762,468,65,89515,70727,17664,23945,66699,87294,257,87159,82182,513]

theorem envBound34846 : H12AffineFastState.Bounded env34846 := by
  intro p hp
  have h : env34846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34845_34846 : H12AffineEnvironment.transform 16 71099 env34845 = env34846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 71099 env34845 == env34846) = true)

theorem identity34846 : scanCanonicalize (H12AffineFastState.compose env34846 (packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound34846 : packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5237,509,65536,71099,68063,1025,508,4160,340,17,375,468,65,68062,70727,4469,2556,66699,65675,257,65538,71027,513]

theorem envBound34847 : H12AffineFastState.Bounded env34847 := by
  intro p hp
  have h : env34847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34846_34847 : H12AffineEnvironment.transform 13 5237 env34846 = env34847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env34846 == env34847) = true)

theorem identity34847 : scanCanonicalize (H12AffineFastState.compose env34847 (packedSelected [0,2,4,7,11,14,17,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34847 : packedSelected [0,2,4,7,11,14,17,18,22] rootPS < 2^1333 := by decide +kernel

def env34848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,372,65536,70962,67926,1025,373,4160,340,17,375,349,65,67927,70727,4469,2421,66562,65538,257,65538,71027,513]

theorem envBound34848 : H12AffineFastState.Bounded env34848 := by
  intro p hp
  have h : env34848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34847_34848 : H12AffineEnvironment.transform 6 9 env34847 = env34848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34847 == env34848) = true)

theorem identity34848 : scanCanonicalize (H12AffineFastState.compose env34848 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34848 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env34849 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,65536,70727,67619,1025,0,4160,33,17,2,40,65,67618,70727,4096,2048,66562,65538,116,65538,70662,513]

theorem envBound34849 : H12AffineFastState.Bounded env34849 := by
  intro p hp
  have h : env34849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34848_34849 : H12AffineEnvironment.transform 7 117 env34848 = env34849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34848 == env34849) = true)

theorem identity34849 : scanCanonicalize (H12AffineFastState.compose env34849 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound34849 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env34850 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1061,41,80,1,65536,65634,67619,1025,0,1125,33,17,2,40,65,67618,65634,1061,2048,66562,65538,116,65538,65571,513]

theorem envBound34850 : H12AffineFastState.Bounded env34850 := by
  intro p hp
  have h : env34850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34849_34850 : H12AffineEnvironment.transform 11 1061 env34849 = env34850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env34849 == env34850) = true)

theorem identity34850 : scanCanonicalize (H12AffineFastState.compose env34850 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound34850 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env34851 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1061,41,80,1,1047,1141,3124,1025,0,1125,33,17,2,40,65,3125,1141,1061,2048,21,1045,116,1045,1076,513]

theorem envBound34851 : H12AffineFastState.Bounded env34851 := by
  intro p hp
  have h : env34851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34850_34851 : H12AffineEnvironment.transform 15 1047 env34850 = env34851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env34850 == env34851) = true)

theorem identity34851 : scanCanonicalize (H12AffineFastState.compose env34851 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound34851 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34852 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1125,1061,41,80,1,1047,1141,81,1025,0,1125,33,17,2,40,65,80,1141,1061,1125,21,1045,116,1045,1076,513]

theorem envBound34852 : H12AffineFastState.Bounded env34852 := by
  intro p hp
  have h : env34852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34851_34852 : H12AffineEnvironment.transform 10 1125 env34851 = env34852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env34851 == env34852) = true)

theorem identity34852 : scanCanonicalize (H12AffineFastState.compose env34852 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34852 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34853 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1077,1061,41,0,1,1047,1061,1,1025,0,1077,33,17,2,40,17,0,1061,1061,1077,21,1045,36,1045,1076,513]

theorem envBound34853 : H12AffineFastState.Bounded env34853 := by
  intro p hp
  have h : env34853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34852_34853 : H12AffineEnvironment.transform 5 16 env34852 = env34853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34852 == env34853) = true)

theorem identity34853 : scanCanonicalize (H12AffineFastState.compose env34853 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34853 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env34854 : List Nat := [2,4,8,16,16,16,9,21,512,1024,1029,1045,25,0,1,1047,1045,1,1025,0,1029,17,17,2,24,17,0,1045,1045,1029,21,1045,20,1045,1028,513]

theorem envBound34854 : H12AffineFastState.Bounded env34854 := by
  intro p hp
  have h : env34854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34853_34854 : H12AffineEnvironment.transform 4 16 env34853 = env34854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34853 == env34854) = true)

theorem identity34854 : scanCanonicalize (H12AffineFastState.compose env34854 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound34854 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34855 : List Nat := [2,4,8,16,16,16,9,21,512,20,17,1,25,0,1,3,1,1,21,0,17,17,17,2,24,17,0,1,1,17,21,1,20,1,16,513]

theorem envBound34855 : H12AffineFastState.Bounded env34855 := by
  intro p hp
  have h : env34855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34854_34855 : H12AffineEnvironment.transform 9 20 env34854 = env34855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34854 == env34855) = true)

def env34856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329897,8328,65,507955,302181,333994,236987,119043,272393,257,98814,90203,63189]

theorem envBound34856 : H12AffineFastState.Bounded env34856 := by
  intro p hp
  have h : env34856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34841_34856 : H12AffineEnvironment.transform 20 4161 env34841 = env34856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34841 == env34856) = true)

theorem identity34856 : scanCanonicalize (H12AffineFastState.compose env34856 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound34856 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,21792,297316,318583,8328,65,398573,302181,314484,149861,1501,272393,257,21792,46213,63189]

theorem envBound34857 : H12AffineFastState.Bounded env34857 := by
  intro p hp
  have h : env34857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34856_34857 : H12AffineEnvironment.transform 15 54494 env34856 = env34857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env34856 == env34857) = true)

def env34858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4161,21792,41292,62559,8328,65,146629,46157,58460,149861,1501,33,257,21792,46213,63189]

theorem envBound34858 : H12AffineFastState.Bounded env34858 := by
  intro p hp
  have h : env34858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34857_34858 : H12AffineEnvironment.transform 17 10280 env34857 = env34858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env34857 == env34858) = true)

theorem identity34858 : scanCanonicalize (H12AffineFastState.compose env34858 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound34858 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,131072,10280,1025,8661,4161,21792,152,21899,8328,65,146629,5529,17800,149861,1501,33,257,21792,5457,22273]

theorem envBound34859 : H12AffineFastState.Bounded env34859 := by
  intro p hp
  have h : env34859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34858_34859 : H12AffineEnvironment.transform 14 8660 env34858 = env34859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env34858 == env34859) = true)

theorem identity34859 : scanCanonicalize (H12AffineFastState.compose env34859 (packedSelected [2,3,4,6,11,16,19,22,23,24,31] rootPS)) = affineNative (2^(16+1) ^^^ 24800) := by decide +kernel

theorem selectedBound34859 : packedSelected [2,3,4,6,11,16,19,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env34860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,24800,10280,1025,8661,4161,21792,152,21899,8328,65,23589,5529,17800,10629,1501,33,257,21792,5457,22273]

theorem envBound34860 : H12AffineFastState.Bounded env34860 := by
  intro p hp
  have h : env34860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34859_34860 : H12AffineEnvironment.transform 16 24800 env34859 = env34860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24800 env34859 == env34860) = true)

theorem identity34860 : scanCanonicalize (H12AffineFastState.compose env34860 (packedSelected [7,12,14,15,16,27] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound34860 : packedSelected [7,12,14,15,16,27] rootPS < 2^1333 := by decide +kernel

def env34861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12344,8660,1330,4312,10280,1025,8661,4161,9496,152,9651,8328,65,11293,5529,13744,10629,1501,33,257,9496,5457,10041]

theorem envBound34861 : H12AffineFastState.Bounded env34861 := by
  intro p hp
  have h : env34861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34860_34861 : H12AffineEnvironment.transform 13 12344 env34860 = env34861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env34860 == env34861) = true)

theorem identity34861 : scanCanonicalize (H12AffineFastState.compose env34861 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34861 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env34862 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,12344,8433,1047,4312,10280,1025,8432,4161,9277,152,9366,8328,65,11293,5308,13461,10400,1272,33,36,9277,5236,9756]

theorem envBound34862 : H12AffineFastState.Bounded env34862 := by
  intro p hp
  have h : env34862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34861_34862 : H12AffineEnvironment.transform 7 37 env34861 = env34862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34861 == env34862) = true)

theorem identity34862 : scanCanonicalize (H12AffineFastState.compose env34862 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound34862 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env34863 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,120,4160,137,1047,4312,2128,1025,136,4161,1093,152,1262,240,65,3173,5308,5357,2264,1272,33,36,1093,5236,1636]

theorem envBound34863 : H12AffineFastState.Bounded env34863 := by
  intro p hp
  have h : env34863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34862_34863 : H12AffineEnvironment.transform 12 120 env34862 = env34863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env34862 == env34863) = true)

theorem identity34863 : scanCanonicalize (H12AffineFastState.compose env34863 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34863 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env34864 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,4096,120,4160,81,1047,4096,2128,1025,80,4161,1093,64,1078,40,65,3173,5220,5173,2048,1056,33,36,1093,5236,1636]

theorem envBound34864 : H12AffineFastState.Bounded env34864 := by
  intro p hp
  have h : env34864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34863_34864 : H12AffineEnvironment.transform 6 88 env34863 = env34864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34863 == env34864) = true)

theorem identity34864 : scanCanonicalize (H12AffineFastState.compose env34864 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34864 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34865 : List Nat := [2,4,8,16,32,64,88,37,512,52,2048,4096,120,4160,81,35,4096,2128,53,80,4161,113,64,2,40,65,2129,4176,4097,2048,20,33,36,113,4160,592]

theorem envBound34865 : H12AffineFastState.Bounded env34865 := by
  intro p hp
  have h : env34865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34864_34865 : H12AffineEnvironment.transform 9 52 env34864 = env34865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34864 == env34865) = true)

theorem identity34865 : scanCanonicalize (H12AffineFastState.compose env34865 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound34865 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34866 : List Nat := [2,4,8,16,32,64,88,37,512,52,81,4096,120,4160,81,35,4096,1,53,80,4161,113,64,2,40,65,0,4176,4097,81,20,33,36,113,4160,592]

theorem envBound34866 : H12AffineFastState.Bounded env34866 := by
  intro p hp
  have h : env34866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34865_34866 : H12AffineEnvironment.transform 10 81 env34865 = env34866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env34865 == env34866) = true)

theorem identity34866 : scanCanonicalize (H12AffineFastState.compose env34866 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound34866 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34867 : List Nat := [2,4,8,16,32,64,88,37,512,52,81,64,120,0,81,35,64,1,53,80,1,113,64,2,40,65,0,16,65,81,20,33,36,113,0,592]

theorem envBound34867 : H12AffineFastState.Bounded env34867 := by
  intro p hp
  have h : env34867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34866_34867 : H12AffineEnvironment.transform 11 64 env34866 = env34867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env34866 == env34867) = true)

def env34868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4161,21792,41293,62558,8328,65,146628,46156,58461,149861,1501,32,257,21792,46213,63189]

theorem envBound34868 : H12AffineFastState.Bounded env34868 := by
  intro p hp
  have h : env34868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34857_34868 : H12AffineEnvironment.transform 17 10281 env34857 = env34868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34857 == env34868) = true)

def env34869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,5528,10281,1025,32769,4161,21792,41293,62558,8328,65,10588,46156,58461,23805,1501,32,257,21792,46213,63189]

theorem envBound34869 : H12AffineFastState.Bounded env34869 := by
  intro p hp
  have h : env34869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34868_34869 : H12AffineEnvironment.transform 16 5528 env34868 = env34869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env34868 == env34869) = true)

theorem identity34869 : scanCanonicalize (H12AffineFastState.compose env34869 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound34869 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env34870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33110,5528,10281,1025,32769,4161,168,41293,41430,8328,65,10588,46156,45525,2421,1501,32,257,168,46213,41821]

theorem envBound34870 : H12AffineFastState.Bounded env34870 := by
  intro p hp
  have h : env34870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34869_34870 : H12AffineEnvironment.transform 13 5512 env34869 = env34870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34869 == env34870) = true)

theorem identity34870 : scanCanonicalize (H12AffineFastState.compose env34870 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound34870 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,137,479,5528,10281,1025,136,4161,168,8644,8543,8328,65,10588,13509,12636,2421,1501,32,257,168,13324,9172]

theorem envBound34871 : H12AffineFastState.Bounded env34871 := by
  intro p hp
  have h : env34871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34870_34871 : H12AffineEnvironment.transform 14 137 env34870 = env34871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env34870 == env34871) = true)

theorem identity34871 : scanCanonicalize (H12AffineFastState.compose env34871 (packedSelected [6,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34871 : packedSelected [6,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env34872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,137,479,5528,2340,1025,136,4161,168,201,82,389,65,2129,5576,4177,2421,1501,32,257,168,5377,729]

theorem envBound34872 : H12AffineFastState.Bounded env34872 := by
  intro p hp
  have h : env34872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34871_34872 : H12AffineEnvironment.transform 12 269 env34871 = env34872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34871 == env34872) = true)

theorem identity34872 : scanCanonicalize (H12AffineFastState.compose env34872 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound34872 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env34873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,508,269,1140,137,479,1124,2340,1025,136,445,168,201,82,389,65,2129,1076,429,2421,1501,32,257,168,1277,729]

theorem envBound34873 : H12AffineFastState.Bounded env34873 := by
  intro p hp
  have h : env34873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34872_34873 : H12AffineEnvironment.transform 11 508 env34872 = env34873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env34872 == env34873) = true)

theorem identity34873 : scanCanonicalize (H12AffineFastState.compose env34873 (packedSelected [1,2,6,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound34873 : packedSelected [1,2,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env34874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,340,508,269,1140,137,479,1124,112,1025,136,445,168,201,82,389,65,261,1076,429,33,1501,32,257,168,1277,729]

theorem envBound34874 : H12AffineFastState.Bounded env34874 := by
  intro p hp
  have h : env34874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34873_34874 : H12AffineEnvironment.transform 10 340 env34873 = env34874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env34873 == env34874) = true)

theorem identity34874 : scanCanonicalize (H12AffineFastState.compose env34874 (packedSelected [0,2,5,6,7,8,16] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound34874 : packedSelected [0,2,5,6,7,8,16] rootPS < 2^1333 := by decide +kernel

def env34875 : List Nat := [2,4,8,16,32,64,128,215,512,1024,131,43,218,1140,137,8,1124,112,1025,136,106,168,201,82,82,65,210,1076,122,33,1034,32,214,168,1277,729]

theorem envBound34875 : H12AffineFastState.Bounded env34875 := by
  intro p hp
  have h : env34875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34874_34875 : H12AffineEnvironment.transform 7 215 env34874 = env34875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env34874 == env34875) = true)

theorem identity34875 : scanCanonicalize (H12AffineFastState.compose env34875 (packedSelected [0,2,3,6,7,8,19] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34875 : packedSelected [0,2,3,6,7,8,19] rootPS < 2^1333 := by decide +kernel

def env34876 : List Nat := [2,4,8,16,32,64,88,15,512,1024,91,43,2,1140,81,8,1124,112,1025,80,106,112,17,82,82,65,10,1076,122,33,1034,32,14,112,1061,513]

theorem envBound34876 : H12AffineFastState.Bounded env34876 := by
  intro p hp
  have h : env34876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34875_34876 : H12AffineEnvironment.transform 6 88 env34875 = env34876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34875 == env34876) = true)

theorem identity34876 : scanCanonicalize (H12AffineFastState.compose env34876 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34876 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34877 : List Nat := [2,4,8,16,32,64,88,15,512,4,91,43,2,112,81,8,96,112,5,80,106,112,17,82,82,65,10,48,122,33,14,32,14,112,33,513]

theorem envBound34877 : H12AffineFastState.Bounded env34877 := by
  intro p hp
  have h : env34877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34876_34877 : H12AffineEnvironment.transform 9 4 env34876 = env34877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34876 == env34877) = true)

theorem identity34877 : scanCanonicalize (H12AffineFastState.compose env34877 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34877 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34878 : List Nat := [2,4,8,16,32,16,8,15,512,4,11,43,2,32,1,8,48,32,5,0,58,32,17,2,2,17,10,48,42,33,14,32,14,32,33,513]

theorem envBound34878 : H12AffineFastState.Bounded env34878 := by
  intro p hp
  have h : env34878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34877_34878 : H12AffineEnvironment.transform 5 16 env34877 = env34878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34877 == env34878) = true)

theorem identity34878 : scanCanonicalize (H12AffineFastState.compose env34878 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34879 : List Nat := [2,4,8,16,16,16,8,15,512,4,11,27,2,16,1,8,0,16,5,0,10,16,17,2,2,17,10,0,26,17,14,16,14,16,17,513]

theorem envBound34879 : H12AffineFastState.Bounded env34879 := by
  intro p hp
  have h : env34879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34878_34879 : H12AffineEnvironment.transform 4 16 env34878 = env34879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34878 == env34879) = true)

theorem identity34879 : scanCanonicalize (H12AffineFastState.compose env34879 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34879 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34880 : List Nat := [2,3,8,16,16,16,8,8,512,3,11,27,2,16,1,8,0,16,2,0,10,16,17,2,2,17,10,0,26,17,9,16,9,16,17,513]

theorem envBound34880 : H12AffineFastState.Bounded env34880 := by
  intro p hp
  have h : env34880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34879_34880 : H12AffineEnvironment.transform 1 3 env34879 = env34880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34879 == env34880) = true)

theorem identity34880 : scanCanonicalize (H12AffineFastState.compose env34880 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34880 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env34881 : List Nat := [2,3,8,10,10,10,8,8,512,3,11,1,2,10,1,8,0,10,2,0,10,10,11,2,2,11,10,0,0,11,9,10,9,10,11,513]

theorem envBound34881 : H12AffineFastState.Bounded env34881 := by
  intro p hp
  have h : env34881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34880_34881 : H12AffineEnvironment.transform 3 10 env34880 = env34881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34880 == env34881) = true)

theorem identity34881 : scanCanonicalize (H12AffineFastState.compose env34881 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34882 : List Nat := [2,3,0,2,2,2,0,0,512,3,3,1,2,2,1,0,0,2,2,0,2,2,3,2,2,3,2,0,0,3,1,2,1,2,3,513]

theorem envBound34882 : H12AffineFastState.Bounded env34882 := by
  intro p hp
  have h : env34882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34881_34882 : H12AffineEnvironment.transform 2 0 env34881 = env34882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34881 == env34882) = true)

def env34883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,5529,10281,1025,32769,4161,21792,41293,62558,8328,65,10589,46156,58461,23804,1501,32,257,21792,46213,63189]

theorem envBound34883 : H12AffineFastState.Bounded env34883 := by
  intro p hp
  have h : env34883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34868_34883 : H12AffineEnvironment.transform 16 5529 env34868 = env34883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env34868 == env34883) = true)

theorem identity34883 : scanCanonicalize (H12AffineFastState.compose env34883 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound34883 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env34884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,343,5529,10281,1025,21896,4161,21792,29892,8663,8328,65,10589,25029,12756,23804,1501,32,257,21792,24844,9052]

theorem envBound34884 : H12AffineFastState.Bounded env34884 := by
  intro p hp
  have h : env34884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34883_34884 : H12AffineEnvironment.transform 14 21897 env34883 = env34884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env34883 == env34884) = true)

theorem identity34884 : scanCanonicalize (H12AffineFastState.compose env34884 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34884 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,343,5529,2420,1025,21896,4161,21792,21913,138,469,65,2048,16536,4233,23804,1501,32,257,21792,16465,513]

theorem envBound34885 : H12AffineFastState.Bounded env34885 := by
  intro p hp
  have h : env34885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34884_34885 : H12AffineEnvironment.transform 12 349 env34884 = env34885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34884 == env34885) = true)

theorem identity34885 : scanCanonicalize (H12AffineFastState.compose env34885 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound34885 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,1,343,5529,2420,1025,0,4161,168,17,138,469,65,2048,5392,4233,2420,1501,32,257,168,5593,513]

theorem envBound34886 : H12AffineFastState.Bounded env34886 := by
  intro p hp
  have h : env34886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34885_34886 : H12AffineEnvironment.transform 13 5512 env34885 = env34886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34885 == env34886) = true)

theorem identity34886 : scanCanonicalize (H12AffineFastState.compose env34886 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34886 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34887 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5456,1,343,5441,2420,1025,0,4161,112,17,82,269,65,2048,5392,4177,2420,1285,32,257,112,5377,513]

theorem envBound34887 : H12AffineFastState.Bounded env34887 := by
  intro p hp
  have h : env34887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34886_34887 : H12AffineEnvironment.transform 6 88 env34886 = env34887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34886 == env34887) = true)

theorem identity34887 : scanCanonicalize (H12AffineFastState.compose env34887 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34887 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34888 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,121,5236,1,115,5221,2128,1025,0,4161,112,17,82,41,65,2048,5172,4177,2128,1057,32,37,112,5157,513]

theorem envBound34888 : H12AffineFastState.Bounded env34888 := by
  intro p hp
  have h : env34888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34887_34888 : H12AffineEnvironment.transform 7 36 env34887 = env34888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34887 == env34888) = true)

theorem identity34888 : scanCanonicalize (H12AffineFastState.compose env34888 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34888 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34889 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2049,1025,0,4112,33,17,3,41,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound34889 : H12AffineFastState.Bounded env34889 := by
  intro p hp
  have h : env34889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34888_34889 : H12AffineEnvironment.transform 5 17 env34888 = env34889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34888 == env34889) = true)

def env34890 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,1,34,1028,2049,1025,0,32,33,17,3,41,16,2048,1028,48,2049,1057,32,37,33,1045,513]

theorem envBound34890 : H12AffineFastState.Bounded env34890 := by
  intro p hp
  have h : env34890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34889_34890 : H12AffineEnvironment.transform 11 48 env34889 = env34890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34889 == env34890) = true)

theorem identity34890 : scanCanonicalize (H12AffineFastState.compose env34890 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound34890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34891 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,48,40,0,1,34,17,2049,20,0,32,33,17,3,41,16,2048,17,48,2049,52,32,37,33,0,513]

theorem envBound34891 : H12AffineFastState.Bounded env34891 := by
  intro p hp
  have h : env34891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34890_34891 : H12AffineEnvironment.transform 9 21 env34890 = env34891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34890 == env34891) = true)

def env34892 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,8,0,1,2,17,2049,20,0,0,1,17,3,9,16,2048,17,16,2049,20,0,5,1,0,513]

theorem envBound34892 : H12AffineFastState.Bounded env34892 := by
  intro p hp
  have h : env34892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34891_34892 : H12AffineEnvironment.transform 4 0 env34891 = env34892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34891 == env34892) = true)

theorem identity34892 : scanCanonicalize (H12AffineFastState.compose env34892 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound34892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34893 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,16,8,0,1,2,17,523,20,0,0,1,17,3,9,16,522,17,16,523,20,0,5,1,0,513]

theorem envBound34893 : H12AffineFastState.Bounded env34893 := by
  intro p hp
  have h : env34893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34892_34893 : H12AffineEnvironment.transform 10 522 env34892 = env34893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env34892 == env34893) = true)

def leafEnv34893 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,16,8,0,1,2,17,523,20,0,0,1,17,3,21,9,1,16,522,17,16,523,20,0,5,1,5,3,0,513,1,0,0]

def active34893 : List Nat := [0,1,2,3,8]

def tree34893 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34893 : H12WitnessSearch.Good tree34893 := H12GlobalWitnessIndex.good

theorem leafIdentity34893 : H12AffineFastState.composeSystem env34893 rootObs = leafEnv34893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34893 rootObs == leafEnv34893) = true)

theorem terminalChecked34893 : H12PackedTerminal.terminalCheckFast leafEnv34893 active34893 tree34893 = true := by decide +kernel

def env34894 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,0,1,3,17,2049,20,0,1,0,17,3,8,16,2048,17,17,2049,21,1,4,0,0,513]

theorem envBound34894 : H12AffineFastState.Bounded env34894 := by
  intro p hp
  have h : env34894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34891_34894 : H12AffineEnvironment.transform 4 1 env34891 = env34894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34891 == env34894) = true)

theorem identity34894 : scanCanonicalize (H12AffineFastState.compose env34894 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34895 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,0,1,3,17,0,20,0,1,0,17,3,8,16,1,17,17,0,21,1,4,0,0,513]

theorem envBound34895 : H12AffineFastState.Bounded env34895 := by
  intro p hp
  have h : env34895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34894_34895 : H12AffineEnvironment.transform 10 1 env34894 = env34895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34894 == env34895) = true)

def leafEnv34895 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,0,1,3,17,0,20,0,1,0,17,3,20,8,1,16,1,17,17,0,21,1,4,0,5,2,0,513,1,1,0]

def active34895 : List Nat := [0,1,2,3,8]

def tree34895 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34895 : H12WitnessSearch.Good tree34895 := H12GlobalWitnessIndex.good

theorem leafIdentity34895 : H12AffineFastState.composeSystem env34895 rootObs = leafEnv34895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34895 rootObs == leafEnv34895) = true)

theorem terminalChecked34895 : H12PackedTerminal.terminalCheckFast leafEnv34895 active34895 tree34895 = true := by decide +kernel

def env34896 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,1,34,1029,2049,1025,0,33,33,17,3,41,16,2048,1029,49,2049,1057,32,37,33,1044,513]

theorem envBound34896 : H12AffineFastState.Bounded env34896 := by
  intro p hp
  have h : env34896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34889_34896 : H12AffineEnvironment.transform 11 49 env34889 = env34896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34889 == env34896) = true)

theorem identity34896 : scanCanonicalize (H12AffineFastState.compose env34896 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34897 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1044,1,3,1029,2049,1025,0,0,0,17,3,8,16,2048,1029,16,2049,1024,1,4,0,1044,513]

theorem envBound34897 : H12AffineFastState.Bounded env34897 := by
  intro p hp
  have h : env34897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34896_34897 : H12AffineEnvironment.transform 4 1 env34896 = env34897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34896 == env34897) = true)

def env34898 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,0,1,3,17,2049,21,0,0,0,17,3,8,16,2048,17,16,2049,20,1,4,0,0,513]

theorem envBound34898 : H12AffineFastState.Bounded env34898 := by
  intro p hp
  have h : env34898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34897_34898 : H12AffineEnvironment.transform 9 20 env34897 = env34898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34897 == env34898) = true)

theorem identity34898 : scanCanonicalize (H12AffineFastState.compose env34898 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34899 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,16,9,0,1,3,17,522,21,0,0,0,17,3,8,16,523,17,16,522,20,1,4,0,0,513]

theorem envBound34899 : H12AffineFastState.Bounded env34899 := by
  intro p hp
  have h : env34899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34898_34899 : H12AffineEnvironment.transform 10 523 env34898 = env34899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34898 == env34899) = true)

def leafEnv34899 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,16,9,0,1,3,17,522,21,0,0,0,17,3,21,8,1,16,523,17,16,522,20,1,4,0,5,2,0,513,1,0,0]

def active34899 : List Nat := [0,1,2,3,8]

def tree34899 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34899 : H12WitnessSearch.Good tree34899 := H12GlobalWitnessIndex.good

theorem leafIdentity34899 : H12AffineFastState.composeSystem env34899 rootObs = leafEnv34899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34899 rootObs == leafEnv34899) = true)

theorem terminalChecked34899 : H12PackedTerminal.terminalCheckFast leafEnv34899 active34899 tree34899 = true := by decide +kernel

def env34900 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,9,1,1,3,16,2049,20,0,0,0,17,3,8,16,2048,16,16,2049,21,1,4,0,1,513]

theorem envBound34900 : H12AffineFastState.Bounded env34900 := by
  intro p hp
  have h : env34900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34897_34900 : H12AffineEnvironment.transform 9 21 env34897 = env34900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34897 == env34900) = true)

theorem identity34900 : scanCanonicalize (H12AffineFastState.compose env34900 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34900 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34901 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,1,1,3,16,1,20,0,0,0,17,3,8,16,0,16,16,1,21,1,4,0,1,513]

theorem envBound34901 : H12AffineFastState.Bounded env34901 := by
  intro p hp
  have h : env34901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34900_34901 : H12AffineEnvironment.transform 10 0 env34900 = env34901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34900 == env34901) = true)

def leafEnv34901 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,1,1,3,16,1,20,0,0,0,17,3,20,8,1,16,0,16,16,1,21,1,4,0,5,2,1,513,1,0,0]

def active34901 : List Nat := [0,1,2,3,8]

def tree34901 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34901 : H12WitnessSearch.Good tree34901 := H12GlobalWitnessIndex.good

theorem leafIdentity34901 : H12AffineFastState.composeSystem env34901 rootObs = leafEnv34901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34901 rootObs == leafEnv34901) = true)

theorem terminalChecked34901 : H12PackedTerminal.terminalCheckFast leafEnv34901 active34901 tree34901 = true := by decide +kernel

def env34902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431209,8328,65,2609267,302180,333994,2330106,119042,2373705,257,2199998,2191387,63188]

theorem envBound34902 : H12AffineFastState.Bounded env34902 := by
  intro p hp
  have h : env34902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34840_34902 : H12AffineEnvironment.transform 23 2431209 env34840 = env34902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env34840 == env34902) = true)

def env34903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329897,8328,65,507955,302180,333994,236986,119042,272393,257,98814,90203,63188]

theorem envBound34903 : H12AffineFastState.Bounded env34903 := by
  intro p hp
  have h : env34903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34902_34903 : H12AffineEnvironment.transform 20 4160 env34902 = env34903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34902 == env34903) = true)

theorem identity34903 : scanCanonicalize (H12AffineFastState.compose env34903 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34903 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,21793,294321,272547,8328,65,450617,302180,276640,179632,61704,272393,257,41460,16465,63188]

theorem envBound34904 : H12AffineFastState.Bounded env34904 := by
  intro p hp
  have h : env34904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34903_34904 : H12AffineEnvironment.transform 15 8202 env34903 = env34904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34903 == env34904) = true)

def env34905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,21793,294201,272427,8192,65,450617,302180,276520,179512,61704,272393,257,41340,16465,63068]

theorem envBound34905 : H12AffineFastState.Bounded env34905 := by
  intro p hp
  have h : env34905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34904_34905 : H12AffineEnvironment.transform 6 8 env34904 = env34905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34904 == env34905) = true)

theorem identity34905 : scanCanonicalize (H12AffineFastState.compose env34905 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound34905 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,262144,1025,32769,4160,21793,294201,272427,8192,65,283765,302180,276520,2420,61704,272393,257,41340,16465,63068]

theorem envBound34906 : H12AffineFastState.Bounded env34906 := by
  intro p hp
  have h : env34906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34905_34906 : H12AffineEnvironment.transform 16 46156 env34905 = env34906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env34905 == env34906) = true)

theorem identity34906 : scanCanonicalize (H12AffineFastState.compose env34906 (packedSelected [0,9,17,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound34906 : packedSelected [0,9,17,22,27] rootPS < 2^1333 := by decide +kernel

def env34907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,10361,1025,32769,4160,21793,21824,82,8192,65,31756,46109,4177,2420,61704,112,257,41340,16465,63068]

theorem envBound34907 : H12AffineFastState.Bounded env34907 := by
  intro p hp
  have h : env34907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34906_34907 : H12AffineEnvironment.transform 17 10361 env34906 = env34907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env34906 == env34907) = true)

theorem identity34907 : scanCanonicalize (H12AffineFastState.compose env34907 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34907 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,38209,2420,1025,32769,4160,21793,21824,82,269,65,23809,38160,4177,2420,53253,112,257,32881,16465,55121]

theorem envBound34908 : H12AffineFastState.Bounded env34908 := by
  intro p hp
  have h : env34908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34907_34908 : H12AffineEnvironment.transform 12 269 env34907 = env34908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34907 == env34908) = true)

theorem identity34908 : scanCanonicalize (H12AffineFastState.compose env34908 (packedSelected [2,3,4,6,7,8,12,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound34908 : packedSelected [2,3,4,6,7,8,12,16,17,19] rootPS < 2^1333 := by decide +kernel

def env34909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,3344,32768,263,38209,2420,1025,32769,4160,6193,6224,82,269,65,4113,38160,4177,2420,40213,112,257,32881,3393,39489]

theorem envBound34909 : H12AffineFastState.Bounded env34909 := by
  intro p hp
  have h : env34909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34908_34909 : H12AffineEnvironment.transform 13 3344 env34908 = env34909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env34908 == env34909) = true)

theorem identity34909 : scanCanonicalize (H12AffineFastState.compose env34909 (packedSelected [0,1,4,5,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound34909 : packedSelected [0,1,4,5,11,12,14] rootPS < 2^1333 := by decide +kernel

def env34910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,3344,373,263,5172,2420,1025,372,4160,6193,6224,82,269,65,4113,5221,4177,2420,7264,112,257,260,3393,6964]

theorem envBound34910 : H12AffineFastState.Bounded env34910 := by
  intro p hp
  have h : env34910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34909_34910 : H12AffineEnvironment.transform 14 373 env34909 = env34910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env34909 == env34910) = true)

theorem identity34910 : scanCanonicalize (H12AffineFastState.compose env34910 (packedSelected [0,2,3,6,8,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34910 : packedSelected [0,2,3,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34911 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,3173,0,114,5172,2049,1025,1,4160,6193,6224,82,120,65,4113,5221,4177,2049,7264,112,116,113,3124,6721]

theorem envBound34911 : H12AffineFastState.Bounded env34911 := by
  intro p hp
  have h : env34911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34910_34911 : H12AffineEnvironment.transform 7 117 env34910 = env34911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34910 == env34911) = true)

theorem identity34911 : scanCanonicalize (H12AffineFastState.compose env34911 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound34911 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34912 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3188,120,3173,0,114,2112,2049,1025,1,3124,1093,1060,82,120,65,3173,2065,3109,2049,20,112,116,113,3124,1589]

theorem envBound34912 : H12AffineFastState.Bounded env34912 := by
  intro p hp
  have h : env34912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34911_34912 : H12AffineEnvironment.transform 11 3188 env34911 = env34912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env34911 == env34912) = true)

theorem identity34912 : scanCanonicalize (H12AffineFastState.compose env34912 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound34912 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34913 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,3076,8,3093,0,2,2096,2049,1025,1,3124,1077,1060,34,8,49,3093,2065,3109,2049,20,0,4,1,3124,1589]

theorem envBound34913 : H12AffineFastState.Bounded env34913 := by
  intro p hp
  have h : env34913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34912_34913 : H12AffineEnvironment.transform 5 48 env34912 = env34913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env34912 == env34913) = true)

theorem identity34913 : scanCanonicalize (H12AffineFastState.compose env34913 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound34913 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env34914 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,2064,8,2049,0,2,2096,2049,21,1,2080,33,48,34,8,49,2049,2065,2097,2049,20,0,4,1,2080,545]

theorem envBound34914 : H12AffineFastState.Bounded env34914 := by
  intro p hp
  have h : env34914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34913_34914 : H12AffineEnvironment.transform 9 20 env34913 = env34914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34913 == env34914) = true)

theorem identity34914 : scanCanonicalize (H12AffineFastState.compose env34914 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34914 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34915 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,2064,8,2049,0,2,2064,2049,21,1,2048,1,16,2,8,17,2049,2065,2065,2049,20,0,4,1,2048,513]

theorem envBound34915 : H12AffineFastState.Bounded env34915 := by
  intro p hp
  have h : env34915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34914_34915 : H12AffineEnvironment.transform 4 0 env34914 = env34915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34914 == env34915) = true)

theorem identity34915 : scanCanonicalize (H12AffineFastState.compose env34915 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound34915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34916 : List Nat := [2,4,8,16,0,16,8,5,512,20,17,1,8,16,0,2,1,16,21,1,17,1,16,2,8,17,16,0,0,16,20,0,4,1,17,513]

theorem envBound34916 : H12AffineFastState.Bounded env34916 := by
  intro p hp
  have h : env34916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34915_34916 : H12AffineEnvironment.transform 10 17 env34915 = env34916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env34915 == env34916) = true)

theorem identity34916 : scanCanonicalize (H12AffineFastState.compose env34916 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound34916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34917 : List Nat := [2,4,8,16,0,16,8,5,10,20,17,1,8,16,0,2,1,16,21,1,17,1,16,2,8,17,16,0,0,16,20,0,4,1,17,11]

theorem envBound34917 : H12AffineFastState.Bounded env34917 := by
  intro p hp
  have h : env34917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34916_34917 : H12AffineEnvironment.transform 8 10 env34916 = env34917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env34916 == env34917) = true)

theorem identity34917 : scanCanonicalize (H12AffineFastState.compose env34917 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34917 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34918 : List Nat := [2,4,8,11,0,11,8,5,10,15,10,1,8,11,0,2,1,11,14,1,10,1,11,2,8,10,11,0,0,11,15,0,4,1,10,11]

theorem envBound34918 : H12AffineFastState.Bounded env34918 := by
  intro p hp
  have h : env34918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34917_34918 : H12AffineEnvironment.transform 3 11 env34917 = env34918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34917 == env34918) = true)

theorem identity34918 : scanCanonicalize (H12AffineFastState.compose env34918 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34918 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env34919 : List Nat := [2,4,3,0,0,0,3,5,1,4,1,1,3,0,0,2,1,0,5,1,1,1,0,2,3,1,0,0,0,0,4,0,4,1,1,0]

theorem envBound34919 : H12AffineFastState.Bounded env34919 := by
  intro p hp
  have h : env34919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34918_34919 : H12AffineEnvironment.transform 2 3 env34918 = env34919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34918 == env34919) = true)

def env34920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,21793,294200,272426,8193,65,450617,302180,276521,179513,61704,272393,257,41341,16465,63069]

theorem envBound34920 : H12AffineFastState.Bounded env34920 := by
  intro p hp
  have h : env34920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34904_34920 : H12AffineEnvironment.transform 6 9 env34904 = env34920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34904 == env34920) = true)

theorem identity34920 : scanCanonicalize (H12AffineFastState.compose env34920 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34920 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,262144,1025,29789,4160,21793,294200,272426,8193,65,398437,288824,276521,149861,1364,272393,257,21793,16465,513]

theorem envBound34921 : H12AffineFastState.Bounded env34921 := by
  intro p hp
  have h : env34921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34920_34921 : H12AffineEnvironment.transform 14 29788 env34920 = env34921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34920 == env34921) = true)

theorem identity34921 : scanCanonicalize (H12AffineFastState.compose env34921 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34921 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env34922 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,262144,1025,29708,4113,21793,294200,272426,8193,16,398388,288824,276521,149812,1285,272393,257,21793,16384,513]

theorem envBound34922 : H12AffineFastState.Bounded env34922 := by
  intro p hp
  have h : env34922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34921_34922 : H12AffineEnvironment.transform 5 17 env34921 = env34922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34921 == env34922) = true)

theorem identity34922 : scanCanonicalize (H12AffineFastState.compose env34922 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound34922 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env34923 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,32041,1025,29708,4113,21793,17,21763,8193,16,157981,5393,17664,149812,1285,21792,257,21793,16384,513]

theorem envBound34923 : H12AffineFastState.Bounded env34923 := by
  intro p hp
  have h : env34923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34922_34923 : H12AffineEnvironment.transform 17 32041 env34922 = env34923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env34922 == env34923) = true)

theorem identity34923 : scanCanonicalize (H12AffineFastState.compose env34923 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound34923 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34924 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,24861,32041,1025,29708,4113,21793,17,21763,8193,16,2048,5393,17664,10281,1285,21792,257,21793,16384,513]

theorem envBound34924 : H12AffineFastState.Bounded env34924 := by
  intro p hp
  have h : env34924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34923_34924 : H12AffineEnvironment.transform 16 24861 env34923 = env34924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env34923 == env34924) = true)

theorem identity34924 : scanCanonicalize (H12AffineFastState.compose env34924 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34924 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env34925 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8202,5393,2341,1025,0,4113,8493,17,8463,8193,16,2048,5393,12556,10281,1285,8492,257,8493,13324,513]

theorem envBound34925 : H12AffineFastState.Bounded env34925 := by
  intro p hp
  have h : env34925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34924_34925 : H12AffineEnvironment.transform 13 13324 env34924 = env34925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34924 == env34925) = true)

theorem identity34925 : scanCanonicalize (H12AffineFastState.compose env34925 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34925 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34926 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4113,33,17,3,269,16,2048,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound34926 : H12AffineFastState.Bounded env34926 := by
  intro p hp
  have h : env34926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34925_34926 : H12AffineEnvironment.transform 12 268 env34925 = env34926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34925 == env34926) = true)

theorem identity34926 : scanCanonicalize (H12AffineFastState.compose env34926 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34926 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34927 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5173,2049,1025,0,4113,33,17,3,41,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound34927 : H12AffineFastState.Bounded env34927 := by
  intro p hp
  have h : env34927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34926_34927 : H12AffineEnvironment.transform 7 36 env34926 = env34927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34926 == env34927) = true)

def env34928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329896,8328,65,507954,302180,333994,236987,119042,272392,257,98815,90202,63188]

theorem envBound34928 : H12AffineFastState.Bounded env34928 := by
  intro p hp
  have h : env34928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34902_34928 : H12AffineEnvironment.transform 20 4161 env34902 = env34928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34902 == env34928) = true)

theorem identity34928 : scanCanonicalize (H12AffineFastState.compose env34928 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound34928 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1025,32769,4161,21792,17,21763,8328,65,171417,115151,17665,236987,119042,95651,257,98815,90202,63188]

theorem envBound34929 : H12AffineFastState.Bounded env34929 := by
  intro p hp
  have h : env34929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34928_34929 : H12AffineEnvironment.transform 17 89515 env34928 = env34929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env34928 == env34929) = true)

def env34930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,4161,21792,17,21763,8192,65,171281,115015,17665,236851,119042,95531,257,98679,90202,63068]

theorem envBound34930 : H12AffineFastState.Bounded env34930 := by
  intro p hp
  have h : env34930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34929_34930 : H12AffineEnvironment.transform 6 8 env34929 = env34930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34929 == env34930) = true)

theorem identity34930 : scanCanonicalize (H12AffineFastState.compose env34930 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34930 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,89379,1025,8541,4161,21792,17,21763,8192,65,146509,90139,17665,212079,94302,95531,257,73771,90202,22272]

theorem envBound34931 : H12AffineFastState.Bounded env34931 := by
  intro p hp
  have h : env34931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34930_34931 : H12AffineEnvironment.transform 14 8540 env34930 = env34931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34930 == env34931) = true)

theorem identity34931 : scanCanonicalize (H12AffineFastState.compose env34931 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34931 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env34932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,32041,1025,8541,4161,21792,17,21763,8192,65,146509,16401,17665,138341,20564,21793,257,33,16464,22272]

theorem envBound34932 : H12AffineFastState.Bounded env34932 := by
  intro p hp
  have h : env34932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34931_34932 : H12AffineEnvironment.transform 15 8202 env34931 = env34932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34931 == env34932) = true)

theorem identity34932 : scanCanonicalize (H12AffineFastState.compose env34932 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound34932 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env34933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8540,8202,131072,10588,1025,8541,4161,341,17,374,8192,65,146509,5220,4468,138341,1057,340,257,33,5157,885]

theorem envBound34933 : H12AffineFastState.Bounded env34933 := by
  intro p hp
  have h : env34933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34932_34933 : H12AffineEnvironment.transform 13 5237 env34932 = env34933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env34932 == env34933) = true)

theorem identity34933 : scanCanonicalize (H12AffineFastState.compose env34933 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34933 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env34934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,81,263,131072,2129,1025,80,4161,341,17,374,269,65,138560,5220,4468,138341,1057,340,257,33,5157,885]

theorem envBound34934 : H12AffineFastState.Bounded env34934 := by
  intro p hp
  have h : env34934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34933_34934 : H12AffineEnvironment.transform 12 269 env34933 = env34934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34933 == env34934) = true)

theorem identity34934 : scanCanonicalize (H12AffineFastState.compose env34934 (packedSelected [0,1,2,4,7,8,9,10,11,12,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34934 : packedSelected [0,1,2,4,7,8,9,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env34935 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,0,263,131072,2048,1025,1,4112,260,17,295,269,16,138513,5173,4389,138292,1057,261,257,33,5157,804]

theorem envBound34935 : H12AffineFastState.Bounded env34935 := by
  intro p hp
  have h : env34935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34934_34935 : H12AffineEnvironment.transform 5 17 env34934 = env34935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34934 == env34935) = true)

theorem identity34935 : scanCanonicalize (H12AffineFastState.compose env34935 (packedSelected [6,7,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 3328) := by decide +kernel

theorem selectedBound34935 : packedSelected [6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34936 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,0,263,3328,2048,1025,1,4112,260,17,295,269,16,4113,5173,4389,4404,1057,261,257,33,5157,804]

theorem envBound34936 : H12AffineFastState.Bounded env34936 := by
  intro p hp
  have h : env34936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34935_34936 : H12AffineEnvironment.transform 16 3328 env34935 = env34936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3328 env34935 == env34936) = true)

theorem identity34936 : scanCanonicalize (H12AffineFastState.compose env34936 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound34936 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env34937 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2357,269,3345,0,263,3328,2048,1025,1,2341,260,17,295,269,16,2340,3328,2064,2049,1057,261,257,33,3344,804]

theorem envBound34937 : H12AffineFastState.Bounded env34937 := by
  intro p hp
  have h : env34937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34936_34937 : H12AffineEnvironment.transform 11 2357 env34936 = env34937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env34936 == env34937) = true)

theorem identity34937 : scanCanonicalize (H12AffineFastState.compose env34937 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34937 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34938 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,41,3125,0,35,3108,2048,1025,1,2049,32,17,3,41,16,2048,3108,2064,2049,1057,33,37,33,3124,512]

theorem envBound34938 : H12AffineFastState.Bounded env34938 := by
  intro p hp
  have h : env34938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34937_34938 : H12AffineEnvironment.transform 7 36 env34937 = env34938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34937 == env34938) = true)

theorem identity34938 : scanCanonicalize (H12AffineFastState.compose env34938 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound34938 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34939 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1029,1044,41,48,0,35,33,1029,1025,1,1028,32,17,3,41,16,1029,33,1045,1028,1057,33,37,33,49,512]

theorem envBound34939 : H12AffineFastState.Bounded env34939 := by
  intro p hp
  have h : env34939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34938_34939 : H12AffineEnvironment.transform 10 1029 env34938 = env34939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env34938 == env34939) = true)

theorem identity34939 : scanCanonicalize (H12AffineFastState.compose env34939 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34939 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34940 : List Nat := [2,4,8,16,11,17,8,15,512,1024,1029,1044,2,27,0,8,10,1029,1025,1,1028,11,17,3,2,16,1029,10,1045,1028,1034,10,14,10,26,512]

theorem envBound34940 : H12AffineFastState.Bounded env34940 := by
  intro p hp
  have h : env34940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34939_34940 : H12AffineEnvironment.transform 4 11 env34939 = env34940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34939 == env34940) = true)

theorem identity34940 : scanCanonicalize (H12AffineFastState.compose env34940 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34940 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34941 : List Nat := [2,4,8,1,11,0,8,15,512,1024,1029,1029,2,10,0,8,10,1029,1025,1,1028,11,0,3,2,1,1029,10,1028,1028,1034,10,14,10,11,512]

theorem envBound34941 : H12AffineFastState.Bounded env34941 := by
  intro p hp
  have h : env34941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34940_34941 : H12AffineEnvironment.transform 3 1 env34940 = env34941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34940 == env34941) = true)

theorem identity34941 : scanCanonicalize (H12AffineFastState.compose env34941 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound34941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34942 : List Nat := [2,4,8,1,11,0,8,15,512,10,15,15,2,10,0,8,10,15,11,1,14,11,0,3,2,1,15,10,14,14,0,10,14,10,11,512]

theorem envBound34942 : H12AffineFastState.Bounded env34942 := by
  intro p hp
  have h : env34942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34941_34942 : H12AffineEnvironment.transform 9 10 env34941 = env34942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env34941 == env34942) = true)

theorem identity34942 : scanCanonicalize (H12AffineFastState.compose env34942 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34942 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34943 : List Nat := [2,4,2,1,1,0,2,5,512,0,5,5,2,0,0,2,0,5,1,1,4,1,0,3,2,1,5,0,4,4,0,0,4,0,1,512]

theorem envBound34943 : H12AffineFastState.Bounded env34943 := by
  intro p hp
  have h : env34943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34942_34943 : H12AffineEnvironment.transform 2 2 env34942 = env34943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34942 == env34943) = true)

def env34944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,4161,21792,17,21763,8193,65,171280,115014,17665,236850,119042,95530,257,98678,90202,63069]

theorem envBound34944 : H12AffineFastState.Bounded env34944 := by
  intro p hp
  have h : env34944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34929_34944 : H12AffineEnvironment.transform 6 9 env34929 = env34944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34929 == env34944) = true)

theorem identity34944 : scanCanonicalize (H12AffineFastState.compose env34944 (packedSelected [1,2,3,10,12,14,15,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound34944 : packedSelected [1,2,3,10,12,14,15,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env34945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,78959,89378,1025,32769,4161,21792,17,21763,8193,65,108927,115014,17665,43357,119042,95530,257,98678,90202,63069]

theorem envBound34945 : H12AffineFastState.Bounded env34945 := by
  intro p hp
  have h : env34945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34944_34945 : H12AffineEnvironment.transform 16 78959 env34944 = env34945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env34944 == env34945) = true)

theorem identity34945 : scanCanonicalize (H12AffineFastState.compose env34945 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34945 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,78959,89378,1025,29789,4161,21792,17,21763,8193,65,89379,79130,17665,23809,75102,95530,257,95530,90202,513]

theorem envBound34946 : H12AffineFastState.Bounded env34946 := by
  intro p hp
  have h : env34946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34945_34946 : H12AffineEnvironment.transform 14 29788 env34945 = env34946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34945 == env34946) = true)

theorem identity34946 : scanCanonicalize (H12AffineFastState.compose env34946 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound34946 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env34947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,24633,2420,1025,29789,4161,21792,17,21763,8193,65,2421,24908,17665,23809,28936,8572,257,8572,13324,513]

theorem envBound34947 : H12AffineFastState.Bounded env34947 := by
  intro p hp
  have h : env34947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34946_34947 : H12AffineEnvironment.transform 15 21590 env34946 = env34947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env34946 == env34947) = true)

theorem identity34947 : scanCanonicalize (H12AffineFastState.compose env34947 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34947 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,5220,2420,1025,0,4161,8573,17,8542,8193,65,2421,5393,12636,10588,1365,8572,257,8572,13324,513]

theorem envBound34948 : H12AffineFastState.Bounded env34948 := by
  intro p hp
  have h : env34948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34947_34948 : H12AffineEnvironment.transform 13 13405 env34947 = env34948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34947 == env34948) = true)

theorem identity34948 : scanCanonicalize (H12AffineFastState.compose env34948 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34948 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34949 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,1,8203,5220,2049,1025,0,4161,8200,17,8235,8193,65,2048,5220,12329,10281,1056,8201,116,8201,13324,513]

theorem envBound34949 : H12AffineFastState.Bounded env34949 := by
  intro p hp
  have h : env34949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34948_34949 : H12AffineEnvironment.transform 7 117 env34948 = env34949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34948 == env34949) = true)

theorem identity34949 : scanCanonicalize (H12AffineFastState.compose env34949 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34949 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env34950 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,4096,8192,13405,1,8203,5220,0,1025,0,4161,8200,17,8235,8193,65,1,5220,12329,8232,1056,8201,116,8201,13324,513]

theorem envBound34950 : H12AffineFastState.Bounded env34950 := by
  intro p hp
  have h : env34950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34949_34950 : H12AffineEnvironment.transform 10 1 env34949 = env34950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34949 == env34950) = true)

def env34951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound34951 : H12AffineFastState.Bounded env34951 := by
  intro p hp
  have h : env34951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31847_34951 : H12AffineEnvironment.transform 31 145662401 env31847 = env34951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env31847 == env34951) = true)

def env34952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound34952 : H12AffineFastState.Bounded env34952 := by
  intro p hp
  have h : env34952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34951_34952 : H12AffineEnvironment.transform 29 155254784 env34951 = env34952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env34951 == env34952) = true)

def env34953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound34953 : H12AffineFastState.Bounded env34953 := by
  intro p hp
  have h : env34953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34952_34953 : H12AffineEnvironment.transform 25 64 env34952 = env34953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env34952 == env34953) = true)

def env34954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound34954 : H12AffineFastState.Bounded env34954 := by
  intro p hp
  have h : env34954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34953_34954 : H12AffineEnvironment.transform 26 30393344 env34953 = env34954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env34953 == env34954) = true)

def env34955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound34955 : H12AffineFastState.Bounded env34955 := by
  intro p hp
  have h : env34955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34954_34955 : H12AffineEnvironment.transform 18 1024 env34954 = env34955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env34954 == env34955) = true)

theorem identity34955 : scanCanonicalize (H12AffineFastState.compose env34955 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91587) := by decide +kernel

theorem selectedBound34955 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,16777216,8328,64,29868032,16834895,8466579,8830976,25265169,20971522,256,25207150,25182410,25207751]

theorem envBound34956 : H12AffineFastState.Bounded env34956 := by
  intro p hp
  have h : env34956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34955_34956 : H12AffineEnvironment.transform 20 91587 env34955 = env34956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91587 env34955 == env34956) = true)

def env34957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119892,8328,64,12981332,79131,8466579,8830976,8409157,4314198,256,8484154,8492190,8484755]

theorem envBound34957 : H12AffineFastState.Bounded env34957 := by
  intro p hp
  have h : env34957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34956_34957 : H12AffineEnvironment.transform 23 119892 env34956 = env34957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119892 env34956 == env34957) = true)

def env34958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981332,79131,8466579,8819968,8389957,4292950,256,8462394,8492190,8462995]

theorem envBound34958 : H12AffineFastState.Bounded env34958 := by
  intro p hp
  have h : env34958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34957_34958 : H12AffineEnvironment.transform 13 5376 env34957 = env34958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34957 == env34958) = true)

def env34959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787060,79131,8466579,8819968,8389957,98678,256,8462394,8492190,8462995]

theorem envBound34959 : H12AffineFastState.Bounded env34959 := by
  intro p hp
  have h : env34959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34958_34959 : H12AffineEnvironment.transform 21 32 env34958 = env34959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env34958 == env34959) = true)

theorem identity34959 : scanCanonicalize (H12AffineFastState.compose env34959 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,78019,32,8388608,73736,8328,64,8787060,79131,8466579,8795228,8389957,73770,256,8462394,8467906,8462995]

theorem envBound34960 : H12AffineFastState.Bounded env34960 := by
  intro p hp
  have h : env34960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34959_34960 : H12AffineEnvironment.transform 14 8540 env34959 = env34960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34959 == env34960) = true)

def env34961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,78019,32,8388608,73736,8328,64,8535252,79131,8466579,8527100,8389957,73770,256,8462394,8467906,8462995]

theorem envBound34961 : H12AffineFastState.Bounded env34961 := by
  intro p hp
  have h : env34961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34960_34961 : H12AffineEnvironment.transform 17 10400 env34960 = env34961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env34960 == env34961) = true)

theorem identity34961 : scanCanonicalize (H12AffineFastState.compose env34961 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound34961 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,78019,32,16,73736,8328,64,146628,79131,77955,138476,1365,73770,256,73770,79314,74371]

theorem envBound34962 : H12AffineFastState.Bounded env34962 := by
  intro p hp
  have h : env34962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34961_34962 : H12AffineEnvironment.transform 22 16 env34961 = env34962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env34961 == env34962) = true)

theorem identity34962 : scanCanonicalize (H12AffineFastState.compose env34962 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound34962 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,70862,10400,1024,8541,78019,32,16,73736,8328,64,75786,79131,77955,67618,1365,73770,256,73770,79314,74371]

theorem envBound34963 : H12AffineFastState.Bounded env34963 := by
  intro p hp
  have h : env34963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34962_34963 : H12AffineEnvironment.transform 16 70862 env34962 = env34963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env34962 == env34963) = true)

theorem identity34963 : scanCanonicalize (H12AffineFastState.compose env34963 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound34963 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env34964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,13388,10400,1024,8541,4161,32,16,138,8328,64,2184,5529,4097,10400,1365,168,256,168,5456,513]

theorem envBound34964 : H12AffineFastState.Bounded env34964 := by
  intro p hp
  have h : env34964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34963_34964 : H12AffineEnvironment.transform 15 8322 env34963 = env34964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env34963 == env34964) = true)

theorem identity34964 : scanCanonicalize (H12AffineFastState.compose env34964 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound34964 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,5376,1296,1230,4096,3308,1024,1297,4161,32,16,138,1220,64,2184,5529,4097,3308,1365,168,256,168,5456,513]

theorem envBound34965 : H12AffineFastState.Bounded env34965 := by
  intro p hp
  have h : env34965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34964_34965 : H12AffineEnvironment.transform 12 1100 env34964 = env34965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env34964 == env34965) = true)

theorem identity34965 : scanCanonicalize (H12AffineFastState.compose env34965 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound34965 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env34966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3464,1100,2184,1296,1230,3464,3308,1024,1297,3529,32,16,138,1220,64,2184,2065,3465,3308,1365,168,256,168,2264,513]

theorem envBound34966 : H12AffineFastState.Bounded env34966 := by
  intro p hp
  have h : env34966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34965_34966 : H12AffineEnvironment.transform 11 3464 env34965 = env34966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env34965 == env34966) = true)

theorem identity34966 : scanCanonicalize (H12AffineFastState.compose env34966 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34966 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env34967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1417,1100,137,1296,1230,1417,1261,1024,1297,1480,32,16,138,1220,64,137,16,1416,1261,1365,168,256,168,217,513]

theorem envBound34967 : H12AffineFastState.Bounded env34967 := by
  intro p hp
  have h : env34967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34966_34967 : H12AffineEnvironment.transform 10 1 env34966 = env34967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34966 == env34967) = true)

theorem identity34967 : scanCanonicalize (H12AffineFastState.compose env34967 (packedSelected [1,4,8,9,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34967 : packedSelected [1,4,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env34968 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1,1276,1100,137,1125,1230,1276,1261,1024,1124,1213,32,16,138,1220,64,137,16,1277,1261,1056,168,117,168,217,513]

theorem envBound34968 : H12AffineFastState.Bounded env34968 := by
  intro p hp
  have h : env34968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34967_34968 : H12AffineEnvironment.transform 7 117 env34967 = env34968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34967 == env34968) = true)

theorem identity34968 : scanCanonicalize (H12AffineFastState.compose env34968 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34968 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34969 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1,1061,1100,80,1125,1047,1061,1076,1024,1124,1124,32,16,83,1053,64,80,16,1060,1076,1056,113,117,113,0,513]

theorem envBound34969 : H12AffineFastState.Bounded env34969 := by
  intro p hp
  have h : env34969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34968_34969 : H12AffineEnvironment.transform 6 89 env34968 = env34969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34968 == env34969) = true)

theorem identity34969 : scanCanonicalize (H12AffineFastState.compose env34969 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound34969 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34970 : List Nat := [2,4,8,16,32,64,89,117,512,100,1,65,40,80,1,115,65,80,100,0,0,32,16,83,121,64,80,16,64,80,68,113,117,113,0,513]

theorem envBound34970 : H12AffineFastState.Bounded env34970 := by
  intro p hp
  have h : env34970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34969_34970 : H12AffineEnvironment.transform 9 100 env34969 = env34970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env34969 == env34970) = true)

theorem identity34970 : scanCanonicalize (H12AffineFastState.compose env34970 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34970 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34971 : List Nat := [2,4,8,1,32,64,72,100,512,100,1,65,40,65,1,98,65,65,100,0,0,32,1,66,104,64,65,1,64,65,68,96,100,96,0,513]

theorem envBound34971 : H12AffineFastState.Bounded env34971 := by
  intro p hp
  have h : env34971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34970_34971 : H12AffineEnvironment.transform 3 1 env34970 = env34971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34970 == env34971) = true)

theorem identity34971 : scanCanonicalize (H12AffineFastState.compose env34971 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34971 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34972 : List Nat := [2,4,8,1,1,64,72,69,512,69,1,65,9,65,1,67,65,65,69,0,0,1,1,66,73,64,65,1,64,65,68,65,69,65,0,513]

theorem envBound34972 : H12AffineFastState.Bounded env34972 := by
  intro p hp
  have h : env34972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34971_34972 : H12AffineEnvironment.transform 4 1 env34971 = env34972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34971 == env34972) = true)

theorem identity34972 : scanCanonicalize (H12AffineFastState.compose env34972 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound34972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34973 : List Nat := [2,4,8,1,1,0,8,5,512,5,1,1,9,1,1,3,1,1,5,0,0,1,1,2,9,0,1,1,0,1,4,1,5,1,0,513]

theorem envBound34973 : H12AffineFastState.Bounded env34973 := by
  intro p hp
  have h : env34973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34972_34973 : H12AffineEnvironment.transform 5 0 env34972 = env34973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34972 == env34973) = true)

theorem identity34973 : scanCanonicalize (H12AffineFastState.compose env34973 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34974 : List Nat := [2,1,8,1,1,0,8,0,512,0,1,1,9,1,1,3,1,1,0,0,0,1,1,2,9,0,1,1,0,1,1,1,0,1,0,513]

theorem envBound34974 : H12AffineFastState.Bounded env34974 := by
  intro p hp
  have h : env34974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34973_34974 : H12AffineEnvironment.transform 1 1 env34973 = env34974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34973 == env34974) = true)

theorem identity34974 : scanCanonicalize (H12AffineFastState.compose env34974 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound34974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34975 : List Nat := [2,1,1,1,1,0,1,0,512,0,1,1,0,1,1,3,1,1,0,0,0,1,1,2,0,0,1,1,0,1,1,1,0,1,0,513]

theorem envBound34975 : H12AffineFastState.Bounded env34975 := by
  intro p hp
  have h : env34975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34974_34975 : H12AffineEnvironment.transform 2 1 env34974 = env34975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env34974 == env34975) = true)

theorem identity34975 : scanCanonicalize (H12AffineFastState.compose env34975 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34975 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34976 : List Nat := [1,1,1,1,1,0,1,0,512,0,1,1,0,1,1,0,1,1,0,0,0,1,1,1,0,0,1,1,0,1,1,1,0,1,0,513]

theorem envBound34976 : H12AffineFastState.Bounded env34976 := by
  intro p hp
  have h : env34976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34975_34976 : H12AffineEnvironment.transform 0 1 env34975 = env34976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34975 == env34976) = true)

def env34977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,32,8388608,73736,8328,64,8535253,79131,8466579,8527101,8389957,73770,256,8462394,8467906,8462995]

theorem envBound34977 : H12AffineFastState.Bounded env34977 := by
  intro p hp
  have h : env34977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34960_34977 : H12AffineEnvironment.transform 17 10401 env34960 = env34977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env34960 == env34977) = true)

def env34978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,32,136448,73736,8328,64,10709,79131,206227,2557,135237,73770,256,210234,204994,210835]

theorem envBound34978 : H12AffineFastState.Bounded env34978 := by
  intro p hp
  have h : env34978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34977_34978 : H12AffineEnvironment.transform 22 136448 env34977 = env34978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env34977 == env34978) = true)

theorem identity34978 : scanCanonicalize (H12AffineFastState.compose env34978 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound34978 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env34979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79250,10401,1024,8541,78019,32,73874,73736,8328,64,10709,79131,4097,2557,75223,73770,256,168,5456,513]

theorem envBound34979 : H12AffineFastState.Bounded env34979 := by
  intro p hp
  have h : env34979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34978_34979 : H12AffineEnvironment.transform 16 79250 env34978 = env34979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env34978 == env34979) = true)

theorem identity34979 : scanCanonicalize (H12AffineFastState.compose env34979 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34979 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10280,1024,8541,77898,32,73755,73736,8193,64,10588,79131,4097,2420,75102,73770,256,33,5456,513]

theorem envBound34980 : H12AffineFastState.Bounded env34980 := by
  intro p hp
  have h : env34980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34979_34980 : H12AffineEnvironment.transform 6 9 env34979 = env34980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34979 == env34980) = true)

theorem identity34980 : scanCanonicalize (H12AffineFastState.compose env34980 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound34980 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,343,13388,10280,1024,8541,12573,32,8524,8543,8193,64,10588,13388,4097,2420,9225,8573,256,33,5456,513]

theorem envBound34981 : H12AffineFastState.Bounded env34981 := by
  intro p hp
  have h : env34981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34980_34981 : H12AffineEnvironment.transform 15 343 env34980 = env34981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env34980 == env34981) = true)

theorem identity34981 : scanCanonicalize (H12AffineFastState.compose env34981 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34981 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env34982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5392,2420,1024,1,4161,32,16,3,349,64,2048,5392,4097,2420,1365,33,256,33,5456,513]

theorem envBound34982 : H12AffineFastState.Bounded env34982 := by
  intro p hp
  have h : env34982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34981_34982 : H12AffineEnvironment.transform 12 348 env34981 = env34982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34981 == env34982) = true)

theorem identity34982 : scanCanonicalize (H12AffineFastState.compose env34982 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound34982 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1647,4096,348,5376,0,343,5392,1819,1024,1,4161,32,16,3,349,64,1647,5392,4097,1819,1365,33,256,33,5456,513]

theorem envBound34983 : H12AffineFastState.Bounded env34983 := by
  intro p hp
  have h : env34983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34982_34983 : H12AffineEnvironment.transform 10 1647 env34982 = env34983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env34982 == env34983) = true)

theorem identity34983 : scanCanonicalize (H12AffineFastState.compose env34983 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34983 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34984 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1647,4096,41,5237,0,34,5221,1646,1024,1,4161,32,16,3,40,64,1647,5221,4097,1646,1056,33,117,33,5157,513]

theorem envBound34984 : H12AffineFastState.Bounded env34984 := by
  intro p hp
  have h : env34984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34983_34984 : H12AffineEnvironment.transform 7 117 env34983 = env34984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34983 == env34984) = true)

theorem identity34984 : scanCanonicalize (H12AffineFastState.compose env34984 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound34984 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34985 : List Nat := [2,4,8,16,32,64,9,117,512,574,81,4096,41,4683,0,34,4699,80,574,1,4161,32,16,3,40,64,81,4699,4097,80,542,33,117,33,4635,513]

theorem envBound34985 : H12AffineFastState.Bounded env34985 := by
  intro p hp
  have h : env34985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34984_34985 : H12AffineEnvironment.transform 9 574 env34984 = env34985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env34984 == env34985) = true)

theorem identity34985 : scanCanonicalize (H12AffineFastState.compose env34985 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34985 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34986 : List Nat := [2,4,8,16,32,64,9,117,42,20,81,4096,41,4193,0,34,4209,80,20,1,4161,32,16,3,40,64,81,4209,4097,80,52,33,117,33,4145,43]

theorem envBound34986 : H12AffineFastState.Bounded env34986 := by
  intro p hp
  have h : env34986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34985_34986 : H12AffineEnvironment.transform 8 42 env34985 = env34986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34985 == env34986) = true)

theorem identity34986 : scanCanonicalize (H12AffineFastState.compose env34986 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound34986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34987 : List Nat := [2,4,8,8,32,64,9,109,42,12,73,4096,41,4193,0,34,4201,72,12,1,4161,32,8,3,40,64,73,4201,4097,72,44,33,109,33,4137,43]

theorem envBound34987 : H12AffineFastState.Bounded env34987 := by
  intro p hp
  have h : env34987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34986_34987 : H12AffineEnvironment.transform 3 8 env34986 = env34987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env34986 == env34987) = true)

def env34988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,32,136449,73736,8328,64,10708,79131,206226,2556,135236,73770,256,210235,204995,210834]

theorem envBound34988 : H12AffineFastState.Bounded env34988 := by
  intro p hp
  have h : env34988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34977_34988 : H12AffineEnvironment.transform 22 136449 env34977 = env34988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env34977 == env34988) = true)

theorem identity34988 : scanCanonicalize (H12AffineFastState.compose env34988 (packedSelected [2,3,4,5,6,7,10,12,14,15,22,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound34988 : packedSelected [2,3,4,5,6,7,10,12,14,15,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env34989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,65536,131072,2421,1024,137,69911,32,136449,66012,348,64,2048,70863,197702,2556,135236,66046,256,201967,196887,202310]

theorem envBound34989 : H12AffineFastState.Bounded env34989 := by
  intro p hp
  have h : env34989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34988_34989 : H12AffineEnvironment.transform 12 468 env34988 = env34989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env34988 == env34989) = true)

theorem identity34989 : scanCanonicalize (H12AffineFastState.compose env34989 (packedSelected [2,5,6,9,11,12,14,15,19,22,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34989 : packedSelected [2,5,6,9,11,12,14,15,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env34990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,65536,131072,2421,1024,1,69911,32,136449,65876,348,64,2048,70727,197702,2420,135236,65910,256,201831,196887,202310]

theorem envBound34990 : H12AffineFastState.Bounded env34990 := by
  intro p hp
  have h : env34990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34989_34990 : H12AffineEnvironment.transform 6 8 env34989 = env34990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34989 == env34990) = true)

theorem identity34990 : scanCanonicalize (H12AffineFastState.compose env34990 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 69667) := by decide +kernel

theorem selectedBound34990 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env34991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,65536,69667,2421,1024,1,69911,32,66850,65876,348,64,2048,70727,5221,2420,65639,65910,256,1092,4404,1637]

theorem envBound34991 : H12AffineFastState.Bounded env34991 := by
  intro p hp
  have h : env34991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34990_34991 : H12AffineEnvironment.transform 16 69667 env34990 = env34991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69667 env34990 == env34991) = true)

theorem identity34991 : scanCanonicalize (H12AffineFastState.compose env34991 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34991 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,34,4097,2421,1024,1,4405,32,1280,374,348,64,2048,5221,5221,2420,69,340,256,1092,4404,1637]

theorem envBound34992 : H12AffineFastState.Bounded env34992 := by
  intro p hp
  have h : env34992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34991_34992 : H12AffineEnvironment.transform 15 34 env34991 = env34992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34991 == env34992) = true)

def env34993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787061,79131,8466579,8819968,8389957,98679,256,8462394,8492190,8462995]

theorem envBound34993 : H12AffineFastState.Bounded env34993 := by
  intro p hp
  have h : env34993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34958_34993 : H12AffineEnvironment.transform 21 33 env34958 = env34993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env34958 == env34993) = true)

theorem identity34993 : scanCanonicalize (H12AffineFastState.compose env34993 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound34993 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,41292,98644,8328,64,439609,79131,102879,406604,41993,98679,256,98678,79314,99295]

theorem envBound34994 : H12AffineFastState.Bounded env34994 := by
  intro p hp
  have h : env34994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34993_34994 : H12AffineEnvironment.transform 22 41292 env34993 = env34994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env34993 == env34994) = true)

theorem identity34994 : scanCanonicalize (H12AffineFastState.compose env34994 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound34994 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env34995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,78019,33,41292,98644,8328,64,203846,79131,102879,236851,41993,98679,256,98678,79314,99295]

theorem envBound34995 : H12AffineFastState.Bounded env34995 := by
  intro p hp
  have h : env34995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34994_34995 : H12AffineEnvironment.transform 17 108927 env34994 = env34995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env34994 == env34995) = true)

def env34996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67619,1024,8541,78019,33,16,73736,8328,64,203846,79131,77955,212079,1365,73771,256,73770,79314,74371]

theorem envBound34996 : H12AffineFastState.Bounded env34996 := by
  intro p hp
  have h : env34996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34995_34996 : H12AffineEnvironment.transform 14 8540 env34995 = env34996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34995 == env34996) = true)

theorem identity34996 : scanCanonicalize (H12AffineFastState.compose env34996 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound34996 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env34997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,13460,67619,1024,8541,78019,33,16,73736,8328,64,75986,79131,77955,67835,1365,73771,256,73770,79314,74371]

theorem envBound34997 : H12AffineFastState.Bounded env34997 := by
  intro p hp
  have h : env34997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34996_34997 : H12AffineEnvironment.transform 16 13460 env34996 = env34997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env34996 == env34997) = true)

theorem identity34997 : scanCanonicalize (H12AffineFastState.compose env34997 (packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound34997 : packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env34998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,216,65536,5392,67619,1024,217,69959,33,16,65932,268,64,67926,70815,69895,67835,1365,65967,256,65966,70742,66311]

theorem envBound34998 : H12AffineFastState.Bounded env34998 := by
  intro p hp
  have h : env34998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34997_34998 : H12AffineEnvironment.transform 12 388 env34997 = env34998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env34997 == env34998) = true)

theorem identity34998 : scanCanonicalize (H12AffineFastState.compose env34998 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34998 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env34999 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5376,1,65536,5392,67619,1024,0,69959,33,16,65877,268,64,67926,70726,69895,67618,1365,65910,256,65911,70742,66311]

theorem envBound34999 : H12AffineFastState.Bounded env34999 := by
  intro p hp
  have h : env34999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34998_34999 : H12AffineEnvironment.transform 6 89 env34998 = env34999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34998 == env34999) = true)

theorem identity34999 : scanCanonicalize (H12AffineFastState.compose env34999 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound34999 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env35000 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3328,349,2048,1,65536,2064,67619,1024,0,68679,33,16,65877,268,64,67926,67910,68615,67618,1365,65910,256,65911,67926,66311]

theorem envBound35000 : H12AffineFastState.Bounded env35000 := by
  intro p hp
  have h : env35000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34999_35000 : H12AffineEnvironment.transform 11 3328 env34999 = env35000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env34999 == env35000) = true)

theorem identity35000 : scanCanonicalize (H12AffineFastState.compose env35000 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound35000 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env35001 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3328,349,2048,1,343,2064,2420,1024,0,3344,33,16,2,268,64,2049,2065,3408,2421,1365,33,256,32,2049,592]

theorem envBound35001 : H12AffineFastState.Bounded env35001 := by
  intro p hp
  have h : env35001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35000_35001 : H12AffineEnvironment.transform 15 343 env35000 = env35001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env35000 == env35001) = true)

theorem identity35001 : scanCanonicalize (H12AffineFastState.compose env35001 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35001 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35002 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,2404,349,2048,1,343,2064,2420,100,0,2420,33,16,2,268,64,2049,2065,2356,2421,305,33,256,32,2049,592]

theorem envBound35002 : H12AffineFastState.Bounded env35002 := by
  intro p hp
  have h : env35002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35001_35002 : H12AffineEnvironment.transform 9 100 env35001 = env35002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35001 == env35002) = true)

theorem identity35002 : scanCanonicalize (H12AffineFastState.compose env35002 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35002 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env35003 : List Nat := [2,4,8,16,32,64,89,117,512,100,2048,2065,40,2048,1,34,2064,2049,100,0,2049,33,16,2,121,64,2049,2065,2113,2048,68,33,117,32,2049,592]

theorem envBound35003 : H12AffineFastState.Bounded env35003 := by
  intro p hp
  have h : env35003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35002_35003 : H12AffineEnvironment.transform 7 117 env35002 = env35003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35002 == env35003) = true)

theorem identity35003 : scanCanonicalize (H12AffineFastState.compose env35003 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35003 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35004 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2065,40,2048,1,34,2064,2049,53,0,2049,33,16,2,40,17,2049,2065,2064,2048,21,33,36,32,2049,513]

theorem envBound35004 : H12AffineFastState.Bounded env35004 := by
  intro p hp
  have h : env35004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35003_35004 : H12AffineEnvironment.transform 5 17 env35003 = env35004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35003 == env35004) = true)

theorem identity35004 : scanCanonicalize (H12AffineFastState.compose env35004 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound35004 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35005 : List Nat := [2,4,8,16,27,17,8,31,512,14,2048,2065,19,2048,1,25,2064,2049,14,0,2049,26,16,2,19,17,2049,2065,2064,2048,21,26,31,27,2049,513]

theorem envBound35005 : H12AffineFastState.Bounded env35005 := by
  intro p hp
  have h : env35005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35004_35005 : H12AffineEnvironment.transform 4 27 env35004 = env35005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env35004 == env35005) = true)

def env35006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67618,1024,8540,78019,33,17,73737,8328,64,203846,79131,77954,212078,1364,73770,256,73771,79314,74370]

theorem envBound35006 : H12AffineFastState.Bounded env35006 := by
  intro p hp
  have h : env35006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34995_35006 : H12AffineEnvironment.transform 14 8541 env34995 = env35006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34995 == env35006) = true)

theorem identity35006 : scanCanonicalize (H12AffineFastState.compose env35006 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound35006 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env35007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,398,131072,2476,1024,8540,12621,33,17,8583,8328,64,138696,13461,12556,146912,1364,8612,256,8613,13404,8972]

theorem envBound35007 : H12AffineFastState.Bounded env35007 := by
  intro p hp
  have h : env35007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35006_35007 : H12AffineEnvironment.transform 15 398 env35006 = env35007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env35006 == env35007) = true)

theorem identity35007 : scanCanonicalize (H12AffineFastState.compose env35007 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound35007 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,217,398,131072,2476,1024,216,4297,33,17,3,268,64,138696,5393,4232,138340,1364,32,256,33,5592,648]

theorem envBound35008 : H12AffineFastState.Bounded env35008 := by
  intro p hp
  have h : env35008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35007_35008 : H12AffineEnvironment.transform 12 388 env35007 = env35008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env35007 == env35008) = true)

theorem identity35008 : scanCanonicalize (H12AffineFastState.compose env35008 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35008 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,262,131072,2340,1024,80,4161,33,17,3,268,64,138560,5393,4096,138340,1364,32,256,33,5456,512]

theorem envBound35009 : H12AffineFastState.Bounded env35009 := by
  intro p hp
  have h : env35009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35008_35009 : H12AffineEnvironment.transform 6 8 env35008 = env35009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35008 == env35009) = true)

theorem identity35009 : scanCanonicalize (H12AffineFastState.compose env35009 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5472) := by decide +kernel

theorem selectedBound35009 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,262,5472,2340,1024,80,4161,33,17,3,268,64,2080,5393,4096,2308,1364,32,256,33,5456,512]

theorem envBound35010 : H12AffineFastState.Bounded env35010 := by
  intro p hp
  have h : env35010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35009_35010 : H12AffineEnvironment.transform 16 5472 env35009 = env35010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5472 env35009 == env35010) = true)

theorem identity35010 : scanCanonicalize (H12AffineFastState.compose env35010 (packedSelected [0,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 1888) := by decide +kernel

theorem selectedBound35010 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env35011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1888,268,608,81,262,512,2340,1024,80,1825,33,17,3,268,64,2080,625,1888,2308,1364,32,256,33,560,512]

theorem envBound35011 : H12AffineFastState.Bounded env35011 := by
  intro p hp
  have h : env35011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35010_35011 : H12AffineEnvironment.transform 11 1888 env35010 = env35011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1888 env35010 == env35011) = true)

theorem identity35011 : scanCanonicalize (H12AffineFastState.compose env35011 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35011 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env35012 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,1856,268,576,81,262,512,2308,1024,80,1793,1,17,3,268,64,2048,593,1856,2308,1364,0,256,1,528,512]

theorem envBound35012 : H12AffineFastState.Bounded env35012 := by
  intro p hp
  have h : env35012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35011_35012 : H12AffineEnvironment.transform 4 0 env35011 = env35012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35011 == env35012) = true)

theorem identity35012 : scanCanonicalize (H12AffineFastState.compose env35012 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35012 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35013 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,1808,268,528,1,262,512,2308,1024,0,1793,1,17,3,268,16,2048,513,1808,2308,1284,0,256,1,528,512]

theorem envBound35013 : H12AffineFastState.Bounded env35013 := by
  intro p hp
  have h : env35013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35012_35013 : H12AffineEnvironment.transform 5 16 env35012 = env35013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35012 == env35013) = true)

theorem identity35013 : scanCanonicalize (H12AffineFastState.compose env35013 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35014 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,513,268,528,1,262,512,2308,273,0,528,1,17,3,268,16,2048,513,513,2308,21,0,256,1,528,512]

theorem envBound35014 : H12AffineFastState.Bounded env35014 := by
  intro p hp
  have h : env35014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35013_35014 : H12AffineEnvironment.transform 9 273 env35013 = env35014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35013 == env35014) = true)

theorem identity35014 : scanCanonicalize (H12AffineFastState.compose env35014 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound35014 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35015 : List Nat := [2,4,8,16,0,16,8,256,512,273,523,513,268,528,1,262,512,783,273,0,528,1,17,3,268,16,523,513,513,783,21,0,256,1,528,512]

theorem envBound35015 : H12AffineFastState.Bounded env35015 := by
  intro p hp
  have h : env35015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35014_35015 : H12AffineEnvironment.transform 10 523 env35014 = env35015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env35014 == env35015) = true)

theorem identity35015 : scanCanonicalize (H12AffineFastState.compose env35015 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound35015 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35016 : List Nat := [2,4,8,16,0,16,8,256,26,273,17,27,268,10,1,262,26,277,273,0,10,1,17,3,268,16,17,27,27,277,21,0,256,1,10,26]

theorem envBound35016 : H12AffineFastState.Bounded env35016 := by
  intro p hp
  have h : env35016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35015_35016 : H12AffineEnvironment.transform 8 26 env35015 = env35016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env35015 == env35016) = true)

theorem identity35016 : scanCanonicalize (H12AffineFastState.compose env35016 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35016 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35017 : List Nat := [2,4,8,16,0,16,8,4,26,21,17,27,8,10,1,2,26,17,21,0,10,1,17,3,8,16,17,27,27,17,21,0,4,1,10,26]

theorem envBound35017 : H12AffineFastState.Bounded env35017 := by
  intro p hp
  have h : env35017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35016_35017 : H12AffineEnvironment.transform 7 4 env35016 = env35017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35016 == env35017) = true)

theorem identity35017 : scanCanonicalize (H12AffineFastState.compose env35017 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound35017 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35018 : List Nat := [2,4,8,5,0,5,8,4,15,0,4,14,8,10,1,2,15,4,0,0,10,1,4,3,8,5,4,14,14,4,0,0,4,1,10,15]

theorem envBound35018 : H12AffineFastState.Bounded env35018 := by
  intro p hp
  have h : env35018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35017_35018 : H12AffineEnvironment.transform 3 5 env35017 = env35018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env35017 == env35018) = true)

theorem identity35018 : scanCanonicalize (H12AffineFastState.compose env35018 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35019 : List Nat := [2,2,8,3,0,3,8,2,9,0,2,8,8,10,1,2,9,2,0,0,10,1,2,3,8,3,2,8,8,2,0,0,2,1,10,9]

theorem envBound35019 : H12AffineFastState.Bounded env35019 := by
  intro p hp
  have h : env35019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35018_35019 : H12AffineEnvironment.transform 1 2 env35018 = env35019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35018 == env35019) = true)

def env35020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981332,79131,8466579,8819969,8389956,4292951,256,8462395,8492190,8462994]

theorem envBound35020 : H12AffineFastState.Bounded env35020 := by
  intro p hp
  have h : env35020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34957_35020 : H12AffineEnvironment.transform 13 5377 env34957 = env35020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34957 == env35020) = true)

def env35021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787060,79131,8466579,8819969,8389956,98679,256,8462395,8492190,8462994]

theorem envBound35021 : H12AffineFastState.Bounded env35021 := by
  intro p hp
  have h : env35021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35020_35021 : H12AffineEnvironment.transform 21 32 env35020 = env35021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35020 == env35021) = true)

def env35022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,8388608,98645,8192,64,8787060,79131,8466459,8819969,8389956,98679,256,8462395,8492054,8462874]

theorem envBound35022 : H12AffineFastState.Bounded env35022 := by
  intro p hp
  have h : env35022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35021_35022 : H12AffineEnvironment.transform 6 8 env35021 = env35022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35021 == env35022) = true)

def env35023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,16,98645,8192,64,398436,79131,77835,431377,1364,98679,256,73771,103430,74250]

theorem envBound35023 : H12AffineFastState.Bounded env35023 := by
  intro p hp
  have h : env35023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35022_35023 : H12AffineEnvironment.transform 22 16 env35022 = env35023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env35022 == env35023) = true)

theorem identity35023 : scanCanonicalize (H12AffineFastState.compose env35023 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35023 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,32,16,73737,8192,64,398436,79131,77835,406605,1364,73771,256,73771,79194,74250]

theorem envBound35024 : H12AffineFastState.Bounded env35024 := by
  intro p hp
  have h : env35024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0