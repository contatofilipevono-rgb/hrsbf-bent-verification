import H12CloudChart0Data150

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound38281 : H12AffineFastState.Bounded env38281 := by
  intro p hp
  have h : env38281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38280_38281 : H12AffineEnvironment.transform 14 29788 env38280 = env38281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env38280 == env38281) = true)

theorem identity38281 : scanCanonicalize (H12AffineFastState.compose env38281 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38281 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,343,13388,10280,1025,8540,4161,33,17,2,8193,64,10588,13389,4096,10280,9224,8573,257,8573,13325,513]

theorem envBound38282 : H12AffineFastState.Bounded env38282 := by
  intro p hp
  have h : env38282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38281_38282 : H12AffineEnvironment.transform 13 5377 env38281 = env38282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38281 == env38282) = true)

def env38283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,121942,115151,17665,2404757,119043,329731,257,2199999,2191386,63188]

theorem envBound38283 : H12AffineFastState.Bounded env38283 := by
  intro p hp
  have h : env38283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38233_38283 : H12AffineEnvironment.transform 21 272513 env38233 = env38283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38233 == env38283) = true)

theorem identity38283 : scanCanonicalize (H12AffineFastState.compose env38283 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound38283 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,272513,17,21763,8328,64,121942,115151,17665,303572,119043,329731,257,98814,90203,63188]

theorem envBound38284 : H12AffineFastState.Bounded env38284 := by
  intro p hp
  have h : env38284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38283_38284 : H12AffineEnvironment.transform 20 4161 env38283 = env38284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38283 == env38284) = true)

def env38285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,272393,17,21763,8192,64,121942,115015,17665,303452,119043,329731,257,98678,90203,63068]

theorem envBound38285 : H12AffineFastState.Bounded env38285 := by
  intro p hp
  have h : env38285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38284_38285 : H12AffineEnvironment.transform 6 8 env38284 = env38285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38284 == env38285) = true)

theorem identity38285 : scanCanonicalize (H12AffineFastState.compose env38285 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound38285 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1025,32769,4161,41341,17,21763,8192,64,121942,115015,17665,10280,119043,98679,257,98678,90203,63068]

theorem envBound38286 : H12AffineFastState.Bounded env38286 := by
  intro p hp
  have h : env38286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38285_38286 : H12AffineEnvironment.transform 17 35188 env38285 = env38286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env38285 == env38286) = true)

theorem identity38286 : scanCanonicalize (H12AffineFastState.compose env38286 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound38286 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,24908,23668,1025,21761,4161,29821,17,21763,8192,64,67926,70727,17665,10280,66563,87159,257,87158,90203,9052]

theorem envBound38287 : H12AffineFastState.Bounded env38287 := by
  intro p hp
  have h : env38287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38286_38287 : H12AffineEnvironment.transform 14 21760 env38286 = env38287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env38286 == env38287) = true)

theorem identity38287 : scanCanonicalize (H12AffineFastState.compose env38287 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38287 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env38288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,16401,23668,1025,21761,4161,21792,17,21763,349,64,67926,70727,17665,2421,66563,87159,257,87158,82182,513]

theorem envBound38288 : H12AffineFastState.Bounded env38288 := by
  intro p hp
  have h : env38288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38287_38288 : H12AffineEnvironment.transform 12 349 env38287 = env38288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38287 == env38288) = true)

theorem identity38288 : scanCanonicalize (H12AffineFastState.compose env38288 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38288 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38289 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21621,65536,16401,23668,1025,21620,4161,21589,17,21622,40,64,67619,70727,17524,2048,66563,87159,116,87158,82035,513]

theorem envBound38289 : H12AffineFastState.Bounded env38289 := by
  intro p hp
  have h : env38289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38288_38289 : H12AffineEnvironment.transform 7 117 env38288 = env38289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38288 == env38289) = true)

theorem identity38289 : scanCanonicalize (H12AffineFastState.compose env38289 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound38289 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env38290 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,4112,1125,65536,4097,3172,1025,1124,4161,1093,17,1126,40,64,67619,70727,5220,2048,66563,66663,116,66662,69731,513]

theorem envBound38290 : H12AffineFastState.Bounded env38290 := by
  intro p hp
  have h : env38290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38289_38290 : H12AffineEnvironment.transform 13 4112 env38289 = env38290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env38289 == env38290) = true)

theorem identity38290 : scanCanonicalize (H12AffineFastState.compose env38290 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound38290 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38291 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,4112,1125,1094,4097,3172,1025,1124,4161,1093,17,1126,40,64,3173,4097,5220,2048,69,33,116,32,5157,513]

theorem envBound38291 : H12AffineFastState.Bounded env38291 := by
  intro p hp
  have h : env38291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38290_38291 : H12AffineEnvironment.transform 15 1094 env38290 = env38291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env38290 == env38291) = true)

theorem identity38291 : scanCanonicalize (H12AffineFastState.compose env38291 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound38291 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38292 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3173,40,3189,1125,1094,3172,3172,1025,1124,3108,1093,17,1126,40,64,3173,3172,2049,2048,69,33,116,32,2112,513]

theorem envBound38292 : H12AffineFastState.Bounded env38292 := by
  intro p hp
  have h : env38292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38291_38292 : H12AffineEnvironment.transform 11 3173 env38291 = env38292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env38291 == env38292) = true)

theorem identity38292 : scanCanonicalize (H12AffineFastState.compose env38292 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38292 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env38293 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2128,40,2112,80,115,2129,2129,52,81,2065,112,17,83,40,64,2128,2129,2049,2048,69,33,116,32,2112,513]

theorem envBound38293 : H12AffineFastState.Bounded env38293 := by
  intro p hp
  have h : env38293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38292_38293 : H12AffineEnvironment.transform 9 53 env38292 = env38293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38292 == env38293) = true)

theorem identity38293 : scanCanonicalize (H12AffineFastState.compose env38293 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38293 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38294 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2048,40,2064,0,35,2049,2049,52,1,2065,32,17,3,40,16,2048,2049,2049,2048,21,33,36,32,2064,513]

theorem envBound38294 : H12AffineFastState.Bounded env38294 := by
  intro p hp
  have h : env38294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38293_38294 : H12AffineEnvironment.transform 5 16 env38293 = env38294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38293 == env38294) = true)

theorem identity38294 : scanCanonicalize (H12AffineFastState.compose env38294 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 517) := by decide +kernel

theorem selectedBound38294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38295 : List Nat := [2,4,8,16,32,16,8,37,512,53,517,517,40,533,0,35,516,516,52,1,532,32,17,3,40,16,517,516,516,517,21,33,36,32,533,513]

theorem envBound38295 : H12AffineFastState.Bounded env38295 := by
  intro p hp
  have h : env38295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38294_38295 : H12AffineEnvironment.transform 10 517 env38294 = env38295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 517 env38294 == env38295) = true)

theorem identity38295 : scanCanonicalize (H12AffineFastState.compose env38295 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound38295 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38296 : List Nat := [2,4,8,7,32,7,8,37,512,34,517,517,40,514,0,35,516,516,35,1,515,32,6,3,40,7,517,516,516,517,2,33,36,32,514,513]

theorem envBound38296 : H12AffineFastState.Bounded env38296 := by
  intro p hp
  have h : env38296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38295_38296 : H12AffineEnvironment.transform 3 7 env38295 = env38296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env38295 == env38296) = true)

theorem identity38296 : scanCanonicalize (H12AffineFastState.compose env38296 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38296 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38297 : List Nat := [2,2,8,1,32,1,8,35,512,34,515,515,40,514,0,35,514,514,35,1,515,32,0,3,40,1,515,514,514,515,2,33,34,32,514,513]

theorem envBound38297 : H12AffineFastState.Bounded env38297 := by
  intro p hp
  have h : env38297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38296_38297 : H12AffineEnvironment.transform 1 2 env38296 = env38297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38296 == env38297) = true)

theorem identity38297 : scanCanonicalize (H12AffineFastState.compose env38297 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38297 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38298 : List Nat := [2,2,3,1,32,1,3,35,512,34,515,515,35,514,0,35,514,514,35,1,515,32,0,3,35,1,515,514,514,515,2,33,34,32,514,513]

theorem envBound38298 : H12AffineFastState.Bounded env38298 := by
  intro p hp
  have h : env38298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38297_38298 : H12AffineEnvironment.transform 2 3 env38297 = env38298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38297 == env38298) = true)

theorem identity38298 : scanCanonicalize (H12AffineFastState.compose env38298 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38298 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38299 : List Nat := [2,2,3,1,1,1,3,2,512,3,515,515,2,514,0,2,514,514,2,1,515,1,0,3,2,1,515,514,514,515,2,0,3,1,514,513]

theorem envBound38299 : H12AffineFastState.Bounded env38299 := by
  intro p hp
  have h : env38299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38298_38299 : H12AffineEnvironment.transform 4 1 env38298 = env38299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38298 == env38299) = true)

def env38300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272392,17,21763,8193,64,121942,115014,17665,303453,119043,329731,257,98679,90203,63069]

theorem envBound38300 : H12AffineFastState.Bounded env38300 := by
  intro p hp
  have h : env38300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38284_38300 : H12AffineEnvironment.transform 6 9 env38284 = env38300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38284 == env38300) = true)

theorem identity38300 : scanCanonicalize (H12AffineFastState.compose env38300 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38300 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1025,32769,4161,32,17,21763,8193,64,121942,115014,17665,35189,119043,73771,257,98679,90203,63069]

theorem envBound38301 : H12AffineFastState.Bounded env38301 := by
  intro p hp
  have h : env38301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38300_38301 : H12AffineEnvironment.transform 17 10280 env38300 = env38301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38300 == env38301) = true)

theorem identity38301 : scanCanonicalize (H12AffineFastState.compose env38301 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38301 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env38302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,5393,10280,1025,32769,4161,32,17,8543,8193,64,108554,111898,12637,35189,107871,73771,257,98679,70663,33281]

theorem envBound38302 : H12AffineFastState.Bounded env38302 := by
  intro p hp
  have h : env38302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38301_38302 : H12AffineEnvironment.transform 13 13404 env38301 = env38302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38301 == env38302) = true)

theorem identity38302 : scanCanonicalize (H12AffineFastState.compose env38302 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38302 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,8202,5393,10280,1025,32769,4161,32,17,8543,8193,64,34816,38160,12637,35189,34133,33,257,41341,13325,33281]

theorem envBound38303 : H12AffineFastState.Bounded env38303 := by
  intro p hp
  have h : env38303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38302_38303 : H12AffineEnvironment.transform 15 8202 env38302 = env38303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38302 == env38303) = true)

theorem identity38303 : scanCanonicalize (H12AffineFastState.compose env38303 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38303 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env38304 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,8202,5393,10280,1025,32769,4113,32,17,8463,8193,16,34816,38160,12557,35109,34053,33,257,41261,13325,33281]

theorem envBound38304 : H12AffineFastState.Bounded env38304 := by
  intro p hp
  have h : env38304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38303_38304 : H12AffineEnvironment.transform 5 16 env38303 = env38304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38303 == env38304) = true)

theorem identity38304 : scanCanonicalize (H12AffineFastState.compose env38304 (packedSelected [2,3,5,6,7,9,11,12,16] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound38304 : packedSelected [2,3,5,6,7,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env38305 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,14137,8202,5393,10280,1025,14136,4113,32,17,8463,8193,16,16185,8745,12557,15900,12860,33,257,5652,13325,13624]

theorem envBound38305 : H12AffineFastState.Bounded env38305 := by
  intro p hp
  have h : env38305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38304_38305 : H12AffineEnvironment.transform 14 14137 env38304 = env38305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env38304 == env38305) = true)

theorem identity38305 : scanCanonicalize (H12AffineFastState.compose env38305 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38305 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env38306 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,5685,262,5393,2340,1025,5684,4113,32,17,3,269,16,7733,805,4097,7952,4912,33,257,5652,5377,5172]

theorem envBound38306 : H12AffineFastState.Bounded env38306 := by
  intro p hp
  have h : env38306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38305_38306 : H12AffineEnvironment.transform 12 268 env38305 = env38306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38305 == env38306) = true)

theorem identity38306 : scanCanonicalize (H12AffineFastState.compose env38306 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound38306 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38307 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,268,292,529,262,309,2340,1025,528,1077,32,17,3,269,16,2577,805,1061,2868,1812,33,257,560,293,16]

theorem envBound38307 : H12AffineFastState.Bounded env38307 := by
  intro p hp
  have h : env38307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38306_38307 : H12AffineEnvironment.transform 11 1060 env38306 = env38307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env38306 == env38307) = true)

theorem identity38307 : scanCanonicalize (H12AffineFastState.compose env38307 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound38307 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38308 : List Nat := [2,4,8,16,32,16,9,256,512,1024,309,1060,268,292,529,262,309,17,1025,528,1077,32,17,3,269,16,804,805,1061,513,1812,33,257,560,293,16]

theorem envBound38308 : H12AffineFastState.Bounded env38308 := by
  intro p hp
  have h : env38308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38307_38308 : H12AffineEnvironment.transform 10 309 env38307 = env38308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env38307 == env38308) = true)

theorem identity38308 : scanCanonicalize (H12AffineFastState.compose env38308 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound38308 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env38309 : List Nat := [2,4,8,16,32,16,9,52,512,1024,1,1060,56,16,529,50,1,17,1025,528,1077,32,17,3,57,16,528,529,1061,513,1568,33,53,560,17,16]

theorem envBound38309 : H12AffineFastState.Bounded env38309 := by
  intro p hp
  have h : env38309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38308_38309 : H12AffineEnvironment.transform 7 52 env38308 = env38309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env38308 == env38309) = true)

theorem identity38309 : scanCanonicalize (H12AffineFastState.compose env38309 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound38309 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38310 : List Nat := [2,4,8,16,32,16,9,52,512,532,1,560,56,16,529,50,1,17,533,528,545,32,17,3,57,16,528,529,561,513,52,33,53,560,17,16]

theorem envBound38310 : H12AffineFastState.Bounded env38310 := by
  intro p hp
  have h : env38310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38309_38310 : H12AffineEnvironment.transform 9 532 env38309 = env38310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env38309 == env38310) = true)

theorem identity38310 : scanCanonicalize (H12AffineFastState.compose env38310 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound38310 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38311 : List Nat := [2,4,8,16,32,16,9,52,16,4,1,32,56,16,1,50,1,17,5,0,49,32,17,3,57,16,0,1,33,17,52,33,53,32,17,16]

theorem envBound38311 : H12AffineFastState.Bounded env38311 := by
  intro p hp
  have h : env38311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38310_38311 : H12AffineEnvironment.transform 8 16 env38310 = env38311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env38310 == env38311) = true)

theorem identity38311 : scanCanonicalize (H12AffineFastState.compose env38311 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound38311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38312 : List Nat := [2,4,8,16,5,16,9,17,16,4,1,5,29,16,1,23,1,17,5,0,20,5,17,3,28,16,0,1,4,17,17,4,16,5,17,16]

theorem envBound38312 : H12AffineFastState.Bounded env38312 := by
  intro p hp
  have h : env38312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38311_38312 : H12AffineEnvironment.transform 4 5 env38311 = env38312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env38311 == env38312) = true)

theorem identity38312 : scanCanonicalize (H12AffineFastState.compose env38312 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38313 : List Nat := [2,1,8,16,0,16,9,17,16,1,1,0,24,16,1,18,1,17,0,0,17,0,17,3,25,16,0,1,1,17,17,1,16,0,17,16]

theorem envBound38313 : H12AffineFastState.Bounded env38313 := by
  intro p hp
  have h : env38313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38312_38313 : H12AffineEnvironment.transform 1 1 env38312 = env38313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38312 == env38313) = true)

theorem identity38313 : scanCanonicalize (H12AffineFastState.compose env38313 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound38313 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38314 : List Nat := [2,1,8,2,0,2,9,3,2,1,1,0,10,2,1,0,1,3,0,0,3,0,3,3,11,2,0,1,1,3,3,1,2,0,3,2]

theorem envBound38314 : H12AffineFastState.Bounded env38314 := by
  intro p hp
  have h : env38314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38313_38314 : H12AffineEnvironment.transform 3 2 env38313 = env38314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env38313 == env38314) = true)

theorem identity38314 : scanCanonicalize (H12AffineFastState.compose env38314 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38314 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38315 : List Nat := [2,1,0,2,0,2,1,3,2,1,1,0,2,2,1,0,1,3,0,0,3,0,3,3,3,2,0,1,1,3,3,1,2,0,3,2]

theorem envBound38315 : H12AffineFastState.Bounded env38315 := by
  intro p hp
  have h : env38315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38314_38315 : H12AffineEnvironment.transform 2 0 env38314 = env38315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38314 == env38315) = true)

def env38316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4584662,115151,17664,2404756,119042,4268162,257,2199998,2191387,63189]

theorem envBound38316 : H12AffineFastState.Bounded env38316 := by
  intro p hp
  have h : env38316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38232_38316 : H12AffineEnvironment.transform 22 2101329 env38232 = env38316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env38232 == env38316) = true)

def env38317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,121942,115151,17664,2404756,119042,329730,257,2199998,2191387,63189]

theorem envBound38317 : H12AffineFastState.Bounded env38317 := by
  intro p hp
  have h : env38317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38316_38317 : H12AffineEnvironment.transform 21 272512 env38316 = env38317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38316 == env38317) = true)

theorem identity38317 : scanCanonicalize (H12AffineFastState.compose env38317 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound38317 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25028,262144,1025,29909,2097152,272512,2101329,2114882,8328,64,75906,79131,17664,2377024,75222,329730,257,2188650,2191387,513]

theorem envBound38318 : H12AffineFastState.Bounded env38318 := by
  intro p hp
  have h : env38318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38317_38318 : H12AffineEnvironment.transform 14 29908 env38317 = env38318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env38317 == env38318) = true)

def env38319 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,2097152,272512,2101249,2114834,8328,16,75906,79131,17664,2376976,75142,329730,257,2188602,2191387,513]

theorem envBound38319 : H12AffineFastState.Bounded env38319 := by
  intro p hp
  have h : env38319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38318_38319 : H12AffineEnvironment.transform 5 16 env38318 = env38319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38318 == env38319) = true)

def env38320 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,24860,262144,1025,29709,2097152,272392,2101249,2114834,8192,16,75786,79131,17664,2376976,75022,329730,257,2188602,2191387,513]

theorem envBound38320 : H12AffineFastState.Bounded env38320 := by
  intro p hp
  have h : env38320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38319_38320 : H12AffineEnvironment.transform 6 8 env38319 = env38320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38319 == env38320) = true)

theorem identity38320 : scanCanonicalize (H12AffineFastState.compose env38320 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 69683) := by decide +kernel

theorem selectedBound38320 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env38321 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,24860,262144,1025,29709,69683,272392,65586,87329,8192,16,75786,79131,17664,349475,75022,329730,257,29961,24616,513]

theorem envBound38321 : H12AffineFastState.Bounded env38321 := by
  intro p hp
  have h : env38321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38320_38321 : H12AffineEnvironment.transform 20 69683 env38320 = env38321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69683 env38320 == env38321) = true)

theorem identity38321 : scanCanonicalize (H12AffineFastState.compose env38321 (packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38321 : packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env38322 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,263,24860,262144,1025,29709,4404,272392,309,21542,8192,16,10509,13340,17664,283684,9225,264453,257,29961,24616,513]

theorem envBound38322 : H12AffineFastState.Bounded env38322 := by
  intro p hp
  have h : env38322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38321_38322 : H12AffineEnvironment.transform 15 263 env38321 = env38322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38321 == env38322) = true)

theorem identity38322 : scanCanonicalize (H12AffineFastState.compose env38322 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22544) := by decide +kernel

theorem selectedBound38322 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38323 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,263,24860,22544,1025,29709,4404,28696,309,21542,8192,16,10509,13340,17664,3124,9225,20757,257,29961,24616,513]

theorem envBound38323 : H12AffineFastState.Bounded env38323 := by
  intro p hp
  have h : env38323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38322_38323 : H12AffineEnvironment.transform 17 22544 env38322 = env38323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22544 env38322 == env38323) = true)

theorem identity38323 : scanCanonicalize (H12AffineFastState.compose env38323 (packedSelected [1,2,3,6,8,10,11,12,15,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound38323 : packedSelected [1,2,3,6,8,10,11,12,15,23,24] rootPS < 2^1333 := by decide +kernel

def env38324 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5157,8233,263,13625,3125,1025,8232,4404,9277,309,3,8192,16,10509,13340,4389,3124,9225,1328,257,8492,13325,513]

theorem envBound38324 : H12AffineFastState.Bounded env38324 := by
  intro p hp
  have h : env38324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38323_38324 : H12AffineEnvironment.transform 13 5157 env38323 = env38324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env38323 == env38324) = true)

theorem identity38324 : scanCanonicalize (H12AffineFastState.compose env38324 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38324 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38325 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,4113,8233,263,12557,2049,53,8232,4404,8201,309,3,8192,16,10509,12328,4389,2048,8253,260,257,8492,12345,513]

theorem envBound38325 : H12AffineFastState.Bounded env38325 := by
  intro p hp
  have h : env38325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38324_38325 : H12AffineEnvironment.transform 9 52 env38324 = env38325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38324 == env38325) = true)

theorem identity38325 : scanCanonicalize (H12AffineFastState.compose env38325 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38325 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38326 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4113,292,263,4096,2049,53,293,4404,260,309,3,269,16,2048,4389,4389,2048,304,260,257,33,4404,513]

theorem envBound38326 : H12AffineFastState.Bounded env38326 := by
  intro p hp
  have h : env38326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38325_38326 : H12AffineEnvironment.transform 12 269 env38325 = env38326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38325 == env38326) = true)

theorem identity38326 : scanCanonicalize (H12AffineFastState.compose env38326 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound38326 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38327 : List Nat := [2,4,8,16,32,16,8,256,512,52,292,4096,269,4113,292,263,4096,293,53,293,4404,260,309,3,269,16,292,4389,4389,292,304,260,257,33,4404,513]

theorem envBound38327 : H12AffineFastState.Bounded env38327 := by
  intro p hp
  have h : env38327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38326_38327 : H12AffineEnvironment.transform 10 292 env38326 = env38327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env38326 == env38327) = true)

theorem identity38327 : scanCanonicalize (H12AffineFastState.compose env38327 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound38327 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38328 : List Nat := [2,4,8,16,32,16,8,256,512,52,292,17,269,0,292,263,17,293,53,293,293,260,309,3,269,16,292,308,308,292,304,260,257,33,293,513]

theorem envBound38328 : H12AffineFastState.Bounded env38328 := by
  intro p hp
  have h : env38328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38327_38328 : H12AffineEnvironment.transform 11 17 env38327 = env38328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env38327 == env38328) = true)

theorem identity38328 : scanCanonicalize (H12AffineFastState.compose env38328 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38328 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38329 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,17,40,0,1,34,17,0,53,0,0,33,16,3,40,16,1,17,17,1,21,33,36,33,0,513]

theorem envBound38329 : H12AffineFastState.Bounded env38329 := by
  intro p hp
  have h : env38329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38328_38329 : H12AffineEnvironment.transform 7 37 env38328 = env38329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38328 == env38329) = true)

theorem identity38329 : scanCanonicalize (H12AffineFastState.compose env38329 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38330 : List Nat := [2,4,8,16,32,16,8,37,1,52,1,17,40,0,1,34,17,0,53,0,0,33,16,3,40,16,1,17,17,1,21,33,36,33,0,0]

theorem envBound38330 : H12AffineFastState.Bounded env38330 := by
  intro p hp
  have h : env38330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38329_38330 : H12AffineEnvironment.transform 8 1 env38329 = env38330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38329 == env38330) = true)

theorem identity38330 : scanCanonicalize (H12AffineFastState.compose env38330 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38331 : List Nat := [2,4,8,11,32,11,8,37,1,47,1,10,40,0,1,34,10,0,46,0,0,33,11,3,40,11,1,10,10,1,14,33,36,33,0,0]

theorem envBound38331 : H12AffineFastState.Bounded env38331 := by
  intro p hp
  have h : env38331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38330_38331 : H12AffineEnvironment.transform 3 11 env38330 = env38331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38330 == env38331) = true)

def env38332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24861,262144,1025,29708,2097152,272393,2101249,2114834,8193,16,75787,79131,17664,2376976,75023,329730,257,2188602,2191387,513]

theorem envBound38332 : H12AffineFastState.Bounded env38332 := by
  intro p hp
  have h : env38332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38319_38332 : H12AffineEnvironment.transform 6 9 env38319 = env38332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38319 == env38332) = true)

theorem identity38332 : scanCanonicalize (H12AffineFastState.compose env38332 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound38332 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env38333 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24861,262144,1025,29708,25628,272393,29725,8462,8193,16,75787,79131,17664,270604,75023,329730,257,65830,70663,513]

theorem envBound38333 : H12AffineFastState.Bounded env38333 := by
  intro p hp
  have h : env38333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38332_38333 : H12AffineEnvironment.transform 20 25628 env38332 = env38333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env38332 == env38333) = true)

theorem identity38333 : scanCanonicalize (H12AffineFastState.compose env38333 (packedSelected [1,4,8,9,12,14,15,16,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound38333 : packedSelected [1,4,8,9,12,14,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env38334 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24861,23589,1025,29708,25628,29740,29725,8462,8193,16,75787,79131,17664,32041,75023,87079,257,65830,70663,513]

theorem envBound38334 : H12AffineFastState.Bounded env38334 := by
  intro p hp
  have h : env38334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38333_38334 : H12AffineEnvironment.transform 17 23589 env38333 = env38334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env38333 == env38334) = true)

theorem identity38334 : scanCanonicalize (H12AffineFastState.compose env38334 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38334 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38335 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,65536,13341,2341,1025,8460,12572,8492,8477,8462,8193,16,75787,79131,4096,10281,75023,65831,257,65830,70663,513]

theorem envBound38335 : H12AffineFastState.Bounded env38335 := by
  intro p hp
  have h : env38335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38334_38335 : H12AffineEnvironment.transform 13 5376 env38334 = env38335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38334 == env38335) = true)

def env38336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,262144,1025,29828,2097152,272512,2101248,2114835,8328,17,75906,79131,17664,2376977,75143,329730,257,2188603,2191387,513]

theorem envBound38336 : H12AffineFastState.Bounded env38336 := by
  intro p hp
  have h : env38336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38318_38336 : H12AffineEnvironment.transform 5 17 env38318 = env38336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38318 == env38336) = true)

theorem identity38336 : scanCanonicalize (H12AffineFastState.compose env38336 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38336 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env38337 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,10280,1025,29828,2097152,168,2101248,2114835,8328,17,75906,79131,17664,2125113,75143,73770,257,2188603,2191387,513]

theorem envBound38337 : H12AffineFastState.Bounded env38337 := by
  intro p hp
  have h : env38337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38336_38337 : H12AffineEnvironment.transform 17 10280 env38336 = env38337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38336 == env38337) = true)

theorem identity38337 : scanCanonicalize (H12AffineFastState.compose env38337 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38337 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env38338 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8203,24981,10280,1025,29828,2097152,168,2101248,2114835,8328,17,2185,5392,17664,2125113,1420,33,257,2114864,2117648,513]

theorem envBound38338 : H12AffineFastState.Bounded env38338 := by
  intro p hp
  have h : env38338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38337_38338 : H12AffineEnvironment.transform 15 8203 env38337 = env38338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38337 == env38338) = true)

theorem identity38338 : scanCanonicalize (H12AffineFastState.compose env38338 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound38338 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38339 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,136,8203,5528,10280,1025,137,2097152,168,2101248,2109726,8328,17,2185,5392,12557,2103604,1420,33,257,2109757,2106397,513]

theorem envBound38339 : H12AffineFastState.Bounded env38339 := by
  intro p hp
  have h : env38339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38338_38339 : H12AffineEnvironment.transform 13 13325 env38338 = env38339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env38338 == env38339) = true)

theorem identity38339 : scanCanonicalize (H12AffineFastState.compose env38339 (packedSelected [0,7,11,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound38339 : packedSelected [0,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env38340 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,136,8203,5528,10280,1025,137,12572,168,8476,2,8328,17,2185,5392,12557,10280,1420,33,257,33,5377,513]

theorem envBound38340 : H12AffineFastState.Bounded env38340 := by
  intro p hp
  have h : env38340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38339_38340 : H12AffineEnvironment.transform 20 12572 env38339 = env38340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env38339 == env38340) = true)

theorem identity38340 : scanCanonicalize (H12AffineFastState.compose env38340 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38340 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38341 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,136,263,5528,2340,1025,137,4112,168,16,2,388,17,2185,5392,4097,2340,1420,33,257,33,5377,513]

theorem envBound38341 : H12AffineFastState.Bounded env38341 := by
  intro p hp
  have h : env38341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38340_38341 : H12AffineEnvironment.transform 12 268 env38340 = env38341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38340 == env38341) = true)

theorem identity38341 : scanCanonicalize (H12AffineFastState.compose env38341 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound38341 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38342 : List Nat := [2,4,8,16,32,17,128,141,512,1024,2048,4096,129,5260,136,138,5141,2217,1025,137,4112,168,16,2,9,17,2185,5277,4097,2217,1025,33,140,33,5260,513]

theorem envBound38342 : H12AffineFastState.Bounded env38342 := by
  intro p hp
  have h : env38342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38341_38342 : H12AffineEnvironment.transform 7 141 env38341 = env38342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env38341 == env38342) = true)

theorem identity38342 : scanCanonicalize (H12AffineFastState.compose env38342 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound38342 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env38343 : List Nat := [2,4,8,16,32,17,128,141,512,1024,1181,4096,129,5260,136,138,5141,1076,1025,137,4112,168,16,2,9,17,1044,5277,4097,1076,1025,33,140,33,5260,513]

theorem envBound38343 : H12AffineFastState.Bounded env38343 := by
  intro p hp
  have h : env38343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38342_38343 : H12AffineEnvironment.transform 10 1181 env38342 = env38343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env38342 == env38343) = true)

theorem identity38343 : scanCanonicalize (H12AffineFastState.compose env38343 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound38343 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38344 : List Nat := [2,4,8,16,32,17,128,141,512,1024,1181,1588,129,696,136,138,545,1076,1025,137,1572,168,16,2,9,17,1044,681,1589,1076,1025,33,140,33,696,513]

theorem envBound38344 : H12AffineFastState.Bounded env38344 := by
  intro p hp
  have h : env38344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38343_38344 : H12AffineEnvironment.transform 11 1588 env38343 = env38344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env38343 == env38344) = true)

theorem identity38344 : scanCanonicalize (H12AffineFastState.compose env38344 (packedSelected [1,2,4,7,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound38344 : packedSelected [1,2,4,7,8,12] rootPS < 2^1333 := by decide +kernel

def env38345 : List Nat := [2,4,8,16,32,17,128,141,49,1024,1181,1029,129,137,136,138,16,1076,1025,137,1045,168,16,2,9,17,1044,152,1028,1076,1025,33,140,33,137,48]

theorem envBound38345 : H12AffineFastState.Bounded env38345 := by
  intro p hp
  have h : env38345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38344_38345 : H12AffineEnvironment.transform 8 49 env38344 = env38345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38344 == env38345) = true)

theorem identity38345 : scanCanonicalize (H12AffineFastState.compose env38345 (packedSelected [4,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound38345 : packedSelected [4,7,14] rootPS < 2^1333 := by decide +kernel

def env38346 : List Nat := [2,4,8,16,32,17,24,21,49,1024,1029,1029,25,17,16,18,16,1076,1025,17,1045,48,16,2,9,17,1044,0,1028,1076,1025,33,20,33,17,48]

theorem envBound38346 : H12AffineFastState.Bounded env38346 := by
  intro p hp
  have h : env38346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38345_38346 : H12AffineEnvironment.transform 6 24 env38345 = env38346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env38345 == env38346) = true)

theorem identity38346 : scanCanonicalize (H12AffineFastState.compose env38346 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38347 : List Nat := [2,4,8,16,0,17,24,21,17,1024,1029,1029,25,17,16,18,16,1044,1025,17,1045,16,16,2,9,17,1044,0,1028,1044,1025,1,20,1,17,16]

theorem envBound38347 : H12AffineFastState.Bounded env38347 := by
  intro p hp
  have h : env38347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38346_38347 : H12AffineEnvironment.transform 4 0 env38346 = env38347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38346 == env38347) = true)

theorem identity38347 : scanCanonicalize (H12AffineFastState.compose env38347 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38347 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38348 : List Nat := [2,4,8,1,0,0,9,4,0,1024,1029,1029,8,0,1,3,1,1029,1025,0,1028,1,1,2,9,0,1029,0,1028,1029,1025,1,5,1,0,1]

theorem envBound38348 : H12AffineFastState.Bounded env38348 := by
  intro p hp
  have h : env38348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38347_38348 : H12AffineEnvironment.transform 3 1 env38347 = env38348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38347 == env38348) = true)

theorem identity38348 : scanCanonicalize (H12AffineFastState.compose env38348 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38349 : List Nat := [2,4,8,1,0,0,9,4,0,5,0,0,8,0,1,3,1,0,4,0,1,1,1,2,9,0,0,0,1,0,4,1,5,1,0,1]

theorem envBound38349 : H12AffineFastState.Bounded env38349 := by
  intro p hp
  have h : env38349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38348_38349 : H12AffineEnvironment.transform 9 5 env38348 = env38349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38348 == env38349) = true)

def env38350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,121943,115151,17664,2404756,119042,329731,257,2199998,2191387,63189]

theorem envBound38350 : H12AffineFastState.Bounded env38350 := by
  intro p hp
  have h : env38350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38316_38350 : H12AffineEnvironment.transform 21 272513 env38316 = env38350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38316 == env38350) = true)

theorem identity38350 : scanCanonicalize (H12AffineFastState.compose env38350 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound38350 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,58516,272513,62661,41430,8328,64,121943,115151,17664,283904,119042,329731,257,95530,103567,63189]

theorem envBound38351 : H12AffineFastState.Bounded env38351 := by
  intro p hp
  have h : env38351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38350_38351 : H12AffineEnvironment.transform 20 58516 env38350 = env38351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env38350 == env38351) = true)

theorem identity38351 : scanCanonicalize (H12AffineFastState.compose env38351 (packedSelected [4,7,9,14,17,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38351 : packedSelected [4,7,9,14,17,27,35] rootPS < 2^1333 := by decide +kernel

def env38352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,25028,262144,1025,32769,58516,272513,62661,41430,8328,64,64605,57797,17664,283904,61704,272393,257,21792,46213,63189]

theorem envBound38352 : H12AffineFastState.Bounded env38352 := by
  intro p hp
  have h : env38352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38351_38352 : H12AffineEnvironment.transform 15 8202 env38351 = env38352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38351 == env38352) = true)

theorem identity38352 : scanCanonicalize (H12AffineFastState.compose env38352 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound38352 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env38353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,25028,262144,1025,29909,4160,272513,17,21762,8328,64,2185,5393,17664,283904,1500,272393,257,21792,16465,513]

theorem envBound38353 : H12AffineFastState.Bounded env38353 := by
  intro p hp
  have h : env38353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38352_38353 : H12AffineEnvironment.transform 14 29908 env38352 = env38353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env38352 == env38353) = true)

theorem identity38353 : scanCanonicalize (H12AffineFastState.compose env38353 (packedSelected [4,7,9,17,27] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound38353 : packedSelected [4,7,9,17,27] rootPS < 2^1333 := by decide +kernel

def env38354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,80,8202,5440,262144,1025,81,4160,272513,17,8582,8328,64,2185,5393,12676,270724,1500,272393,257,8612,13525,513]

theorem envBound38354 : H12AffineFastState.Bounded env38354 := by
  intro p hp
  have h : env38354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38353_38354 : H12AffineEnvironment.transform 13 13444 env38353 = env38354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env38353 == env38354) = true)

theorem identity38354 : scanCanonicalize (H12AffineFastState.compose env38354 (packedSelected [1,2,5,6,8,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38354 : packedSelected [1,2,5,6,8,17,24] rootPS < 2^1333 := by decide +kernel

def env38355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,80,262,5440,262144,1025,81,4160,264589,17,138,388,64,2185,5393,4232,262280,1500,264453,257,168,5593,513]

theorem envBound38355 : H12AffineFastState.Bounded env38355 := by
  intro p hp
  have h : env38355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38354_38355 : H12AffineEnvironment.transform 12 268 env38354 = env38355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38354 == env38355) = true)

theorem identity38355 : scanCanonicalize (H12AffineFastState.compose env38355 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound38355 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,80,262,5440,2340,1025,81,4160,169,17,138,388,64,2185,5393,4232,2476,1500,33,257,168,5593,513]

theorem envBound38356 : H12AffineFastState.Bounded env38356 := by
  intro p hp
  have h : env38356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38355_38356 : H12AffineEnvironment.transform 17 2340 env38355 = env38356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env38355 == env38356) = true)

theorem identity38356 : scanCanonicalize (H12AffineFastState.compose env38356 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound38356 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env38357 : List Nat := [2,4,8,16,32,64,128,256,17,1024,2048,4096,268,5512,80,262,5440,2340,1025,81,4160,169,17,138,388,64,2185,5393,4232,2476,1500,33,257,168,5593,16]

theorem envBound38357 : H12AffineFastState.Bounded env38357 := by
  intro p hp
  have h : env38357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38356_38357 : H12AffineEnvironment.transform 8 17 env38356 = env38357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env38356 == env38357) = true)

theorem identity38357 : scanCanonicalize (H12AffineFastState.compose env38357 (packedSelected [2,3,5,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38357 : packedSelected [2,3,5,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env38358 : List Nat := [2,4,8,16,32,64,128,5,17,1024,2048,4096,9,5261,80,3,5189,2081,1025,81,4160,169,17,138,129,64,2185,5140,4232,2217,1241,33,4,168,5340,16]

theorem envBound38358 : H12AffineFastState.Bounded env38358 := by
  intro p hp
  have h : env38358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38357_38358 : H12AffineEnvironment.transform 7 5 env38357 = env38358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38357 == env38358) = true)

theorem identity38358 : scanCanonicalize (H12AffineFastState.compose env38358 (packedSelected [1,2,4,8,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3228) := by decide +kernel

theorem selectedBound38358 : packedSelected [1,2,4,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env38359 : List Nat := [2,4,8,16,32,64,128,5,17,1024,2048,3228,9,2065,80,3,2265,2081,1025,81,3292,169,17,138,129,64,2185,2184,3092,2217,1241,33,4,168,2112,16]

theorem envBound38359 : H12AffineFastState.Bounded env38359 := by
  intro p hp
  have h : env38359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38358_38359 : H12AffineEnvironment.transform 11 3228 env38358 = env38359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3228 env38358 == env38359) = true)

theorem identity38359 : scanCanonicalize (H12AffineFastState.compose env38359 (packedSelected [1,2,3,4,5,7,8,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38359 : packedSelected [1,2,3,4,5,7,8,12,18] rootPS < 2^1333 := by decide +kernel

def env38360 : List Nat := [2,4,8,16,32,16,128,5,17,1024,2048,3228,9,2065,0,3,2185,2081,1025,1,3212,169,17,138,129,16,2185,2184,3092,2217,1161,33,4,168,2064,16]

theorem envBound38360 : H12AffineFastState.Bounded env38360 := by
  intro p hp
  have h : env38360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38359_38360 : H12AffineEnvironment.transform 5 16 env38359 = env38360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38359 == env38360) = true)

theorem identity38360 : scanCanonicalize (H12AffineFastState.compose env38360 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound38360 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38361 : List Nat := [2,4,8,16,32,16,128,5,17,1024,137,1045,9,152,0,3,0,168,1025,1,1029,169,17,138,129,16,0,1,1181,32,1161,33,4,168,153,16]

theorem envBound38361 : H12AffineFastState.Bounded env38361 := by
  intro p hp
  have h : env38361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38360_38361 : H12AffineEnvironment.transform 10 137 env38360 = env38361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env38360 == env38361) = true)

theorem identity38361 : scanCanonicalize (H12AffineFastState.compose env38361 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38361 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env38362 : List Nat := [2,4,8,16,32,16,128,5,17,4,137,17,9,152,0,3,0,168,5,1,1,169,17,138,129,16,0,1,153,32,141,33,4,168,153,16]

theorem envBound38362 : H12AffineFastState.Bounded env38362 := by
  intro p hp
  have h : env38362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38361_38362 : H12AffineEnvironment.transform 9 4 env38361 = env38362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38361 == env38362) = true)

def env38363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066247,115150,10507601,8692164,10600786,4268163,257,8487406,8478795,10544773]

theorem envBound38363 : H12AffineFastState.Bounded env38363 := by
  intro p hp
  have h : env38363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38231_38363 : H12AffineEnvironment.transform 16 25029 env38231 = env38363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env38231 == env38363) = true)

def env38364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4584663,115150,17665,2404756,119042,4268163,257,2199998,2191387,63189]

theorem envBound38364 : H12AffineFastState.Bounded env38364 := by
  intro p hp
  have h : env38364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38363_38364 : H12AffineEnvironment.transform 22 2101328 env38363 = env38364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env38363 == env38364) = true)

def env38365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,121943,115150,17665,2404756,119042,329731,257,2199998,2191387,63189]

theorem envBound38365 : H12AffineFastState.Bounded env38365 := by
  intro p hp
  have h : env38365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38364_38365 : H12AffineEnvironment.transform 21 272512 env38364 = env38365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38364 == env38365) = true)

theorem identity38365 : scanCanonicalize (H12AffineFastState.compose env38365 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound38365 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,115870,272512,120014,98781,8328,64,121943,115150,17665,357642,119042,329731,257,21792,46213,63189]

theorem envBound38366 : H12AffineFastState.Bounded env38366 := by
  intro p hp
  have h : env38366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38365_38366 : H12AffineEnvironment.transform 20 115870 env38365 = env38366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env38365 == env38366) = true)

def env38367 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,115870,272512,119966,98701,8328,16,121863,115102,17665,357642,119042,329731,257,21792,46213,63109]

theorem envBound38367 : H12AffineFastState.Bounded env38367 := by
  intro p hp
  have h : env38367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38366_38367 : H12AffineEnvironment.transform 5 16 env38366 = env38367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38366 == env38367) = true)

theorem identity38367 : scanCanonicalize (H12AffineFastState.compose env38367 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound38367 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38368 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,100522,1025,32769,115870,106538,119966,98701,8328,16,121863,115102,17665,64928,119042,32937,257,21792,46213,63109]

theorem envBound38368 : H12AffineFastState.Bounded env38368 := by
  intro p hp
  have h : env38368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38367_38368 : H12AffineEnvironment.transform 17 100522 env38367 = env38368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env38367 == env38368) = true)

theorem identity38368 : scanCanonicalize (H12AffineFastState.compose env38368 (packedSelected [0,1,3,4,7,17,18,22,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound38368 : packedSelected [0,1,3,4,7,17,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38369 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,97326,1025,29829,77850,87214,73754,95497,8328,16,75907,79130,17665,2340,75142,29741,257,21792,16385,513]

theorem envBound38369 : H12AffineFastState.Bounded env38369 := by
  intro p hp
  have h : env38369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38368_38369 : H12AffineEnvironment.transform 14 29828 env38368 = env38369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env38368 == env38369) = true)

theorem identity38369 : scanCanonicalize (H12AffineFastState.compose env38369 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38369 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env38370 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,65536,13460,76079,1025,8580,77850,65967,73754,73736,8328,16,75907,79130,4096,2340,75142,8492,257,33,5376,513]

theorem envBound38370 : H12AffineFastState.Bounded env38370 := by
  intro p hp
  have h : env38370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38369_38370 : H12AffineEnvironment.transform 13 5377 env38369 = env38370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38369 == env38370) = true)

theorem identity38370 : scanCanonicalize (H12AffineFastState.compose env38370 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound38370 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env38371 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,398,13460,10401,1025,8580,12692,33,8596,8582,8328,16,10509,13460,4096,2340,9224,8492,257,33,5376,513]

theorem envBound38371 : H12AffineFastState.Bounded env38371 := by
  intro p hp
  have h : env38371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38370_38371 : H12AffineEnvironment.transform 15 398 env38370 = env38371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env38370 == env38371) = true)

theorem identity38371 : scanCanonicalize (H12AffineFastState.compose env38371 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38371 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38372 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,137,398,5528,2477,1025,136,4248,33,152,138,388,16,2049,5528,4096,2340,1284,32,257,33,5376,513]

theorem envBound38372 : H12AffineFastState.Bounded env38372 := by
  intro p hp
  have h : env38372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38371_38372 : H12AffineEnvironment.transform 12 268 env38371 = env38372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38371 == env38372) = true)

theorem identity38372 : scanCanonicalize (H12AffineFastState.compose env38372 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound38372 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38373 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,268,4248,137,398,4097,2477,408,136,4248,33,152,138,388,16,2049,4097,4096,2340,157,32,257,33,4249,513]

theorem envBound38373 : H12AffineFastState.Bounded env38373 := by
  intro p hp
  have h : env38373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38372_38373 : H12AffineEnvironment.transform 9 409 env38372 = env38373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env38372 == env38373) = true)

theorem identity38373 : scanCanonicalize (H12AffineFastState.compose env38373 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound38373 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env38374 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,2492,268,2340,137,398,2493,2477,408,136,2340,33,152,138,388,16,2049,2493,2492,2340,157,32,257,33,2341,513]

theorem envBound38374 : H12AffineFastState.Bounded env38374 := by
  intro p hp
  have h : env38374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38373_38374 : H12AffineEnvironment.transform 11 2492 env38373 = env38374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env38373 == env38374) = true)

theorem identity38374 : scanCanonicalize (H12AffineFastState.compose env38374 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38374 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env38375 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2356,268,2340,1,262,2357,2341,272,0,2340,33,16,2,268,16,2049,2357,2356,2340,21,32,257,33,2341,513]

theorem envBound38375 : H12AffineFastState.Bounded env38375 := by
  intro p hp
  have h : env38375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38374_38375 : H12AffineEnvironment.transform 6 8 env38374 = env38375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38374 == env38375) = true)

theorem identity38375 : scanCanonicalize (H12AffineFastState.compose env38375 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38375 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38376 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2064,40,2048,1,34,2065,2049,52,0,2048,33,16,2,40,16,2049,2065,2064,2048,21,32,37,33,2049,513]

theorem envBound38376 : H12AffineFastState.Bounded env38376 := by
  intro p hp
  have h : env38376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38375_38376 : H12AffineEnvironment.transform 7 36 env38375 = env38376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38375 == env38376) = true)

theorem identity38376 : scanCanonicalize (H12AffineFastState.compose env38376 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound38376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38377 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,40,48,1,34,33,49,52,0,48,33,16,2,40,16,49,33,32,48,21,32,37,33,49,513]

theorem envBound38377 : H12AffineFastState.Bounded env38377 := by
  intro p hp
  have h : env38377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38376_38377 : H12AffineEnvironment.transform 10 48 env38376 = env38377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env38376 == env38377) = true)

def leafEnv38377 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,40,48,1,34,33,49,52,0,48,33,16,2,20,40,1,16,49,33,32,48,21,32,37,33,5,34,49,513,1,49,0]

def active38377 : List Nat := [0,1,2,3,4,8]

def tree38377 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38377 : H12WitnessSearch.Good tree38377 := H12GlobalWitnessIndex.good

theorem leafIdentity38377 : H12AffineFastState.composeSystem env38377 rootObs = leafEnv38377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38377 rootObs == leafEnv38377) = true)

theorem terminalChecked38377 : H12PackedTerminal.terminalCheckFast leafEnv38377 active38377 tree38377 = true := by decide +kernel

def env38378 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,115870,272512,119967,98700,8328,17,121862,115103,17665,357642,119042,329731,257,21792,46213,63108]

theorem envBound38378 : H12AffineFastState.Bounded env38378 := by
  intro p hp
  have h : env38378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38366_38378 : H12AffineEnvironment.transform 5 17 env38366 = env38378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38366 == env38378) = true)

theorem identity38378 : scanCanonicalize (H12AffineFastState.compose env38378 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound38378 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38379 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,122146,1025,32769,115870,128418,119967,98700,8328,17,121862,115103,17665,43048,119042,54561,257,21792,46213,63108]

theorem envBound38379 : H12AffineFastState.Bounded env38379 := by
  intro p hp
  have h : env38379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38378_38379 : H12AffineEnvironment.transform 17 122146 env38378 = env38379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env38378 == env38379) = true)

theorem identity38379 : scanCanonicalize (H12AffineFastState.compose env38379 (packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound38379 : packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38380 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54278,24980,2340,1025,32769,4248,8612,153,21898,8328,17,2048,5529,17665,43048,1284,54561,257,21792,46213,63108]

theorem envBound38380 : H12AffineFastState.Bounded env38380 := by
  intro p hp
  have h : env38380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38379_38380 : H12AffineEnvironment.transform 15 54278 env38379 = env38380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env38379 == env38380) = true)

theorem identity38380 : scanCanonicalize (H12AffineFastState.compose env38380 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound38380 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38381 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8323,24980,2340,1025,29828,4248,8612,153,21898,8328,17,2048,5529,17665,23725,1284,8612,257,21792,16384,513]

theorem envBound38381 : H12AffineFastState.Bounded env38381 := by
  intro p hp
  have h : env38381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38380_38381 : H12AffineEnvironment.transform 14 29829 env38380 = env38381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env38380 == env38381) = true)

theorem identity38381 : scanCanonicalize (H12AffineFastState.compose env38381 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38381 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env38382 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21897,399,16536,2340,1025,21896,4248,168,153,21898,388,17,2048,5529,17665,23725,1284,168,257,21792,16384,513]

theorem envBound38382 : H12AffineFastState.Bounded env38382 := by
  intro p hp
  have h : env38382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38381_38382 : H12AffineEnvironment.transform 12 268 env38381 = env38382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38381 == env38382) = true)

theorem identity38382 : scanCanonicalize (H12AffineFastState.compose env38382 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38382 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38383 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,262,16401,2340,1025,21761,4113,33,16,21763,269,17,2048,5392,17665,23588,1284,33,257,21792,16384,513]

theorem envBound38383 : H12AffineFastState.Bounded env38383 := by
  intro p hp
  have h : env38383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38382_38383 : H12AffineEnvironment.transform 6 9 env38382 = env38383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38382 == env38383) = true)

theorem identity38383 : scanCanonicalize (H12AffineFastState.compose env38383 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound38383 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38384 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5157,293,262,5172,2340,1025,292,4113,33,16,294,269,17,2048,5392,4388,2049,1284,33,257,261,5157,513]

theorem envBound38384 : H12AffineFastState.Bounded env38384 := by
  intro p hp
  have h : env38384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38383_38384 : H12AffineEnvironment.transform 13 5157 env38383 = env38384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env38383 == env38384) = true)

theorem identity38384 : scanCanonicalize (H12AffineFastState.compose env38384 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38384 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38385 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,35,5172,2049,1025,1,4113,33,16,3,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound38385 : H12AffineFastState.Bounded env38385 := by
  intro p hp
  have h : env38385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38384_38385 : H12AffineEnvironment.transform 7 37 env38384 = env38385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38384 == env38385) = true)

def env38386 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1045,0,35,1028,2049,1025,1,33,33,16,3,40,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound38386 : H12AffineFastState.Bounded env38386 := by
  intro p hp
  have h : env38386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38385_38386 : H12AffineEnvironment.transform 11 48 env38385 = env38386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38385 == env38386) = true)

def env38387 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1044,0,35,1029,2049,1025,1,32,33,16,3,40,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound38387 : H12AffineFastState.Bounded env38387 := by
  intro p hp
  have h : env38387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38385_38387 : H12AffineEnvironment.transform 11 49 env38385 = env38387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38385 == env38387) = true)

theorem identity38387 : scanCanonicalize (H12AffineFastState.compose env38387 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38388 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,41,33,0,35,48,2049,52,1,32,33,16,3,40,17,2048,49,48,2049,20,33,36,32,33,513]

theorem envBound38388 : H12AffineFastState.Bounded env38388 := by
  intro p hp
  have h : env38388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38387_38388 : H12AffineEnvironment.transform 9 53 env38387 = env38388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38387 == env38388) = true)

def env38389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,121942,115150,17665,2404756,119042,329730,257,2199998,2191387,63189]

theorem envBound38389 : H12AffineFastState.Bounded env38389 := by
  intro p hp
  have h : env38389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38364_38389 : H12AffineEnvironment.transform 21 272513 env38364 = env38389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38364 == env38389) = true)

theorem identity38389 : scanCanonicalize (H12AffineFastState.compose env38389 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound38389 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,25029,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,2185,5393,17665,2404756,1501,318685,257,2114913,2139332,63189]

theorem envBound38390 : H12AffineFastState.Bounded env38390 := by
  intro p hp
  have h : env38390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38389_38390 : H12AffineEnvironment.transform 15 54495 env38389 = env38390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env38389 == env38390) = true)

theorem identity38390 : scanCanonicalize (H12AffineFastState.compose env38390 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound38390 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25029,262144,1025,29909,2097152,272513,2101328,2114883,8328,64,2185,5393,17665,2377024,1501,272393,257,2114913,2117648,513]

theorem envBound38391 : H12AffineFastState.Bounded env38391 := by
  intro p hp
  have h : env38391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38390_38391 : H12AffineEnvironment.transform 14 29908 env38390 = env38391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env38390 == env38391) = true)

theorem identity38391 : scanCanonicalize (H12AffineFastState.compose env38391 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound38391 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env38392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25029,262144,1025,29909,25629,272513,29773,8542,8328,64,2185,5393,17665,270685,1501,272393,257,8572,13325,513]

theorem envBound38392 : H12AffineFastState.Bounded env38392 := by
  intro p hp
  have h : env38392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38391_38392 : H12AffineEnvironment.transform 20 25629 env38391 = env38392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env38391 == env38392) = true)

theorem identity38392 : scanCanonicalize (H12AffineFastState.compose env38392 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound38392 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env38393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25029,10400,1025,29909,25629,33,29773,8542,8328,64,2185,5393,17665,2557,1501,169,257,8572,13325,513]

theorem envBound38393 : H12AffineFastState.Bounded env38393 := by
  intro p hp
  have h : env38393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38392_38393 : H12AffineEnvironment.transform 17 10400 env38392 = env38393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env38392 == env38393) = true)

theorem identity38393 : scanCanonicalize (H12AffineFastState.compose env38393 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound38393 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env38394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,2129,15493,8203,10644,10400,1025,15492,11340,33,15388,8542,8328,64,2185,5393,3408,2557,1501,169,257,8572,13325,513]

theorem envBound38394 : H12AffineFastState.Bounded env38394 := by
  intro p hp
  have h : env38394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38393_38394 : H12AffineEnvironment.transform 13 2129 env38393 = env38394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env38393 == env38394) = true)

theorem identity38394 : scanCanonicalize (H12AffineFastState.compose env38394 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 6548) := by decide +kernel

theorem selectedBound38394 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env38395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6548,2129,1297,6559,4096,4404,1025,1296,5592,33,1416,6346,6428,64,2185,5393,3408,2557,1501,169,257,6376,3481,513]

theorem envBound38395 : H12AffineFastState.Bounded env38395 := by
  intro p hp
  have h : env38395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38394_38395 : H12AffineEnvironment.transform 12 6548 env38394 = env38395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6548 env38394 == env38395) = true)

theorem identity38395 : scanCanonicalize (H12AffineFastState.compose env38395 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 3545) := by decide +kernel

theorem selectedBound38395 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env38396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3545,1101,2129,1297,1094,3545,3309,1025,1296,2049,33,1416,1299,1221,64,2185,2248,3408,2557,1501,169,257,1329,3481,513]

theorem envBound38396 : H12AffineFastState.Bounded env38396 := by
  intro p hp
  have h : env38396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38395_38396 : H12AffineEnvironment.transform 11 3545 env38395 = env38396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3545 env38395 == env38396) = true)

theorem identity38396 : scanCanonicalize (H12AffineFastState.compose env38396 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound38396 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38397 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,2341,177,2129,493,186,2341,2065,253,492,2049,33,372,495,57,64,2185,2248,2476,2557,289,169,257,461,2405,513]

theorem envBound38397 : H12AffineFastState.Bounded env38397 := by
  intro p hp
  have h : env38397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38396_38397 : H12AffineEnvironment.transform 9 252 env38396 = env38397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env38396 == env38397) = true)

theorem identity38397 : scanCanonicalize (H12AffineFastState.compose env38397 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound38397 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38398 : List Nat := [2,4,8,16,32,64,128,237,512,252,2048,2248,177,2129,0,186,2248,2065,253,1,2049,33,153,2,57,64,2185,2248,2113,2064,204,169,236,32,2184,513]

theorem envBound38398 : H12AffineFastState.Bounded env38398 := by
  intro p hp
  have h : env38398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38397_38398 : H12AffineEnvironment.transform 7 237 env38397 = env38398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env38397 == env38398) = true)

theorem identity38398 : scanCanonicalize (H12AffineFastState.compose env38398 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38398 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38399 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,2112,57,2129,0,50,2112,2065,117,1,2049,33,17,2,57,64,2049,2112,2113,2064,68,33,100,32,2048,513]

theorem envBound38399 : H12AffineFastState.Bounded env38399 := by
  intro p hp
  have h : env38399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38398_38399 : H12AffineEnvironment.transform 6 8 env38398 = env38399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38398 == env38399) = true)

theorem identity38399 : scanCanonicalize (H12AffineFastState.compose env38399 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound38399 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38400 : List Nat := [2,4,8,16,32,64,8,101,512,116,90,26,57,11,0,50,26,75,117,1,91,33,17,2,57,64,91,26,27,74,68,33,100,32,90,513]

theorem envBound38400 : H12AffineFastState.Bounded env38400 := by
  intro p hp
  have h : env38400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38399_38400 : H12AffineEnvironment.transform 10 90 env38399 = env38400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env38399 == env38400) = true)

theorem identity38400 : scanCanonicalize (H12AffineFastState.compose env38400 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound38400 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env38401 : List Nat := [2,4,8,16,32,64,8,101,24,116,90,26,57,11,0,50,26,75,117,1,91,33,17,2,57,64,91,26,27,74,68,33,100,32,90,25]

theorem envBound38401 : H12AffineFastState.Bounded env38401 := by
  intro p hp
  have h : env38401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38400_38401 : H12AffineEnvironment.transform 8 24 env38400 = env38401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env38400 == env38401) = true)

theorem identity38401 : scanCanonicalize (H12AffineFastState.compose env38401 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38401 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38402 : List Nat := [2,4,8,10,32,64,8,101,2,110,64,0,35,11,0,40,0,75,111,1,65,33,11,2,35,64,65,0,1,74,68,33,100,32,64,3]

theorem envBound38402 : H12AffineFastState.Bounded env38402 := by
  intro p hp
  have h : env38402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38401_38402 : H12AffineEnvironment.transform 3 10 env38401 = env38402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38401 == env38402) = true)

theorem identity38402 : scanCanonicalize (H12AffineFastState.compose env38402 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38402 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38403 : List Nat := [2,4,8,10,11,64,8,78,2,69,64,0,8,11,0,3,0,75,68,1,65,10,11,2,8,64,65,0,1,74,68,10,79,11,64,3]

theorem envBound38403 : H12AffineFastState.Bounded env38403 := by
  intro p hp
  have h : env38403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38402_38403 : H12AffineEnvironment.transform 4 11 env38402 = env38403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38402 == env38403) = true)

theorem identity38403 : scanCanonicalize (H12AffineFastState.compose env38403 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38403 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env38404 : List Nat := [2,4,3,1,0,64,3,69,2,69,64,0,3,0,0,3,0,64,68,1,65,1,0,2,3,64,65,0,1,65,68,1,68,0,64,3]

theorem envBound38404 : H12AffineFastState.Bounded env38404 := by
  intro p hp
  have h : env38404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38403_38404 : H12AffineEnvironment.transform 2 3 env38403 = env38404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38403 == env38404) = true)

theorem identity38404 : scanCanonicalize (H12AffineFastState.compose env38404 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38405 : List Nat := [2,2,3,1,0,64,3,67,2,67,64,0,3,0,0,3,0,64,66,1,65,1,0,2,3,64,65,0,1,65,66,1,66,0,64,3]

theorem envBound38405 : H12AffineFastState.Bounded env38405 := by
  intro p hp
  have h : env38405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38404_38405 : H12AffineEnvironment.transform 1 2 env38404 = env38405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38404 == env38405) = true)

theorem identity38405 : scanCanonicalize (H12AffineFastState.compose env38405 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38406 : List Nat := [2,2,3,1,0,0,3,3,2,3,0,0,3,0,0,3,0,0,2,1,1,1,0,2,3,0,1,0,1,1,2,1,2,0,0,3]

theorem envBound38406 : H12AffineFastState.Bounded env38406 := by
  intro p hp
  have h : env38406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38405_38406 : H12AffineEnvironment.transform 5 0 env38405 = env38406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38405 == env38406) = true)

def env38407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4584662,115150,17664,2404757,119043,4268163,257,2199999,2191386,63188]

theorem envBound38407 : H12AffineFastState.Bounded env38407 := by
  intro p hp
  have h : env38407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38363_38407 : H12AffineEnvironment.transform 22 2101329 env38363 = env38407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env38363 == env38407) = true)

def env38408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,121942,115150,17664,2404757,119043,329731,257,2199999,2191386,63188]

theorem envBound38408 : H12AffineFastState.Bounded env38408 := by
  intro p hp
  have h : env38408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38407_38408 : H12AffineEnvironment.transform 21 272512 env38407 = env38408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38407 == env38408) = true)

theorem identity38408 : scanCanonicalize (H12AffineFastState.compose env38408 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound38408 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,77899,272512,73754,95496,8328,64,121942,115150,17664,360926,119043,329731,257,41460,16465,63188]

theorem envBound38409 : H12AffineFastState.Bounded env38409 := by
  intro p hp
  have h : env38409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38408_38409 : H12AffineEnvironment.transform 20 77899 env38408 = env38409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env38408 == env38409) = true)

def env38410 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,77851,272512,73754,95496,8328,16,121862,115102,17664,360846,119043,329731,257,41380,16385,63108]

theorem envBound38410 : H12AffineFastState.Bounded env38410 := by
  intro p hp
  have h : env38410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38409_38410 : H12AffineEnvironment.transform 5 16 env38409 = env38410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38409 == env38410) = true)

theorem identity38410 : scanCanonicalize (H12AffineFastState.compose env38410 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound38410 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env38411 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,23725,1025,32769,77851,29741,73754,95496,8328,16,121862,115102,17664,122147,119043,87214,257,41380,16385,63108]

theorem envBound38411 : H12AffineFastState.Bounded env38411 := by
  intro p hp
  have h : env38411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38410_38411 : H12AffineEnvironment.transform 17 23725 env38410 = env38411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env38410 == env38411) = true)

theorem identity38411 : scanCanonicalize (H12AffineFastState.compose env38411 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound38411 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env38412 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,21646,24981,23725,1025,32769,25749,29741,29844,8582,8328,16,34952,38160,17664,35245,34189,32,257,41380,16385,63108]

theorem envBound38412 : H12AffineFastState.Bounded env38412 := by
  intro p hp
  have h : env38412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38411_38412 : H12AffineEnvironment.transform 15 21646 env38411 = env38412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env38411 == env38412) = true)

theorem identity38412 : scanCanonicalize (H12AffineFastState.compose env38412 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound38412 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env38413 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,8322,5529,10401,1025,32769,4249,33,152,8582,8328,16,34952,38160,12556,35245,34189,32,257,41380,13325,33416]

theorem envBound38413 : H12AffineFastState.Bounded env38413 := by
  intro p hp
  have h : env38413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38412_38413 : H12AffineEnvironment.transform 13 13324 env38412 = env38413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env38412 == env38413) = true)

theorem identity38413 : scanCanonicalize (H12AffineFastState.compose env38413 (packedSelected [4,7,9,17,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38413 : packedSelected [4,7,9,17,27] rootPS < 2^1333 := by decide +kernel

def env38414 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,32768,398,5529,2477,1025,32769,4249,33,152,138,388,16,34952,38160,4096,35245,34189,32,257,32936,5377,33416]

theorem envBound38414 : H12AffineFastState.Bounded env38414 := by
  intro p hp
  have h : env38414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38413_38414 : H12AffineEnvironment.transform 12 268 env38413 = env38414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38413 == env38414) = true)

theorem identity38414 : scanCanonicalize (H12AffineFastState.compose env38414 (packedSelected [1,4,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound38414 : packedSelected [1,4,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env38415 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,268,4248,32768,398,4097,2477,409,32769,4249,33,152,138,388,16,34952,37000,4096,35245,32789,32,257,32936,4249,33416]

theorem envBound38415 : H12AffineFastState.Bounded env38415 := by
  intro p hp
  have h : env38415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38414_38415 : H12AffineEnvironment.transform 9 408 env38414 = env38415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env38414 == env38415) = true)

theorem identity38415 : scanCanonicalize (H12AffineFastState.compose env38415 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound38415 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38416 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,268,4248,137,398,4097,2477,409,136,4249,33,152,138,388,16,2049,4097,4096,2340,156,32,257,33,4249,513]

theorem envBound38416 : H12AffineFastState.Bounded env38416 := by
  intro p hp
  have h : env38416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38415_38416 : H12AffineEnvironment.transform 14 137 env38415 = env38416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env38415 == env38416) = true)

theorem identity38416 : scanCanonicalize (H12AffineFastState.compose env38416 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound38416 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env38417 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,2493,268,2341,137,398,2492,2477,409,136,2340,33,152,138,388,16,2049,2492,2493,2340,156,32,257,33,2340,513]

theorem envBound38417 : H12AffineFastState.Bounded env38417 := by
  intro p hp
  have h : env38417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38416_38417 : H12AffineEnvironment.transform 11 2493 env38416 = env38417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env38416 == env38417) = true)

theorem identity38417 : scanCanonicalize (H12AffineFastState.compose env38417 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38417 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env38418 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2357,268,2341,1,262,2356,2341,273,0,2340,33,16,2,268,16,2049,2356,2357,2340,20,32,257,33,2340,513]

theorem envBound38418 : H12AffineFastState.Bounded env38418 := by
  intro p hp
  have h : env38418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38417_38418 : H12AffineEnvironment.transform 6 8 env38417 = env38418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38417 == env38418) = true)

def env38419 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,77850,272512,73754,95496,8328,17,121863,115103,17664,360847,119043,329731,257,41381,16384,63109]

theorem envBound38419 : H12AffineFastState.Bounded env38419 := by
  intro p hp
  have h : env38419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38409_38419 : H12AffineEnvironment.transform 5 17 env38409 = env38419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38409 == env38419) = true)

theorem identity38419 : scanCanonicalize (H12AffineFastState.compose env38419 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 122282) := by decide +kernel

theorem selectedBound38419 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env38420 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,122282,1025,32769,77850,128298,73754,95496,8328,17,121863,115103,17664,23589,119043,54697,257,41381,16384,63109]

theorem envBound38420 : H12AffineFastState.Bounded env38420 := by
  intro p hp
  have h : env38420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38419_38420 : H12AffineEnvironment.transform 17 122282 env38419 = env38420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122282 env38419 == env38420) = true)

theorem identity38420 : scanCanonicalize (H12AffineFastState.compose env38420 (packedSelected [0,1,3,9,16,18,19,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound38420 : packedSelected [0,1,3,9,16,18,19,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38421 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,65536,16401,122282,1025,32769,70047,119983,65951,87181,269,17,121863,115103,17664,23589,119043,54697,257,32800,16384,55040]

theorem envBound38421 : H12AffineFastState.Bounded env38421 := by
  intro p hp
  have h : env38421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38420_38421 : H12AffineEnvironment.transform 12 389 env38420 = env38421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env38420 == env38421) = true)

theorem identity38421 : scanCanonicalize (H12AffineFastState.compose env38421 (packedSelected [17,18,19,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound38421 : packedSelected [17,18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env38422 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,33167,16401,23589,1025,32769,36880,21792,32784,54530,269,17,23944,16400,17664,23589,20620,54697,257,32800,16384,55040]

theorem envBound38422 : H12AffineFastState.Bounded env38422 := by
  intro p hp
  have h : env38422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38421_38422 : H12AffineEnvironment.transform 15 33167 env38421 = env38422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env38421 == env38422) = true)

theorem identity38422 : scanCanonicalize (H12AffineFastState.compose env38422 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38422 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env38423 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,32768,33167,5392,2340,1025,32769,36880,33,32784,32771,269,17,2185,5393,4097,2340,1421,32936,257,32800,5377,33281]

theorem envBound38423 : H12AffineFastState.Bounded env38423 := by
  intro p hp
  have h : env38423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38422_38423 : H12AffineEnvironment.transform 13 5377 env38422 = env38423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38422 == env38423) = true)

theorem identity38423 : scanCanonicalize (H12AffineFastState.compose env38423 (packedSelected [1,5,10,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound38423 : packedSelected [1,5,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env38424 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,40,5292,32768,32802,5309,2185,1025,32769,36880,33,32784,32771,160,17,2185,5308,4097,2185,1056,32936,172,32800,5292,33281]

theorem envBound38424 : H12AffineFastState.Bounded env38424 := by
  intro p hp
  have h : env38424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38423_38424 : H12AffineEnvironment.transform 7 173 env38423 = env38424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38423 == env38424) = true)

theorem identity38424 : scanCanonicalize (H12AffineFastState.compose env38424 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38424 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env38425 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,32768,32802,5172,2048,1025,32769,36880,33,32784,32771,41,17,2048,5173,4097,2048,1056,32801,37,32800,5157,33281]

theorem envBound38425 : H12AffineFastState.Bounded env38425 := by
  intro p hp
  have h : env38425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38424_38425 : H12AffineEnvironment.transform 6 9 env38424 = env38425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38424 == env38425) = true)

theorem identity38425 : scanCanonicalize (H12AffineFastState.compose env38425 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38425 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38426 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5172,2048,1025,1,4112,33,16,3,41,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound38426 : H12AffineFastState.Bounded env38426 := by
  intro p hp
  have h : env38426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38425_38426 : H12AffineEnvironment.transform 14 0 env38425 = env38426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38425 == env38426) = true)

def env38427 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,0,34,1028,2048,1025,1,32,33,16,3,41,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound38427 : H12AffineFastState.Bounded env38427 := by
  intro p hp
  have h : env38427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38426_38427 : H12AffineEnvironment.transform 11 48 env38426 = env38427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38426 == env38427) = true)

theorem identity38427 : scanCanonicalize (H12AffineFastState.compose env38427 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound38427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38428 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,48,40,1045,0,34,1028,1573,1025,1,32,33,16,3,41,17,1573,1029,49,1573,1056,33,37,32,1045,513]

theorem envBound38428 : H12AffineFastState.Bounded env38428 := by
  intro p hp
  have h : env38428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38427_38428 : H12AffineEnvironment.transform 10 1573 env38427 = env38428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env38427 == env38428) = true)

def env38429 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,40,33,0,34,48,529,53,1,32,33,16,3,41,17,529,49,49,529,20,33,37,32,33,513]

theorem envBound38429 : H12AffineFastState.Bounded env38429 := by
  intro p hp
  have h : env38429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38428_38429 : H12AffineEnvironment.transform 9 52 env38428 = env38429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38428 == env38429) = true)

theorem identity38429 : scanCanonicalize (H12AffineFastState.compose env38429 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound38429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38430 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,48,40,33,0,34,48,59,53,1,32,33,16,3,41,17,59,49,49,59,20,33,37,32,33,43]

theorem envBound38430 : H12AffineFastState.Bounded env38430 := by
  intro p hp
  have h : env38430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38429_38430 : H12AffineEnvironment.transform 8 42 env38429 = env38430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env38429 == env38430) = true)

def leafEnv38430 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,48,40,33,0,34,48,59,53,1,32,33,16,3,21,41,1,17,59,49,49,59,20,33,37,32,5,35,33,43,1,32,0]

def active38430 : List Nat := [0,1,2,3,4]

def tree38430 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38430 : H12WitnessSearch.Good tree38430 := H12GlobalWitnessIndex.good

theorem leafIdentity38430 : H12AffineFastState.composeSystem env38430 rootObs = leafEnv38430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38430 rootObs == leafEnv38430) = true)

theorem terminalChecked38430 : H12PackedTerminal.terminalCheckFast leafEnv38430 active38430 tree38430 = true := by decide +kernel

def env38431 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,32,0,34,49,528,52,1,32,33,16,3,41,17,528,48,49,528,21,33,37,32,32,513]

theorem envBound38431 : H12AffineFastState.Bounded env38431 := by
  intro p hp
  have h : env38431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38428_38431 : H12AffineEnvironment.transform 9 53 env38428 = env38431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38428 == env38431) = true)

def env38432 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,0,34,1029,2048,1025,1,33,33,16,3,41,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound38432 : H12AffineFastState.Bounded env38432 := by
  intro p hp
  have h : env38432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38426_38432 : H12AffineEnvironment.transform 11 49 env38426 = env38432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38426 == env38432) = true)

theorem identity38432 : scanCanonicalize (H12AffineFastState.compose env38432 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound38432 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38433 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,49,40,1044,0,34,1029,529,1025,1,33,33,16,3,41,17,529,1028,48,529,1056,33,37,32,1044,513]

theorem envBound38433 : H12AffineFastState.Bounded env38433 := by
  intro p hp
  have h : env38433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38432_38433 : H12AffineEnvironment.transform 10 529 env38432 = env38433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env38432 == env38433) = true)

def env38434 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,32,0,34,49,529,53,1,33,33,16,3,41,17,529,48,48,529,20,33,37,32,32,513]

theorem envBound38434 : H12AffineFastState.Bounded env38434 := by
  intro p hp
  have h : env38434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38433_38434 : H12AffineEnvironment.transform 9 52 env38433 = env38434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38433 == env38434) = true)

theorem identity38434 : scanCanonicalize (H12AffineFastState.compose env38434 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38434 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38435 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,49,40,32,0,34,49,58,53,1,33,33,16,3,41,17,58,48,48,58,20,33,37,32,32,42]

theorem envBound38435 : H12AffineFastState.Bounded env38435 := by
  intro p hp
  have h : env38435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38434_38435 : H12AffineEnvironment.transform 8 43 env38434 = env38435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38434 == env38435) = true)

def leafEnv38435 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,49,40,32,0,34,49,58,53,1,33,33,16,3,21,41,1,17,58,48,48,58,20,33,37,32,5,35,32,42,1,33,0]

def active38435 : List Nat := [0,1,2,3,4]

def tree38435 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38435 : H12WitnessSearch.Good tree38435 := H12GlobalWitnessIndex.good

theorem leafIdentity38435 : H12AffineFastState.composeSystem env38435 rootObs = leafEnv38435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38435 rootObs == leafEnv38435) = true)

theorem terminalChecked38435 : H12PackedTerminal.terminalCheckFast leafEnv38435 active38435 tree38435 = true := by decide +kernel

def env38436 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,40,33,0,34,48,529,52,1,33,33,16,3,41,17,529,49,48,529,21,33,37,32,33,513]

theorem envBound38436 : H12AffineFastState.Bounded env38436 := by
  intro p hp
  have h : env38436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38433_38436 : H12AffineEnvironment.transform 9 53 env38433 = env38436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38433 == env38436) = true)

def env38437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,121943,115150,17664,2404757,119043,329730,257,2199999,2191386,63188]

theorem envBound38437 : H12AffineFastState.Bounded env38437 := by
  intro p hp
  have h : env38437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38407_38437 : H12AffineEnvironment.transform 21 272513 env38407 = env38437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38407 == env38437) = true)

theorem identity38437 : scanCanonicalize (H12AffineFastState.compose env38437 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38437 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,64604,57797,17664,2404757,61704,272393,257,2142644,2117649,63188]

theorem envBound38438 : H12AffineFastState.Bounded env38438 := by
  intro p hp
  have h : env38438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38437_38438 : H12AffineEnvironment.transform 15 8203 env38437 = env38438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38437 == env38438) = true)

def env38439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,2097152,272393,2101329,2114883,8192,64,64604,57677,17664,2404637,61704,272393,257,2142524,2117649,63068]

theorem envBound38439 : H12AffineFastState.Bounded env38439 := by
  intro p hp
  have h : env38439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38438_38439 : H12AffineEnvironment.transform 6 8 env38438 = env38439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38438 == env38439) = true)

theorem identity38439 : scanCanonicalize (H12AffineFastState.compose env38439 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound38439 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env38440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,12392,272393,8249,29995,8192,64,64604,57677,17664,295285,61704,272393,257,33108,24697,63068]

theorem envBound38440 : H12AffineFastState.Bounded env38440 := by
  intro p hp
  have h : env38440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38439_38440 : H12AffineEnvironment.transform 20 12392 env38439 = env38440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env38439 == env38440) = true)

theorem identity38440 : scanCanonicalize (H12AffineFastState.compose env38440 (packedSelected [0,1,2,4,11,17,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38440 : packedSelected [0,1,2,4,11,17,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,32768,34,16740,262144,1025,32769,4161,264224,16,21762,41,64,56437,49508,17664,295285,53537,264224,257,33108,16464,54901]

theorem envBound38441 : H12AffineFastState.Bounded env38441 := by
  intro p hp
  have h : env38441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38440_38441 : H12AffineEnvironment.transform 12 41 env38440 = env38441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38440 == env38441) = true)

theorem identity38441 : scanCanonicalize (H12AffineFastState.compose env38441 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound38441 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,372,34,16740,262144,1025,373,4161,264224,16,21762,41,64,23809,16400,17664,262145,20565,264224,257,32,16464,22273]

theorem envBound38442 : H12AffineFastState.Bounded env38442 := by
  intro p hp
  have h : env38442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38441_38442 : H12AffineEnvironment.transform 14 372 env38441 = env38442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env38441 == env38442) = true)

theorem identity38442 : scanCanonicalize (H12AffineFastState.compose env38442 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound38442 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,372,34,5393,262144,1025,373,4161,264224,16,375,41,64,2420,5221,4469,262145,1056,264224,257,32,5157,884]

theorem envBound38443 : H12AffineFastState.Bounded env38443 := by
  intro p hp
  have h : env38443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38442_38443 : H12AffineEnvironment.transform 13 5237 env38442 = env38443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env38442 == env38443) = true)

theorem identity38443 : scanCanonicalize (H12AffineFastState.compose env38443 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound38443 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env38444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,372,34,5393,2048,1025,373,4161,32,16,375,41,64,2420,5221,4469,2049,1056,32,257,32,5157,884]

theorem envBound38444 : H12AffineFastState.Bounded env38444 := by
  intro p hp
  have h : env38444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38443_38444 : H12AffineEnvironment.transform 17 2048 env38443 = env38444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env38443 == env38444) = true)

theorem identity38444 : scanCanonicalize (H12AffineFastState.compose env38444 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 382) := by decide +kernel

theorem selectedBound38444 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env38445 : List Nat := [2,4,8,16,32,64,8,256,382,1024,2048,4096,41,5237,372,34,5393,2048,1025,373,4161,32,16,375,41,64,2420,5221,4469,2049,1056,32,257,32,5157,10]

theorem envBound38445 : H12AffineFastState.Bounded env38445 := by
  intro p hp
  have h : env38445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38444_38445 : H12AffineEnvironment.transform 8 382 env38444 = env38445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 382 env38444 == env38445) = true)

theorem identity38445 : scanCanonicalize (H12AffineFastState.compose env38445 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38445 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38446 : List Nat := [2,4,8,16,32,64,8,256,382,272,2048,4096,41,4453,372,34,4097,2048,273,373,4161,32,16,375,41,64,2420,4469,4469,2049,304,32,257,32,4405,10]

theorem envBound38446 : H12AffineFastState.Bounded env38446 := by
  intro p hp
  have h : env38446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38445_38446 : H12AffineEnvironment.transform 9 272 env38445 = env38446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38445 == env38446) = true)

theorem identity38446 : scanCanonicalize (H12AffineFastState.compose env38446 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38446 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env38447 : List Nat := [2,4,8,16,32,64,8,36,90,52,2048,4096,41,4161,80,34,4097,2048,53,81,4161,32,16,83,41,64,2128,4177,4177,2049,20,32,37,32,4113,10]

theorem envBound38447 : H12AffineFastState.Bounded env38447 := by
  intro p hp
  have h : env38447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38446_38447 : H12AffineEnvironment.transform 7 36 env38446 = env38447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38446 == env38447) = true)

theorem identity38447 : scanCanonicalize (H12AffineFastState.compose env38447 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound38447 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38448 : List Nat := [2,4,8,16,32,64,8,36,90,52,2048,2064,41,2129,80,34,2065,2048,53,81,2129,32,16,83,41,64,2128,2113,2113,2049,20,32,37,32,2049,10]

theorem envBound38448 : H12AffineFastState.Bounded env38448 := by
  intro p hp
  have h : env38448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38447_38448 : H12AffineEnvironment.transform 11 2064 env38447 = env38448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env38447 == env38448) = true)

theorem identity38448 : scanCanonicalize (H12AffineFastState.compose env38448 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38448 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38449 : List Nat := [2,4,8,16,1,64,8,5,90,21,2048,2064,8,2129,80,3,2065,2048,20,81,2129,1,16,83,8,64,2128,2113,2113,2049,20,1,4,1,2049,10]

theorem envBound38449 : H12AffineFastState.Bounded env38449 := by
  intro p hp
  have h : env38449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38448_38449 : H12AffineEnvironment.transform 4 1 env38448 = env38449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38448 == env38449) = true)

theorem identity38449 : scanCanonicalize (H12AffineFastState.compose env38449 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound38449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38450 : List Nat := [2,4,8,16,1,64,8,5,90,21,81,65,8,0,80,3,64,81,20,81,0,1,16,83,8,64,1,16,16,80,20,1,4,1,80,10]

theorem envBound38450 : H12AffineFastState.Bounded env38450 := by
  intro p hp
  have h : env38450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38449_38450 : H12AffineEnvironment.transform 10 81 env38449 = env38450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env38449 == env38450) = true)

def env38451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,262144,1025,32769,2097152,272392,2101329,2114883,8193,64,64604,57676,17664,2404636,61704,272393,257,2142525,2117649,63069]

theorem envBound38451 : H12AffineFastState.Bounded env38451 := by
  intro p hp
  have h : env38451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38438_38451 : H12AffineEnvironment.transform 6 9 env38438 = env38451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38438 == env38451) = true)

theorem identity38451 : scanCanonicalize (H12AffineFastState.compose env38451 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound38451 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env38452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10281,1025,32769,2097152,33,2101329,2114883,8193,64,64604,57676,17664,2136373,61704,32,257,2142525,2117649,63069]

theorem envBound38452 : H12AffineFastState.Bounded env38452 := by
  intro p hp
  have h : env38452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38451_38452 : H12AffineEnvironment.transform 17 10281 env38451 = env38452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38451 == env38452) = true)

theorem identity38452 : scanCanonicalize (H12AffineFastState.compose env38452 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound38452 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10281,1025,32769,4161,33,16,21762,8193,64,64604,57676,17664,35188,61704,32,257,41340,16464,63069]

theorem envBound38453 : H12AffineFastState.Bounded env38453 := by
  intro p hp
  have h : env38453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38452_38453 : H12AffineEnvironment.transform 20 4161 env38452 = env38453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38452 == env38453) = true)

theorem identity38453 : scanCanonicalize (H12AffineFastState.compose env38453 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound38453 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env38454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1296,8203,24908,10281,1025,1297,4161,33,16,21762,8193,64,31052,25692,17664,3172,29720,32,257,9324,16464,29517]

theorem envBound38454 : H12AffineFastState.Bounded env38454 := by
  intro p hp
  have h : env38454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38453_38454 : H12AffineEnvironment.transform 14 1296 env38453 = env38454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env38453 == env38454) = true)

theorem identity38454 : scanCanonicalize (H12AffineFastState.compose env38454 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound38454 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env38455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1296,115,16692,2129,1025,1297,4161,33,16,21762,121,64,22836,17444,17664,3172,21600,32,257,1044,16464,21301]

theorem envBound38455 : H12AffineFastState.Bounded env38455 := by
  intro p hp
  have h : env38455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38454_38455 : H12AffineEnvironment.transform 12 120 env38454 = env38455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env38454 == env38455) = true)

theorem identity38455 : scanCanonicalize (H12AffineFastState.compose env38455 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound38455 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,1296,115,5441,2129,1025,1297,4161,33,16,375,121,64,3393,4177,4469,3172,21,32,257,1044,5157,1856]

theorem envBound38456 : H12AffineFastState.Bounded env38456 := by
  intro p hp
  have h : env38456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38455_38456 : H12AffineEnvironment.transform 13 5237 env38455 = env38456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env38455 == env38456) = true)

theorem identity38456 : scanCanonicalize (H12AffineFastState.compose env38456 (packedSelected [0,2,9,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound38456 : packedSelected [0,2,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env38457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,120,3124,1296,115,3328,2129,1025,1297,2048,33,16,375,121,64,3393,2064,2356,3172,21,32,257,1044,3172,1856]

theorem envBound38457 : H12AffineFastState.Bounded env38457 := by
  intro p hp
  have h : env38457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38456_38457 : H12AffineEnvironment.transform 11 2113 env38456 = env38457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env38456 == env38457) = true)

theorem identity38457 : scanCanonicalize (H12AffineFastState.compose env38457 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound38457 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env38458 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,120,2128,372,115,2404,2129,101,373,2048,33,16,375,121,64,2341,2064,2356,2048,21,32,257,112,2048,804]

theorem envBound38458 : H12AffineFastState.Bounded env38458 := by
  intro p hp
  have h : env38458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38457_38458 : H12AffineEnvironment.transform 9 100 env38457 = env38458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env38457 == env38458) = true)

theorem identity38458 : scanCanonicalize (H12AffineFastState.compose env38458 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 383) := by decide +kernel

theorem selectedBound38458 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38459 : List Nat := [2,4,8,16,32,64,9,256,383,100,2048,2113,120,2128,372,115,2404,2129,101,373,2048,33,16,375,121,64,2341,2064,2356,2048,21,32,257,112,2048,91]

theorem envBound38459 : H12AffineFastState.Bounded env38459 := by
  intro p hp
  have h : env38459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38458_38459 : H12AffineEnvironment.transform 8 383 env38458 = env38459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 383 env38458 == env38459) = true)

theorem identity38459 : scanCanonicalize (H12AffineFastState.compose env38459 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound38459 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env38460 : List Nat := [2,4,8,16,32,64,9,256,383,100,80,17,120,0,372,115,308,1,101,373,80,33,16,375,121,64,373,64,356,80,21,32,257,112,80,91]

theorem envBound38460 : H12AffineFastState.Bounded env38460 := by
  intro p hp
  have h : env38460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38459_38460 : H12AffineEnvironment.transform 10 80 env38459 = env38460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env38459 == env38460) = true)

theorem identity38460 : scanCanonicalize (H12AffineFastState.compose env38460 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound38460 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38461 : List Nat := [2,4,8,16,32,49,9,256,270,21,33,17,9,0,261,2,308,1,20,260,33,33,16,262,8,49,260,49,277,33,21,32,257,1,33,42]

theorem envBound38461 : H12AffineFastState.Bounded env38461 := by
  intro p hp
  have h : env38461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38460_38461 : H12AffineEnvironment.transform 5 49 env38460 = env38461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env38460 == env38461) = true)

theorem identity38461 : scanCanonicalize (H12AffineFastState.compose env38461 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38461 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38462 : List Nat := [2,4,8,16,32,49,9,36,42,21,33,17,9,0,33,2,16,1,20,32,33,33,16,34,8,49,32,49,49,33,21,32,37,1,33,42]

theorem envBound38462 : H12AffineFastState.Bounded env38462 := by
  intro p hp
  have h : env38462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38461_38462 : H12AffineEnvironment.transform 7 36 env38461 = env38462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38461 == env38462) = true)

theorem identity38462 : scanCanonicalize (H12AffineFastState.compose env38462 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38463 : List Nat := [2,4,4,16,32,49,5,36,38,21,33,17,5,0,33,2,16,1,20,32,33,33,16,34,4,49,32,49,49,33,21,32,37,1,33,38]

theorem envBound38463 : H12AffineFastState.Bounded env38463 := by
  intro p hp
  have h : env38463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38462_38463 : H12AffineEnvironment.transform 2 4 env38462 = env38463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38462 == env38463) = true)

theorem identity38463 : scanCanonicalize (H12AffineFastState.compose env38463 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38463 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38464 : List Nat := [2,4,4,16,0,17,5,4,6,21,1,17,5,0,1,2,16,1,20,0,1,1,16,2,4,17,0,17,17,1,21,0,5,1,1,6]

theorem envBound38464 : H12AffineFastState.Bounded env38464 := by
  intro p hp
  have h : env38464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38463_38464 : H12AffineEnvironment.transform 4 0 env38463 = env38464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38463 == env38464) = true)

theorem identity38464 : scanCanonicalize (H12AffineFastState.compose env38464 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound38464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38465 : List Nat := [2,4,4,5,0,4,5,4,6,0,1,4,5,0,1,2,5,1,1,0,1,1,5,2,4,4,0,4,4,1,0,0,5,1,1,6]

theorem envBound38465 : H12AffineFastState.Bounded env38465 := by
  intro p hp
  have h : env38465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38464_38465 : H12AffineEnvironment.transform 3 5 env38464 = env38465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env38464 == env38465) = true)

def env38466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound38466 : H12AffineFastState.Bounded env38466 := by
  intro p hp
  have h : env38466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38095_38466 : H12AffineEnvironment.transform 26 30393345 env38095 = env38466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env38095 == env38466) = true)

def env38467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound38467 : H12AffineFastState.Bounded env38467 := by
  intro p hp
  have h : env38467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38466_38467 : H12AffineEnvironment.transform 18 1024 env38466 = env38467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env38466 == env38467) = true)

theorem identity38467 : scanCanonicalize (H12AffineFastState.compose env38467 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8430022) := by decide +kernel

theorem selectedBound38467 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8430022,8328,64,4678087,10560842,10507601,8830977,75223,14795783,256,2188651,2196686,513]

theorem envBound38468 : H12AffineFastState.Bounded env38468 := by
  intro p hp
  have h : env38468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38467_38468 : H12AffineEnvironment.transform 23 8430022 env38467 = env38468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8430022 env38467 == env38468) = true)

def env38469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8192,64,4677967,10560842,10507601,8830977,75103,14795783,256,2188651,2196550,513]

theorem envBound38469 : H12AffineFastState.Bounded env38469 := by
  intro p hp
  have h : env38469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38468_38469 : H12AffineEnvironment.transform 6 8 env38468 = env38469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38468 == env38469) = true)

theorem identity38469 : scanCanonicalize (H12AffineFastState.compose env38469 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound38469 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,8388608,8429902,8192,64,4456788,10560842,10507601,8757274,75103,14795783,256,2188651,2196550,513]

theorem envBound38470 : H12AffineFastState.Bounded env38470 := by
  intro p hp
  have h : env38470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38469_38470 : H12AffineEnvironment.transform 16 90139 env38469 = env38470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env38469 == env38470) = true)

def env38471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,16,41310,8192,64,4456788,2172250,2118977,368650,75103,6407191,256,2188651,2196550,513]

theorem envBound38471 : H12AffineFastState.Bounded env38471 := by
  intro p hp
  have h : env38471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38470_38471 : H12AffineEnvironment.transform 22 16 env38470 = env38471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env38470 == env38471) = true)

theorem identity38471 : scanCanonicalize (H12AffineFastState.compose env38471 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46092) := by decide +kernel

theorem selectedBound38471 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,46092,4194304,16,41310,8192,64,4456788,102742,57677,368650,75103,4288539,256,119143,77898,513]

theorem envBound38472 : H12AffineFastState.Bounded env38472 := by
  intro p hp
  have h : env38472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38471_38472 : H12AffineEnvironment.transform 20 46092 env38471 = env38472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46092 env38471 == env38472) = true)

theorem identity38472 : scanCanonicalize (H12AffineFastState.compose env38472 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38472 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env38473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,262144,1024,8541,5456,4194304,16,2,8192,64,4456788,77834,16401,328022,75103,4288539,256,94267,77898,513]

theorem envBound38473 : H12AffineFastState.Bounded env38473 := by
  intro p hp
  have h : env38473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38472_38473 : H12AffineEnvironment.transform 14 8540 env38472 = env38473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38472 == env38473) = true)

def env38474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,262144,1024,8541,5456,4194304,16,2,8192,64,4456788,77834,4097,328022,75103,4268043,256,73771,77898,513]

theorem envBound38474 : H12AffineFastState.Bounded env38474 := by
  intro p hp
  have h : env38474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38473_38474 : H12AffineEnvironment.transform 13 4112 env38473 = env38474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env38473 == env38474) = true)

theorem identity38474 : scanCanonicalize (H12AffineFastState.compose env38474 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound38474 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env38475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,262144,1024,8541,5456,33,16,2,8192,64,262517,77834,4097,328022,75103,73770,256,73771,77898,513]

theorem envBound38475 : H12AffineFastState.Bounded env38475 := by
  intro p hp
  have h : env38475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38474_38475 : H12AffineEnvironment.transform 21 33 env38474 = env38475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env38474 == env38475) = true)

theorem identity38475 : scanCanonicalize (H12AffineFastState.compose env38475 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound38475 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env38476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,67618,1024,8541,5456,33,16,2,8192,64,67927,77834,4097,2420,75103,73770,256,73771,77898,513]

theorem envBound38476 : H12AffineFastState.Bounded env38476 := by
  intro p hp
  have h : env38476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38475_38476 : H12AffineEnvironment.transform 17 67618 env38475 = env38476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env38475 == env38476) = true)

theorem identity38476 : scanCanonicalize (H12AffineFastState.compose env38476 (packedSelected [0,4,6,7,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound38476 : packedSelected [0,4,6,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env38477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1305,4112,1093,65536,70930,67618,1024,1092,5456,33,16,2,1305,64,67927,70931,4097,2420,65606,66867,256,66866,70995,513]

theorem envBound38477 : H12AffineFastState.Bounded env38477 := by
  intro p hp
  have h : env38477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38476_38477 : H12AffineEnvironment.transform 12 1305 env38476 = env38477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env38476 == env38477) = true)

theorem identity38477 : scanCanonicalize (H12AffineFastState.compose env38477 (packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1298) := by decide +kernel

theorem selectedBound38477 : packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1305,4112,1093,1298,4096,3376,1024,1092,5456,33,16,2,1305,64,3141,4097,4097,2420,1364,33,256,32,4161,513]

theorem envBound38478 : H12AffineFastState.Bounded env38478 := by
  intro p hp
  have h : env38478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38477_38478 : H12AffineEnvironment.transform 15 1298 env38477 = env38478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1298 env38477 == env38478) = true)

def env38479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,65536,77834,262144,1024,8541,5456,4194304,16,2,8192,64,4456788,77834,4096,328022,75103,4268042,256,73770,77898,513]

theorem envBound38479 : H12AffineFastState.Bounded env38479 := by
  intro p hp
  have h : env38479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38473_38479 : H12AffineEnvironment.transform 13 4113 env38473 = env38479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env38473 == env38479) = true)

theorem identity38479 : scanCanonicalize (H12AffineFastState.compose env38479 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38479 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,4096,262144,1024,8541,5456,4194304,16,2,8192,64,4456788,4096,4096,270684,1365,4194304,256,32,4160,513]

theorem envBound38480 : H12AffineFastState.Bounded env38480 := by
  intro p hp
  have h : env38480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38479_38480 : H12AffineEnvironment.transform 15 8202 env38479 = env38480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38479 == env38480) = true)

theorem identity38480 : scanCanonicalize (H12AffineFastState.compose env38480 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound38480 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,4096,262144,1024,8541,5456,113,16,2,8192,64,262437,4096,4096,270684,1365,113,256,32,4160,513]

theorem envBound38481 : H12AffineFastState.Bounded env38481 := by
  intro p hp
  have h : env38481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38480_38481 : H12AffineEnvironment.transform 21 113 env38480 = env38481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env38480 == env38481) = true)

theorem identity38481 : scanCanonicalize (H12AffineFastState.compose env38481 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound38481 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env38482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,4096,2420,1024,8541,5456,113,16,2,8192,64,2129,4096,4096,10280,1365,113,256,32,4160,513]

theorem envBound38482 : H12AffineFastState.Bounded env38482 := by
  intro p hp
  have h : env38482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38481_38482 : H12AffineEnvironment.transform 17 2420 env38481 = env38482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env38481 == env38482) = true)

theorem identity38482 : scanCanonicalize (H12AffineFastState.compose env38482 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38482 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env38483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,4113,81,263,4096,2420,1024,80,5456,113,16,2,269,64,2129,4096,4096,2341,1365,113,256,32,4160,513]

theorem envBound38483 : H12AffineFastState.Bounded env38483 := by
  intro p hp
  have h : env38483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38482_38483 : H12AffineEnvironment.transform 12 269 env38482 = env38483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38482 == env38483) = true)

theorem identity38483 : scanCanonicalize (H12AffineFastState.compose env38483 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound38483 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38484 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,4113,81,263,4096,2420,320,80,4112,113,16,2,269,64,2129,4096,4096,2341,21,113,256,32,4160,513]

theorem envBound38484 : H12AffineFastState.Bounded env38484 := by
  intro p hp
  have h : env38484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38483_38484 : H12AffineEnvironment.transform 9 320 env38483 = env38484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env38483 == env38484) = true)

theorem identity38484 : scanCanonicalize (H12AffineFastState.compose env38484 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38484 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38485 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4113,1,263,4096,2340,272,0,4112,33,16,2,269,16,2049,4096,4096,2341,21,33,256,32,4112,513]

theorem envBound38485 : H12AffineFastState.Bounded env38485 := by
  intro p hp
  have h : env38485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38484_38485 : H12AffineEnvironment.transform 5 16 env38484 = env38485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38484 == env38485) = true)

theorem identity38485 : scanCanonicalize (H12AffineFastState.compose env38485 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound38485 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38486 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2064,269,2049,1,263,2064,2340,272,0,2048,33,16,2,269,16,2049,2064,2064,2341,21,33,256,32,2048,513]

theorem envBound38486 : H12AffineFastState.Bounded env38486 := by
  intro p hp
  have h : env38486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38485_38486 : H12AffineEnvironment.transform 11 2064 env38485 = env38486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env38485 == env38486) = true)

theorem identity38486 : scanCanonicalize (H12AffineFastState.compose env38486 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38486 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38487 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,40,2049,1,34,2064,2049,53,0,2048,33,16,2,40,16,2049,2064,2064,2048,21,33,37,32,2048,513]

theorem envBound38487 : H12AffineFastState.Bounded env38487 := by
  intro p hp
  have h : env38487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38486_38487 : H12AffineEnvironment.transform 7 37 env38486 = env38487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38486 == env38487) = true)

theorem identity38487 : scanCanonicalize (H12AffineFastState.compose env38487 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound38487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38488 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,40,48,1,34,33,48,53,0,49,33,16,2,40,16,48,33,33,49,21,33,37,32,49,513]

theorem envBound38488 : H12AffineFastState.Bounded env38488 := by
  intro p hp
  have h : env38488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38487_38488 : H12AffineEnvironment.transform 10 49 env38487 = env38488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env38487 == env38488) = true)

def leafEnv38488 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,40,48,1,34,33,48,53,0,49,33,16,2,21,40,1,16,48,33,33,49,21,33,37,32,4,34,49,513,1,48,0]

def active38488 : List Nat := [0,1,2,3,4,8]

def tree38488 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38488 : H12WitnessSearch.Good tree38488 := H12GlobalWitnessIndex.good

theorem leafIdentity38488 : H12AffineFastState.composeSystem env38488 rootObs = leafEnv38488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38488 rootObs == leafEnv38488) = true)

theorem terminalChecked38488 : H12PackedTerminal.terminalCheckFast leafEnv38488 active38488 tree38488 = true := by decide +kernel

def env38489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456788,2172251,2118976,368651,75103,6407190,256,2188651,2196550,513]

theorem envBound38489 : H12AffineFastState.Bounded env38489 := by
  intro p hp
  have h : env38489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38470_38489 : H12AffineEnvironment.transform 22 17 env38470 = env38489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env38470 == env38489) = true)

theorem identity38489 : scanCanonicalize (H12AffineFastState.compose env38489 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound38489 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90139,262144,1024,29005,2097152,4194304,17,20499,8192,64,4456788,2172251,2118976,348487,75103,6370650,256,2188651,2192650,513]

theorem envBound38490 : H12AffineFastState.Bounded env38490 := by
  intro p hp
  have h : env38490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38489_38490 : H12AffineEnvironment.transform 14 29004 env38489 = env38490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env38489 == env38490) = true)

theorem identity38490 : scanCanonicalize (H12AffineFastState.compose env38490 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound38490 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env38491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,2097152,4194304,17,20499,8192,64,4225389,2172251,2118976,76158,75103,6370650,256,2188651,2192650,513]

theorem envBound38491 : H12AffineFastState.Bounded env38491 := by
  intro p hp
  have h : env38491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38490_38491 : H12AffineEnvironment.transform 17 30777 env38490 = env38491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env38490 == env38491) = true)

def env38492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5456,4194304,17,20499,8192,64,4225389,77835,16400,76158,75103,4268042,256,94267,90202,513]

theorem envBound38492 : H12AffineFastState.Bounded env38492 := by
  intro p hp
  have h : env38492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38491_38492 : H12AffineEnvironment.transform 20 5456 env38491 = env38492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env38491 == env38492) = true)

theorem identity38492 : scanCanonicalize (H12AffineFastState.compose env38492 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound38492 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5456,20528,17,20499,8192,64,10589,77835,16400,76158,75103,94266,256,94267,90202,513]

theorem envBound38493 : H12AffineFastState.Bounded env38493 := by
  intro p hp
  have h : env38493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38492_38493 : H12AffineEnvironment.transform 21 20528 env38492 = env38493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env38492 == env38493) = true)

theorem identity38493 : scanCanonicalize (H12AffineFastState.compose env38493 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38493 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16400,30777,1024,29005,5456,20528,17,20499,8192,64,10589,4096,16400,2421,1364,20529,256,20528,16465,513]

theorem envBound38494 : H12AffineFastState.Bounded env38494 := by
  intro p hp
  have h : env38494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38493_38494 : H12AffineEnvironment.transform 15 8203 env38493 = env38494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38493 == env38494) = true)

theorem identity38494 : scanCanonicalize (H12AffineFastState.compose env38494 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound38494 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,80,8203,12556,2341,1024,81,5456,8492,17,8463,8192,64,10589,4096,12556,2421,1364,8493,256,8492,12621,513]

theorem envBound38495 : H12AffineFastState.Bounded env38495 := by
  intro p hp
  have h : env38495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38494_38495 : H12AffineEnvironment.transform 13 12572 env38494 = env38495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env38494 == env38495) = true)

theorem identity38495 : scanCanonicalize (H12AffineFastState.compose env38495 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38495 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4161,80,342,4177,2341,1024,81,5456,113,17,82,349,64,2048,4096,4177,2421,1364,112,256,113,4112,513]

theorem envBound38496 : H12AffineFastState.Bounded env38496 := by
  intro p hp
  have h : env38496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38495_38496 : H12AffineEnvironment.transform 12 349 env38495 = env38496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38495 == env38496) = true)

theorem identity38496 : scanCanonicalize (H12AffineFastState.compose env38496 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound38496 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,349,1076,80,342,1060,2341,1024,81,293,113,17,82,349,64,2048,1141,1060,2421,1364,112,256,113,1125,513]

theorem envBound38497 : H12AffineFastState.Bounded env38497 := by
  intro p hp
  have h : env38497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38496_38497 : H12AffineEnvironment.transform 11 1141 env38496 = env38497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env38496 == env38497) = true)

def env38498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5457,4194304,17,20499,8192,64,4225389,77834,16401,76158,75103,4268043,256,94266,90203,513]

theorem envBound38498 : H12AffineFastState.Bounded env38498 := by
  intro p hp
  have h : env38498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38491_38498 : H12AffineEnvironment.transform 20 5457 env38491 = env38498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env38491 == env38498) = true)

theorem identity38498 : scanCanonicalize (H12AffineFastState.compose env38498 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound38498 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1024,29005,5457,32,17,20499,8192,64,31053,77834,16401,76158,75103,73771,256,94266,90203,513]

theorem envBound38499 : H12AffineFastState.Bounded env38499 := by
  intro p hp
  have h : env38499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38498_38499 : H12AffineEnvironment.transform 21 32 env38498 = env38499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env38498 == env38499) = true)

theorem identity38499 : scanCanonicalize (H12AffineFastState.compose env38499 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound38499 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,10281,1024,8541,5457,32,17,3,8192,64,10589,77834,4097,76158,75103,73771,256,73770,77899,513]

theorem envBound38500 : H12AffineFastState.Bounded env38500 := by
  intro p hp
  have h : env38500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38499_38500 : H12AffineEnvironment.transform 13 4112 env38499 = env38500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env38499 == env38500) = true)

theorem identity38500 : scanCanonicalize (H12AffineFastState.compose env38500 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound38500 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7544,4112,7204,65536,68979,5457,1024,7205,5457,32,17,3,7544,64,5157,68978,4097,70662,71719,73043,256,73042,68915,513]

theorem envBound38501 : H12AffineFastState.Bounded env38501 := by
  intro p hp
  have h : env38501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38500_38501 : H12AffineEnvironment.transform 12 7544 env38500 = env38501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env38500 == env38501) = true)

theorem identity38501 : scanCanonicalize (H12AffineFastState.compose env38501 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound38501 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env38502 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,6429,4112,6209,65536,67862,4404,101,6208,4404,32,17,3,6429,64,4160,67863,4097,69731,71719,71990,256,71991,67926,513]

theorem envBound38502 : H12AffineFastState.Bounded env38502 := by
  intro p hp
  have h : env38502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38501_38502 : H12AffineEnvironment.transform 9 101 env38501 = env38502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env38501 == env38502) = true)

def env38503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8193,64,4677966,10560842,10507601,8830977,75102,14795783,256,2188651,2196551,513]

theorem envBound38503 : H12AffineFastState.Bounded env38503 := by
  intro p hp
  have h : env38503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38468_38503 : H12AffineEnvironment.transform 6 9 env38468 = env38503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38468 == env38503) = true)

def env38504 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8193,64,4677966,2172250,2118977,442385,75102,6407191,256,2188651,2196551,513]

theorem envBound38504 : H12AffineFastState.Bounded env38504 := by
  intro p hp
  have h : env38504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38503_38504 : H12AffineEnvironment.transform 22 16 env38503 = env38504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env38503 == env38504) = true)

def env38505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8193,64,4677966,115014,45405,442385,75102,4268043,256,98679,90203,513]

theorem envBound38505 : H12AffineFastState.Bounded env38505 := by
  intro p hp
  have h : env38505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38504_38505 : H12AffineEnvironment.transform 20 58396 env38504 = env38505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env38504 == env38505) = true)

theorem identity38505 : scanCanonicalize (H12AffineFastState.compose env38505 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38505 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,4194304,16,41311,8193,64,4604228,57676,45405,442385,1364,4194305,256,41341,16465,513]

theorem envBound38506 : H12AffineFastState.Bounded env38506 := by
  intro p hp
  have h : env38506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38505_38506 : H12AffineEnvironment.transform 15 8202 env38505 = env38506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38505 == env38506) = true)

theorem identity38506 : scanCanonicalize (H12AffineFastState.compose env38506 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound38506 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env38507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419913,16,41311,8193,64,10509,57676,45405,442385,1364,419912,256,41341,16465,513]

theorem envBound38507 : H12AffineFastState.Bounded env38507 := by
  intro p hp
  have h : env38507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38506_38507 : H12AffineEnvironment.transform 21 419913 env38506 = env38507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env38506 == env38507) = true)

def env38508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58396,272393,16,41311,8193,64,10509,57676,45405,294993,1364,272392,256,41341,16465,513]

theorem envBound38508 : H12AffineFastState.Bounded env38508 := by
  intro p hp
  have h : env38508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38507_38508 : H12AffineEnvironment.transform 16 16448 env38507 = env38508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env38507 == env38508) = true)

theorem identity38508 : scanCanonicalize (H12AffineFastState.compose env38508 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound38508 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,2341,1024,32769,58396,8492,16,41311,8193,64,10509,57676,45405,35188,1364,8493,256,41341,16465,513]

theorem envBound38509 : H12AffineFastState.Bounded env38509 := by
  intro p hp
  have h : env38509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38508_38509 : H12AffineEnvironment.transform 17 2341 env38508 = env38509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env38508 == env38509) = true)

theorem identity38509 : scanCanonicalize (H12AffineFastState.compose env38509 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound38509 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env38510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8202,16448,2341,1024,8460,17681,8492,16,82,8193,64,10509,16449,4176,10361,1364,8493,256,112,16465,513]

theorem envBound38510 : H12AffineFastState.Bounded env38510 := by
  intro p hp
  have h : env38510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38509_38510 : H12AffineEnvironment.transform 14 8461 env38509 = env38510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env38509 == env38510) = true)

theorem identity38510 : scanCanonicalize (H12AffineFastState.compose env38510 (packedSelected [0,1,3,4,5,8,10,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38510 : packedSelected [0,1,3,4,5,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env38511 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8202,16401,2341,1024,8460,17681,8492,16,3,8193,17,10509,16400,4097,10280,1285,8493,256,33,16384,513]

theorem envBound38511 : H12AffineFastState.Bounded env38511 := by
  intro p hp
  have h : env38511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38510_38511 : H12AffineEnvironment.transform 5 17 env38510 = env38511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38510 == env38511) = true)

theorem identity38511 : scanCanonicalize (H12AffineFastState.compose env38511 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound38511 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38512 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,8461,8202,5173,2341,1024,8460,4405,8492,16,3,8193,17,10509,5172,4097,10280,1285,8493,256,33,5156,513]

theorem envBound38512 : H12AffineFastState.Bounded env38512 := by
  intro p hp
  have h : env38512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38511_38512 : H12AffineEnvironment.transform 13 5156 env38511 = env38512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env38511 == env38512) = true)

theorem identity38512 : scanCanonicalize (H12AffineFastState.compose env38512 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38512 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38513 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,0,263,5173,2341,1024,1,4405,33,16,3,268,17,2048,5172,4097,2341,1285,32,256,33,5156,513]

theorem envBound38513 : H12AffineFastState.Bounded env38513 := by
  intro p hp
  have h : env38513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38512_38513 : H12AffineEnvironment.transform 12 269 env38512 = env38513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38512 == env38513) = true)

def env38514 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,269,2836,0,263,2821,2341,1024,1,3589,33,16,3,268,17,2048,2820,3889,2341,1285,32,256,33,2836,513]

theorem envBound38514 : H12AffineFastState.Bounded env38514 := by
  intro p hp
  have h : env38514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38513_38514 : H12AffineEnvironment.transform 11 3888 env38513 = env38514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env38513 == env38514) = true)

def env38515 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,269,1044,0,263,1029,1573,1024,1,261,33,16,3,268,17,1792,1028,49,1573,1285,32,256,33,1044,513]

theorem envBound38515 : H12AffineFastState.Bounded env38515 := by
  intro p hp
  have h : env38515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38514_38515 : H12AffineEnvironment.transform 10 1792 env38514 = env38515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env38514 == env38515) = true)

def env38516 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,269,1045,0,263,1028,1572,1024,1,260,33,16,3,268,17,1793,1029,48,1572,1285,32,256,33,1045,513]

theorem envBound38516 : H12AffineFastState.Bounded env38516 := by
  intro p hp
  have h : env38516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38514_38516 : H12AffineEnvironment.transform 10 1793 env38514 = env38516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env38514 == env38516) = true)

theorem identity38516 : scanCanonicalize (H12AffineFastState.compose env38516 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38516 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38517 : List Nat := [2,4,8,16,32,17,9,256,512,273,528,49,269,260,0,263,277,821,273,1,260,33,16,3,268,17,528,276,48,821,20,32,256,33,260,513]

theorem envBound38517 : H12AffineFastState.Bounded env38517 := by
  intro p hp
  have h : env38517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38516_38517 : H12AffineEnvironment.transform 9 273 env38516 = env38517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38516 == env38517) = true)

def env38518 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,41,32,0,35,49,529,53,1,32,33,16,3,40,17,528,48,48,529,20,32,36,33,32,513]

theorem envBound38518 : H12AffineFastState.Bounded env38518 := by
  intro p hp
  have h : env38518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38517_38518 : H12AffineEnvironment.transform 7 36 env38517 = env38518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38517 == env38518) = true)

def env38519 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,49,40,33,0,34,48,528,52,1,33,33,16,3,41,17,528,49,48,528,20,32,37,33,33,513]

theorem envBound38519 : H12AffineFastState.Bounded env38519 := by
  intro p hp
  have h : env38519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38517_38519 : H12AffineEnvironment.transform 7 37 env38517 = env38519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38517 == env38519) = true)

theorem identity38519 : scanCanonicalize (H12AffineFastState.compose env38519 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38519 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38520 : List Nat := [2,4,8,16,32,17,9,37,43,52,59,49,40,33,0,34,48,59,52,1,33,33,16,3,41,17,59,49,48,59,20,32,37,33,33,42]

theorem envBound38520 : H12AffineFastState.Bounded env38520 := by
  intro p hp
  have h : env38520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38519_38520 : H12AffineEnvironment.transform 8 43 env38519 = env38520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38519 == env38520) = true)

def leafEnv38520 : List Nat := [2,4,8,16,32,17,9,37,43,52,59,49,40,33,0,34,48,59,52,1,33,33,16,3,20,41,1,17,59,49,48,59,20,32,37,33,4,35,33,42,1,33,0]

def active38520 : List Nat := [0,1,2,3,4]

def tree38520 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38520 : H12WitnessSearch.Good tree38520 := H12GlobalWitnessIndex.good

theorem leafIdentity38520 : H12AffineFastState.composeSystem env38520 rootObs = leafEnv38520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38520 rootObs == leafEnv38520) = true)

theorem terminalChecked38520 : H12PackedTerminal.terminalCheckFast leafEnv38520 active38520 tree38520 = true := by decide +kernel

def env38521 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,269,2837,0,263,2820,2341,1024,1,3588,33,16,3,268,17,2048,2821,3888,2341,1285,32,256,33,2837,513]

theorem envBound38521 : H12AffineFastState.Bounded env38521 := by
  intro p hp
  have h : env38521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38513_38521 : H12AffineEnvironment.transform 11 3889 env38513 = env38521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env38513 == env38521) = true)

def env38522 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,269,1045,0,263,1028,1573,1024,1,260,33,16,3,268,17,1792,1029,48,1573,1285,32,256,33,1045,513]

theorem envBound38522 : H12AffineFastState.Bounded env38522 := by
  intro p hp
  have h : env38522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38521_38522 : H12AffineEnvironment.transform 10 1792 env38521 = env38522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env38521 == env38522) = true)

theorem identity38522 : scanCanonicalize (H12AffineFastState.compose env38522 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38523 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,49,269,32,0,263,49,528,53,1,260,33,16,3,268,17,821,48,48,528,304,32,256,33,32,513]

theorem envBound38523 : H12AffineFastState.Bounded env38523 := by
  intro p hp
  have h : env38523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38522_38523 : H12AffineEnvironment.transform 9 53 env38522 = env38523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38522 == env38523) = true)

def env38524 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,269,1044,0,263,1029,1572,1024,1,261,33,16,3,268,17,1793,1028,49,1572,1285,32,256,33,1044,513]

theorem envBound38524 : H12AffineFastState.Bounded env38524 := by
  intro p hp
  have h : env38524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38521_38524 : H12AffineEnvironment.transform 10 1793 env38521 = env38524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env38521 == env38524) = true)

theorem identity38524 : scanCanonicalize (H12AffineFastState.compose env38524 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38525 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,48,40,1044,0,34,1029,1572,1024,1,32,33,16,3,41,17,1572,1028,49,1572,1056,32,37,33,1044,513]

theorem envBound38525 : H12AffineFastState.Bounded env38525 := by
  intro p hp
  have h : env38525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38524_38525 : H12AffineEnvironment.transform 7 37 env38524 = env38525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38524 == env38525) = true)

def env38526 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,48,40,32,0,34,49,528,52,1,32,33,16,3,41,17,528,48,49,528,20,32,37,33,32,513]

theorem envBound38526 : H12AffineFastState.Bounded env38526 := by
  intro p hp
  have h : env38526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38525_38526 : H12AffineEnvironment.transform 9 52 env38525 = env38526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38525 == env38526) = true)

theorem identity38526 : scanCanonicalize (H12AffineFastState.compose env38526 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound38526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38527 : List Nat := [2,4,8,16,32,17,9,37,42,52,58,48,40,32,0,34,49,58,52,1,32,33,16,3,41,17,58,48,49,58,20,32,37,33,32,43]

theorem envBound38527 : H12AffineFastState.Bounded env38527 := by
  intro p hp
  have h : env38527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38526_38527 : H12AffineEnvironment.transform 8 42 env38526 = env38527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env38526 == env38527) = true)

def leafEnv38527 : List Nat := [2,4,8,16,32,17,9,37,42,52,58,48,40,32,0,34,49,58,52,1,32,33,16,3,20,41,1,17,58,48,49,58,20,32,37,33,4,35,32,43,1,32,0]

def active38527 : List Nat := [0,1,2,3,4]

def tree38527 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38527 : H12WitnessSearch.Good tree38527 := H12GlobalWitnessIndex.good

theorem leafIdentity38527 : H12AffineFastState.composeSystem env38527 rootObs = leafEnv38527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38527 rootObs == leafEnv38527) = true)

theorem terminalChecked38527 : H12PackedTerminal.terminalCheckFast leafEnv38527 active38527 tree38527 = true := by decide +kernel

def env38528 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,48,40,33,0,34,48,529,53,1,32,33,16,3,41,17,529,49,49,529,21,32,37,33,33,513]

theorem envBound38528 : H12AffineFastState.Bounded env38528 := by
  intro p hp
  have h : env38528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38525_38528 : H12AffineEnvironment.transform 9 53 env38525 = env38528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38525 == env38528) = true)

def env38529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58396,272392,16,41311,8193,64,10509,57676,45405,294992,1364,272393,256,41341,16465,513]

theorem envBound38529 : H12AffineFastState.Bounded env38529 := by
  intro p hp
  have h : env38529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38507_38529 : H12AffineEnvironment.transform 16 16449 env38507 = env38529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env38507 == env38529) = true)

theorem identity38529 : scanCanonicalize (H12AffineFastState.compose env38529 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound38529 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,10281,1024,32769,58396,33,16,41311,8193,64,10509,57676,45405,43129,1364,32,256,41341,16465,513]

theorem envBound38530 : H12AffineFastState.Bounded env38530 := by
  intro p hp
  have h : env38530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38529_38530 : H12AffineEnvironment.transform 17 10281 env38529 = env38530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38529 == env38530) = true)

theorem identity38530 : scanCanonicalize (H12AffineFastState.compose env38530 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2128) := by decide +kernel

theorem selectedBound38530 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,2128,8202,16449,10281,1024,2129,27724,33,16,10511,8193,64,10509,26908,14605,8233,1364,32,256,10541,16465,513]

theorem envBound38531 : H12AffineFastState.Bounded env38531 := by
  intro p hp
  have h : env38531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38530_38531 : H12AffineEnvironment.transform 14 2128 env38530 = env38531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2128 env38530 == env38531) = true)

theorem identity38531 : scanCanonicalize (H12AffineFastState.compose env38531 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound38531 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,2128,5127,16449,7204,1024,2129,22593,33,16,7426,5132,64,7424,23825,3328,5156,1364,32,256,7456,16465,513]

theorem envBound38532 : H12AffineFastState.Bounded env38532 := by
  intro p hp
  have h : env38532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38531_38532 : H12AffineEnvironment.transform 12 5133 env38531 = env38532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env38531 == env38532) = true)

theorem identity38532 : scanCanonicalize (H12AffineFastState.compose env38532 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound38532 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env38533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,3100,16384,2128,3094,16449,1077,1024,2129,16464,33,16,1299,3101,64,1297,17664,3328,3125,1364,32,256,1329,16465,513]

theorem envBound38533 : H12AffineFastState.Bounded env38533 := by
  intro p hp
  have h : env38533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38532_38533 : H12AffineEnvironment.transform 11 2065 env38532 = env38533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env38532 == env38533) = true)

theorem identity38533 : scanCanonicalize (H12AffineFastState.compose env38533 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38533 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38534 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,3100,16384,2048,3094,16401,1077,1024,2049,16384,33,16,1299,3101,16,1297,17664,3328,3125,1284,32,256,1329,16385,513]

theorem envBound38534 : H12AffineFastState.Bounded env38534 := by
  intro p hp
  have h : env38534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38533_38534 : H12AffineEnvironment.transform 5 16 env38533 = env38534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38533 == env38534) = true)

theorem identity38534 : scanCanonicalize (H12AffineFastState.compose env38534 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound38534 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38535 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,3100,2308,2048,3094,2325,1077,1024,2049,2308,33,16,1299,3101,16,1297,3076,3328,3125,1284,32,256,1329,2309,513]

theorem envBound38535 : H12AffineFastState.Bounded env38535 := by
  intro p hp
  have h : env38535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38534_38535 : H12AffineEnvironment.transform 13 2308 env38534 = env38535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env38534 == env38535) = true)

theorem identity38535 : scanCanonicalize (H12AffineFastState.compose env38535 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound38535 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0