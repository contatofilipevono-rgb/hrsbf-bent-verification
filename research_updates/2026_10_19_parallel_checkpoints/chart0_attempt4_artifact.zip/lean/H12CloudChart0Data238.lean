import H12CloudChart0Data237

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity60391 : scanCanonicalize (H12AffineFastState.compose env60391 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 90) := by decide +kernel

theorem selectedBound60391 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60392 : List Nat := [2,4,8,16,2,64,90,84,0,7,83,0,8,80,2,2,2,65,6,2,2,0,65,3,90,16,18,81,82,2,4,3,84,83,2,1]

theorem envBound60392 : H12AffineFastState.Bounded env60392 := by
  intro p hp
  have h : env60392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60391_60392 : H12AffineEnvironment.transform 6 90 env60391 = env60392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 90 env60391 == env60392) = true)

theorem identity60392 : scanCanonicalize (H12AffineFastState.compose env60392 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound60392 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60393 : List Nat := [2,4,8,16,2,24,2,12,0,7,11,0,8,8,2,2,2,25,6,2,2,0,25,3,2,16,18,9,10,2,4,3,12,11,2,1]

theorem envBound60393 : H12AffineFastState.Bounded env60393 := by
  intro p hp
  have h : env60393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60392_60393 : H12AffineEnvironment.transform 5 24 env60392 = env60393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env60392 == env60393) = true)

theorem identity60393 : scanCanonicalize (H12AffineFastState.compose env60393 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60393 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60394 : List Nat := [2,4,2,16,2,18,2,6,0,7,1,0,2,2,2,2,2,19,6,2,2,0,19,3,2,16,18,3,0,2,4,3,6,1,2,1]

theorem envBound60394 : H12AffineFastState.Bounded env60394 := by
  intro p hp
  have h : env60394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60393_60394 : H12AffineEnvironment.transform 2 2 env60393 = env60394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60393 == env60394) = true)

theorem identity60394 : scanCanonicalize (H12AffineFastState.compose env60394 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60394 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60395 : List Nat := [1,4,1,16,1,17,1,5,0,4,1,0,1,1,1,1,1,16,5,1,1,0,16,0,1,16,17,0,0,1,4,0,5,1,1,1]

theorem envBound60395 : H12AffineFastState.Bounded env60395 := by
  intro p hp
  have h : env60395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60394_60395 : H12AffineEnvironment.transform 0 1 env60394 = env60395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60394 == env60395) = true)

theorem identity60395 : scanCanonicalize (H12AffineFastState.compose env60395 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60395 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60396 : List Nat := [1,4,1,1,1,0,1,5,0,4,1,0,1,1,1,1,1,1,5,1,1,0,1,0,1,1,0,0,0,1,4,0,5,1,1,1]

theorem envBound60396 : H12AffineFastState.Bounded env60396 := by
  intro p hp
  have h : env60396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60395_60396 : H12AffineEnvironment.transform 3 1 env60395 = env60396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60395 == env60396) = true)

def env60397 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1289,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound60397 : H12AffineFastState.Bounded env60397 := by
  intro p hp
  have h : env60397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60373_60397 : H12AffineEnvironment.transform 8 1 env60373 = env60397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60373 == env60397) = true)

theorem identity60397 : scanCanonicalize (H12AffineFastState.compose env60397 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 9561) := by decide +kernel

theorem selectedBound60397 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60398 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,9561,1417,9664,3158,1289,9617,277548,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound60398 : H12AffineFastState.Bounded env60398 := by
  intro p hp
  have h : env60398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60397_60398 : H12AffineEnvironment.transform 20 9561 env60397 = env60398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 9561 env60397 == env60398) = true)

def env60399 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,217,1417,64,3158,1289,17,268716,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound60399 : H12AffineFastState.Bounded env60399 := by
  intro p hp
  have h : env60399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60398_60399 : H12AffineEnvironment.transform 12 1408 env60398 = env60399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60398 == env60399) = true)

theorem identity60399 : scanCanonicalize (H12AffineFastState.compose env60399 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound60399 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60400 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,217,1417,64,3158,1289,17,268716,4177,3361,7537,6181,4572,256,6312,3441,1]

theorem envBound60400 : H12AffineFastState.Bounded env60400 := by
  intro p hp
  have h : env60400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60399_60400 : H12AffineEnvironment.transform 15 6179 env60399 = env60400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env60399 == env60400) = true)

theorem identity60400 : scanCanonicalize (H12AffineFastState.compose env60400 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60400 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60401 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6179,3441,6376,1025,2128,217,1417,64,3158,1289,17,324,4177,3361,7537,6181,4572,256,6312,3441,1]

theorem envBound60401 : H12AffineFastState.Bounded env60401 := by
  intro p hp
  have h : env60401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60400_60401 : H12AffineEnvironment.transform 17 6376 env60400 = env60401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60400 == env60401) = true)

theorem identity60401 : scanCanonicalize (H12AffineFastState.compose env60401 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60401 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60402 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1408,412,2128,2543,3441,2340,1025,2128,217,1417,64,3158,1289,17,324,413,3361,3261,2537,16,256,2404,3441,1]

theorem envBound60402 : H12AffineFastState.Bounded env60402 := by
  intro p hp
  have h : env60402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60401_60402 : H12AffineEnvironment.transform 11 460 env60401 = env60402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60401 == env60402) = true)

theorem identity60402 : scanCanonicalize (H12AffineFastState.compose env60402 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60402 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60403 : List Nat := [2,4,8,16,32,64,128,256,1,409,2048,460,25,412,2128,2543,2280,2340,408,2128,217,16,64,2511,144,17,324,413,2232,2340,2537,16,256,2404,2280,1]

theorem envBound60403 : H12AffineFastState.Bounded env60403 := by
  intro p hp
  have h : env60403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60402_60403 : H12AffineEnvironment.transform 9 409 env60402 = env60403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60402 == env60403) = true)

theorem identity60403 : scanCanonicalize (H12AffineFastState.compose env60403 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60403 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60404 : List Nat := [2,4,8,16,32,64,128,256,1,409,325,460,25,412,277,170,429,97,408,277,217,16,64,138,144,17,324,413,509,97,172,16,256,33,429,1]

theorem envBound60404 : H12AffineFastState.Bounded env60404 := by
  intro p hp
  have h : env60404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60403_60404 : H12AffineEnvironment.transform 10 325 env60403 = env60404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60403 == env60404) = true)

theorem identity60404 : scanCanonicalize (H12AffineFastState.compose env60404 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60404 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60405 : List Nat := [2,4,8,16,32,64,128,94,1,199,27,146,25,194,75,170,243,97,198,75,217,16,64,138,144,17,26,195,163,97,172,16,94,33,243,1]

theorem envBound60405 : H12AffineFastState.Bounded env60405 := by
  intro p hp
  have h : env60405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60404_60405 : H12AffineEnvironment.transform 7 94 env60404 = env60405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60404 == env60405) = true)

theorem identity60405 : scanCanonicalize (H12AffineFastState.compose env60405 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60405 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60406 : List Nat := [2,4,8,16,16,64,128,94,1,199,27,146,25,194,75,154,195,81,198,75,217,16,64,138,144,17,26,195,147,81,156,16,94,17,195,1]

theorem envBound60406 : H12AffineFastState.Bounded env60406 := by
  intro p hp
  have h : env60406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60405_60406 : H12AffineEnvironment.transform 4 16 env60405 = env60406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60405 == env60406) = true)

def env60407 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,216,1417,65,3158,1289,16,268717,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound60407 : H12AffineFastState.Bounded env60407 := by
  intro p hp
  have h : env60407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60398_60407 : H12AffineEnvironment.transform 12 1409 env60398 = env60407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60398 == env60407) = true)

theorem identity60407 : scanCanonicalize (H12AffineFastState.compose env60407 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2340) := by decide +kernel

theorem selectedBound60407 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60408 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2340,1409,2420,2128,65536,68727,262144,1025,2128,216,1417,65,3158,1289,16,262281,2421,68647,66898,65542,68095,256,65675,68727,0]

theorem envBound60408 : H12AffineFastState.Bounded env60408 := by
  intro p hp
  have h : env60408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60407_60408 : H12AffineEnvironment.transform 11 2340 env60407 = env60408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2340 env60407 == env60408) = true)

theorem identity60408 : scanCanonicalize (H12AffineFastState.compose env60408 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60408 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60409 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1245,1409,1165,1449,65536,65934,262144,1025,1449,216,1417,65,431,1289,16,262281,1164,66014,66898,65542,66566,256,65675,65934,0]

theorem envBound60409 : H12AffineFastState.Bounded env60409 := by
  intro p hp
  have h : env60409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60408_60409 : H12AffineEnvironment.transform 10 1529 env60408 = env60409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60408 == env60409) = true)

theorem identity60409 : scanCanonicalize (H12AffineFastState.compose env60409 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65815) := by decide +kernel

theorem selectedBound60409 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60410 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1245,1409,1165,1449,65536,65934,65815,1025,1449,216,1417,65,431,1289,16,65950,1164,66014,66898,65542,66566,256,65675,65934,0]

theorem envBound60410 : H12AffineFastState.Bounded env60410 := by
  intro p hp
  have h : env60410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60409_60410 : H12AffineEnvironment.transform 17 65815 env60409 = env60410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65815 env60409 == env60410) = true)

theorem identity60410 : scanCanonicalize (H12AffineFastState.compose env60410 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60410 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60411 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1245,1409,1165,1449,1063,1449,1328,1025,1449,216,1417,65,431,1289,16,1465,1164,1529,373,1057,33,256,1196,1449,0]

theorem envBound60411 : H12AffineFastState.Bounded env60411 := by
  intro p hp
  have h : env60411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60410_60411 : H12AffineEnvironment.transform 15 1063 env60410 = env60411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60410 == env60411) = true)

theorem identity60411 : scanCanonicalize (H12AffineFastState.compose env60411 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60411 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60412 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,1,349,81,373,251,373,492,221,373,216,341,65,431,469,16,357,80,293,373,253,33,256,112,373,0]

theorem envBound60412 : H12AffineFastState.Bounded env60412 := by
  intro p hp
  have h : env60412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60411_60412 : H12AffineEnvironment.transform 9 220 env60411 = env60412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60411 == env60412) = true)

theorem identity60412 : scanCanonicalize (H12AffineFastState.compose env60412 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60412 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60413 : List Nat := [2,4,8,16,32,17,128,256,1,141,293,1,268,0,292,170,292,445,140,292,137,260,16,431,388,16,308,1,293,292,172,33,256,33,292,0]

theorem envBound60413 : H12AffineFastState.Bounded env60413 := by
  intro p hp
  have h : env60413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60412_60413 : H12AffineEnvironment.transform 5 17 env60412 = env60413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60412 == env60413) = true)

theorem identity60413 : scanCanonicalize (H12AffineFastState.compose env60413 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound60413 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60414 : List Nat := [2,4,8,16,32,17,128,141,1,141,168,1,129,0,169,170,169,48,140,169,137,137,16,34,9,16,185,1,168,169,172,33,141,33,169,0]

theorem envBound60414 : H12AffineFastState.Bounded env60414 := by
  intro p hp
  have h : env60414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60413_60414 : H12AffineEnvironment.transform 7 141 env60413 = env60414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env60413 == env60414) = true)

theorem identity60414 : scanCanonicalize (H12AffineFastState.compose env60414 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60414 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60415 : List Nat := [2,4,2,16,32,17,128,135,1,135,162,1,129,0,163,160,163,48,134,163,131,131,16,34,3,16,179,1,162,163,166,33,135,33,163,0]

theorem envBound60415 : H12AffineFastState.Bounded env60415 := by
  intro p hp
  have h : env60415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60414_60415 : H12AffineEnvironment.transform 2 2 env60414 = env60415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60414 == env60415) = true)

theorem identity60415 : scanCanonicalize (H12AffineFastState.compose env60415 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 49) := by decide +kernel

theorem selectedBound60415 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60416 : List Nat := [2,4,2,16,32,17,49,54,1,54,19,1,48,0,18,17,18,48,55,18,50,50,16,34,3,16,2,1,19,18,23,33,54,33,18,0]

theorem envBound60416 : H12AffineFastState.Bounded env60416 := by
  intro p hp
  have h : env60416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60415_60416 : H12AffineEnvironment.transform 6 49 env60415 = env60416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 49 env60415 == env60416) = true)

theorem identity60416 : scanCanonicalize (H12AffineFastState.compose env60416 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60416 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60417 : List Nat := [2,4,2,16,1,17,16,23,1,23,19,1,17,0,18,17,18,17,22,18,19,19,16,3,3,16,2,1,19,18,23,0,23,0,18,0]

theorem envBound60417 : H12AffineFastState.Bounded env60417 := by
  intro p hp
  have h : env60417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60416_60417 : H12AffineEnvironment.transform 4 1 env60416 = env60417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60416 == env60417) = true)

theorem identity60417 : scanCanonicalize (H12AffineFastState.compose env60417 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60418 : List Nat := [0,4,0,16,1,17,16,21,1,21,17,1,17,0,16,17,16,17,20,16,17,17,16,1,1,16,0,1,17,16,21,0,21,0,16,0]

theorem envBound60418 : H12AffineFastState.Bounded env60418 := by
  intro p hp
  have h : env60418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60417_60418 : H12AffineEnvironment.transform 0 0 env60417 = env60418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60417 == env60418) = true)

theorem identity60418 : scanCanonicalize (H12AffineFastState.compose env60418 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60419 : List Nat := [0,4,0,0,1,1,0,5,1,5,1,1,1,0,0,1,0,1,4,0,1,1,0,1,1,0,0,1,1,0,5,0,5,0,0,0]

theorem envBound60419 : H12AffineFastState.Bounded env60419 := by
  intro p hp
  have h : env60419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60418_60419 : H12AffineEnvironment.transform 3 0 env60418 = env60419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60418 == env60419) = true)

def env60420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3670,1288,9616,2366324,4177,77954,67411,65543,68607,256,65675,78034,10113]

theorem envBound60420 : H12AffineFastState.Bounded env60420 := by
  intro p hp
  have h : env60420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60372_60420 : H12AffineEnvironment.transform 22 9665 env60372 = env60420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60372 == env60420) = true)

def env60421 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1288,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound60421 : H12AffineFastState.Bounded env60421 := by
  intro p hp
  have h : env60421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60420_60421 : H12AffineEnvironment.transform 8 0 env60420 = env60421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60420 == env60421) = true)

theorem identity60421 : scanCanonicalize (H12AffineFastState.compose env60421 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound60421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60422 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,7433,4176,2129,65536,69083,262144,1025,2129,2097152,1417,6344,3158,1288,6297,2365812,4177,69003,66899,65543,68095,256,65675,69083,6280]

theorem envBound60422 : H12AffineFastState.Bounded env60422 := by
  intro p hp
  have h : env60422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60421_60422 : H12AffineEnvironment.transform 12 7433 env60421 = env60422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env60421 == env60422) = true)

def env60423 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,2097152,1417,64,3158,1288,17,2359804,2265,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound60423 : H12AffineFastState.Bounded env60423 := by
  intro p hp
  have h : env60423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60422_60423 : H12AffineEnvironment.transform 11 2184 env60422 = env60423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env60422 == env60423) = true)

theorem identity60423 : scanCanonicalize (H12AffineFastState.compose env60423 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound60423 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60424 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,65650,1417,64,3158,1288,17,328078,2265,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound60424 : H12AffineFastState.Bounded env60424 := by
  intro p hp
  have h : env60424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60423_60424 : H12AffineEnvironment.transform 20 65650 env60423 = env60424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env60423 == env60424) = true)

theorem identity60424 : scanCanonicalize (H12AffineFastState.compose env60424 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound60424 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60425 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2129,65536,69083,97,1025,2129,65650,1417,64,3158,1288,17,66031,2265,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound60425 : H12AffineFastState.Bounded env60425 := by
  intro p hp
  have h : env60425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60424_60425 : H12AffineEnvironment.transform 17 97 env60424 = env60425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env60424 == env60425) = true)

theorem identity60425 : scanCanonicalize (H12AffineFastState.compose env60425 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60425 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60426 : List Nat := [2,4,8,16,32,64,128,256,0,409,2048,2184,24,2264,2129,65536,67650,97,408,2129,65650,16,64,2511,145,17,66031,2265,67602,65738,65543,68095,256,65675,67650,0]

theorem envBound60426 : H12AffineFastState.Bounded env60426 := by
  intro p hp
  have h : env60426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60425_60426 : H12AffineEnvironment.transform 9 409 env60425 = env60426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60425 == env60426) = true)

theorem identity60426 : scanCanonicalize (H12AffineFastState.compose env60426 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60426 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60427 : List Nat := [2,4,8,16,16,64,128,256,0,409,2048,2184,24,2264,2129,65536,67650,81,408,2129,65602,16,64,2511,145,17,66015,2265,67602,65738,65543,68047,256,65675,67650,0]

theorem envBound60427 : H12AffineFastState.Bounded env60427 := by
  intro p hp
  have h : env60427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60426_60427 : H12AffineEnvironment.transform 4 16 env60426 = env60427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60426 == env60427) = true)

theorem identity60427 : scanCanonicalize (H12AffineFastState.compose env60427 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound60427 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60428 : List Nat := [2,4,8,16,16,64,128,256,0,409,2048,2184,24,2264,2129,155,2265,81,408,2129,217,16,64,2511,145,17,324,2265,2185,81,156,2388,256,16,2265,0]

theorem envBound60428 : H12AffineFastState.Bounded env60428 := by
  intro p hp
  have h : env60428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60427_60428 : H12AffineEnvironment.transform 15 155 env60427 = env60428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env60427 == env60428) = true)

theorem identity60428 : scanCanonicalize (H12AffineFastState.compose env60428 (packedSelected [1,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60428 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env60429 : List Nat := [2,4,8,16,16,64,128,256,0,409,324,460,24,412,277,155,413,81,408,277,217,16,64,139,145,17,324,413,461,81,156,16,256,16,413,0]

theorem envBound60429 : H12AffineFastState.Bounded env60429 := by
  intro p hp
  have h : env60429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60428_60429 : H12AffineEnvironment.transform 10 324 env60428 = env60429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60428 == env60429) = true)

theorem identity60429 : scanCanonicalize (H12AffineFastState.compose env60429 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60429 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60430 : List Nat := [2,4,8,16,16,64,128,21,0,140,81,217,24,137,0,155,136,81,141,0,217,16,64,139,145,17,81,136,216,81,156,16,21,16,136,0]

theorem envBound60430 : H12AffineFastState.Bounded env60430 := by
  intro p hp
  have h : env60430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60429_60430 : H12AffineEnvironment.transform 7 21 env60429 = env60430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60429 == env60430) = true)

theorem identity60430 : scanCanonicalize (H12AffineFastState.compose env60430 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60431 : List Nat := [2,4,8,16,16,64,19,21,0,31,81,74,24,26,0,8,27,81,30,0,74,16,64,24,2,17,81,27,75,81,15,16,21,16,27,0]

theorem envBound60431 : H12AffineFastState.Bounded env60431 := by
  intro p hp
  have h : env60431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60430_60431 : H12AffineEnvironment.transform 6 19 env60430 = env60431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60430 == env60431) = true)

theorem identity60431 : scanCanonicalize (H12AffineFastState.compose env60431 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound60431 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60432 : List Nat := [2,4,8,16,16,10,19,21,0,31,27,0,24,26,0,8,27,27,30,0,0,16,10,24,2,17,27,27,1,27,15,16,21,16,27,0]

theorem envBound60432 : H12AffineFastState.Bounded env60432 := by
  intro p hp
  have h : env60432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60431_60432 : H12AffineEnvironment.transform 5 10 env60431 = env60432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env60431 == env60432) = true)

theorem identity60432 : scanCanonicalize (H12AffineFastState.compose env60432 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60432 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60433 : List Nat := [2,4,8,10,10,10,9,15,0,5,1,0,2,0,0,8,1,1,4,0,0,10,10,2,2,11,1,1,1,1,15,10,15,10,1,0]

theorem envBound60433 : H12AffineFastState.Bounded env60433 := by
  intro p hp
  have h : env60433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60432_60433 : H12AffineEnvironment.transform 3 10 env60432 = env60433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60432 == env60433) = true)

def env60434 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,2097152,1417,65,3158,1288,16,2359805,2264,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound60434 : H12AffineFastState.Bounded env60434 := by
  intro p hp
  have h : env60434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60422_60434 : H12AffineEnvironment.transform 11 2185 env60422 = env60434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env60422 == env60434) = true)

theorem identity60434 : scanCanonicalize (H12AffineFastState.compose env60434 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound60434 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60435 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,372,1417,65,3158,1288,16,262281,2264,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound60435 : H12AffineFastState.Bounded env60435 := by
  intro p hp
  have h : env60435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60434_60435 : H12AffineEnvironment.transform 20 372 env60434 = env60435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env60434 == env60435) = true)

theorem identity60435 : scanCanonicalize (H12AffineFastState.compose env60435 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60435 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60436 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1393,1408,1313,1449,65536,65571,262144,1025,1449,372,1417,65,430,1288,16,262281,1312,65651,66899,65543,66567,256,65675,65571,1]

theorem envBound60436 : H12AffineFastState.Bounded env60436 := by
  intro p hp
  have h : env60436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60435_60436 : H12AffineEnvironment.transform 10 1528 env60435 = env60436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60435 == env60436) = true)

theorem identity60436 : scanCanonicalize (H12AffineFastState.compose env60436 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65723) := by decide +kernel

theorem selectedBound60436 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60437 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1393,1408,1313,1449,65536,65571,65723,1025,1449,372,1417,65,430,1288,16,65586,1312,65651,66899,65543,66567,256,65675,65571,1]

theorem envBound60437 : H12AffineFastState.Bounded env60437 := by
  intro p hp
  have h : env60437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60436_60437 : H12AffineEnvironment.transform 17 65723 env60436 = env60437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65723 env60436 == env60437) = true)

theorem identity60437 : scanCanonicalize (H12AffineFastState.compose env60437 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60437 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60438 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1393,1408,1313,1449,1063,1028,1180,1025,1449,372,1417,65,430,1288,16,1045,1312,1108,372,1056,32,256,1196,1028,1]

theorem envBound60438 : H12AffineFastState.Bounded env60438 := by
  intro p hp
  have h : env60438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60437_60438 : H12AffineEnvironment.transform 15 1063 env60437 = env60438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60437 == env60438) = true)

theorem identity60438 : scanCanonicalize (H12AffineFastState.compose env60438 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60438 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60439 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,428,349,508,372,250,217,65,220,372,372,340,65,430,469,16,200,509,137,372,253,32,256,113,217,1]

theorem envBound60439 : H12AffineFastState.Bounded env60439 := by
  intro p hp
  have h : env60439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60438_60439 : H12AffineEnvironment.transform 9 221 env60438 = env60439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60438 == env60439) = true)

theorem identity60439 : scanCanonicalize (H12AffineFastState.compose env60439 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound60439 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60440 : List Nat := [2,4,8,16,32,64,128,141,0,221,168,33,208,113,249,250,217,65,220,249,249,217,65,35,88,16,200,112,137,249,253,32,141,113,217,1]

theorem envBound60440 : H12AffineFastState.Bounded env60440 := by
  intro p hp
  have h : env60440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60439_60440 : H12AffineEnvironment.transform 7 141 env60439 = env60440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env60439 == env60440) = true)

theorem identity60440 : scanCanonicalize (H12AffineFastState.compose env60440 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60440 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60441 : List Nat := [2,4,8,16,32,17,128,141,0,140,168,33,129,32,168,171,136,16,141,168,168,136,16,35,9,16,153,33,137,168,172,32,141,32,136,1]

theorem envBound60441 : H12AffineFastState.Bounded env60441 := by
  intro p hp
  have h : env60441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60440_60441 : H12AffineEnvironment.transform 5 17 env60440 = env60441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60440 == env60441) = true)

theorem identity60441 : scanCanonicalize (H12AffineFastState.compose env60441 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound60441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60442 : List Nat := [2,4,8,16,32,17,11,6,0,7,35,33,10,32,35,32,3,16,6,35,35,3,16,35,9,16,18,33,2,35,39,32,6,32,3,1]

theorem envBound60442 : H12AffineFastState.Bounded env60442 := by
  intro p hp
  have h : env60442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60441_60442 : H12AffineEnvironment.transform 6 11 env60441 = env60442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env60441 == env60442) = true)

theorem identity60442 : scanCanonicalize (H12AffineFastState.compose env60442 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound60442 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60443 : List Nat := [2,4,8,16,24,17,11,6,0,7,27,25,10,24,27,24,3,16,6,27,27,3,16,27,9,16,18,25,2,27,31,24,6,24,3,1]

theorem envBound60443 : H12AffineFastState.Bounded env60443 := by
  intro p hp
  have h : env60443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60442_60443 : H12AffineEnvironment.transform 4 24 env60442 = env60443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env60442 == env60443) = true)

theorem identity60443 : scanCanonicalize (H12AffineFastState.compose env60443 (packedSelected [1,3,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60443 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env60444 : List Nat := [0,4,8,16,24,17,9,4,0,5,25,25,8,24,25,24,1,16,4,25,25,1,16,25,9,16,16,25,0,25,29,24,4,24,1,1]

theorem envBound60444 : H12AffineFastState.Bounded env60444 := by
  intro p hp
  have h : env60444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60443_60444 : H12AffineEnvironment.transform 0 0 env60443 = env60444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60443 == env60444) = true)

theorem identity60444 : scanCanonicalize (H12AffineFastState.compose env60444 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60444 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60445 : List Nat := [0,4,8,0,8,1,9,4,0,5,9,9,8,8,9,8,1,0,4,9,9,1,0,9,9,0,0,9,0,9,13,8,4,8,1,1]

theorem envBound60445 : H12AffineFastState.Bounded env60445 := by
  intro p hp
  have h : env60445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60444_60445 : H12AffineEnvironment.transform 3 0 env60444 = env60445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60444 == env60445) = true)

def env60446 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound60446 : H12AffineFastState.Bounded env60446 := by
  intro p hp
  have h : env60446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60420_60446 : H12AffineEnvironment.transform 8 1 env60420 = env60446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60420 == env60446) = true)

theorem identity60446 : scanCanonicalize (H12AffineFastState.compose env60446 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound60446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60447 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,8192,2264,2128,65536,75866,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2359805,2265,75786,66898,65543,68094,256,65675,75866,9600]

theorem envBound60447 : H12AffineFastState.Bounded env60447 := by
  intro p hp
  have h : env60447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60446_60447 : H12AffineEnvironment.transform 11 2184 env60446 = env60447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env60446 == env60447) = true)

def env60448 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1408,2264,2128,65536,69082,262144,1025,2128,2097152,1417,65,3159,1288,16,2359805,2265,69002,66898,65543,68094,256,65675,69082,0]

theorem envBound60448 : H12AffineFastState.Bounded env60448 := by
  intro p hp
  have h : env60448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60447_60448 : H12AffineEnvironment.transform 12 1408 env60447 = env60448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60447 == env60448) = true)

theorem identity60448 : scanCanonicalize (H12AffineFastState.compose env60448 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound60448 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60449 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1408,2264,2128,65536,69082,262144,1025,2128,372,1417,65,3159,1288,16,262281,2265,69002,66898,65543,68094,256,65675,69082,0]

theorem envBound60449 : H12AffineFastState.Bounded env60449 := by
  intro p hp
  have h : env60449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60448_60449 : H12AffineEnvironment.transform 20 372 env60448 = env60449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env60448 == env60449) = true)

theorem identity60449 : scanCanonicalize (H12AffineFastState.compose env60449 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60449 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60450 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1393,1408,1313,1449,65536,65571,262144,1025,1449,372,1417,65,430,1288,16,262281,1312,65651,66898,65543,66567,256,65675,65571,0]

theorem envBound60450 : H12AffineFastState.Bounded env60450 := by
  intro p hp
  have h : env60450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60449_60450 : H12AffineEnvironment.transform 10 1529 env60449 = env60450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60449 == env60450) = true)

theorem identity60450 : scanCanonicalize (H12AffineFastState.compose env60450 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65723) := by decide +kernel

theorem selectedBound60450 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60451 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1393,1408,1313,1449,65536,65571,65723,1025,1449,372,1417,65,430,1288,16,65586,1312,65651,66898,65543,66567,256,65675,65571,0]

theorem envBound60451 : H12AffineFastState.Bounded env60451 := by
  intro p hp
  have h : env60451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60450_60451 : H12AffineEnvironment.transform 17 65723 env60450 = env60451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65723 env60450 == env60451) = true)

theorem identity60451 : scanCanonicalize (H12AffineFastState.compose env60451 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60451 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60452 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1393,1408,1313,1449,1063,1028,1180,1025,1449,372,1417,65,430,1288,16,1045,1312,1108,373,1056,32,256,1196,1028,0]

theorem envBound60452 : H12AffineFastState.Bounded env60452 := by
  intro p hp
  have h : env60452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60451_60452 : H12AffineEnvironment.transform 15 1063 env60451 = env60452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60451 == env60452) = true)

theorem identity60452 : scanCanonicalize (H12AffineFastState.compose env60452 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60452 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60453 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,429,348,509,373,251,216,64,221,373,372,341,65,430,468,16,201,508,136,373,252,32,256,112,216,0]

theorem envBound60453 : H12AffineFastState.Bounded env60453 := by
  intro p hp
  have h : env60453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60452_60453 : H12AffineEnvironment.transform 9 220 env60452 = env60453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60452 == env60453) = true)

theorem identity60453 : scanCanonicalize (H12AffineFastState.compose env60453 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60453 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60454 : List Nat := [2,4,8,16,17,64,128,256,1,220,276,412,348,460,324,202,216,64,221,324,325,341,65,415,468,16,201,461,136,324,205,17,256,65,216,0]

theorem envBound60454 : H12AffineFastState.Bounded env60454 := by
  intro p hp
  have h : env60454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60453_60454 : H12AffineEnvironment.transform 4 17 env60453 = env60454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60453 == env60454) = true)

theorem identity60454 : scanCanonicalize (H12AffineFastState.compose env60454 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 222) := by decide +kernel

theorem selectedBound60454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60455 : List Nat := [2,4,8,16,17,64,128,222,1,220,202,66,130,18,154,202,216,64,221,154,155,139,65,65,10,16,201,19,136,154,205,17,222,65,216,0]

theorem envBound60455 : H12AffineFastState.Bounded env60455 := by
  intro p hp
  have h : env60455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60454_60455 : H12AffineEnvironment.transform 7 222 env60454 = env60455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 222 env60454 == env60455) = true)

theorem identity60455 : scanCanonicalize (H12AffineFastState.compose env60455 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound60455 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60456 : List Nat := [2,4,8,16,17,64,66,28,1,30,8,66,64,18,88,8,26,64,31,88,89,73,65,65,10,16,11,19,74,88,15,17,28,65,26,0]

theorem envBound60456 : H12AffineFastState.Bounded env60456 := by
  intro p hp
  have h : env60456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60455_60456 : H12AffineEnvironment.transform 6 66 env60455 = env60456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env60455 == env60456) = true)

theorem identity60456 : scanCanonicalize (H12AffineFastState.compose env60456 (packedSelected [3,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound60456 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env60457 : List Nat := [2,4,8,16,17,3,1,28,1,30,8,1,3,18,27,8,26,3,31,27,26,10,2,2,10,16,11,19,9,27,15,17,28,2,26,0]

theorem envBound60457 : H12AffineFastState.Bounded env60457 := by
  intro p hp
  have h : env60457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60456_60457 : H12AffineEnvironment.transform 5 3 env60456 = env60457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env60456 == env60457) = true)

theorem identity60457 : scanCanonicalize (H12AffineFastState.compose env60457 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60457 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60458 : List Nat := [2,4,8,2,3,3,1,14,1,12,8,1,3,0,9,8,8,3,13,9,8,10,2,2,10,2,11,1,9,9,15,3,14,2,8,0]

theorem envBound60458 : H12AffineFastState.Bounded env60458 := by
  intro p hp
  have h : env60458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60457_60458 : H12AffineEnvironment.transform 3 2 env60457 = env60458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60457 == env60458) = true)

theorem identity60458 : scanCanonicalize (H12AffineFastState.compose env60458 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60458 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60459 : List Nat := [0,4,8,0,1,1,1,12,1,12,8,1,1,0,9,8,8,1,13,9,8,8,0,0,8,0,9,1,9,9,13,1,12,0,8,0]

theorem envBound60459 : H12AffineFastState.Bounded env60459 := by
  intro p hp
  have h : env60459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60458_60459 : H12AffineEnvironment.transform 0 0 env60458 = env60459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60458 == env60459) = true)

theorem identity60459 : scanCanonicalize (H12AffineFastState.compose env60459 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60459 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env60460 : List Nat := [0,4,0,0,1,1,1,4,1,4,0,1,1,0,1,0,0,1,5,1,0,0,0,0,0,0,1,1,1,1,5,1,4,0,0,0]

theorem envBound60460 : H12AffineFastState.Bounded env60460 := by
  intro p hp
  have h : env60460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60459_60460 : H12AffineEnvironment.transform 2 0 env60459 = env60460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60459 == env60460) = true)

def env60461 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,2097152,1417,64,3159,1288,17,2359805,2265,69003,66898,65543,68094,256,65675,69083,1]

theorem envBound60461 : H12AffineFastState.Bounded env60461 := by
  intro p hp
  have h : env60461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60447_60461 : H12AffineEnvironment.transform 12 1409 env60447 = env60461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60447 == env60461) = true)

theorem identity60461 : scanCanonicalize (H12AffineFastState.compose env60461 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65651) := by decide +kernel

theorem selectedBound60461 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60462 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,65651,1417,64,3159,1288,17,328078,2265,69003,66898,65543,68094,256,65675,69083,1]

theorem envBound60462 : H12AffineFastState.Bounded env60462 := by
  intro p hp
  have h : env60462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60461_60462 : H12AffineEnvironment.transform 20 65651 env60461 = env60462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65651 env60461 == env60462) = true)

theorem identity60462 : scanCanonicalize (H12AffineFastState.compose env60462 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound60462 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60463 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2128,65536,69083,96,1025,2128,65651,1417,64,3159,1288,17,66030,2265,69003,66898,65543,68094,256,65675,69083,1]

theorem envBound60463 : H12AffineFastState.Bounded env60463 := by
  intro p hp
  have h : env60463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60462_60463 : H12AffineEnvironment.transform 17 96 env60462 = env60463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env60462 == env60463) = true)

theorem identity60463 : scanCanonicalize (H12AffineFastState.compose env60463 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60463 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60464 : List Nat := [2,4,8,16,32,64,128,256,1,409,2048,2184,24,2264,2128,65536,67650,96,408,2128,65651,16,64,2510,145,17,66030,2265,67602,65739,65543,68094,256,65675,67650,1]

theorem envBound60464 : H12AffineFastState.Bounded env60464 := by
  intro p hp
  have h : env60464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60463_60464 : H12AffineEnvironment.transform 9 409 env60463 = env60464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60463 == env60464) = true)

theorem identity60464 : scanCanonicalize (H12AffineFastState.compose env60464 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound60464 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60465 : List Nat := [2,4,8,16,32,64,128,256,1,409,372,508,24,428,292,65536,65846,96,408,292,65651,16,64,186,145,17,66030,429,65894,65739,65543,65674,256,65675,65846,1]

theorem envBound60465 : H12AffineFastState.Bounded env60465 := by
  intro p hp
  have h : env60465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60464_60465 : H12AffineEnvironment.transform 10 372 env60464 = env60465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env60464 == env60465) = true)

theorem identity60465 : scanCanonicalize (H12AffineFastState.compose env60465 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound60465 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60466 : List Nat := [2,4,8,16,32,64,128,256,1,409,372,508,24,428,292,171,413,96,408,292,216,16,64,186,145,17,325,429,461,96,172,33,256,32,413,1]

theorem envBound60466 : H12AffineFastState.Bounded env60466 := by
  intro p hp
  have h : env60466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60465_60466 : H12AffineEnvironment.transform 15 171 env60465 = env60466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env60465 == env60466) = true)

theorem identity60466 : scanCanonicalize (H12AffineFastState.compose env60466 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60466 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60467 : List Nat := [2,4,8,16,32,64,128,110,1,247,26,146,24,194,74,171,243,96,246,74,216,16,64,186,145,17,43,195,163,96,172,33,110,32,243,1]

theorem envBound60467 : H12AffineFastState.Bounded env60467 := by
  intro p hp
  have h : env60467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60466_60467 : H12AffineEnvironment.transform 7 110 env60466 = env60467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60466 == env60467) = true)

theorem identity60467 : scanCanonicalize (H12AffineFastState.compose env60467 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60467 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env60468 : List Nat := [2,4,8,16,17,64,128,95,1,198,26,146,24,194,74,154,194,81,199,74,216,16,64,139,145,17,26,195,146,81,157,16,95,17,194,1]

theorem envBound60468 : H12AffineFastState.Bounded env60468 := by
  intro p hp
  have h : env60468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60467_60468 : H12AffineEnvironment.transform 4 17 env60467 = env60468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60467 == env60468) = true)

theorem identity60468 : scanCanonicalize (H12AffineFastState.compose env60468 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound60468 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60469 : List Nat := [2,4,8,16,17,64,89,95,1,31,26,75,24,27,74,67,27,81,30,74,1,16,64,82,72,17,26,26,75,81,68,16,95,17,27,1]

theorem envBound60469 : H12AffineFastState.Bounded env60469 := by
  intro p hp
  have h : env60469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60468_60469 : H12AffineEnvironment.transform 6 89 env60468 = env60469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env60468 == env60469) = true)

theorem identity60469 : scanCanonicalize (H12AffineFastState.compose env60469 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60470 : List Nat := [2,4,8,16,17,17,8,14,1,31,26,26,24,27,27,18,27,0,30,27,1,16,17,3,25,17,26,26,26,0,21,16,14,17,27,1]

theorem envBound60470 : H12AffineFastState.Bounded env60470 := by
  intro p hp
  have h : env60470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60469_60470 : H12AffineEnvironment.transform 5 17 env60469 = env60470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60469 == env60470) = true)

theorem identity60470 : scanCanonicalize (H12AffineFastState.compose env60470 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60470 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60471 : List Nat := [2,4,8,11,10,10,8,14,1,4,1,1,3,0,0,9,0,0,5,0,1,11,10,3,2,10,1,1,1,0,14,11,14,10,0,1]

theorem envBound60471 : H12AffineFastState.Bounded env60471 := by
  intro p hp
  have h : env60471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60470_60471 : H12AffineEnvironment.transform 3 11 env60470 = env60471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60470 == env60471) = true)

def env60472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8388688,134217728,4176,77954,4294794,8463814,149237954,256,136679854,78034,33563273]

theorem envBound60472 : H12AffineFastState.Bounded env60472 := by
  intro p hp
  have h : env60472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58981_60472 : H12AffineEnvironment.transform 13 4177 env58981 = env60472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58981 == env60472) = true)

theorem identity60472 : scanCanonicalize (H12AffineFastState.compose env60472 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound60472 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env60473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388688,134217728,4176,77954,4294794,8463814,149237954,256,136679854,78034,513]

theorem envBound60473 : H12AffineFastState.Bounded env60473 := by
  intro p hp
  have h : env60473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60472_60473 : H12AffineEnvironment.transform 24 8328 env60472 = env60473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env60472 == env60473) = true)

theorem identity60473 : scanCanonicalize (H12AffineFastState.compose env60473 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound60473 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388688,8724554,4176,77954,4294794,8463814,6295688,256,10531300,78034,513]

theorem envBound60474 : H12AffineFastState.Bounded env60474 := by
  intro p hp
  have h : env60474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60473_60474 : H12AffineEnvironment.transform 26 8724554 env60473 = env60474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env60473 == env60474) = true)

theorem identity60474 : scanCanonicalize (H12AffineFastState.compose env60474 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound60474 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,4097,4194304,8388608,8430022,8328,8388688,8724554,4176,77954,4294794,8463814,4194441,256,8430053,78034,513]

theorem envBound60475 : H12AffineFastState.Bounded env60475 := by
  intro p hp
  have h : env60475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60474_60475 : H12AffineEnvironment.transform 20 4097 env60474 = env60475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env60474 == env60475) = true)

theorem identity60475 : scanCanonicalize (H12AffineFastState.compose env60475 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4292675) := by decide +kernel

theorem selectedBound60475 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env60476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,4097,4194304,4292675,4268421,8328,4292627,4497417,4176,77954,4294794,4236677,4194441,256,4268454,78034,513]

theorem envBound60476 : H12AffineFastState.Bounded env60476 := by
  intro p hp
  have h : env60476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60475_60476 : H12AffineEnvironment.transform 22 4292675 env60475 = env60476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292675 env60475 == env60476) = true)

theorem identity60476 : scanCanonicalize (H12AffineFastState.compose env60476 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound60476 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env60477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,4097,397,98766,73736,8328,98718,303492,4176,77954,100615,41992,260,256,73771,78034,513]

theorem envBound60477 : H12AffineFastState.Bounded env60477 := by
  intro p hp
  have h : env60477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60476_60477 : H12AffineEnvironment.transform 21 397 env60476 = env60477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env60476 == env60477) = true)

theorem identity60477 : scanCanonicalize (H12AffineFastState.compose env60477 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound60477 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,8283,4233,262144,1025,32768,4097,397,41365,83,8328,41413,303492,4176,4313,43356,41992,260,256,112,4233,513]

theorem envBound60478 : H12AffineFastState.Bounded env60478 := by
  intro p hp
  have h : env60478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60477_60478 : H12AffineEnvironment.transform 15 8283 env60477 = env60478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env60477 == env60478) = true)

theorem identity60478 : scanCanonicalize (H12AffineFastState.compose env60478 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8433) := by decide +kernel

theorem selectedBound60478 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env60479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8433,8283,4233,262144,1025,8433,4097,397,356,83,8328,308,262517,4176,4313,2477,1273,260,256,112,4233,513]

theorem envBound60479 : H12AffineFastState.Bounded env60479 := by
  intro p hp
  have h : env60479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60478_60479 : H12AffineEnvironment.transform 14 8433 env60478 = env60479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env60478 == env60479) = true)

theorem identity60479 : scanCanonicalize (H12AffineFastState.compose env60479 (packedSelected [2,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60479 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env60480 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8433,8283,4233,262144,1025,8433,4097,33,200,83,8328,152,262361,4176,4313,2049,1273,168,172,112,4233,513]

theorem envBound60480 : H12AffineFastState.Bounded env60480 := by
  intro p hp
  have h : env60480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60479_60480 : H12AffineEnvironment.transform 7 172 env60479 = env60480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60479 == env60480) = true)

theorem identity60480 : scanCanonicalize (H12AffineFastState.compose env60480 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 4680) := by decide +kernel

theorem selectedBound60480 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env60481 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,4680,4177,4793,4627,4233,262144,1025,4793,4097,33,200,83,4800,152,262361,4176,4313,2049,1273,168,172,112,4233,513]

theorem envBound60481 : H12AffineFastState.Bounded env60481 := by
  intro p hp
  have h : env60481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60480_60481 : H12AffineEnvironment.transform 12 4680 env60480 = env60481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4680 env60480 == env60481) = true)

theorem identity60481 : scanCanonicalize (H12AffineFastState.compose env60481 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 5182) := by decide +kernel

theorem selectedBound60481 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60482 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,4680,4177,4793,4627,4233,5182,1025,4793,4097,33,200,83,4800,152,5351,4176,4313,2049,1273,168,172,112,4233,513]

theorem envBound60482 : H12AffineFastState.Bounded env60482 := by
  intro p hp
  have h : env60482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60481_60482 : H12AffineEnvironment.transform 17 5182 env60481 = env60482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5182 env60481 == env60482) = true)

def env60483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131152,4315355,8463814,4294967296,256,4307611965,131073,33563273]

theorem envBound60483 : H12AffineFastState.Bounded env60483 := by
  intro p hp
  have h : env60483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58978_60483 : H12AffineEnvironment.transform 34 131073 env58978 = env60483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58978 == env60483) = true)

theorem identity60483 : scanCanonicalize (H12AffineFastState.compose env60483 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 147157138) := by decide +kernel

theorem selectedBound60483 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env60484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131152,4315355,8463814,147157138,256,134578607,131073,33563273]

theorem envBound60484 : H12AffineFastState.Bounded env60484 := by
  intro p hp
  have h : env60484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60483_60484 : H12AffineEnvironment.transform 31 147157138 env60483 = env60484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 147157138 env60483 == env60484) = true)

theorem identity60484 : scanCanonicalize (H12AffineFastState.compose env60484 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound60484 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env60485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,12992837,16385,131152,4315355,8463814,209367,256,12828906,131073,33563273]

theorem envBound60485 : H12AffineFastState.Bounded env60485 := by
  intro p hp
  have h : env60485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60484_60485 : H12AffineEnvironment.transform 26 12992837 env60484 = env60485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env60484 == env60485) = true)

def env60486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304862,33554432,6342041,2544861,16385,131152,4315355,6402142,209367,256,2315634,131073,33563273]

theorem envBound60486 : H12AffineFastState.Bounded env60486 := by
  intro p hp
  have h : env60486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60485_60486 : H12AffineEnvironment.transform 22 6329752 env60485 = env60486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env60485 == env60486) = true)

def env60487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304862,4247640,6342041,2544861,16385,131152,4315355,6402142,209367,256,2315634,131073,4256465]

theorem envBound60487 : H12AffineFastState.Bounded env60487 := by
  intro p hp
  have h : env60487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60486_60487 : H12AffineEnvironment.transform 24 4247640 env60486 = env60487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env60486 == env60487) = true)

def env60488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269392,144712,169102,2257032,157001,2544861,16385,131152,2324491,200846,209367,256,2315634,131073,2249217]

theorem envBound60488 : H12AffineFastState.Bounded env60488 := by
  intro p hp
  have h : env60488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60487_60488 : H12AffineEnvironment.transform 21 2269392 env60487 = env60488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env60487 == env60488) = true)

def env60489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46480,144712,169102,26056,157001,311709,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60489 : H12AffineFastState.Bounded env60489 := by
  intro p hp
  have h : env60489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60488_60489 : H12AffineEnvironment.transform 20 136512 env60488 = env60489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60488 == env60489) = true)

def env60490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46480,144712,169102,26056,157001,103453,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60490 : H12AffineFastState.Bounded env60490 := by
  intro p hp
  have h : env60490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60489_60490 : H12AffineEnvironment.transform 17 87424 env60489 = env60490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60489 == env60490) = true)

theorem identity60490 : scanCanonicalize (H12AffineFastState.compose env60490 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 118883) := by decide +kernel

theorem selectedBound60490 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,118883,87424,1025,32768,116003,46480,124203,83181,26056,111914,103453,16385,118835,93515,49389,57780,256,81970,118882,18241]

theorem envBound60491 : H12AffineFastState.Bounded env60491 := by
  intro p hp
  have h : env60491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60490_60491 : H12AffineEnvironment.transform 16 118883 env60490 = env60491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 118883 env60490 == env60491) = true)

def env60492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,103715,69824,1025,32768,98403,46480,106603,65965,8328,111914,103453,1345,103795,75787,34221,42228,256,66930,103714,513]

theorem envBound60492 : H12AffineFastState.Bounded env60492 := by
  intro p hp
  have h : env60492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60491_60492 : H12AffineEnvironment.transform 13 1344 env60491 = env60492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60491 == env60492) = true)

theorem identity60492 : scanCanonicalize (H12AffineFastState.compose env60492 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60492 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,445,33886,1025,32768,5373,46480,13557,38195,8328,8628,131,1345,493,48277,34221,42228,256,37356,444,513]

theorem envBound60493 : H12AffineFastState.Bounded env60493 := by
  intro p hp
  have h : env60493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60492_60493 : H12AffineEnvironment.transform 15 38046 env60492 = env60493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60492 == env60493) = true)

theorem identity60493 : scanCanonicalize (H12AffineFastState.compose env60493 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound60493 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,32768,38046,445,33886,1025,32768,5373,37940,5457,38195,300,16,131,1345,493,40241,34221,34128,256,37356,444,513]

theorem envBound60494 : H12AffineFastState.Bounded env60494 := by
  intro p hp
  have h : env60494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60493_60494 : H12AffineEnvironment.transform 12 420 env60493 = env60494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env60493 == env60494) = true)

theorem identity60494 : scanCanonicalize (H12AffineFastState.compose env60494 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60494 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,1108,4298,445,10,1025,1108,5373,4192,5457,4455,300,16,131,1345,493,6501,505,260,256,5560,444,513]

theorem envBound60495 : H12AffineFastState.Bounded env60495 := by
  intro p hp
  have h : env60495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60494_60495 : H12AffineEnvironment.transform 14 1108 env60494 = env60495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env60494 == env60495) = true)

theorem identity60495 : scanCanonicalize (H12AffineFastState.compose env60495 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound60495 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,420,1344,1108,2688,445,10,1025,1108,3767,2602,3867,2861,300,16,131,1345,493,815,505,260,256,4082,444,513]

theorem envBound60496 : H12AffineFastState.Bounded env60496 := by
  intro p hp
  have h : env60496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60495_60496 : H12AffineEnvironment.transform 11 2634 env60495 = env60496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env60495 == env60496) = true)

theorem identity60496 : scanCanonicalize (H12AffineFastState.compose env60496 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60496 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60497 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,2194,420,1344,1108,2136,445,10,1025,1108,3183,2290,3523,2549,300,16,131,1345,493,503,505,260,256,3370,444,217]

theorem envBound60497 : H12AffineFastState.Bounded env60497 := by
  intro p hp
  have h : env60497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60496_60497 : H12AffineEnvironment.transform 8 216 env60496 = env60497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60496 == env60497) = true)

theorem identity60497 : scanCanonicalize (H12AffineFastState.compose env60497 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60497 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env60498 : List Nat := [2,4,8,16,32,64,128,253,216,1024,2048,2194,89,1213,1108,2136,64,10,1025,1108,3183,2290,3134,2056,209,16,131,1212,16,10,4,249,253,3287,65,217]

theorem envBound60498 : H12AffineFastState.Bounded env60498 := by
  intro p hp
  have h : env60498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60497_60498 : H12AffineEnvironment.transform 7 253 env60497 = env60498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60497 == env60498) = true)

theorem identity60498 : scanCanonicalize (H12AffineFastState.compose env60498 (packedSelected [1,4,5,9,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound60498 : packedSelected [1,4,5,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env60499 : List Nat := [2,4,8,16,32,64,128,253,216,172,2048,2194,89,17,248,2136,64,10,173,248,2243,2290,2194,2056,209,16,131,16,16,10,4,249,253,2171,65,217]

theorem envBound60499 : H12AffineFastState.Bounded env60499 := by
  intro p hp
  have h : env60499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60498_60499 : H12AffineEnvironment.transform 9 172 env60498 = env60499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env60498 == env60499) = true)

theorem identity60499 : scanCanonicalize (H12AffineFastState.compose env60499 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound60499 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60500 : List Nat := [2,4,8,16,32,64,128,253,216,172,131,17,89,17,248,219,64,10,173,248,64,113,17,139,209,16,131,16,16,10,4,249,253,248,65,217]

theorem envBound60500 : H12AffineFastState.Bounded env60500 := by
  intro p hp
  have h : env60500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60499_60500 : H12AffineEnvironment.transform 10 131 env60499 = env60500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env60499 == env60500) = true)

theorem identity60500 : scanCanonicalize (H12AffineFastState.compose env60500 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound60500 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60501 : List Nat := [2,4,8,16,32,64,57,68,97,21,58,17,89,17,65,98,64,10,20,65,64,113,17,50,104,16,58,16,16,10,4,64,68,65,65,96]

theorem envBound60501 : H12AffineFastState.Bounded env60501 := by
  intro p hp
  have h : env60501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60500_60501 : H12AffineEnvironment.transform 6 57 env60500 = env60501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env60500 == env60501) = true)

theorem identity60501 : scanCanonicalize (H12AffineFastState.compose env60501 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60501 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60502 : List Nat := [2,4,8,16,32,33,57,37,0,21,58,17,56,17,32,3,33,10,20,32,33,16,17,50,9,16,58,16,16,10,4,33,37,32,32,1]

theorem envBound60502 : H12AffineFastState.Bounded env60502 := by
  intro p hp
  have h : env60502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60501_60502 : H12AffineEnvironment.transform 5 33 env60501 = env60502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60501 == env60502) = true)

def env60503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,103714,69825,1025,32768,98402,46480,106602,65964,8329,111914,103453,1344,103794,75786,34220,42229,256,66931,103715,512]

theorem envBound60503 : H12AffineFastState.Bounded env60503 := by
  intro p hp
  have h : env60503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60491_60503 : H12AffineEnvironment.transform 13 1345 env60491 = env60503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60491 == env60503) = true)

theorem identity60503 : scanCanonicalize (H12AffineFastState.compose env60503 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60503 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,98355,67024,1025,32768,98402,41089,106602,65964,8329,106555,98572,1344,98403,75786,34220,42229,256,66931,98354,512]

theorem envBound60504 : H12AffineFastState.Bounded env60504 := by
  intro p hp
  have h : env60504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60503_60504 : H12AffineEnvironment.transform 11 1297 env60503 = env60504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60503 == env60504) = true)

def env60505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46480,144712,169102,26056,157001,103452,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60505 : H12AffineFastState.Bounded env60505 := by
  intro p hp
  have h : env60505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60489_60505 : H12AffineEnvironment.transform 17 87425 env60489 = env60505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60489 == env60505) = true)

theorem identity60505 : scanCanonicalize (H12AffineFastState.compose env60505 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 103715) := by decide +kernel

theorem selectedBound60505 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103715,87425,1025,32768,98403,46480,106603,65965,26056,127082,103452,16385,103795,93515,34221,42228,256,81970,103714,18241]

theorem envBound60506 : H12AffineFastState.Bounded env60506 := by
  intro p hp
  have h : env60506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60505_60506 : H12AffineEnvironment.transform 16 103715 env60505 = env60506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103715 env60505 == env60506) = true)

def env60507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,103715,69825,1025,32768,98403,46480,106603,65965,8328,111914,103452,1345,103795,75787,34221,42228,256,66930,103714,513]

theorem envBound60507 : H12AffineFastState.Bounded env60507 := by
  intro p hp
  have h : env60507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60506_60507 : H12AffineEnvironment.transform 13 1344 env60506 = env60507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60506 == env60507) = true)

theorem identity60507 : scanCanonicalize (H12AffineFastState.compose env60507 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60507 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,445,33887,1025,32768,5373,46480,13557,38195,8328,8628,130,1345,493,48277,34221,42228,256,37356,444,513]

theorem envBound60508 : H12AffineFastState.Bounded env60508 := by
  intro p hp
  have h : env60508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60507_60508 : H12AffineEnvironment.transform 15 38046 env60507 = env60508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60507 == env60508) = true)

theorem identity60508 : scanCanonicalize (H12AffineFastState.compose env60508 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound60508 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,32768,38046,445,33887,1025,32768,5373,37940,5457,38195,300,16,130,1345,493,40241,34221,34128,256,37356,444,513]

theorem envBound60509 : H12AffineFastState.Bounded env60509 := by
  intro p hp
  have h : env60509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60508_60509 : H12AffineEnvironment.transform 12 420 env60508 = env60509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env60508 == env60509) = true)

theorem identity60509 : scanCanonicalize (H12AffineFastState.compose env60509 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60509 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,1108,4298,445,11,1025,1108,5373,4192,5457,4455,300,16,130,1345,493,6501,505,260,256,5560,444,513]

theorem envBound60510 : H12AffineFastState.Bounded env60510 := by
  intro p hp
  have h : env60510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60509_60510 : H12AffineEnvironment.transform 14 1108 env60509 = env60510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env60509 == env60510) = true)

theorem identity60510 : scanCanonicalize (H12AffineFastState.compose env60510 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound60510 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,420,1344,1108,2688,445,11,1025,1108,3767,2602,3867,2861,300,16,130,1345,493,815,505,260,256,4082,444,513]

theorem envBound60511 : H12AffineFastState.Bounded env60511 := by
  intro p hp
  have h : env60511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60510_60511 : H12AffineEnvironment.transform 11 2634 env60510 = env60511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env60510 == env60511) = true)

theorem identity60511 : scanCanonicalize (H12AffineFastState.compose env60511 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1410) := by decide +kernel

theorem selectedBound60511 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1410,1992,420,1344,1108,1794,445,11,1025,1108,821,1960,665,1711,300,16,130,1345,493,815,505,260,256,624,444,513]

theorem envBound60512 : H12AffineFastState.Bounded env60512 := by
  intro p hp
  have h : env60512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60511_60512 : H12AffineEnvironment.transform 10 1410 env60511 = env60512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1410 env60511 == env60512) = true)

theorem identity60512 : scanCanonicalize (H12AffineFastState.compose env60512 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound60512 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env60513 : List Nat := [2,4,8,16,32,64,128,256,292,1024,1410,1260,420,1344,1108,1062,445,11,1025,1108,17,1164,445,1419,300,16,130,1345,493,11,505,260,256,340,444,293]

theorem envBound60513 : H12AffineFastState.Bounded env60513 := by
  intro p hp
  have h : env60513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60512_60513 : H12AffineEnvironment.transform 8 292 env60512 = env60513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env60512 == env60513) = true)

theorem identity60513 : scanCanonicalize (H12AffineFastState.compose env60513 (packedSelected [1,4,5,9,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound60513 : packedSelected [1,4,5,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env60514 : List Nat := [2,4,8,16,32,64,128,256,292,337,211,445,420,17,261,375,445,11,336,261,17,477,445,218,300,16,130,16,493,11,505,260,256,340,444,293]

theorem envBound60514 : H12AffineFastState.Bounded env60514 := by
  intro p hp
  have h : env60514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60513_60514 : H12AffineEnvironment.transform 9 337 env60513 = env60514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env60513 == env60514) = true)

theorem identity60514 : scanCanonicalize (H12AffineFastState.compose env60514 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60514 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env60515 : List Nat := [2,4,8,16,17,64,128,256,277,337,211,396,405,17,261,326,396,11,336,261,17,477,396,218,285,16,130,16,476,11,456,260,256,340,397,276]

theorem envBound60515 : H12AffineFastState.Bounded env60515 := by
  intro p hp
  have h : env60515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60514_60515 : H12AffineEnvironment.transform 4 17 env60514 = env60515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60514 == env60515) = true)

theorem identity60515 : scanCanonicalize (H12AffineFastState.compose env60515 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60515 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env60516 : List Nat := [2,4,8,16,17,17,128,256,277,256,130,396,405,17,261,279,396,11,257,261,17,396,396,139,285,16,130,16,397,11,409,260,256,261,397,276]

theorem envBound60516 : H12AffineFastState.Bounded env60516 := by
  intro p hp
  have h : env60516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60515_60516 : H12AffineEnvironment.transform 5 17 env60515 = env60516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60515 == env60516) = true)

theorem identity60516 : scanCanonicalize (H12AffineFastState.compose env60516 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60517 : List Nat := [2,4,8,16,17,17,128,21,0,21,130,153,128,17,16,2,153,11,20,16,17,153,153,139,8,16,130,16,152,11,140,17,21,16,152,1]

theorem envBound60517 : H12AffineFastState.Bounded env60517 := by
  intro p hp
  have h : env60517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60516_60517 : H12AffineEnvironment.transform 7 21 env60516 = env60517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60516 == env60517) = true)

theorem identity60517 : scanCanonicalize (H12AffineFastState.compose env60517 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound60517 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60518 : List Nat := [2,4,8,16,17,17,10,21,0,21,8,19,10,17,16,2,19,11,20,16,17,19,19,1,8,16,8,16,18,11,6,17,21,16,18,1]

theorem envBound60518 : H12AffineFastState.Bounded env60518 := by
  intro p hp
  have h : env60518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60517_60518 : H12AffineEnvironment.transform 6 10 env60517 = env60518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env60517 == env60518) = true)

theorem identity60518 : scanCanonicalize (H12AffineFastState.compose env60518 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60518 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60519 : List Nat := [0,4,8,16,17,17,8,21,0,21,8,17,8,17,16,0,17,9,20,16,17,17,17,1,8,16,8,16,16,9,4,17,21,16,16,1]

theorem envBound60519 : H12AffineFastState.Bounded env60519 := by
  intro p hp
  have h : env60519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60518_60519 : H12AffineEnvironment.transform 0 0 env60518 = env60519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60518 == env60519) = true)

def env60520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,103715,69824,1025,32768,98403,46480,106603,65965,8329,111915,103452,1344,103795,75786,34221,42228,256,66931,103714,512]

theorem envBound60520 : H12AffineFastState.Bounded env60520 := by
  intro p hp
  have h : env60520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60506_60520 : H12AffineEnvironment.transform 13 1345 env60506 = env60520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60506 == env60520) = true)

theorem identity60520 : scanCanonicalize (H12AffineFastState.compose env60520 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60520 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,98354,67025,1025,32768,98403,41089,106603,65965,8329,106554,98573,1344,98402,75786,34221,42228,256,66931,98355,512]

theorem envBound60521 : H12AffineFastState.Bounded env60521 := by
  intro p hp
  have h : env60521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60520_60521 : H12AffineEnvironment.transform 11 1297 env60520 = env60521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60520 == env60521) = true)

def env60522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,46481,144712,169102,26057,157001,311708,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60522 : H12AffineFastState.Bounded env60522 := by
  intro p hp
  have h : env60522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60488_60522 : H12AffineEnvironment.transform 20 136513 env60488 = env60522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env60488 == env60522) = true)

def env60523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136513,46481,144712,169102,26057,157001,103452,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60523 : H12AffineFastState.Bounded env60523 := by
  intro p hp
  have h : env60523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60522_60523 : H12AffineEnvironment.transform 17 87424 env60522 = env60523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60522 == env60523) = true)

theorem identity60523 : scanCanonicalize (H12AffineFastState.compose env60523 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 98355) := by decide +kernel

theorem selectedBound60523 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,98355,87424,1025,32768,103794,46481,111995,70845,26057,124282,103452,16385,98403,93514,37053,45540,256,81971,98354,18240]

theorem envBound60524 : H12AffineFastState.Bounded env60524 := by
  intro p hp
  have h : env60524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60523_60524 : H12AffineEnvironment.transform 16 98355 env60523 = env60524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 98355 env60523 == env60524) = true)

def env60525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,98355,69824,1025,32768,103794,46481,111995,70845,8329,106554,103452,1345,98403,75786,37053,45540,256,66931,98354,512]

theorem envBound60525 : H12AffineFastState.Bounded env60525 := by
  intro p hp
  have h : env60525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60524_60525 : H12AffineEnvironment.transform 13 1344 env60524 = env60525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60524 == env60525) = true)

theorem identity60525 : scanCanonicalize (H12AffineFastState.compose env60525 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60525 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,98355,67024,1025,32768,98402,41089,106603,65965,8329,106554,98572,1345,98403,75786,34221,42228,256,66931,98354,512]

theorem envBound60526 : H12AffineFastState.Bounded env60526 := by
  intro p hp
  have h : env60526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60525_60526 : H12AffineEnvironment.transform 11 1296 env60525 = env60526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60525 == env60526) = true)

def env60527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,98355,69825,1025,32768,103794,46481,111995,70845,8328,106555,103452,1344,98403,75787,37053,45540,256,66930,98354,513]

theorem envBound60527 : H12AffineFastState.Bounded env60527 := by
  intro p hp
  have h : env60527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60524_60527 : H12AffineEnvironment.transform 13 1345 env60524 = env60527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60524 == env60527) = true)

theorem identity60527 : scanCanonicalize (H12AffineFastState.compose env60527 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60527 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,5292,33886,1025,32768,493,46481,8676,32802,8328,13476,131,1344,5372,48276,37053,45540,256,37357,5293,513]

theorem envBound60528 : H12AffineFastState.Bounded env60528 := by
  intro p hp
  have h : env60528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60527_60528 : H12AffineEnvironment.transform 15 38047 env60527 = env60528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60527 == env60528) = true)

theorem identity60528 : scanCanonicalize (H12AffineFastState.compose env60528 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound60528 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,32768,38047,5292,33886,1025,32768,493,33061,5456,32802,5180,16,131,1344,5372,34848,37053,34128,256,37357,5293,513]

theorem envBound60529 : H12AffineFastState.Bounded env60529 := by
  intro p hp
  have h : env60529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60528_60529 : H12AffineEnvironment.transform 12 5300 env60528 = env60529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env60528 == env60529) = true)

theorem identity60529 : scanCanonicalize (H12AffineFastState.compose env60529 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60529 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,1108,4299,5292,10,1025,1108,493,1393,5456,1142,5180,16,131,1344,5372,3188,5353,260,256,5561,5293,513]

theorem envBound60530 : H12AffineFastState.Bounded env60530 := by
  intro p hp
  have h : env60530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60529_60530 : H12AffineEnvironment.transform 14 1108 env60529 = env60530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env60529 == env60530) = true)

theorem identity60530 : scanCanonicalize (H12AffineFastState.compose env60530 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound60530 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,3839,1345,1108,2688,3815,10,1025,1108,493,1393,3867,1142,3703,16,131,1344,3767,3188,3746,260,256,4082,3814,513]

theorem envBound60531 : H12AffineFastState.Bounded env60531 := by
  intro p hp
  have h : env60531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60530_60531 : H12AffineEnvironment.transform 11 2635 env60530 = env60531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env60530 == env60531) = true)

theorem identity60531 : scanCanonicalize (H12AffineFastState.compose env60531 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound60531 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60532 : List Nat := [2,4,8,16,32,64,128,256,512,549,2048,2635,2266,868,625,2688,2242,10,548,625,493,852,2366,595,2130,16,131,869,2194,2641,2183,260,256,2519,2243,513]

theorem envBound60532 : H12AffineFastState.Bounded env60532 := by
  intro p hp
  have h : env60532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60531_60532 : H12AffineEnvironment.transform 9 549 env60531 = env60532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env60531 == env60532) = true)

theorem identity60532 : scanCanonicalize (H12AffineFastState.compose env60532 (packedSelected [1,5,10,16,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound60532 : packedSelected [1,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env60533 : List Nat := [2,4,8,16,32,64,128,256,512,549,602,17,640,868,625,218,664,10,548,625,493,852,868,595,520,16,131,869,712,11,733,260,256,909,665,513]

theorem envBound60533 : H12AffineFastState.Bounded env60533 := by
  intro p hp
  have h : env60533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60532_60533 : H12AffineEnvironment.transform 10 602 env60532 = env60533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env60532 == env60533) = true)

theorem identity60533 : scanCanonicalize (H12AffineFastState.compose env60533 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound60533 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env60534 : List Nat := [2,4,8,16,32,64,128,256,137,172,211,17,9,493,248,218,17,10,173,248,493,477,493,218,129,16,131,492,65,11,84,260,256,260,16,136]

theorem envBound60534 : H12AffineFastState.Bounded env60534 := by
  intro p hp
  have h : env60534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60533_60534 : H12AffineEnvironment.transform 8 137 env60533 = env60534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env60533 == env60534) = true)

def env60535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136513,46481,144712,169102,26057,157001,103453,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60535 : H12AffineFastState.Bounded env60535 := by
  intro p hp
  have h : env60535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60522_60535 : H12AffineEnvironment.transform 17 87425 env60522 = env60535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60522 == env60535) = true)

theorem identity60535 : scanCanonicalize (H12AffineFastState.compose env60535 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 116082) := by decide +kernel

theorem selectedBound60535 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,116082,87425,1025,32768,118835,46481,127034,86524,26057,106555,103453,16385,116002,93514,54780,62629,256,81971,116083,18240]

theorem envBound60536 : H12AffineFastState.Bounded env60536 := by
  intro p hp
  have h : env60536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60535_60536 : H12AffineEnvironment.transform 16 116082 env60535 = env60536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 116082 env60535 == env60536) = true)

def env60537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,98354,69825,1025,32768,103795,46481,111994,70844,8329,106555,103453,1345,98402,75786,37052,45541,256,66931,98355,512]

theorem envBound60537 : H12AffineFastState.Bounded env60537 := by
  intro p hp
  have h : env60537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60536_60537 : H12AffineEnvironment.transform 13 1344 env60536 = env60537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60536 == env60537) = true)

theorem identity60537 : scanCanonicalize (H12AffineFastState.compose env60537 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60537 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,98354,67025,1025,32768,98403,41089,106602,65964,8329,106555,98573,1345,98402,75786,34220,42229,256,66931,98355,512]

theorem envBound60538 : H12AffineFastState.Bounded env60538 := by
  intro p hp
  have h : env60538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60537_60538 : H12AffineEnvironment.transform 11 1296 env60537 = env60538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60537 == env60538) = true)

def env60539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,98355,69824,1025,32768,103794,46481,111995,70845,8328,106555,103453,1344,98403,75787,37053,45540,256,66930,98354,513]

theorem envBound60539 : H12AffineFastState.Bounded env60539 := by
  intro p hp
  have h : env60539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60536_60539 : H12AffineEnvironment.transform 13 1345 env60536 = env60539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60536 == env60539) = true)

theorem identity60539 : scanCanonicalize (H12AffineFastState.compose env60539 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60539 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,5292,33887,1025,32768,493,46481,8676,32802,8328,13476,130,1344,5372,48276,37053,45540,256,37357,5293,513]

theorem envBound60540 : H12AffineFastState.Bounded env60540 := by
  intro p hp
  have h : env60540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60539_60540 : H12AffineEnvironment.transform 15 38047 env60539 = env60540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60539 == env60540) = true)

theorem identity60540 : scanCanonicalize (H12AffineFastState.compose env60540 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound60540 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,32768,38047,5292,33887,1025,32768,493,33061,5456,32802,5180,16,130,1344,5372,34848,37053,34128,256,37357,5293,513]

theorem envBound60541 : H12AffineFastState.Bounded env60541 := by
  intro p hp
  have h : env60541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60540_60541 : H12AffineEnvironment.transform 12 5300 env60540 = env60541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env60540 == env60541) = true)

theorem identity60541 : scanCanonicalize (H12AffineFastState.compose env60541 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60541 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,1108,4299,5292,11,1025,1108,493,1393,5456,1142,5180,16,130,1344,5372,3188,5353,260,256,5561,5293,513]

theorem envBound60542 : H12AffineFastState.Bounded env60542 := by
  intro p hp
  have h : env60542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60541_60542 : H12AffineEnvironment.transform 14 1108 env60541 = env60542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env60541 == env60542) = true)

theorem identity60542 : scanCanonicalize (H12AffineFastState.compose env60542 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound60542 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,3839,1345,1108,2688,3815,11,1025,1108,493,1393,3867,1142,3703,16,130,1344,3767,3188,3746,260,256,4082,3814,513]

theorem envBound60543 : H12AffineFastState.Bounded env60543 := by
  intro p hp
  have h : env60543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60542_60543 : H12AffineEnvironment.transform 11 2635 env60542 = env60543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env60542 == env60543) = true)

theorem identity60543 : scanCanonicalize (H12AffineFastState.compose env60543 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound60543 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,383,820,1920,1345,1108,1023,1944,11,1025,1108,493,1393,1636,1142,1800,16,130,1344,1992,1291,2013,260,256,1677,1945,513]

theorem envBound60544 : H12AffineFastState.Bounded env60544 := by
  intro p hp
  have h : env60544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60543_60544 : H12AffineEnvironment.transform 10 383 env60543 = env60544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env60543 == env60544) = true)

theorem identity60544 : scanCanonicalize (H12AffineFastState.compose env60544 (packedSelected [1,5,10,16,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound60544 : packedSelected [1,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env60545 : List Nat := [2,4,8,16,32,64,128,256,512,257,383,820,641,64,341,1023,665,11,256,341,493,112,869,375,521,16,130,65,713,10,732,260,256,908,664,513]

theorem envBound60545 : H12AffineFastState.Bounded env60545 := by
  intro p hp
  have h : env60545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60544_60545 : H12AffineEnvironment.transform 9 257 env60544 = env60545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env60544 == env60545) = true)

theorem identity60545 : scanCanonicalize (H12AffineFastState.compose env60545 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound60545 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env60546 : List Nat := [2,4,8,16,32,64,128,256,136,257,383,444,9,64,341,375,17,11,256,341,493,112,493,375,129,16,130,65,65,10,84,260,256,260,16,137]

theorem envBound60546 : H12AffineFastState.Bounded env60546 := by
  intro p hp
  have h : env60546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60545_60546 : H12AffineEnvironment.transform 8 136 env60545 = env60546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env60545 == env60546) = true)

def env60547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269393,144713,169103,2257033,157000,2544861,16385,131152,2324490,200847,209367,256,2315634,131073,2249216]

theorem envBound60547 : H12AffineFastState.Bounded env60547 := by
  intro p hp
  have h : env60547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60487_60547 : H12AffineEnvironment.transform 21 2269393 env60487 = env60547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env60487 == env60547) = true)

def env60548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46481,144713,169103,26057,157000,311709,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60548 : H12AffineFastState.Bounded env60548 := by
  intro p hp
  have h : env60548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60547_60548 : H12AffineEnvironment.transform 20 136512 env60547 = env60548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60547 == env60548) = true)

def env60549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46481,144713,169103,26057,157000,103453,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60549 : H12AffineFastState.Bounded env60549 := by
  intro p hp
  have h : env60549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60548_60549 : H12AffineEnvironment.transform 17 87424 env60548 = env60549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60548 == env60549) = true)

theorem identity60549 : scanCanonicalize (H12AffineFastState.compose env60549 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 122923) := by decide +kernel

theorem selectedBound60549 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122923,87424,1025,32768,128363,46481,120162,95396,26057,99683,103453,16385,123003,93514,61604,53756,256,81970,122922,18240]

theorem envBound60550 : H12AffineFastState.Bounded env60550 := by
  intro p hp
  have h : env60550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60549_60550 : H12AffineEnvironment.transform 16 122923 env60549 = env60550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122923 env60549 == env60550) = true)

def env60551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,107883,69824,1025,32768,110635,46481,102434,78308,8329,99683,103453,1345,107835,75786,46564,38076,256,66930,107882,512]

theorem envBound60551 : H12AffineFastState.Bounded env60551 := by
  intro p hp
  have h : env60551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60550_60551 : H12AffineEnvironment.transform 13 1344 env60550 = env60551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60550 == env60551) = true)

theorem identity60551 : scanCanonicalize (H12AffineFastState.compose env60551 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60551 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,107883,67024,1025,32768,107835,41089,99634,74996,8329,99683,98573,1345,107835,75786,41204,33196,256,66930,107882,512]

theorem envBound60552 : H12AffineFastState.Bounded env60552 := by
  intro p hp
  have h : env60552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60551_60552 : H12AffineEnvironment.transform 11 1296 env60551 = env60552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60551 == env60552) = true)

def env60553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,107882,69825,1025,32768,110634,46481,102435,78309,8328,99683,103453,1344,107834,75787,46565,38077,256,66931,107883,513]

theorem envBound60553 : H12AffineFastState.Bounded env60553 := by
  intro p hp
  have h : env60553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60550_60553 : H12AffineEnvironment.transform 13 1345 env60550 = env60553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60550 == env60553) = true)

theorem identity60553 : scanCanonicalize (H12AffineFastState.compose env60553 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60553 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,12788,33887,1025,32768,9396,46481,1213,42363,8328,4605,131,1344,12708,48277,46565,38077,256,37357,12789,513]

theorem envBound60554 : H12AffineFastState.Bounded env60554 := by
  intro p hp
  have h : env60554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60553_60554 : H12AffineEnvironment.transform 15 38046 env60553 = env60554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60553 == env60554) = true)

theorem identity60554 : scanCanonicalize (H12AffineFastState.compose env60554 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound60554 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,32768,34162,8216,33887,1025,32768,9396,42109,1213,42363,8328,17,131,1344,8264,44409,41993,34129,256,32769,8217,513]

theorem envBound60555 : H12AffineFastState.Bounded env60555 := by
  intro p hp
  have h : env60555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60554_60555 : H12AffineEnvironment.transform 11 492 env60554 = env60555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env60554 == env60555) = true)

theorem identity60555 : scanCanonicalize (H12AffineFastState.compose env60555 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound60555 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,1109,295,8216,10,1025,1109,9396,8232,1213,8494,8328,17,131,1344,8264,10540,8284,260,256,1108,8217,513]

theorem envBound60556 : H12AffineFastState.Bounded env60556 := by
  intro p hp
  have h : env60556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60555_60556 : H12AffineEnvironment.transform 14 1109 env60555 = env60556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env60555 == env60556) = true)

theorem identity60556 : scanCanonicalize (H12AffineFastState.compose env60556 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound60556 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,523,492,8192,1345,1109,295,8216,10,1025,1109,9396,8232,1213,8494,8328,17,131,1344,8264,8999,8284,260,256,1108,8217,513]

theorem envBound60557 : H12AffineFastState.Bounded env60557 := by
  intro p hp
  have h : env60557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60556_60557 : H12AffineEnvironment.transform 10 523 env60556 = env60557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env60556 == env60557) = true)

theorem identity60557 : scanCanonicalize (H12AffineFastState.compose env60557 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60557 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,523,492,421,1345,1109,295,445,10,1025,1109,1297,397,1213,139,301,17,131,1344,493,642,505,260,256,1108,444,513]

theorem envBound60558 : H12AffineFastState.Bounded env60558 := by
  intro p hp
  have h : env60558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60557_60558 : H12AffineEnvironment.transform 12 421 env60557 = env60558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60557 == env60558) = true)

theorem identity60558 : scanCanonicalize (H12AffineFastState.compose env60558 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound60558 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60559 : List Nat := [2,4,8,16,32,64,128,256,512,904,523,492,421,713,989,295,445,10,905,989,665,397,821,139,301,17,131,712,493,642,505,260,256,988,444,513]

theorem envBound60559 : H12AffineFastState.Bounded env60559 := by
  intro p hp
  have h : env60559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60558_60559 : H12AffineEnvironment.transform 9 904 env60558 = env60559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env60558 == env60559) = true)

theorem identity60559 : scanCanonicalize (H12AffineFastState.compose env60559 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60559 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env60560 : List Nat := [2,4,8,16,32,64,34,256,512,810,523,334,263,619,895,295,287,10,811,895,571,303,821,41,301,17,33,618,335,544,347,260,256,894,286,513]

theorem envBound60560 : H12AffineFastState.Bounded env60560 := by
  intro p hp
  have h : env60560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60559_60560 : H12AffineEnvironment.transform 6 34 env60559 = env60560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60559 == env60560) = true)

theorem identity60560 : scanCanonicalize (H12AffineFastState.compose env60560 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60560 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60561 : List Nat := [2,4,8,16,32,16,34,256,512,810,523,286,263,571,815,295,287,10,811,815,571,303,821,41,301,17,33,570,287,544,267,260,256,814,286,513]

theorem envBound60561 : H12AffineFastState.Bounded env60561 := by
  intro p hp
  have h : env60561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60560_60561 : H12AffineEnvironment.transform 5 16 env60560 = env60561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60560 == env60561) = true)

theorem identity60561 : scanCanonicalize (H12AffineFastState.compose env60561 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60561 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env60562 : List Nat := [1,4,8,16,32,16,33,256,512,809,520,285,260,568,812,292,284,9,808,812,568,300,821,41,301,17,33,569,284,544,264,260,256,813,285,513]

theorem envBound60562 : H12AffineFastState.Bounded env60562 := by
  intro p hp
  have h : env60562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60561_60562 : H12AffineEnvironment.transform 0 1 env60561 = env60562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60561 == env60562) = true)

theorem identity60562 : scanCanonicalize (H12AffineFastState.compose env60562 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 29) := by decide +kernel

theorem selectedBound60562 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env60563 : List Nat := [1,4,8,16,32,16,33,29,512,564,520,0,25,568,561,57,1,9,565,561,568,49,552,41,48,17,33,569,1,544,21,25,29,560,0,513]

theorem envBound60563 : H12AffineFastState.Bounded env60563 := by
  intro p hp
  have h : env60563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60562_60563 : H12AffineEnvironment.transform 7 29 env60562 = env60563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 29 env60562 == env60563) = true)

theorem identity60563 : scanCanonicalize (H12AffineFastState.compose env60563 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60563 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60564 : List Nat := [1,4,8,0,32,0,33,13,512,548,520,0,9,552,545,41,1,9,549,545,552,33,552,41,32,1,33,553,1,544,5,9,13,544,0,513]

theorem envBound60564 : H12AffineFastState.Bounded env60564 := by
  intro p hp
  have h : env60564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60563_60564 : H12AffineEnvironment.transform 3 0 env60563 = env60564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60563 == env60564) = true)

theorem identity60564 : scanCanonicalize (H12AffineFastState.compose env60564 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound60564 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60565 : List Nat := [1,4,8,0,32,0,33,13,8,44,0,0,9,32,41,41,1,9,45,41,32,33,32,41,32,1,33,33,1,40,5,9,13,40,0,9]

theorem envBound60565 : H12AffineFastState.Bounded env60565 := by
  intro p hp
  have h : env60565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60564_60565 : H12AffineEnvironment.transform 8 8 env60564 = env60565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env60564 == env60565) = true)

theorem identity60565 : scanCanonicalize (H12AffineFastState.compose env60565 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60565 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env60566 : List Nat := [1,4,8,0,9,0,8,13,8,5,0,0,9,9,0,0,1,9,4,0,9,8,9,0,9,1,8,8,1,1,5,9,13,1,0,9]

theorem envBound60566 : H12AffineFastState.Bounded env60566 := by
  intro p hp
  have h : env60566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60565_60566 : H12AffineEnvironment.transform 4 9 env60565 = env60566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60565 == env60566) = true)

theorem identity60566 : scanCanonicalize (H12AffineFastState.compose env60566 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60567 : List Nat := [1,4,1,0,0,0,1,4,1,5,0,0,0,0,0,0,1,0,4,0,0,1,0,0,0,1,1,1,1,1,5,0,4,1,0,0]

theorem envBound60567 : H12AffineFastState.Bounded env60567 := by
  intro p hp
  have h : env60567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60566_60567 : H12AffineEnvironment.transform 2 1 env60566 = env60567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60566 == env60567) = true)

def env60568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46481,144713,169103,26057,157000,103452,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60568 : H12AffineFastState.Bounded env60568 := by
  intro p hp
  have h : env60568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60548_60568 : H12AffineEnvironment.transform 17 87425 env60548 = env60568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60548 == env60568) = true)

theorem identity60568 : scanCanonicalize (H12AffineFastState.compose env60568 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 107882) := by decide +kernel

theorem selectedBound60568 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,107882,87425,1025,32768,110634,46481,102435,78309,26057,114722,103452,16385,107834,93514,46565,38077,256,81970,107883,18240]

theorem envBound60569 : H12AffineFastState.Bounded env60569 := by
  intro p hp
  have h : env60569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60568_60569 : H12AffineEnvironment.transform 16 107882 env60568 = env60569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 107882 env60568 == env60569) = true)

def env60570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,107882,69825,1025,32768,110634,46481,102435,78309,8329,99682,103452,1345,107834,75786,46565,38077,256,66930,107883,512]

theorem envBound60570 : H12AffineFastState.Bounded env60570 := by
  intro p hp
  have h : env60570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60569_60570 : H12AffineEnvironment.transform 13 1344 env60569 = env60570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60569 == env60570) = true)

theorem identity60570 : scanCanonicalize (H12AffineFastState.compose env60570 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60570 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,107882,67025,1025,32768,107834,41089,99635,74997,8329,99682,98572,1345,107834,75786,41205,33197,256,66930,107883,512]

theorem envBound60571 : H12AffineFastState.Bounded env60571 := by
  intro p hp
  have h : env60571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60570_60571 : H12AffineEnvironment.transform 11 1296 env60570 = env60571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60570 == env60571) = true)

def env60572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,107882,69824,1025,32768,110634,46481,102435,78309,8328,99683,103452,1344,107834,75787,46565,38077,256,66931,107883,513]

theorem envBound60572 : H12AffineFastState.Bounded env60572 := by
  intro p hp
  have h : env60572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60569_60572 : H12AffineEnvironment.transform 13 1345 env60569 = env60572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60569 == env60572) = true)

theorem identity60572 : scanCanonicalize (H12AffineFastState.compose env60572 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60572 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,12788,33886,1025,32768,9396,46481,1213,42363,8328,4605,130,1344,12708,48277,46565,38077,256,37357,12789,513]

theorem envBound60573 : H12AffineFastState.Bounded env60573 := by
  intro p hp
  have h : env60573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60572_60573 : H12AffineEnvironment.transform 15 38046 env60572 = env60573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60572 == env60573) = true)

theorem identity60573 : scanCanonicalize (H12AffineFastState.compose env60573 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound60573 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,32768,34162,8216,33886,1025,32768,9396,42109,1213,42363,8328,17,130,1344,8264,44409,41993,34129,256,32769,8217,513]

theorem envBound60574 : H12AffineFastState.Bounded env60574 := by
  intro p hp
  have h : env60574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60573_60574 : H12AffineEnvironment.transform 11 492 env60573 = env60574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env60573 == env60574) = true)

theorem identity60574 : scanCanonicalize (H12AffineFastState.compose env60574 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound60574 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,1109,295,8216,11,1025,1109,9396,8232,1213,8494,8328,17,130,1344,8264,10540,8284,260,256,1108,8217,513]

theorem envBound60575 : H12AffineFastState.Bounded env60575 := by
  intro p hp
  have h : env60575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60574_60575 : H12AffineEnvironment.transform 14 1109 env60574 = env60575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env60574 == env60575) = true)

theorem identity60575 : scanCanonicalize (H12AffineFastState.compose env60575 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound60575 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,523,492,8192,1345,1109,295,8216,11,1025,1109,9396,8232,1213,8494,8328,17,130,1344,8264,8999,8284,260,256,1108,8217,513]

theorem envBound60576 : H12AffineFastState.Bounded env60576 := by
  intro p hp
  have h : env60576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60575_60576 : H12AffineEnvironment.transform 10 523 env60575 = env60576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env60575 == env60576) = true)

theorem identity60576 : scanCanonicalize (H12AffineFastState.compose env60576 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60576 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,523,492,421,1345,1109,295,445,11,1025,1109,1297,397,1213,139,301,17,130,1344,493,642,505,260,256,1108,444,513]

theorem envBound60577 : H12AffineFastState.Bounded env60577 := by
  intro p hp
  have h : env60577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60576_60577 : H12AffineEnvironment.transform 12 421 env60576 = env60577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60576 == env60577) = true)

theorem identity60577 : scanCanonicalize (H12AffineFastState.compose env60577 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound60577 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60578 : List Nat := [2,4,8,16,32,64,128,256,512,904,523,492,421,713,989,295,445,11,905,989,665,397,821,139,301,17,130,712,493,642,505,260,256,988,444,513]

theorem envBound60578 : H12AffineFastState.Bounded env60578 := by
  intro p hp
  have h : env60578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60577_60578 : H12AffineEnvironment.transform 9 904 env60577 = env60578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env60577 == env60578) = true)

theorem identity60578 : scanCanonicalize (H12AffineFastState.compose env60578 (packedSelected [3,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound60578 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env60579 : List Nat := [2,4,8,16,32,64,128,256,391,15,396,492,421,334,90,295,445,11,14,90,286,397,178,139,301,17,130,335,493,261,505,260,256,91,444,390]

theorem envBound60579 : H12AffineFastState.Bounded env60579 := by
  intro p hp
  have h : env60579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60578_60579 : H12AffineEnvironment.transform 8 391 env60578 = env60579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env60578 == env60579) = true)

theorem identity60579 : scanCanonicalize (H12AffineFastState.compose env60579 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60579 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60580 : List Nat := [2,4,8,16,32,64,128,94,217,15,210,178,251,16,90,121,227,11,14,90,64,211,178,139,115,17,130,17,179,91,167,90,94,91,226,216]

theorem envBound60580 : H12AffineFastState.Bounded env60580 := by
  intro p hp
  have h : env60580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60579_60580 : H12AffineEnvironment.transform 7 94 env60579 = env60580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60579 == env60580) = true)

theorem identity60580 : scanCanonicalize (H12AffineFastState.compose env60580 (packedSelected [2,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 32) := by decide +kernel

theorem selectedBound60580 : packedSelected [2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60581 : List Nat := [2,4,8,16,32,64,32,94,121,15,114,18,91,16,90,121,67,11,14,90,64,115,18,43,115,17,34,17,19,91,7,90,94,91,66,120]

theorem envBound60581 : H12AffineFastState.Bounded env60581 := by
  intro p hp
  have h : env60581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60580_60581 : H12AffineEnvironment.transform 6 32 env60580 = env60581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 32 env60580 == env60581) = true)

theorem identity60581 : scanCanonicalize (H12AffineFastState.compose env60581 (packedSelected [4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound60581 : packedSelected [4,5,11] rootPS < 2^1333 := by decide +kernel

def env60582 : List Nat := [2,4,8,16,32,18,32,12,43,15,32,18,9,16,8,43,17,11,14,8,18,33,18,43,33,17,34,17,19,9,7,8,12,9,16,42]

theorem envBound60582 : H12AffineFastState.Bounded env60582 := by
  intro p hp
  have h : env60582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60581_60582 : H12AffineEnvironment.transform 5 18 env60581 = env60582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env60581 == env60582) = true)

theorem identity60582 : scanCanonicalize (H12AffineFastState.compose env60582 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound60582 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60583 : List Nat := [2,4,8,16,3,18,3,12,8,15,3,18,9,16,8,8,17,11,14,8,18,2,18,8,2,17,1,17,19,9,7,8,12,9,16,9]

theorem envBound60583 : H12AffineFastState.Bounded env60583 := by
  intro p hp
  have h : env60583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60582_60583 : H12AffineEnvironment.transform 4 3 env60582 = env60583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env60582 == env60583) = true)

theorem identity60583 : scanCanonicalize (H12AffineFastState.compose env60583 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60584 : List Nat := [2,4,8,10,3,8,3,12,8,15,3,8,9,10,8,8,11,11,14,8,8,2,8,8,2,11,1,11,9,9,7,8,12,9,10,9]

theorem envBound60584 : H12AffineFastState.Bounded env60584 := by
  intro p hp
  have h : env60584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60583_60584 : H12AffineEnvironment.transform 3 10 env60583 = env60584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60583 == env60584) = true)

theorem identity60584 : scanCanonicalize (H12AffineFastState.compose env60584 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60584 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60585 : List Nat := [0,4,8,8,1,8,1,12,8,13,1,8,9,8,8,8,9,9,12,8,8,0,8,8,0,9,1,9,9,9,5,8,12,9,8,9]

theorem envBound60585 : H12AffineFastState.Bounded env60585 := by
  intro p hp
  have h : env60585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60584_60585 : H12AffineEnvironment.transform 0 0 env60584 = env60585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60584 == env60585) = true)

theorem identity60585 : scanCanonicalize (H12AffineFastState.compose env60585 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60586 : List Nat := [0,4,0,0,1,0,1,4,0,5,1,0,1,0,0,0,1,1,4,0,0,0,0,0,0,1,1,1,1,1,5,0,4,1,0,1]

theorem envBound60586 : H12AffineFastState.Bounded env60586 := by
  intro p hp
  have h : env60586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60585_60586 : H12AffineEnvironment.transform 2 0 env60585 = env60586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60585 == env60586) = true)

def env60587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,46480,144713,169103,26056,157000,311708,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60587 : H12AffineFastState.Bounded env60587 := by
  intro p hp
  have h : env60587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60547_60587 : H12AffineEnvironment.transform 20 136513 env60547 = env60587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env60547 == env60587) = true)

def env60588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136513,46480,144713,169103,26056,157000,103452,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60588 : H12AffineFastState.Bounded env60588 := by
  intro p hp
  have h : env60588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60587_60588 : H12AffineEnvironment.transform 17 87424 env60587 = env60588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60587 == env60588) = true)

theorem identity60588 : scanCanonicalize (H12AffineFastState.compose env60588 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 110714) := by decide +kernel

theorem selectedBound60588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,110714,87424,1025,32768,107835,46480,99635,74997,26056,120114,103452,16385,110634,93515,41205,33197,256,81971,110715,18241]

theorem envBound60589 : H12AffineFastState.Bounded env60589 := by
  intro p hp
  have h : env60589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60588_60589 : H12AffineEnvironment.transform 16 110714 env60588 = env60589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110714 env60588 == env60589) = true)

def env60590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,110714,69824,1025,32768,107835,46480,99635,74997,8328,102514,103452,1345,110634,75787,41205,33197,256,66931,110715,513]

theorem envBound60590 : H12AffineFastState.Bounded env60590 := by
  intro p hp
  have h : env60590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60589_60590 : H12AffineEnvironment.transform 13 1344 env60589 = env60590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60589 == env60590) = true)

theorem identity60590 : scanCanonicalize (H12AffineFastState.compose env60590 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60590 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,9445,33887,1025,32768,12708,46480,4524,45162,8328,1261,131,1345,9397,48276,41205,33197,256,37356,9444,513]

theorem envBound60591 : H12AffineFastState.Bounded env60591 := by
  intro p hp
  have h : env60591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60590_60591 : H12AffineEnvironment.transform 15 38047 env60590 = env60591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60590 == env60591) = true)

theorem identity60591 : scanCanonicalize (H12AffineFastState.compose env60591 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound60591 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60592 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,32768,36963,8217,32931,253,32768,12708,45420,4524,45162,8328,17,131,445,8265,47208,41205,33197,256,37356,8216,513]

theorem envBound60592 : H12AffineFastState.Bounded env60592 := by
  intro p hp
  have h : env60592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60591_60592 : H12AffineEnvironment.transform 9 252 env60591 = env60592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env60591 == env60592) = true)

theorem identity60592 : scanCanonicalize (H12AffineFastState.compose env60592 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound60592 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60593 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,169,4298,8217,10,253,169,12708,12741,4524,12483,8328,17,131,445,8265,14529,8284,260,256,4421,8216,513]

theorem envBound60593 : H12AffineFastState.Bounded env60593 := by
  intro p hp
  have h : env60593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60592_60593 : H12AffineEnvironment.transform 14 169 env60592 = env60593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env60592 == env60593) = true)

theorem identity60593 : scanCanonicalize (H12AffineFastState.compose env60593 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3046) := by decide +kernel

theorem selectedBound60593 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60594 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,3046,8192,444,169,2860,8217,10,253,169,10818,10787,2634,11045,8328,17,131,445,8265,8999,8284,260,256,2723,8216,513]

theorem envBound60594 : H12AffineFastState.Bounded env60594 := by
  intro p hp
  have h : env60594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60593_60594 : H12AffineEnvironment.transform 11 3046 env60593 = env60594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3046 env60593 == env60594) = true)

theorem identity60594 : scanCanonicalize (H12AffineFastState.compose env60594 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound60594 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60595 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,3046,2990,444,169,2860,2999,10,253,169,492,397,2634,139,2854,17,131,445,3047,2185,3058,260,256,2723,2998,513]

theorem envBound60595 : H12AffineFastState.Bounded env60595 := by
  intro p hp
  have h : env60595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60594_60595 : H12AffineEnvironment.transform 12 2990 env60594 = env60595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env60594 == env60595) = true)

theorem identity60595 : scanCanonicalize (H12AffineFastState.compose env60595 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 382) := by decide +kernel

theorem selectedBound60595 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60596 : List Nat := [2,4,8,16,32,64,128,256,512,252,382,664,720,444,169,594,713,10,253,169,492,397,820,139,600,17,131,445,665,503,652,260,256,989,712,513]

theorem envBound60596 : H12AffineFastState.Bounded env60596 := by
  intro p hp
  have h : env60596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60595_60596 : H12AffineEnvironment.transform 10 382 env60595 = env60596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 382 env60595 == env60596) = true)

theorem identity60596 : scanCanonicalize (H12AffineFastState.compose env60596 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound60596 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60597 : List Nat := [2,4,8,16,32,64,128,256,123,252,382,227,171,444,169,41,178,10,253,169,492,397,335,139,35,17,131,445,226,503,247,260,256,422,179,122]

theorem envBound60597 : H12AffineFastState.Bounded env60597 := by
  intro p hp
  have h : env60597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60596_60597 : H12AffineEnvironment.transform 8 123 env60596 = env60597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env60596 == env60597) = true)

theorem identity60597 : scanCanonicalize (H12AffineFastState.compose env60597 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60597 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env60598 : List Nat := [2,4,8,16,32,17,128,256,42,173,303,178,171,444,169,41,178,10,172,169,445,397,286,139,35,17,131,445,179,422,166,260,256,422,179,43]

theorem envBound60598 : H12AffineFastState.Bounded env60598 := by
  intro p hp
  have h : env60598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60597_60598 : H12AffineEnvironment.transform 5 17 env60597 = env60598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60597 == env60598) = true)

theorem identity60598 : scanCanonicalize (H12AffineFastState.compose env60598 (packedSelected [2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 60) := by decide +kernel

theorem selectedBound60598 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env60599 : List Nat := [2,4,8,16,32,17,128,60,42,173,19,178,171,128,169,41,178,10,172,169,129,177,34,139,35,17,131,129,179,154,166,56,60,154,179,43]

theorem envBound60599 : H12AffineFastState.Bounded env60599 := by
  intro p hp
  have h : env60599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60598_60599 : H12AffineEnvironment.transform 7 60 env60598 = env60599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 60 env60598 == env60599) = true)

theorem identity60599 : scanCanonicalize (H12AffineFastState.compose env60599 (packedSelected [2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound60599 : packedSelected [2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60600 : List Nat := [2,4,8,16,32,17,26,60,42,55,19,40,49,26,51,41,40,10,54,51,27,43,34,17,35,17,25,27,41,0,60,56,60,0,41,43]

theorem envBound60600 : H12AffineFastState.Bounded env60600 := by
  intro p hp
  have h : env60600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60599_60600 : H12AffineEnvironment.transform 6 26 env60599 = env60600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env60599 == env60600) = true)

theorem identity60600 : scanCanonicalize (H12AffineFastState.compose env60600 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60600 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60601 : List Nat := [2,4,8,16,2,17,26,30,8,21,19,10,19,26,17,11,10,10,20,17,27,9,0,17,1,17,25,27,11,0,30,26,30,0,11,9]

theorem envBound60601 : H12AffineFastState.Bounded env60601 := by
  intro p hp
  have h : env60601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60600_60601 : H12AffineEnvironment.transform 4 2 env60600 = env60601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60600 == env60601) = true)

theorem identity60601 : scanCanonicalize (H12AffineFastState.compose env60601 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60602 : List Nat := [2,4,0,16,2,17,18,22,0,21,19,2,19,18,17,3,2,2,20,17,19,1,0,17,1,17,17,19,3,0,22,18,22,0,3,1]

theorem envBound60602 : H12AffineFastState.Bounded env60602 := by
  intro p hp
  have h : env60602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60601_60602 : H12AffineEnvironment.transform 2 0 env60601 = env60602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60601 == env60602) = true)

theorem identity60602 : scanCanonicalize (H12AffineFastState.compose env60602 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60602 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60603 : List Nat := [2,4,0,2,2,3,0,4,0,7,1,2,1,0,3,3,2,2,6,3,1,1,0,3,1,3,3,1,3,0,4,0,4,0,3,1]

theorem envBound60603 : H12AffineFastState.Bounded env60603 := by
  intro p hp
  have h : env60603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60602_60603 : H12AffineEnvironment.transform 3 2 env60602 = env60603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60602 == env60603) = true)

theorem identity60603 : scanCanonicalize (H12AffineFastState.compose env60603 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60604 : List Nat := [1,4,0,1,1,0,0,4,0,4,1,1,1,0,0,0,1,1,5,0,1,1,0,0,1,0,0,1,0,0,4,0,4,0,0,1]

theorem envBound60604 : H12AffineFastState.Bounded env60604 := by
  intro p hp
  have h : env60604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60603_60604 : H12AffineEnvironment.transform 0 1 env60603 = env60604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60603 == env60604) = true)

def env60605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,110714,69825,1025,32768,107835,46480,99635,74997,8329,102515,103452,1344,110634,75786,41205,33197,256,66930,110715,512]

theorem envBound60605 : H12AffineFastState.Bounded env60605 := by
  intro p hp
  have h : env60605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60589_60605 : H12AffineEnvironment.transform 13 1345 env60589 = env60605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60589 == env60605) = true)

theorem identity60605 : scanCanonicalize (H12AffineFastState.compose env60605 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60605 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,107883,67024,1025,32768,107835,41089,99635,74997,8329,99682,98573,1344,107835,75786,41205,33197,256,66930,107882,512]

theorem envBound60606 : H12AffineFastState.Bounded env60606 := by
  intro p hp
  have h : env60606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60605_60606 : H12AffineEnvironment.transform 11 1297 env60605 = env60606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60605 == env60606) = true)

def env60607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136513,46480,144713,169103,26056,157000,103453,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60607 : H12AffineFastState.Bounded env60607 := by
  intro p hp
  have h : env60607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60587_60607 : H12AffineEnvironment.transform 17 87425 env60587 = env60607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60587 == env60607) = true)

theorem identity60607 : scanCanonicalize (H12AffineFastState.compose env60607 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 128314) := by decide +kernel

theorem selectedBound60607 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,128314,87425,1025,32768,123003,46480,114803,90549,26056,102514,103453,16385,128362,93515,58805,50413,256,81971,128315,18241]

theorem envBound60608 : H12AffineFastState.Bounded env60608 := by
  intro p hp
  have h : env60608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60607_60608 : H12AffineEnvironment.transform 16 128314 env60607 = env60608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 128314 env60607 == env60608) = true)

def env60609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,110714,69825,1025,32768,107835,46480,99635,74997,8328,102514,103453,1345,110634,75787,41205,33197,256,66931,110715,513]

theorem envBound60609 : H12AffineFastState.Bounded env60609 := by
  intro p hp
  have h : env60609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60608_60609 : H12AffineEnvironment.transform 13 1344 env60608 = env60609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60608 == env60609) = true)

theorem identity60609 : scanCanonicalize (H12AffineFastState.compose env60609 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60609 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,9445,33886,1025,32768,12708,46480,4524,45162,8328,1261,130,1345,9397,48276,41205,33197,256,37356,9444,513]

theorem envBound60610 : H12AffineFastState.Bounded env60610 := by
  intro p hp
  have h : env60610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60609_60610 : H12AffineEnvironment.transform 15 38047 env60609 = env60610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60609 == env60610) = true)

theorem identity60610 : scanCanonicalize (H12AffineFastState.compose env60610 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound60610 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60611 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,32768,36963,8217,32930,253,32768,12708,45420,4524,45162,8328,17,130,445,8265,47208,41205,33197,256,37356,8216,513]

theorem envBound60611 : H12AffineFastState.Bounded env60611 := by
  intro p hp
  have h : env60611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60610_60611 : H12AffineEnvironment.transform 9 252 env60610 = env60611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env60610 == env60611) = true)

theorem identity60611 : scanCanonicalize (H12AffineFastState.compose env60611 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound60611 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60612 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,169,4298,8217,11,253,169,12708,12741,4524,12483,8328,17,130,445,8265,14529,8284,260,256,4421,8216,513]

theorem envBound60612 : H12AffineFastState.Bounded env60612 := by
  intro p hp
  have h : env60612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60611_60612 : H12AffineEnvironment.transform 14 169 env60611 = env60612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env60611 == env60612) = true)

theorem identity60612 : scanCanonicalize (H12AffineFastState.compose env60612 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3046) := by decide +kernel

theorem selectedBound60612 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60613 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,3046,8192,444,169,2860,8217,11,253,169,10818,10787,2634,11045,8328,17,130,445,8265,8999,8284,260,256,2723,8216,513]

theorem envBound60613 : H12AffineFastState.Bounded env60613 := by
  intro p hp
  have h : env60613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60612_60613 : H12AffineEnvironment.transform 11 3046 env60612 = env60613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3046 env60612 == env60613) = true)

theorem identity60613 : scanCanonicalize (H12AffineFastState.compose env60613 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound60613 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60614 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,3046,2990,444,169,2860,2999,11,253,169,492,397,2634,139,2854,17,130,445,3047,2185,3058,260,256,2723,2998,513]

theorem envBound60614 : H12AffineFastState.Bounded env60614 := by
  intro p hp
  have h : env60614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60613_60614 : H12AffineEnvironment.transform 12 2990 env60613 = env60614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env60613 == env60614) = true)

theorem identity60614 : scanCanonicalize (H12AffineFastState.compose env60614 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 382) := by decide +kernel

theorem selectedBound60614 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60615 : List Nat := [2,4,8,16,32,64,128,256,512,252,382,664,720,444,169,594,713,11,253,169,492,397,820,139,600,17,130,445,665,503,652,260,256,989,712,513]

theorem envBound60615 : H12AffineFastState.Bounded env60615 := by
  intro p hp
  have h : env60615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60614_60615 : H12AffineEnvironment.transform 10 382 env60614 = env60615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 382 env60614 == env60615) = true)

theorem identity60615 : scanCanonicalize (H12AffineFastState.compose env60615 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound60615 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60616 : List Nat := [2,4,8,16,32,64,128,95,512,252,33,664,720,227,169,594,713,11,253,169,179,210,619,139,600,17,130,226,665,168,652,91,95,642,712,513]

theorem envBound60616 : H12AffineFastState.Bounded env60616 := by
  intro p hp
  have h : env60616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60615_60616 : H12AffineEnvironment.transform 7 95 env60615 = env60616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env60615 == env60616) = true)

theorem identity60616 : scanCanonicalize (H12AffineFastState.compose env60616 (packedSelected [2,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60616 : packedSelected [2,7,9,11] rootPS < 2^1333 := by decide +kernel

def env60617 : List Nat := [2,4,8,16,32,64,128,95,216,252,33,64,8,227,169,138,17,11,253,169,179,210,179,139,128,17,130,226,65,168,84,91,95,90,16,217]

theorem envBound60617 : H12AffineFastState.Bounded env60617 := by
  intro p hp
  have h : env60617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60616_60617 : H12AffineEnvironment.transform 8 216 env60616 = env60617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60616 == env60617) = true)

theorem identity60617 : scanCanonicalize (H12AffineFastState.compose env60617 (packedSelected [0,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 57) := by decide +kernel

theorem selectedBound60617 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env60618 : List Nat := [2,4,8,16,32,57,128,38,161,133,33,57,8,154,169,138,17,11,132,169,179,171,179,139,128,17,130,155,56,168,45,34,38,35,16,160]

theorem envBound60618 : H12AffineFastState.Bounded env60618 := by
  intro p hp
  have h : env60618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60617_60618 : H12AffineEnvironment.transform 5 57 env60617 = env60618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 57 env60617 == env60618) = true)

theorem identity60618 : scanCanonicalize (H12AffineFastState.compose env60618 (packedSelected [1,2,3,4,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60618 : packedSelected [1,2,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60619 : List Nat := [2,4,8,16,9,16,128,15,136,133,8,16,8,154,128,138,17,11,132,128,154,130,154,139,128,17,130,155,17,129,4,11,15,10,16,137]

theorem envBound60619 : H12AffineFastState.Bounded env60619 := by
  intro p hp
  have h : env60619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60618_60619 : H12AffineEnvironment.transform 4 9 env60618 = env60619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60618 == env60619) = true)

theorem identity60619 : scanCanonicalize (H12AffineFastState.compose env60619 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60619 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60620 : List Nat := [2,4,8,3,9,3,128,15,136,133,8,3,8,137,128,138,2,11,132,128,137,130,137,139,128,2,130,136,2,129,4,11,15,10,3,137]

theorem envBound60620 : H12AffineFastState.Bounded env60620 := by
  intro p hp
  have h : env60620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60619_60620 : H12AffineEnvironment.transform 3 3 env60619 = env60620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60619 == env60620) = true)

theorem identity60620 : scanCanonicalize (H12AffineFastState.compose env60620 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound60620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60621 : List Nat := [2,4,8,3,9,3,1,15,9,4,8,3,8,8,1,11,2,11,5,1,8,3,8,10,1,2,3,9,2,0,4,11,15,10,3,8]

theorem envBound60621 : H12AffineFastState.Bounded env60621 := by
  intro p hp
  have h : env60621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60620_60621 : H12AffineEnvironment.transform 6 1 env60620 = env60621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env60620 == env60621) = true)

theorem identity60621 : scanCanonicalize (H12AffineFastState.compose env60621 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60622 : List Nat := [2,4,1,3,0,3,1,6,0,4,1,3,1,1,1,2,2,2,5,1,1,3,1,3,1,2,3,0,2,0,4,2,6,3,3,1]

theorem envBound60622 : H12AffineFastState.Bounded env60622 := by
  intro p hp
  have h : env60622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60621_60622 : H12AffineEnvironment.transform 2 1 env60621 = env60622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60621 == env60622) = true)

theorem identity60622 : scanCanonicalize (H12AffineFastState.compose env60622 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60623 : List Nat := [1,4,1,0,0,0,1,5,0,4,1,0,1,1,1,1,1,1,5,1,1,0,1,0,1,1,0,0,1,0,4,1,5,0,0,1]

theorem envBound60623 : H12AffineFastState.Bounded env60623 := by
  intro p hp
  have h : env60623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60622_60623 : H12AffineEnvironment.transform 0 1 env60622 = env60623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60622 == env60623) = true)

def env60624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,110715,69824,1025,32768,107834,46480,99634,74996,8329,102514,103453,1344,110635,75786,41204,33196,256,66930,110714,512]

theorem envBound60624 : H12AffineFastState.Bounded env60624 := by
  intro p hp
  have h : env60624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60608_60624 : H12AffineEnvironment.transform 13 1345 env60608 = env60624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60608 == env60624) = true)

theorem identity60624 : scanCanonicalize (H12AffineFastState.compose env60624 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60624 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,107882,67025,1025,32768,107834,41089,99634,74996,8329,99683,98572,1344,107834,75786,41204,33196,256,66930,107883,512]

theorem envBound60625 : H12AffineFastState.Bounded env60625 := by
  intro p hp
  have h : env60625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60624_60625 : H12AffineEnvironment.transform 11 1297 env60624 = env60625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60624 == env60625) = true)

def env60626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304862,4247641,6342041,2544861,16385,131152,4315355,6402142,209367,256,2315634,131073,4256464]

theorem envBound60626 : H12AffineFastState.Bounded env60626 := by
  intro p hp
  have h : env60626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60486_60626 : H12AffineEnvironment.transform 24 4247641 env60486 = env60626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env60486 == env60626) = true)

def env60627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269392,144712,169102,2257033,157001,2544861,16385,131152,2324491,200846,209367,256,2315634,131073,2249216]

theorem envBound60627 : H12AffineFastState.Bounded env60627 := by
  intro p hp
  have h : env60627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60626_60627 : H12AffineEnvironment.transform 21 2269392 env60626 = env60627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env60626 == env60627) = true)

def env60628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46480,144712,169102,26057,157001,311709,16385,131152,93515,200846,209367,256,81970,131073,18240]

theorem envBound60628 : H12AffineFastState.Bounded env60628 := by
  intro p hp
  have h : env60628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60627_60628 : H12AffineEnvironment.transform 20 136512 env60627 = env60628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60627 == env60628) = true)

def env60629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46480,144712,169102,26057,157001,103453,16385,131152,93515,200846,209367,256,81970,131073,18240]

theorem envBound60629 : H12AffineFastState.Bounded env60629 := by
  intro p hp
  have h : env60629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60628_60629 : H12AffineEnvironment.transform 17 87424 env60628 = env60629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60628 == env60629) = true)

theorem identity60629 : scanCanonicalize (H12AffineFastState.compose env60629 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 74047) := by decide +kernel

theorem selectedBound60629 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74047,87424,1025,32768,78975,46480,70775,112049,26057,83062,103453,16385,74095,93515,12721,4328,256,81970,74046,18240]

theorem envBound60630 : H12AffineFastState.Bounded env60630 := by
  intro p hp
  have h : env60630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60629_60630 : H12AffineEnvironment.transform 16 74047 env60629 = env60630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74047 env60629 == env60630) = true)

def env60631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,74047,69824,1025,32768,78975,46480,70775,112049,8329,65846,103453,1345,74095,75787,12721,4328,256,66930,74046,512]

theorem envBound60631 : H12AffineFastState.Bounded env60631 := by
  intro p hp
  have h : env60631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60630_60631 : H12AffineEnvironment.transform 13 1344 env60630 = env60631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60630 == env60631) = true)

theorem identity60631 : scanCanonicalize (H12AffineFastState.compose env60631 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60631 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,74047,67024,1025,32768,74095,41088,65895,106657,8329,65846,98573,1345,74095,75787,9377,1528,256,66930,74046,512]

theorem envBound60632 : H12AffineFastState.Bounded env60632 := by
  intro p hp
  have h : env60632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60631_60632 : H12AffineEnvironment.transform 11 1296 env60631 = env60632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60631 == env60632) = true)

def env60633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,74047,69825,1025,32768,78975,46480,70775,112049,8328,65847,103453,1344,74095,75786,12721,4328,256,66931,74046,513]

theorem envBound60633 : H12AffineFastState.Bounded env60633 := by
  intro p hp
  have h : env60633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60630_60633 : H12AffineEnvironment.transform 13 1345 env60630 = env60633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60630 == env60633) = true)

theorem identity60633 : scanCanonicalize (H12AffineFastState.compose env60633 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60633 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,46496,33886,1025,32768,41184,46480,33000,8494,8328,38312,130,1344,46576,48277,12721,4328,256,37356,46497,513]

theorem envBound60634 : H12AffineFastState.Bounded env60634 := by
  intro p hp
  have h : env60634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60633_60634 : H12AffineEnvironment.transform 15 38047 env60633 = env60634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60633 == env60634) = true)

theorem identity60634 : scanCanonicalize (H12AffineFastState.compose env60634 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5560) := by decide +kernel

theorem selectedBound60634 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5560,295,8216,4582,1025,5560,13656,8232,5456,8494,8328,16,130,1344,8264,10541,12721,4328,256,1108,8217,513]

theorem envBound60635 : H12AffineFastState.Bounded env60635 := by
  intro p hp
  have h : env60635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60634_60635 : H12AffineEnvironment.transform 14 5560 env60634 = env60635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5560 env60634 == env60635) = true)

theorem identity60635 : scanCanonicalize (H12AffineFastState.compose env60635 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound60635 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,1108,295,8216,10,1025,1108,9396,8232,1212,8494,8328,16,130,1344,8264,10541,8285,260,256,1108,8217,513]

theorem envBound60636 : H12AffineFastState.Bounded env60636 := by
  intro p hp
  have h : env60636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60635_60636 : H12AffineEnvironment.transform 11 492 env60635 = env60636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env60635 == env60636) = true)

theorem identity60636 : scanCanonicalize (H12AffineFastState.compose env60636 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound60636 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,2991,1345,1108,295,2999,10,1025,1108,3867,2951,1212,2689,2855,16,130,1344,3047,642,3058,260,256,1108,2998,513]

theorem envBound60637 : H12AffineFastState.Bounded env60637 := by
  intro p hp
  have h : env60637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60636_60637 : H12AffineEnvironment.transform 12 2991 env60636 = env60637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env60636 == env60637) = true)

theorem identity60637 : scanCanonicalize (H12AffineFastState.compose env60637 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound60637 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,421,1345,1108,295,445,10,1025,1108,1297,397,1212,139,301,16,130,1344,493,642,504,260,256,1108,444,513]

theorem envBound60638 : H12AffineFastState.Bounded env60638 := by
  intro p hp
  have h : env60638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60637_60638 : H12AffineEnvironment.transform 10 522 env60637 = env60638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env60637 == env60638) = true)

theorem identity60638 : scanCanonicalize (H12AffineFastState.compose env60638 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60638 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60639 : List Nat := [2,4,8,16,32,64,128,256,216,1024,210,492,421,1345,1108,295,445,10,1025,1108,1297,397,1212,139,301,16,130,1344,493,90,504,260,256,1108,444,217]

theorem envBound60639 : H12AffineFastState.Bounded env60639 := by
  intro p hp
  have h : env60639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60638_60639 : H12AffineEnvironment.transform 8 216 env60638 = env60639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60638 == env60639) = true)

theorem identity60639 : scanCanonicalize (H12AffineFastState.compose env60639 (packedSelected [1,3,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60639 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env60640 : List Nat := [2,4,8,16,32,16,128,256,136,1024,130,444,421,1297,1028,295,445,10,1025,1028,1297,397,1212,139,301,16,130,1296,445,10,424,260,256,1028,444,137]

theorem envBound60640 : H12AffineFastState.Bounded env60640 := by
  intro p hp
  have h : env60640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60639_60640 : H12AffineEnvironment.transform 5 16 env60639 = env60640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60639 == env60640) = true)

theorem identity60640 : scanCanonicalize (H12AffineFastState.compose env60640 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound60640 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env60641 : List Nat := [2,4,8,16,32,16,128,256,136,172,130,444,421,445,168,295,445,10,173,168,445,397,16,139,301,16,130,444,445,10,424,260,256,168,444,137]

theorem envBound60641 : H12AffineFastState.Bounded env60641 := by
  intro p hp
  have h : env60641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60640_60641 : H12AffineEnvironment.transform 9 172 env60640 = env60641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env60640 == env60641) = true)

theorem identity60641 : scanCanonicalize (H12AffineFastState.compose env60641 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound60641 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60642 : List Nat := [2,4,8,16,32,16,8,256,0,36,10,308,301,309,32,295,309,10,37,32,309,261,16,3,301,16,10,308,309,10,288,260,256,32,308,1]

theorem envBound60642 : H12AffineFastState.Bounded env60642 := by
  intro p hp
  have h : env60642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60641_60642 : H12AffineEnvironment.transform 6 8 env60641 = env60642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env60641 == env60642) = true)

theorem identity60642 : scanCanonicalize (H12AffineFastState.compose env60642 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 12) := by decide +kernel

theorem selectedBound60642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60643 : List Nat := [2,4,8,16,32,16,8,12,0,36,10,56,33,57,32,43,57,10,37,32,57,9,16,3,33,16,10,56,57,10,44,8,12,32,56,1]

theorem envBound60643 : H12AffineFastState.Bounded env60643 := by
  intro p hp
  have h : env60643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60642_60643 : H12AffineEnvironment.transform 7 12 env60642 = env60643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 12 env60642 == env60643) = true)

theorem identity60643 : scanCanonicalize (H12AffineFastState.compose env60643 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound60643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60644 : List Nat := [2,4,8,16,8,16,8,12,0,12,10,16,9,17,8,3,17,10,13,8,17,9,16,3,9,16,10,16,17,10,4,8,12,8,16,1]

theorem envBound60644 : H12AffineFastState.Bounded env60644 := by
  intro p hp
  have h : env60644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60643_60644 : H12AffineEnvironment.transform 4 8 env60643 = env60644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env60643 == env60644) = true)

theorem identity60644 : scanCanonicalize (H12AffineFastState.compose env60644 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60645 : List Nat := [2,4,8,3,8,3,8,12,0,12,10,3,9,2,8,3,2,10,13,8,2,9,3,3,9,3,10,3,2,10,4,8,12,8,3,1]

theorem envBound60645 : H12AffineFastState.Bounded env60645 := by
  intro p hp
  have h : env60645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60644_60645 : H12AffineEnvironment.transform 3 3 env60644 = env60645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60644 == env60645) = true)

theorem identity60645 : scanCanonicalize (H12AffineFastState.compose env60645 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60645 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60646 : List Nat := [1,4,8,0,8,0,8,12,0,12,9,0,9,1,8,0,1,9,13,8,1,9,0,0,9,0,9,0,1,9,4,8,12,8,0,1]

theorem envBound60646 : H12AffineFastState.Bounded env60646 := by
  intro p hp
  have h : env60646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60645_60646 : H12AffineEnvironment.transform 0 1 env60645 = env60646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60645 == env60646) = true)

theorem identity60646 : scanCanonicalize (H12AffineFastState.compose env60646 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60646 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60647 : List Nat := [1,4,1,0,1,0,1,5,0,5,0,0,0,1,1,0,1,0,4,1,1,0,0,0,0,0,0,0,1,0,4,1,5,1,0,1]

theorem envBound60647 : H12AffineFastState.Bounded env60647 := by
  intro p hp
  have h : env60647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60646_60647 : H12AffineEnvironment.transform 2 1 env60646 = env60647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60646 == env60647) = true)

def env60648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46480,144712,169102,26057,157001,103452,16385,131152,93515,200846,209367,256,81970,131073,18240]

theorem envBound60648 : H12AffineFastState.Bounded env60648 := by
  intro p hp
  have h : env60648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60628_60648 : H12AffineEnvironment.transform 17 87425 env60628 = env60648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60628 == env60648) = true)

theorem identity60648 : scanCanonicalize (H12AffineFastState.compose env60648 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 91262) := by decide +kernel

theorem selectedBound60648 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,91262,87425,1025,32768,94526,46480,86326,127216,26057,65847,103452,16385,91182,93515,29936,21929,256,81970,91263,18240]

theorem envBound60649 : H12AffineFastState.Bounded env60649 := by
  intro p hp
  have h : env60649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60648_60649 : H12AffineEnvironment.transform 16 91262 env60648 = env60649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91262 env60648 == env60649) = true)

def env60650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,74046,69825,1025,32768,78974,46480,70774,112048,8329,65847,103452,1345,74094,75787,12720,4329,256,66930,74047,512]

theorem envBound60650 : H12AffineFastState.Bounded env60650 := by
  intro p hp
  have h : env60650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60649_60650 : H12AffineEnvironment.transform 13 1344 env60649 = env60650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60649 == env60650) = true)

theorem identity60650 : scanCanonicalize (H12AffineFastState.compose env60650 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60650 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,74046,67025,1025,32768,74094,41088,65894,106656,8329,65847,98572,1345,74094,75787,9376,1529,256,66930,74047,512]

theorem envBound60651 : H12AffineFastState.Bounded env60651 := by
  intro p hp
  have h : env60651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60650_60651 : H12AffineEnvironment.transform 11 1296 env60650 = env60651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60650 == env60651) = true)

def env60652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,74047,69824,1025,32768,78975,46480,70775,112049,8328,65847,103452,1344,74095,75786,12721,4328,256,66931,74046,513]

theorem envBound60652 : H12AffineFastState.Bounded env60652 := by
  intro p hp
  have h : env60652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60649_60652 : H12AffineEnvironment.transform 13 1345 env60649 = env60652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60649 == env60652) = true)

theorem identity60652 : scanCanonicalize (H12AffineFastState.compose env60652 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

end H12CloudChart0