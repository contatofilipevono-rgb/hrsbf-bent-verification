import H12CloudChart0Data076

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env19422 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,5133,5377,5377,5127,17,7204,1024,5376,4112,32,17,2,5133,17,2049,5392,4096,7205,1284,33,256,33,5376,513]

theorem envBound19422 : H12AffineFastState.Bounded env19422 := by
  intro p hp
  have h : env19422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19421_19422 : H12AffineEnvironment.transform 12 5133 env19421 = env19422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env19421 == env19422) = true)

theorem identity19422 : scanCanonicalize (H12AffineFastState.compose env19422 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound19422 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19423 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,5133,5377,5377,5127,17,4113,1024,5376,4112,32,17,2,5133,17,1076,5392,4096,4112,1284,33,256,33,5376,513]

theorem envBound19423 : H12AffineFastState.Bounded env19423 := by
  intro p hp
  have h : env19423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19422_19423 : H12AffineEnvironment.transform 10 1077 env19422 = env19423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env19422 == env19423) = true)

theorem identity19423 : scanCanonicalize (H12AffineFastState.compose env19423 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound19423 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,1061,40,292,292,34,17,1076,1024,293,1077,32,17,2,40,17,1076,309,1061,1077,1284,33,256,33,293,513]

theorem envBound19424 : H12AffineFastState.Bounded env19424 := by
  intro p hp
  have h : env19424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19423_19424 : H12AffineEnvironment.transform 11 1061 env19423 = env19424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env19423 == env19424) = true)

theorem identity19424 : scanCanonicalize (H12AffineFastState.compose env19424 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19424 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19425 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1077,1061,40,1,1,34,17,1076,1024,0,1077,32,17,2,40,17,1076,16,1061,1077,1057,33,37,33,0,513]

theorem envBound19425 : H12AffineFastState.Bounded env19425 := by
  intro p hp
  have h : env19425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19424_19425 : H12AffineEnvironment.transform 7 37 env19424 = env19425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19424 == env19425) = true)

theorem identity19425 : scanCanonicalize (H12AffineFastState.compose env19425 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19426 : List Nat := [2,4,8,0,32,1,8,37,512,1024,1061,1061,40,1,1,34,1,1060,1024,0,1061,32,1,2,40,1,1060,0,1061,1061,1057,33,37,33,0,513]

theorem envBound19426 : H12AffineFastState.Bounded env19426 := by
  intro p hp
  have h : env19426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19425_19426 : H12AffineEnvironment.transform 3 0 env19425 = env19426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19425 == env19426) = true)

theorem identity19426 : scanCanonicalize (H12AffineFastState.compose env19426 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound19426 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19427 : List Nat := [2,4,8,0,32,1,8,37,512,46,11,11,40,1,1,34,1,10,46,0,11,32,1,2,40,1,10,0,11,11,15,33,37,33,0,513]

theorem envBound19427 : H12AffineFastState.Bounded env19427 := by
  intro p hp
  have h : env19427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19426_19427 : H12AffineEnvironment.transform 9 46 env19426 = env19427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env19426 == env19427) = true)

theorem identity19427 : scanCanonicalize (H12AffineFastState.compose env19427 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19427 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19428 : List Nat := [2,4,8,0,11,1,8,14,512,5,11,11,3,1,1,9,1,10,5,0,11,11,1,2,3,1,10,0,11,11,15,10,14,10,0,513]

theorem envBound19428 : H12AffineFastState.Bounded env19428 := by
  intro p hp
  have h : env19428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19427_19428 : H12AffineEnvironment.transform 4 11 env19427 = env19428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19427 == env19428) = true)

theorem identity19428 : scanCanonicalize (H12AffineFastState.compose env19428 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound19428 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19429 : List Nat := [2,0,8,0,11,1,8,10,512,1,11,11,3,1,1,9,1,10,1,0,11,11,1,2,3,1,10,0,11,11,11,10,10,10,0,513]

theorem envBound19429 : H12AffineFastState.Bounded env19429 := by
  intro p hp
  have h : env19429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19428_19429 : H12AffineEnvironment.transform 1 0 env19428 = env19429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env19428 == env19429) = true)

theorem identity19429 : scanCanonicalize (H12AffineFastState.compose env19429 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19429 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19430 : List Nat := [2,0,3,0,0,1,3,1,512,1,0,0,3,1,1,2,1,1,1,0,0,0,1,2,3,1,1,0,0,0,0,1,1,1,0,513]

theorem envBound19430 : H12AffineFastState.Bounded env19430 := by
  intro p hp
  have h : env19430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19429_19430 : H12AffineEnvironment.transform 2 3 env19429 = env19430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19429 == env19430) = true)

theorem identity19430 : scanCanonicalize (H12AffineFastState.compose env19430 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound19430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19431 : List Nat := [2,0,3,0,0,1,3,1,3,1,0,0,3,1,1,2,1,1,1,0,0,0,1,2,3,1,1,0,0,0,0,1,1,1,0,2]

theorem envBound19431 : H12AffineFastState.Bounded env19431 := by
  intro p hp
  have h : env19431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19430_19431 : H12AffineEnvironment.transform 8 3 env19430 = env19431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env19430 == env19431) = true)

def env19432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,16777216,8328,64,17227834,18973836,77834,2598234,18932042,16851104,256,16818678,16793682,18990748]

theorem envBound19432 : H12AffineFastState.Bounded env19432 := by
  intro p hp
  have h : env19432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19339_19432 : H12AffineEnvironment.transform 21 2114913 env19339 = env19432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env19339 == env19432) = true)

def env19433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175168,8328,64,2609402,46156,77834,2598234,119178,2101344,256,2199862,2191506,63068]

theorem envBound19433 : H12AffineFastState.Bounded env19433 := by
  intro p hp
  have h : env19433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19432_19433 : H12AffineEnvironment.transform 23 2175168 env19432 = env19433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env19432 == env19433) = true)

def env19434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73856,8328,64,508090,46156,77834,505114,119178,32,256,98678,90322,63068]

theorem envBound19434 : H12AffineFastState.Bounded env19434 := by
  intro p hp
  have h : env19434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19433_19434 : H12AffineEnvironment.transform 20 4160 env19433 = env19434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19433 == env19434) = true)

theorem identity19434 : scanCanonicalize (H12AffineFastState.compose env19434 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound19434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,1024,32769,4160,21793,62661,41310,8328,64,409956,46156,45524,406724,20564,32,256,168,57612,63068]

theorem envBound19435 : H12AffineFastState.Bounded env19435 := by
  intro p hp
  have h : env19435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19434_19435 : H12AffineEnvironment.transform 15 33246 env19434 = env19435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env19434 == env19435) = true)

def env19436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,10280,1024,32769,4160,21793,62661,41310,8328,64,158028,46156,45524,138476,20564,32,256,168,57612,63068]

theorem envBound19436 : H12AffineFastState.Bounded env19436 := by
  intro p hp
  have h : env19436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19435_19436 : H12AffineEnvironment.transform 17 10280 env19435 = env19436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env19435 == env19436) = true)

theorem identity19436 : scanCanonicalize (H12AffineFastState.compose env19436 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound19436 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16400,10280,1024,32769,4160,21793,62661,41310,8328,64,10588,46156,45524,23804,20564,32,256,168,57612,63068]

theorem envBound19437 : H12AffineFastState.Bounded env19437 := by
  intro p hp
  have h : env19437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19436_19437 : H12AffineEnvironment.transform 16 16400 env19436 = env19437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19436 == env19437) = true)

theorem identity19437 : scanCanonicalize (H12AffineFastState.compose env19437 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound19437 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env19438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,32768,33246,16400,3173,1024,32769,4160,21793,53384,34067,1221,64,3345,36865,38297,23804,20564,32,256,168,50497,53777]

theorem envBound19438 : H12AffineFastState.Bounded env19438 := by
  intro p hp
  have h : env19438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19437_19438 : H12AffineEnvironment.transform 12 1101 env19437 = env19438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env19437 == env19438) = true)

theorem identity19438 : scanCanonicalize (H12AffineFastState.compose env19438 (packedSelected [0,3,4,5,7,10,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound19438 : packedSelected [0,3,4,5,7,10,21,22] rootPS < 2^1333 := by decide +kernel

def env19439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,5512,32768,33246,5528,3173,1024,32769,4160,169,34048,34067,1221,64,3345,36865,38297,2420,1500,32,256,168,37065,34713]

theorem envBound19439 : H12AffineFastState.Bounded env19439 := by
  intro p hp
  have h : env19439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19438_19439 : H12AffineEnvironment.transform 13 5512 env19438 = env19439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env19438 == env19439) = true)

theorem identity19439 : scanCanonicalize (H12AffineFastState.compose env19439 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19439 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,5512,1,479,5528,3173,1024,0,4160,169,1281,1298,1221,64,3345,4096,5528,2420,1500,32,256,168,4296,1944]

theorem envBound19440 : H12AffineFastState.Bounded env19440 := by
  intro p hp
  have h : env19440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19439_19440 : H12AffineEnvironment.transform 14 1 env19439 = env19440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19439 == env19440) = true)

theorem identity19440 : scanCanonicalize (H12AffineFastState.compose env19440 (packedSelected [0,2,7,11,12,14,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19440 : packedSelected [0,2,7,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env19441 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,1101,5260,1,219,5276,3173,1024,0,4160,169,1029,1046,1221,64,3093,4096,5276,2160,1240,32,4,168,4296,1692]

theorem envBound19441 : H12AffineFastState.Bounded env19441 := by
  intro p hp
  have h : env19441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19440_19441 : H12AffineEnvironment.transform 7 4 env19440 = env19441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19440 == env19441) = true)

theorem identity19441 : scanCanonicalize (H12AffineFastState.compose env19441 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19441 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env19442 : List Nat := [2,4,8,16,32,64,128,4,512,52,2048,4096,121,4280,1,219,4264,2129,52,0,4160,169,49,34,241,64,2081,4096,4264,2160,236,32,4,168,4296,680]

theorem envBound19442 : H12AffineFastState.Bounded env19442 := by
  intro p hp
  have h : env19442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19441_19442 : H12AffineEnvironment.transform 9 52 env19441 = env19442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19441 == env19442) = true)

theorem identity19442 : scanCanonicalize (H12AffineFastState.compose env19442 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19442 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env19443 : List Nat := [2,4,8,16,32,64,9,4,512,52,2048,4096,121,4145,1,82,4129,2129,52,0,4160,32,49,34,120,64,2081,4096,4129,2160,101,32,4,33,4161,545]

theorem envBound19443 : H12AffineFastState.Bounded env19443 := by
  intro p hp
  have h : env19443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19442_19443 : H12AffineEnvironment.transform 6 9 env19442 = env19443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19442 == env19443) = true)

theorem identity19443 : scanCanonicalize (H12AffineFastState.compose env19443 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19443 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19444 : List Nat := [2,4,8,16,1,64,9,4,512,21,2048,4096,88,4112,1,82,4096,2129,21,0,4160,1,16,3,89,64,2048,4096,4096,2129,68,1,4,0,4161,512]

theorem envBound19444 : H12AffineFastState.Bounded env19444 := by
  intro p hp
  have h : env19444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19443_19444 : H12AffineEnvironment.transform 4 1 env19443 = env19444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19443 == env19444) = true)

theorem identity19444 : scanCanonicalize (H12AffineFastState.compose env19444 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound19444 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19445 : List Nat := [2,4,8,16,1,1,9,4,512,21,2048,4096,25,4112,1,19,4096,2064,21,0,4097,1,16,3,24,1,2048,4096,4096,2064,5,1,4,0,4096,512]

theorem envBound19445 : H12AffineFastState.Bounded env19445 := by
  intro p hp
  have h : env19445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19444_19445 : H12AffineEnvironment.transform 5 1 env19444 = env19445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env19444 == env19445) = true)

theorem identity19445 : scanCanonicalize (H12AffineFastState.compose env19445 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19445 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19446 : List Nat := [2,4,8,16,1,1,9,4,1,21,2048,4096,25,4112,1,19,4096,2064,21,0,4097,1,16,3,24,1,2048,4096,4096,2064,5,1,4,0,4096,1]

theorem envBound19446 : H12AffineFastState.Bounded env19446 := by
  intro p hp
  have h : env19446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19445_19446 : H12AffineEnvironment.transform 8 1 env19445 = env19446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19445 == env19446) = true)

theorem identity19446 : scanCanonicalize (H12AffineFastState.compose env19446 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound19446 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env19447 : List Nat := [2,4,8,16,1,1,9,4,1,21,20,4096,25,4112,1,19,4096,4,21,0,4097,1,16,3,24,1,20,4096,4096,4,5,1,4,0,4096,1]

theorem envBound19447 : H12AffineFastState.Bounded env19447 := by
  intro p hp
  have h : env19447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19446_19447 : H12AffineEnvironment.transform 10 20 env19446 = env19447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env19446 == env19447) = true)

theorem identity19447 : scanCanonicalize (H12AffineFastState.compose env19447 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound19447 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19448 : List Nat := [2,0,8,16,1,1,9,0,1,17,16,4096,25,4112,1,19,4096,0,17,0,4097,1,16,3,24,1,16,4096,4096,0,1,1,0,0,4096,1]

theorem envBound19448 : H12AffineFastState.Bounded env19448 := by
  intro p hp
  have h : env19448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19447_19448 : H12AffineEnvironment.transform 1 0 env19447 = env19448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env19447 == env19448) = true)

theorem identity19448 : scanCanonicalize (H12AffineFastState.compose env19448 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound19448 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19449 : List Nat := [2,0,8,16,1,1,9,0,1,17,16,1,25,17,1,19,1,0,17,0,0,1,16,3,24,1,16,1,1,0,1,1,0,0,1,1]

theorem envBound19449 : H12AffineFastState.Bounded env19449 := by
  intro p hp
  have h : env19449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19448_19449 : H12AffineEnvironment.transform 11 1 env19448 = env19449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env19448 == env19449) = true)

theorem identity19449 : scanCanonicalize (H12AffineFastState.compose env19449 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19450 : List Nat := [2,0,8,0,1,1,9,0,1,1,0,1,9,1,1,3,1,0,1,0,0,1,0,3,8,1,0,1,1,0,1,1,0,0,1,1]

theorem envBound19450 : H12AffineFastState.Bounded env19450 := by
  intro p hp
  have h : env19450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19449_19450 : H12AffineEnvironment.transform 3 0 env19449 = env19450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19449 == env19450) = true)

def env19451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,10281,1024,32769,4160,21793,62661,41310,8328,64,158029,46156,45524,138477,20564,32,256,168,57612,63068]

theorem envBound19451 : H12AffineFastState.Bounded env19451 := by
  intro p hp
  have h : env19451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19435_19451 : H12AffineEnvironment.transform 17 10281 env19435 = env19451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19435 == env19451) = true)

theorem identity19451 : scanCanonicalize (H12AffineFastState.compose env19451 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19451 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29963,131072,10281,1024,29908,4160,21793,16,21899,8328,64,158029,16537,17665,138477,20564,32,256,168,5593,649]

theorem envBound19452 : H12AffineFastState.Bounded env19452 := by
  intro p hp
  have h : env19452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19451_19452 : H12AffineEnvironment.transform 14 29909 env19451 = env19452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19451 == env19452) = true)

theorem identity19452 : scanCanonicalize (H12AffineFastState.compose env19452 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 24753) := by decide +kernel

theorem selectedBound19452 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env19453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29963,24753,10281,1024,29908,4160,21793,16,21899,8328,64,2556,16537,17665,31836,20564,32,256,168,5593,649]

theorem envBound19453 : H12AffineFastState.Bounded env19453 := by
  intro p hp
  have h : env19453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19452_19453 : H12AffineEnvironment.transform 16 24753 env19452 = env19453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24753 env19452 == env19453) = true)

theorem identity19453 : scanCanonicalize (H12AffineFastState.compose env19453 (packedSelected [0,6,7,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound19453 : packedSelected [0,6,7,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19454 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,29909,29943,24753,10281,1024,29908,4160,21725,16,21623,8328,64,2048,16537,17661,31836,20564,32,252,168,5157,649]

theorem envBound19454 : H12AffineFastState.Bounded env19454 := by
  intro p hp
  have h : env19454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19453_19454 : H12AffineEnvironment.transform 7 252 env19453 = env19454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env19453 == env19454) = true)

theorem identity19454 : scanCanonicalize (H12AffineFastState.compose env19454 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound19454 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19455 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5156,8433,8403,13461,10281,1024,8432,4160,249,16,83,8328,64,2048,5309,4313,10360,1136,32,252,168,5157,649]

theorem envBound19455 : H12AffineFastState.Bounded env19455 := by
  intro p hp
  have h : env19455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19454_19455 : H12AffineEnvironment.transform 13 5156 env19454 = env19455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env19454 == env19455) = true)

theorem identity19455 : scanCanonicalize (H12AffineFastState.compose env19455 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound19455 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env19456 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,120,5156,137,171,5357,2129,1024,136,4160,249,16,83,240,64,2048,5309,4313,2048,1136,32,252,168,5157,649]

theorem envBound19456 : H12AffineFastState.Bounded env19456 := by
  intro p hp
  have h : env19456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19455_19456 : H12AffineEnvironment.transform 12 120 env19455 = env19456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env19455 == env19456) = true)

theorem identity19456 : scanCanonicalize (H12AffineFastState.compose env19456 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound19456 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19457 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,120,5156,81,115,5173,2129,1024,80,4160,33,16,83,40,64,2048,5221,4097,2048,1136,32,36,112,5157,593]

theorem envBound19457 : H12AffineFastState.Bounded env19457 := by
  intro p hp
  have h : env19457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19456_19457 : H12AffineEnvironment.transform 6 88 env19456 = env19457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env19456 == env19457) = true)

def env19458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73857,8328,64,508091,46156,77834,505115,119178,33,256,98679,90323,63068]

theorem envBound19458 : H12AffineFastState.Bounded env19458 := by
  intro p hp
  have h : env19458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19433_19458 : H12AffineEnvironment.transform 20 4161 env19433 = env19458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19433 == env19458) = true)

theorem identity19458 : scanCanonicalize (H12AffineFastState.compose env19458 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound19458 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,21792,41292,62679,8328,64,398573,46156,58460,418125,1500,33,256,21793,46213,63068]

theorem envBound19459 : H12AffineFastState.Bounded env19459 := by
  intro p hp
  have h : env19459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19458_19459 : H12AffineEnvironment.transform 15 54358 env19458 = env19459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env19458 == env19459) = true)

def env19460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,4161,21792,41292,62679,8328,64,146629,46156,58460,149861,1500,33,256,21793,46213,63068]

theorem envBound19460 : H12AffineFastState.Bounded env19460 := by
  intro p hp
  have h : env19460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19459_19460 : H12AffineEnvironment.transform 17 10280 env19459 = env19460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env19459 == env19460) = true)

theorem identity19460 : scanCanonicalize (H12AffineFastState.compose env19460 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19460 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10280,1024,32769,4161,33,41292,41430,8328,64,146629,46156,45405,138340,1500,33,256,32,46213,41821]

theorem envBound19461 : H12AffineFastState.Bounded env19461 := by
  intro p hp
  have h : env19461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19460_19461 : H12AffineEnvironment.transform 13 5377 env19460 = env19461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19460 == env19461) = true)

theorem identity19461 : scanCanonicalize (H12AffineFastState.compose env19461 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound19461 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env19462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,5393,10280,1024,32769,4161,33,41292,41430,8328,64,10708,46156,45405,2421,1500,33,256,32,46213,41821]

theorem envBound19462 : H12AffineFastState.Bounded env19462 := by
  intro p hp
  have h : env19462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19461_19462 : H12AffineEnvironment.transform 16 5393 env19461 = env19462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env19461 == env19462) = true)

theorem identity19462 : scanCanonicalize (H12AffineFastState.compose env19462 (packedSelected [5,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound19462 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env19463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,9293,9498,5393,10280,1024,9292,4161,33,1281,1435,8328,64,10708,4097,5392,2421,1500,33,256,32,4296,1808]

theorem envBound19463 : H12AffineFastState.Bounded env19463 := by
  intro p hp
  have h : env19463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19462_19463 : H12AffineEnvironment.transform 14 9293 env19462 = env19463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env19462 == env19463) = true)

theorem identity19463 : scanCanonicalize (H12AffineFastState.compose env19463 (packedSelected [0,7,8,10,11,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound19463 : packedSelected [0,7,8,10,11,18,23,24] rootPS < 2^1333 := by decide +kernel

def env19464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,8192,3392,9293,9498,3408,10280,1024,9292,2048,33,1281,1435,8328,64,10708,2112,3409,2421,1500,33,256,32,2185,1808]

theorem envBound19464 : H12AffineFastState.Bounded env19464 := by
  intro p hp
  have h : env19464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19463_19464 : H12AffineEnvironment.transform 11 2113 env19463 = env19464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env19463 == env19464) = true)

theorem identity19464 : scanCanonicalize (H12AffineFastState.compose env19464 (packedSelected [1,2,4,6,8,9,10,11,15,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19464 : packedSelected [1,2,4,6,8,9,10,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env19465 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2113,8192,3392,9293,9498,3408,10280,1024,9292,2048,33,1281,1346,8273,64,10509,2112,3409,2421,1285,33,256,32,2128,1808]

theorem envBound19465 : H12AffineFastState.Bounded env19465 := by
  intro p hp
  have h : env19465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19464_19465 : H12AffineEnvironment.transform 6 89 env19464 = env19465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19464 == env19465) = true)

theorem identity19465 : scanCanonicalize (H12AffineFastState.compose env19465 (packedSelected [0,2,3,4,5,6,7,9,10,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19465 : packedSelected [0,2,3,4,5,6,7,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env19466 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,2113,8192,2340,8233,8574,2356,10280,100,8232,2048,33,357,294,8273,64,10509,2112,2357,2421,353,33,256,32,2128,884]

theorem envBound19466 : H12AffineFastState.Bounded env19466 := by
  intro p hp
  have h : env19466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19465_19466 : H12AffineEnvironment.transform 9 100 env19465 = env19466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19465 == env19466) = true)

theorem identity19466 : scanCanonicalize (H12AffineFastState.compose env19466 (packedSelected [1,2,3,4,6,9,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19466 : packedSelected [1,2,3,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env19467 : List Nat := [2,4,8,16,32,64,89,37,512,100,2048,2113,8192,2049,8233,8283,2065,10280,100,8232,2048,33,64,3,8273,64,10280,2112,2064,2128,68,33,37,32,2128,593]

theorem envBound19467 : H12AffineFastState.Bounded env19467 := by
  intro p hp
  have h : env19467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19466_19467 : H12AffineEnvironment.transform 7 37 env19466 = env19467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19466 == env19467) = true)

theorem identity19467 : scanCanonicalize (H12AffineFastState.compose env19467 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound19467 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19468 : List Nat := [2,4,8,16,32,64,89,37,512,100,2048,2113,121,2049,80,34,2065,2129,100,81,2048,33,64,3,40,64,2129,2112,2064,2128,68,33,37,32,2128,593]

theorem envBound19468 : H12AffineFastState.Bounded env19468 := by
  intro p hp
  have h : env19468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19467_19468 : H12AffineEnvironment.transform 12 121 env19467 = env19468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env19467 == env19468) = true)

theorem identity19468 : scanCanonicalize (H12AffineFastState.compose env19468 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19468 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env19469 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2065,41,2049,0,34,2065,2049,52,1,2048,33,16,3,40,16,2049,2064,2064,2048,20,33,37,32,2048,513]

theorem envBound19469 : H12AffineFastState.Bounded env19469 := by
  intro p hp
  have h : env19469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19468_19469 : H12AffineEnvironment.transform 5 16 env19468 = env19469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19468 == env19469) = true)

theorem identity19469 : scanCanonicalize (H12AffineFastState.compose env19469 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound19469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19470 : List Nat := [2,4,8,16,32,16,9,37,32,52,2048,2065,41,2049,0,34,2065,2049,52,1,2048,33,16,3,40,16,2049,2064,2064,2048,20,33,37,32,2048,33]

theorem envBound19470 : H12AffineFastState.Bounded env19470 := by
  intro p hp
  have h : env19470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19469_19470 : H12AffineEnvironment.transform 8 32 env19469 = env19470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env19469 == env19470) = true)

def env19471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4161,21792,41292,62679,8328,64,146628,46156,58460,149860,1500,33,256,21793,46213,63068]

theorem envBound19471 : H12AffineFastState.Bounded env19471 := by
  intro p hp
  have h : env19471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19459_19471 : H12AffineEnvironment.transform 17 10281 env19459 = env19471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19459 == env19471) = true)

theorem identity19471 : scanCanonicalize (H12AffineFastState.compose env19471 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19471 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1024,29788,4161,21792,21777,138,8328,64,146628,16401,4097,149860,1500,33,256,21793,16600,513]

theorem envBound19472 : H12AffineFastState.Bounded env19472 := by
  intro p hp
  have h : env19472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19471_19472 : H12AffineEnvironment.transform 14 29789 env19471 = env19472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19471 == env19472) = true)

theorem identity19472 : scanCanonicalize (H12AffineFastState.compose env19472 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound19472 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21977,399,131072,2477,1024,21976,4161,21792,21777,138,268,64,138560,16401,4097,149860,1500,33,256,21793,16600,513]

theorem envBound19473 : H12AffineFastState.Bounded env19473 := by
  intro p hp
  have h : env19473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19472_19473 : H12AffineEnvironment.transform 12 388 env19472 = env19473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env19472 == env19473) = true)

theorem identity19473 : scanCanonicalize (H12AffineFastState.compose env19473 (packedSelected [0,1,3,4,5,7,8,9,10,11,14,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound19473 : packedSelected [0,1,3,4,5,7,8,9,10,11,14,19,23] rootPS < 2^1333 := by decide +kernel

def env19474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,0,399,131072,2477,1024,1,4161,249,200,138,268,64,138560,5576,4097,138429,1500,33,256,248,5377,513]

theorem envBound19474 : H12AffineFastState.Bounded env19474 := by
  intro p hp
  have h : env19474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19473_19474 : H12AffineEnvironment.transform 13 5593 env19473 = env19474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env19473 == env19474) = true)

theorem identity19474 : scanCanonicalize (H12AffineFastState.compose env19474 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19474 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,0,399,5392,2477,1024,1,4161,249,200,138,268,64,2128,5576,4097,2477,1500,33,256,248,5377,513]

theorem envBound19475 : H12AffineFastState.Bounded env19475 := by
  intro p hp
  have h : env19475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19474_19475 : H12AffineEnvironment.transform 16 5392 env19474 = env19475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19474 == env19475) = true)

theorem identity19475 : scanCanonicalize (H12AffineFastState.compose env19475 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound19475 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,388,309,0,399,508,2477,1024,1,1197,249,200,138,268,64,2128,292,1261,2477,1500,33,256,248,493,513]

theorem envBound19476 : H12AffineFastState.Bounded env19476 := by
  intro p hp
  have h : env19476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19475_19476 : H12AffineEnvironment.transform 11 1260 env19475 = env19476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env19475 == env19476) = true)

theorem identity19476 : scanCanonicalize (H12AffineFastState.compose env19476 (packedSelected [1,8,19] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound19476 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env19477 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1076,348,309,0,343,292,2421,1024,1,1141,33,16,82,268,64,2128,292,1077,2421,1284,33,256,32,309,513]

theorem envBound19477 : H12AffineFastState.Bounded env19477 := by
  intro p hp
  have h : env19477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19476_19477 : H12AffineEnvironment.transform 6 88 env19476 = env19477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env19476 == env19477) = true)

theorem identity19477 : scanCanonicalize (H12AffineFastState.compose env19477 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound19477 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env19478 : List Nat := [2,4,8,16,32,64,88,256,512,1024,33,1076,348,309,0,343,292,340,1024,1,1141,33,16,82,268,64,113,292,1077,340,1284,33,256,32,309,513]

theorem envBound19478 : H12AffineFastState.Bounded env19478 := by
  intro p hp
  have h : env19478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19477_19478 : H12AffineEnvironment.transform 10 33 env19477 = env19478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env19477 == env19478) = true)

theorem identity19478 : scanCanonicalize (H12AffineFastState.compose env19478 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19478 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19479 : List Nat := [2,4,8,16,32,16,8,256,512,1024,33,1076,268,309,0,263,292,260,1024,1,1061,33,16,2,268,16,33,292,1077,260,1284,33,256,32,309,513]

theorem envBound19479 : H12AffineFastState.Bounded env19479 := by
  intro p hp
  have h : env19479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19478_19479 : H12AffineEnvironment.transform 5 16 env19478 = env19479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19478 == env19479) = true)

def env19480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175169,8328,64,2609403,46157,77834,2598234,119179,2101345,256,2199863,2191507,63069]

theorem envBound19480 : H12AffineFastState.Bounded env19480 := by
  intro p hp
  have h : env19480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19432_19480 : H12AffineEnvironment.transform 23 2175169 env19432 = env19480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env19432 == env19480) = true)

def env19481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73857,8328,64,508091,46157,77834,505114,119179,33,256,98679,90323,63069]

theorem envBound19481 : H12AffineFastState.Bounded env19481 := by
  intro p hp
  have h : env19481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19480_19481 : H12AffineEnvironment.transform 20 4160 env19480 = env19481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19480 == env19481) = true)

theorem identity19481 : scanCanonicalize (H12AffineFastState.compose env19481 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19481 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,21793,21776,138,8328,64,450736,46157,4097,431377,61824,33,256,41340,16600,63069]

theorem envBound19482 : H12AffineFastState.Bounded env19482 := by
  intro p hp
  have h : env19482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19481_19482 : H12AffineEnvironment.transform 15 8203 env19481 = env19482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19481 == env19482) = true)

def env19483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32160,1024,32769,4160,21793,21776,138,8328,64,171280,46157,4097,190641,61824,33,256,41340,16600,63069]

theorem envBound19483 : H12AffineFastState.Bounded env19483 := by
  intro p hp
  have h : env19483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19482_19483 : H12AffineEnvironment.transform 17 32160 env19482 = env19483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env19482 == env19483) = true)

theorem identity19483 : scanCanonicalize (H12AffineFastState.compose env19483 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound19483 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env19484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,131072,10281,1024,32769,4160,168,153,138,8328,64,171280,46157,4097,179512,41993,33,256,41340,5457,41940]

theorem envBound19484 : H12AffineFastState.Bounded env19484 := by
  intro p hp
  have h : env19484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19483_19484 : H12AffineEnvironment.transform 13 5513 env19483 = env19484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env19483 == env19484) = true)

theorem identity19484 : scanCanonicalize (H12AffineFastState.compose env19484 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound19484 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env19485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,46156,10281,1024,32769,4160,168,153,138,8328,64,10588,46157,4097,2420,41993,33,256,41340,5457,41940]

theorem envBound19485 : H12AffineFastState.Bounded env19485 := by
  intro p hp
  have h : env19485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19484_19485 : H12AffineEnvironment.transform 16 46156 env19484 = env19485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env19484 == env19485) = true)

theorem identity19485 : scanCanonicalize (H12AffineFastState.compose env19485 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound19485 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,80,8203,13340,10281,1024,81,4160,168,153,138,8328,64,10588,13341,4097,2420,9305,33,256,8492,5457,9092]

theorem envBound19486 : H12AffineFastState.Bounded env19486 := by
  intro p hp
  have h : env19486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19485_19486 : H12AffineEnvironment.transform 14 80 env19485 = env19486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env19485 == env19486) = true)

theorem identity19486 : scanCanonicalize (H12AffineFastState.compose env19486 (packedSelected [1,8,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19486 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env19487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,8203,13340,10281,1024,81,4160,33,16,3,8193,64,10588,13341,4097,2420,9305,33,256,8492,5457,8973]

theorem envBound19487 : H12AffineFastState.Bounded env19487 := by
  intro p hp
  have h : env19487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19486_19487 : H12AffineEnvironment.transform 6 9 env19486 = env19487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19486 == env19487) = true)

theorem identity19487 : scanCanonicalize (H12AffineFastState.compose env19487 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound19487 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env19488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,4096,8192,5376,80,8203,13340,8460,1024,81,4160,33,16,3,8193,64,8313,13341,4097,81,9305,33,256,8492,5457,8973]

theorem envBound19488 : H12AffineFastState.Bounded env19488 := by
  intro p hp
  have h : env19488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19487_19488 : H12AffineEnvironment.transform 10 293 env19487 = env19488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env19487 == env19488) = true)

theorem identity19488 : scanCanonicalize (H12AffineFastState.compose env19488 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound19488 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,17,8192,1297,80,8203,9229,8460,1024,81,81,33,16,3,8193,64,8313,9228,16,81,9305,33,256,8492,1344,8973]

theorem envBound19489 : H12AffineFastState.Bounded env19489 := by
  intro p hp
  have h : env19489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19488_19489 : H12AffineEnvironment.transform 11 17 env19488 = env19489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19488 == env19489) = true)

theorem identity19489 : scanCanonicalize (H12AffineFastState.compose env19489 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound19489 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env19490 : List Nat := [2,4,8,16,32,64,9,256,81,1024,293,17,8192,1297,80,8203,9229,8460,1024,81,81,33,16,3,8193,64,8313,9228,16,81,9305,33,256,8492,1344,8540]

theorem envBound19490 : H12AffineFastState.Bounded env19490 := by
  intro p hp
  have h : env19490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19489_19490 : H12AffineEnvironment.transform 8 81 env19489 = env19490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env19489 == env19490) = true)

theorem identity19490 : scanCanonicalize (H12AffineFastState.compose env19490 (packedSelected [1,5,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 365) := by decide +kernel

theorem selectedBound19490 : packedSelected [1,5,6,11] rootPS < 2^1333 := by decide +kernel

def env19491 : List Nat := [2,4,8,16,32,64,9,256,81,1024,293,17,365,1297,80,358,1376,97,1024,81,81,33,16,3,364,64,276,1377,16,81,1332,33,256,65,1344,49]

theorem envBound19491 : H12AffineFastState.Bounded env19491 := by
  intro p hp
  have h : env19491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19490_19491 : H12AffineEnvironment.transform 12 365 env19490 = env19491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 365 env19490 == env19491) = true)

theorem identity19491 : scanCanonicalize (H12AffineFastState.compose env19491 (packedSelected [1,5,12,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19491 : packedSelected [1,5,12,14] rootPS < 2^1333 := by decide +kernel

def env19492 : List Nat := [2,4,8,16,1,64,9,256,81,1024,260,17,332,1297,80,327,1345,64,1024,81,81,0,16,3,333,64,276,1344,16,81,1301,0,256,65,1344,16]

theorem envBound19492 : H12AffineFastState.Bounded env19492 := by
  intro p hp
  have h : env19492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19491_19492 : H12AffineEnvironment.transform 4 1 env19491 = env19492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19491 == env19492) = true)

theorem identity19492 : scanCanonicalize (H12AffineFastState.compose env19492 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19492 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19493 : List Nat := [2,4,8,16,1,16,9,256,1,1024,260,17,284,1297,0,279,1297,16,1024,1,1,0,16,3,285,16,276,1296,16,1,1301,0,256,17,1296,16]

theorem envBound19493 : H12AffineFastState.Bounded env19493 := by
  intro p hp
  have h : env19493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19492_19493 : H12AffineEnvironment.transform 5 16 env19492 = env19493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19492 == env19493) = true)

theorem identity19493 : scanCanonicalize (H12AffineFastState.compose env19493 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound19493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19494 : List Nat := [2,4,8,16,1,16,9,256,1,4,260,17,284,277,0,279,277,16,4,1,1,0,16,3,285,16,276,276,16,1,273,0,256,17,276,16]

theorem envBound19494 : H12AffineFastState.Bounded env19494 := by
  intro p hp
  have h : env19494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19493_19494 : H12AffineEnvironment.transform 9 4 env19493 = env19494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env19493 == env19494) = true)

theorem identity19494 : scanCanonicalize (H12AffineFastState.compose env19494 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19494 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19495 : List Nat := [2,4,8,16,1,16,9,20,1,4,16,17,8,1,0,3,1,16,4,1,1,0,16,3,9,16,0,0,16,1,5,0,20,17,0,16]

theorem envBound19495 : H12AffineFastState.Bounded env19495 := by
  intro p hp
  have h : env19495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19494_19495 : H12AffineEnvironment.transform 7 20 env19494 = env19495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19494 == env19495) = true)

theorem identity19495 : scanCanonicalize (H12AffineFastState.compose env19495 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19495 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19496 : List Nat := [2,4,8,0,1,0,9,4,1,4,0,1,8,1,0,3,1,0,4,1,1,0,0,3,9,0,0,0,0,1,5,0,4,1,0,0]

theorem envBound19496 : H12AffineFastState.Bounded env19496 := by
  intro p hp
  have h : env19496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19495_19496 : H12AffineEnvironment.transform 3 0 env19495 = env19496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19495 == env19496) = true)

def env19497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32161,1024,32769,4160,21793,21776,138,8328,64,171281,46157,4097,190640,61824,33,256,41340,16600,63069]

theorem envBound19497 : H12AffineFastState.Bounded env19497 := by
  intro p hp
  have h : env19497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19482_19497 : H12AffineEnvironment.transform 17 32161 env19482 = env19497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env19482 == env19497) = true)

theorem identity19497 : scanCanonicalize (H12AffineFastState.compose env19497 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound19497 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env19498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38297,32161,1024,32769,4160,21793,21776,138,8328,64,2184,46157,4097,32041,61824,33,256,41340,16600,63069]

theorem envBound19498 : H12AffineFastState.Bounded env19498 := by
  intro p hp
  have h : env19498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19497_19498 : H12AffineEnvironment.transform 16 38297 env19497 = env19498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env19497 == env19498) = true)

theorem identity19498 : scanCanonicalize (H12AffineFastState.compose env19498 (packedSelected [0,5,6,12,16,18,19,20,23,24,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound19498 : packedSelected [0,5,6,12,16,18,19,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env19499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,8203,13461,32161,1024,8461,4160,21793,21776,138,8328,64,2184,5441,4097,32041,20620,33,256,112,16600,22353]

theorem envBound19499 : H12AffineFastState.Bounded env19499 := by
  intro p hp
  have h : env19499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19498_19499 : H12AffineEnvironment.transform 14 8460 env19498 = env19499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env19498 == env19499) = true)

theorem identity19499 : scanCanonicalize (H12AffineFastState.compose env19499 (packedSelected [0,2,7,9,10,11,14,16,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19499 : packedSelected [0,2,7,9,10,11,14,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env19500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8460,8203,13461,2477,1024,8461,4160,8493,8476,138,8328,64,2184,5441,4097,2341,9344,33,256,112,13524,9053]

theorem envBound19500 : H12AffineFastState.Bounded env19500 := by
  intro p hp
  have h : env19500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19499_19500 : H12AffineEnvironment.transform 13 13324 env19499 = env19500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19499 == env19500) = true)

theorem identity19500 : scanCanonicalize (H12AffineFastState.compose env19500 (packedSelected [1,2,3,5,8,10,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19500 : packedSelected [1,2,3,5,8,10,16,19] rootPS < 2^1333 := by decide +kernel

def env19501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5513,137,398,5392,2477,1024,136,4160,168,153,138,269,64,2184,5441,4097,2341,1285,33,256,112,5457,728]

theorem envBound19501 : H12AffineFastState.Bounded env19501 := by
  intro p hp
  have h : env19501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19500_19501 : H12AffineEnvironment.transform 12 389 env19500 = env19501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19500 == env19501) = true)

theorem identity19501 : scanCanonicalize (H12AffineFastState.compose env19501 (packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19501 : packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env19502 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,161,5293,137,170,5172,2185,1024,136,4160,168,153,138,41,64,2184,5221,4097,2049,1057,33,36,112,5237,728]

theorem envBound19502 : H12AffineFastState.Bounded env19502 := by
  intro p hp
  have h : env19502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19501_19502 : H12AffineEnvironment.transform 7 36 env19501 = env19502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19501 == env19502) = true)

theorem identity19502 : scanCanonicalize (H12AffineFastState.compose env19502 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19502 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env19503 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,161,5293,137,170,5172,2185,1024,136,4112,168,153,138,41,16,2184,5173,4097,2049,1057,33,36,32,5157,648]

theorem envBound19503 : H12AffineFastState.Bounded env19503 := by
  intro p hp
  have h : env19503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19502_19503 : H12AffineEnvironment.transform 5 16 env19502 = env19503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19502 == env19503) = true)

theorem identity19503 : scanCanonicalize (H12AffineFastState.compose env19503 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound19503 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env19504 : List Nat := [2,4,8,16,32,16,128,36,512,189,2048,4096,161,4112,137,170,4233,2185,189,136,4112,168,153,138,41,16,2184,4232,4097,2049,156,33,36,32,4248,648]

theorem envBound19504 : H12AffineFastState.Bounded env19504 := by
  intro p hp
  have h : env19504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19503_19504 : H12AffineEnvironment.transform 9 189 env19503 = env19504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env19503 == env19504) = true)

theorem identity19504 : scanCanonicalize (H12AffineFastState.compose env19504 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound19504 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env19505 : List Nat := [2,4,8,16,32,16,128,36,512,189,48,4096,161,4112,137,170,4233,185,189,136,4112,168,153,138,41,16,184,4232,4097,49,156,33,36,32,4248,648]

theorem envBound19505 : H12AffineFastState.Bounded env19505 := by
  intro p hp
  have h : env19505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19504_19505 : H12AffineEnvironment.transform 10 48 env19504 = env19505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env19504 == env19505) = true)

theorem identity19505 : scanCanonicalize (H12AffineFastState.compose env19505 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19505 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env19506 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,4096,41,4112,1,34,4097,49,53,0,4112,32,17,2,41,16,48,4096,4097,49,20,33,36,32,4112,512]

theorem envBound19506 : H12AffineFastState.Bounded env19506 := by
  intro p hp
  have h : env19506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19505_19506 : H12AffineEnvironment.transform 6 8 env19505 = env19506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19505 == env19506) = true)

theorem identity19506 : scanCanonicalize (H12AffineFastState.compose env19506 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound19506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19507 : List Nat := [2,4,8,16,32,16,8,36,48,53,48,4096,41,4112,1,34,4097,49,53,0,4112,32,17,2,41,16,48,4096,4097,49,20,33,36,32,4112,48]

theorem envBound19507 : H12AffineFastState.Bounded env19507 := by
  intro p hp
  have h : env19507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19506_19507 : H12AffineEnvironment.transform 8 48 env19506 = env19507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env19506 == env19507) = true)

theorem identity19507 : scanCanonicalize (H12AffineFastState.compose env19507 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound19507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19508 : List Nat := [2,1,8,16,32,16,8,33,48,48,48,4096,41,4112,1,34,4097,49,48,0,4112,32,17,2,41,16,48,4096,4097,49,17,33,33,32,4112,48]

theorem envBound19508 : H12AffineFastState.Bounded env19508 := by
  intro p hp
  have h : env19508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19507_19508 : H12AffineEnvironment.transform 1 1 env19507 = env19508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env19507 == env19508) = true)

theorem identity19508 : scanCanonicalize (H12AffineFastState.compose env19508 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound19508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19509 : List Nat := [2,1,8,16,32,16,8,33,48,48,48,33,41,49,1,34,32,49,48,0,49,32,17,2,41,16,48,33,32,49,17,33,33,32,49,48]

theorem envBound19509 : H12AffineFastState.Bounded env19509 := by
  intro p hp
  have h : env19509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19508_19509 : H12AffineEnvironment.transform 11 33 env19508 = env19509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env19508 == env19509) = true)

theorem identity19509 : scanCanonicalize (H12AffineFastState.compose env19509 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19509 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19510 : List Nat := [2,1,8,0,32,0,8,33,32,32,32,33,41,33,1,34,32,33,32,0,33,32,1,2,41,0,32,33,32,33,1,33,33,32,33,32]

theorem envBound19510 : H12AffineFastState.Bounded env19510 := by
  intro p hp
  have h : env19510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19509_19510 : H12AffineEnvironment.transform 3 0 env19509 = env19510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19509 == env19510) = true)

theorem identity19510 : scanCanonicalize (H12AffineFastState.compose env19510 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19510 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19511 : List Nat := [2,1,8,0,1,0,8,0,1,1,1,0,8,0,1,3,1,0,1,0,0,1,1,2,8,0,1,0,1,0,1,0,0,1,0,1]

theorem envBound19511 : H12AffineFastState.Bounded env19511 := by
  intro p hp
  have h : env19511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19510_19511 : H12AffineEnvironment.transform 4 1 env19510 = env19511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19510 == env19511) = true)

def env19512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73856,8328,64,508090,46157,77834,505115,119179,32,256,98678,90322,63069]

theorem envBound19512 : H12AffineFastState.Bounded env19512 := by
  intro p hp
  have h : env19512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19480_19512 : H12AffineEnvironment.transform 20 4161 env19480 = env19512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19480 == env19512) = true)

theorem identity19512 : scanCanonicalize (H12AffineFastState.compose env19512 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound19512 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30082,131072,262144,1024,32769,4161,21792,152,21762,8328,64,439608,46157,17800,442521,41993,32,256,62708,5456,63069]

theorem envBound19513 : H12AffineFastState.Bounded env19513 := by
  intro p hp
  have h : env19513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19512_19513 : H12AffineEnvironment.transform 15 30082 env19512 = env19513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env19512 == env19513) = true)

def env19514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,4161,21792,16,21762,8192,64,439608,46157,17664,442385,41993,32,256,62588,5456,63069]

theorem envBound19514 : H12AffineFastState.Bounded env19514 := by
  intro p hp
  have h : env19514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19513_19514 : H12AffineEnvironment.transform 6 8 env19513 = env19514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19513 == env19514) = true)

theorem identity19514 : scanCanonicalize (H12AffineFastState.compose env19514 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19514 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,4161,21792,16,21762,8192,64,409956,16401,17664,406605,20565,32,256,32,5456,513]

theorem envBound19515 : H12AffineFastState.Bounded env19515 := by
  intro p hp
  have h : env19515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19514_19515 : H12AffineEnvironment.transform 14 29788 env19514 = env19515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19514 == env19515) = true)

theorem identity19515 : scanCanonicalize (H12AffineFastState.compose env19515 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound19515 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env19516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,131072,149861,1024,29789,4161,21792,16,21762,8192,64,2049,16401,17664,32040,20565,32,256,32,5456,513]

theorem envBound19516 : H12AffineFastState.Bounded env19516 := by
  intro p hp
  have h : env19516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19515_19516 : H12AffineEnvironment.transform 17 149861 env19515 = env19516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env19515 == env19516) = true)

theorem identity19516 : scanCanonicalize (H12AffineFastState.compose env19516 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19516 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env19517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,23669,1024,29789,4161,21792,16,21762,8192,64,2049,16401,17664,32040,20565,32,256,32,5456,513]

theorem envBound19517 : H12AffineFastState.Bounded env19517 := by
  intro p hp
  have h : env19517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19516_19517 : H12AffineEnvironment.transform 16 5392 env19516 = env19517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19516 == env19517) = true)

theorem identity19517 : scanCanonicalize (H12AffineFastState.compose env19517 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19517 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21590,5392,23669,1024,21761,4161,21792,16,21762,348,64,2049,16401,17664,23668,20565,32,256,32,5456,513]

theorem envBound19518 : H12AffineFastState.Bounded env19518 := by
  intro p hp
  have h : env19518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19517_19518 : H12AffineEnvironment.transform 12 348 env19517 = env19518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19517 == env19518) = true)

def env19519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,4161,21792,17,21762,8193,64,439608,46157,17665,442384,41993,32,256,62589,5456,63069]

theorem envBound19519 : H12AffineFastState.Bounded env19519 := by
  intro p hp
  have h : env19519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19513_19519 : H12AffineEnvironment.transform 6 9 env19513 = env19519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19513 == env19519) = true)

theorem identity19519 : scanCanonicalize (H12AffineFastState.compose env19519 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound19519 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32040,1024,32769,4161,21792,17,21762,8193,64,182288,46157,17665,179512,41993,32,256,62589,5456,63069]

theorem envBound19520 : H12AffineFastState.Bounded env19520 := by
  intro p hp
  have h : env19520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19519_19520 : H12AffineEnvironment.transform 17 32040 env19519 = env19520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env19519 == env19520) = true)

theorem identity19520 : scanCanonicalize (H12AffineFastState.compose env19520 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19520 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env19521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,5392,32040,1024,32769,4161,21792,17,21762,8193,64,56576,46157,17665,43048,41993,32,256,62589,5456,63069]

theorem envBound19521 : H12AffineFastState.Bounded env19521 := by
  intro p hp
  have h : env19521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19520_19521 : H12AffineEnvironment.transform 16 5392 env19520 = env19521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19520 == env19521) = true)

theorem identity19521 : scanCanonicalize (H12AffineFastState.compose env19521 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19521 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,5392,32040,1024,29789,4161,21792,17,21762,8193,64,10588,16401,17665,23668,20565,32,256,33,5456,513]

theorem envBound19522 : H12AffineFastState.Bounded env19522 := by
  intro p hp
  have h : env19522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19521_19522 : H12AffineEnvironment.transform 14 29788 env19521 = env19522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19521 == env19522) = true)

theorem identity19522 : scanCanonicalize (H12AffineFastState.compose env19522 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound19522 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,20496,20807,5392,22884,1024,20497,4161,21792,17,21762,1101,64,3344,16401,17665,23668,20565,32,256,33,5456,513]

theorem envBound19523 : H12AffineFastState.Bounded env19523 := by
  intro p hp
  have h : env19523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19522_19523 : H12AffineEnvironment.transform 12 1100 env19522 = env19523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env19522 == env19523) = true)

theorem identity19523 : scanCanonicalize (H12AffineFastState.compose env19523 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19523 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env19524 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1100,16384,20496,20578,5173,22593,1024,20497,4161,21509,17,21543,1101,64,3125,16401,17444,23668,20565,32,37,33,5237,513]

theorem envBound19524 : H12AffineFastState.Bounded env19524 := by
  intro p hp
  have h : env19524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19523_19524 : H12AffineEnvironment.transform 7 37 env19523 = env19524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19523 == env19524) = true)

theorem identity19524 : scanCanonicalize (H12AffineFastState.compose env19524 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound19524 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env19525 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1100,2129,6209,6195,5173,4112,1024,6208,4161,7252,17,7286,1101,64,3125,2112,3189,5157,6148,32,37,33,5237,513]

theorem envBound19525 : H12AffineFastState.Bounded env19525 := by
  intro p hp
  have h : env19525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19524_19525 : H12AffineEnvironment.transform 13 2129 env19524 = env19525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env19524 == env19525) = true)

theorem identity19525 : scanCanonicalize (H12AffineFastState.compose env19525 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound19525 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env19526 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,1100,2129,1125,1047,2065,3124,1024,1124,3173,112,17,82,1101,64,3125,2112,3189,2049,1056,32,37,33,2129,513]

theorem envBound19526 : H12AffineFastState.Bounded env19526 := by
  intro p hp
  have h : env19526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19525_19526 : H12AffineEnvironment.transform 11 3108 env19525 = env19526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env19525 == env19526) = true)

theorem identity19526 : scanCanonicalize (H12AffineFastState.compose env19526 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19526 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env19527 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3108,1052,2049,1077,1047,2065,3124,1024,1076,3125,32,17,2,1053,16,3125,2064,3109,2049,1056,32,37,33,2049,513]

theorem envBound19527 : H12AffineFastState.Bounded env19527 := by
  intro p hp
  have h : env19527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19526_19527 : H12AffineEnvironment.transform 5 16 env19526 = env19527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19526 == env19527) = true)

theorem identity19527 : scanCanonicalize (H12AffineFastState.compose env19527 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound19527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19528 : List Nat := [2,4,8,16,32,16,9,37,512,1024,49,1045,1052,48,1077,1047,32,1029,1024,1076,1028,32,17,2,1053,16,1028,33,1044,48,1056,32,37,33,48,513]

theorem envBound19528 : H12AffineFastState.Bounded env19528 := by
  intro p hp
  have h : env19528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19527_19528 : H12AffineEnvironment.transform 10 49 env19527 = env19528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env19527 == env19528) = true)

theorem identity19528 : scanCanonicalize (H12AffineFastState.compose env19528 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound19528 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19529 : List Nat := [2,4,8,16,32,16,9,37,512,564,49,545,552,48,513,547,32,561,564,512,560,32,17,2,553,16,560,33,544,48,532,32,37,33,48,513]

theorem envBound19529 : H12AffineFastState.Bounded env19529 := by
  intro p hp
  have h : env19529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19528_19529 : H12AffineEnvironment.transform 9 564 env19528 = env19529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env19528 == env19529) = true)

theorem identity19529 : scanCanonicalize (H12AffineFastState.compose env19529 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound19529 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env19530 : List Nat := [2,4,8,16,32,16,9,37,32,20,49,1,8,48,33,3,32,17,20,32,16,32,17,2,9,16,16,33,0,48,52,32,37,33,48,33]

theorem envBound19530 : H12AffineFastState.Bounded env19530 := by
  intro p hp
  have h : env19530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19529_19530 : H12AffineEnvironment.transform 8 32 env19529 = env19530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env19529 == env19530) = true)

theorem identity19530 : scanCanonicalize (H12AffineFastState.compose env19530 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19530 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19531 : List Nat := [2,4,8,16,0,16,9,5,0,20,17,1,8,16,1,3,0,17,20,0,16,0,17,2,9,16,16,1,0,16,20,0,5,1,16,1]

theorem envBound19531 : H12AffineFastState.Bounded env19531 := by
  intro p hp
  have h : env19531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19530_19531 : H12AffineEnvironment.transform 4 0 env19530 = env19531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19530 == env19531) = true)

theorem identity19531 : scanCanonicalize (H12AffineFastState.compose env19531 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19531 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19532 : List Nat := [2,4,8,1,0,1,9,5,0,5,0,1,8,1,1,3,0,0,5,0,1,0,0,2,9,1,1,1,0,1,5,0,5,1,1,1]

theorem envBound19532 : H12AffineFastState.Bounded env19532 := by
  intro p hp
  have h : env19532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19531_19532 : H12AffineEnvironment.transform 3 1 env19531 = env19532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19531 == env19532) = true)

def env19533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound19533 : H12AffineFastState.Bounded env19533 := by
  intro p hp
  have h : env19533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19337_19533 : H12AffineEnvironment.transform 18 1025 env19337 = env19533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19337 == env19533) = true)

theorem identity19533 : scanCanonicalize (H12AffineFastState.compose env19533 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262491) := by decide +kernel

theorem selectedBound19533 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262491,8328,64,15025626,196950,10507601,8830976,10682826,4448282,257,8601975,8626386,10626589]

theorem envBound19534 : H12AffineFastState.Bounded env19534 := by
  intro p hp
  have h : env19534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19533_19534 : H12AffineEnvironment.transform 23 2262491 env19533 = env19534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262491 env19533 == env19534) = true)

def env19535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025626,115150,10507601,8650904,10600786,4268162,257,8487407,8478794,10544773]

theorem envBound19535 : H12AffineFastState.Bounded env19535 := by
  intro p hp
  have h : env19535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19534_19535 : H12AffineEnvironment.transform 16 49304 env19534 = env19535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env19534 == env19535) = true)

def env19536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543882,115150,17665,2363592,119042,4268162,257,2199999,2191386,63189]

theorem envBound19536 : H12AffineFastState.Bounded env19536 := by
  intro p hp
  have h : env19536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19535_19536 : H12AffineEnvironment.transform 22 2101328 env19535 = env19536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env19535 == env19536) = true)

def env19537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97546,115150,17665,2363592,119042,329730,257,2199999,2191386,63189]

theorem envBound19537 : H12AffineFastState.Bounded env19537 := by
  intro p hp
  have h : env19537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19536_19537 : H12AffineEnvironment.transform 21 272512 env19536 = env19537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19536 == env19537) = true)

theorem identity19537 : scanCanonicalize (H12AffineFastState.compose env19537 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound19537 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4161,272512,17,21762,8328,64,97546,115150,17665,262281,119042,329730,257,98814,90203,63189]

theorem envBound19538 : H12AffineFastState.Bounded env19538 := by
  intro p hp
  have h : env19538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19537_19538 : H12AffineEnvironment.transform 20 4161 env19537 = env19538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19537 == env19538) = true)

def env19539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21762,8192,64,97546,115014,17665,262145,119042,329730,257,98678,90203,63069]

theorem envBound19539 : H12AffineFastState.Bounded env19539 := by
  intro p hp
  have h : env19539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19538_19539 : H12AffineEnvironment.transform 6 8 env19538 = env19539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19538 == env19539) = true)

theorem identity19539 : scanCanonicalize (H12AffineFastState.compose env19539 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound19539 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32041,1025,32769,4161,21793,17,21762,8192,64,97546,115014,17665,32040,119042,95531,257,98678,90203,63069]

theorem envBound19540 : H12AffineFastState.Bounded env19540 := by
  intro p hp
  have h : env19540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19539_19540 : H12AffineEnvironment.transform 17 32041 env19539 = env19540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env19539 == env19540) = true)

theorem identity19540 : scanCanonicalize (H12AffineFastState.compose env19540 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound19540 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env19541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21795,49168,32041,1025,32769,4161,21793,17,21762,8192,64,10281,37989,17665,32040,33825,8200,257,54357,13688,63069]

theorem envBound19541 : H12AffineFastState.Bounded env19541 := by
  intro p hp
  have h : env19541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19540_19541 : H12AffineEnvironment.transform 15 21795 env19540 = env19541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env19540 == env19541) = true)

theorem identity19541 : scanCanonicalize (H12AffineFastState.compose env19541 (packedSelected [0,2,6,11,14,16,18,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19541 : packedSelected [0,2,6,11,14,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env19542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21795,16401,32041,1025,0,4161,21793,17,21762,8192,64,10281,5220,17665,32040,1056,8200,257,21588,13688,30300]

theorem envBound19542 : H12AffineFastState.Bounded env19542 := by
  intro p hp
  have h : env19542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19541_19542 : H12AffineEnvironment.transform 14 1 env19541 = env19542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19541 == env19542) = true)

theorem identity19542 : scanCanonicalize (H12AffineFastState.compose env19542 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound19542 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env19543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,1,8203,13625,2049,1025,0,4161,8201,17,8234,8192,64,10281,5220,12329,2048,1056,8200,257,8572,13688,884]

theorem envBound19543 : H12AffineFastState.Bounded env19543 := by
  intro p hp
  have h : env19543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19542_19543 : H12AffineEnvironment.transform 13 13608 env19542 = env19543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env19542 == env19543) = true)

theorem identity19543 : scanCanonicalize (H12AffineFastState.compose env19543 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19543 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5236,1,343,5221,2049,1025,0,4161,341,17,374,348,64,2421,5220,4469,2048,1056,340,257,32,5156,884]

theorem envBound19544 : H12AffineFastState.Bounded env19544 := by
  intro p hp
  have h : env19544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19543_19544 : H12AffineEnvironment.transform 12 348 env19543 = env19544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19543 == env19544) = true)

theorem identity19544 : scanCanonicalize (H12AffineFastState.compose env19544 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19544 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19545 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,1,35,5221,2049,1025,0,4161,33,17,2,40,64,2049,5220,4097,2048,1056,32,117,32,5156,512]

theorem envBound19545 : H12AffineFastState.Bounded env19545 := by
  intro p hp
  have h : env19545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19544_19545 : H12AffineEnvironment.transform 7 116 env19544 = env19545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19544 == env19545) = true)

theorem identity19545 : scanCanonicalize (H12AffineFastState.compose env19545 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound19545 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19546 : List Nat := [2,4,8,16,32,64,8,116,512,69,2048,4096,40,4145,1,35,4128,2049,68,0,4161,33,17,2,40,64,2049,4129,4097,2048,101,32,117,32,4193,512]

theorem envBound19546 : H12AffineFastState.Bounded env19546 := by
  intro p hp
  have h : env19546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19545_19546 : H12AffineEnvironment.transform 9 69 env19545 = env19546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env19545 == env19546) = true)

theorem identity19546 : scanCanonicalize (H12AffineFastState.compose env19546 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19547 : List Nat := [2,4,8,16,1,64,8,85,512,69,2048,4096,9,4112,1,2,4097,2049,68,0,4161,0,17,2,9,64,2049,4096,4097,2048,68,1,84,1,4160,512]

theorem envBound19547 : H12AffineFastState.Bounded env19547 := by
  intro p hp
  have h : env19547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19546_19547 : H12AffineEnvironment.transform 4 1 env19546 = env19547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19546 == env19547) = true)

theorem identity19547 : scanCanonicalize (H12AffineFastState.compose env19547 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound19547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19548 : List Nat := [2,4,8,16,1,64,8,85,512,69,2048,17,9,1,1,2,16,2049,68,0,80,0,17,2,9,64,2049,17,16,2048,68,1,84,1,81,512]

theorem envBound19548 : H12AffineFastState.Bounded env19548 := by
  intro p hp
  have h : env19548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19547_19548 : H12AffineEnvironment.transform 11 17 env19547 = env19548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19547 == env19548) = true)

theorem identity19548 : scanCanonicalize (H12AffineFastState.compose env19548 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound19548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19549 : List Nat := [2,4,8,16,1,64,8,85,512,69,80,17,9,1,1,2,16,81,68,0,80,0,17,2,9,64,81,17,16,80,68,1,84,1,81,512]

theorem envBound19549 : H12AffineFastState.Bounded env19549 := by
  intro p hp
  have h : env19549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19548_19549 : H12AffineEnvironment.transform 10 80 env19548 = env19549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env19548 == env19549) = true)

theorem identity19549 : scanCanonicalize (H12AffineFastState.compose env19549 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 94) := by decide +kernel

theorem selectedBound19549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19550 : List Nat := [2,4,8,16,1,64,8,85,94,69,80,17,9,1,1,2,16,81,68,0,80,0,17,2,9,64,81,17,16,80,68,1,84,1,81,94]

theorem envBound19550 : H12AffineFastState.Bounded env19550 := by
  intro p hp
  have h : env19550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19549_19550 : H12AffineEnvironment.transform 8 94 env19549 = env19550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 94 env19549 == env19550) = true)

def env19551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21762,8193,64,97546,115015,17665,262144,119042,329730,257,98679,90203,63068]

theorem envBound19551 : H12AffineFastState.Bounded env19551 := by
  intro p hp
  have h : env19551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19538_19551 : H12AffineEnvironment.transform 6 9 env19538 = env19551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19538 == env19551) = true)

theorem identity19551 : scanCanonicalize (H12AffineFastState.compose env19551 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound19551 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56436,1025,32769,4161,62589,17,21762,8193,64,97546,115015,17665,56436,119042,119926,257,98679,90203,63068]

theorem envBound19552 : H12AffineFastState.Bounded env19552 := by
  intro p hp
  have h : env19552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19551_19552 : H12AffineEnvironment.transform 17 56436 env19551 = env19552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env19551 == env19552) = true)

theorem identity19552 : scanCanonicalize (H12AffineFastState.compose env19552 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound19552 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,5393,2420,1025,21761,4161,8573,17,21762,8193,64,97546,70727,17665,2420,66562,65910,257,87159,90203,9052]

theorem envBound19553 : H12AffineFastState.Bounded env19553 := by
  intro p hp
  have h : env19553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19552_19553 : H12AffineEnvironment.transform 14 21760 env19552 = env19553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env19552 == env19553) = true)

theorem identity19553 : scanCanonicalize (H12AffineFastState.compose env19553 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19553 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env19554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,5393,2420,1025,21761,4161,8573,17,21762,8193,64,23808,13389,17665,2420,9224,8572,257,29821,16465,9052]

theorem envBound19554 : H12AffineFastState.Bounded env19554 := by
  intro p hp
  have h : env19554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19553_19554 : H12AffineEnvironment.transform 15 8202 env19553 = env19554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19553 == env19554) = true)

def env19555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97547,115150,17665,2363592,119042,329731,257,2199999,2191386,63189]

theorem envBound19555 : H12AffineFastState.Bounded env19555 := by
  intro p hp
  have h : env19555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19536_19555 : H12AffineEnvironment.transform 21 272513 env19536 = env19555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19536 == env19555) = true)

def env19556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101328,2114883,8192,64,97547,115014,17665,2363456,119042,329731,257,2199863,2191386,63069]

theorem envBound19556 : H12AffineFastState.Bounded env19556 := by
  intro p hp
  have h : env19556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19555_19556 : H12AffineEnvironment.transform 6 8 env19555 = env19556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19555 == env19556) = true)

def env19557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,16,21763,8192,64,97547,115014,17665,262144,119042,329731,257,98679,90202,63069]

theorem envBound19557 : H12AffineFastState.Bounded env19557 := by
  intro p hp
  have h : env19557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19556_19557 : H12AffineEnvironment.transform 20 4160 env19556 = env19557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19556 == env19557) = true)

theorem identity19557 : scanCanonicalize (H12AffineFastState.compose env19557 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19557 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,262144,1025,32769,4160,272393,16,2,8192,64,75786,103495,4096,262144,99331,329731,257,98679,79195,41820]

theorem envBound19558 : H12AffineFastState.Bounded env19558 := by
  intro p hp
  have h : env19558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19557_19558 : H12AffineEnvironment.transform 13 5377 env19557 = env19558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19557 == env19558) = true)

theorem identity19558 : scanCanonicalize (H12AffineFastState.compose env19558 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound19558 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env19559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10360,1025,32769,4160,113,16,2,8192,64,75786,103495,4096,10360,99331,73851,257,98679,79195,41820]

theorem envBound19559 : H12AffineFastState.Bounded env19559 := by
  intro p hp
  have h : env19559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19558_19559 : H12AffineEnvironment.transform 17 10360 env19558 = env19559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env19558 == env19559) = true)

theorem identity19559 : scanCanonicalize (H12AffineFastState.compose env19559 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 41343) := by decide +kernel

theorem selectedBound19559 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env19560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,41343,38161,10360,1025,32769,4160,113,16,2,8192,64,35189,13624,4096,10360,9596,33028,257,8200,37924,41820]

theorem envBound19560 : H12AffineFastState.Bounded env19560 := by
  intro p hp
  have h : env19560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19559_19560 : H12AffineEnvironment.transform 15 41343 env19559 = env19560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41343 env19559 == env19560) = true)

theorem identity19560 : scanCanonicalize (H12AffineFastState.compose env19560 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound19560 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8312,263,13673,10360,1025,8313,4160,113,16,2,8192,64,10509,13624,4096,10360,9596,8572,257,8200,13404,804]

theorem envBound19561 : H12AffineFastState.Bounded env19561 := by
  intro p hp
  have h : env19561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19560_19561 : H12AffineEnvironment.transform 14 8312 env19560 = env19561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env19560 == env19561) = true)

theorem identity19561 : scanCanonicalize (H12AffineFastState.compose env19561 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19561 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env19562 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8312,115,13341,10360,1025,8313,4160,113,16,2,8192,64,10361,13388,4096,10360,9224,8200,117,8200,13404,592]

theorem envBound19562 : H12AffineFastState.Bounded env19562 := by
  intro p hp
  have h : env19562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19561_19562 : H12AffineEnvironment.transform 7 116 env19561 = env19562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19561 == env19562) = true)

theorem identity19562 : scanCanonicalize (H12AffineFastState.compose env19562 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound19562 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env19563 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1101,5237,1077,115,4176,3125,1025,1076,4160,113,16,2,1101,64,3124,4097,4096,3125,69,1093,117,1093,4113,592]

theorem envBound19563 : H12AffineFastState.Bounded env19563 := by
  intro p hp
  have h : env19563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19562_19563 : H12AffineEnvironment.transform 12 1101 env19562 = env19563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env19562 == env19563) = true)

theorem identity19563 : scanCanonicalize (H12AffineFastState.compose env19563 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound19563 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env19564 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2065,1101,3172,1077,115,2113,3125,1025,1076,2129,113,16,2,1101,64,3124,2064,2065,3125,69,1093,117,1093,2048,592]

theorem envBound19564 : H12AffineFastState.Bounded env19564 := by
  intro p hp
  have h : env19564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19563_19564 : H12AffineEnvironment.transform 11 2065 env19563 = env19564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env19563 == env19564) = true)

theorem identity19564 : scanCanonicalize (H12AffineFastState.compose env19564 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19564 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env19565 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,2065,121,2128,1,115,2113,2049,53,0,2129,113,16,2,121,64,2048,2064,2065,2049,69,113,117,113,2048,592]

theorem envBound19565 : H12AffineFastState.Bounded env19565 := by
  intro p hp
  have h : env19565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19564_19565 : H12AffineEnvironment.transform 9 52 env19564 = env19565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19564 == env19565) = true)

theorem identity19565 : scanCanonicalize (H12AffineFastState.compose env19565 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19565 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env19566 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,41,2048,1,35,2065,2049,53,0,2049,33,16,2,41,16,2048,2064,2065,2049,21,33,37,33,2048,512]

theorem envBound19566 : H12AffineFastState.Bounded env19566 := by
  intro p hp
  have h : env19566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19565_19566 : H12AffineEnvironment.transform 5 16 env19565 = env19566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19565 == env19566) = true)

theorem identity19566 : scanCanonicalize (H12AffineFastState.compose env19566 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound19566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19567 : List Nat := [2,4,8,16,32,16,8,36,21,52,2048,2065,41,2048,1,35,2065,2049,53,0,2049,33,16,2,41,16,2048,2064,2065,2049,21,33,37,33,2048,21]

theorem envBound19567 : H12AffineFastState.Bounded env19567 := by
  intro p hp
  have h : env19567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19566_19567 : H12AffineEnvironment.transform 8 21 env19566 = env19567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env19566 == env19567) = true)

theorem identity19567 : scanCanonicalize (H12AffineFastState.compose env19567 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound19567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19568 : List Nat := [2,3,8,16,32,16,8,35,18,51,2048,2065,41,2048,1,35,2065,2049,50,0,2049,33,16,2,41,16,2048,2064,2065,2049,18,33,34,33,2048,18]

theorem envBound19568 : H12AffineFastState.Bounded env19568 := by
  intro p hp
  have h : env19568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19567_19568 : H12AffineEnvironment.transform 1 3 env19567 = env19568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env19567 == env19568) = true)

theorem identity19568 : scanCanonicalize (H12AffineFastState.compose env19568 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound19568 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19569 : List Nat := [2,3,8,16,32,16,8,35,18,51,49,32,41,49,1,35,32,48,50,0,48,33,16,2,41,16,49,33,32,48,18,33,34,33,49,18]

theorem envBound19569 : H12AffineFastState.Bounded env19569 := by
  intro p hp
  have h : env19569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19568_19569 : H12AffineEnvironment.transform 10 49 env19568 = env19569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env19568 == env19569) = true)

theorem identity19569 : scanCanonicalize (H12AffineFastState.compose env19569 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19569 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19570 : List Nat := [2,3,8,10,32,10,8,35,8,41,43,32,41,43,1,35,32,42,40,0,42,33,10,2,41,10,43,33,32,42,8,33,34,33,43,8]

theorem envBound19570 : H12AffineFastState.Bounded env19570 := by
  intro p hp
  have h : env19570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19569_19570 : H12AffineEnvironment.transform 3 10 env19569 = env19570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19569 == env19570) = true)

theorem identity19570 : scanCanonicalize (H12AffineFastState.compose env19570 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19570 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19571 : List Nat := [2,3,8,10,1,10,8,2,8,8,10,1,8,10,1,2,1,11,9,0,11,0,10,2,8,10,10,0,1,11,8,0,3,0,10,8]

theorem envBound19571 : H12AffineFastState.Bounded env19571 := by
  intro p hp
  have h : env19571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19570_19571 : H12AffineEnvironment.transform 4 1 env19570 = env19571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19570 == env19571) = true)

def env19572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21762,8192,64,97547,115014,17665,262145,119042,329731,257,98678,90203,63069]

theorem envBound19572 : H12AffineFastState.Bounded env19572 := by
  intro p hp
  have h : env19572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19556_19572 : H12AffineEnvironment.transform 20 4161 env19556 = env19572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19556 == env19572) = true)

theorem identity19572 : scanCanonicalize (H12AffineFastState.compose env19572 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound19572 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32041,1025,32769,4161,21792,17,21762,8192,64,97547,115014,17665,32040,119042,95530,257,98678,90203,63069]

theorem envBound19573 : H12AffineFastState.Bounded env19573 := by
  intro p hp
  have h : env19573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19572_19573 : H12AffineEnvironment.transform 17 32041 env19572 = env19573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env19572 == env19573) = true)

theorem identity19573 : scanCanonicalize (H12AffineFastState.compose env19573 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62510) := by decide +kernel

theorem selectedBound19573 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env19574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62510,49168,32041,1025,32769,4161,21792,17,21762,8192,64,35109,13672,17665,32040,9516,33028,257,30040,38005,63069]

theorem envBound19574 : H12AffineFastState.Bounded env19574 := by
  intro p hp
  have h : env19574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19573_19574 : H12AffineEnvironment.transform 15 62510 env19573 = env19574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62510 env19573 == env19574) = true)

theorem identity19574 : scanCanonicalize (H12AffineFastState.compose env19574 (packedSelected [0,3,5,9,10,12,15,19,22,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound19574 : packedSelected [0,3,5,9,10,12,15,19,22,26,27] rootPS < 2^1333 := by decide +kernel

def env19575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,8575,5441,32041,1025,21840,4161,21792,17,21762,8192,64,23668,13672,17665,32040,9516,21589,257,30040,16676,8972]

theorem envBound19575 : H12AffineFastState.Bounded env19575 := by
  intro p hp
  have h : env19575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19574_19575 : H12AffineEnvironment.transform 14 21841 env19574 = env19575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env19574 == env19575) = true)

theorem identity19575 : scanCanonicalize (H12AffineFastState.compose env19575 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19575 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env19576 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,21620,8282,5220,31756,1025,21621,4161,21509,17,21543,8192,64,23668,13389,17444,31757,9225,21589,36,29821,16385,8745]

theorem envBound19576 : H12AffineFastState.Bounded env19576 := by
  intro p hp
  have h : env19576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19575_19576 : H12AffineEnvironment.transform 7 37 env19575 = env19576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19575 == env19576) = true)

theorem identity19576 : scanCanonicalize (H12AffineFastState.compose env19576 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound19576 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env19577 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5237,1,8282,5220,10361,1025,0,4161,112,17,82,8192,64,2049,13389,4177,10360,9225,32,36,8200,5236,8745]

theorem envBound19577 : H12AffineFastState.Bounded env19577 := by
  intro p hp
  have h : env19577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19576_19577 : H12AffineEnvironment.transform 13 5237 env19576 = env19577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env19576 == env19577) = true)

theorem identity19577 : scanCanonicalize (H12AffineFastState.compose env19577 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound19577 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19578 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5237,1,35,5220,2048,1025,0,4161,112,17,82,121,64,2049,5172,4177,2049,1136,32,36,113,5236,592]

theorem envBound19578 : H12AffineFastState.Bounded env19578 := by
  intro p hp
  have h : env19578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19577_19578 : H12AffineEnvironment.transform 12 121 env19577 = env19578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env19577 == env19578) = true)

def env19579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101328,2114883,8193,64,97547,115015,17665,2363457,119042,329731,257,2199862,2191386,63068]

theorem envBound19579 : H12AffineFastState.Bounded env19579 := by
  intro p hp
  have h : env19579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19555_19579 : H12AffineEnvironment.transform 6 9 env19555 = env19579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19555 == env19579) = true)

def env19580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,16,21763,8193,64,97547,115015,17665,262145,119042,329731,257,98678,90202,63068]

theorem envBound19580 : H12AffineFastState.Bounded env19580 := by
  intro p hp
  have h : env19580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19579_19580 : H12AffineEnvironment.transform 20 4160 env19579 = env19580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19579 == env19580) = true)

theorem identity19580 : scanCanonicalize (H12AffineFastState.compose env19580 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19580 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1025,29788,4160,272392,16,21763,8193,64,97547,79130,17665,262145,75103,329731,257,95531,90202,513]

theorem envBound19581 : H12AffineFastState.Bounded env19581 := by
  intro p hp
  have h : env19581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19580_19581 : H12AffineEnvironment.transform 14 29789 env19580 = env19581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19580 == env19581) = true)

theorem identity19581 : scanCanonicalize (H12AffineFastState.compose env19581 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound19581 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21591,13388,262144,1025,29788,4160,272392,16,21763,8193,64,10588,24909,17665,262145,28936,285780,257,8572,13325,513]

theorem envBound19582 : H12AffineFastState.Bounded env19582 := by
  intro p hp
  have h : env19582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19581_19582 : H12AffineEnvironment.transform 15 21591 env19581 = env19582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env19581 == env19582) = true)

theorem identity19582 : scanCanonicalize (H12AffineFastState.compose env19582 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19582 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21591,5392,262144,1025,21760,4160,264532,16,21763,349,64,2048,16401,17665,262145,20564,285780,257,32,5457,513]

theorem envBound19583 : H12AffineFastState.Bounded env19583 := by
  intro p hp
  have h : env19583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19582_19583 : H12AffineEnvironment.transform 12 348 env19582 = env19583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19582 == env19583) = true)

theorem identity19583 : scanCanonicalize (H12AffineFastState.compose env19583 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound19583 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21591,5392,2420,1025,21760,4160,32,16,21763,349,64,2048,16401,17665,2421,20564,21792,257,32,5457,513]

theorem envBound19584 : H12AffineFastState.Bounded env19584 := by
  intro p hp
  have h : env19584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19583_19584 : H12AffineEnvironment.transform 17 2420 env19583 = env19584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env19583 == env19584) = true)

theorem identity19584 : scanCanonicalize (H12AffineFastState.compose env19584 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound19584 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,1296,1094,5392,2420,1025,1297,4160,32,16,1298,349,64,2048,4096,5392,2421,69,1329,257,32,5457,513]

theorem envBound19585 : H12AffineFastState.Bounded env19585 := by
  intro p hp
  have h : env19585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19584_19585 : H12AffineEnvironment.transform 13 4113 env19584 = env19585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env19584 == env19585) = true)

theorem identity19585 : scanCanonicalize (H12AffineFastState.compose env19585 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19585 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env19586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,348,4113,1296,1094,5392,1076,1025,1297,4160,32,16,1298,349,64,1344,4096,5392,1077,69,1329,257,32,5457,513]

theorem envBound19586 : H12AffineFastState.Bounded env19586 := by
  intro p hp
  have h : env19586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19585_19586 : H12AffineEnvironment.transform 10 1344 env19585 = env19586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env19585 == env19586) = true)

theorem identity19586 : scanCanonicalize (H12AffineFastState.compose env19586 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19586 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env19587 : List Nat := [2,4,8,16,32,64,9,256,512,100,292,4096,348,4113,372,34,4468,80,101,373,4160,32,16,374,349,64,292,4096,4468,81,69,341,257,32,4405,513]

theorem envBound19587 : H12AffineFastState.Bounded env19587 := by
  intro p hp
  have h : env19587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19586_19587 : H12AffineEnvironment.transform 9 100 env19586 = env19587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19586 == env19587) = true)

theorem identity19587 : scanCanonicalize (H12AffineFastState.compose env19587 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound19587 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19588 : List Nat := [2,4,8,16,32,64,9,256,512,100,292,65,348,80,372,34,309,80,101,373,1,32,16,374,349,64,292,65,309,81,69,341,257,32,372,513]

theorem envBound19588 : H12AffineFastState.Bounded env19588 := by
  intro p hp
  have h : env19588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19587_19588 : H12AffineEnvironment.transform 11 65 env19587 = env19588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env19587 == env19588) = true)

theorem identity19588 : scanCanonicalize (H12AffineFastState.compose env19588 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19588 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env19589 : List Nat := [2,4,8,16,32,64,9,116,512,100,80,65,40,80,0,34,65,80,101,1,1,32,16,2,41,64,80,65,65,81,69,33,117,32,0,513]

theorem envBound19589 : H12AffineFastState.Bounded env19589 := by
  intro p hp
  have h : env19589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19588_19589 : H12AffineEnvironment.transform 7 116 env19588 = env19589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19588 == env19589) = true)

theorem identity19589 : scanCanonicalize (H12AffineFastState.compose env19589 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound19589 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19590 : List Nat := [2,4,8,16,32,64,9,116,65,100,80,65,40,80,0,34,65,80,101,1,1,32,16,2,41,64,80,65,65,81,69,33,117,32,0,64]

theorem envBound19590 : H12AffineFastState.Bounded env19590 := by
  intro p hp
  have h : env19590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19589_19590 : H12AffineEnvironment.transform 8 65 env19589 = env19590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env19589 == env19590) = true)

theorem identity19590 : scanCanonicalize (H12AffineFastState.compose env19590 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound19590 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19591 : List Nat := [2,4,8,16,32,59,9,15,58,31,43,58,40,43,0,34,58,43,30,1,1,32,16,2,41,59,43,58,58,42,62,33,14,32,0,59]

theorem envBound19591 : H12AffineFastState.Bounded env19591 := by
  intro p hp
  have h : env19591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19590_19591 : H12AffineEnvironment.transform 5 59 env19590 = env19591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env19590 == env19591) = true)

theorem identity19591 : scanCanonicalize (H12AffineFastState.compose env19591 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19591 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19592 : List Nat := [2,4,8,16,11,16,9,15,17,31,0,17,3,0,0,9,17,0,30,1,1,11,16,2,2,16,0,17,17,1,21,10,14,11,0,16]

theorem envBound19592 : H12AffineFastState.Bounded env19592 := by
  intro p hp
  have h : env19592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19591_19592 : H12AffineEnvironment.transform 4 11 env19591 = env19592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19591 == env19592) = true)

def env19593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21762,8193,64,97547,115015,17665,262144,119042,329731,257,98679,90203,63068]

theorem envBound19593 : H12AffineFastState.Bounded env19593 := by
  intro p hp
  have h : env19593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19579_19593 : H12AffineEnvironment.transform 20 4161 env19579 = env19593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19579 == env19593) = true)

theorem identity19593 : scanCanonicalize (H12AffineFastState.compose env19593 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound19593 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56436,1025,32769,4161,62588,17,21762,8193,64,97547,115015,17665,56436,119042,119927,257,98679,90203,63068]

theorem envBound19594 : H12AffineFastState.Bounded env19594 := by
  intro p hp
  have h : env19594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19593_19594 : H12AffineEnvironment.transform 17 56436 env19593 = env19594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env19593 == env19594) = true)

theorem identity19594 : scanCanonicalize (H12AffineFastState.compose env19594 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19594 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,49169,56436,1025,32769,4161,62588,17,21762,8193,64,64604,16400,17665,56436,20565,21792,257,32,57612,63068]

theorem envBound19595 : H12AffineFastState.Bounded env19595 := by
  intro p hp
  have h : env19595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19594_19595 : H12AffineEnvironment.transform 15 33111 env19594 = env19595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19594 == env19595) = true)

theorem identity19595 : scanCanonicalize (H12AffineFastState.compose env19595 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound19595 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,30042,13340,10361,1025,29708,4161,113,17,21762,8193,64,2129,16400,17665,10361,20565,21792,257,32,5377,593]

theorem envBound19596 : H12AffineFastState.Bounded env19596 := by
  intro p hp
  have h : env19596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19595_19596 : H12AffineEnvironment.transform 14 29709 env19595 = env19596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env19595 == env19596) = true)

theorem identity19596 : scanCanonicalize (H12AffineFastState.compose env19596 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19596 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env19597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8202,13340,10361,1025,8540,4161,113,17,82,8193,64,2129,5440,4177,10361,1285,112,257,32,5377,593]

theorem envBound19597 : H12AffineFastState.Bounded env19597 := by
  intro p hp
  have h : env19597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19596_19597 : H12AffineEnvironment.transform 13 5456 env19596 = env19597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19596 == env19597) = true)

theorem identity19597 : scanCanonicalize (H12AffineFastState.compose env19597 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19597 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19598 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5157,8232,8202,13340,10361,1025,8233,4161,113,17,82,8193,64,2129,5173,4177,10361,1136,112,116,32,5236,593]

theorem envBound19598 : H12AffineFastState.Bounded env19598 := by
  intro p hp
  have h : env19598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19597_19598 : H12AffineEnvironment.transform 7 117 env19597 = env19598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19597 == env19598) = true)

theorem identity19598 : scanCanonicalize (H12AffineFastState.compose env19598 (packedSelected [0,3,5,6,7,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound19598 : packedSelected [0,3,5,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env19599 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,7180,5157,7204,7174,2064,5237,1025,7205,4161,113,17,82,7181,64,2129,5173,4177,5237,1136,112,116,32,5236,593]

theorem envBound19599 : H12AffineFastState.Bounded env19599 := by
  intro p hp
  have h : env19599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19598_19599 : H12AffineEnvironment.transform 12 7180 env19598 = env19599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env19598 == env19599) = true)

def env19600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543883,115150,17664,2363593,119043,4268162,257,2199998,2191387,63188]

theorem envBound19600 : H12AffineFastState.Bounded env19600 := by
  intro p hp
  have h : env19600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19535_19600 : H12AffineEnvironment.transform 22 2101329 env19535 = env19600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env19535 == env19600) = true)

def env19601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97547,115150,17664,2363593,119043,329730,257,2199998,2191387,63188]

theorem envBound19601 : H12AffineFastState.Bounded env19601 := by
  intro p hp
  have h : env19601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19600_19601 : H12AffineEnvironment.transform 21 272512 env19600 = env19601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19600 == env19601) = true)

theorem identity19601 : scanCanonicalize (H12AffineFastState.compose env19601 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound19601 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58517,272512,62660,41430,8328,64,97547,115150,17664,324700,119043,329730,257,95531,103566,63188]

theorem envBound19602 : H12AffineFastState.Bounded env19602 := by
  intro p hp
  have h : env19602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19601_19602 : H12AffineEnvironment.transform 20 58517 env19601 = env19602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env19601 == env19602) = true)

def env19603 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58517,272512,62612,41350,8328,16,97547,115102,17664,324620,119043,329730,257,95531,103566,63108]

theorem envBound19603 : H12AffineFastState.Bounded env19603 := by
  intro p hp
  have h : env19603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19602_19603 : H12AffineEnvironment.transform 5 16 env19602 = env19603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19602 == env19603) = true)

theorem identity19603 : scanCanonicalize (H12AffineFastState.compose env19603 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound19603 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env19604 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62850,49304,262144,1025,32769,58517,272512,62612,41350,8328,16,34953,13340,17664,324620,9345,327040,257,32937,24844,63108]

theorem envBound19604 : H12AffineFastState.Bounded env19604 := by
  intro p hp
  have h : env19604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19603_19604 : H12AffineEnvironment.transform 15 62850 env19603 = env19604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env19603 == env19604) = true)

theorem identity19604 : scanCanonicalize (H12AffineFastState.compose env19604 (packedSelected [0,1,3,9,16,17,20,22,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound19604 : packedSelected [0,1,3,9,16,17,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env19605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,21646,24980,262144,1025,8461,17817,272512,21912,138,8328,16,10629,13340,17664,283904,9345,285836,257,8613,24844,22408]

theorem envBound19605 : H12AffineFastState.Bounded env19605 := by
  intro p hp
  have h : env19605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19604_19605 : H12AffineEnvironment.transform 14 8460 env19604 = env19605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env19604 == env19605) = true)

def env19606 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58517,272512,62613,41351,8328,17,97547,115103,17664,324621,119043,329730,257,95531,103566,63109]

theorem envBound19606 : H12AffineFastState.Bounded env19606 := by
  intro p hp
  have h : env19606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19602_19606 : H12AffineEnvironment.transform 5 17 env19602 = env19606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19602 == env19606) = true)

theorem identity19606 : scanCanonicalize (H12AffineFastState.compose env19606 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound19606 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env19607 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40971,49304,262144,1025,32769,58517,272512,62613,41351,8328,17,56576,24980,17664,324621,28936,305161,257,54560,13445,63109]

theorem envBound19607 : H12AffineFastState.Bounded env19607 := by
  intro p hp
  have h : env19607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19606_19607 : H12AffineEnvironment.transform 15 40971 env19606 = env19607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env19606 == env19607) = true)

theorem identity19607 : scanCanonicalize (H12AffineFastState.compose env19607 (packedSelected [1,5,8,10,18,23,24,31] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound19607 : packedSelected [1,5,8,10,18,23,24,31] rootPS < 2^1333 := by decide +kernel

def env19608 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40971,49304,56356,1025,32769,58517,62628,62613,41351,8328,17,56576,24980,17664,10281,28936,29741,257,54560,13445,63109]

theorem envBound19608 : H12AffineFastState.Bounded env19608 := by
  intro p hp
  have h : env19608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19607_19608 : H12AffineEnvironment.transform 17 56356 env19607 = env19608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env19607 == env19608) = true)

theorem identity19608 : scanCanonicalize (H12AffineFastState.compose env19608 (packedSelected [0,1,2,3,5,6,7,8,9,12,16,17,18,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19608 : packedSelected [0,1,2,3,5,6,7,8,9,12,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env19609 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,56356,1025,32769,58397,62508,62493,41231,8192,17,56576,24860,17664,10281,28936,29741,257,54560,13325,62989]

theorem envBound19609 : H12AffineFastState.Bounded env19609 := by
  intro p hp
  have h : env19609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19608_19609 : H12AffineEnvironment.transform 6 8 env19608 = env19609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19608 == env19609) = true)

theorem identity19609 : scanCanonicalize (H12AffineFastState.compose env19609 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound19609 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19610 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21540,29743,5172,2048,1025,21541,12345,8200,8249,29995,8192,17,2340,24860,17664,10281,28936,29741,257,260,13325,8745]

theorem envBound19610 : H12AffineFastState.Bounded env19610 := by
  intro p hp
  have h : env19610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19609_19610 : H12AffineEnvironment.transform 14 21540 env19609 = env19610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env19609 == env19610) = true)

theorem identity19610 : scanCanonicalize (H12AffineFastState.compose env19610 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19610 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19611 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21540,21795,5172,2048,1025,21541,4405,260,309,21543,268,17,2340,16400,17664,2341,20484,21793,257,260,5377,805]

theorem envBound19611 : H12AffineFastState.Bounded env19611 := by
  intro p hp
  have h : env19611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19610_19611 : H12AffineEnvironment.transform 12 268 env19610 = env19611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19610 == env19611) = true)

theorem identity19611 : scanCanonicalize (H12AffineFastState.compose env19611 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19611 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19612 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,292,35,5172,2048,1025,293,4405,260,309,295,268,17,2340,5392,4096,2341,1284,33,257,260,5377,805]

theorem envBound19612 : H12AffineFastState.Bounded env19612 := by
  intro p hp
  have h : env19612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19611_19612 : H12AffineEnvironment.transform 13 5376 env19611 = env19612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19611 == env19612) = true)

theorem identity19612 : scanCanonicalize (H12AffineFastState.compose env19612 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound19612 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env19613 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,268,5376,292,35,5172,1076,1025,293,4405,260,309,295,268,17,1296,5392,4096,1297,1284,33,257,260,5377,805]

theorem envBound19613 : H12AffineFastState.Bounded env19613 := by
  intro p hp
  have h : env19613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19612_19613 : H12AffineEnvironment.transform 10 1076 env19612 = env19613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env19612 == env19613) = true)

theorem identity19613 : scanCanonicalize (H12AffineFastState.compose env19613 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound19613 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19614 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,1280,268,0,292,35,308,1076,1025,293,1077,260,309,295,268,17,1296,16,1280,1297,1284,33,257,260,1,805]

theorem envBound19614 : H12AffineFastState.Bounded env19614 := by
  intro p hp
  have h : env19614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19613_19614 : H12AffineEnvironment.transform 11 1280 env19613 = env19614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env19613 == env19614) = true)

theorem identity19614 : scanCanonicalize (H12AffineFastState.compose env19614 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19614 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env19615 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,1061,41,0,1,35,17,1076,1025,0,1077,33,16,2,41,17,1077,16,1061,1076,1057,33,36,33,1,512]

theorem envBound19615 : H12AffineFastState.Bounded env19615 := by
  intro p hp
  have h : env19615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19614_19615 : H12AffineEnvironment.transform 7 37 env19614 = env19615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19614 == env19615) = true)

theorem identity19615 : scanCanonicalize (H12AffineFastState.compose env19615 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19616 : List Nat := [2,4,8,1,32,0,8,37,512,1024,1061,1061,41,0,1,35,0,1061,1025,0,1060,33,1,2,41,0,1060,1,1061,1061,1057,33,36,33,1,512]

theorem envBound19616 : H12AffineFastState.Bounded env19616 := by
  intro p hp
  have h : env19616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19615_19616 : H12AffineEnvironment.transform 3 1 env19615 = env19616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19615 == env19616) = true)

theorem identity19616 : scanCanonicalize (H12AffineFastState.compose env19616 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound19616 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19617 : List Nat := [2,4,8,1,32,0,8,37,512,15,42,42,41,0,1,35,0,42,14,0,43,33,1,2,41,0,43,1,42,42,46,33,36,33,1,512]

theorem envBound19617 : H12AffineFastState.Bounded env19617 := by
  intro p hp
  have h : env19617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19616_19617 : H12AffineEnvironment.transform 9 15 env19616 = env19617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env19616 == env19617) = true)

theorem identity19617 : scanCanonicalize (H12AffineFastState.compose env19617 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound19617 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19618 : List Nat := [2,4,8,1,32,0,8,37,43,15,42,42,41,0,1,35,0,42,14,0,43,33,1,2,41,0,43,1,42,42,46,33,36,33,1,43]

theorem envBound19618 : H12AffineFastState.Bounded env19618 := by
  intro p hp
  have h : env19618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19617_19618 : H12AffineEnvironment.transform 8 43 env19617 = env19618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env19617 == env19618) = true)

theorem identity19618 : scanCanonicalize (H12AffineFastState.compose env19618 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound19618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19619 : List Nat := [2,3,8,1,32,0,8,34,43,8,42,42,41,0,1,35,0,42,9,0,43,33,1,2,41,0,43,1,42,42,41,33,35,33,1,43]

theorem envBound19619 : H12AffineFastState.Bounded env19619 := by
  intro p hp
  have h : env19619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19618_19619 : H12AffineEnvironment.transform 1 3 env19618 = env19619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env19618 == env19619) = true)

theorem identity19619 : scanCanonicalize (H12AffineFastState.compose env19619 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19619 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19620 : List Nat := [2,3,8,1,0,0,8,2,11,8,10,10,9,0,1,3,0,10,9,0,11,1,1,2,9,0,11,1,10,10,9,1,3,1,1,11]

theorem envBound19620 : H12AffineFastState.Bounded env19620 := by
  intro p hp
  have h : env19620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19619_19620 : H12AffineEnvironment.transform 4 0 env19619 = env19620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19619 == env19620) = true)

theorem identity19620 : scanCanonicalize (H12AffineFastState.compose env19620 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound19620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19621 : List Nat := [2,3,0,1,0,0,0,2,3,0,2,2,1,0,1,3,0,2,1,0,3,1,1,2,1,0,3,1,2,2,1,1,3,1,1,3]

theorem envBound19621 : H12AffineFastState.Bounded env19621 := by
  intro p hp
  have h : env19621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19620_19621 : H12AffineEnvironment.transform 2 0 env19620 = env19621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env19620 == env19621) = true)

def env19622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97546,115150,17664,2363593,119043,329731,257,2199998,2191387,63188]

theorem envBound19622 : H12AffineFastState.Bounded env19622 := by
  intro p hp
  have h : env19622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19600_19622 : H12AffineEnvironment.transform 21 272513 env19600 = env19622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19600 == env19622) = true)

theorem identity19622 : scanCanonicalize (H12AffineFastState.compose env19622 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19622 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,262144,1025,29908,2097152,272513,2101329,2114883,8328,64,97546,79131,17664,2363593,75222,329731,257,2188651,2191387,513]

theorem envBound19623 : H12AffineFastState.Bounded env19623 := by
  intro p hp
  have h : env19623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19622_19623 : H12AffineEnvironment.transform 14 29909 env19622 = env19623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19622 == env19623) = true)

def env19624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,32240,1025,29908,2097152,21873,2101329,2114883,8328,64,97546,79131,17664,2125113,75222,95731,257,2188651,2191387,513]

theorem envBound19624 : H12AffineFastState.Bounded env19624 := by
  intro p hp
  have h : env19624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19623_19624 : H12AffineEnvironment.transform 17 32240 env19623 = env19624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env19623 == env19624) = true)

def env19625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32120,1025,29788,2097152,21873,2101329,2114883,8192,64,97546,79131,17664,2125113,75102,95611,257,2188651,2191387,513]

theorem envBound19625 : H12AffineFastState.Bounded env19625 := by
  intro p hp
  have h : env19625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19624_19625 : H12AffineEnvironment.transform 6 8 env19624 = env19625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19624 == env19625) = true)

theorem identity19625 : scanCanonicalize (H12AffineFastState.compose env19625 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 69731) := by decide +kernel

theorem selectedBound19625 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env19626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32120,1025,29788,69731,21873,65586,87328,8192,64,97546,79131,17664,97626,75102,95611,257,29960,24696,513]

theorem envBound19626 : H12AffineFastState.Bounded env19626 := by
  intro p hp
  have h : env19626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19625_19626 : H12AffineEnvironment.transform 20 69731 env19625 = env19626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69731 env19625 == env19626) = true)

theorem identity19626 : scanCanonicalize (H12AffineFastState.compose env19626 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound19626 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env19627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,1378,13389,32120,1025,29788,5377,21873,1360,20546,8192,64,30824,12409,17664,30776,8252,28697,257,29960,24696,513]

theorem envBound19627 : H12AffineFastState.Bounded env19627 := by
  intro p hp
  have h : env19627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19626_19627 : H12AffineEnvironment.transform 15 1378 env19626 = env19627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env19626 == env19627) = true)

theorem identity19627 : scanCanonicalize (H12AffineFastState.compose env19627 (packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound19627 : packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS < 2^1333 := by decide +kernel

def env19628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,9577,1378,13389,11340,1025,9576,5377,1093,1360,374,8192,64,10588,12409,5172,10508,8252,8493,257,9276,12620,513]

theorem envBound19628 : H12AffineFastState.Bounded env19628 := by
  intro p hp
  have h : env19628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19627_19628 : H12AffineEnvironment.transform 13 4404 env19627 = env19628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env19627 == env19628) = true)

theorem identity19628 : scanCanonicalize (H12AffineFastState.compose env19628 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19628 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,4404,1345,1378,5221,3172,1025,1344,5377,1093,1360,374,40,64,2420,4177,5172,2340,20,261,257,1044,4452,513]

theorem envBound19629 : H12AffineFastState.Bounded env19629 := by
  intro p hp
  have h : env19629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19628_19629 : H12AffineEnvironment.transform 12 40 env19628 = env19629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19628 == env19629) = true)

theorem identity19629 : scanCanonicalize (H12AffineFastState.compose env19629 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19629 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env19630 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,4112,1125,1094,5221,3172,1025,1124,5157,1093,1140,82,40,64,2128,4177,5172,2048,20,33,37,1044,4160,513]

theorem envBound19630 : H12AffineFastState.Bounded env19630 := by
  intro p hp
  have h : env19630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19629_19630 : H12AffineEnvironment.transform 7 36 env19629 = env19630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19629 == env19630) = true)

theorem identity19630 : scanCanonicalize (H12AffineFastState.compose env19630 (packedSelected [2,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound19630 : packedSelected [2,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env19631 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2113,40,2129,1125,1094,3108,3172,1025,1124,3172,1093,1140,82,40,64,2128,2064,3189,2048,20,33,37,1044,2049,513]

theorem envBound19631 : H12AffineFastState.Bounded env19631 := by
  intro p hp
  have h : env19631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19630_19631 : H12AffineEnvironment.transform 11 2113 env19630 = env19631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env19630 == env19631) = true)

theorem identity19631 : scanCanonicalize (H12AffineFastState.compose env19631 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19631 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env19632 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,2113,40,2129,0,35,2113,2049,100,1,2049,32,17,82,40,64,2128,2064,2064,2048,20,33,37,113,2049,513]

theorem envBound19632 : H12AffineFastState.Bounded env19632 := by
  intro p hp
  have h : env19632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19631_19632 : H12AffineEnvironment.transform 9 101 env19631 = env19632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19631 == env19632) = true)

theorem identity19632 : scanCanonicalize (H12AffineFastState.compose env19632 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound19632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19633 : List Nat := [2,4,8,16,32,64,8,36,512,101,112,49,40,33,0,35,49,113,100,1,113,32,17,82,40,64,32,96,96,112,20,33,37,113,113,513]

theorem envBound19633 : H12AffineFastState.Bounded env19633 := by
  intro p hp
  have h : env19633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19632_19633 : H12AffineEnvironment.transform 10 112 env19632 = env19633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env19632 == env19633) = true)

theorem identity19633 : scanCanonicalize (H12AffineFastState.compose env19633 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19633 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env19634 : List Nat := [2,4,8,16,32,64,8,36,0,101,112,49,40,33,0,35,49,113,100,1,113,32,17,82,40,64,32,96,96,112,20,33,37,113,113,1]

theorem envBound19634 : H12AffineFastState.Bounded env19634 := by
  intro p hp
  have h : env19634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19633_19634 : H12AffineEnvironment.transform 8 0 env19633 = env19634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19633 == env19634) = true)

theorem identity19634 : scanCanonicalize (H12AffineFastState.compose env19634 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19634 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env19635 : List Nat := [2,4,8,1,32,64,8,36,0,101,97,32,40,33,0,35,32,96,100,1,96,32,0,67,40,64,32,96,96,97,5,33,37,96,96,1]

theorem envBound19635 : H12AffineFastState.Bounded env19635 := by
  intro p hp
  have h : env19635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19634_19635 : H12AffineEnvironment.transform 3 1 env19634 = env19635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19634 == env19635) = true)

theorem identity19635 : scanCanonicalize (H12AffineFastState.compose env19635 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19636 : List Nat := [2,4,8,1,0,64,8,4,0,69,65,0,8,1,0,3,0,64,68,1,64,0,0,67,8,64,0,64,64,65,5,1,5,64,64,1]

theorem envBound19636 : H12AffineFastState.Bounded env19636 := by
  intro p hp
  have h : env19636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19635_19636 : H12AffineEnvironment.transform 4 0 env19635 = env19636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19635 == env19636) = true)

theorem identity19636 : scanCanonicalize (H12AffineFastState.compose env19636 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound19636 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19637 : List Nat := [2,4,8,1,0,0,8,4,0,5,1,0,8,1,0,3,0,0,4,1,0,0,0,3,8,0,0,0,0,1,5,1,5,0,0,1]

theorem envBound19637 : H12AffineFastState.Bounded env19637 := by
  intro p hp
  have h : env19637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19636_19637 : H12AffineEnvironment.transform 5 0 env19636 = env19637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env19636 == env19637) = true)

def env19638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32121,1025,29789,2097152,21873,2101329,2114883,8193,64,97546,79131,17664,2125113,75103,95610,257,2188651,2191387,513]

theorem envBound19638 : H12AffineFastState.Bounded env19638 := by
  intro p hp
  have h : env19638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19624_19638 : H12AffineEnvironment.transform 6 9 env19624 = env19638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19624 == env19638) = true)

theorem identity19638 : scanCanonicalize (H12AffineFastState.compose env19638 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 4112) := by decide +kernel

theorem selectedBound19638 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env19639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32121,1025,29789,4112,21873,65,21843,8193,64,97546,79131,17664,32041,75103,95610,257,95611,90123,513]

theorem envBound19639 : H12AffineFastState.Bounded env19639 := by
  intro p hp
  have h : env19639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19638_19639 : H12AffineEnvironment.transform 20 4112 env19638 = env19639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4112 env19638 == env19639) = true)

theorem identity19639 : scanCanonicalize (H12AffineFastState.compose env19639 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19639 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env19640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,65536,13389,10281,1025,8461,4112,33,65,3,8193,64,75866,79131,4176,10361,75103,73770,257,73771,79195,513]

theorem envBound19640 : H12AffineFastState.Bounded env19640 := by
  intro p hp
  have h : env19640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19639_19640 : H12AffineEnvironment.transform 13 5456 env19639 = env19640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19639 == env19640) = true)

theorem identity19640 : scanCanonicalize (H12AffineFastState.compose env19640 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19640 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env19641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,8202,13389,10281,1025,8461,4112,33,65,3,8193,64,2128,5393,4176,10361,1365,32,257,33,5457,513]

theorem envBound19641 : H12AffineFastState.Bounded env19641 := by
  intro p hp
  have h : env19641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19640_19641 : H12AffineEnvironment.transform 15 8202 env19640 = env19641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19640 == env19641) = true)

def env19642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,32241,1025,29908,2097152,21872,2101329,2114883,8328,64,97546,79131,17664,2125112,75222,95730,257,2188651,2191387,513]

theorem envBound19642 : H12AffineFastState.Bounded env19642 := by
  intro p hp
  have h : env19642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19623_19642 : H12AffineEnvironment.transform 17 32241 env19623 = env19642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env19623 == env19642) = true)

theorem identity19642 : scanCanonicalize (H12AffineFastState.compose env19642 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19642 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env19643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32120,1025,29789,2097152,21872,2101329,2114883,8193,64,97546,79131,17664,2125112,75103,95611,257,2188651,2191387,513]

theorem envBound19643 : H12AffineFastState.Bounded env19643 := by
  intro p hp
  have h : env19643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19642_19643 : H12AffineEnvironment.transform 6 9 env19642 = env19643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19642 == env19643) = true)

theorem identity19643 : scanCanonicalize (H12AffineFastState.compose env19643 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19643 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env19644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13389,32120,1025,29789,2097152,21872,2101329,2114883,8193,64,23808,5393,17664,2125112,1365,21873,257,2114913,2117649,513]

theorem envBound19644 : H12AffineFastState.Bounded env19644 := by
  intro p hp
  have h : env19644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19643_19644 : H12AffineEnvironment.transform 15 8202 env19643 = env19644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19643 == env19644) = true)

theorem identity19644 : scanCanonicalize (H12AffineFastState.compose env19644 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19644 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env19645 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,13340,32041,1025,29708,2097152,21793,2101248,2114834,8193,17,23808,5393,17664,2125112,1284,21792,257,2114864,2117649,513]

theorem envBound19645 : H12AffineFastState.Bounded env19645 := by
  intro p hp
  have h : env19645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19644_19645 : H12AffineEnvironment.transform 5 17 env19644 = env19645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19644 == env19645) = true)

def env19646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025626,115151,10507601,8650905,10600787,4268163,257,8487406,8478795,10544772]

theorem envBound19646 : H12AffineFastState.Bounded env19646 := by
  intro p hp
  have h : env19646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19534_19646 : H12AffineEnvironment.transform 16 49305 env19534 = env19646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env19534 == env19646) = true)

def env19647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543882,115151,17665,2363593,119043,4268163,257,2199998,2191387,63188]

theorem envBound19647 : H12AffineFastState.Bounded env19647 := by
  intro p hp
  have h : env19647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19646_19647 : H12AffineEnvironment.transform 22 2101328 env19646 = env19647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env19646 == env19647) = true)

def env19648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97546,115151,17665,2363593,119043,329731,257,2199998,2191387,63188]

theorem envBound19648 : H12AffineFastState.Bounded env19648 := by
  intro p hp
  have h : env19648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19647_19648 : H12AffineEnvironment.transform 21 272512 env19647 = env19648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19647 == env19648) = true)

theorem identity19648 : scanCanonicalize (H12AffineFastState.compose env19648 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound19648 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49305,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,43476,5393,17665,2363593,1501,318685,257,2114912,2139333,63188]

theorem envBound19649 : H12AffineFastState.Bounded env19649 := by
  intro p hp
  have h : env19649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19648_19649 : H12AffineEnvironment.transform 15 54494 env19648 = env19649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env19648 == env19649) = true)

theorem identity19649 : scanCanonicalize (H12AffineFastState.compose env19649 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19649 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,13388,262144,1025,29908,2097152,272512,2101328,2114882,8328,64,23809,5393,17665,2363593,1501,272392,257,2114912,2117648,513]

theorem envBound19650 : H12AffineFastState.Bounded env19650 := by
  intro p hp
  have h : env19650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19649_19650 : H12AffineEnvironment.transform 14 29909 env19649 = env19650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19649 == env19650) = true)

theorem identity19650 : scanCanonicalize (H12AffineFastState.compose env19650 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound19650 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env19651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,13388,262144,1025,29908,25628,272512,29772,8542,8328,64,23809,5393,17665,292053,1501,272392,257,8572,13324,513]

theorem envBound19651 : H12AffineFastState.Bounded env19651 := by
  intro p hp
  have h : env19651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19650_19651 : H12AffineEnvironment.transform 20 25628 env19650 = env19651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env19650 == env19651) = true)

theorem identity19651 : scanCanonicalize (H12AffineFastState.compose env19651 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound19651 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,13388,10281,1025,29908,25628,169,29772,8542,8328,64,23809,5393,17665,23804,1501,33,257,8572,13324,513]

theorem envBound19652 : H12AffineFastState.Bounded env19652 := by
  intro p hp
  have h : env19652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19651_19652 : H12AffineEnvironment.transform 17 10281 env19651 = env19652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19651 == env19652) = true)

theorem identity19652 : scanCanonicalize (H12AffineFastState.compose env19652 (packedSelected [2,6,9,11,14,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19652 : packedSelected [2,6,9,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env19653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,13388,10281,1025,29789,25628,32,29772,8542,8193,64,23809,5393,17665,23669,1364,33,257,8572,13324,513]

theorem envBound19653 : H12AffineFastState.Bounded env19653 := by
  intro p hp
  have h : env19653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19652_19653 : H12AffineEnvironment.transform 6 9 env19652 = env19653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19652 == env19653) = true)

theorem identity19653 : scanCanonicalize (H12AffineFastState.compose env19653 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19653 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19654 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8203,13341,10281,1025,29708,25628,32,29725,8463,8193,17,23809,5393,17665,23588,1285,33,257,8493,13324,513]

theorem envBound19654 : H12AffineFastState.Bounded env19654 := by
  intro p hp
  have h : env19654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19653_19654 : H12AffineEnvironment.transform 5 17 env19653 = env19654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19653 == env19654) = true)

theorem identity19654 : scanCanonicalize (H12AffineFastState.compose env19654 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19654 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env19655 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,13341,10281,1025,8461,12573,32,8476,8463,8193,17,2048,5393,4096,2341,1285,33,257,8493,13324,513]

theorem envBound19655 : H12AffineFastState.Bounded env19655 := by
  intro p hp
  have h : env19655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19654_19655 : H12AffineEnvironment.transform 13 5377 env19654 = env19655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19654 == env19655) = true)

def env19656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97547,115151,17665,2363593,119043,329730,257,2199998,2191387,63188]

theorem envBound19656 : H12AffineFastState.Bounded env19656 := by
  intro p hp
  have h : env19656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19647_19656 : H12AffineEnvironment.transform 21 272513 env19647 = env19656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19647 == env19656) = true)

theorem identity19656 : scanCanonicalize (H12AffineFastState.compose env19656 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound19656 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,115871,272513,120015,98781,8328,64,97547,115151,17665,382038,119043,329730,257,21793,46212,63188]

theorem envBound19657 : H12AffineFastState.Bounded env19657 := by
  intro p hp
  have h : env19657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19656_19657 : H12AffineEnvironment.transform 20 115871 env19656 = env19657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env19656 == env19657) = true)

def env19658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10400,1025,32769,115871,33,120015,98781,8328,64,97547,115151,17665,130294,119043,73890,257,21793,46212,63188]

theorem envBound19658 : H12AffineFastState.Bounded env19658 := by
  intro p hp
  have h : env19658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19657_19658 : H12AffineEnvironment.transform 17 10400 env19657 = env19658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19657 == env19658) = true)

theorem identity19658 : scanCanonicalize (H12AffineFastState.compose env19658 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound19658 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33166,49305,10400,1025,32769,17681,33,21825,83,8328,64,64645,16449,17665,32120,20621,41260,257,21793,46212,63188]

theorem envBound19659 : H12AffineFastState.Bounded env19659 := by
  intro p hp
  have h : env19659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19658_19659 : H12AffineEnvironment.transform 15 33166 env19658 = env19659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env19658 == env19659) = true)

theorem identity19659 : scanCanonicalize (H12AffineFastState.compose env19659 (packedSelected [0,1,3,9,17,19,22,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound19659 : packedSelected [0,1,3,9,17,19,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env19660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29828,29962,13341,10400,1025,29829,17681,33,21825,83,8328,64,2049,16449,17665,32120,20621,21928,257,21793,16384,592]

theorem envBound19660 : H12AffineFastState.Bounded env19660 := by
  intro p hp
  have h : env19660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19659_19660 : H12AffineEnvironment.transform 14 29828 env19659 = env19660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env19659 == env19660) = true)

theorem identity19660 : scanCanonicalize (H12AffineFastState.compose env19660 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,20,22,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19660 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env19661 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29789,29962,13341,10361,1025,29788,17681,33,21825,83,8273,64,2049,16449,17665,32120,20564,21873,257,21793,16384,592]

theorem envBound19661 : H12AffineFastState.Bounded env19661 := by
  intro p hp
  have h : env19661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19660_19661 : H12AffineEnvironment.transform 6 89 env19660 = env19661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19660 == env19661) = true)

theorem identity19661 : scanCanonicalize (H12AffineFastState.compose env19661 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound19661 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env19662 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,12345,1124,1331,13341,10361,1025,1125,13608,33,9592,83,8273,64,2049,12408,13624,3393,8301,9544,257,9496,12345,592]

theorem envBound19662 : H12AffineFastState.Bounded env19662 := by
  intro p hp
  have h : env19662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19661_19662 : H12AffineEnvironment.transform 13 12345 env19661 = env19662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env19661 == env19662) = true)

theorem identity19662 : scanCanonicalize (H12AffineFastState.compose env19662 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound19662 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env19663 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,1385,5456,1124,1331,4468,3344,1025,1125,4161,33,17,83,1336,64,2049,5393,4177,3393,1284,33,257,113,5456,592]

theorem envBound19663 : H12AffineFastState.Bounded env19663 := by
  intro p hp
  have h : env19663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19662_19663 : H12AffineEnvironment.transform 12 1385 env19662 = env19663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env19662 == env19663) = true)

theorem identity19663 : scanCanonicalize (H12AffineFastState.compose env19663 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound19663 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19664 : List Nat := [2,4,8,16,32,64,89,256,512,68,2048,4096,301,4372,32,375,4468,2388,69,33,4161,33,17,83,380,64,2049,4437,4177,2309,320,33,257,113,4372,592]

theorem envBound19664 : H12AffineFastState.Bounded env19664 := by
  intro p hp
  have h : env19664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19663_19664 : H12AffineEnvironment.transform 9 68 env19663 = env19664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env19663 == env19664) = true)

theorem identity19664 : scanCanonicalize (H12AffineFastState.compose env19664 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound19664 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env19665 : List Nat := [2,4,8,16,32,64,89,256,512,68,2048,2097,301,2341,32,375,2373,2388,69,33,2160,33,17,83,380,64,2049,2404,2144,2309,320,33,257,113,2341,592]

theorem envBound19665 : H12AffineFastState.Bounded env19665 := by
  intro p hp
  have h : env19665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19664_19665 : H12AffineEnvironment.transform 11 2097 env19664 = env19665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env19664 == env19665) = true)

theorem identity19665 : scanCanonicalize (H12AffineFastState.compose env19665 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound19665 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env19666 : List Nat := [2,4,8,16,32,49,40,256,512,53,2048,2097,301,2341,32,262,2356,2341,52,33,2049,33,17,34,269,49,2049,2325,2065,2309,305,33,257,0,2341,545]

theorem envBound19666 : H12AffineFastState.Bounded env19666 := by
  intro p hp
  have h : env19666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19665_19666 : H12AffineEnvironment.transform 5 49 env19665 = env19666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env19665 == env19666) = true)

theorem identity19666 : scanCanonicalize (H12AffineFastState.compose env19666 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound19666 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19667 : List Nat := [2,4,8,16,32,49,40,256,512,53,815,798,301,522,32,262,539,522,52,33,814,33,17,34,269,49,814,570,830,554,305,33,257,0,522,545]

theorem envBound19667 : H12AffineFastState.Bounded env19667 := by
  intro p hp
  have h : env19667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19666_19667 : H12AffineEnvironment.transform 10 815 env19666 = env19667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env19666 == env19667) = true)

theorem identity19667 : scanCanonicalize (H12AffineFastState.compose env19667 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19667 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19668 : List Nat := [2,4,8,16,32,49,40,5,512,53,554,539,40,522,32,3,539,522,52,33,555,33,17,34,8,49,555,570,571,554,52,33,4,0,522,545]

theorem envBound19668 : H12AffineFastState.Bounded env19668 := by
  intro p hp
  have h : env19668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19667_19668 : H12AffineEnvironment.transform 7 5 env19667 = env19668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19667 == env19668) = true)

theorem identity19668 : scanCanonicalize (H12AffineFastState.compose env19668 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound19668 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env19669 : List Nat := [2,4,8,16,32,49,40,5,36,53,14,63,40,46,32,3,63,46,52,33,15,33,17,34,8,49,15,30,31,14,52,33,4,0,46,5]

theorem envBound19669 : H12AffineFastState.Bounded env19669 := by
  intro p hp
  have h : env19669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19668_19669 : H12AffineEnvironment.transform 8 36 env19668 = env19669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env19668 == env19669) = true)

theorem identity19669 : scanCanonicalize (H12AffineFastState.compose env19669 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound19669 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env19670 : List Nat := [2,4,8,9,32,40,40,5,36,44,14,38,40,46,32,3,38,46,45,33,15,33,8,34,8,40,15,7,6,14,45,33,4,0,46,5]

theorem envBound19670 : H12AffineFastState.Bounded env19670 := by
  intro p hp
  have h : env19670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19669_19670 : H12AffineEnvironment.transform 3 9 env19669 = env19670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env19669 == env19670) = true)

theorem identity19670 : scanCanonicalize (H12AffineFastState.compose env19670 (packedSelected [0,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19670 : packedSelected [0,10] rootPS < 2^1333 := by decide +kernel

def env19671 : List Nat := [2,4,8,9,1,9,9,5,5,13,14,7,9,15,1,3,7,15,12,0,15,0,8,3,8,9,15,7,6,14,12,0,4,0,15,5]

theorem envBound19671 : H12AffineFastState.Bounded env19671 := by
  intro p hp
  have h : env19671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19670_19671 : H12AffineEnvironment.transform 4 1 env19670 = env19671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19670 == env19671) = true)

theorem identity19671 : scanCanonicalize (H12AffineFastState.compose env19671 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound19671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19672 : List Nat := [2,4,7,6,1,6,6,5,5,2,1,7,6,0,1,3,7,0,3,0,0,0,7,3,7,6,0,7,6,1,3,0,4,0,0,5]

theorem envBound19672 : H12AffineFastState.Bounded env19672 := by
  intro p hp
  have h : env19672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19671_19672 : H12AffineEnvironment.transform 2 7 env19671 = env19672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env19671 == env19672) = true)

def env19673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10401,1025,32769,115871,32,120015,98781,8328,64,97547,115151,17665,130295,119043,73891,257,21793,46212,63188]

theorem envBound19673 : H12AffineFastState.Bounded env19673 := by
  intro p hp
  have h : env19673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19657_19673 : H12AffineEnvironment.transform 17 10401 env19657 = env19673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19657 == env19673) = true)

theorem identity19673 : scanCanonicalize (H12AffineFastState.compose env19673 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62590) := by decide +kernel

theorem selectedBound19673 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env19674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62590,49305,10401,1025,32769,12513,32,8369,30115,8328,64,35189,13745,17665,2185,9597,54493,257,21793,46212,63188]

theorem envBound19674 : H12AffineFastState.Bounded env19674 := by
  intro p hp
  have h : env19674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19673_19674 : H12AffineEnvironment.transform 15 62590 env19673 = env19674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62590 env19673 == env19674) = true)

theorem identity19674 : scanCanonicalize (H12AffineFastState.compose env19674 (packedSelected [0,2,6,7,8,10,11,12,15,16,18,28] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound19674 : packedSelected [0,2,6,7,8,10,11,12,15,16,18,28] rootPS < 2^1333 := by decide +kernel

def env19675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,508,30082,16741,10401,1025,509,12513,32,8369,30115,8328,64,2185,13745,17665,2185,9597,21793,257,21793,13688,30504]

theorem envBound19675 : H12AffineFastState.Bounded env19675 := by
  intro p hp
  have h : env19675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19674_19675 : H12AffineEnvironment.transform 14 508 env19674 = env19675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env19674 == env19675) = true)

theorem identity19675 : scanCanonicalize (H12AffineFastState.compose env19675 (packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound19675 : packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,508,8694,5393,10401,1025,509,12513,32,8369,8663,8328,64,2185,13745,4469,2185,9597,341,257,341,13688,9052]

theorem envBound19676 : H12AffineFastState.Bounded env19676 := by
  intro p hp
  have h : env19676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19675_19676 : H12AffineEnvironment.transform 13 5236 env19675 = env19676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env19675 == env19676) = true)

theorem identity19676 : scanCanonicalize (H12AffineFastState.compose env19676 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound19676 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env19677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5236,508,35,5393,2420,1025,509,4404,32,356,2,349,64,2185,5220,4469,2185,1192,341,257,341,5293,649]

theorem envBound19677 : H12AffineFastState.Bounded env19677 := by
  intro p hp
  have h : env19677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19676_19677 : H12AffineEnvironment.transform 12 469 env19676 = env19677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env19676 == env19677) = true)

theorem identity19677 : scanCanonicalize (H12AffineFastState.compose env19677 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19677 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env19678 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5236,293,35,5393,2420,1025,292,4404,32,356,2,349,64,2128,5220,4469,2128,1137,341,257,341,5236,592]

theorem envBound19678 : H12AffineFastState.Bounded env19678 := by
  intro p hp
  have h : env19678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19677_19678 : H12AffineEnvironment.transform 6 89 env19677 = env19678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19677 == env19678) = true)

theorem identity19678 : scanCanonicalize (H12AffineFastState.compose env19678 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound19678 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19679 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,268,4404,293,35,4177,2420,321,292,4404,32,356,2,349,64,2128,4388,4469,2128,305,341,257,341,4404,592]

end H12CloudChart0