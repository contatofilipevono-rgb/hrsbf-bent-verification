import H12CloudChart0Data049

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity12523 : scanCanonicalize (H12AffineFastState.compose env12523 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12523 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12524 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,58396,32,16,41231,8193,16,10509,57628,45324,43048,1284,33,256,41261,16385,513]

theorem envBound12524 : H12AffineFastState.Bounded env12524 := by
  intro p hp
  have h : env12524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12523_12524 : H12AffineEnvironment.transform 5 16 env12523 = env12524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12523 == env12524) = true)

theorem identity12524 : scanCanonicalize (H12AffineFastState.compose env12524 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound12524 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env12525 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13576,32768,8202,13592,10280,1024,32769,37140,32,16,41231,8193,16,10509,37908,45324,43048,1284,33,256,41261,13577,513]

theorem envBound12525 : H12AffineFastState.Bounded env12525 := by
  intro p hp
  have h : env12525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12524_12525 : H12AffineEnvironment.transform 13 13576 env12524 = env12525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env12524 == env12525) = true)

theorem identity12525 : scanCanonicalize (H12AffineFastState.compose env12525 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12525 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12526 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13576,0,8202,13592,10280,1024,1,4372,32,16,8463,8193,16,10509,5140,12556,10280,1284,33,256,8493,13577,513]

theorem envBound12526 : H12AffineFastState.Bounded env12526 := by
  intro p hp
  have h : env12526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12525_12526 : H12AffineEnvironment.transform 14 0 env12525 = env12526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12525 == env12526) = true)

theorem identity12526 : scanCanonicalize (H12AffineFastState.compose env12526 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12526 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12527 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5124,0,262,5140,2340,1024,1,4372,32,16,3,269,16,2049,5140,4096,2340,1284,33,256,33,5125,513]

theorem envBound12527 : H12AffineFastState.Bounded env12527 := by
  intro p hp
  have h : env12527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12526_12527 : H12AffineEnvironment.transform 12 268 env12526 = env12527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12526 == env12527) = true)

theorem identity12527 : scanCanonicalize (H12AffineFastState.compose env12527 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12528 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,4096,268,5124,0,262,5140,2308,1024,1,4372,0,16,3,269,16,2049,5140,4096,2308,1284,1,256,1,5125,513]

theorem envBound12528 : H12AffineFastState.Bounded env12528 := by
  intro p hp
  have h : env12528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12527_12528 : H12AffineEnvironment.transform 4 0 env12527 = env12528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12527 == env12528) = true)

theorem identity12528 : scanCanonicalize (H12AffineFastState.compose env12528 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12528 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12529 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,16,268,1044,0,262,1028,2308,1024,1,260,0,16,3,269,16,2049,1028,16,2308,1284,1,256,1,1045,513]

theorem envBound12529 : H12AffineFastState.Bounded env12529 := by
  intro p hp
  have h : env12529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12528_12529 : H12AffineEnvironment.transform 11 16 env12528 = env12529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12528 == env12529) = true)

theorem identity12529 : scanCanonicalize (H12AffineFastState.compose env12529 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound12529 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12530 : List Nat := [2,4,8,16,0,16,9,256,260,1024,2048,16,268,1044,0,262,1028,2308,1024,1,260,0,16,3,269,16,2049,1028,16,2308,1284,1,256,1,1045,261]

theorem envBound12530 : H12AffineFastState.Bounded env12530 := by
  intro p hp
  have h : env12530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12529_12530 : H12AffineEnvironment.transform 8 260 env12529 = env12530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env12529 == env12530) = true)

theorem identity12530 : scanCanonicalize (H12AffineFastState.compose env12530 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound12530 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12531 : List Nat := [2,4,8,16,0,16,9,256,260,1024,276,16,268,1044,0,262,1028,16,1024,1,260,0,16,3,269,16,277,1028,16,16,1284,1,256,1,1045,261]

theorem envBound12531 : H12AffineFastState.Bounded env12531 := by
  intro p hp
  have h : env12531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12530_12531 : H12AffineEnvironment.transform 10 276 env12530 = env12531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env12530 == env12531) = true)

theorem identity12531 : scanCanonicalize (H12AffineFastState.compose env12531 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound12531 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12532 : List Nat := [2,4,8,16,0,16,9,256,260,256,276,16,268,276,0,262,260,16,256,1,260,0,16,3,269,16,277,260,16,16,4,1,256,1,277,261]

theorem envBound12532 : H12AffineFastState.Bounded env12532 := by
  intro p hp
  have h : env12532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12531_12532 : H12AffineEnvironment.transform 9 256 env12531 = env12532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env12531 == env12532) = true)

def env12533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58396,272393,16,41311,8193,64,10509,57676,45404,294993,1364,272392,256,41341,16465,513]

theorem envBound12533 : H12AffineFastState.Bounded env12533 := by
  intro p hp
  have h : env12533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12521_12533 : H12AffineEnvironment.transform 16 16449 env12521 = env12533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env12521 == env12533) = true)

theorem identity12533 : scanCanonicalize (H12AffineFastState.compose env12533 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound12533 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,2421,1024,32769,58396,8572,16,41311,8193,64,10509,57676,45404,35108,1364,8573,256,41341,16465,513]

theorem envBound12534 : H12AffineFastState.Bounded env12534 := by
  intro p hp
  have h : env12534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12533_12534 : H12AffineEnvironment.transform 17 2421 env12533 = env12534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env12533 == env12534) = true)

theorem identity12534 : scanCanonicalize (H12AffineFastState.compose env12534 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12534 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env12535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16449,2421,1024,32769,50449,113,16,32850,268,64,2048,49217,36945,35108,1364,112,256,32880,16465,513]

theorem envBound12535 : H12AffineFastState.Bounded env12535 := by
  intro p hp
  have h : env12535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12534_12535 : H12AffineEnvironment.transform 12 269 env12534 = env12535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12534 == env12535) = true)

theorem identity12535 : scanCanonicalize (H12AffineFastState.compose env12535 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound12535 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env12536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,263,16449,2421,1024,81,17729,113,16,2,268,64,2048,16401,4097,2420,1364,112,256,32,16465,513]

theorem envBound12536 : H12AffineFastState.Bounded env12536 := by
  intro p hp
  have h : env12536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12535_12536 : H12AffineEnvironment.transform 14 80 env12535 = env12536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env12535 == env12536) = true)

theorem identity12536 : scanCanonicalize (H12AffineFastState.compose env12536 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 372) := by decide +kernel

theorem selectedBound12536 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env12537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,372,80,263,309,2421,1024,81,1077,113,16,2,268,64,2048,357,4097,2420,1364,112,256,32,293,513]

theorem envBound12537 : H12AffineFastState.Bounded env12537 := by
  intro p hp
  have h : env12537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12536_12537 : H12AffineEnvironment.transform 13 372 env12536 = env12537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 372 env12536 == env12537) = true)

theorem identity12537 : scanCanonicalize (H12AffineFastState.compose env12537 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound12537 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env12538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,269,372,80,263,309,2421,1024,81,1077,113,16,2,268,64,2048,357,2064,2420,1364,112,256,32,293,513]

theorem envBound12538 : H12AffineFastState.Bounded env12538 := by
  intro p hp
  have h : env12538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12537_12538 : H12AffineEnvironment.transform 11 2065 env12537 = env12538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env12537 == env12538) = true)

theorem identity12538 : scanCanonicalize (H12AffineFastState.compose env12538 (packedSelected [0,3,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound12538 : packedSelected [0,3,5,9,11] rootPS < 2^1333 := by decide +kernel

def env12539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,357,269,372,80,263,309,1,1024,81,1077,113,16,2,268,64,372,357,356,0,1364,112,256,32,293,513]

theorem envBound12539 : H12AffineFastState.Bounded env12539 := by
  intro p hp
  have h : env12539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12538_12539 : H12AffineEnvironment.transform 10 372 env12538 = env12539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env12538 == env12539) = true)

def env12540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8193,64,4677967,115015,45405,442384,75102,4268042,256,98678,90202,513]

theorem envBound12540 : H12AffineFastState.Bounded env12540 := by
  intro p hp
  have h : env12540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12518_12540 : H12AffineEnvironment.transform 20 58397 env12518 = env12540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env12518 == env12540) = true)

def env12541 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8193,16,4677919,114967,45325,442384,75022,4268042,256,98598,90122,513]

theorem envBound12541 : H12AffineFastState.Bounded env12541 := by
  intro p hp
  have h : env12541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12540_12541 : H12AffineEnvironment.transform 5 16 env12540 = env12541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12540 == env12541) = true)

def env12542 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8193,16,4409655,114967,45325,190520,75022,4268042,256,98598,90122,513]

theorem envBound12542 : H12AffineFastState.Bounded env12542 := by
  intro p hp
  have h : env12542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12541_12542 : H12AffineEnvironment.transform 17 10280 env12541 = env12542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12541 == env12542) = true)

theorem identity12542 : scanCanonicalize (H12AffineFastState.compose env12542 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound12542 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env12543 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,65830,16,41231,8193,16,149521,114967,45325,190520,75022,8492,256,98598,90122,513]

theorem envBound12543 : H12AffineFastState.Bounded env12543 := by
  intro p hp
  have h : env12543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12542_12543 : H12AffineEnvironment.transform 21 65830 env12542 = env12543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env12542 == env12543) = true)

theorem identity12543 : scanCanonicalize (H12AffineFastState.compose env12543 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound12543 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env12544 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58397,65830,16,41231,8193,16,34817,114967,45325,10280,75022,8492,256,98598,90122,513]

theorem envBound12544 : H12AffineFastState.Bounded env12544 := by
  intro p hp
  have h : env12544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12543_12544 : H12AffineEnvironment.transform 16 49168 env12543 = env12544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env12543 == env12544) = true)

theorem identity12544 : scanCanonicalize (H12AffineFastState.compose env12544 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound12544 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env12545 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10280,1024,32769,58397,41261,16,41231,8193,16,34817,24860,45325,10280,34053,8492,256,8493,49153,513]

theorem envBound12545 : H12AffineFastState.Bounded env12545 := by
  intro p hp
  have h : env12545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12544_12545 : H12AffineEnvironment.transform 15 40971 env12544 = env12545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env12544 == env12545) = true)

def env12546 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8193,16,4409654,114967,45325,190521,75022,4268042,256,98598,90122,513]

theorem envBound12546 : H12AffineFastState.Bounded env12546 := by
  intro p hp
  have h : env12546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12541_12546 : H12AffineEnvironment.transform 17 10281 env12541 = env12546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12541 == env12546) = true)

theorem identity12546 : scanCanonicalize (H12AffineFastState.compose env12546 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound12546 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env12547 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,199939,16,41231,8193,16,17461,114967,45325,190521,75022,142601,256,98598,90122,513]

theorem envBound12547 : H12AffineFastState.Bounded env12547 := by
  intro p hp
  have h : env12547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12546_12547 : H12AffineEnvironment.transform 21 199939 env12546 = env12547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env12546 == env12547) = true)

theorem identity12547 : scanCanonicalize (H12AffineFastState.compose env12547 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12547 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env12548 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,58397,27929,16,41231,8193,16,17461,114967,45325,100387,75022,85267,256,98598,90122,513]

theorem envBound12548 : H12AffineFastState.Bounded env12548 := by
  intro p hp
  have h : env12548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12547_12548 : H12AffineEnvironment.transform 16 90138 env12547 = env12548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12547 == env12548) = true)

theorem identity12548 : scanCanonicalize (H12AffineFastState.compose env12548 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 24879) := by decide +kernel

theorem selectedBound12548 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env12549 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,24879,309,10281,1024,32769,58397,27929,16,41231,8193,16,17461,41016,45325,59660,17441,11324,256,57353,293,513]

theorem envBound12549 : H12AffineFastState.Bounded env12549 := by
  intro p hp
  have h : env12549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12548_12549 : H12AffineEnvironment.transform 15 24879 env12548 = env12549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24879 env12548 == env12549) = true)

theorem identity12549 : scanCanonicalize (H12AffineFastState.compose env12549 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound12549 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12550 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,292,32768,8203,309,10281,1024,32769,42297,11325,16,41231,8193,16,1297,41016,45325,43048,1285,11324,256,41261,293,513]

theorem envBound12550 : H12AffineFastState.Bounded env12550 := by
  intro p hp
  have h : env12550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12549_12550 : H12AffineEnvironment.transform 13 292 env12549 = env12550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env12549 == env12550) = true)

theorem identity12550 : scanCanonicalize (H12AffineFastState.compose env12550 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound12550 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12551 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,8192,292,32768,8203,309,10281,1024,32769,42297,11325,16,41231,8193,16,1297,41016,41016,43048,1285,11324,256,41261,293,513]

theorem envBound12551 : H12AffineFastState.Bounded env12551 := by
  intro p hp
  have h : env12551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12550_12551 : H12AffineEnvironment.transform 11 309 env12550 = env12551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env12550 == env12551) = true)

theorem identity12551 : scanCanonicalize (H12AffineFastState.compose env12551 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12551 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12552 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,309,8192,292,32768,8203,309,8233,1024,32769,42297,9277,16,41231,8193,16,1297,41016,41016,41000,1285,9276,256,41261,293,513]

theorem envBound12552 : H12AffineFastState.Bounded env12552 := by
  intro p hp
  have h : env12552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12551_12552 : H12AffineEnvironment.transform 10 0 env12551 = env12552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12551 == env12552) = true)

theorem identity12552 : scanCanonicalize (H12AffineFastState.compose env12552 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12552 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12553 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,16,8192,1,32768,8203,16,8233,1024,32769,42012,9277,16,41002,8193,16,1076,41016,41016,41000,1056,9276,37,40968,0,513]

theorem envBound12553 : H12AffineFastState.Bounded env12553 := by
  intro p hp
  have h : env12553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12552_12553 : H12AffineEnvironment.transform 7 37 env12552 = env12553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12552 == env12553) = true)

theorem identity12553 : scanCanonicalize (H12AffineFastState.compose env12553 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 9756) := by decide +kernel

theorem selectedBound12553 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env12554 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,16,8192,1,9756,8203,16,8233,1024,9757,512,9277,16,1590,8193,16,1076,1572,1572,1588,1056,9276,37,1556,0,513]

theorem envBound12554 : H12AffineFastState.Bounded env12554 := by
  intro p hp
  have h : env12554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12553_12554 : H12AffineEnvironment.transform 14 9756 env12553 = env12554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9756 env12553 == env12554) = true)

theorem identity12554 : scanCanonicalize (H12AffineFastState.compose env12554 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12554 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env12555 : List Nat := [2,4,8,0,32,0,9,37,512,1024,0,0,8192,1,9740,8203,0,8233,1024,9741,512,9261,0,1574,8193,0,1060,1572,1572,1572,1056,9260,37,1540,0,513]

theorem envBound12555 : H12AffineFastState.Bounded env12555 := by
  intro p hp
  have h : env12555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12554_12555 : H12AffineEnvironment.transform 3 0 env12554 = env12555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12554 == env12555) = true)

theorem identity12555 : scanCanonicalize (H12AffineFastState.compose env12555 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound12555 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12556 : List Nat := [2,4,8,0,32,0,9,37,512,1024,0,0,552,1,1060,547,0,513,1024,1061,512,1541,0,1574,553,0,1060,1572,1572,1572,1056,1540,37,1540,0,513]

theorem envBound12556 : H12AffineFastState.Bounded env12556 := by
  intro p hp
  have h : env12556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12555_12556 : H12AffineEnvironment.transform 12 552 env12555 = env12556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env12555 == env12556) = true)

theorem identity12556 : scanCanonicalize (H12AffineFastState.compose env12556 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12556 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env12557 : List Nat := [2,4,8,0,32,0,9,37,0,1024,0,0,40,1,1060,35,0,1,1024,1061,0,1029,0,1062,41,0,1060,1060,1060,1060,1056,1028,37,1028,0,1]

theorem envBound12557 : H12AffineFastState.Bounded env12557 := by
  intro p hp
  have h : env12557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12556_12557 : H12AffineEnvironment.transform 8 0 env12556 = env12557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12556 == env12557) = true)

theorem identity12557 : scanCanonicalize (H12AffineFastState.compose env12557 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound12557 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12558 : List Nat := [2,4,8,0,32,0,9,37,0,4,0,0,40,1,32,35,0,1,4,33,0,1,0,34,41,0,32,32,32,32,36,0,37,0,0,1]

theorem envBound12558 : H12AffineFastState.Bounded env12558 := by
  intro p hp
  have h : env12558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12557_12558 : H12AffineEnvironment.transform 9 4 env12557 = env12558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env12557 == env12558) = true)

theorem identity12558 : scanCanonicalize (H12AffineFastState.compose env12558 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12559 : List Nat := [2,4,8,0,0,0,9,5,0,4,0,0,8,1,0,3,0,1,4,1,0,1,0,2,9,0,0,0,0,0,4,0,5,0,0,1]

theorem envBound12559 : H12AffineFastState.Bounded env12559 := by
  intro p hp
  have h : env12559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12558_12559 : H12AffineEnvironment.transform 4 0 env12558 = env12559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12558 == env12559) = true)

def env12560 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8193,17,4677918,114966,45324,442384,75023,4268042,256,98599,90123,513]

theorem envBound12560 : H12AffineFastState.Bounded env12560 := by
  intro p hp
  have h : env12560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12540_12560 : H12AffineEnvironment.transform 5 17 env12540 = env12560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12540 == env12560) = true)

theorem identity12560 : scanCanonicalize (H12AffineFastState.compose env12560 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12560 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env12561 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8193,17,4409654,114966,45324,190520,75023,4268042,256,98599,90123,513]

theorem envBound12561 : H12AffineFastState.Bounded env12561 := by
  intro p hp
  have h : env12561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12560_12561 : H12AffineEnvironment.transform 17 10280 env12560 = env12561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12560 == env12561) = true)

theorem identity12561 : scanCanonicalize (H12AffineFastState.compose env12561 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound12561 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env12562 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,4194304,16,41230,8193,17,4204845,114966,45324,100387,75023,4268042,256,98599,90123,513]

theorem envBound12562 : H12AffineFastState.Bounded env12562 := by
  intro p hp
  have h : env12562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12561_12562 : H12AffineEnvironment.transform 16 90139 env12561 = env12562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env12561 == env12562) = true)

theorem identity12562 : scanCanonicalize (H12AffineFastState.compose env12562 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound12562 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env12563 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,65830,16,41230,8193,17,75787,114966,45324,100387,75023,8492,256,98599,90123,513]

theorem envBound12563 : H12AffineFastState.Bounded env12563 := by
  intro p hp
  have h : env12563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12562_12563 : H12AffineEnvironment.transform 21 65830 env12562 = env12563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env12562 == env12563) = true)

theorem identity12563 : scanCanonicalize (H12AffineFastState.compose env12563 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound12563 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12564 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33030,57629,10280,1024,32769,58397,32800,16,41230,8193,17,43277,16400,45324,2341,41993,8492,256,33,57613,513]

theorem envBound12564 : H12AffineFastState.Bounded env12564 := by
  intro p hp
  have h : env12564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12563_12564 : H12AffineEnvironment.transform 15 33030 env12563 = env12564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env12563 == env12564) = true)

theorem identity12564 : scanCanonicalize (H12AffineFastState.compose env12564 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12564 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12565 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33030,49168,2341,1024,32769,50448,32800,16,32771,268,17,34816,16400,36865,2341,34052,33,256,33,49152,513]

theorem envBound12565 : H12AffineFastState.Bounded env12565 := by
  intro p hp
  have h : env12565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12564_12565 : H12AffineEnvironment.transform 12 269 env12564 = env12565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12564 == env12565) = true)

theorem identity12565 : scanCanonicalize (H12AffineFastState.compose env12565 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound12565 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12566 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21540,21794,5172,2341,1024,21541,4404,21508,16,21543,268,17,23588,16400,17445,2341,20768,33,256,33,5156,513]

theorem envBound12566 : H12AffineFastState.Bounded env12566 := by
  intro p hp
  have h : env12566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12565_12566 : H12AffineEnvironment.transform 14 21540 env12565 = env12566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env12565 == env12566) = true)

theorem identity12566 : scanCanonicalize (H12AffineFastState.compose env12566 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound12566 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env12567 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,6160,3124,3378,5172,2341,1024,3125,4404,3092,16,3127,268,17,1076,6144,7221,2341,2352,33,256,33,5156,513]

theorem envBound12567 : H12AffineFastState.Bounded env12567 := by
  intro p hp
  have h : env12567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12566_12567 : H12AffineEnvironment.transform 13 6160 env12566 = env12567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env12566 == env12567) = true)

theorem identity12567 : scanCanonicalize (H12AffineFastState.compose env12567 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound12567 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12568 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1045,4096,269,5125,33,295,5172,1328,1024,32,4404,1,16,34,268,17,1076,5141,4128,1328,1317,33,256,33,5156,513]

theorem envBound12568 : H12AffineFastState.Bounded env12568 := by
  intro p hp
  have h : env12568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12567_12568 : H12AffineEnvironment.transform 10 1045 env12567 = env12568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env12567 == env12568) = true)

def env12569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8193,64,4677967,2172251,2118977,442385,75102,6407190,256,2188651,2196551,513]

theorem envBound12569 : H12AffineFastState.Bounded env12569 := by
  intro p hp
  have h : env12569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12517_12569 : H12AffineEnvironment.transform 22 17 env12517 = env12569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12517 == env12569) = true)

theorem identity12569 : scanCanonicalize (H12AffineFastState.compose env12569 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12569 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41310,8193,64,4456789,2172251,2118977,368651,75102,6407190,256,2188651,2196551,513]

theorem envBound12570 : H12AffineFastState.Bounded env12570 := by
  intro p hp
  have h : env12570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12569_12570 : H12AffineEnvironment.transform 16 90138 env12569 = env12570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12569 == env12570) = true)

theorem identity12570 : scanCanonicalize (H12AffineFastState.compose env12570 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound12570 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,262144,1024,32769,2097152,4194304,17,41310,8193,64,4456789,2139148,2118977,270684,41993,6309185,256,2155580,2098448,513]

theorem envBound12571 : H12AffineFastState.Bounded env12571 := by
  intro p hp
  have h : env12571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12570_12571 : H12AffineEnvironment.transform 15 33111 env12570 = env12571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env12570 == env12571) = true)

theorem identity12571 : scanCanonicalize (H12AffineFastState.compose env12571 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12571 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,2097152,4194304,17,41310,8193,64,4204925,2139148,2118977,2420,41993,6309185,256,2155580,2098448,513]

theorem envBound12572 : H12AffineFastState.Bounded env12572 := by
  intro p hp
  have h : env12572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12571_12572 : H12AffineEnvironment.transform 17 10280 env12571 = env12572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12571 == env12572) = true)

theorem identity12572 : scanCanonicalize (H12AffineFastState.compose env12572 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound12572 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,25676,4194304,17,41310,8193,64,4204925,49216,12557,2420,41993,4202765,256,32880,24924,513]

theorem envBound12573 : H12AffineFastState.Bounded env12573 := by
  intro p hp
  have h : env12573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12572_12573 : H12AffineEnvironment.transform 20 25676 env12572 = env12573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env12572 == env12573) = true)

theorem identity12573 : scanCanonicalize (H12AffineFastState.compose env12573 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound12573 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env12574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,25676,8493,17,41310,8193,64,2128,49216,12557,2420,41993,32,256,32880,24924,513]

theorem envBound12574 : H12AffineFastState.Bounded env12574 := by
  intro p hp
  have h : env12574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12573_12574 : H12AffineEnvironment.transform 21 8493 env12573 = env12574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env12573 == env12574) = true)

theorem identity12574 : scanCanonicalize (H12AffineFastState.compose env12574 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12574 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1024,8541,25676,8493,17,2,8193,64,2128,24860,12557,2420,1365,32,256,8492,24924,513]

theorem envBound12575 : H12AffineFastState.Bounded env12575 := by
  intro p hp
  have h : env12575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12574_12575 : H12AffineEnvironment.transform 14 8540 env12574 = env12575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12574 == env12575) = true)

theorem identity12575 : scanCanonicalize (H12AffineFastState.compose env12575 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12575 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,80,263,16401,2340,1024,81,17728,33,17,2,269,64,2128,16400,4097,2420,1365,32,256,32,16464,513]

theorem envBound12576 : H12AffineFastState.Bounded env12576 := by
  intro p hp
  have h : env12576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12575_12576 : H12AffineEnvironment.transform 12 268 env12575 = env12576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12575 == env12576) = true)

theorem identity12576 : scanCanonicalize (H12AffineFastState.compose env12576 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1392) := by decide +kernel

theorem selectedBound12576 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1392,268,16384,80,263,16401,2340,1024,81,17728,33,17,2,269,64,2128,16400,1393,2420,1365,32,256,32,16464,513]

theorem envBound12577 : H12AffineFastState.Bounded env12577 := by
  intro p hp
  have h : env12577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12576_12577 : H12AffineEnvironment.transform 11 1392 env12576 = env12577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1392 env12576 == env12577) = true)

theorem identity12577 : scanCanonicalize (H12AffineFastState.compose env12577 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2624) := by decide +kernel

theorem selectedBound12577 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env12578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1392,268,2624,80,263,2641,2340,1024,81,3840,33,17,2,269,64,2128,2640,1393,2420,1365,32,256,32,2576,513]

theorem envBound12578 : H12AffineFastState.Bounded env12578 := by
  intro p hp
  have h : env12578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12577_12578 : H12AffineEnvironment.transform 13 2624 env12577 = env12578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2624 env12577 == env12578) = true)

theorem identity12578 : scanCanonicalize (H12AffineFastState.compose env12578 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound12578 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env12579 : List Nat := [2,4,8,16,32,64,9,256,276,1024,2048,1392,268,2388,80,263,2373,2340,1024,81,3092,33,17,2,269,64,2128,2372,1393,2420,1365,32,256,32,2308,277]

theorem envBound12579 : H12AffineFastState.Bounded env12579 := by
  intro p hp
  have h : env12579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12578_12579 : H12AffineEnvironment.transform 8 276 env12578 = env12579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env12578 == env12579) = true)

theorem identity12579 : scanCanonicalize (H12AffineFastState.compose env12579 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound12579 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12580 : List Nat := [2,4,8,16,32,64,9,84,64,1024,2048,1060,88,2048,80,83,2065,2160,1024,81,3092,33,17,2,89,64,2128,2064,1061,2080,1025,32,84,32,2128,65]

theorem envBound12580 : H12AffineFastState.Bounded env12580 := by
  intro p hp
  have h : env12580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12579_12580 : H12AffineEnvironment.transform 7 84 env12579 = env12580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env12579 == env12580) = true)

theorem identity12580 : scanCanonicalize (H12AffineFastState.compose env12580 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12580 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env12581 : List Nat := [2,4,8,16,32,17,9,5,17,1024,2048,1060,9,2048,1,2,2065,2081,1024,0,3092,33,17,2,8,17,2049,2064,1061,2080,1025,32,5,32,2049,16]

theorem envBound12581 : H12AffineFastState.Bounded env12581 := by
  intro p hp
  have h : env12581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12580_12581 : H12AffineEnvironment.transform 5 17 env12580 = env12581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12580 == env12581) = true)

def env12582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound12582 : H12AffineFastState.Bounded env12582 := by
  intro p hp
  have h : env12582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12480_12582 : H12AffineEnvironment.transform 18 1025 env12480 = env12582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12480 == env12582) = true)

theorem identity12582 : scanCanonicalize (H12AffineFastState.compose env12582 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound12582 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655367,18973837,10507600,8749383,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound12583 : H12AffineFastState.Bounded env12583 := by
  intro p hp
  have h : env12583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12582_12583 : H12AffineEnvironment.transform 16 82246 env12582 = env12583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env12582 == env12583) = true)

def env12584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623435,8393985,10507600,8749383,2102685,12645453,257,21792,46212,2175562]

theorem envBound12584 : H12AffineFastState.Bounded env12584 := by
  intro p hp
  have h : env12584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12583_12584 : H12AffineEnvironment.transform 23 10588556 env12583 = env12584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env12583 == env12584) = true)

def env12585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623435,2098513,17664,2461975,2102685,6349853,257,21792,46212,2175562]

theorem envBound12585 : H12AffineFastState.Bounded env12585 := by
  intro p hp
  have h : env12585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12584_12585 : H12AffineEnvironment.transform 22 2101328 env12584 = env12585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env12584 == env12585) = true)

def env12586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177099,2098513,17664,2461975,2102685,2411677,257,21792,46212,2175562]

theorem envBound12586 : H12AffineFastState.Bounded env12586 := by
  intro p hp
  have h : env12586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12585_12586 : H12AffineEnvironment.transform 21 272512 env12585 = env12586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12585 == env12586) = true)

theorem identity12586 : scanCanonicalize (H12AffineFastState.compose env12586 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12586 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,2097152,272512,2101328,41430,8328,64,2103361,2098513,17664,2404637,2102685,2411677,257,21792,46212,2101824]

theorem envBound12587 : H12AffineFastState.Bounded env12587 := by
  intro p hp
  have h : env12587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12586_12587 : H12AffineEnvironment.transform 15 8202 env12586 = env12587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12586 == env12587) = true)

theorem identity12587 : scanCanonicalize (H12AffineFastState.compose env12587 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309472) := by decide +kernel

theorem selectedBound12587 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,309472,272512,305328,41430,8328,64,303265,310705,17664,2557,306557,29821,257,21792,46212,305824]

theorem envBound12588 : H12AffineFastState.Bounded env12588 := by
  intro p hp
  have h : env12588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12587_12588 : H12AffineEnvironment.transform 20 309472 env12587 = env12588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309472 env12587 == env12588) = true)

theorem identity12588 : scanCanonicalize (H12AffineFastState.compose env12588 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound12588 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env12589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,35324,1025,32769,12572,41340,8524,41430,8328,64,10589,13389,17664,2557,9345,29821,257,21792,46212,9052]

theorem envBound12589 : H12AffineFastState.Bounded env12589 := by
  intro p hp
  have h : env12589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12588_12589 : H12AffineEnvironment.transform 17 35324 env12588 = env12589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env12588 == env12589) = true)

theorem identity12589 : scanCanonicalize (H12AffineFastState.compose env12589 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound12589 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,479,16537,35324,1025,32769,4297,32937,153,32771,349,64,2184,5528,17664,2557,1364,21928,257,21792,38225,649]

theorem envBound12590 : H12AffineFastState.Bounded env12590 := by
  intro p hp
  have h : env12590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12589_12590 : H12AffineEnvironment.transform 12 469 env12589 = env12590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env12589 == env12590) = true)

theorem identity12590 : scanCanonicalize (H12AffineFastState.compose env12590 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound12590 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env12591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,479,16537,23804,1025,21761,4297,21929,153,21763,349,64,2184,5528,17664,2557,1364,21928,257,21792,16465,649]

theorem envBound12591 : H12AffineFastState.Bounded env12591 := by
  intro p hp
  have h : env12591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12590_12591 : H12AffineEnvironment.transform 14 21760 env12590 = env12591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env12590 == env12591) = true)

theorem identity12591 : scanCanonicalize (H12AffineFastState.compose env12591 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound12591 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,479,5392,2421,1025,136,4297,32,153,138,349,64,2184,5528,4233,2557,1364,33,257,169,5592,649]

theorem envBound12592 : H12AffineFastState.Bounded env12592 := by
  intro p hp
  have h : env12592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12591_12592 : H12AffineEnvironment.transform 13 5513 env12591 = env12592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env12591 == env12592) = true)

theorem identity12592 : scanCanonicalize (H12AffineFastState.compose env12592 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound12592 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12593 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,41,5237,137,35,5356,2185,1025,136,4297,32,153,138,161,64,2184,5220,4233,2049,1192,33,253,169,5156,649]

theorem envBound12593 : H12AffineFastState.Bounded env12593 := by
  intro p hp
  have h : env12593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12592_12593 : H12AffineEnvironment.transform 7 252 env12592 = env12593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env12592 == env12593) = true)

theorem identity12593 : scanCanonicalize (H12AffineFastState.compose env12593 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound12593 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12594 : List Nat := [2,4,8,16,32,64,128,252,512,1024,217,4096,41,5237,137,35,5356,80,1025,136,4297,32,153,138,161,64,81,5220,4233,216,1192,33,253,169,5156,649]

theorem envBound12594 : H12AffineFastState.Bounded env12594 := by
  intro p hp
  have h : env12594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12593_12594 : H12AffineEnvironment.transform 10 217 env12593 = env12594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env12593 == env12594) = true)

theorem identity12594 : scanCanonicalize (H12AffineFastState.compose env12594 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12594 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env12595 : List Nat := [2,4,8,16,32,17,128,173,512,1024,136,4096,41,5156,137,35,5309,1,1025,136,4248,32,153,138,161,17,0,5173,4233,137,1192,33,172,169,5156,649]

theorem envBound12595 : H12AffineFastState.Bounded env12595 := by
  intro p hp
  have h : env12595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12594_12595 : H12AffineEnvironment.transform 5 17 env12594 = env12595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12594 == env12595) = true)

theorem identity12595 : scanCanonicalize (H12AffineFastState.compose env12595 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound12595 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env12596 : List Nat := [2,4,8,16,32,17,128,173,512,1024,136,153,41,1213,137,35,1060,1,1025,136,1,32,153,138,161,17,0,1196,16,137,1192,33,172,169,1213,649]

theorem envBound12596 : H12AffineFastState.Bounded env12596 := by
  intro p hp
  have h : env12596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12595_12596 : H12AffineEnvironment.transform 11 153 env12595 = env12596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env12595 == env12596) = true)

theorem identity12596 : scanCanonicalize (H12AffineFastState.compose env12596 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound12596 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12597 : List Nat := [2,4,8,16,32,17,128,173,512,21,136,153,41,168,137,35,49,1,20,136,1,32,153,138,161,17,0,185,16,137,189,33,172,169,168,649]

theorem envBound12597 : H12AffineFastState.Bounded env12597 := by
  intro p hp
  have h : env12597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12596_12597 : H12AffineEnvironment.transform 9 21 env12596 = env12597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env12596 == env12597) = true)

def env12598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177098,2098513,17664,2461975,2102685,2411676,257,21792,46212,2175562]

theorem envBound12598 : H12AffineFastState.Bounded env12598 := by
  intro p hp
  have h : env12598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12585_12598 : H12AffineEnvironment.transform 21 272513 env12585 = env12598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12585 == env12598) = true)

theorem identity12598 : scanCanonicalize (H12AffineFastState.compose env12598 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound12598 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272513,73755,98780,8328,64,2049,79130,17664,303452,75222,392407,257,21792,46212,513]

theorem envBound12599 : H12AffineFastState.Bounded env12599 := by
  intro p hp
  have h : env12599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12598_12599 : H12AffineEnvironment.transform 20 77899 env12598 = env12599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env12598 == env12599) = true)

theorem identity12599 : scanCanonicalize (H12AffineFastState.compose env12599 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound12599 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env12600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67618,1025,32769,77899,73891,73755,98780,8328,64,2049,79130,17664,108926,75222,62709,257,21792,46212,513]

theorem envBound12600 : H12AffineFastState.Bounded env12600 := by
  intro p hp
  have h : env12600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12599_12600 : H12AffineEnvironment.transform 17 67618 env12599 = env12600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env12599 == env12600) = true)

theorem identity12600 : scanCanonicalize (H12AffineFastState.compose env12600 (packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12600 : packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env12601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,82246,67618,1025,32769,69911,66047,65863,98780,468,64,2049,70726,17664,100386,66698,54697,257,21792,38360,513]

theorem envBound12601 : H12AffineFastState.Bounded env12601 := by
  intro p hp
  have h : env12601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12600_12601 : H12AffineEnvironment.transform 12 348 env12600 = env12601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12600 == env12601) = true)

def env12602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82246,67618,1025,32769,69911,65911,65863,98644,348,64,2049,70726,17664,100386,66562,54561,257,21792,38224,513]

theorem envBound12602 : H12AffineFastState.Bounded env12602 := by
  intro p hp
  have h : env12602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12601_12602 : H12AffineEnvironment.transform 6 8 env12601 = env12602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12601 == env12602) = true)

theorem identity12602 : scanCanonicalize (H12AffineFastState.compose env12602 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound12602 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env12603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33031,49217,35109,1025,32769,36880,32880,32832,83,348,64,2049,38209,17664,2341,34053,54561,257,21792,38224,513]

theorem envBound12603 : H12AffineFastState.Bounded env12603 := by
  intro p hp
  have h : env12603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12602_12603 : H12AffineEnvironment.transform 15 33031 env12602 = env12603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env12602 == env12603) = true)

theorem identity12603 : scanCanonicalize (H12AffineFastState.compose env12603 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12603 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env12604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,32768,33031,38161,35109,1025,32769,36880,32880,32832,83,348,64,2049,38209,4176,2341,34053,32881,257,112,38224,513]

theorem envBound12604 : H12AffineFastState.Bounded env12604 := by
  intro p hp
  have h : env12604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12603_12604 : H12AffineEnvironment.transform 13 5456 env12603 = env12604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12603 == env12604) = true)

theorem identity12604 : scanCanonicalize (H12AffineFastState.compose env12604 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12604 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12605 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,32768,33031,38161,35109,1025,32769,36880,32801,32785,2,269,17,2049,38160,4097,2341,34053,32800,257,33,38145,513]

theorem envBound12605 : H12AffineFastState.Bounded env12605 := by
  intro p hp
  have h : env12605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12604_12605 : H12AffineEnvironment.transform 5 17 env12604 = env12605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12604 == env12605) = true)

theorem identity12605 : scanCanonicalize (H12AffineFastState.compose env12605 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound12605 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env12606 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,269,5377,32768,33031,38161,33845,1025,32769,36880,32801,32785,2,269,17,1297,38160,4097,1077,34053,32800,257,33,38145,513]

theorem envBound12606 : H12AffineFastState.Bounded env12606 := by
  intro p hp
  have h : env12606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12605_12606 : H12AffineEnvironment.transform 10 1296 env12605 = env12606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env12605 == env12606) = true)

theorem identity12606 : scanCanonicalize (H12AffineFastState.compose env12606 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12606 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12607 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,269,5377,1,262,5392,1076,1025,0,4113,32,16,2,269,17,1297,5393,4097,1077,1284,33,257,33,5376,513]

theorem envBound12607 : H12AffineFastState.Bounded env12607 := by
  intro p hp
  have h : env12607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12606_12607 : H12AffineEnvironment.transform 14 1 env12606 = env12607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12606 == env12607) = true)

theorem identity12607 : scanCanonicalize (H12AffineFastState.compose env12607 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12607 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12608 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,4096,41,5157,1,34,5172,1076,1025,0,4113,32,16,2,41,17,1077,5173,4097,1077,1056,33,37,33,5156,513]

theorem envBound12608 : H12AffineFastState.Bounded env12608 := by
  intro p hp
  have h : env12608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12607_12608 : H12AffineEnvironment.transform 7 36 env12607 = env12608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12607 == env12608) = true)

theorem identity12608 : scanCanonicalize (H12AffineFastState.compose env12608 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12608 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12609 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,4096,41,4113,1,34,4096,0,53,0,4113,32,16,2,41,17,1,4097,4097,1,20,33,37,33,4112,513]

theorem envBound12609 : H12AffineFastState.Bounded env12609 := by
  intro p hp
  have h : env12609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12608_12609 : H12AffineEnvironment.transform 9 52 env12608 = env12609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12608 == env12609) = true)

theorem identity12609 : scanCanonicalize (H12AffineFastState.compose env12609 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12610 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,4096,41,4113,1,34,4096,0,53,0,4113,32,16,2,41,17,1,4097,4097,1,20,33,37,33,4112,1]

theorem envBound12610 : H12AffineFastState.Bounded env12610 := by
  intro p hp
  have h : env12610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12609_12610 : H12AffineEnvironment.transform 8 0 env12609 = env12610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12609 == env12610) = true)

theorem identity12610 : scanCanonicalize (H12AffineFastState.compose env12610 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound12610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12611 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,11,41,26,1,34,11,0,53,0,26,32,16,2,41,17,1,10,10,1,20,33,37,33,27,1]

theorem envBound12611 : H12AffineFastState.Bounded env12611 := by
  intro p hp
  have h : env12611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12610_12611 : H12AffineEnvironment.transform 11 11 env12610 = env12611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env12610 == env12611) = true)

theorem identity12611 : scanCanonicalize (H12AffineFastState.compose env12611 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12611 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12612 : List Nat := [2,4,8,10,32,11,8,36,0,46,0,11,41,0,1,34,11,0,47,0,0,32,10,2,41,11,1,10,10,1,14,33,37,33,1,1]

theorem envBound12612 : H12AffineFastState.Bounded env12612 := by
  intro p hp
  have h : env12612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12611_12612 : H12AffineEnvironment.transform 3 10 env12611 = env12612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12611 == env12612) = true)

def env12613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,67618,1025,32769,69911,65910,65863,98645,349,64,2049,70726,17664,100386,66563,54560,257,21792,38225,513]

theorem envBound12613 : H12AffineFastState.Bounded env12613 := by
  intro p hp
  have h : env12613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12601_12613 : H12AffineEnvironment.transform 6 9 env12601 = env12613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12601 == env12613) = true)

theorem identity12613 : scanCanonicalize (H12AffineFastState.compose env12613 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound12613 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33110,49168,35188,1025,32769,36929,32800,32785,3,349,64,2049,38160,17664,2420,34133,54560,257,21792,38225,513]

theorem envBound12614 : H12AffineFastState.Bounded env12614 := by
  intro p hp
  have h : env12614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12613_12614 : H12AffineEnvironment.transform 15 33110 env12613 = env12614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env12613 == env12614) = true)

theorem identity12614 : scanCanonicalize (H12AffineFastState.compose env12614 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12614 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,342,16400,2420,1025,1,4161,32,17,3,349,64,2049,5392,17664,2420,1365,21792,257,21792,5457,513]

theorem envBound12615 : H12AffineFastState.Bounded env12615 := by
  intro p hp
  have h : env12615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12614_12615 : H12AffineEnvironment.transform 14 0 env12614 = env12615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12614 == env12615) = true)

theorem identity12615 : scanCanonicalize (H12AffineFastState.compose env12615 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound12615 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,6161,0,342,6145,2420,1025,1,4161,32,17,3,349,64,2049,5392,7441,2420,1365,3377,257,3377,5457,513]

theorem envBound12616 : H12AffineFastState.Bounded env12616 := by
  intro p hp
  have h : env12616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12615_12616 : H12AffineEnvironment.transform 13 6161 env12615 = env12616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env12615 == env12616) = true)

theorem identity12616 : scanCanonicalize (H12AffineFastState.compose env12616 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound12616 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env12617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1313,4096,348,5424,0,342,5408,1109,1025,1,4161,32,17,3,349,64,1312,5392,4144,1109,1365,16,257,16,5457,513]

theorem envBound12617 : H12AffineFastState.Bounded env12617 := by
  intro p hp
  have h : env12617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12616_12617 : H12AffineEnvironment.transform 10 1313 env12616 = env12617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env12616 == env12617) = true)

theorem identity12617 : scanCanonicalize (H12AffineFastState.compose env12617 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound12617 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env12618 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1141,4096,8,5220,0,2,5236,1109,1025,1,4161,32,17,3,9,64,1140,5188,4144,1109,1025,16,85,16,5125,513]

theorem envBound12618 : H12AffineFastState.Bounded env12618 := by
  intro p hp
  have h : env12618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12617_12618 : H12AffineEnvironment.transform 7 84 env12617 = env12618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env12617 == env12618) = true)

theorem identity12618 : scanCanonicalize (H12AffineFastState.compose env12618 (packedSelected [2,11] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound12618 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env12619 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1141,1109,8,49,0,2,33,1109,1025,1,1044,32,17,3,9,64,1140,17,1125,1109,1025,16,85,16,80,513]

theorem envBound12619 : H12AffineFastState.Bounded env12619 := by
  intro p hp
  have h : env12619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12618_12619 : H12AffineEnvironment.transform 11 1109 env12618 = env12619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env12618 == env12619) = true)

theorem identity12619 : scanCanonicalize (H12AffineFastState.compose env12619 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound12619 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12620 : List Nat := [2,4,8,16,32,64,9,84,512,532,609,577,8,49,0,2,33,577,533,1,512,32,17,3,9,64,608,17,625,577,533,16,85,16,80,513]

theorem envBound12620 : H12AffineFastState.Bounded env12620 := by
  intro p hp
  have h : env12620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12619_12620 : H12AffineEnvironment.transform 9 532 env12619 = env12620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env12619 == env12620) = true)

theorem identity12620 : scanCanonicalize (H12AffineFastState.compose env12620 (packedSelected [0,1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12620 : packedSelected [0,1,2,8] rootPS < 2^1333 := by decide +kernel

def env12621 : List Nat := [2,4,8,1,32,64,9,69,512,517,609,577,8,32,0,2,33,577,516,1,512,32,0,3,9,64,608,0,608,577,516,1,68,1,65,513]

theorem envBound12621 : H12AffineFastState.Bounded env12621 := by
  intro p hp
  have h : env12621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12620_12621 : H12AffineEnvironment.transform 3 1 env12620 = env12621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12620 == env12621) = true)

theorem identity12621 : scanCanonicalize (H12AffineFastState.compose env12621 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12621 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12622 : List Nat := [2,4,8,1,32,64,9,69,1,4,96,64,8,32,0,2,33,64,5,1,1,32,0,3,9,64,97,0,97,64,5,1,68,1,65,0]

theorem envBound12622 : H12AffineFastState.Bounded env12622 := by
  intro p hp
  have h : env12622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12621_12622 : H12AffineEnvironment.transform 8 1 env12621 = env12622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12621 == env12622) = true)

def env12623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623435,2098512,17665,2461974,2102685,6349852,257,21792,46212,2175562]

theorem envBound12623 : H12AffineFastState.Bounded env12623 := by
  intro p hp
  have h : env12623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12584_12623 : H12AffineEnvironment.transform 22 2101329 env12584 = env12623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env12584 == env12623) = true)

def env12624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177099,2098512,17665,2461974,2102685,2411676,257,21792,46212,2175562]

theorem envBound12624 : H12AffineFastState.Bounded env12624 := by
  intro p hp
  have h : env12624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12623_12624 : H12AffineEnvironment.transform 21 272512 env12623 = env12624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12623 == env12624) = true)

theorem identity12624 : scanCanonicalize (H12AffineFastState.compose env12624 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound12624 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38297,262144,1025,32769,2097152,272512,2101329,21762,8328,64,2157716,2098512,17665,2377161,2102685,2411676,257,21792,46212,2156181]

theorem envBound12625 : H12AffineFastState.Bounded env12625 := by
  intro p hp
  have h : env12625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12624_12625 : H12AffineEnvironment.transform 15 54495 env12624 = env12625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env12624 == env12625) = true)

def env12626 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,2097152,272512,2101249,21762,8328,16,2157716,2098432,17665,2377113,2102685,2411676,257,21792,46212,2156181]

theorem envBound12626 : H12AffineFastState.Bounded env12626 := by
  intro p hp
  have h : env12626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12625_12626 : H12AffineEnvironment.transform 5 16 env12625 = env12626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12625 == env12626) = true)

theorem identity12626 : scanCanonicalize (H12AffineFastState.compose env12626 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound12626 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env12627 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,58516,272512,62613,21762,8328,16,2048,57748,17665,303373,61705,272392,257,21792,46212,513]

theorem envBound12627 : H12AffineFastState.Bounded env12627 := by
  intro p hp
  have h : env12627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12626_12627 : H12AffineEnvironment.transform 20 58516 env12626 = env12627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env12626 == env12627) = true)

theorem identity12627 : scanCanonicalize (H12AffineFastState.compose env12627 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound12627 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env12628 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,23589,1025,32769,58516,29861,62613,21762,8328,16,2048,57748,17665,64808,61705,29741,257,21792,46212,513]

theorem envBound12628 : H12AffineFastState.Bounded env12628 := by
  intro p hp
  have h : env12628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12627_12628 : H12AffineEnvironment.transform 17 23589 env12627 = env12628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env12627 == env12628) = true)

theorem identity12628 : scanCanonicalize (H12AffineFastState.compose env12628 (packedSelected [0,1,2,3,4,5,6,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12628 : packedSelected [0,1,2,3,4,5,6,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env12629 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33167,38297,2341,1025,32769,45460,8613,41365,2,8328,16,2048,46228,4097,43048,41993,8493,257,32,46212,513]

theorem envBound12629 : H12AffineFastState.Bounded env12629 := by
  intro p hp
  have h : env12629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12628_12629 : H12AffineEnvironment.transform 13 5376 env12628 = env12629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12628 == env12629) = true)

theorem identity12629 : scanCanonicalize (H12AffineFastState.compose env12629 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12629 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env12630 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,1,398,5528,2341,1025,0,12693,8613,8596,2,8328,16,2048,13461,4097,10281,9224,8493,257,32,13445,513]

theorem envBound12630 : H12AffineFastState.Bounded env12630 := by
  intro p hp
  have h : env12630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12629_12630 : H12AffineEnvironment.transform 14 1 env12629 = env12630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12629 == env12630) = true)

theorem identity12630 : scanCanonicalize (H12AffineFastState.compose env12630 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound12630 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env12631 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5376,1,398,5528,2341,1025,0,4113,33,16,2,268,16,2048,5393,4097,2477,1420,169,257,32,5377,513]

theorem envBound12631 : H12AffineFastState.Bounded env12631 := by
  intro p hp
  have h : env12631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12630_12631 : H12AffineEnvironment.transform 12 388 env12630 = env12631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env12630 == env12631) = true)

theorem identity12631 : scanCanonicalize (H12AffineFastState.compose env12631 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12631 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12632 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2341,1025,0,4113,33,16,2,268,16,2048,5393,4097,2341,1284,33,257,32,5377,513]

theorem envBound12632 : H12AffineFastState.Bounded env12632 := by
  intro p hp
  have h : env12632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12631_12632 : H12AffineEnvironment.transform 6 8 env12631 = env12632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12631 == env12632) = true)

theorem identity12632 : scanCanonicalize (H12AffineFastState.compose env12632 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound12632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12633 : List Nat := [2,4,8,16,32,16,8,256,512,256,2048,4096,268,4096,1,262,4112,2341,257,0,4113,33,16,2,268,16,2048,4113,4097,2341,4,33,257,32,4097,513]

theorem envBound12633 : H12AffineFastState.Bounded env12633 := by
  intro p hp
  have h : env12633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12632_12633 : H12AffineEnvironment.transform 9 256 env12632 = env12633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env12632 == env12633) = true)

theorem identity12633 : scanCanonicalize (H12AffineFastState.compose env12633 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound12633 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12634 : List Nat := [2,4,8,16,32,16,8,256,309,256,2048,4096,268,4096,1,262,4112,2341,257,0,4113,33,16,2,268,16,2048,4113,4097,2341,4,33,257,32,4097,308]

theorem envBound12634 : H12AffineFastState.Bounded env12634 := by
  intro p hp
  have h : env12634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12633_12634 : H12AffineEnvironment.transform 8 309 env12633 = env12634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env12633 == env12634) = true)

theorem identity12634 : scanCanonicalize (H12AffineFastState.compose env12634 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound12634 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12635 : List Nat := [2,4,8,16,32,16,8,256,309,256,2048,1,268,1,1,262,17,2341,257,0,16,33,16,2,268,16,2048,16,0,2341,4,33,257,32,0,308]

theorem envBound12635 : H12AffineFastState.Bounded env12635 := by
  intro p hp
  have h : env12635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12634_12635 : H12AffineEnvironment.transform 11 1 env12634 = env12635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env12634 == env12635) = true)

def env12636 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,262144,1025,32769,2097152,272512,2101248,21762,8328,17,2157716,2098433,17665,2377112,2102685,2411676,257,21792,46212,2156181]

theorem envBound12636 : H12AffineFastState.Bounded env12636 := by
  intro p hp
  have h : env12636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12625_12636 : H12AffineEnvironment.transform 5 17 env12625 = env12636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12625 == env12636) = true)

theorem identity12636 : scanCanonicalize (H12AffineFastState.compose env12636 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12636 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env12637 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,262144,1025,32769,2097152,272392,2101248,21762,8192,17,2157596,2098433,17665,2376976,2102549,2411540,257,21792,46092,2156061]

theorem envBound12637 : H12AffineFastState.Bounded env12637 := by
  intro p hp
  have h : env12637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12636_12637 : H12AffineEnvironment.transform 6 8 env12636 = env12637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12636 == env12637) = true)

theorem identity12637 : scanCanonicalize (H12AffineFastState.compose env12637 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound12637 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env12638 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,262144,1025,32769,25629,272392,29725,21762,8192,17,34817,24860,17665,270605,28936,305161,257,21792,46092,33280]

theorem envBound12638 : H12AffineFastState.Bounded env12638 := by
  intro p hp
  have h : env12638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12637_12638 : H12AffineEnvironment.transform 20 25629 env12637 = env12638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env12637 == env12638) = true)

theorem identity12638 : scanCanonicalize (H12AffineFastState.compose env12638 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound12638 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env12639 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,32040,1025,32769,25629,21792,29725,21762,8192,17,34817,24860,17665,23589,28936,54561,257,21792,46092,33280]

theorem envBound12639 : H12AffineFastState.Bounded env12639 := by
  intro p hp
  have h : env12639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12638_12639 : H12AffineEnvironment.transform 17 32040 env12638 = env12639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env12638 == env12639) = true)

theorem identity12639 : scanCanonicalize (H12AffineFastState.compose env12639 (packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12639 : packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env12640 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,29962,13341,32040,1025,8461,25629,21792,29725,21762,8192,17,10509,24860,17665,23589,28936,29741,257,21792,5376,8972]

theorem envBound12640 : H12AffineFastState.Bounded env12640 := by
  intro p hp
  have h : env12640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12639_12640 : H12AffineEnvironment.transform 14 8460 env12639 = env12640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12639 == env12640) = true)

def env12641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177098,2098512,17665,2461974,2102685,2411677,257,21792,46212,2175562]

theorem envBound12641 : H12AffineFastState.Bounded env12641 := by
  intro p hp
  have h : env12641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12623_12641 : H12AffineEnvironment.transform 21 272513 env12623 = env12641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12623 == env12641) = true)

theorem identity12641 : scanCanonicalize (H12AffineFastState.compose env12641 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound12641 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115871,272513,120014,98781,8328,64,64725,115151,17665,284041,119042,329730,257,21792,46212,63189]

theorem envBound12642 : H12AffineFastState.Bounded env12642 := by
  intro p hp
  have h : env12642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12641_12642 : H12AffineEnvironment.transform 20 115871 env12641 = env12642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env12641 == env12642) = true)

def env12643 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115871,272513,119966,98701,8328,16,64645,115103,17665,284041,119042,329730,257,21792,46212,63109]

theorem envBound12643 : H12AffineFastState.Bounded env12643 := by
  intro p hp
  have h : env12643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12642_12643 : H12AffineEnvironment.transform 5 16 env12642 = env12643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12642 == env12643) = true)

theorem identity12643 : scanCanonicalize (H12AffineFastState.compose env12643 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound12643 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env12644 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,122146,1025,32769,115871,128419,119966,98701,8328,16,64645,115103,17665,100523,119042,54560,257,21792,46212,63109]

theorem envBound12644 : H12AffineFastState.Bounded env12644 := by
  intro p hp
  have h : env12644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12643_12644 : H12AffineEnvironment.transform 17 122146 env12643 = env12644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env12643 == env12644) = true)

theorem identity12644 : scanCanonicalize (H12AffineFastState.compose env12644 (packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12644 : packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12645 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,24860,64808,1025,32769,58517,54697,62612,41351,8328,16,64645,57749,17665,43169,61704,54560,257,21792,46212,63109]

theorem envBound12645 : H12AffineFastState.Bounded env12645 := by
  intro p hp
  have h : env12645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12644_12645 : H12AffineEnvironment.transform 15 8202 env12644 = env12645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12644 == env12645) = true)

theorem identity12645 : scanCanonicalize (H12AffineFastState.compose env12645 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound12645 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env12646 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8202,24860,2476,1025,29829,4113,8493,16,21763,8328,16,2049,5393,17665,23589,1420,8612,257,21792,16384,513]

theorem envBound12646 : H12AffineFastState.Bounded env12646 := by
  intro p hp
  have h : env12646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12645_12646 : H12AffineEnvironment.transform 14 29828 env12645 = env12646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env12645 == env12646) = true)

theorem identity12646 : scanCanonicalize (H12AffineFastState.compose env12646 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12646 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12647 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21896,262,16400,2476,1025,21897,4113,33,16,21763,388,16,2049,5393,17665,23589,1420,168,257,21792,16384,513]

theorem envBound12647 : H12AffineFastState.Bounded env12647 := by
  intro p hp
  have h : env12647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12646_12647 : H12AffineEnvironment.transform 12 268 env12646 = env12647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12646 == env12647) = true)

theorem identity12647 : scanCanonicalize (H12AffineFastState.compose env12647 (packedSelected [0,2,5,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound12647 : packedSelected [0,2,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env12648 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,444,268,16384,17460,262,16400,2476,1025,17461,429,33,16,17599,388,16,2049,1197,17665,19865,1420,168,257,17564,16384,513]

theorem envBound12648 : H12AffineFastState.Bounded env12648 := by
  intro p hp
  have h : env12648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12647_12648 : H12AffineEnvironment.transform 11 444 env12647 = env12648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env12647 == env12648) = true)

theorem identity12648 : scanCanonicalize (H12AffineFastState.compose env12648 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 393) := by decide +kernel

theorem selectedBound12648 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12649 : List Nat := [2,4,8,16,32,16,128,256,512,393,2048,444,268,16384,16829,262,16400,2476,392,16828,429,33,16,16694,388,16,2049,292,16520,18448,5,168,257,16661,16384,513]

theorem envBound12649 : H12AffineFastState.Bounded env12649 := by
  intro p hp
  have h : env12649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12648_12649 : H12AffineEnvironment.transform 9 393 env12648 = env12649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env12648 == env12649) = true)

theorem identity12649 : scanCanonicalize (H12AffineFastState.compose env12649 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(13+1) ^^^ 2609) := by decide +kernel

theorem selectedBound12649 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env12650 : List Nat := [2,4,8,16,32,16,128,256,512,393,2048,444,268,2609,2956,262,2593,2476,392,2957,429,33,16,2823,388,16,2049,292,2745,545,5,168,257,2852,2609,513]

theorem envBound12650 : H12AffineFastState.Bounded env12650 := by
  intro p hp
  have h : env12650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12649_12650 : H12AffineEnvironment.transform 13 2609 env12649 = env12650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2609 env12649 == env12650) = true)

theorem identity12650 : scanCanonicalize (H12AffineFastState.compose env12650 (packedSelected [0,1,5,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound12650 : packedSelected [0,1,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env12651 : List Nat := [2,4,8,16,32,16,128,256,512,393,396,444,268,957,512,262,941,32,392,513,429,33,16,651,388,16,397,292,821,545,5,168,257,680,957,513]

theorem envBound12651 : H12AffineFastState.Bounded env12651 := by
  intro p hp
  have h : env12651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12650_12651 : H12AffineEnvironment.transform 10 396 env12650 = env12651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env12650 == env12651) = true)

theorem identity12651 : scanCanonicalize (H12AffineFastState.compose env12651 (packedSelected [4,6,7,14] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12651 : packedSelected [4,6,7,14] rootPS < 2^1333 := by decide +kernel

def env12652 : List Nat := [2,4,8,16,32,16,128,256,1,393,396,444,268,444,1,262,428,32,392,0,429,33,16,138,388,16,397,292,308,32,5,168,257,169,444,0]

theorem envBound12652 : H12AffineFastState.Bounded env12652 := by
  intro p hp
  have h : env12652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12651_12652 : H12AffineEnvironment.transform 8 1 env12651 = env12652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12651 == env12652) = true)

theorem identity12652 : scanCanonicalize (H12AffineFastState.compose env12652 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound12652 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env12653 : List Nat := [2,4,8,16,32,16,128,188,1,53,48,0,176,0,1,186,16,32,52,0,17,33,16,138,56,16,49,152,136,32,5,168,189,169,0,0]

theorem envBound12653 : H12AffineFastState.Bounded env12653 := by
  intro p hp
  have h : env12653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12652_12653 : H12AffineEnvironment.transform 7 188 env12652 = env12653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env12652 == env12653) = true)

theorem identity12653 : scanCanonicalize (H12AffineFastState.compose env12653 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound12653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12654 : List Nat := [2,4,8,16,32,16,40,20,1,53,48,0,24,0,1,18,16,32,52,0,17,33,16,34,56,16,49,48,32,32,5,0,21,1,0,0]

theorem envBound12654 : H12AffineFastState.Bounded env12654 := by
  intro p hp
  have h : env12654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12653_12654 : H12AffineEnvironment.transform 6 40 env12653 = env12654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env12653 == env12654) = true)

def env12655 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115871,272513,119967,98700,8328,17,64644,115102,17665,284041,119042,329730,257,21792,46212,63108]

theorem envBound12655 : H12AffineFastState.Bounded env12655 := by
  intro p hp
  have h : env12655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12642_12655 : H12AffineEnvironment.transform 5 17 env12642 = env12655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12642 == env12655) = true)

theorem identity12655 : scanCanonicalize (H12AffineFastState.compose env12655 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound12655 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env12656 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,64808,1025,32769,115871,54697,119967,98700,8328,17,64644,115102,17665,43169,119042,128298,257,21792,46212,63108]

theorem envBound12656 : H12AffineFastState.Bounded env12656 := by
  intro p hp
  have h : env12656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12655_12656 : H12AffineEnvironment.transform 17 64808 env12655 = env12656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env12655 == env12656) = true)

theorem identity12656 : scanCanonicalize (H12AffineFastState.compose env12656 (packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12656 : packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env12657 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,24861,64808,1025,32769,58517,54697,62613,41350,8328,17,64644,57748,17665,43169,61704,54560,257,21792,46212,63108]

theorem envBound12657 : H12AffineFastState.Bounded env12657 := by
  intro p hp
  have h : env12657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12656_12657 : H12AffineEnvironment.transform 15 8202 env12656 = env12657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12656 == env12657) = true)

theorem identity12657 : scanCanonicalize (H12AffineFastState.compose env12657 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound12657 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env12658 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8202,13460,43169,1025,32769,45340,32800,41244,41350,8328,17,43277,46109,4232,43169,42113,32937,257,169,46212,41741]

theorem envBound12658 : H12AffineFastState.Bounded env12658 := by
  intro p hp
  have h : env12658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12657_12658 : H12AffineEnvironment.transform 13 5513 env12657 = env12658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env12657 == env12658) = true)

theorem identity12658 : scanCanonicalize (H12AffineFastState.compose env12658 (packedSelected [1,2,3,5,6,7,8,9,10,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 2712) := by decide +kernel

theorem selectedBound12658 : packedSelected [1,2,3,5,6,7,8,9,10,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env12659 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,2712,8202,13460,8761,1025,2713,15236,2744,11140,11038,8328,17,9109,16005,4232,8761,11801,2609,257,169,15900,10645]

theorem envBound12659 : H12AffineFastState.Bounded env12659 := by
  intro p hp
  have h : env12659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12658_12659 : H12AffineEnvironment.transform 14 2712 env12658 = env12659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2712 env12658 == env12659) = true)

theorem identity12659 : scanCanonicalize (H12AffineFastState.compose env12659 (packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 2877) := by decide +kernel

theorem selectedBound12659 : packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env12660 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2877,5513,2712,2871,8105,2308,1025,2713,4281,2744,185,35,2997,17,2216,5560,4232,2308,1316,2609,257,169,5409,680]

theorem envBound12660 : H12AffineFastState.Bounded env12660 := by
  intro p hp
  have h : env12660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12659_12660 : H12AffineEnvironment.transform 12 2877 env12659 = env12660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2877 env12659 == env12660) = true)

theorem identity12660 : scanCanonicalize (H12AffineFastState.compose env12660 (packedSelected [2,6,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12660 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env12661 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,2845,5513,2712,2839,8073,2308,1025,2713,4249,2712,153,3,2965,17,2184,5528,4232,2308,1284,2577,257,137,5377,648]

theorem envBound12661 : H12AffineFastState.Bounded env12661 := by
  intro p hp
  have h : env12661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12660_12661 : H12AffineEnvironment.transform 4 0 env12660 = env12661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12660 == env12661) = true)

theorem identity12661 : scanCanonicalize (H12AffineFastState.compose env12661 (packedSelected [0,1,2,6,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound12661 : packedSelected [0,1,2,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env12662 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,1540,2845,909,2712,2839,2445,2308,1025,2713,1693,2712,153,3,2965,17,2184,924,1676,2308,1284,2577,257,137,773,648]

theorem envBound12662 : H12AffineFastState.Bounded env12662 := by
  intro p hp
  have h : env12662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12661_12662 : H12AffineEnvironment.transform 11 1540 env12661 = env12662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env12661 == env12662) = true)

theorem identity12662 : scanCanonicalize (H12AffineFastState.compose env12662 (packedSelected [0,2,3,4,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound12662 : packedSelected [0,2,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12663 : List Nat := [2,4,8,16,0,17,128,256,512,1024,528,1540,269,909,136,263,925,788,1025,137,1693,136,153,3,389,17,664,924,1676,788,1284,1,257,137,773,648]

theorem envBound12663 : H12AffineFastState.Bounded env12663 := by
  intro p hp
  have h : env12663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12662_12663 : H12AffineEnvironment.transform 10 528 env12662 = env12663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env12662 == env12663) = true)

theorem identity12663 : scanCanonicalize (H12AffineFastState.compose env12663 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 393) := by decide +kernel

theorem selectedBound12663 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12664 : List Nat := [2,4,8,16,0,17,128,256,512,393,528,909,269,909,136,263,925,788,392,137,788,136,153,3,389,17,664,924,773,788,141,1,257,137,773,648]

theorem envBound12664 : H12AffineFastState.Bounded env12664 := by
  intro p hp
  have h : env12664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12663_12664 : H12AffineEnvironment.transform 9 393 env12663 = env12664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env12663 == env12664) = true)

theorem identity12664 : scanCanonicalize (H12AffineFastState.compose env12664 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound12664 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12665 : List Nat := [2,4,8,16,0,17,24,256,512,273,528,789,269,789,16,263,773,788,272,17,788,16,1,3,285,17,512,772,773,788,21,1,257,17,773,528]

theorem envBound12665 : H12AffineFastState.Bounded env12665 := by
  intro p hp
  have h : env12665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12664_12665 : H12AffineEnvironment.transform 6 24 env12664 = env12665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env12664 == env12665) = true)

theorem identity12665 : scanCanonicalize (H12AffineFastState.compose env12665 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12665 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env12666 : List Nat := [2,4,8,1,0,0,9,256,512,256,513,772,269,772,1,263,773,773,257,0,773,1,1,3,268,0,512,772,773,773,4,1,257,0,773,513]

theorem envBound12666 : H12AffineFastState.Bounded env12666 := by
  intro p hp
  have h : env12666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12665_12666 : H12AffineEnvironment.transform 3 1 env12665 = env12666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12665 == env12666) = true)

def env12667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623434,8393984,10507600,8749383,2102684,12645452,257,21793,46213,2175563]

theorem envBound12667 : H12AffineFastState.Bounded env12667 := by
  intro p hp
  have h : env12667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12583_12667 : H12AffineEnvironment.transform 23 10588557 env12583 = env12667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env12583 == env12667) = true)

def env12668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623434,2098512,17664,2461975,2102684,6349852,257,21793,46213,2175563]

theorem envBound12668 : H12AffineFastState.Bounded env12668 := by
  intro p hp
  have h : env12668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12667_12668 : H12AffineEnvironment.transform 22 2101328 env12667 = env12668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env12667 == env12668) = true)

def env12669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177098,2098512,17664,2461975,2102684,2411676,257,21793,46213,2175563]

theorem envBound12669 : H12AffineFastState.Bounded env12669 := by
  intro p hp
  have h : env12669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12668_12669 : H12AffineEnvironment.transform 21 272512 env12668 = env12669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12668 == env12669) = true)

theorem identity12669 : scanCanonicalize (H12AffineFastState.compose env12669 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound12669 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,58516,272512,62660,98781,8328,64,122078,57796,17664,357763,61704,272392,257,21793,46213,120543]

theorem envBound12670 : H12AffineFastState.Bounded env12670 := by
  intro p hp
  have h : env12670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12669_12670 : H12AffineEnvironment.transform 20 58516 env12669 = env12670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env12669 == env12670) = true)

def env12671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,58516,168,62660,98781,8328,64,122078,57796,17664,89515,61704,32,257,21793,46213,120543]

theorem envBound12671 : H12AffineFastState.Bounded env12671 := by
  intro p hp
  have h : env12671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12670_12671 : H12AffineEnvironment.transform 17 10280 env12670 = env12671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12670 == env12671) = true)

theorem identity12671 : scanCanonicalize (H12AffineFastState.compose env12671 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound12671 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env12672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21726,5528,10280,1025,32769,58516,168,62660,54531,8328,64,34816,57796,17664,2421,61704,32,257,21793,46213,33281]

theorem envBound12672 : H12AffineFastState.Bounded env12672 := by
  intro p hp
  have h : env12672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12671_12672 : H12AffineEnvironment.transform 15 21726 env12671 = env12672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env12671 == env12672) = true)

theorem identity12672 : scanCanonicalize (H12AffineFastState.compose env12672 (packedSelected [0,1,3,4,7,8,10,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound12672 : packedSelected [0,1,3,4,7,8,10,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,5528,10280,1025,32769,36929,168,32785,41430,8328,64,34816,38161,12757,2421,34269,32,257,8692,46213,33281]

theorem envBound12673 : H12AffineFastState.Bounded env12673 := by
  intro p hp
  have h : env12673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12672_12673 : H12AffineEnvironment.transform 13 13525 env12672 = env12673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env12672 == env12673) = true)

theorem identity12673 : scanCanonicalize (H12AffineFastState.compose env12673 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound12673 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env12674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5456,32768,398,5528,2477,1025,32769,36929,168,32785,32851,269,64,34816,38161,4176,2421,34269,32,257,113,38144,33281]

theorem envBound12674 : H12AffineFastState.Bounded env12674 := by
  intro p hp
  have h : env12674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12673_12674 : H12AffineEnvironment.transform 12 389 env12673 = env12674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env12673 == env12674) = true)

theorem identity12674 : scanCanonicalize (H12AffineFastState.compose env12674 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12674 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env12675 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5456,32768,343,5441,2420,1025,32769,36929,113,32785,32851,269,64,34816,38161,4176,2421,34052,32,257,113,38144,33281]

theorem envBound12675 : H12AffineFastState.Bounded env12675 := by
  intro p hp
  have h : env12675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12674_12675 : H12AffineEnvironment.transform 6 89 env12674 = env12675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12674 == env12675) = true)

theorem identity12675 : scanCanonicalize (H12AffineFastState.compose env12675 (packedSelected [0,1,3,5,6,7,8,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound12675 : packedSelected [0,1,3,5,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env12676 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5456,113,343,5441,2420,1025,112,4144,113,96,34,269,64,2161,5472,4176,2421,1397,32,257,113,5489,624]

theorem envBound12676 : H12AffineFastState.Bounded env12676 := by
  intro p hp
  have h : env12676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12675_12676 : H12AffineEnvironment.transform 14 113 env12675 = env12676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env12675 == env12676) = true)

theorem identity12676 : scanCanonicalize (H12AffineFastState.compose env12676 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12676 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12677 : List Nat := [2,4,8,16,0,64,89,256,512,1024,2048,4096,348,5456,81,343,5441,2388,1025,80,4112,81,64,2,269,64,2129,5440,4176,2389,1365,0,257,81,5457,592]

theorem envBound12677 : H12AffineFastState.Bounded env12677 := by
  intro p hp
  have h : env12677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12676_12677 : H12AffineEnvironment.transform 4 0 env12676 = env12677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12676 == env12677) = true)

theorem identity12677 : scanCanonicalize (H12AffineFastState.compose env12677 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound12677 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env12678 : List Nat := [2,4,8,16,0,64,89,84,512,1024,2048,4096,8,5124,81,3,5141,2048,1025,80,4112,81,64,2,89,64,2129,5140,4176,2049,1025,0,85,81,5125,592]

theorem envBound12678 : H12AffineFastState.Bounded env12678 := by
  intro p hp
  have h : env12678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12677_12678 : H12AffineEnvironment.transform 7 84 env12677 = env12678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env12677 == env12678) = true)

theorem identity12678 : scanCanonicalize (H12AffineFastState.compose env12678 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound12678 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env12679 : List Nat := [2,4,8,16,0,64,89,84,512,532,2048,4096,8,4624,81,3,4609,2048,533,80,4112,81,64,2,89,64,2129,4608,4176,2049,533,0,85,81,4625,592]

theorem envBound12679 : H12AffineFastState.Bounded env12679 := by
  intro p hp
  have h : env12679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12678_12679 : H12AffineEnvironment.transform 9 532 env12678 = env12679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env12678 == env12679) = true)

theorem identity12679 : scanCanonicalize (H12AffineFastState.compose env12679 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12679 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env12680 : List Nat := [2,4,8,16,0,17,8,5,512,532,2048,4096,8,4624,0,3,4609,2048,533,1,4112,0,17,2,8,17,2048,4608,4097,2049,533,0,4,0,4625,513]

theorem envBound12680 : H12AffineFastState.Bounded env12680 := by
  intro p hp
  have h : env12680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12679_12680 : H12AffineEnvironment.transform 5 17 env12679 = env12680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12679 == env12680) = true)

theorem identity12680 : scanCanonicalize (H12AffineFastState.compose env12680 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound12680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12681 : List Nat := [2,4,8,16,0,17,8,5,512,532,2048,512,8,16,0,3,1,2048,533,1,528,0,17,2,8,17,2048,0,513,2049,533,0,4,0,17,513]

theorem envBound12681 : H12AffineFastState.Bounded env12681 := by
  intro p hp
  have h : env12681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12680_12681 : H12AffineEnvironment.transform 11 512 env12680 = env12681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env12680 == env12681) = true)

theorem identity12681 : scanCanonicalize (H12AffineFastState.compose env12681 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound12681 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12682 : List Nat := [2,4,8,16,0,17,8,5,16,4,2048,16,8,16,0,3,1,2048,5,1,0,0,17,2,8,17,2048,0,17,2049,5,0,4,0,17,17]

theorem envBound12682 : H12AffineFastState.Bounded env12682 := by
  intro p hp
  have h : env12682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12681_12682 : H12AffineEnvironment.transform 8 16 env12681 = env12682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env12681 == env12682) = true)

theorem identity12682 : scanCanonicalize (H12AffineFastState.compose env12682 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12683 : List Nat := [2,4,8,1,0,0,8,5,1,4,2048,1,8,1,0,3,1,2048,5,1,0,0,0,2,8,0,2048,0,0,2049,5,0,4,0,0,0]

theorem envBound12683 : H12AffineFastState.Bounded env12683 := by
  intro p hp
  have h : env12683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12682_12683 : H12AffineEnvironment.transform 3 1 env12682 = env12683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12682 == env12683) = true)

theorem identity12683 : scanCanonicalize (H12AffineFastState.compose env12683 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12684 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,1,8,1,0,3,1,0,5,1,0,0,0,2,8,0,0,0,0,1,5,0,4,0,0,0]

theorem envBound12684 : H12AffineFastState.Bounded env12684 := by
  intro p hp
  have h : env12684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12683_12684 : H12AffineEnvironment.transform 10 0 env12683 = env12684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12683 == env12684) = true)

def env12685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1025,32769,58516,169,62660,98781,8328,64,122078,57796,17664,89514,61704,33,257,21793,46213,120543]

theorem envBound12685 : H12AffineFastState.Bounded env12685 := by
  intro p hp
  have h : env12685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12670_12685 : H12AffineEnvironment.transform 17 10281 env12670 = env12685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12670 == env12685) = true)

theorem identity12685 : scanCanonicalize (H12AffineFastState.compose env12685 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound12685 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env12686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,82246,10281,1025,8352,17461,169,21605,74108,8328,64,97407,16741,17664,89514,20905,33,257,21793,5156,95870]

theorem envBound12686 : H12AffineFastState.Bounded env12686 := by
  intro p hp
  have h : env12686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12685_12686 : H12AffineEnvironment.transform 14 8353 env12685 = env12686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env12685 == env12686) = true)

theorem identity12686 : scanCanonicalize (H12AffineFastState.compose env12686 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound12686 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8353,65536,70863,10281,1025,8352,4540,169,492,74108,8328,64,76278,5356,4233,67619,1056,33,257,168,5156,74743]

theorem envBound12687 : H12AffineFastState.Bounded env12687 := by
  intro p hp
  have h : env12687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12686_12687 : H12AffineEnvironment.transform 13 5513 env12686 = env12687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env12686 == env12687) = true)

theorem identity12687 : scanCanonicalize (H12AffineFastState.compose env12687 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8353,8202,13509,10281,1025,8352,4540,169,492,374,8328,64,2556,5356,4233,10281,1056,33,257,168,5156,1021]

theorem envBound12688 : H12AffineFastState.Bounded env12688 := by
  intro p hp
  have h : env12688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12687_12688 : H12AffineEnvironment.transform 15 8202 env12687 = env12688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12687 == env12688) = true)

theorem identity12688 : scanCanonicalize (H12AffineFastState.compose env12688 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12688 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,509,342,5529,2421,1025,508,4540,169,492,374,468,64,2556,5356,4233,2421,1056,33,257,168,5156,1021]

theorem envBound12689 : H12AffineFastState.Bounded env12689 := by
  intro p hp
  have h : env12689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12688_12689 : H12AffineEnvironment.transform 12 348 env12688 = env12689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12688 == env12689) = true)

theorem identity12689 : scanCanonicalize (H12AffineFastState.compose env12689 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12689 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,373,342,5393,2421,1025,372,4404,33,356,374,348,64,2420,5220,4097,2421,1056,33,257,32,5156,885]

theorem envBound12690 : H12AffineFastState.Bounded env12690 := by
  intro p hp
  have h : env12690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12689_12690 : H12AffineEnvironment.transform 6 8 env12689 = env12690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12689 == env12690) = true)

theorem identity12690 : scanCanonicalize (H12AffineFastState.compose env12690 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12690 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12691 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4112,373,342,4096,2421,272,372,4404,33,356,374,348,64,2420,4469,4097,2421,305,33,257,32,4405,885]

theorem envBound12691 : H12AffineFastState.Bounded env12691 := by
  intro p hp
  have h : env12691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12690_12691 : H12AffineEnvironment.transform 9 273 env12690 = env12691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12690 == env12691) = true)

theorem identity12691 : scanCanonicalize (H12AffineFastState.compose env12691 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12691 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env12692 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,41,4112,0,35,4096,2048,101,1,4161,33,17,3,41,64,2049,4096,4097,2048,68,33,116,32,4160,512]

theorem envBound12692 : H12AffineFastState.Bounded env12692 := by
  intro p hp
  have h : env12692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12691_12692 : H12AffineEnvironment.transform 7 117 env12691 = env12692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12691 == env12692) = true)

theorem identity12692 : scanCanonicalize (H12AffineFastState.compose env12692 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound12692 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12693 : List Nat := [2,4,8,16,16,64,8,69,512,84,2048,4096,25,4112,0,19,4096,2048,85,1,4161,17,17,3,25,64,2049,4096,4097,2048,68,17,68,16,4160,512]

theorem envBound12693 : H12AffineFastState.Bounded env12693 := by
  intro p hp
  have h : env12693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12692_12693 : H12AffineEnvironment.transform 4 16 env12692 = env12693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env12692 == env12693) = true)

theorem identity12693 : scanCanonicalize (H12AffineFastState.compose env12693 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound12693 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12694 : List Nat := [2,4,8,16,16,64,8,69,512,84,2048,2059,25,2075,0,19,2059,2048,85,1,2122,17,17,3,25,64,2049,2059,2058,2048,68,17,68,16,2123,512]

theorem envBound12694 : H12AffineFastState.Bounded env12694 := by
  intro p hp
  have h : env12694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12693_12694 : H12AffineEnvironment.transform 11 2059 env12693 = env12694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env12693 == env12694) = true)

theorem identity12694 : scanCanonicalize (H12AffineFastState.compose env12694 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound12694 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12695 : List Nat := [2,4,8,16,16,64,8,69,5,84,2048,2059,25,2075,0,19,2059,2048,85,1,2122,17,17,3,25,64,2049,2059,2058,2048,68,17,68,16,2123,5]

theorem envBound12695 : H12AffineFastState.Bounded env12695 := by
  intro p hp
  have h : env12695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12694_12695 : H12AffineEnvironment.transform 8 5 env12694 = env12695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env12694 == env12695) = true)

theorem identity12695 : scanCanonicalize (H12AffineFastState.compose env12695 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound12695 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12696 : List Nat := [2,4,8,16,16,3,8,6,5,23,2048,2059,25,2075,0,19,2059,2048,22,1,2057,17,17,3,25,3,2049,2059,2058,2048,7,17,7,16,2056,5]

theorem envBound12696 : H12AffineFastState.Bounded env12696 := by
  intro p hp
  have h : env12696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12695_12696 : H12AffineEnvironment.transform 5 3 env12695 = env12696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env12695 == env12696) = true)

theorem identity12696 : scanCanonicalize (H12AffineFastState.compose env12696 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12697 : List Nat := [2,4,8,0,0,3,8,6,5,7,2048,2059,9,2059,0,3,2059,2048,6,1,2057,1,1,3,9,3,2049,2059,2058,2048,7,1,7,0,2056,5]

theorem envBound12697 : H12AffineFastState.Bounded env12697 := by
  intro p hp
  have h : env12697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12696_12697 : H12AffineEnvironment.transform 3 0 env12696 = env12697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12696 == env12697) = true)

theorem identity12697 : scanCanonicalize (H12AffineFastState.compose env12697 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12697 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12698 : List Nat := [2,4,3,0,0,3,3,6,5,7,2048,2048,2,2048,0,3,2048,2048,6,1,2050,1,1,3,2,3,2049,2048,2049,2048,7,1,7,0,2051,5]

theorem envBound12698 : H12AffineFastState.Bounded env12698 := by
  intro p hp
  have h : env12698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12697_12698 : H12AffineEnvironment.transform 2 3 env12697 = env12698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12697 == env12698) = true)

def env12699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177099,2098512,17664,2461975,2102684,2411677,257,21793,46213,2175563]

theorem envBound12699 : H12AffineFastState.Bounded env12699 := by
  intro p hp
  have h : env12699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12668_12699 : H12AffineEnvironment.transform 21 272513 env12668 = env12699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12668 == env12699) = true)

theorem identity12699 : scanCanonicalize (H12AffineFastState.compose env12699 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound12699 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82246,262144,1025,29908,2097152,272513,2101328,95496,8328,64,2177099,2098512,17664,2450882,2102684,2373704,257,21793,16464,2175563]

theorem envBound12700 : H12AffineFastState.Bounded env12700 := by
  intro p hp
  have h : env12700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12699_12700 : H12AffineEnvironment.transform 14 29909 env12699 = env12700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env12699 == env12700) = true)

def env12701 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82198,262144,1025,29828,2097152,272513,2101248,95496,8328,16,2177051,2098432,17664,2450834,2102684,2373656,257,21793,16384,2175515]

theorem envBound12701 : H12AffineFastState.Bounded env12701 := by
  intro p hp
  have h : env12701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12700_12701 : H12AffineEnvironment.transform 5 16 env12700 = env12701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12700 == env12701) = true)

theorem identity12701 : scanCanonicalize (H12AffineFastState.compose env12701 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound12701 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12702 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82198,76198,1025,29828,2097152,65831,2101248,95496,8328,16,2177051,2098432,17664,2116660,2102684,2167230,257,21793,16384,2175515]

theorem envBound12702 : H12AffineFastState.Bounded env12702 := by
  intro p hp
  have h : env12702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12701_12702 : H12AffineEnvironment.transform 17 76198 env12701 = env12702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env12701 == env12702) = true)

theorem identity12702 : scanCanonicalize (H12AffineFastState.compose env12702 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12702 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env12703 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,24980,2340,1025,29828,2097152,8613,2101248,21898,8328,16,2103449,2098432,17664,2116660,2102684,2109756,257,21793,16384,2101913]

theorem envBound12703 : H12AffineFastState.Bounded env12703 := by
  intro p hp
  have h : env12703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12702_12703 : H12AffineEnvironment.transform 15 8322 env12702 = env12703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12702 == env12703) = true)

theorem identity12703 : scanCanonicalize (H12AffineFastState.compose env12703 (packedSelected [17,19,26] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound12703 : packedSelected [17,19,26] rootPS < 2^1333 := by decide +kernel

def env12704 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,262,16400,2340,1025,21760,2097152,33,2101248,21898,268,16,2103449,2098432,17664,2116660,2102684,2101432,257,21793,16384,2101913]

theorem envBound12704 : H12AffineFastState.Bounded env12704 := by
  intro p hp
  have h : env12704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12703_12704 : H12AffineEnvironment.transform 12 388 env12703 = env12704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env12703 == env12704) = true)

theorem identity12704 : scanCanonicalize (H12AffineFastState.compose env12704 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound12704 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env12705 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,137,262,5528,2340,1025,136,2097152,33,2101248,2,268,16,2103449,2098432,4232,2103740,2102684,2101432,257,169,5512,2101913]

theorem envBound12705 : H12AffineFastState.Bounded env12705 := by
  intro p hp
  have h : env12705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12704_12705 : H12AffineEnvironment.transform 13 5512 env12704 = env12705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env12704 == env12705) = true)

theorem identity12705 : scanCanonicalize (H12AffineFastState.compose env12705 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4248) := by decide +kernel

theorem selectedBound12705 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12706 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,137,262,5528,2340,1025,136,4248,33,152,2,268,16,2049,5528,4232,2340,1284,32,257,169,5512,513]

theorem envBound12706 : H12AffineFastState.Bounded env12706 := by
  intro p hp
  have h : env12706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12705_12706 : H12AffineEnvironment.transform 20 4248 env12705 = env12706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4248 env12705 == env12706) = true)

theorem identity12706 : scanCanonicalize (H12AffineFastState.compose env12706 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12706 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12707 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1025,0,4112,33,16,2,268,16,2049,5392,4096,2340,1284,32,257,33,5376,513]

theorem envBound12707 : H12AffineFastState.Bounded env12707 := by
  intro p hp
  have h : env12707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12706_12707 : H12AffineEnvironment.transform 6 8 env12706 = env12707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12706 == env12707) = true)

theorem identity12707 : scanCanonicalize (H12AffineFastState.compose env12707 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound12707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12708 : List Nat := [2,4,8,16,32,16,8,20,512,1024,2048,4096,24,5140,1,18,5124,2096,1025,0,4112,33,16,2,24,16,2049,5124,4096,2096,1040,32,21,33,5140,513]

theorem envBound12708 : H12AffineFastState.Bounded env12708 := by
  intro p hp
  have h : env12708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12707_12708 : H12AffineEnvironment.transform 7 20 env12707 = env12708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env12707 == env12708) = true)

theorem identity12708 : scanCanonicalize (H12AffineFastState.compose env12708 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound12708 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12709 : List Nat := [2,4,8,16,32,16,8,20,512,1024,2048,1557,24,513,1,18,529,2096,1025,0,1541,33,16,2,24,16,2049,529,1557,2096,1040,32,21,33,513,513]

theorem envBound12709 : H12AffineFastState.Bounded env12709 := by
  intro p hp
  have h : env12709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12708_12709 : H12AffineEnvironment.transform 11 1557 env12708 = env12709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env12708 == env12709) = true)

theorem identity12709 : scanCanonicalize (H12AffineFastState.compose env12709 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12709 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12710 : List Nat := [2,4,8,16,32,16,8,20,0,1024,2048,1045,24,1,1,18,17,2096,1025,0,1029,33,16,2,24,16,2049,17,1045,2096,1040,32,21,33,1,1]

theorem envBound12710 : H12AffineFastState.Bounded env12710 := by
  intro p hp
  have h : env12710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12709_12710 : H12AffineEnvironment.transform 8 0 env12709 = env12710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12709 == env12710) = true)

theorem identity12710 : scanCanonicalize (H12AffineFastState.compose env12710 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound12710 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12711 : List Nat := [2,4,8,16,32,16,8,20,0,1024,1060,1045,24,1,1,18,17,1044,1025,0,1029,33,16,2,24,16,1061,17,1045,1044,1040,32,21,33,1,1]

theorem envBound12711 : H12AffineFastState.Bounded env12711 := by
  intro p hp
  have h : env12711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12710_12711 : H12AffineEnvironment.transform 10 1060 env12710 = env12711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env12710 == env12711) = true)

theorem identity12711 : scanCanonicalize (H12AffineFastState.compose env12711 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12711 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12712 : List Nat := [2,4,8,16,32,16,8,20,0,52,16,33,24,1,1,18,17,32,53,0,49,33,16,2,24,16,17,17,33,32,36,32,21,33,1,1]

theorem envBound12712 : H12AffineFastState.Bounded env12712 := by
  intro p hp
  have h : env12712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12711_12712 : H12AffineEnvironment.transform 9 52 env12711 = env12712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12711 == env12712) = true)

theorem identity12712 : scanCanonicalize (H12AffineFastState.compose env12712 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12713 : List Nat := [2,4,8,1,32,1,8,5,0,37,1,33,9,1,1,3,0,32,36,0,32,33,1,2,9,1,0,0,33,32,36,32,4,33,1,1]

theorem envBound12713 : H12AffineFastState.Bounded env12713 := by
  intro p hp
  have h : env12713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12712_12713 : H12AffineEnvironment.transform 3 1 env12712 = env12713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12712 == env12713) = true)

theorem identity12713 : scanCanonicalize (H12AffineFastState.compose env12713 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12713 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12714 : List Nat := [2,4,8,1,1,1,8,5,0,4,1,0,9,1,1,3,0,1,5,0,1,0,1,2,9,1,0,0,0,1,5,1,4,0,1,1]

theorem envBound12714 : H12AffineFastState.Bounded env12714 := by
  intro p hp
  have h : env12714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12713_12714 : H12AffineEnvironment.transform 4 1 env12713 = env12714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12713 == env12714) = true)

theorem identity12714 : scanCanonicalize (H12AffineFastState.compose env12714 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12715 : List Nat := [2,4,3,1,1,1,3,5,0,4,1,0,2,1,1,3,0,1,5,0,1,0,1,2,2,1,0,0,0,1,5,1,4,0,1,1]

theorem envBound12715 : H12AffineFastState.Bounded env12715 := by
  intro p hp
  have h : env12715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12714_12715 : H12AffineEnvironment.transform 2 3 env12714 = env12715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12714 == env12715) = true)

def env12716 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,262144,1025,29829,2097152,272513,2101249,95496,8328,17,2177050,2098433,17664,2450835,2102684,2373657,257,21793,16385,2175514]

theorem envBound12716 : H12AffineFastState.Bounded env12716 := by
  intro p hp
  have h : env12716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12700_12716 : H12AffineEnvironment.transform 5 17 env12700 = env12716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12700 == env12716) = true)

theorem identity12716 : scanCanonicalize (H12AffineFastState.compose env12716 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound12716 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12717 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,2477,1025,29829,2097152,8492,2101249,95496,8328,17,2177050,2098433,17664,2190398,2102684,2109876,257,21793,16385,2175514]

theorem envBound12717 : H12AffineFastState.Bounded env12717 := by
  intro p hp
  have h : env12717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12716_12717 : H12AffineEnvironment.transform 17 2477 env12716 = env12717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env12716 == env12717) = true)

theorem identity12717 : scanCanonicalize (H12AffineFastState.compose env12717 (packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound12717 : packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS < 2^1333 := by decide +kernel

def env12718 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,2477,1025,29829,77851,8492,73754,95496,8328,17,2049,79130,17664,23589,75143,65967,257,21793,16385,513]

theorem envBound12718 : H12AffineFastState.Bounded env12718 := by
  intro p hp
  have h : env12718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12717_12718 : H12AffineEnvironment.transform 20 77851 env12717 = env12718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env12717 == env12718) = true)

theorem identity12718 : scanCanonicalize (H12AffineFastState.compose env12718 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12718 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env12719 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,21897,65536,82199,2477,1025,21896,69910,33,65815,87045,389,17,2049,70679,17664,23589,66698,65967,257,21793,16385,513]

theorem envBound12719 : H12AffineFastState.Bounded env12719 := by
  intro p hp
  have h : env12719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12718_12719 : H12AffineEnvironment.transform 12 269 env12718 = env12719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12718 == env12719) = true)

theorem identity12719 : scanCanonicalize (H12AffineFastState.compose env12719 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound12719 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env12720 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,21897,398,16537,2477,1025,21896,4248,33,153,21899,389,17,2049,5529,17664,23589,1284,33,257,21793,16385,513]

theorem envBound12720 : H12AffineFastState.Bounded env12720 := by
  intro p hp
  have h : env12720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12719_12720 : H12AffineEnvironment.transform 15 398 env12719 = env12720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env12719 == env12720) = true)

theorem identity12720 : scanCanonicalize (H12AffineFastState.compose env12720 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12720 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12721 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,136,398,5528,2477,1025,137,4248,33,153,138,389,17,2049,5529,4097,2340,1284,33,257,32,5376,513]

theorem envBound12721 : H12AffineFastState.Bounded env12721 := by
  intro p hp
  have h : env12721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12720_12721 : H12AffineEnvironment.transform 13 5377 env12720 = env12721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12720 == env12721) = true)

theorem identity12721 : scanCanonicalize (H12AffineFastState.compose env12721 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12721 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12722 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,269,4112,136,398,4233,2477,272,137,4248,33,153,138,389,17,2049,4232,4097,2340,21,33,257,32,4113,513]

theorem envBound12722 : H12AffineFastState.Bounded env12722 := by
  intro p hp
  have h : env12722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12721_12722 : H12AffineEnvironment.transform 9 273 env12721 = env12722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12721 == env12722) = true)

theorem identity12722 : scanCanonicalize (H12AffineFastState.compose env12722 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12722 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12723 : List Nat := [2,4,8,16,32,17,128,36,512,53,2048,4096,41,4112,136,170,4233,2185,52,137,4248,33,153,138,161,17,2049,4232,4097,2048,21,33,37,32,4113,513]

theorem envBound12723 : H12AffineFastState.Bounded env12723 := by
  intro p hp
  have h : env12723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12722_12723 : H12AffineEnvironment.transform 7 36 env12722 = env12723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12722 == env12723) = true)

theorem identity12723 : scanCanonicalize (H12AffineFastState.compose env12723 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound12723 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env12724 : List Nat := [2,4,8,16,32,17,128,36,131,53,2048,4096,41,4112,136,170,4233,2185,52,137,4248,33,153,138,161,17,2049,4232,4097,2048,21,33,37,32,4113,130]

theorem envBound12724 : H12AffineFastState.Bounded env12724 := by
  intro p hp
  have h : env12724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12723_12724 : H12AffineEnvironment.transform 8 131 env12723 = env12724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env12723 == env12724) = true)

theorem identity12724 : scanCanonicalize (H12AffineFastState.compose env12724 (packedSelected [0,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound12724 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env12725 : List Nat := [2,4,8,16,32,17,128,36,131,53,2048,137,41,153,136,170,0,2185,52,137,17,33,153,138,161,17,2049,1,136,2048,21,33,37,32,152,130]

theorem envBound12725 : H12AffineFastState.Bounded env12725 := by
  intro p hp
  have h : env12725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12724_12725 : H12AffineEnvironment.transform 11 137 env12724 = env12725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env12724 == env12725) = true)

theorem identity12725 : scanCanonicalize (H12AffineFastState.compose env12725 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound12725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12726 : List Nat := [2,4,8,16,32,17,128,36,131,53,16,137,41,153,136,170,0,153,52,137,17,33,153,138,161,17,17,1,136,16,21,33,37,32,152,130]

theorem envBound12726 : H12AffineFastState.Bounded env12726 := by
  intro p hp
  have h : env12726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12725_12726 : H12AffineEnvironment.transform 10 16 env12725 = env12726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env12725 == env12726) = true)

theorem identity12726 : scanCanonicalize (H12AffineFastState.compose env12726 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12726 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12727 : List Nat := [2,4,3,16,32,17,128,36,131,53,16,130,34,146,131,161,0,146,52,130,17,33,146,129,161,17,17,1,131,16,21,33,37,32,147,130]

theorem envBound12727 : H12AffineFastState.Bounded env12727 := by
  intro p hp
  have h : env12727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12726_12727 : H12AffineEnvironment.transform 2 3 env12726 = env12727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12726 == env12727) = true)

theorem identity12727 : scanCanonicalize (H12AffineFastState.compose env12727 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound12727 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env12728 : List Nat := [2,4,3,16,32,17,2,36,1,53,16,0,34,16,1,35,0,16,52,0,17,33,16,3,35,17,17,1,1,16,21,33,37,32,17,0]

theorem envBound12728 : H12AffineFastState.Bounded env12728 := by
  intro p hp
  have h : env12728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12727_12728 : H12AffineEnvironment.transform 6 2 env12727 = env12728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env12727 == env12728) = true)

theorem identity12728 : scanCanonicalize (H12AffineFastState.compose env12728 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12729 : List Nat := [2,4,3,1,32,0,2,36,1,36,1,0,34,1,1,35,0,1,37,0,0,33,1,3,35,0,0,1,1,1,4,33,37,32,0,0]

theorem envBound12729 : H12AffineFastState.Bounded env12729 := by
  intro p hp
  have h : env12729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12728_12729 : H12AffineEnvironment.transform 3 1 env12728 = env12729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12728 == env12729) = true)

theorem identity12729 : scanCanonicalize (H12AffineFastState.compose env12729 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12729 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12730 : List Nat := [2,4,3,1,1,0,2,5,1,5,1,0,3,1,1,2,0,1,4,0,0,0,1,3,2,0,0,1,1,1,4,0,4,1,0,0]

theorem envBound12730 : H12AffineFastState.Bounded env12730 := by
  intro p hp
  have h : env12730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12729_12730 : H12AffineEnvironment.transform 4 1 env12729 = env12730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12729 == env12730) = true)

def env12731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623434,2098513,17665,2461974,2102684,6349853,257,21793,46213,2175563]

theorem envBound12731 : H12AffineFastState.Bounded env12731 := by
  intro p hp
  have h : env12731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12667_12731 : H12AffineEnvironment.transform 22 2101329 env12667 = env12731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env12667 == env12731) = true)

def env12732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177098,2098513,17665,2461974,2102684,2411677,257,21793,46213,2175563]

theorem envBound12732 : H12AffineFastState.Bounded env12732 := by
  intro p hp
  have h : env12732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12731_12732 : H12AffineEnvironment.transform 21 272512 env12731 = env12732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12731 == env12732) = true)

theorem identity12732 : scanCanonicalize (H12AffineFastState.compose env12732 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound12732 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4160,272512,17,98780,8328,64,75786,5393,17665,360790,1500,318685,257,21793,46213,74251]

theorem envBound12733 : H12AffineFastState.Bounded env12733 := by
  intro p hp
  have h : env12733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12732_12733 : H12AffineEnvironment.transform 20 4160 env12732 = env12733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12732 == env12733) = true)

theorem identity12733 : scanCanonicalize (H12AffineFastState.compose env12733 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12733 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env12734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,4160,272512,17,41430,8328,64,2048,5393,17665,303452,1500,318685,257,21793,46213,513]

theorem envBound12734 : H12AffineFastState.Bounded env12734 := by
  intro p hp
  have h : env12734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12733_12734 : H12AffineEnvironment.transform 15 8202 env12733 = env12734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12733 == env12734) = true)

theorem identity12734 : scanCanonicalize (H12AffineFastState.compose env12734 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound12734 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env12735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,35324,1025,32769,4160,41340,17,41430,8328,64,2048,5393,17665,10400,1500,21793,257,21793,46213,513]

theorem envBound12735 : H12AffineFastState.Bounded env12735 := by
  intro p hp
  have h : env12735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12734_12735 : H12AffineEnvironment.transform 17 35324 env12734 = env12735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env12734 == env12735) = true)

theorem identity12735 : scanCanonicalize (H12AffineFastState.compose env12735 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12735 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env12736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16401,35324,1025,32769,4160,32801,17,32907,469,64,2048,5393,17665,2557,1500,21793,257,21793,38360,513]

theorem envBound12736 : H12AffineFastState.Bounded env12736 := by
  intro p hp
  have h : env12736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12735_12736 : H12AffineEnvironment.transform 12 349 env12735 = env12736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12735 == env12736) = true)

theorem identity12736 : scanCanonicalize (H12AffineFastState.compose env12736 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12736 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,32768,343,5392,35324,1025,32769,4160,32801,17,32907,469,64,2048,5393,4096,2557,1500,32,257,32,38360,513]

theorem envBound12737 : H12AffineFastState.Bounded env12737 := by
  intro p hp
  have h : env12737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12736_12737 : H12AffineEnvironment.transform 13 5377 env12736 = env12737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12736 == env12737) = true)

theorem identity12737 : scanCanonicalize (H12AffineFastState.compose env12737 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12737 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env12738 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5237,32768,35,5220,34952,1025,32769,4160,32801,17,32907,161,64,2048,5221,4096,2185,1192,32,117,32,38060,513]

theorem envBound12738 : H12AffineFastState.Bounded env12738 := by
  intro p hp
  have h : env12738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12737_12738 : H12AffineEnvironment.transform 7 116 env12737 = env12738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12737 == env12738) = true)

theorem identity12738 : scanCanonicalize (H12AffineFastState.compose env12738 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12738 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12739 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,32768,35,5220,34816,1025,32769,4160,32801,17,32771,41,64,2048,5221,4096,2049,1056,32,117,32,37924,513]

theorem envBound12739 : H12AffineFastState.Bounded env12739 := by
  intro p hp
  have h : env12739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12738_12739 : H12AffineEnvironment.transform 6 8 env12738 = env12739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12738 == env12739) = true)

theorem identity12739 : scanCanonicalize (H12AffineFastState.compose env12739 (packedSelected [3,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound12739 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env12740 : List Nat := [2,4,8,16,32,64,8,116,512,63,2048,4096,41,4170,32768,35,4187,34816,62,32769,4160,32801,17,32771,41,64,2048,4186,4096,2049,31,32,117,32,36891,513]

theorem envBound12740 : H12AffineFastState.Bounded env12740 := by
  intro p hp
  have h : env12740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12739_12740 : H12AffineEnvironment.transform 9 63 env12739 = env12740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env12739 == env12740) = true)

theorem identity12740 : scanCanonicalize (H12AffineFastState.compose env12740 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound12740 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12741 : List Nat := [2,4,8,16,32,64,8,116,512,63,81,4096,41,4170,32768,35,4187,32849,62,32769,4160,32801,17,32771,41,64,81,4186,4096,80,31,32,117,32,36891,513]

theorem envBound12741 : H12AffineFastState.Bounded env12741 := by
  intro p hp
  have h : env12741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12740_12741 : H12AffineEnvironment.transform 10 81 env12740 = env12741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env12740 == env12741) = true)

theorem identity12741 : scanCanonicalize (H12AffineFastState.compose env12741 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound12741 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env12742 : List Nat := [2,4,8,16,10,64,8,94,512,21,81,4096,3,4170,32768,9,4187,32849,20,32769,4160,32779,17,32771,3,64,81,4186,4096,80,31,10,95,10,36891,513]

theorem envBound12742 : H12AffineFastState.Bounded env12742 := by
  intro p hp
  have h : env12742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12741_12742 : H12AffineEnvironment.transform 4 10 env12741 = env12742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env12741 == env12742) = true)

theorem identity12742 : scanCanonicalize (H12AffineFastState.compose env12742 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12742 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env12743 : List Nat := [2,4,8,16,10,16,8,14,512,21,1,4096,3,4122,32768,9,4107,32769,20,32769,4112,32779,17,32771,3,16,1,4106,4096,0,31,10,15,10,36891,513]

theorem envBound12743 : H12AffineFastState.Bounded env12743 := by
  intro p hp
  have h : env12743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12742_12743 : H12AffineEnvironment.transform 5 16 env12742 = env12743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12742 == env12743) = true)

theorem identity12743 : scanCanonicalize (H12AffineFastState.compose env12743 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 27) := by decide +kernel

theorem selectedBound12743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12744 : List Nat := [2,4,8,16,10,16,8,14,512,21,1,4096,3,4122,27,9,4107,26,20,26,4112,16,17,24,3,16,1,4106,4096,0,31,10,15,10,4096,513]

theorem envBound12744 : H12AffineFastState.Bounded env12744 := by
  intro p hp
  have h : env12744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12743_12744 : H12AffineEnvironment.transform 14 27 env12743 = env12744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27 env12743 == env12744) = true)

theorem identity12744 : scanCanonicalize (H12AffineFastState.compose env12744 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound12744 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env12745 : List Nat := [2,4,8,16,10,16,8,14,512,21,1,10,3,16,27,9,1,26,20,26,26,16,17,24,3,16,1,0,10,0,31,10,15,10,10,513]

theorem envBound12745 : H12AffineFastState.Bounded env12745 := by
  intro p hp
  have h : env12745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12744_12745 : H12AffineEnvironment.transform 11 10 env12744 = env12745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env12744 == env12745) = true)

def env12746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177099,2098513,17665,2461974,2102684,2411676,257,21793,46213,2175563]

theorem envBound12746 : H12AffineFastState.Bounded env12746 := by
  intro p hp
  have h : env12746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12731_12746 : H12AffineEnvironment.transform 21 272513 env12731 = env12746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12731 == env12746) = true)

def env12747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272393,2101329,98644,8192,64,2177099,2098513,17665,2461974,2102548,2411540,257,21793,46093,2175563]

theorem envBound12747 : H12AffineFastState.Bounded env12747 := by
  intro p hp
  have h : env12747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12746_12747 : H12AffineEnvironment.transform 6 8 env12746 = env12747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12746 == env12747) = true)

theorem identity12747 : scanCanonicalize (H12AffineFastState.compose env12747 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound12747 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272393,73755,98644,8192,64,2049,79131,17665,303452,75102,392286,257,21793,46093,513]

theorem envBound12748 : H12AffineFastState.Bounded env12748 := by
  intro p hp
  have h : env12748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12747_12748 : H12AffineEnvironment.transform 20 77898 env12747 = env12748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env12747 == env12748) = true)

theorem identity12748 : scanCanonicalize (H12AffineFastState.compose env12748 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound12748 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env12749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67618,1025,32769,77898,73771,73755,98644,8192,64,2049,79131,17665,108926,75102,62588,257,21793,46093,513]

theorem envBound12749 : H12AffineFastState.Bounded env12749 := by
  intro p hp
  have h : env12749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12748_12749 : H12AffineEnvironment.transform 17 67618 env12748 = env12749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env12748 == env12749) = true)

theorem identity12749 : scanCanonicalize (H12AffineFastState.compose env12749 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12749 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env12750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,82246,67618,1025,8460,77898,73771,73755,73817,8192,64,2049,79131,17665,67699,75102,21873,257,21793,5376,513]

theorem envBound12750 : H12AffineFastState.Bounded env12750 := by
  intro p hp
  have h : env12750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12749_12750 : H12AffineEnvironment.transform 14 8461 env12749 = env12750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12749 == env12750) = true)

theorem identity12750 : scanCanonicalize (H12AffineFastState.compose env12750 (packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound12750 : packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS < 2^1333 := by decide +kernel

def env12751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21511,5441,23589,1025,8460,25677,29740,29724,29790,8192,64,2049,24860,17665,23668,29017,21873,257,21793,5376,513]

theorem envBound12751 : H12AffineFastState.Bounded env12751 := by
  intro p hp
  have h : env12751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12750_12751 : H12AffineEnvironment.transform 15 21511 env12750 = env12751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env12750 == env12751) = true)

theorem identity12751 : scanCanonicalize (H12AffineFastState.compose env12751 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,263,5441,2341,1025,8460,12621,8492,8476,8542,8192,64,2049,13340,4097,2420,9305,113,257,33,5376,513]

theorem envBound12752 : H12AffineFastState.Bounded env12752 := by
  intro p hp
  have h : env12752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12751_12752 : H12AffineEnvironment.transform 13 5376 env12751 = env12752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12751 == env12752) = true)

theorem identity12752 : scanCanonicalize (H12AffineFastState.compose env12752 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12752 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12753 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,263,5393,2341,1025,8460,12573,8492,8476,8462,8192,16,2049,13340,4097,2340,9225,33,257,33,5376,513]

theorem envBound12753 : H12AffineFastState.Bounded env12753 := by
  intro p hp
  have h : env12753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12752_12753 : H12AffineEnvironment.transform 5 16 env12752 = env12753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12752 == env12753) = true)

theorem identity12753 : scanCanonicalize (H12AffineFastState.compose env12753 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound12753 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env12754 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1060,8192,292,8461,263,309,2341,1025,8460,9529,8492,8476,8462,8192,16,2049,8248,1061,2340,9225,33,257,33,292,513]

theorem envBound12754 : H12AffineFastState.Bounded env12754 := by
  intro p hp
  have h : env12754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12753_12754 : H12AffineEnvironment.transform 11 1060 env12753 = env12754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env12753 == env12754) = true)

theorem identity12754 : scanCanonicalize (H12AffineFastState.compose env12754 (packedSelected [1,2,3,5,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound12754 : packedSelected [1,2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env12755 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1060,2316,292,2049,263,309,2341,1025,2048,3125,2080,2064,2050,2316,16,2049,2356,1061,2340,3333,33,257,33,292,513]

theorem envBound12755 : H12AffineFastState.Bounded env12755 := by
  intro p hp
  have h : env12755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12754_12755 : H12AffineEnvironment.transform 12 2316 env12754 = env12755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env12754 == env12755) = true)

theorem identity12755 : scanCanonicalize (H12AffineFastState.compose env12755 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12755 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12756 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1060,268,292,1,263,309,293,1025,0,1077,32,16,2,268,16,1,308,1061,292,1285,33,257,33,292,513]

theorem envBound12756 : H12AffineFastState.Bounded env12756 := by
  intro p hp
  have h : env12756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12755_12756 : H12AffineEnvironment.transform 10 0 env12755 = env12756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12755 == env12756) = true)

theorem identity12756 : scanCanonicalize (H12AffineFastState.compose env12756 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12756 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12757 : List Nat := [2,4,8,16,32,16,8,256,512,52,0,16,268,292,1,263,309,293,53,0,1,32,16,2,268,16,1,308,17,292,305,33,257,33,292,513]

theorem envBound12757 : H12AffineFastState.Bounded env12757 := by
  intro p hp
  have h : env12757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12756_12757 : H12AffineEnvironment.transform 9 52 env12756 = env12757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12756 == env12757) = true)

def env12758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272392,2101329,98645,8193,64,2177099,2098513,17665,2461974,2102549,2411541,257,21793,46092,2175563]

theorem envBound12758 : H12AffineFastState.Bounded env12758 := by
  intro p hp
  have h : env12758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12746_12758 : H12AffineEnvironment.transform 6 9 env12746 = env12758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12746 == env12758) = true)

theorem identity12758 : scanCanonicalize (H12AffineFastState.compose env12758 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound12758 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12759 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,343,16401,262144,1025,32769,2097152,272392,2101329,32770,8193,64,2111772,2098513,17665,2396225,2102549,2411541,257,21793,46092,2110236]

theorem envBound12759 : H12AffineFastState.Bounded env12759 := by
  intro p hp
  have h : env12759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12758_12759 : H12AffineEnvironment.transform 15 343 env12758 = env12759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env12758 == env12759) = true)

theorem identity12759 : scanCanonicalize (H12AffineFastState.compose env12759 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound12759 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12760 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,343,16401,35188,1025,32769,2097152,41340,2101329,32770,8193,64,2111772,2098513,17665,2103605,2102549,2114913,257,21793,46092,2110236]

theorem envBound12760 : H12AffineFastState.Bounded env12760 := by
  intro p hp
  have h : env12760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12759_12760 : H12AffineEnvironment.transform 17 35188 env12759 = env12760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env12759 == env12760) = true)

theorem identity12760 : scanCanonicalize (H12AffineFastState.compose env12760 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound12760 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env12761 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,32768,343,5173,35188,1025,32769,2097152,41340,2101329,32770,8193,64,2111772,2098513,4389,2103605,2102549,2101573,257,261,46092,2110236]

theorem envBound12761 : H12AffineFastState.Bounded env12761 := by
  intro p hp
  have h : env12761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12760_12761 : H12AffineEnvironment.transform 13 5156 env12760 = env12761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env12760 == env12761) = true)

theorem identity12761 : scanCanonicalize (H12AffineFastState.compose env12761 (packedSelected [0,1,7,8,9,12,14,15,16,19,22] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound12761 : packedSelected [0,1,7,8,9,12,14,15,16,19,22] rootPS < 2^1333 := by decide +kernel

def env12762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,32768,343,5173,35188,1025,32769,4161,41340,16,32770,8193,64,10589,5392,4389,2420,1364,260,257,261,46092,9053]

theorem envBound12762 : H12AffineFastState.Bounded env12762 := by
  intro p hp
  have h : env12762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12761_12762 : H12AffineEnvironment.transform 20 4161 env12761 = env12762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12761 == env12762) = true)

theorem identity12762 : scanCanonicalize (H12AffineFastState.compose env12762 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12762 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env12763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8541,343,5173,10281,1025,8540,4161,33,16,8543,8193,64,10589,5392,4389,2420,1364,260,257,261,5457,9053]

theorem envBound12763 : H12AffineFastState.Bounded env12763 := by
  intro p hp
  have h : env12763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12762_12763 : H12AffineEnvironment.transform 14 8541 env12762 = env12763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12762 == env12763) = true)

theorem identity12763 : scanCanonicalize (H12AffineFastState.compose env12763 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12763 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env12764 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4404,8541,343,4389,10281,273,8540,4161,33,16,8543,8193,64,10589,4096,4389,2420,68,260,257,261,4161,9053]

theorem envBound12764 : H12AffineFastState.Bounded env12764 := by
  intro p hp
  have h : env12764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12763_12764 : H12AffineEnvironment.transform 9 272 env12763 = env12764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12763 == env12764) = true)

theorem identity12764 : scanCanonicalize (H12AffineFastState.compose env12764 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound12764 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12765 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,121,4404,292,343,4389,2128,273,293,4161,33,16,294,120,64,2340,4096,4389,2420,68,260,257,261,4161,804]

theorem envBound12765 : H12AffineFastState.Bounded env12765 := by
  intro p hp
  have h : env12765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12764_12765 : H12AffineEnvironment.transform 12 121 env12764 = env12765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env12764 == env12765) = true)

def env12766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound12766 : H12AffineFastState.Bounded env12766 := by
  intro p hp
  have h : env12766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12479_12766 : H12AffineEnvironment.transform 26 30393345 env12479 = env12766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env12479 == env12766) = true)

def env12767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound12767 : H12AffineFastState.Bounded env12767 := by
  intro p hp
  have h : env12767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12766_12767 : H12AffineEnvironment.transform 18 1024 env12766 = env12767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12766 == env12767) = true)

theorem identity12767 : scanCanonicalize (H12AffineFastState.compose env12767 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2212870) := by decide +kernel

theorem selectedBound12767 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2212870,16777216,8328,64,23462919,18973836,102742,2556935,18890775,23160256,256,16777386,16834830,18966465]

theorem envBound12768 : H12AffineFastState.Bounded env12768 := by
  intro p hp
  have h : env12768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12767_12768 : H12AffineEnvironment.transform 22 2212870 env12767 = env12768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2212870 env12767 == env12768) = true)

def env12769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,16777216,8328,64,17227835,18973836,102742,2556935,18890775,16876028,256,16777386,16834830,18966465]

theorem envBound12769 : H12AffineFastState.Bounded env12769 := by
  intro p hp
  have h : env12769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12768_12769 : H12AffineEnvironment.transform 21 2155580 env12768 = env12769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env12768 == env12769) = true)

def env12770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,16777216,8192,64,17227835,18973700,102742,2556935,18890775,16875892,256,16777250,16834830,18966345]

theorem envBound12770 : H12AffineFastState.Bounded env12770 := by
  intro p hp
  have h : env12770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12769_12770 : H12AffineEnvironment.transform 6 8 env12769 = env12770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12769 == env12770) = true)

theorem identity12770 : scanCanonicalize (H12AffineFastState.compose env12770 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound12770 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,41310,8192,64,409957,2172250,102742,2556935,2154825,73770,256,41340,16464,2213399]

theorem envBound12771 : H12AffineFastState.Bounded env12771 := by
  intro p hp
  have h : env12771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12770_12771 : H12AffineEnvironment.transform 23 41310 env12770 = env12771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env12770 == env12771) = true)

def env12772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,62588,119878,41310,8192,64,409957,79130,102742,463943,61705,73770,256,41340,16464,120407]

theorem envBound12772 : H12AffineFastState.Bounded env12772 := by
  intro p hp
  have h : env12772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12771_12772 : H12AffineEnvironment.transform 20 4160 env12771 = env12772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12771 == env12772) = true)

theorem identity12772 : scanCanonicalize (H12AffineFastState.compose env12772 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound12772 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,62588,16,41310,8192,64,409957,57676,17664,442385,61705,62588,256,41340,16464,513]

theorem envBound12773 : H12AffineFastState.Bounded env12773 := by
  intro p hp
  have h : env12773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12772_12773 : H12AffineEnvironment.transform 15 54358 env12772 = env12773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env12772 == env12773) = true)

def env12774 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,62508,16,41230,8192,16,409909,57628,17664,442385,61705,62508,256,41260,16384,513]

theorem envBound12774 : H12AffineFastState.Bounded env12774 := by
  intro p hp
  have h : env12774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12773_12774 : H12AffineEnvironment.transform 5 16 env12773 = env12774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12773 == env12774) = true)

theorem identity12774 : scanCanonicalize (H12AffineFastState.compose env12774 (packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound12774 : packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS < 2^1333 := by decide +kernel

def env12775 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,262144,1024,32769,4112,62508,16,41230,8192,16,316452,57628,17664,283904,61705,62508,256,41260,16384,513]

theorem envBound12775 : H12AffineFastState.Bounded env12775 := by
  intro p hp
  have h : env12775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12774_12775 : H12AffineEnvironment.transform 16 38161 env12774 = env12775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env12774 == env12775) = true)

theorem identity12775 : scanCanonicalize (H12AffineFastState.compose env12775 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12775 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12776 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,10280,1024,32769,4112,62508,16,41230,8192,16,64524,57628,17664,32040,61705,62508,256,41260,16384,513]

theorem envBound12776 : H12AffineFastState.Bounded env12776 := by
  intro p hp
  have h : env12776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12775_12776 : H12AffineEnvironment.transform 17 10280 env12775 = env12776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12775 == env12776) = true)

theorem identity12776 : scanCanonicalize (H12AffineFastState.compose env12776 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12776 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env12777 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,29963,13340,10280,1024,8460,4112,21793,16,3,8192,16,23809,16401,17664,32040,20484,21793,256,33,16384,513]

theorem envBound12777 : H12AffineFastState.Bounded env12777 := by
  intro p hp
  have h : env12777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12776_12777 : H12AffineEnvironment.transform 14 8461 env12776 = env12777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12776 == env12777) = true)

theorem identity12777 : scanCanonicalize (H12AffineFastState.compose env12777 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12777 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12778 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8202,13340,10280,1024,8460,4112,32,16,3,8192,16,2048,5392,4097,10281,1285,32,256,33,5377,513]

theorem envBound12778 : H12AffineFastState.Bounded env12778 := by
  intro p hp
  have h : env12778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12777_12778 : H12AffineEnvironment.transform 13 5377 env12777 = env12778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12777 == env12778) = true)

theorem identity12778 : scanCanonicalize (H12AffineFastState.compose env12778 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12778 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12779 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1024,1,4112,32,16,3,269,16,2048,5392,4097,2340,1285,32,256,33,5377,513]

theorem envBound12779 : H12AffineFastState.Bounded env12779 := by
  intro p hp
  have h : env12779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12778_12779 : H12AffineEnvironment.transform 12 269 env12778 = env12779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12778 == env12779) = true)

end H12CloudChart0