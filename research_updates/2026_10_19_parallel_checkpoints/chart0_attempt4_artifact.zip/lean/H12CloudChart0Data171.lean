import H12CloudChart0Data170

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans43329_43330 : H12AffineEnvironment.transform 6 121 env43329 = env43330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env43329 == env43330) = true)

theorem identity43330 : scanCanonicalize (H12AffineFastState.compose env43330 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43330 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43331 : List Nat := [2,4,8,16,32,17,40,36,512,1024,545,4096,8,5156,1,2,5173,545,1024,0,4113,33,17,2,40,16,513,5172,4097,545,1024,0,36,32,5156,512]

theorem envBound43331 : H12AffineFastState.Bounded env43331 := by
  intro p hp
  have h : env43331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43330_43331 : H12AffineEnvironment.transform 5 17 env43330 = env43331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43330 == env43331) = true)

theorem identity43331 : scanCanonicalize (H12AffineFastState.compose env43331 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound43331 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43332 : List Nat := [2,4,8,16,32,17,40,36,512,564,545,4096,8,4624,1,2,4609,545,564,0,4113,33,17,2,40,16,513,4608,4097,545,564,0,36,32,4624,512]

theorem envBound43332 : H12AffineFastState.Bounded env43332 := by
  intro p hp
  have h : env43332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43331_43332 : H12AffineEnvironment.transform 9 564 env43331 = env43332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env43331 == env43332) = true)

theorem identity43332 : scanCanonicalize (H12AffineFastState.compose env43332 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound43332 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43333 : List Nat := [2,4,8,16,32,17,40,36,512,564,545,529,8,1,1,2,16,545,564,0,512,33,17,2,40,16,513,17,528,545,564,0,36,32,1,512]

theorem envBound43333 : H12AffineFastState.Bounded env43333 := by
  intro p hp
  have h : env43333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43332_43333 : H12AffineEnvironment.transform 11 529 env43332 = env43333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env43332 == env43333) = true)

theorem identity43333 : scanCanonicalize (H12AffineFastState.compose env43333 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound43333 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43334 : List Nat := [2,4,8,16,32,17,40,36,48,4,17,33,8,1,1,2,16,17,4,0,48,33,17,2,40,16,49,17,32,17,4,0,36,32,1,48]

theorem envBound43334 : H12AffineFastState.Bounded env43334 := by
  intro p hp
  have h : env43334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43333_43334 : H12AffineEnvironment.transform 8 48 env43333 = env43334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env43333 == env43334) = true)

theorem identity43334 : scanCanonicalize (H12AffineFastState.compose env43334 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43334 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43335 : List Nat := [2,4,8,16,1,17,9,5,17,4,17,0,8,1,1,2,16,17,4,0,17,0,17,2,9,16,16,17,1,17,4,0,5,1,1,17]

theorem envBound43335 : H12AffineFastState.Bounded env43335 := by
  intro p hp
  have h : env43335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43334_43335 : H12AffineEnvironment.transform 4 1 env43334 = env43335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43334 == env43335) = true)

def env43336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,156133,120014,16777216,8328,65,16959642,16880845,102879,108926,16797918,16979045,256,16777250,16834951,16873225]

theorem envBound43336 : H12AffineFastState.Bounded env43336 := by
  intro p hp
  have h : env43336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43293_43336 : H12AffineEnvironment.transform 17 179633 env43293 = env43336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env43293 == env43336) = true)

theorem identity43336 : scanCanonicalize (H12AffineFastState.compose env43336 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound43336 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,156133,120014,95496,8328,65,245138,57797,102879,108926,75222,156013,256,95530,103567,513]

theorem envBound43337 : H12AffineFastState.Bounded env43337 := by
  intro p hp
  have h : env43337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43336_43337 : H12AffineEnvironment.transform 23 95496 env43336 = env43337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env43336 == env43337) = true)

def env43338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156013,119878,95496,8192,65,245018,57677,102743,108926,75102,156013,256,95530,103431,513]

theorem envBound43338 : H12AffineFastState.Bounded env43338 := by
  intro p hp
  have h : env43338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43337_43338 : H12AffineEnvironment.transform 6 8 env43337 = env43338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43337 == env43338) = true)

theorem identity43338 : scanCanonicalize (H12AffineFastState.compose env43338 (packedSelected [1,4,8,9,12,14,16,17,19,38] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound43338 : packedSelected [1,4,8,9,12,14,16,17,19,38] rootPS < 2^1333 := by decide +kernel

def env43339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138340,1024,8540,4161,156013,95515,95496,8192,65,203847,16400,77834,67619,75102,156013,256,95530,79194,513]

theorem envBound43339 : H12AffineFastState.Bounded env43339 := by
  intro p hp
  have h : env43339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43338_43339 : H12AffineEnvironment.transform 14 8541 env43338 = env43339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env43338 == env43339) = true)

theorem identity43339 : scanCanonicalize (H12AffineFastState.compose env43339 (packedSelected [0,4,7,8,9,10,12,14,15,16,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound43339 : packedSelected [0,4,7,8,9,10,12,14,15,16,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env43340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21591,131072,138340,1024,8540,4161,156013,8524,8543,8192,65,149520,16400,25693,23668,28937,156013,256,8573,24845,513]

theorem envBound43340 : H12AffineFastState.Bounded env43340 := by
  intro p hp
  have h : env43340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43339_43340 : H12AffineEnvironment.transform 15 21591 env43339 = env43340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env43339 == env43340) = true)

theorem identity43340 : scanCanonicalize (H12AffineFastState.compose env43340 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound43340 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env43341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21591,13389,10281,1024,8540,4161,21792,8524,8543,8192,65,31837,16400,25693,23668,28937,21792,256,8573,24845,513]

theorem envBound43341 : H12AffineFastState.Bounded env43341 := by
  intro p hp
  have h : env43341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43340_43341 : H12AffineEnvironment.transform 16 13389 env43340 = env43341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env43340 == env43341) = true)

theorem identity43341 : scanCanonicalize (H12AffineFastState.compose env43341 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43341 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21591,5393,2421,1024,0,4161,21792,16,3,348,65,23809,16400,17665,23668,20565,21792,256,33,16465,513]

theorem envBound43342 : H12AffineFastState.Bounded env43342 := by
  intro p hp
  have h : env43342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43341_43342 : H12AffineEnvironment.transform 12 348 env43341 = env43342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43341 == env43342) = true)

def env43343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,119879,95496,8193,65,245019,57676,102742,108926,75103,156013,256,95530,103430,513]

theorem envBound43343 : H12AffineFastState.Bounded env43343 := by
  intro p hp
  have h : env43343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43337_43343 : H12AffineEnvironment.transform 6 9 env43337 = env43343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43337 == env43343) = true)

theorem identity43343 : scanCanonicalize (H12AffineFastState.compose env43343 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound43343 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4161,65910,119879,95496,8193,65,56577,57676,102742,108926,75103,65911,256,95530,103430,513]

theorem envBound43344 : H12AffineFastState.Bounded env43344 := by
  intro p hp
  have h : env43344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43343_43344 : H12AffineEnvironment.transform 16 90138 env43343 = env43344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env43343 == env43344) = true)

theorem identity43344 : scanCanonicalize (H12AffineFastState.compose env43344 (packedSelected [0,1,3,4,8,9,10,11,12,15,18,20,23,24,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 61806) := by decide +kernel

theorem selectedBound43344 : packedSelected [0,1,3,4,8,9,10,11,12,15,18,20,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env43345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,61806,37236,11340,1024,32769,4161,61464,9513,33894,8193,65,56577,57676,24632,22544,54321,61465,256,33860,25960,513]

theorem envBound43345 : H12AffineFastState.Bounded env43345 := by
  intro p hp
  have h : env43345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43344_43345 : H12AffineEnvironment.transform 15 61806 env43344 = env43345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61806 env43344 == env43345) = true)

theorem identity43345 : scanCanonicalize (H12AffineFastState.compose env43345 (packedSelected [1,2,5,6,7,8,11,12,14,15,20,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound43345 : packedSelected [1,2,5,6,7,8,11,12,14,15,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env43346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,28990,4388,11340,1024,81,4161,28744,9513,1078,8193,65,23889,24860,24632,22544,21601,28745,256,1044,25960,513]

theorem envBound43346 : H12AffineFastState.Bounded env43346 := by
  intro p hp
  have h : env43346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43345_43346 : H12AffineEnvironment.transform 14 80 env43345 = env43346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env43345 == env43346) = true)

theorem identity43346 : scanCanonicalize (H12AffineFastState.compose env43346 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound43346 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env43347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,80,9327,4388,11340,1024,81,4161,9497,9513,1078,8193,65,2048,13389,13673,3393,304,9496,256,1044,12345,513]

theorem envBound43347 : H12AffineFastState.Bounded env43347 := by
  intro p hp
  have h : env43347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43346_43347 : H12AffineEnvironment.transform 13 5457 env43346 = env43347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env43346 == env43347) = true)

theorem identity43347 : scanCanonicalize (H12AffineFastState.compose env43347 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43347 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,0,9279,4388,11292,1024,1,4113,9497,9513,1078,8193,17,2048,13341,13625,3345,304,9496,256,1044,12345,513]

theorem envBound43348 : H12AffineFastState.Bounded env43348 := by
  intro p hp
  have h : env43348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43347_43348 : H12AffineEnvironment.transform 5 16 env43347 = env43348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43347 == env43348) = true)

theorem identity43348 : scanCanonicalize (H12AffineFastState.compose env43348 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound43348 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43349 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5377,0,1046,4388,3125,1024,1,4113,1328,1280,1078,40,17,2048,5172,5392,3345,304,1329,256,1044,4112,513]

theorem envBound43349 : H12AffineFastState.Bounded env43349 := by
  intro p hp
  have h : env43349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43348_43349 : H12AffineEnvironment.transform 12 41 env43348 = env43349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env43348 == env43349) = true)

theorem identity43349 : scanCanonicalize (H12AffineFastState.compose env43349 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43349 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43350 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,41,4113,0,262,4388,2341,272,1,4113,32,16,294,40,17,2048,4388,4096,2049,304,33,256,260,4112,513]

theorem envBound43350 : H12AffineFastState.Bounded env43350 := by
  intro p hp
  have h : env43350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43349_43350 : H12AffineEnvironment.transform 9 272 env43349 = env43350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43349 == env43350) = true)

theorem identity43350 : scanCanonicalize (H12AffineFastState.compose env43350 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound43350 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43351 : List Nat := [2,4,8,16,32,16,9,256,512,272,821,4096,41,4113,0,262,4388,528,272,1,4113,32,16,294,40,17,821,4388,4096,820,304,33,256,260,4112,513]

theorem envBound43351 : H12AffineFastState.Bounded env43351 := by
  intro p hp
  have h : env43351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43350_43351 : H12AffineEnvironment.transform 10 821 env43350 = env43351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env43350 == env43351) = true)

theorem identity43351 : scanCanonicalize (H12AffineFastState.compose env43351 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound43351 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env43352 : List Nat := [2,4,8,16,32,16,9,256,512,272,821,513,41,528,0,262,805,528,272,1,528,32,16,294,40,17,821,805,513,820,304,33,256,260,529,513]

theorem envBound43352 : H12AffineFastState.Bounded env43352 := by
  intro p hp
  have h : env43352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43351_43352 : H12AffineEnvironment.transform 11 513 env43351 = env43352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env43351 == env43352) = true)

theorem identity43352 : scanCanonicalize (H12AffineFastState.compose env43352 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43352 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43353 : List Nat := [2,4,8,16,0,16,9,256,512,272,789,513,9,528,0,262,773,528,272,1,528,0,16,262,8,17,789,773,513,788,272,1,256,260,529,513]

theorem envBound43353 : H12AffineFastState.Bounded env43353 := by
  intro p hp
  have h : env43353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43352_43353 : H12AffineEnvironment.transform 4 0 env43352 = env43353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43352 == env43353) = true)

theorem identity43353 : scanCanonicalize (H12AffineFastState.compose env43353 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound43353 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43354 : List Nat := [2,4,8,16,0,16,9,256,276,272,1,277,9,260,0,262,17,260,272,1,260,0,16,262,8,17,1,17,277,0,272,1,256,260,261,277]

theorem envBound43354 : H12AffineFastState.Bounded env43354 := by
  intro p hp
  have h : env43354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43353_43354 : H12AffineEnvironment.transform 8 276 env43353 = env43354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env43353 == env43354) = true)

theorem identity43354 : scanCanonicalize (H12AffineFastState.compose env43354 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43355 : List Nat := [2,4,8,1,0,1,9,256,261,257,1,260,9,260,0,262,0,260,257,1,260,0,1,262,8,0,1,0,260,0,257,1,256,260,261,260]

theorem envBound43355 : H12AffineFastState.Bounded env43355 := by
  intro p hp
  have h : env43355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43354_43355 : H12AffineEnvironment.transform 3 1 env43354 = env43355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43354 == env43355) = true)

def env43356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156133,485759,16777216,8328,65,16959642,17246589,102878,108926,17231215,17148373,256,16777251,16834950,17287864]

theorem envBound43356 : H12AffineFastState.Bounded env43356 := by
  intro p hp
  have h : env43356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43292_43356 : H12AffineEnvironment.transform 20 437745 env43292 = env43356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env43292 == env43356) = true)

theorem identity43356 : scanCanonicalize (H12AffineFastState.compose env43356 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound43356 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env43357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156133,485759,188870,8328,65,10588,379067,102878,108926,265385,477203,256,188901,131136,338814]

theorem envBound43357 : H12AffineFastState.Bounded env43357 := by
  intro p hp
  have h : env43357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43356_43357 : H12AffineEnvironment.transform 23 188870 env43356 = env43357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env43356 == env43357) = true)

def env43358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,156133,120015,188870,8328,65,10588,226571,102878,108926,176409,128419,256,188901,131136,235214]

theorem envBound43358 : H12AffineFastState.Bounded env43358 := by
  intro p hp
  have h : env43358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43357_43358 : H12AffineEnvironment.transform 17 179632 env43357 = env43358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env43357 == env43358) = true)

theorem identity43358 : scanCanonicalize (H12AffineFastState.compose env43358 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound43358 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149861,1024,29908,4161,156133,73754,136467,8328,65,10588,226571,91403,89515,148940,65910,256,136496,131136,221723]

theorem envBound43359 : H12AffineFastState.Bounded env43359 := by
  intro p hp
  have h : env43359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43358_43359 : H12AffineEnvironment.transform 14 29909 env43358 = env43359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env43358 == env43359) = true)

def env43360 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149813,1024,29828,4113,156085,73754,136467,8328,17,10508,226571,91403,89515,148892,65830,256,136496,131088,221723]

theorem envBound43360 : H12AffineFastState.Bounded env43360 := by
  intro p hp
  have h : env43360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43359_43360 : H12AffineEnvironment.transform 5 16 env43359 = env43360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43359 == env43360) = true)

theorem identity43360 : scanCanonicalize (H12AffineFastState.compose env43360 (packedSelected [0,4,5,7,8,10,16,18,19,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound43360 : packedSelected [0,4,5,7,8,10,16,18,19,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43361 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70679,89378,1024,29828,4113,95650,73754,65796,8328,17,10508,24860,91403,89515,86411,65830,256,65831,70663,30220]

theorem envBound43361 : H12AffineFastState.Bounded env43361 := by
  intro p hp
  have h : env43361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43360_43361 : H12AffineEnvironment.transform 16 70679 env43360 = env43361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env43360 == env43361) = true)

theorem identity43361 : scanCanonicalize (H12AffineFastState.compose env43361 (packedSelected [1,3,4,5,7,8,9,10,11,16,17,18,19,20,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43361 : packedSelected [1,3,4,5,7,8,9,10,11,16,17,18,19,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env43362 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21897,65536,70679,89378,1024,21896,4113,87214,65814,65796,388,17,2048,16400,82951,89515,86411,65830,256,65831,70663,22272]

theorem envBound43362 : H12AffineFastState.Bounded env43362 := by
  intro p hp
  have h : env43362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43361_43362 : H12AffineEnvironment.transform 12 268 env43361 = env43362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43361 == env43362) = true)

theorem identity43362 : scanCanonicalize (H12AffineFastState.compose env43362 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43362 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env43363 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,65536,70679,89378,1024,21760,4113,87078,65814,65796,268,17,2048,16400,82951,89379,86275,65830,256,65831,70663,22272]

theorem envBound43363 : H12AffineFastState.Bounded env43363 := by
  intro p hp
  have h : env43363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43362_43363 : H12AffineEnvironment.transform 6 8 env43362 = env43363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43362 == env43363) = true)

theorem identity43363 : scanCanonicalize (H12AffineFastState.compose env43363 (packedSelected [1,4,5,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 6423) := by decide +kernel

theorem selectedBound43363 : packedSelected [1,4,5,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43364 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,6423,3328,17461,1024,21760,4113,19761,6145,6163,268,17,2048,16400,23824,17460,18452,6193,256,6192,3344,22272]

theorem envBound43364 : H12AffineFastState.Bounded env43364 := by
  intro p hp
  have h : env43364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43363_43364 : H12AffineEnvironment.transform 15 6423 env43363 = env43364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6423 env43363 == env43364) = true)

theorem identity43364 : scanCanonicalize (H12AffineFastState.compose env43364 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43364 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env43365 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,6423,3328,4405,1024,0,4113,6193,6145,6163,268,17,2048,5392,2064,4404,7444,6193,256,6192,3344,512]

theorem envBound43365 : H12AffineFastState.Bounded env43365 := by
  intro p hp
  have h : env43365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43364_43365 : H12AffineEnvironment.transform 13 5376 env43364 = env43365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43364 == env43365) = true)

theorem identity43365 : scanCanonicalize (H12AffineFastState.compose env43365 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound43365 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43366 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2096,268,3376,1,295,3328,2309,1024,0,2081,1,49,35,268,17,2048,3360,2064,2308,1316,1,256,0,3344,512]

theorem envBound43366 : H12AffineFastState.Bounded env43366 := by
  intro p hp
  have h : env43366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43365_43366 : H12AffineEnvironment.transform 11 2096 env43365 = env43366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env43365 == env43366) = true)

theorem identity43366 : scanCanonicalize (H12AffineFastState.compose env43366 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43366 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env43367 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2096,268,2081,1,295,2065,2309,273,0,2081,1,49,35,268,17,2048,2097,2064,2308,53,1,256,0,2049,512]

theorem envBound43367 : H12AffineFastState.Bounded env43367 := by
  intro p hp
  have h : env43367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43366_43367 : H12AffineEnvironment.transform 9 273 env43366 = env43367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43366 == env43367) = true)

theorem identity43367 : scanCanonicalize (H12AffineFastState.compose env43367 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound43367 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43368 : List Nat := [2,4,8,16,32,16,8,256,512,273,260,308,268,293,1,295,277,1,273,0,293,1,49,35,268,17,260,309,276,0,53,1,256,0,261,512]

theorem envBound43368 : H12AffineFastState.Bounded env43368 := by
  intro p hp
  have h : env43368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43367_43368 : H12AffineEnvironment.transform 10 260 env43367 = env43368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env43367 == env43368) = true)

theorem identity43368 : scanCanonicalize (H12AffineFastState.compose env43368 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43369 : List Nat := [2,4,8,16,1,16,8,256,512,273,260,277,268,260,1,262,277,1,273,0,260,1,16,2,268,17,260,276,276,0,20,1,256,0,261,512]

theorem envBound43369 : H12AffineFastState.Bounded env43369 := by
  intro p hp
  have h : env43369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43368_43369 : H12AffineEnvironment.transform 4 1 env43368 = env43369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43368 == env43369) = true)

theorem identity43369 : scanCanonicalize (H12AffineFastState.compose env43369 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43369 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43370 : List Nat := [2,4,8,16,1,16,8,256,0,273,260,277,268,260,1,262,277,1,273,0,260,1,16,2,268,17,260,276,276,0,20,1,256,0,261,0]

theorem envBound43370 : H12AffineFastState.Bounded env43370 := by
  intro p hp
  have h : env43370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43369_43370 : H12AffineEnvironment.transform 8 0 env43369 = env43370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43369 == env43370) = true)

def env43371 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149812,1024,29829,4112,156084,73754,136467,8328,16,10509,226571,91403,89515,148893,65831,256,136496,131089,221723]

theorem envBound43371 : H12AffineFastState.Bounded env43371 := by
  intro p hp
  have h : env43371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43359_43371 : H12AffineEnvironment.transform 5 17 env43359 = env43371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43359 == env43371) = true)

theorem identity43371 : scanCanonicalize (H12AffineFastState.compose env43371 (packedSelected [0,4,5,7,8,10,16,18,19,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound43371 : packedSelected [0,4,5,7,8,10,16,18,19,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43372 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24860,10280,1024,29829,4112,168,73754,29711,8328,16,10509,70679,91403,89515,9345,65831,256,29740,24845,66311]

theorem envBound43372 : H12AffineFastState.Bounded env43372 := by
  intro p hp
  have h : env43372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43371_43372 : H12AffineEnvironment.transform 16 24860 env43371 = env43372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env43371 == env43372) = true)

theorem identity43372 : scanCanonicalize (H12AffineFastState.compose env43372 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9618) := by decide +kernel

theorem selectedBound43372 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43373 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,9618,24860,10280,1024,29829,4112,168,1416,29711,8328,16,10509,12677,16537,30777,9345,9397,256,29740,24845,9877]

theorem envBound43373 : H12AffineFastState.Bounded env43373 := by
  intro p hp
  have h : env43373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43372_43373 : H12AffineEnvironment.transform 15 9618 env43372 = env43373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9618 env43372 == env43373) = true)

theorem identity43373 : scanCanonicalize (H12AffineFastState.compose env43373 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 12465) := by decide +kernel

theorem selectedBound43373 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env43374 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,12465,1077,9618,4525,10280,1024,1076,4112,168,1416,1214,8328,16,10509,12677,12328,2184,9345,9397,256,1181,4540,9877]

theorem envBound43374 : H12AffineFastState.Bounded env43374 := by
  intro p hp
  have h : env43374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43373_43374 : H12AffineEnvironment.transform 13 12465 env43373 = env43374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12465 env43373 == env43374) = true)

theorem identity43374 : scanCanonicalize (H12AffineFastState.compose env43374 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,17,19] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound43374 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env43375 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,4096,8192,12465,1,8614,4525,10280,52,0,4112,168,444,138,8328,16,10509,12677,12328,2184,8373,8321,256,169,4540,8865]

theorem envBound43375 : H12AffineFastState.Bounded env43375 := by
  intro p hp
  have h : env43375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43374_43375 : H12AffineEnvironment.transform 9 52 env43374 = env43375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43374 == env43375) = true)

theorem identity43375 : scanCanonicalize (H12AffineFastState.compose env43375 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound43375 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43376 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,4096,8192,12465,1,8203,4096,10280,52,0,4112,168,17,138,8328,16,10400,12328,12328,2184,8373,8321,173,169,4113,8865]

theorem envBound43376 : H12AffineFastState.Bounded env43376 := by
  intro p hp
  have h : env43376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43375_43376 : H12AffineEnvironment.transform 7 173 env43375 = env43376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43375 == env43376) = true)

def env43377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,156133,120014,188870,8328,65,10588,226570,102878,108926,176408,128418,256,188901,131136,235215]

theorem envBound43377 : H12AffineFastState.Bounded env43377 := by
  intro p hp
  have h : env43377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43357_43377 : H12AffineEnvironment.transform 17 179633 env43357 = env43377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env43357 == env43377) = true)

theorem identity43377 : scanCanonicalize (H12AffineFastState.compose env43377 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound43377 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122283,1024,32769,4160,66047,120014,98780,8328,65,10588,5392,102878,108926,119042,128418,256,98815,90202,63189]

theorem envBound43378 : H12AffineFastState.Bounded env43378 := by
  intro p hp
  have h : env43378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43377_43378 : H12AffineEnvironment.transform 16 90138 env43377 = env43378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env43377 == env43378) = true)

def env43379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122147,1024,32769,4160,65911,119878,98644,8192,65,10588,5392,102742,108926,119042,128298,256,98679,90202,63069]

theorem envBound43379 : H12AffineFastState.Bounded env43379 := by
  intro p hp
  have h : env43379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43378_43379 : H12AffineEnvironment.transform 6 8 env43378 = env43379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43378 == env43379) = true)

theorem identity43379 : scanCanonicalize (H12AffineFastState.compose env43379 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound43379 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env43380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,76159,1024,29789,4160,65911,73754,95496,8192,65,10588,5392,91402,89378,75102,65910,256,95531,90202,513]

theorem envBound43380 : H12AffineFastState.Bounded env43380 := by
  intro p hp
  have h : env43380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43379_43380 : H12AffineEnvironment.transform 14 29788 env43379 = env43380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env43379 == env43380) = true)

theorem identity43380 : scanCanonicalize (H12AffineFastState.compose env43380 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43380 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env43381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16401,2420,1024,29789,4160,8572,17,21763,8192,65,10588,5392,17665,32041,1365,8573,256,21792,16465,513]

theorem envBound43381 : H12AffineFastState.Bounded env43381 := by
  intro p hp
  have h : env43381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43380_43381 : H12AffineEnvironment.transform 15 8203 env43380 = env43381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43380 == env43381) = true)

theorem identity43381 : scanCanonicalize (H12AffineFastState.compose env43381 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43381 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,2420,1024,8541,4160,8572,17,3,8192,65,10588,5392,4097,10281,1365,8573,256,32,5457,513]

theorem envBound43382 : H12AffineFastState.Bounded env43382 := by
  intro p hp
  have h : env43382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43381_43382 : H12AffineEnvironment.transform 13 5376 env43381 = env43382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43381 == env43382) = true)

theorem identity43382 : scanCanonicalize (H12AffineFastState.compose env43382 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43382 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5393,2420,1024,1,4160,32,17,3,348,65,2048,5392,4097,2421,1365,33,256,32,5457,513]

theorem envBound43383 : H12AffineFastState.Bounded env43383 := by
  intro p hp
  have h : env43383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43382_43383 : H12AffineEnvironment.transform 12 348 env43382 = env43383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43382 == env43383) = true)

theorem identity43383 : scanCanonicalize (H12AffineFastState.compose env43383 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound43383 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1140,348,372,0,343,357,2420,1024,1,1076,32,17,3,348,65,2048,356,1141,2421,1365,33,256,32,293,513]

theorem envBound43384 : H12AffineFastState.Bounded env43384 := by
  intro p hp
  have h : env43384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43383_43384 : H12AffineEnvironment.transform 11 1140 env43383 = env43384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env43383 == env43384) = true)

theorem identity43384 : scanCanonicalize (H12AffineFastState.compose env43384 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound43384 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,1140,348,372,0,343,357,1345,1024,1,1076,32,17,3,348,65,1077,356,1141,1344,1365,33,256,32,293,513]

theorem envBound43385 : H12AffineFastState.Bounded env43385 := by
  intro p hp
  have h : env43385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43384_43385 : H12AffineEnvironment.transform 10 1077 env43384 = env43385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env43384 == env43385) = true)

theorem identity43385 : scanCanonicalize (H12AffineFastState.compose env43385 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43385 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43386 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,1140,41,1,0,34,16,1076,1024,1,1076,32,17,3,41,65,1077,17,1141,1077,1056,33,117,32,80,513]

theorem envBound43386 : H12AffineFastState.Bounded env43386 := by
  intro p hp
  have h : env43386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43385_43386 : H12AffineEnvironment.transform 7 117 env43385 = env43386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43385 == env43386) = true)

theorem identity43386 : scanCanonicalize (H12AffineFastState.compose env43386 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound43386 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env43387 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,17,41,1,0,34,16,81,101,1,81,32,17,3,41,65,80,17,16,80,69,33,117,32,80,513]

theorem envBound43387 : H12AffineFastState.Bounded env43387 := by
  intro p hp
  have h : env43387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43386_43387 : H12AffineEnvironment.transform 9 101 env43386 = env43387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env43386 == env43387) = true)

theorem identity43387 : scanCanonicalize (H12AffineFastState.compose env43387 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound43387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43388 : List Nat := [2,4,8,16,32,64,8,117,32,101,80,17,41,1,0,34,16,81,101,1,81,32,17,3,41,65,80,17,16,80,69,33,117,32,80,33]

theorem envBound43388 : H12AffineFastState.Bounded env43388 := by
  intro p hp
  have h : env43388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43387_43388 : H12AffineEnvironment.transform 8 32 env43387 = env43388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env43387 == env43388) = true)

def env43389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4160,65910,119879,98645,8193,65,10588,5392,102743,108926,119042,128299,256,98678,90202,63068]

theorem envBound43389 : H12AffineFastState.Bounded env43389 := by
  intro p hp
  have h : env43389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43378_43389 : H12AffineEnvironment.transform 6 9 env43378 = env43389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43378 == env43389) = true)

theorem identity43389 : scanCanonicalize (H12AffineFastState.compose env43389 (packedSelected [4,5,9,12,15,16,19,24,35] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound43389 : packedSelected [4,5,9,12,15,16,19,24,35] rootPS < 2^1333 := by decide +kernel

def env43390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,65536,70962,108554,1024,32769,4160,65910,106863,98645,8193,65,10588,5392,102743,108926,107562,98307,256,98678,71026,33652]

theorem envBound43390 : H12AffineFastState.Bounded env43390 := by
  intro p hp
  have h : env43390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43389_43390 : H12AffineEnvironment.transform 13 13608 env43389 = env43390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env43389 == env43390) = true)

theorem identity43390 : scanCanonicalize (H12AffineFastState.compose env43390 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound43390 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env43391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,343,5221,43357,1024,32769,4160,33,41016,32770,8193,65,10588,5392,36864,43049,42365,33108,256,32801,5157,33652]

theorem envBound43391 : H12AffineFastState.Bounded env43391 := by
  intro p hp
  have h : env43391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43390_43391 : H12AffineEnvironment.transform 15 343 env43390 = env43391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env43390 == env43391) = true)

theorem identity43391 : scanCanonicalize (H12AffineFastState.compose env43391 (packedSelected [1,2,6,8,10,14,15,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43391 : packedSelected [1,2,6,8,10,14,15,18,20] rootPS < 2^1333 := by decide +kernel

def env43392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5157,32768,343,5221,34896,1024,32769,4160,33,33077,32770,268,65,2129,5392,36864,35108,33904,33108,256,32801,5157,33652]

theorem envBound43392 : H12AffineFastState.Bounded env43392 := by
  intro p hp
  have h : env43392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43391_43392 : H12AffineEnvironment.transform 12 269 env43391 = env43392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43391 == env43392) = true)

theorem identity43392 : scanCanonicalize (H12AffineFastState.compose env43392 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43392 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env43393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5157,0,343,5221,2128,1024,1,4160,33,309,2,268,65,2129,5392,4096,2340,1136,340,256,33,5157,884]

theorem envBound43393 : H12AffineFastState.Bounded env43393 := by
  intro p hp
  have h : env43393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43392_43393 : H12AffineEnvironment.transform 14 0 env43392 = env43393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43392 == env43393) = true)

theorem identity43393 : scanCanonicalize (H12AffineFastState.compose env43393 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43393 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env43394 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,269,4112,0,343,4176,2128,53,1,4160,33,309,2,268,65,2129,4389,4096,2340,69,340,256,33,4112,884]

theorem envBound43394 : H12AffineFastState.Bounded env43394 := by
  intro p hp
  have h : env43394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43393_43394 : H12AffineEnvironment.transform 9 53 env43393 = env43394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43393 == env43394) = true)

def env43395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound43395 : H12AffineFastState.Bounded env43395 := by
  intro p hp
  have h : env43395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43222_43395 : H12AffineEnvironment.transform 18 1025 env43222 = env43395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env43222 == env43395) = true)

theorem identity43395 : scanCanonicalize (H12AffineFastState.compose env43395 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297471) := by decide +kernel

theorem selectedBound43395 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297471,8328,65,12798462,2428274,10507600,8830976,8719855,6679614,257,10833235,10857719,8661561]

theorem envBound43396 : H12AffineFastState.Bounded env43396 := by
  intro p hp
  have h : env43396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43395_43396 : H12AffineEnvironment.transform 23 297471 env43395 = env43396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297471 env43395 == env43396) = true)

def env43397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12798326,2428274,10507600,8830976,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound43397 : H12AffineFastState.Bounded env43397 := by
  intro p hp
  have h : env43397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43396_43397 : H12AffineEnvironment.transform 6 8 env43396 = env43397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43396 == env43397) = true)

def env43398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650854,2428274,10507600,8683536,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound43398 : H12AffineFastState.Bounded env43398 := by
  intro p hp
  have h : env43398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43397_43398 : H12AffineEnvironment.transform 16 16400 env43397 = env43398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env43397 == env43398) = true)

theorem identity43398 : scanCanonicalize (H12AffineFastState.compose env43398 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297316) := by decide +kernel

theorem selectedBound43398 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,297316,297335,8192,65,4554754,2428274,2415668,2420,99331,6679614,257,2212919,2172187,41821]

theorem envBound43399 : H12AffineFastState.Bounded env43399 := by
  intro p hp
  have h : env43399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43398_43399 : H12AffineEnvironment.transform 22 297316 env43398 = env43399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297316 env43398 == env43399) = true)

theorem identity43399 : scanCanonicalize (H12AffineFastState.compose env43399 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound43399 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env43400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16400,262144,1025,32769,2097152,4194304,297316,297335,8192,65,4456788,2395172,2415668,2420,1365,6581608,257,2114913,2139213,41821]

theorem envBound43400 : H12AffineFastState.Bounded env43400 := by
  intro p hp
  have h : env43400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43399_43400 : H12AffineEnvironment.transform 15 33110 env43399 = env43400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env43399 == env43400) = true)

theorem identity43400 : scanCanonicalize (H12AffineFastState.compose env43400 (packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound43400 : packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS < 2^1333 := by decide +kernel

def env43401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16400,262144,1025,32769,2097152,41340,297316,297335,8192,65,303144,2395172,2415668,2420,1365,2411540,257,2114913,2139213,41821]

theorem envBound43401 : H12AffineFastState.Bounded env43401 := by
  intro p hp
  have h : env43401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43400_43401 : H12AffineEnvironment.transform 21 41340 env43400 = env43401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env43400 == env43401) = true)

theorem identity43401 : scanCanonicalize (H12AffineFastState.compose env43401 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound43401 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,16400,262144,1025,32769,25677,41340,297316,297335,8192,65,303144,321641,309369,2420,1365,305241,257,8492,49152,41821]

theorem envBound43402 : H12AffineFastState.Bounded env43402 := by
  intro p hp
  have h : env43402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43401_43402 : H12AffineEnvironment.transform 20 25677 env43401 = env43402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env43401 == env43402) = true)

def env43403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8574,16400,262144,1025,8233,25677,340,272716,272735,8192,65,262144,280641,268369,2420,1365,264305,257,8492,24616,885]

theorem envBound43403 : H12AffineFastState.Bounded env43403 := by
  intro p hp
  have h : env43403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43402_43403 : H12AffineEnvironment.transform 14 8232 env43402 = env43403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env43402 == env43403) = true)

theorem identity43403 : scanCanonicalize (H12AffineFastState.compose env43403 (packedSelected [0,1,3,4,10,11,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound43403 : packedSelected [0,1,3,4,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8574,16400,10589,1025,8233,25677,340,17,2,8192,65,10589,24860,12556,2420,1365,8492,257,8492,24616,885]

theorem envBound43404 : H12AffineFastState.Bounded env43404 := by
  intro p hp
  have h : env43404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43403_43404 : H12AffineEnvironment.transform 17 10589 env43403 = env43404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env43403 == env43404) = true)

theorem identity43404 : scanCanonicalize (H12AffineFastState.compose env43404 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43404 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43405 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8232,8494,16400,10509,1025,8233,25629,260,17,2,8192,17,10509,24860,12556,2340,1285,8492,257,8492,24616,805]

theorem envBound43405 : H12AffineFastState.Bounded env43405 := by
  intro p hp
  have h : env43405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43404_43405 : H12AffineEnvironment.transform 5 16 env43404 = env43405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43404 == env43405) = true)

theorem identity43405 : scanCanonicalize (H12AffineFastState.compose env43405 (packedSelected [2,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound43405 : packedSelected [2,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43406 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13609,8232,8494,13625,10509,1025,8233,4404,260,17,2,8192,17,10509,5173,12556,2340,1285,8492,257,8492,5377,805]

theorem envBound43406 : H12AffineFastState.Bounded env43406 := by
  intro p hp
  have h : env43406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43405_43406 : H12AffineEnvironment.transform 13 13609 env43405 = env43406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env43405 == env43406) = true)

theorem identity43406 : scanCanonicalize (H12AffineFastState.compose env43406 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound43406 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43407 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6201,3344,6161,6423,3328,4404,1025,6160,4404,260,17,2,6201,17,4404,5173,2357,2340,1285,6421,257,6421,5377,805]

theorem envBound43407 : H12AffineFastState.Bounded env43407 := by
  intro p hp
  have h : env43407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43406_43407 : H12AffineEnvironment.transform 12 6201 env43406 = env43407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env43406 == env43407) = true)

theorem identity43407 : scanCanonicalize (H12AffineFastState.compose env43407 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound43407 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43408 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,4096,5416,1,5376,5126,17,4404,1025,5377,4404,260,17,2,5416,17,4404,5173,1060,1077,1285,5124,257,5124,5377,805]

theorem envBound43408 : H12AffineFastState.Bounded env43408 := by
  intro p hp
  have h : env43408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43407_43408 : H12AffineEnvironment.transform 10 1297 env43407 = env43408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env43407 == env43408) = true)

theorem identity43408 : scanCanonicalize (H12AffineFastState.compose env43408 (packedSelected [2,6,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound43408 : packedSelected [2,6,10,14] rootPS < 2^1333 := by decide +kernel

def env43409 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,1281,41,1,1,263,17,1077,1025,0,1077,260,17,2,41,17,1077,308,1060,1077,1285,261,257,261,0,805]

theorem envBound43409 : H12AffineFastState.Bounded env43409 := by
  intro p hp
  have h : env43409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43408_43409 : H12AffineEnvironment.transform 11 1281 env43408 = env43409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env43408 == env43409) = true)

theorem identity43409 : scanCanonicalize (H12AffineFastState.compose env43409 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43409 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43410 : List Nat := [2,4,8,16,32,16,8,256,512,53,292,308,41,1,1,263,17,0,52,0,0,260,17,2,41,17,0,308,17,0,304,261,257,261,0,805]

theorem envBound43410 : H12AffineFastState.Bounded env43410 := by
  intro p hp
  have h : env43410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43409_43410 : H12AffineEnvironment.transform 9 53 env43409 = env43410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43409 == env43410) = true)

theorem identity43410 : scanCanonicalize (H12AffineFastState.compose env43410 (packedSelected [0,2,6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound43410 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env43411 : List Nat := [2,4,8,16,32,16,8,52,512,53,16,0,41,1,1,51,17,0,52,0,0,48,17,2,41,17,0,0,17,0,4,49,53,49,0,529]

theorem envBound43411 : H12AffineFastState.Bounded env43411 := by
  intro p hp
  have h : env43411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43410_43411 : H12AffineEnvironment.transform 7 52 env43410 = env43411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env43410 == env43411) = true)

theorem identity43411 : scanCanonicalize (H12AffineFastState.compose env43411 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43412 : List Nat := [2,4,8,1,32,1,8,37,512,36,1,0,41,1,1,34,0,0,37,0,0,33,0,2,41,0,0,0,0,0,4,32,36,32,0,512]

theorem envBound43412 : H12AffineFastState.Bounded env43412 := by
  intro p hp
  have h : env43412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43411_43412 : H12AffineEnvironment.transform 3 1 env43411 = env43412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43411 == env43412) = true)

theorem identity43412 : scanCanonicalize (H12AffineFastState.compose env43412 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43413 : List Nat := [2,4,8,1,1,1,8,4,512,5,1,0,8,1,1,3,0,0,4,0,0,0,0,2,8,0,0,0,0,0,4,1,5,1,0,512]

theorem envBound43413 : H12AffineFastState.Bounded env43413 := by
  intro p hp
  have h : env43413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43412_43413 : H12AffineEnvironment.transform 4 1 env43412 = env43413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43412 == env43413) = true)

theorem identity43413 : scanCanonicalize (H12AffineFastState.compose env43413 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43414 : List Nat := [2,1,8,1,1,1,8,1,512,0,1,0,8,1,1,3,0,0,1,0,0,0,0,2,8,0,0,0,0,0,1,1,0,1,0,512]

theorem envBound43414 : H12AffineFastState.Bounded env43414 := by
  intro p hp
  have h : env43414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43413_43414 : H12AffineEnvironment.transform 1 1 env43413 = env43414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43413 == env43414) = true)

theorem identity43414 : scanCanonicalize (H12AffineFastState.compose env43414 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43414 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43415 : List Nat := [2,1,8,1,1,1,8,1,0,0,1,0,8,1,1,3,0,0,1,0,0,0,0,2,8,0,0,0,0,0,1,1,0,1,0,0]

theorem envBound43415 : H12AffineFastState.Bounded env43415 := by
  intro p hp
  have h : env43415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43414_43415 : H12AffineEnvironment.transform 8 0 env43414 = env43415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43414 == env43415) = true)

def env43416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8575,16400,262144,1025,8232,25677,341,272717,272734,8192,65,262145,280640,268368,2420,1365,264304,257,8492,24617,884]

theorem envBound43416 : H12AffineFastState.Bounded env43416 := by
  intro p hp
  have h : env43416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43402_43416 : H12AffineEnvironment.transform 14 8233 env43402 = env43416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env43402 == env43416) = true)

theorem identity43416 : scanCanonicalize (H12AffineFastState.compose env43416 (packedSelected [0,1,3,4,10,11,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43416 : packedSelected [0,1,3,4,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8575,16400,10281,1025,8232,25677,341,356,375,8192,65,10280,24681,12409,2420,1365,8281,257,8492,24617,884]

theorem envBound43417 : H12AffineFastState.Bounded env43417 := by
  intro p hp
  have h : env43417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43416_43417 : H12AffineEnvironment.transform 17 10281 env43416 = env43417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43416 == env43417) = true)

theorem identity43417 : scanCanonicalize (H12AffineFastState.compose env43417 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43417 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,293,115,16400,2341,1025,292,17729,341,356,375,268,65,2340,16741,4469,2420,1365,341,257,32,16677,884]

theorem envBound43418 : H12AffineFastState.Bounded env43418 := by
  intro p hp
  have h : env43418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43417_43418 : H12AffineEnvironment.transform 12 268 env43417 = env43418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43417 == env43418) = true)

theorem identity43418 : scanCanonicalize (H12AffineFastState.compose env43418 (packedSelected [0,1,2,4,5,6,11] rootPS)) = affineNative (2^(13+1) ^^^ 7505) := by decide +kernel

theorem selectedBound43418 : packedSelected [0,1,2,4,5,6,11] rootPS < 2^1333 := by decide +kernel

def env43419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,7505,293,115,7489,2341,1025,292,6160,341,356,375,268,65,2340,7220,4469,2420,1365,341,257,32,7284,884]

theorem envBound43419 : H12AffineFastState.Bounded env43419 := by
  intro p hp
  have h : env43419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43418_43419 : H12AffineEnvironment.transform 13 7505 env43418 = env43419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7505 env43418 == env43419) = true)

theorem identity43419 : scanCanonicalize (H12AffineFastState.compose env43419 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound43419 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,268,5377,293,115,5393,373,1025,292,4160,341,356,375,268,65,372,5220,4469,292,1365,341,257,32,5156,884]

theorem envBound43420 : H12AffineFastState.Bounded env43420 := by
  intro p hp
  have h : env43420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43419_43420 : H12AffineEnvironment.transform 10 80 env43419 = env43420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env43419 == env43420) = true)

def env43421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650855,2428274,10507600,8683537,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound43421 : H12AffineFastState.Bounded env43421 := by
  intro p hp
  have h : env43421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43397_43421 : H12AffineEnvironment.transform 16 16401 env43397 = env43421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43397 == env43421) = true)

theorem identity43421 : scanCanonicalize (H12AffineFastState.compose env43421 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43421 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1025,8541,2097152,4194304,8388608,272427,8192,65,12650855,2428274,10507600,8659277,8719719,6638946,257,10833235,10816803,8661561]

theorem envBound43422 : H12AffineFastState.Bounded env43422 := by
  intro p hp
  have h : env43422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43421_43422 : H12AffineEnvironment.transform 14 8540 env43421 = env43422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43421 == env43422) = true)

theorem identity43422 : scanCanonicalize (H12AffineFastState.compose env43422 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 329779) := by decide +kernel

theorem selectedBound43422 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env43423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1025,8541,2097152,4194304,329779,272427,8192,65,4456788,2428274,2448739,76158,1364,6638946,257,2114912,2098448,74250]

theorem envBound43423 : H12AffineFastState.Bounded env43423 := by
  intro p hp
  have h : env43423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43422_43423 : H12AffineEnvironment.transform 22 329779 env43422 = env43423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 329779 env43422 == env43423) = true)

theorem identity43423 : scanCanonicalize (H12AffineFastState.compose env43423 (packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 329731) := by decide +kernel

theorem selectedBound43423 : packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS < 2^1333 := by decide +kernel

def env43424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1025,8541,2097152,329731,329779,272427,8192,65,67927,2428274,2448739,76158,1364,2114913,257,2114912,2098448,74250]

theorem envBound43424 : H12AffineFastState.Bounded env43424 := by
  intro p hp
  have h : env43424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43423_43424 : H12AffineEnvironment.transform 21 329731 env43423 = env43424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329731 env43423 == env43424) = true)

theorem identity43424 : scanCanonicalize (H12AffineFastState.compose env43424 (packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound43424 : packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env43425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1025,8541,91466,329731,329779,272427,8192,65,67927,288824,276521,76158,1364,73771,257,73770,90202,74250]

theorem envBound43425 : H12AffineFastState.Bounded env43425 := by
  intro p hp
  have h : env43425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43424_43425 : H12AffineEnvironment.transform 20 91466 env43424 = env43425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env43424 == env43425) = true)

theorem identity43425 : scanCanonicalize (H12AffineFastState.compose env43425 (packedSelected [2,4,9,11,16,17,18,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound43425 : packedSelected [2,4,9,11,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env43426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,91466,73771,73755,3,8192,65,67927,16400,4097,76158,1364,73771,257,73770,90202,74250]

theorem envBound43426 : H12AffineFastState.Bounded env43426 := by
  intro p hp
  have h : env43426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43425_43426 : H12AffineEnvironment.transform 17 10280 env43425 = env43426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43425 == env43426) = true)

theorem identity43426 : scanCanonicalize (H12AffineFastState.compose env43426 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound43426 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8540,65536,5221,10280,1025,8541,78142,73771,73755,3,8192,65,67927,5220,4097,76158,1364,73771,257,73770,78894,74250]

theorem envBound43427 : H12AffineFastState.Bounded env43427 := by
  intro p hp
  have h : env43427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43426_43427 : H12AffineEnvironment.transform 13 5236 env43426 = env43427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env43426 == env43427) = true)

theorem identity43427 : scanCanonicalize (H12AffineFastState.compose env43427 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound43427 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env43428 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4113,8540,65536,4096,10280,100,8541,78142,73771,73755,3,8192,65,67927,4097,4097,76158,305,73771,257,73770,77899,74250]

theorem envBound43428 : H12AffineFastState.Bounded env43428 := by
  intro p hp
  have h : env43428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43427_43428 : H12AffineEnvironment.transform 9 101 env43427 = env43428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env43427 == env43428) = true)

theorem identity43428 : scanCanonicalize (H12AffineFastState.compose env43428 (packedSelected [1,3,4,6,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 14411) := by decide +kernel

theorem selectedBound43428 : packedSelected [1,3,4,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env43429 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4113,8540,14411,4096,10280,100,8541,2421,6240,6224,3,8192,65,12572,4097,4097,4405,305,6240,257,6241,2048,6721]

theorem envBound43429 : H12AffineFastState.Bounded env43429 := by
  intro p hp
  have h : env43429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43428_43429 : H12AffineEnvironment.transform 15 14411 env43428 = env43429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14411 env43428 == env43429) = true)

theorem identity43429 : scanCanonicalize (H12AffineFastState.compose env43429 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43429 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env43430 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,269,4113,81,6470,4096,2341,100,80,2421,6240,6224,3,269,65,4113,4097,4097,4405,305,6240,257,6241,2048,6721]

theorem envBound43430 : H12AffineFastState.Bounded env43430 := by
  intro p hp
  have h : env43430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43429_43430 : H12AffineEnvironment.transform 12 269 env43429 = env43430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43429 == env43430) = true)

theorem identity43430 : scanCanonicalize (H12AffineFastState.compose env43430 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound43430 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env43431 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2065,269,2048,81,343,2065,2341,100,80,2421,113,65,3,269,65,2048,2064,2064,2340,305,113,257,112,2048,592]

theorem envBound43431 : H12AffineFastState.Bounded env43431 := by
  intro p hp
  have h : env43431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43430_43431 : H12AffineEnvironment.transform 11 2065 env43430 = env43431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env43430 == env43431) = true)

theorem identity43431 : scanCanonicalize (H12AffineFastState.compose env43431 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43431 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43432 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2065,269,2048,0,262,2065,2341,53,1,2340,32,16,3,269,16,2048,2064,2064,2340,305,32,257,33,2048,513]

theorem envBound43432 : H12AffineFastState.Bounded env43432 := by
  intro p hp
  have h : env43432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43431_43432 : H12AffineEnvironment.transform 5 17 env43431 = env43432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43431 == env43432) = true)

theorem identity43432 : scanCanonicalize (H12AffineFastState.compose env43432 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 831) := by decide +kernel

theorem selectedBound43432 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43433 : List Nat := [2,4,8,16,32,17,8,256,512,52,831,814,269,831,0,262,814,538,53,1,539,32,16,3,269,16,831,815,815,539,305,32,257,33,831,513]

theorem envBound43433 : H12AffineFastState.Bounded env43433 := by
  intro p hp
  have h : env43433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43432_43433 : H12AffineEnvironment.transform 10 831 env43432 = env43433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 831 env43432 == env43433) = true)

theorem identity43433 : scanCanonicalize (H12AffineFastState.compose env43433 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound43433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43434 : List Nat := [2,4,8,16,32,17,8,256,27,52,292,309,269,292,0,262,309,1,53,1,0,32,16,3,269,16,292,308,308,0,305,32,257,33,292,26]

theorem envBound43434 : H12AffineFastState.Bounded env43434 := by
  intro p hp
  have h : env43434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43433_43434 : H12AffineEnvironment.transform 8 27 env43433 = env43434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env43433 == env43434) = true)

def env43435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12798327,2428274,10507600,8830976,8719718,6679614,257,10833235,10857598,8661561]

theorem envBound43435 : H12AffineFastState.Bounded env43435 := by
  intro p hp
  have h : env43435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43396_43435 : H12AffineEnvironment.transform 6 9 env43396 = env43435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43396 == env43435) = true)

def env43436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650855,2428274,10507600,8683536,8719718,6679614,257,10833235,10857598,8661561]

theorem envBound43436 : H12AffineFastState.Bounded env43436 := by
  intro p hp
  have h : env43436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43435_43436 : H12AffineEnvironment.transform 16 16400 env43435 = env43436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env43435 == env43436) = true)

theorem identity43436 : scanCanonicalize (H12AffineFastState.compose env43436 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43436 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,8388608,41311,8193,65,12650855,2172251,10507600,8431673,8463695,6407191,257,10577274,10585175,8389136]

theorem envBound43437 : H12AffineFastState.Bounded env43437 := by
  intro p hp
  have h : env43437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43436_43437 : H12AffineEnvironment.transform 17 10281 env43436 = env43437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43436 == env43437) = true)

def env43438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,16,41311,8193,65,4262263,2172251,2118976,43049,75103,6407191,257,2188650,2196551,512]

theorem envBound43438 : H12AffineFastState.Bounded env43438 := by
  intro p hp
  have h : env43438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43437_43438 : H12AffineEnvironment.transform 22 16 env43437 = env43438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env43437 == env43438) = true)

theorem identity43438 : scanCanonicalize (H12AffineFastState.compose env43438 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 58728) := by decide +kernel

theorem selectedBound43438 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58728,4194304,16,41311,8193,65,4262263,114739,45096,43049,75103,4268415,257,98306,90415,512]

theorem envBound43439 : H12AffineFastState.Bounded env43439 := by
  intro p hp
  have h : env43439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43438_43439 : H12AffineEnvironment.transform 20 58728 env43438 = env43439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58728 env43438 == env43439) = true)

theorem identity43439 : scanCanonicalize (H12AffineFastState.compose env43439 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound43439 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env43440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58728,98679,16,41311,8193,65,34816,114739,45096,43049,75103,40968,257,98306,90415,512]

theorem envBound43440 : H12AffineFastState.Bounded env43440 := by
  intro p hp
  have h : env43440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43439_43440 : H12AffineEnvironment.transform 21 98679 env43439 = env43440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env43439 == env43440) = true)

theorem identity43440 : scanCanonicalize (H12AffineFastState.compose env43440 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 61499) := by decide +kernel

theorem selectedBound43440 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,61499,16400,10281,1025,32769,58728,29004,16,41311,8193,65,34816,12296,45096,43049,54628,40968,257,28729,37140,512]

theorem envBound43441 : H12AffineFastState.Bounded env43441 := by
  intro p hp
  have h : env43441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43440_43441 : H12AffineEnvironment.transform 15 61499 env43440 = env43441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61499 env43440 == env43441) = true)

theorem identity43441 : scanCanonicalize (H12AffineFastState.compose env43441 (packedSelected [12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43441 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env43442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,42299,5392,10281,1025,32769,45160,9292,16,41311,8193,65,34816,12296,45096,43049,32868,40968,257,9529,37140,512]

theorem envBound43442 : H12AffineFastState.Bounded env43442 := by
  intro p hp
  have h : env43442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43441_43442 : H12AffineEnvironment.transform 13 5376 env43441 = env43442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43441 == env43442) = true)

theorem identity43442 : scanCanonicalize (H12AffineFastState.compose env43442 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound43442 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env43443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1076,8463,5392,10281,1025,1077,13404,9292,16,9579,8193,65,3124,12296,13340,11293,1104,9276,257,9529,5408,512]

theorem envBound43443 : H12AffineFastState.Bounded env43443 := by
  intro p hp
  have h : env43443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43442_43443 : H12AffineEnvironment.transform 14 1076 env43442 = env43443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env43442 == env43443) = true)

theorem identity43443 : scanCanonicalize (H12AffineFastState.compose env43443 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound43443 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env43444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,5376,1076,1127,5392,3393,1025,1077,4404,292,16,3,1385,65,3124,5472,4468,2421,1104,340,257,81,5408,512]

theorem envBound43444 : H12AffineFastState.Bounded env43444 := by
  intro p hp
  have h : env43444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43443_43444 : H12AffineEnvironment.transform 12 1384 env43443 = env43444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env43443 == env43444) = true)

theorem identity43444 : scanCanonicalize (H12AffineFastState.compose env43444 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound43444 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43445 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,41,4161,373,294,4177,2048,320,372,4404,292,16,3,40,65,2421,4129,4468,2421,273,340,257,81,4193,512]

theorem envBound43445 : H12AffineFastState.Bounded env43445 := by
  intro p hp
  have h : env43445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43444_43445 : H12AffineEnvironment.transform 9 321 env43444 = env43445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43444 == env43445) = true)

theorem identity43445 : scanCanonicalize (H12AffineFastState.compose env43445 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43445 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43446 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,41,4161,0,83,4177,2048,53,1,4161,81,16,3,40,65,2048,4129,4097,2048,100,33,116,81,4193,512]

theorem envBound43446 : H12AffineFastState.Bounded env43446 := by
  intro p hp
  have h : env43446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43445_43446 : H12AffineEnvironment.transform 7 117 env43445 = env43446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43445 == env43446) = true)

theorem identity43446 : scanCanonicalize (H12AffineFastState.compose env43446 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43446 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43447 : List Nat := [2,4,8,16,32,49,9,4,512,52,2048,4096,41,4144,0,34,4128,2048,53,1,4144,32,16,3,40,48,2048,4129,4097,2048,21,33,5,32,4112,512]

theorem envBound43447 : H12AffineFastState.Bounded env43447 := by
  intro p hp
  have h : env43447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43446_43447 : H12AffineEnvironment.transform 5 49 env43446 = env43447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43446 == env43447) = true)

theorem identity43447 : scanCanonicalize (H12AffineFastState.compose env43447 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound43447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43448 : List Nat := [2,4,8,16,32,49,9,4,512,52,2048,2561,41,2609,0,34,2593,2048,53,1,2609,32,16,3,40,48,2048,2592,2560,2048,21,33,5,32,2577,512]

theorem envBound43448 : H12AffineFastState.Bounded env43448 := by
  intro p hp
  have h : env43448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43447_43448 : H12AffineEnvironment.transform 11 2561 env43447 = env43448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env43447 == env43448) = true)

theorem identity43448 : scanCanonicalize (H12AffineFastState.compose env43448 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound43448 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43449 : List Nat := [2,4,8,16,32,49,9,4,512,52,528,17,41,33,0,34,49,528,53,1,33,32,16,3,40,48,528,48,16,528,21,33,5,32,1,512]

theorem envBound43449 : H12AffineFastState.Bounded env43449 := by
  intro p hp
  have h : env43449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43448_43449 : H12AffineEnvironment.transform 10 528 env43448 = env43449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env43448 == env43449) = true)

theorem identity43449 : scanCanonicalize (H12AffineFastState.compose env43449 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43449 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43450 : List Nat := [2,4,8,16,1,16,9,4,512,21,528,17,8,0,0,3,16,528,20,1,0,1,16,3,9,17,528,17,16,528,21,0,5,1,1,512]

theorem envBound43450 : H12AffineFastState.Bounded env43450 := by
  intro p hp
  have h : env43450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43449_43450 : H12AffineEnvironment.transform 4 1 env43449 = env43450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43449 == env43450) = true)

theorem identity43450 : scanCanonicalize (H12AffineFastState.compose env43450 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound43450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43451 : List Nat := [2,4,8,5,1,5,9,4,512,0,517,4,8,0,0,3,5,517,1,1,0,1,5,3,9,4,517,4,5,517,0,0,5,1,1,512]

theorem envBound43451 : H12AffineFastState.Bounded env43451 := by
  intro p hp
  have h : env43451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43450_43451 : H12AffineEnvironment.transform 3 5 env43450 = env43451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env43450 == env43451) = true)

theorem identity43451 : scanCanonicalize (H12AffineFastState.compose env43451 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound43451 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43452 : List Nat := [2,4,8,5,1,5,9,4,4,0,1,4,8,0,0,3,5,1,1,1,0,1,5,3,9,4,1,4,5,1,0,0,5,1,1,4]

theorem envBound43452 : H12AffineFastState.Bounded env43452 := by
  intro p hp
  have h : env43452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43451_43452 : H12AffineEnvironment.transform 8 4 env43451 = env43452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env43451 == env43452) = true)

def env43453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41311,8193,65,4262262,2172251,2118977,43048,75102,6407191,257,2188651,2196550,513]

theorem envBound43453 : H12AffineFastState.Bounded env43453 := by
  intro p hp
  have h : env43453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43437_43453 : H12AffineEnvironment.transform 22 17 env43437 = env43453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43437 == env43453) = true)

def env43454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,4194304,17,41311,8193,65,4262262,115015,45405,43048,75102,4268043,257,98679,90202,513]

theorem envBound43454 : H12AffineFastState.Bounded env43454 := by
  intro p hp
  have h : env43454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43453_43454 : H12AffineEnvironment.transform 20 58396 env43453 = env43454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env43453 == env43454) = true)

theorem identity43454 : scanCanonicalize (H12AffineFastState.compose env43454 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43454 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58396,4194304,17,41311,8193,65,4204924,57677,45405,43048,1364,4194305,257,41341,16464,513]

theorem envBound43455 : H12AffineFastState.Bounded env43455 := by
  intro p hp
  have h : env43455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43454_43455 : H12AffineEnvironment.transform 15 8202 env43454 = env43455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43454 == env43455) = true)

theorem identity43455 : scanCanonicalize (H12AffineFastState.compose env43455 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound43455 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env43456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58396,33,17,41311,8193,65,10589,57677,45405,43048,1364,32,257,41341,16464,513]

theorem envBound43456 : H12AffineFastState.Bounded env43456 := by
  intro p hp
  have h : env43456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43455_43456 : H12AffineEnvironment.transform 21 33 env43455 = env43456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env43455 == env43456) = true)

theorem identity43456 : scanCanonicalize (H12AffineFastState.compose env43456 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43456 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env43457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16400,2340,1025,32769,50449,33,17,32850,268,65,2128,49216,36944,35109,1364,32,257,32880,16464,513]

theorem envBound43457 : H12AffineFastState.Bounded env43457 := by
  intro p hp
  have h : env43457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43456_43457 : H12AffineEnvironment.transform 12 269 env43456 = env43457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43456 == env43457) = true)

theorem identity43457 : scanCanonicalize (H12AffineFastState.compose env43457 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound43457 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,263,16400,2340,1025,80,17728,33,17,3,268,65,2128,16401,4097,2420,1364,32,257,33,16464,513]

theorem envBound43458 : H12AffineFastState.Bounded env43458 := by
  intro p hp
  have h : env43458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43457_43458 : H12AffineEnvironment.transform 14 81 env43457 = env43458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env43457 == env43458) = true)

theorem identity43458 : scanCanonicalize (H12AffineFastState.compose env43458 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43458 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43459 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,263,16400,2340,1025,0,17680,33,17,3,268,17,2048,16401,4097,2340,1284,32,257,33,16384,513]

theorem envBound43459 : H12AffineFastState.Bounded env43459 := by
  intro p hp
  have h : env43459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43458_43459 : H12AffineEnvironment.transform 5 16 env43458 = env43459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43458 == env43459) = true)

theorem identity43459 : scanCanonicalize (H12AffineFastState.compose env43459 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound43459 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43460 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5156,1,263,5172,2340,1025,0,4404,33,17,3,268,17,2048,5173,4097,2340,1284,32,257,33,5156,513]

theorem envBound43460 : H12AffineFastState.Bounded env43460 := by
  intro p hp
  have h : env43460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43459_43460 : H12AffineEnvironment.transform 13 5156 env43459 = env43460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env43459 == env43460) = true)

def env43461 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,269,2836,1,263,2820,2340,1025,0,3588,33,17,3,268,17,2048,2821,3889,2340,1284,32,257,33,2836,513]

theorem envBound43461 : H12AffineFastState.Bounded env43461 := by
  intro p hp
  have h : env43461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43460_43461 : H12AffineEnvironment.transform 11 3888 env43460 = env43461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env43460 == env43461) = true)

def env43462 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,269,1044,1,263,1028,1572,1025,0,260,33,17,3,268,17,1792,1029,49,1572,1284,32,257,33,1044,513]

theorem envBound43462 : H12AffineFastState.Bounded env43462 := by
  intro p hp
  have h : env43462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43461_43462 : H12AffineEnvironment.transform 10 1792 env43461 = env43462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env43461 == env43462) = true)

theorem identity43462 : scanCanonicalize (H12AffineFastState.compose env43462 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound43462 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43463 : List Nat := [2,4,8,16,32,16,9,256,512,304,560,48,269,292,1,263,308,788,305,0,260,33,17,3,268,17,560,309,49,788,52,32,257,33,292,513]

theorem envBound43463 : H12AffineFastState.Bounded env43463 := by
  intro p hp
  have h : env43463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43462_43463 : H12AffineEnvironment.transform 9 304 env43462 = env43463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env43462 == env43463) = true)

def env43464 : List Nat := [2,4,8,16,32,16,9,4,512,52,560,48,9,32,1,3,48,528,53,0,0,33,17,3,8,17,560,49,49,528,52,32,5,33,32,513]

theorem envBound43464 : H12AffineFastState.Bounded env43464 := by
  intro p hp
  have h : env43464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43463_43464 : H12AffineEnvironment.transform 7 4 env43463 = env43464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43463 == env43464) = true)

theorem identity43464 : scanCanonicalize (H12AffineFastState.compose env43464 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound43464 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43465 : List Nat := [2,4,8,16,32,16,9,4,16,52,32,48,9,32,1,3,48,0,53,0,0,33,17,3,8,17,32,49,49,0,52,32,5,33,32,17]

theorem envBound43465 : H12AffineFastState.Bounded env43465 := by
  intro p hp
  have h : env43465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43464_43465 : H12AffineEnvironment.transform 8 16 env43464 = env43465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43464 == env43465) = true)

def leafEnv43465 : List Nat := [2,4,8,16,32,16,9,4,16,52,32,48,9,32,1,3,48,0,53,0,0,33,17,3,53,8,1,17,32,49,49,0,52,32,5,33,5,2,32,17,1,0,0]

def active43465 : List Nat := [0,1,2,3,4]

def tree43465 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43465 : H12WitnessSearch.Good tree43465 := H12GlobalWitnessIndex.good

theorem leafIdentity43465 : H12AffineFastState.composeSystem env43465 rootObs = leafEnv43465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43465 rootObs == leafEnv43465) = true)

theorem terminalChecked43465 : H12PackedTerminal.terminalCheckFast leafEnv43465 active43465 tree43465 = true := by decide +kernel

def env43466 : List Nat := [2,4,8,16,32,16,9,5,512,53,560,48,8,33,1,2,49,529,52,0,1,33,17,3,9,17,560,48,49,529,52,32,4,33,33,513]

theorem envBound43466 : H12AffineFastState.Bounded env43466 := by
  intro p hp
  have h : env43466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43463_43466 : H12AffineEnvironment.transform 7 5 env43463 = env43466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43463 == env43466) = true)

theorem identity43466 : scanCanonicalize (H12AffineFastState.compose env43466 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43466 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43467 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,43,8,33,1,2,42,522,47,0,1,33,10,3,9,10,555,43,42,522,47,32,4,33,33,513]

theorem envBound43467 : H12AffineFastState.Bounded env43467 := by
  intro p hp
  have h : env43467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43466_43467 : H12AffineEnvironment.transform 3 11 env43466 = env43467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43466 == env43467) = true)

def leafEnv43467 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,43,8,33,1,2,42,522,47,0,1,33,10,3,46,9,1,10,555,43,42,522,47,32,4,33,5,3,33,513,1,1,0]

def active43467 : List Nat := [0,1,2,4,8]

def tree43467 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43467 : H12WitnessSearch.Good tree43467 := H12GlobalWitnessIndex.good

theorem leafIdentity43467 : H12AffineFastState.composeSystem env43467 rootObs = leafEnv43467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43467 rootObs == leafEnv43467) = true)

theorem terminalChecked43467 : H12PackedTerminal.terminalCheckFast leafEnv43467 active43467 tree43467 = true := by decide +kernel

def env43468 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,269,1045,1,263,1029,1573,1025,0,261,33,17,3,268,17,1793,1028,48,1573,1284,32,257,33,1045,513]

theorem envBound43468 : H12AffineFastState.Bounded env43468 := by
  intro p hp
  have h : env43468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43461_43468 : H12AffineEnvironment.transform 10 1793 env43461 = env43468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env43461 == env43468) = true)

theorem identity43468 : scanCanonicalize (H12AffineFastState.compose env43468 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43469 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1793,16,269,1045,1,263,1029,1540,1025,0,261,0,17,3,268,17,1793,1028,17,1540,1284,1,257,0,1045,513]

theorem envBound43469 : H12AffineFastState.Bounded env43469 := by
  intro p hp
  have h : env43469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43468_43469 : H12AffineEnvironment.transform 4 1 env43468 = env43469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43468 == env43469) = true)

def env43470 : List Nat := [2,4,8,16,1,16,9,256,512,20,789,16,269,1,1,263,17,528,21,0,261,0,17,3,268,17,789,16,17,528,272,1,257,0,1,513]

theorem envBound43470 : H12AffineFastState.Bounded env43470 := by
  intro p hp
  have h : env43470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43469_43470 : H12AffineEnvironment.transform 9 20 env43469 = env43470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43469 == env43470) = true)

theorem identity43470 : scanCanonicalize (H12AffineFastState.compose env43470 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43471 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,10,269,1,1,263,11,522,15,0,261,0,11,3,268,11,783,10,11,522,266,1,257,0,1,513]

theorem envBound43471 : H12AffineFastState.Bounded env43471 := by
  intro p hp
  have h : env43471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43470_43471 : H12AffineEnvironment.transform 3 10 env43470 = env43471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43470 == env43471) = true)

def leafEnv43471 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,10,269,1,1,263,11,522,15,0,261,0,11,3,267,268,1,11,783,10,11,522,266,1,257,0,5,262,1,513,1,261,0]

def active43471 : List Nat := [0,1,2,7,8]

def tree43471 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43471 : H12WitnessSearch.Good tree43471 := H12GlobalWitnessIndex.good

theorem leafIdentity43471 : H12AffineFastState.composeSystem env43471 rootObs = leafEnv43471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43471 rootObs == leafEnv43471) = true)

theorem terminalChecked43471 : H12PackedTerminal.terminalCheckFast leafEnv43471 active43471 tree43471 = true := by decide +kernel

def env43472 : List Nat := [2,4,8,16,1,16,9,256,512,21,788,16,269,0,1,263,16,529,20,0,261,0,17,3,268,17,788,17,17,529,273,1,257,0,0,513]

theorem envBound43472 : H12AffineFastState.Bounded env43472 := by
  intro p hp
  have h : env43472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43469_43472 : H12AffineEnvironment.transform 9 21 env43469 = env43472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43469 == env43472) = true)

theorem identity43472 : scanCanonicalize (H12AffineFastState.compose env43472 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound43472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43473 : List Nat := [2,4,8,16,1,16,9,256,276,21,0,16,269,0,1,263,16,261,20,0,261,0,17,3,268,17,0,17,17,261,273,1,257,0,0,277]

theorem envBound43473 : H12AffineFastState.Bounded env43473 := by
  intro p hp
  have h : env43473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43472_43473 : H12AffineEnvironment.transform 8 276 env43472 = env43473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env43472 == env43473) = true)

def leafEnv43473 : List Nat := [2,4,8,16,1,16,9,256,276,21,0,16,269,0,1,263,16,261,20,0,261,0,17,3,272,268,1,17,0,17,17,261,273,1,257,0,5,262,0,277,1,261,0]

def active43473 : List Nat := [0,1,2,3,7]

def tree43473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43473 : H12WitnessSearch.Good tree43473 := H12GlobalWitnessIndex.good

theorem leafIdentity43473 : H12AffineFastState.composeSystem env43473 rootObs = leafEnv43473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43473 rootObs == leafEnv43473) = true)

theorem terminalChecked43473 : H12PackedTerminal.terminalCheckFast leafEnv43473 active43473 tree43473 = true := by decide +kernel

def env43474 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,269,2837,1,263,2821,2340,1025,0,3589,33,17,3,268,17,2048,2820,3888,2340,1284,32,257,33,2837,513]

theorem envBound43474 : H12AffineFastState.Bounded env43474 := by
  intro p hp
  have h : env43474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43460_43474 : H12AffineEnvironment.transform 11 3889 env43460 = env43474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env43460 == env43474) = true)

def env43475 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,269,1045,1,263,1029,1572,1025,0,261,33,17,3,268,17,1792,1028,48,1572,1284,32,257,33,1045,513]

theorem envBound43475 : H12AffineFastState.Bounded env43475 := by
  intro p hp
  have h : env43475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43474_43475 : H12AffineEnvironment.transform 10 1792 env43474 = env43475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env43474 == env43475) = true)

theorem identity43475 : scanCanonicalize (H12AffineFastState.compose env43475 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43476 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1540,49,9,1045,1,3,1029,1572,1025,0,1,33,17,3,8,17,1540,1028,48,1572,1024,32,5,33,1045,513]

theorem envBound43476 : H12AffineFastState.Bounded env43476 := by
  intro p hp
  have h : env43476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43475_43476 : H12AffineEnvironment.transform 7 4 env43475 = env43476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43475 == env43476) = true)

def env43477 : List Nat := [2,4,8,16,32,16,9,4,512,52,560,49,9,33,1,3,49,528,53,0,1,33,17,3,8,17,560,48,48,528,52,32,5,33,33,513]

theorem envBound43477 : H12AffineFastState.Bounded env43477 := by
  intro p hp
  have h : env43477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43476_43477 : H12AffineEnvironment.transform 9 52 env43476 = env43477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43476 == env43477) = true)

theorem identity43477 : scanCanonicalize (H12AffineFastState.compose env43477 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43477 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43478 : List Nat := [2,4,8,16,32,16,9,4,17,52,33,49,9,33,1,3,49,1,53,0,1,33,17,3,8,17,33,48,48,1,52,32,5,33,33,16]

theorem envBound43478 : H12AffineFastState.Bounded env43478 := by
  intro p hp
  have h : env43478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43477_43478 : H12AffineEnvironment.transform 8 17 env43477 = env43478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43477 == env43478) = true)

def leafEnv43478 : List Nat := [2,4,8,16,32,16,9,4,17,52,33,49,9,33,1,3,49,1,53,0,1,33,17,3,53,8,1,17,33,48,48,1,52,32,5,33,5,2,33,16,1,1,0]

def active43478 : List Nat := [0,1,2,3,4]

def tree43478 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43478 : H12WitnessSearch.Good tree43478 := H12GlobalWitnessIndex.good

theorem leafIdentity43478 : H12AffineFastState.composeSystem env43478 rootObs = leafEnv43478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43478 rootObs == leafEnv43478) = true)

theorem terminalChecked43478 : H12PackedTerminal.terminalCheckFast leafEnv43478 active43478 tree43478 = true := by decide +kernel

def env43479 : List Nat := [2,4,8,16,32,16,9,4,512,53,561,49,9,32,1,3,48,529,52,0,1,33,17,3,8,17,561,49,48,529,53,32,5,33,32,513]

theorem envBound43479 : H12AffineFastState.Bounded env43479 := by
  intro p hp
  have h : env43479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43476_43479 : H12AffineEnvironment.transform 9 53 env43476 = env43479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43476 == env43479) = true)

theorem identity43479 : scanCanonicalize (H12AffineFastState.compose env43479 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43480 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,42,9,32,1,3,43,522,47,0,1,33,10,3,8,10,554,42,43,522,46,32,5,33,32,513]

theorem envBound43480 : H12AffineFastState.Bounded env43480 := by
  intro p hp
  have h : env43480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43479_43480 : H12AffineEnvironment.transform 3 11 env43479 = env43480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43479 == env43480) = true)

def leafEnv43480 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,42,9,32,1,3,43,522,47,0,1,33,10,3,47,8,1,10,554,42,43,522,46,32,5,33,5,2,32,513,1,1,0]

def active43480 : List Nat := [0,1,2,4,8]

def tree43480 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43480 : H12WitnessSearch.Good tree43480 := H12GlobalWitnessIndex.good

theorem leafIdentity43480 : H12AffineFastState.composeSystem env43480 rootObs = leafEnv43480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43480 rootObs == leafEnv43480) = true)

theorem terminalChecked43480 : H12PackedTerminal.terminalCheckFast leafEnv43480 active43480 tree43480 = true := by decide +kernel

def env43481 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,269,1044,1,263,1028,1573,1025,0,260,33,17,3,268,17,1793,1029,49,1573,1284,32,257,33,1044,513]

theorem envBound43481 : H12AffineFastState.Bounded env43481 := by
  intro p hp
  have h : env43481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43474_43481 : H12AffineEnvironment.transform 10 1793 env43474 = env43481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env43474 == env43481) = true)

theorem identity43481 : scanCanonicalize (H12AffineFastState.compose env43481 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43482 : List Nat := [2,4,8,16,32,16,9,256,512,21,788,48,269,1,1,263,17,560,20,0,260,33,17,3,268,17,788,16,49,560,273,32,257,33,1,513]

theorem envBound43482 : H12AffineFastState.Bounded env43482 := by
  intro p hp
  have h : env43482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43481_43482 : H12AffineEnvironment.transform 9 21 env43481 = env43482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43481 == env43482) = true)

def env43483 : List Nat := [2,4,8,16,0,16,9,256,512,21,788,16,269,1,1,263,17,528,20,0,260,1,17,3,268,17,788,16,17,528,273,0,257,1,1,513]

theorem envBound43483 : H12AffineFastState.Bounded env43483 := by
  intro p hp
  have h : env43483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43482_43483 : H12AffineEnvironment.transform 4 0 env43482 = env43483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43482 == env43483) = true)

theorem identity43483 : scanCanonicalize (H12AffineFastState.compose env43483 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43484 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,10,269,1,1,263,11,522,14,0,260,1,11,3,268,11,782,10,11,522,267,0,257,1,1,513]

theorem envBound43484 : H12AffineFastState.Bounded env43484 := by
  intro p hp
  have h : env43484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43483_43484 : H12AffineEnvironment.transform 3 10 env43483 = env43484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43483 == env43484) = true)

def leafEnv43484 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,10,269,1,1,263,11,522,14,0,260,1,11,3,266,268,1,11,782,10,11,522,267,0,257,1,5,262,1,513,1,260,0]

def active43484 : List Nat := [0,1,2,7,8]

def tree43484 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43484 : H12WitnessSearch.Good tree43484 := H12GlobalWitnessIndex.good

theorem leafIdentity43484 : H12AffineFastState.composeSystem env43484 rootObs = leafEnv43484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43484 rootObs == leafEnv43484) = true)

theorem terminalChecked43484 : H12PackedTerminal.terminalCheckFast leafEnv43484 active43484 tree43484 = true := by decide +kernel

def env43485 : List Nat := [2,4,8,16,1,16,9,256,512,21,788,17,269,1,1,263,17,529,20,0,260,0,17,3,268,17,788,16,16,529,273,1,257,0,1,513]

theorem envBound43485 : H12AffineFastState.Bounded env43485 := by
  intro p hp
  have h : env43485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43482_43485 : H12AffineEnvironment.transform 4 1 env43482 = env43485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43482 == env43485) = true)

theorem identity43485 : scanCanonicalize (H12AffineFastState.compose env43485 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound43485 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43486 : List Nat := [2,4,8,16,1,16,9,256,277,21,1,17,269,1,1,263,17,260,20,0,260,0,17,3,268,17,1,16,16,260,273,1,257,0,1,276]

theorem envBound43486 : H12AffineFastState.Bounded env43486 := by
  intro p hp
  have h : env43486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43485_43486 : H12AffineEnvironment.transform 8 277 env43485 = env43486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env43485 == env43486) = true)

def leafEnv43486 : List Nat := [2,4,8,16,1,16,9,256,277,21,1,17,269,1,1,263,17,260,20,0,260,0,17,3,272,268,1,17,1,16,16,260,273,1,257,0,5,262,1,276,1,260,0]

def active43486 : List Nat := [0,1,2,3,7]

def tree43486 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43486 : H12WitnessSearch.Good tree43486 := H12GlobalWitnessIndex.good

theorem leafIdentity43486 : H12AffineFastState.composeSystem env43486 rootObs = leafEnv43486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43486 rootObs == leafEnv43486) = true)

theorem terminalChecked43486 : H12PackedTerminal.terminalCheckFast leafEnv43486 active43486 tree43486 = true := by decide +kernel

def env43487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,4194304,17,41311,8193,65,4262262,115014,45404,43048,75102,4268042,257,98678,90203,513]

theorem envBound43487 : H12AffineFastState.Bounded env43487 := by
  intro p hp
  have h : env43487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43453_43487 : H12AffineEnvironment.transform 20 58397 env43453 = env43487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env43453 == env43487) = true)

theorem identity43487 : scanCanonicalize (H12AffineFastState.compose env43487 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound43487 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env43488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,41340,17,41311,8193,65,108554,115014,45404,43048,75102,98678,257,98678,90203,513]

theorem envBound43488 : H12AffineFastState.Bounded env43488 := by
  intro p hp
  have h : env43488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43487_43488 : H12AffineEnvironment.transform 21 41340 env43487 = env43488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env43487 == env43488) = true)

theorem identity43488 : scanCanonicalize (H12AffineFastState.compose env43488 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43488 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env43489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,58397,41340,17,41311,8193,65,34817,57677,45404,43048,1365,41341,257,41341,16464,513]

theorem envBound43489 : H12AffineFastState.Bounded env43489 := by
  intro p hp
  have h : env43489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43488_43489 : H12AffineEnvironment.transform 15 8203 env43488 = env43489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43488 == env43489) = true)

theorem identity43489 : scanCanonicalize (H12AffineFastState.compose env43489 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43489 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,16400,2421,1025,32769,50497,32800,17,32771,349,65,34817,49169,36864,35188,1365,32801,257,32801,16464,513]

theorem envBound43490 : H12AffineFastState.Bounded env43490 := by
  intro p hp
  have h : env43490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43489_43490 : H12AffineEnvironment.transform 12 348 env43489 = env43490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43489 == env43490) = true)

theorem identity43490 : scanCanonicalize (H12AffineFastState.compose env43490 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43490 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,343,16400,2421,1025,1,17729,32,17,3,349,65,2049,16401,4096,2420,1365,33,257,33,16464,513]

theorem envBound43491 : H12AffineFastState.Bounded env43491 := by
  intro p hp
  have h : env43491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43490_43491 : H12AffineEnvironment.transform 14 0 env43490 = env43491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43490 == env43491) = true)

theorem identity43491 : scanCanonicalize (H12AffineFastState.compose env43491 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound43491 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,603,4096,348,16384,0,343,16400,814,1025,1,17729,32,17,3,349,65,602,16401,4096,815,1365,33,257,33,16464,513]

theorem envBound43492 : H12AffineFastState.Bounded env43492 := by
  intro p hp
  have h : env43492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43491_43492 : H12AffineEnvironment.transform 10 603 env43491 = env43492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env43491 == env43492) = true)

theorem identity43492 : scanCanonicalize (H12AffineFastState.compose env43492 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43492 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,603,4096,348,5377,0,343,5393,814,1025,1,4160,32,17,3,349,65,602,5392,4096,815,1365,33,257,33,5457,513]

theorem envBound43493 : H12AffineFastState.Bounded env43493 := by
  intro p hp
  have h : env43493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43492_43493 : H12AffineEnvironment.transform 13 5377 env43492 = env43493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43492 == env43493) = true)

theorem identity43493 : scanCanonicalize (H12AffineFastState.compose env43493 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound43493 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env43494 : List Nat := [2,4,8,16,32,64,9,116,512,1024,603,4096,40,5237,0,35,5221,602,1025,1,4160,32,17,3,41,65,602,5220,4096,603,1057,33,117,33,5157,513]

theorem envBound43494 : H12AffineFastState.Bounded env43494 := by
  intro p hp
  have h : env43494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43493_43494 : H12AffineEnvironment.transform 7 116 env43493 = env43494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env43493 == env43494) = true)

theorem identity43494 : scanCanonicalize (H12AffineFastState.compose env43494 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound43494 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43495 : List Nat := [2,4,8,16,32,64,9,116,512,622,603,4096,40,4635,0,35,4619,602,623,1,4160,32,17,3,41,65,602,4618,4096,603,591,33,117,33,4683,513]

theorem envBound43495 : H12AffineFastState.Bounded env43495 := by
  intro p hp
  have h : env43495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43494_43495 : H12AffineEnvironment.transform 9 622 env43494 = env43495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env43494 == env43495) = true)

theorem identity43495 : scanCanonicalize (H12AffineFastState.compose env43495 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound43495 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env43496 : List Nat := [2,4,8,16,32,64,9,116,42,68,113,4096,40,4145,0,35,4129,112,69,1,4160,32,17,3,41,65,112,4128,4096,113,101,33,117,33,4193,43]

theorem envBound43496 : H12AffineFastState.Bounded env43496 := by
  intro p hp
  have h : env43496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43495_43496 : H12AffineEnvironment.transform 8 42 env43495 = env43496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env43495 == env43496) = true)

theorem identity43496 : scanCanonicalize (H12AffineFastState.compose env43496 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 56) := by decide +kernel

theorem selectedBound43496 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43497 : List Nat := [2,4,8,16,32,56,9,12,42,60,9,4096,40,4145,0,35,4129,8,61,1,4152,32,17,3,41,57,8,4128,4096,9,29,33,13,33,4121,43]

theorem envBound43497 : H12AffineFastState.Bounded env43497 := by
  intro p hp
  have h : env43497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43496_43497 : H12AffineEnvironment.transform 5 56 env43496 = env43497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 56 env43496 == env43497) = true)

theorem identity43497 : scanCanonicalize (H12AffineFastState.compose env43497 (packedSelected [1,11] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound43497 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env43498 : List Nat := [2,4,8,16,8,16,9,12,2,20,9,4096,0,4121,0,11,4105,8,21,1,4112,8,17,3,1,17,8,4104,4096,9,29,9,13,9,4121,3]

theorem envBound43498 : H12AffineFastState.Bounded env43498 := by
  intro p hp
  have h : env43498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43497_43498 : H12AffineEnvironment.transform 4 8 env43497 = env43498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env43497 == env43498) = true)

theorem identity43498 : scanCanonicalize (H12AffineFastState.compose env43498 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 25) := by decide +kernel

theorem selectedBound43498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43499 : List Nat := [2,4,8,16,8,16,9,12,2,20,9,25,0,0,0,11,16,8,21,1,9,8,17,3,1,17,8,17,25,9,29,9,13,9,0,3]

theorem envBound43499 : H12AffineFastState.Bounded env43499 := by
  intro p hp
  have h : env43499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43498_43499 : H12AffineEnvironment.transform 11 25 env43498 = env43499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 25 env43498 == env43499) = true)

theorem identity43499 : scanCanonicalize (H12AffineFastState.compose env43499 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43500 : List Nat := [2,2,8,16,8,16,9,10,2,18,9,25,0,0,0,11,16,8,19,1,9,8,17,3,1,17,8,17,25,9,27,9,11,9,0,3]

theorem envBound43500 : H12AffineFastState.Bounded env43500 := by
  intro p hp
  have h : env43500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43499_43500 : H12AffineEnvironment.transform 1 2 env43499 = env43500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43499 == env43500) = true)

theorem identity43500 : scanCanonicalize (H12AffineFastState.compose env43500 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound43500 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43501 : List Nat := [2,2,0,16,0,16,1,2,2,18,1,17,0,0,0,3,16,0,19,1,1,0,17,3,1,17,0,17,17,1,19,1,3,1,0,3]

theorem envBound43501 : H12AffineFastState.Bounded env43501 := by
  intro p hp
  have h : env43501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43500_43501 : H12AffineEnvironment.transform 2 0 env43500 = env43501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env43500 == env43501) = true)

def env43502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650854,2428274,10507600,8683537,8719718,6679614,257,10833235,10857598,8661561]

theorem envBound43502 : H12AffineFastState.Bounded env43502 := by
  intro p hp
  have h : env43502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43435_43502 : H12AffineEnvironment.transform 16 16401 env43435 = env43502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43435 == env43502) = true)

theorem identity43502 : scanCanonicalize (H12AffineFastState.compose env43502 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound43502 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,297334,8193,65,4262263,2428274,2118977,294912,331127,6679614,257,2444610,2468975,272936]

theorem envBound43503 : H12AffineFastState.Bounded env43503 := by
  intro p hp
  have h : env43503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43502_43503 : H12AffineEnvironment.transform 22 17 env43502 = env43503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env43502 == env43503) = true)

def env43504 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,17,41310,8193,65,4262263,2172250,2118977,43048,75103,6407190,257,2188650,2196551,512]

theorem envBound43504 : H12AffineFastState.Bounded env43504 := by
  intro p hp
  have h : env43504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43503_43504 : H12AffineEnvironment.transform 17 10280 env43503 = env43504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43503 == env43504) = true)

theorem identity43504 : scanCanonicalize (H12AffineFastState.compose env43504 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 116066) := by decide +kernel

theorem selectedBound43504 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,116066,4194304,17,41310,8193,65,4262263,57400,102435,43048,75103,4194676,257,40968,16677,512]

theorem envBound43505 : H12AffineFastState.Bounded env43505 := by
  intro p hp
  have h : env43505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43504_43505 : H12AffineEnvironment.transform 20 116066 env43504 = env43505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 116066 env43504 == env43505) = true)

theorem identity43505 : scanCanonicalize (H12AffineFastState.compose env43505 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound43505 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env43506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,10280,1025,32769,17461,4194304,17,41310,8193,65,4229152,57400,4468,43048,41992,4194676,257,40968,16677,512]

theorem envBound43506 : H12AffineFastState.Bounded env43506 := by
  intro p hp
  have h : env43506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43505_43506 : H12AffineEnvironment.transform 15 33111 env43505 = env43506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env43505 == env43506) = true)

theorem identity43506 : scanCanonicalize (H12AffineFastState.compose env43506 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 26665) := by decide +kernel

theorem selectedBound43506 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,10280,1025,32769,17461,26665,17,41310,8193,65,57353,57400,4468,43048,41992,26973,257,40968,16677,512]

theorem envBound43507 : H12AffineFastState.Bounded env43507 := by
  intro p hp
  have h : env43507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43506_43507 : H12AffineEnvironment.transform 21 26665 env43506 = env43507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 26665 env43506 == env43507) = true)

theorem identity43507 : scanCanonicalize (H12AffineFastState.compose env43507 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13436) := by decide +kernel

theorem selectedBound43507 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env43508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13436,32768,33111,13421,10280,1025,32769,12361,7253,17,41310,8193,65,38005,37956,4468,43048,41992,7457,257,40968,13657,512]

theorem envBound43508 : H12AffineFastState.Bounded env43508 := by
  intro p hp
  have h : env43508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43507_43508 : H12AffineEnvironment.transform 13 13436 env43507 = env43508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13436 env43507 == env43508) = true)

theorem identity43508 : scanCanonicalize (H12AffineFastState.compose env43508 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 6160) := by decide +kernel

theorem selectedBound43508 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13436,6160,6471,13421,10280,1025,6161,12361,7253,17,14670,8193,65,3173,3156,4468,12344,15384,7457,257,14360,13657,512]

theorem envBound43509 : H12AffineFastState.Bounded env43509 := by
  intro p hp
  have h : env43509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43508_43509 : H12AffineEnvironment.transform 14 6160 env43508 = env43509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6160 env43508 == env43509) = true)

theorem identity43509 : scanCanonicalize (H12AffineFastState.compose env43509 (packedSelected [9,14,22] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound43509 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env43510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,8192,10249,1125,1330,10264,10280,1025,1124,11324,32,17,9531,8193,65,3173,3156,3329,11341,8301,340,257,9325,10540,512]

theorem envBound43510 : H12AffineFastState.Bounded env43510 := by
  intro p hp
  have h : env43510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43509_43510 : H12AffineEnvironment.transform 11 3189 env43509 = env43510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env43509 == env43510) = true)

theorem identity43510 : scanCanonicalize (H12AffineFastState.compose env43510 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound43510 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env43511 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,3077,8192,10249,1045,1330,10264,10280,1025,1044,11324,32,17,9531,8193,49,3093,3108,3329,11325,8221,292,257,9245,10540,512]

theorem envBound43511 : H12AffineFastState.Bounded env43511 := by
  intro p hp
  have h : env43511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43510_43511 : H12AffineEnvironment.transform 5 48 env43510 = env43511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env43510 == env43511) = true)

theorem identity43511 : scanCanonicalize (H12AffineFastState.compose env43511 (packedSelected [3,5,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound43511 : packedSelected [3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env43512 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,3077,9,2048,1045,1330,2065,2081,1025,1044,3125,32,17,1330,8,49,3093,3108,3329,3124,20,292,257,1044,2341,512]

theorem envBound43512 : H12AffineFastState.Bounded env43512 := by
  intro p hp
  have h : env43512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43511_43512 : H12AffineEnvironment.transform 12 9 env43511 = env43512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env43511 == env43512) = true)

theorem identity43512 : scanCanonicalize (H12AffineFastState.compose env43512 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43512 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env43513 : List Nat := [2,4,8,16,32,48,9,256,512,272,2048,2325,9,2048,261,34,2065,2081,273,260,2341,32,17,34,8,49,2309,2356,2065,2340,20,292,257,260,2341,512]

theorem envBound43513 : H12AffineFastState.Bounded env43513 := by
  intro p hp
  have h : env43513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43512_43513 : H12AffineEnvironment.transform 9 272 env43512 = env43513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43512 == env43513) = true)

theorem identity43513 : scanCanonicalize (H12AffineFastState.compose env43513 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43513 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43514 : List Nat := [2,4,8,16,32,48,9,5,512,21,2048,2064,9,2048,0,34,2065,2081,20,1,2080,32,17,34,8,49,2048,2097,2065,2081,20,33,4,1,2080,512]

theorem envBound43514 : H12AffineFastState.Bounded env43514 := by
  intro p hp
  have h : env43514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43513_43514 : H12AffineEnvironment.transform 7 5 env43513 = env43514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43513 == env43514) = true)

theorem identity43514 : scanCanonicalize (H12AffineFastState.compose env43514 (packedSelected [2,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43514 : packedSelected [2,15] rootPS < 2^1333 := by decide +kernel

def env43515 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2064,9,2048,0,3,2065,2048,20,1,2049,1,17,3,8,16,2048,2064,2065,2048,20,0,4,1,2049,512]

theorem envBound43515 : H12AffineFastState.Bounded env43515 := by
  intro p hp
  have h : env43515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43514_43515 : H12AffineEnvironment.transform 4 1 env43514 = env43515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43514 == env43515) = true)

theorem identity43515 : scanCanonicalize (H12AffineFastState.compose env43515 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43516 : List Nat := [2,4,8,16,1,17,9,5,1,21,2048,2064,9,2048,0,3,2065,2048,20,1,2049,1,17,3,8,16,2048,2064,2065,2048,20,0,4,1,2049,1]

theorem envBound43516 : H12AffineFastState.Bounded env43516 := by
  intro p hp
  have h : env43516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43515_43516 : H12AffineEnvironment.transform 8 1 env43515 = env43516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43515 == env43516) = true)

theorem identity43516 : scanCanonicalize (H12AffineFastState.compose env43516 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound43516 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43517 : List Nat := [2,4,8,16,1,17,9,5,1,21,31,15,9,31,0,3,14,31,20,1,30,1,17,3,8,16,31,15,14,31,20,0,4,1,30,1]

theorem envBound43517 : H12AffineFastState.Bounded env43517 := by
  intro p hp
  have h : env43517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43516_43517 : H12AffineEnvironment.transform 10 31 env43516 = env43517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env43516 == env43517) = true)

def leafEnv43517 : List Nat := [2,4,8,16,1,17,9,5,1,21,31,15,9,31,0,3,14,31,20,1,30,1,17,3,21,8,1,16,31,15,14,31,20,0,4,1,5,2,30,1,1,31,0]

def active43517 : List Nat := [0,1,2,3]

def tree43517 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43517 : H12WitnessSearch.Good tree43517 := H12GlobalWitnessIndex.good

theorem leafIdentity43517 : H12AffineFastState.composeSystem env43517 rootObs = leafEnv43517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43517 rootObs == leafEnv43517) = true)

theorem terminalChecked43517 : H12PackedTerminal.terminalCheckFast leafEnv43517 active43517 tree43517 = true := by decide +kernel

def env43518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41311,8193,65,4262263,2172251,2118977,43049,75102,6407191,257,2188651,2196550,513]

theorem envBound43518 : H12AffineFastState.Bounded env43518 := by
  intro p hp
  have h : env43518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43503_43518 : H12AffineEnvironment.transform 17 10281 env43503 = env43518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43503 == env43518) = true)

theorem identity43518 : scanCanonicalize (H12AffineFastState.compose env43518 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound43518 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env43519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115734,4194304,17,41311,8193,65,4262263,57677,102743,43049,75102,4194305,257,41341,16464,513]

theorem envBound43519 : H12AffineFastState.Bounded env43519 := by
  intro p hp
  have h : env43519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43518_43519 : H12AffineEnvironment.transform 20 115734 env43518 = env43519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env43518 == env43519) = true)

theorem identity43519 : scanCanonicalize (H12AffineFastState.compose env43519 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound43519 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env43520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115734,8573,17,41311,8193,65,75786,57677,102743,43049,75102,8572,257,41341,16464,513]

theorem envBound43520 : H12AffineFastState.Bounded env43520 := by
  intro p hp
  have h : env43520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43519_43520 : H12AffineEnvironment.transform 21 8573 env43519 = env43520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env43519 == env43520) = true)

theorem identity43520 : scanCanonicalize (H12AffineFastState.compose env43520 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound43520 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env43521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1025,32769,25629,8573,17,41311,8193,65,34817,57677,12636,43049,34133,8572,257,41341,16464,513]

theorem envBound43521 : H12AffineFastState.Bounded env43521 := by
  intro p hp
  have h : env43521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43520_43521 : H12AffineEnvironment.transform 15 40971 env43520 = env43521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env43520 == env43521) = true)

theorem identity43521 : scanCanonicalize (H12AffineFastState.compose env43521 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43521 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43522 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1025,32769,25629,8492,17,41230,8193,16,34817,57628,12557,43049,34052,8493,257,41260,16385,513]

theorem envBound43522 : H12AffineFastState.Bounded env43522 := by
  intro p hp
  have h : env43522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43521_43522 : H12AffineEnvironment.transform 5 17 env43521 = env43522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43521 == env43522) = true)

theorem identity43522 : scanCanonicalize (H12AffineFastState.compose env43522 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43522 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43523 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,33031,16401,2341,1025,32769,17681,32,17,32770,269,16,34817,49168,4097,35109,34052,33,257,32800,16385,513]

theorem envBound43523 : H12AffineFastState.Bounded env43523 := by
  intro p hp
  have h : env43523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43522_43523 : H12AffineEnvironment.transform 12 268 env43522 = env43523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43522 == env43523) = true)

theorem identity43523 : scanCanonicalize (H12AffineFastState.compose env43523 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43523 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43524 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,263,16401,2341,1025,1,17681,32,17,2,269,16,2049,16400,4097,2341,1284,33,257,32,16385,513]

theorem envBound43524 : H12AffineFastState.Bounded env43524 := by
  intro p hp
  have h : env43524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43523_43524 : H12AffineEnvironment.transform 14 0 env43523 = env43524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43523 == env43524) = true)

theorem identity43524 : scanCanonicalize (H12AffineFastState.compose env43524 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4389) := by decide +kernel

theorem selectedBound43524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43525 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4389,0,263,4404,2341,1025,1,5172,32,17,2,269,16,2049,4405,4097,2341,1284,33,257,32,4388,513]

theorem envBound43525 : H12AffineFastState.Bounded env43525 := by
  intro p hp
  have h : env43525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43524_43525 : H12AffineEnvironment.transform 13 4389 env43524 = env43525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4389 env43524 == env43525) = true)

theorem identity43525 : scanCanonicalize (H12AffineFastState.compose env43525 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound43525 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43526 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,512,268,805,0,263,820,2341,1025,1,1588,32,17,2,269,16,2049,821,513,2341,1284,33,257,32,804,513]

theorem envBound43526 : H12AffineFastState.Bounded env43526 := by
  intro p hp
  have h : env43526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43525_43526 : H12AffineEnvironment.transform 11 512 env43525 = env43526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env43525 == env43526) = true)

theorem identity43526 : scanCanonicalize (H12AffineFastState.compose env43526 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound43526 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43527 : List Nat := [2,4,8,16,32,17,9,256,512,768,2048,512,268,805,0,263,820,2341,769,1,308,32,17,2,269,16,2049,821,513,2341,516,33,257,32,804,513]

theorem envBound43527 : H12AffineFastState.Bounded env43527 := by
  intro p hp
  have h : env43527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43526_43527 : H12AffineEnvironment.transform 9 768 env43526 = env43527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env43526 == env43527) = true)

theorem identity43527 : scanCanonicalize (H12AffineFastState.compose env43527 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound43527 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43528 : List Nat := [2,4,8,16,32,17,9,52,512,564,2048,512,56,529,0,51,512,2065,565,1,0,32,17,2,57,16,2049,513,513,2065,516,33,53,32,528,513]

theorem envBound43528 : H12AffineFastState.Bounded env43528 := by
  intro p hp
  have h : env43528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43527_43528 : H12AffineEnvironment.transform 7 52 env43527 = env43528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env43527 == env43528) = true)

theorem identity43528 : scanCanonicalize (H12AffineFastState.compose env43528 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound43528 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43529 : List Nat := [2,4,8,16,32,17,9,52,512,564,16,512,56,529,0,51,512,1,565,1,0,32,17,2,57,16,17,513,513,1,516,33,53,32,528,513]

theorem envBound43529 : H12AffineFastState.Bounded env43529 := by
  intro p hp
  have h : env43529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43528_43529 : H12AffineEnvironment.transform 10 16 env43528 = env43529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env43528 == env43529) = true)

theorem identity43529 : scanCanonicalize (H12AffineFastState.compose env43529 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound43529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43530 : List Nat := [2,4,8,16,32,17,9,52,32,20,16,32,56,49,0,51,32,1,21,1,0,32,17,2,57,16,17,33,33,1,36,33,53,32,48,33]

theorem envBound43530 : H12AffineFastState.Bounded env43530 := by
  intro p hp
  have h : env43530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43529_43530 : H12AffineEnvironment.transform 8 32 env43529 = env43530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env43529 == env43530) = true)

def env43531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound43531 : H12AffineFastState.Bounded env43531 := by
  intro p hp
  have h : env43531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43221_43531 : H12AffineEnvironment.transform 26 30393345 env43221 = env43531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env43221 == env43531) = true)

def env43532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound43532 : H12AffineFastState.Bounded env43532 := by
  intro p hp
  have h : env43532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43531_43532 : H12AffineEnvironment.transform 18 1024 env43531 = env43532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env43531 == env43532) = true)

theorem identity43532 : scanCanonicalize (H12AffineFastState.compose env43532 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882238) := by decide +kernel

theorem selectedBound43532 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882238,8328,65,6409407,8882226,10507600,8830976,2590894,13068670,256,509970,469430,2535289]

theorem envBound43533 : H12AffineFastState.Bounded env43533 := by
  intro p hp
  have h : env43533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43532_43533 : H12AffineEnvironment.transform 23 10882238 env43532 = env43533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882238 env43532 == env43533) = true)

def env43534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412156,2114882,8328,65,6409407,115150,2497708,35324,2590894,4268162,256,509970,469430,2535289]

theorem envBound43534 : H12AffineFastState.Bounded env43534 := by
  intro p hp
  have h : env43534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43533_43534 : H12AffineEnvironment.transform 22 412156 env43533 = env43534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412156 env43533 == env43534) = true)

def env43535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412156,2114882,8328,65,215367,115150,2497708,35324,2590894,2336122,256,509970,469430,2535289]

theorem envBound43535 : H12AffineFastState.Bounded env43535 := by
  intro p hp
  have h : env43535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43534_43535 : H12AffineEnvironment.transform 21 2262520 env43534 = env43535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env43534 == env43535) = true)

def env43536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,21762,8328,65,215367,115150,396524,35324,497902,243002,256,509970,469430,442169]

theorem envBound43536 : H12AffineFastState.Bounded env43536 := by
  intro p hp
  have h : env43536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43535_43536 : H12AffineEnvironment.transform 20 4160 env43535 = env43536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43535 == env43536) = true)

theorem identity43536 : scanCanonicalize (H12AffineFastState.compose env43536 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound43536 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,169400,16,21762,8328,65,215367,115150,17664,35324,119042,243002,256,98814,90202,63189]

theorem envBound43537 : H12AffineFastState.Bounded env43537 := by
  intro p hp
  have h : env43537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43536_43537 : H12AffineEnvironment.transform 17 149996 env43536 = env43537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env43536 == env43537) = true)

def env43538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169264,16,21762,8192,65,215367,115014,17664,35188,119042,243002,256,98678,90202,63069]

theorem envBound43538 : H12AffineFastState.Bounded env43538 := by
  intro p hp
  have h : env43538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43537_43538 : H12AffineEnvironment.transform 6 8 env43537 = env43538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43537 == env43538) = true)

theorem identity43538 : scanCanonicalize (H12AffineFastState.compose env43538 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound43538 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4160,21793,16,21762,8192,65,100694,115014,17664,35188,119042,95531,256,98678,90202,63069]

theorem envBound43539 : H12AffineFastState.Bounded env43539 := by
  intro p hp
  have h : env43539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43538_43539 : H12AffineEnvironment.transform 16 49169 env43538 = env43539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43538 == env43539) = true)

theorem identity43539 : scanCanonicalize (H12AffineFastState.compose env43539 (packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 54563) := by decide +kernel

theorem selectedBound43539 : packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env43540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54563,49169,35189,1024,32769,4160,21793,16,21762,8192,65,23669,5221,17664,35188,1057,40968,256,21589,46457,63069]

theorem envBound43540 : H12AffineFastState.Bounded env43540 := by
  intro p hp
  have h : env43540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43539_43540 : H12AffineEnvironment.transform 15 54563 env43539 = env43540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54563 env43539 == env43540) = true)

theorem identity43540 : scanCanonicalize (H12AffineFastState.compose env43540 (packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43540 : packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env43541 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,49169,34816,1024,32769,4160,21588,16,21623,8192,65,23669,5221,17525,34817,1057,40968,117,21589,46092,63069]

theorem envBound43541 : H12AffineFastState.Bounded env43541 := by
  intro p hp
  have h : env43541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43540_43541 : H12AffineEnvironment.transform 7 117 env43540 = env43541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43540 == env43541) = true)

theorem identity43541 : scanCanonicalize (H12AffineFastState.compose env43541 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43541 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43542 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,32768,54358,49169,34816,1024,32769,4160,21588,16,21623,40,65,23669,5221,17525,34817,1057,32800,117,21589,37924,54901]

theorem envBound43542 : H12AffineFastState.Bounded env43542 := by
  intro p hp
  have h : env43542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43541_43542 : H12AffineEnvironment.transform 12 40 env43541 = env43542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43541 == env43542) = true)

theorem identity43542 : scanCanonicalize (H12AffineFastState.compose env43542 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43542 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43543 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,16384,32768,54358,49169,34816,1024,32769,4160,21588,16,21590,9,65,23636,5188,17492,34817,1024,32769,84,21589,37893,54868]

theorem envBound43543 : H12AffineFastState.Bounded env43543 := by
  intro p hp
  have h : env43543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43542_43543 : H12AffineEnvironment.transform 4 1 env43542 = env43543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43542 == env43543) = true)

theorem identity43543 : scanCanonicalize (H12AffineFastState.compose env43543 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21589) := by decide +kernel

theorem selectedBound43543 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43544 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,16384,21589,3,5188,23637,1024,21588,4160,21588,16,21590,9,65,23636,5188,17492,23636,1024,21588,84,21589,16464,513]

theorem envBound43544 : H12AffineFastState.Bounded env43544 := by
  intro p hp
  have h : env43544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43543_43544 : H12AffineEnvironment.transform 14 21589 env43543 = env43544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21589 env43543 == env43544) = true)

theorem identity43544 : scanCanonicalize (H12AffineFastState.compose env43544 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound43544 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43545 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5124,81,3,5188,2129,1024,80,4160,80,16,82,9,65,2128,5188,4176,2128,1024,80,84,81,5204,513]

theorem envBound43545 : H12AffineFastState.Bounded env43545 := by
  intro p hp
  have h : env43545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43544_43545 : H12AffineEnvironment.transform 13 5124 env43544 = env43545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env43544 == env43545) = true)

theorem identity43545 : scanCanonicalize (H12AffineFastState.compose env43545 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound43545 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env43546 : List Nat := [2,4,8,16,1,64,8,84,512,1024,576,4096,9,5124,81,3,5188,529,1024,80,4160,80,16,82,9,65,528,5188,4176,528,1024,80,84,81,5204,513]

theorem envBound43546 : H12AffineFastState.Bounded env43546 := by
  intro p hp
  have h : env43546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43545_43546 : H12AffineEnvironment.transform 10 576 env43545 = env43546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env43545 == env43546) = true)

theorem identity43546 : scanCanonicalize (H12AffineFastState.compose env43546 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43546 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43547 : List Nat := [2,4,8,16,1,16,8,4,512,1024,528,4096,9,5124,1,3,5140,529,1024,0,4112,0,16,2,9,17,528,5140,4096,528,1024,0,4,1,5124,513]

theorem envBound43547 : H12AffineFastState.Bounded env43547 := by
  intro p hp
  have h : env43547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43546_43547 : H12AffineEnvironment.transform 5 16 env43546 = env43547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43546 == env43547) = true)

theorem identity43547 : scanCanonicalize (H12AffineFastState.compose env43547 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound43547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43548 : List Nat := [2,4,8,16,1,16,8,4,512,1024,528,1045,9,17,1,3,1,529,1024,0,1029,0,16,2,9,17,528,1,1045,528,1024,0,4,1,17,513]

theorem envBound43548 : H12AffineFastState.Bounded env43548 := by
  intro p hp
  have h : env43548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43547_43548 : H12AffineEnvironment.transform 11 1045 env43547 = env43548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env43547 == env43548) = true)

theorem identity43548 : scanCanonicalize (H12AffineFastState.compose env43548 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound43548 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43549 : List Nat := [2,4,8,16,1,16,8,4,512,517,528,528,9,17,1,3,1,529,517,0,512,0,16,2,9,17,528,1,528,528,517,0,4,1,17,513]

theorem envBound43549 : H12AffineFastState.Bounded env43549 := by
  intro p hp
  have h : env43549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43548_43549 : H12AffineEnvironment.transform 9 517 env43548 = env43549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env43548 == env43549) = true)

theorem identity43549 : scanCanonicalize (H12AffineFastState.compose env43549 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43549 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43550 : List Nat := [2,4,8,16,1,16,8,4,0,5,16,16,9,17,1,3,1,17,5,0,0,0,16,2,9,17,16,1,16,16,5,0,4,1,17,1]

theorem envBound43550 : H12AffineFastState.Bounded env43550 := by
  intro p hp
  have h : env43550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43549_43550 : H12AffineEnvironment.transform 8 0 env43549 = env43550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43549 == env43550) = true)

theorem identity43550 : scanCanonicalize (H12AffineFastState.compose env43550 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43550 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43551 : List Nat := [2,4,8,0,1,0,8,4,0,5,0,0,9,1,1,3,1,1,5,0,0,0,0,2,9,1,0,1,0,0,5,0,4,1,1,1]

theorem envBound43551 : H12AffineFastState.Bounded env43551 := by
  intro p hp
  have h : env43551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43550_43551 : H12AffineEnvironment.transform 3 0 env43550 = env43551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43550 == env43551) = true)

theorem identity43551 : scanCanonicalize (H12AffineFastState.compose env43551 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43551 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43552 : List Nat := [2,4,3,0,1,0,3,4,0,5,0,0,2,1,1,3,1,1,5,0,0,0,0,2,2,1,0,1,0,0,5,0,4,1,1,1]

theorem envBound43552 : H12AffineFastState.Bounded env43552 := by
  intro p hp
  have h : env43552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43551_43552 : H12AffineEnvironment.transform 2 3 env43551 = env43552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43551 == env43552) = true)

def env43553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,21762,8193,65,215367,115015,17664,35189,119042,243002,256,98679,90202,63068]

theorem envBound43553 : H12AffineFastState.Bounded env43553 := by
  intro p hp
  have h : env43553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43537_43553 : H12AffineEnvironment.transform 6 9 env43537 = env43553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43537 == env43553) = true)

theorem identity43553 : scanCanonicalize (H12AffineFastState.compose env43553 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound43553 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1024,32769,4160,62589,16,21762,8193,65,75787,115015,17664,35189,119042,119926,256,98679,90202,63068]

theorem envBound43554 : H12AffineFastState.Bounded env43554 := by
  intro p hp
  have h : env43554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43553_43554 : H12AffineEnvironment.transform 16 24908 env43553 = env43554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env43553 == env43554) = true)

theorem identity43554 : scanCanonicalize (H12AffineFastState.compose env43554 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43554 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13389,10281,1024,32769,4160,41340,16,3,8193,65,75787,103494,4097,35189,99331,98679,256,98679,79195,41821]

theorem envBound43555 : H12AffineFastState.Bounded env43555 := by
  intro p hp
  have h : env43555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43554_43555 : H12AffineEnvironment.transform 13 5377 env43554 = env43555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43554 == env43555) = true)

theorem identity43555 : scanCanonicalize (H12AffineFastState.compose env43555 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43555 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env43556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,65536,5393,2421,1024,32769,4160,32800,16,3,349,65,67927,103494,4097,35189,99331,98679,256,98679,70663,33281]

theorem envBound43556 : H12AffineFastState.Bounded env43556 := by
  intro p hp
  have h : env43556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43555_43556 : H12AffineEnvironment.transform 12 348 env43555 = env43556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43555 == env43556) = true)

theorem identity43556 : scanCanonicalize (H12AffineFastState.compose env43556 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound43556 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,342,5393,2421,1024,32769,4160,32800,16,3,349,65,2049,38160,4097,35189,34133,32801,256,32801,5457,33281]

theorem envBound43557 : H12AffineFastState.Bounded env43557 := by
  intro p hp
  have h : env43557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43556_43557 : H12AffineEnvironment.transform 15 342 env43556 = env43557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env43556 == env43557) = true)

theorem identity43557 : scanCanonicalize (H12AffineFastState.compose env43557 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound43557 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,340,342,5393,2421,1024,341,4160,372,16,3,349,65,2049,5188,4097,2081,1025,373,256,373,5457,853]

theorem envBound43558 : H12AffineFastState.Bounded env43558 := by
  intro p hp
  have h : env43558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43557_43558 : H12AffineEnvironment.transform 14 340 env43557 = env43558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env43557 == env43558) = true)

theorem identity43558 : scanCanonicalize (H12AffineFastState.compose env43558 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43558 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env43559 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,5124,81,83,5140,2160,1024,80,4160,113,16,3,88,65,2049,5188,4097,2081,1025,112,5,112,5204,592]

theorem envBound43559 : H12AffineFastState.Bounded env43559 := by
  intro p hp
  have h : env43559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43558_43559 : H12AffineEnvironment.transform 7 5 env43558 = env43559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43558 == env43559) = true)

theorem identity43559 : scanCanonicalize (H12AffineFastState.compose env43559 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound43559 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env43560 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,2096,89,3124,81,83,3108,2160,1024,80,2160,113,16,3,88,65,2049,3188,2097,2081,1025,112,5,112,3172,592]

theorem envBound43560 : H12AffineFastState.Bounded env43560 := by
  intro p hp
  have h : env43560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43559_43560 : H12AffineEnvironment.transform 11 2096 env43559 = env43560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env43559 == env43560) = true)

theorem identity43560 : scanCanonicalize (H12AffineFastState.compose env43560 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound43560 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43561 : List Nat := [2,4,8,16,32,64,9,5,512,1024,113,65,89,1093,81,83,1109,1,1024,80,1,113,16,3,88,65,112,1029,64,80,1025,112,5,112,1045,592]

theorem envBound43561 : H12AffineFastState.Bounded env43561 := by
  intro p hp
  have h : env43561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43560_43561 : H12AffineEnvironment.transform 10 113 env43560 = env43561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env43560 == env43561) = true)

theorem identity43561 : scanCanonicalize (H12AffineFastState.compose env43561 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound43561 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env43562 : List Nat := [2,4,8,16,32,48,9,5,512,1024,1,49,41,1077,33,35,1061,1,1024,32,1,1,16,3,40,49,0,1029,48,32,1025,0,5,0,1045,544]

theorem envBound43562 : H12AffineFastState.Bounded env43562 := by
  intro p hp
  have h : env43562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43561_43562 : H12AffineEnvironment.transform 5 48 env43561 = env43562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env43561 == env43562) = true)

theorem identity43562 : scanCanonicalize (H12AffineFastState.compose env43562 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43562 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43563 : List Nat := [2,4,8,16,1,17,9,5,512,1024,1,16,8,1044,0,2,1028,1,1024,1,1,1,16,3,9,16,0,1029,17,1,1025,0,5,0,1045,513]

theorem envBound43563 : H12AffineFastState.Bounded env43563 := by
  intro p hp
  have h : env43563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43562_43563 : H12AffineEnvironment.transform 4 1 env43562 = env43563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43562 == env43563) = true)

def env43564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,21763,8328,65,215367,115150,396525,35324,497903,243003,256,509970,469430,442168]

theorem envBound43564 : H12AffineFastState.Bounded env43564 := by
  intro p hp
  have h : env43564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43535_43564 : H12AffineEnvironment.transform 20 4161 env43535 = env43564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43535 == env43564) = true)

theorem identity43564 : scanCanonicalize (H12AffineFastState.compose env43564 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound43564 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,156012,412156,21763,8328,65,215367,79131,396525,32041,486458,213486,256,474311,469430,412653]

theorem envBound43565 : H12AffineFastState.Bounded env43565 := by
  intro p hp
  have h : env43565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43564_43565 : H12AffineEnvironment.transform 14 29909 env43564 = env43565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env43564 == env43565) = true)

def env43566 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4113,155964,412076,21763,8328,17,215319,79131,396477,32041,486458,213438,256,474263,469430,412605]

theorem envBound43566 : H12AffineFastState.Bounded env43566 := by
  intro p hp
  have h : env43566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43565_43566 : H12AffineEnvironment.transform 5 16 env43565 = env43566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43565 == env43566) = true)

theorem identity43566 : scanCanonicalize (H12AffineFastState.compose env43566 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound43566 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env43567 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,157753,1024,29828,4113,155964,8597,21763,8328,17,215319,79131,25732,32041,66563,213438,256,87214,82319,9092]

theorem envBound43567 : H12AffineFastState.Bounded env43567 := by
  intro p hp
  have h : env43567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43566_43567 : H12AffineEnvironment.transform 17 157753 env43566 = env43567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env43566 == env43567) = true)

theorem identity43567 : scanCanonicalize (H12AffineFastState.compose env43567 (packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound43567 : packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43568 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,262,131072,157753,1024,29828,4113,155964,8597,21763,8328,17,149521,13341,25732,32041,1285,147640,256,21928,16521,9092]

theorem envBound43568 : H12AffineFastState.Bounded env43568 := by
  intro p hp
  have h : env43568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43567_43568 : H12AffineEnvironment.transform 15 262 env43567 = env43568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env43567 == env43568) = true)

theorem identity43568 : scanCanonicalize (H12AffineFastState.compose env43568 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound43568 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env43569 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8461,262,131072,146865,1024,8460,4113,144564,8597,139,8328,17,138649,13341,12556,10401,1285,136496,256,32,5377,9092]

theorem envBound43569 : H12AffineFastState.Bounded env43569 := by
  intro p hp
  have h : env43569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43568_43569 : H12AffineEnvironment.transform 13 5512 env43568 = env43569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env43568 == env43569) = true)

theorem identity43569 : scanCanonicalize (H12AffineFastState.compose env43569 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound43569 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43570 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8461,262,5393,10400,1024,8460,4113,8613,8597,139,8328,17,2184,13341,12556,10401,1285,33,256,32,5377,9092]

theorem envBound43570 : H12AffineFastState.Bounded env43570 := by
  intro p hp
  have h : env43570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43569_43570 : H12AffineEnvironment.transform 16 5393 env43569 = env43570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env43569 == env43570) = true)

theorem identity43570 : scanCanonicalize (H12AffineFastState.compose env43570 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound43570 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env43571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2200,8192,3344,8461,262,3465,10400,1024,8460,2185,8613,8597,139,8328,17,2184,11397,10644,10401,1285,33,256,32,3481,9092]

theorem envBound43571 : H12AffineFastState.Bounded env43571 := by
  intro p hp
  have h : env43571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43570_43571 : H12AffineEnvironment.transform 11 2200 env43570 = env43571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env43570 == env43571) = true)

theorem identity43571 : scanCanonicalize (H12AffineFastState.compose env43571 (packedSelected [0,3,4,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43571 : packedSelected [0,3,4,8,10,12] rootPS < 2^1333 := by decide +kernel

def env43572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,153,8192,1297,8461,262,1416,8353,1024,8460,136,8613,8597,139,8328,17,137,9348,8597,8352,1285,33,256,32,1432,9092]

theorem envBound43572 : H12AffineFastState.Bounded env43572 := by
  intro p hp
  have h : env43572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43571_43572 : H12AffineEnvironment.transform 10 1 env43571 = env43572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43571 == env43572) = true)

theorem identity43572 : scanCanonicalize (H12AffineFastState.compose env43572 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound43572 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env43573 : List Nat := [2,4,8,16,32,16,128,256,512,189,1,153,8192,428,8461,262,309,8353,189,8460,136,8613,8597,139,8328,17,137,8249,8597,8352,440,33,256,32,293,9092]

theorem envBound43573 : H12AffineFastState.Bounded env43573 := by
  intro p hp
  have h : env43573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43572_43573 : H12AffineEnvironment.transform 9 189 env43572 = env43573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env43572 == env43573) = true)

theorem identity43573 : scanCanonicalize (H12AffineFastState.compose env43573 (packedSelected [0,1,3,4,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43573 : packedSelected [0,1,3,4,15] rootPS < 2^1333 := by decide +kernel

def env43574 : List Nat := [2,4,8,16,32,16,128,256,512,189,1,153,269,428,0,262,309,428,189,1,136,168,152,139,389,17,137,308,152,429,440,33,256,32,293,649]

theorem envBound43574 : H12AffineFastState.Bounded env43574 := by
  intro p hp
  have h : env43574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43573_43574 : H12AffineEnvironment.transform 12 269 env43573 = env43574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43573 == env43574) = true)

theorem identity43574 : scanCanonicalize (H12AffineFastState.compose env43574 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43574 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43575 : List Nat := [2,4,8,16,32,16,128,172,512,189,1,153,161,0,0,170,153,0,189,1,136,168,152,139,41,17,137,152,152,1,20,33,172,32,137,649]

theorem envBound43575 : H12AffineFastState.Bounded env43575 := by
  intro p hp
  have h : env43575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43574_43575 : H12AffineEnvironment.transform 7 172 env43574 = env43575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43574 == env43575) = true)

def env43576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4112,155965,412077,21763,8328,16,215318,79131,396476,32041,486458,213439,256,474262,469430,412604]

theorem envBound43576 : H12AffineFastState.Bounded env43576 := by
  intro p hp
  have h : env43576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43565_43576 : H12AffineEnvironment.transform 5 17 env43565 = env43576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43565 == env43576) = true)

theorem identity43576 : scanCanonicalize (H12AffineFastState.compose env43576 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound43576 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env43577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21647,131072,262144,1024,29829,4112,155965,412077,21763,8328,16,138649,24980,396476,32041,407733,136496,256,419865,425273,412604]

theorem envBound43577 : H12AffineFastState.Bounded env43577 := by
  intro p hp
  have h : env43577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43576_43577 : H12AffineEnvironment.transform 15 21647 env43576 = env43577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env43576 == env43577) = true)

theorem identity43577 : scanCanonicalize (H12AffineFastState.compose env43577 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound43577 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21647,131072,138293,1024,29829,4112,155965,21912,21763,8328,16,138649,24980,4233,32041,9344,136496,256,29740,24844,22409]

theorem envBound43578 : H12AffineFastState.Bounded env43578 := by
  intro p hp
  have h : env43578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43577_43578 : H12AffineEnvironment.transform 17 138293 env43577 = env43578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env43577 == env43578) = true)

theorem identity43578 : scanCanonicalize (H12AffineFastState.compose env43578 (packedSelected [1,3,4,5,8,9,11,12,14,15,16,17,18,20,35] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound43578 : packedSelected [1,3,4,5,8,9,11,12,14,15,16,17,18,20,35] rootPS < 2^1333 := by decide +kernel

def env43579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21647,24861,32040,1024,29829,4112,32,21912,21763,8328,16,31876,24980,4233,32041,9344,29741,256,29740,24844,22409]

end H12CloudChart0