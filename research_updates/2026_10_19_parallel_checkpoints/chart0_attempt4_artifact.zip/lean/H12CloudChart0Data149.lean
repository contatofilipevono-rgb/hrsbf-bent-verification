import H12CloudChart0Data148

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound37780 : packedSelected [1,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2540,3149,429,0,3142,445,1124,1024,1,2476,169,17,3482,3269,65,1297,3324,1197,1125,1501,249,256,3424,293,513]

theorem envBound37781 : H12AffineFastState.Bounded env37781 := by
  intro p hp
  have h : env37781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37780_37781 : H12AffineEnvironment.transform 12 3149 env37780 = env37781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3149 env37780 == env37781) = true)

theorem identity37781 : scanCanonicalize (H12AffineFastState.compose env37781 (packedSelected [1,3,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound37781 : packedSelected [1,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env37782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1296,1276,349,429,0,342,445,1124,1024,1,1212,169,17,138,469,65,1297,492,1197,1125,1501,249,256,112,293,513]

theorem envBound37782 : H12AffineFastState.Bounded env37782 := by
  intro p hp
  have h : env37782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37781_37782 : H12AffineEnvironment.transform 10 1296 env37781 = env37782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env37781 == env37782) = true)

theorem identity37782 : scanCanonicalize (H12AffineFastState.compose env37782 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound37782 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env37783 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1296,1061,349,372,0,342,356,1124,1024,1,1125,112,17,83,268,65,1297,309,1140,1125,1284,32,256,112,293,513]

theorem envBound37783 : H12AffineFastState.Bounded env37783 := by
  intro p hp
  have h : env37783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37782_37783 : H12AffineEnvironment.transform 6 89 env37782 = env37783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env37782 == env37783) = true)

theorem identity37783 : scanCanonicalize (H12AffineFastState.compose env37783 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37783 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37784 : List Nat := [2,4,8,16,32,64,89,256,512,52,292,17,349,372,0,342,356,80,52,1,81,112,17,83,268,65,293,309,64,81,304,32,256,112,293,513]

theorem envBound37784 : H12AffineFastState.Bounded env37784 := by
  intro p hp
  have h : env37784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37783_37784 : H12AffineEnvironment.transform 9 52 env37783 = env37784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37783 == env37784) = true)

theorem identity37784 : scanCanonicalize (H12AffineFastState.compose env37784 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37785 : List Nat := [2,4,8,16,32,64,89,37,512,52,1,17,120,81,0,115,65,80,52,1,81,112,17,83,41,65,0,16,64,81,21,32,37,112,0,513]

theorem envBound37785 : H12AffineFastState.Bounded env37785 := by
  intro p hp
  have h : env37785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37784_37785 : H12AffineEnvironment.transform 7 37 env37784 = env37785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37784 == env37785) = true)

theorem identity37785 : scanCanonicalize (H12AffineFastState.compose env37785 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37785 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37786 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,41,0,0,34,16,1,52,1,0,33,17,2,41,16,0,16,17,0,21,32,37,33,0,513]

theorem envBound37786 : H12AffineFastState.Bounded env37786 := by
  intro p hp
  have h : env37786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37785_37786 : H12AffineEnvironment.transform 5 17 env37785 = env37786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37785 == env37786) = true)

theorem identity37786 : scanCanonicalize (H12AffineFastState.compose env37786 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound37786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37787 : List Nat := [2,4,8,16,32,17,8,37,32,52,1,17,41,0,0,34,16,1,52,1,0,33,17,2,41,16,0,16,17,0,21,32,37,33,0,33]

theorem envBound37787 : H12AffineFastState.Bounded env37787 := by
  intro p hp
  have h : env37787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37786_37787 : H12AffineEnvironment.transform 8 32 env37786 = env37787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env37786 == env37787) = true)

theorem identity37787 : scanCanonicalize (H12AffineFastState.compose env37787 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37787 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37788 : List Nat := [2,4,8,1,32,0,8,37,32,37,1,0,41,0,0,34,1,1,37,1,0,33,0,2,41,1,0,1,0,0,4,32,37,33,0,33]

theorem envBound37788 : H12AffineFastState.Bounded env37788 := by
  intro p hp
  have h : env37788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37787_37788 : H12AffineEnvironment.transform 3 1 env37787 = env37788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37787 == env37788) = true)

def env37789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,8388608,98781,8328,65,12683758,5392,8406288,8456242,8390093,4256860,256,8410416,8434837,8462874]

theorem envBound37789 : H12AffineFastState.Bounded env37789 := by
  intro p hp
  have h : env37789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37756_37789 : H12AffineEnvironment.transform 20 4161 env37756 = env37789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37756 == env37789) = true)

def env37790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,16,98781,8328,65,4295166,5392,17664,67618,1501,4256860,256,21792,46213,74250]

theorem envBound37790 : H12AffineFastState.Bounded env37790 := by
  intro p hp
  have h : env37790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37789_37790 : H12AffineEnvironment.transform 22 16 env37789 = env37790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env37789 == env37790) = true)

theorem identity37790 : scanCanonicalize (H12AffineFastState.compose env37790 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound37790 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138477,1024,32769,4161,4194304,16,21762,8328,65,4218145,5392,17664,56573,1501,4256860,256,21792,46213,63189]

theorem envBound37791 : H12AffineFastState.Bounded env37791 := by
  intro p hp
  have h : env37791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37790_37791 : H12AffineEnvironment.transform 15 54495 env37790 = env37791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env37790 == env37791) = true)

def env37792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,138341,1024,32769,4161,4194304,16,21762,8192,65,4218145,5392,17664,56437,1365,4256860,256,21792,46093,63069]

theorem envBound37792 : H12AffineFastState.Bounded env37792 := by
  intro p hp
  have h : env37792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37791_37792 : H12AffineEnvironment.transform 6 8 env37791 = env37792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37791 == env37792) = true)

theorem identity37792 : scanCanonicalize (H12AffineFastState.compose env37792 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound37792 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,10281,1024,32769,4161,4194304,16,21762,8192,65,4218145,5392,17664,56437,1365,4256860,256,21792,46093,63069]

theorem envBound37793 : H12AffineFastState.Bounded env37793 := by
  intro p hp
  have h : env37793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37792_37793 : H12AffineEnvironment.transform 16 13388 env37792 = env37793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env37792 == env37793) = true)

theorem identity37793 : scanCanonicalize (H12AffineFastState.compose env37793 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound37793 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,13388,10281,1024,32769,4161,4194304,16,8543,8192,65,4204924,5392,12637,43048,1365,4227073,256,8573,46093,33280]

theorem envBound37794 : H12AffineFastState.Bounded env37794 := by
  intro p hp
  have h : env37794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37793_37794 : H12AffineEnvironment.transform 13 13405 env37793 = env37794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env37793 == env37794) = true)

theorem identity37794 : scanCanonicalize (H12AffineFastState.compose env37794 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37794 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33111,5393,2420,1024,32769,4161,4194304,16,2,349,65,4196385,5392,4096,35189,1365,4227073,256,32,38224,33280]

theorem envBound37795 : H12AffineFastState.Bounded env37795 := by
  intro p hp
  have h : env37795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37794_37795 : H12AffineEnvironment.transform 12 349 env37794 = env37795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37794 == env37795) = true)

theorem identity37795 : scanCanonicalize (H12AffineFastState.compose env37795 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 32880) := by decide +kernel

theorem selectedBound37795 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env37796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33111,5393,2420,1024,32769,4161,32880,16,2,349,65,34897,5392,4096,35189,1365,113,256,32,38224,33280]

theorem envBound37796 : H12AffineFastState.Bounded env37796 := by
  intro p hp
  have h : env37796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37795_37796 : H12AffineEnvironment.transform 21 32880 env37795 = env37796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32880 env37795 == env37796) = true)

theorem identity37796 : scanCanonicalize (H12AffineFastState.compose env37796 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37796 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env37797 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,32768,33031,5393,2340,1024,32769,4113,32800,16,2,269,17,34817,5392,4096,35109,1285,33,256,32,38144,33280]

theorem envBound37797 : H12AffineFastState.Bounded env37797 := by
  intro p hp
  have h : env37797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37796_37797 : H12AffineEnvironment.transform 5 16 env37796 = env37797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37796 == env37797) = true)

theorem identity37797 : scanCanonicalize (H12AffineFastState.compose env37797 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37797 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37798 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5376,32768,33031,5393,2308,1024,32769,4113,32768,16,2,269,17,34817,5392,4096,35077,1285,1,256,0,38144,33280]

theorem envBound37798 : H12AffineFastState.Bounded env37798 := by
  intro p hp
  have h : env37798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37797_37798 : H12AffineEnvironment.transform 4 0 env37797 = env37798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37797 == env37798) = true)

theorem identity37798 : scanCanonicalize (H12AffineFastState.compose env37798 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37798 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37799 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5376,1,262,5393,2308,1024,0,4113,1,16,2,269,17,2048,5392,4096,2308,1285,1,256,0,5377,513]

theorem envBound37799 : H12AffineFastState.Bounded env37799 := by
  intro p hp
  have h : env37799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37798_37799 : H12AffineEnvironment.transform 14 1 env37798 = env37799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37798 == env37799) = true)

theorem identity37799 : scanCanonicalize (H12AffineFastState.compose env37799 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37799 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37800 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,1,2,5141,2048,1024,0,4113,1,16,2,9,17,2048,5140,4096,2048,1025,1,4,0,5125,513]

theorem envBound37800 : H12AffineFastState.Bounded env37800 := by
  intro p hp
  have h : env37800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37799_37800 : H12AffineEnvironment.transform 7 4 env37799 = env37800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37799 == env37800) = true)

theorem identity37800 : scanCanonicalize (H12AffineFastState.compose env37800 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37800 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37801 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,4096,9,5124,1,2,5141,522,1024,0,4113,1,16,2,9,17,522,5140,4096,522,1025,1,4,0,5125,513]

theorem envBound37801 : H12AffineFastState.Bounded env37801 := by
  intro p hp
  have h : env37801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37800_37801 : H12AffineEnvironment.transform 10 522 env37800 = env37801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37800 == env37801) = true)

def env37802 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,16,9,1044,1,2,1029,522,1024,0,1,1,16,2,9,17,522,1028,16,522,1025,1,4,0,1045,513]

theorem envBound37802 : H12AffineFastState.Bounded env37802 := by
  intro p hp
  have h : env37802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37801_37802 : H12AffineEnvironment.transform 11 16 env37801 = env37802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37801 == env37802) = true)

theorem identity37802 : scanCanonicalize (H12AffineFastState.compose env37802 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound37802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37803 : List Nat := [2,4,8,16,0,16,8,4,31,1024,21,16,9,1044,1,2,1029,21,1024,0,1,1,16,2,9,17,21,1028,16,21,1025,1,4,0,1045,30]

theorem envBound37803 : H12AffineFastState.Bounded env37803 := by
  intro p hp
  have h : env37803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37802_37803 : H12AffineEnvironment.transform 8 31 env37802 = env37803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env37802 == env37803) = true)

def env37804 : List Nat := [2,4,8,16,0,16,8,4,31,0,21,16,9,20,1,2,5,21,0,0,1,1,16,2,9,17,21,4,16,21,1,1,4,0,21,30]

theorem envBound37804 : H12AffineFastState.Bounded env37804 := by
  intro p hp
  have h : env37804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37803_37804 : H12AffineEnvironment.transform 9 0 env37803 = env37804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env37803 == env37804) = true)

theorem identity37804 : scanCanonicalize (H12AffineFastState.compose env37804 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37804 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37805 : List Nat := [2,4,8,6,0,6,8,4,9,0,3,6,9,2,1,2,5,3,0,0,1,1,6,2,9,7,3,4,6,3,1,1,4,0,3,8]

theorem envBound37805 : H12AffineFastState.Bounded env37805 := by
  intro p hp
  have h : env37805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37804_37805 : H12AffineEnvironment.transform 3 6 env37804 = env37805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37804 == env37805) = true)

def leafEnv37805 : List Nat := [2,4,8,6,0,6,8,4,9,0,3,6,9,2,1,2,5,3,0,0,1,1,6,2,0,9,1,7,3,4,6,3,1,1,4,0,5,2,3,8,1,0,0]

def active37805 : List Nat := [0,1,2]

def tree37805 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37805 : H12WitnessSearch.Good tree37805 := H12GlobalWitnessIndex.good

theorem leafIdentity37805 : H12AffineFastState.composeSystem env37805 rootObs = leafEnv37805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37805 rootObs == leafEnv37805) = true)

theorem terminalChecked37805 : H12PackedTerminal.terminalCheckFast leafEnv37805 active37805 tree37805 = true := by decide +kernel

def env37806 : List Nat := [2,4,8,16,0,16,8,4,31,1,21,16,9,21,1,2,4,21,1,0,1,1,16,2,9,17,21,5,16,21,0,1,4,0,20,30]

theorem envBound37806 : H12AffineFastState.Bounded env37806 := by
  intro p hp
  have h : env37806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37803_37806 : H12AffineEnvironment.transform 9 1 env37803 = env37806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env37803 == env37806) = true)

theorem identity37806 : scanCanonicalize (H12AffineFastState.compose env37806 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37806 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37807 : List Nat := [0,4,8,16,0,16,8,4,29,1,21,16,9,21,1,0,4,21,1,0,1,1,16,0,9,17,21,5,16,21,0,1,4,0,20,28]

theorem envBound37807 : H12AffineFastState.Bounded env37807 := by
  intro p hp
  have h : env37807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37806_37807 : H12AffineEnvironment.transform 0 0 env37806 = env37807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37806 == env37807) = true)

def leafEnv37807 : List Nat := [0,4,8,16,0,16,8,4,29,1,21,16,9,21,1,0,4,21,1,0,1,1,16,0,1,9,1,17,21,5,16,21,0,1,4,0,5,0,20,28,1,0,0]

def active37807 : List Nat := [1,2,3]

def tree37807 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37807 : H12WitnessSearch.Good tree37807 := H12GlobalWitnessIndex.good

theorem leafIdentity37807 : H12AffineFastState.composeSystem env37807 rootObs = leafEnv37807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37807 rootObs == leafEnv37807) = true)

theorem terminalChecked37807 : H12PackedTerminal.terminalCheckFast leafEnv37807 active37807 tree37807 = true := by decide +kernel

def env37808 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,17,9,1045,1,2,1028,522,1024,0,0,1,16,2,9,17,522,1029,17,522,1025,1,4,0,1044,513]

theorem envBound37808 : H12AffineFastState.Bounded env37808 := by
  intro p hp
  have h : env37808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37801_37808 : H12AffineEnvironment.transform 11 17 env37801 = env37808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37801 == env37808) = true)

theorem identity37808 : scanCanonicalize (H12AffineFastState.compose env37808 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound37808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37809 : List Nat := [2,4,8,16,0,16,8,4,512,522,522,17,9,543,1,2,526,522,522,0,0,1,16,2,9,17,522,527,17,522,523,1,4,0,542,513]

theorem envBound37809 : H12AffineFastState.Bounded env37809 := by
  intro p hp
  have h : env37809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37808_37809 : H12AffineEnvironment.transform 9 522 env37808 = env37809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env37808 == env37809) = true)

def env37810 : List Nat := [2,4,8,4,0,4,8,4,512,522,522,5,9,523,1,2,526,522,522,0,0,1,4,2,9,5,522,527,5,522,523,1,4,0,522,513]

theorem envBound37810 : H12AffineFastState.Bounded env37810 := by
  intro p hp
  have h : env37810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37809_37810 : H12AffineEnvironment.transform 3 4 env37809 = env37810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37809 == env37810) = true)

theorem identity37810 : scanCanonicalize (H12AffineFastState.compose env37810 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37811 : List Nat := [0,4,8,4,0,4,8,4,512,520,520,5,9,521,1,0,524,520,520,0,0,1,4,0,9,5,520,525,5,520,521,1,4,0,520,513]

theorem envBound37811 : H12AffineFastState.Bounded env37811 := by
  intro p hp
  have h : env37811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37810_37811 : H12AffineEnvironment.transform 0 0 env37810 = env37811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37810 == env37811) = true)

def leafEnv37811 : List Nat := [0,4,8,4,0,4,8,4,512,520,520,5,9,521,1,0,524,520,520,0,0,1,4,0,520,9,1,5,520,525,5,520,521,1,4,0,5,0,520,513,1,1,0]

def active37811 : List Nat := [1,2,8]

def tree37811 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37811 : H12WitnessSearch.Good tree37811 := H12GlobalWitnessIndex.good

theorem leafIdentity37811 : H12AffineFastState.composeSystem env37811 rootObs = leafEnv37811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37811 rootObs == leafEnv37811) = true)

theorem terminalChecked37811 : H12PackedTerminal.terminalCheckFast leafEnv37811 active37811 tree37811 = true := by decide +kernel

def env37812 : List Nat := [2,4,8,5,0,5,8,4,512,522,522,4,9,522,1,2,526,522,522,0,0,1,5,2,9,4,522,527,4,522,523,1,4,0,523,513]

theorem envBound37812 : H12AffineFastState.Bounded env37812 := by
  intro p hp
  have h : env37812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37809_37812 : H12AffineEnvironment.transform 3 5 env37809 = env37812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37809 == env37812) = true)

theorem identity37812 : scanCanonicalize (H12AffineFastState.compose env37812 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound37812 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37813 : List Nat := [2,4,8,5,0,5,8,4,9,3,3,4,9,3,1,2,7,3,3,0,0,1,5,2,9,4,3,6,4,3,2,1,4,0,2,8]

theorem envBound37813 : H12AffineFastState.Bounded env37813 := by
  intro p hp
  have h : env37813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37812_37813 : H12AffineEnvironment.transform 8 9 env37812 = env37813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env37812 == env37813) = true)

def leafEnv37813 : List Nat := [2,4,8,5,0,5,8,4,9,3,3,4,9,3,1,2,7,3,3,0,0,1,5,2,3,9,1,4,3,6,4,3,2,1,4,0,5,2,2,8,1,1,0]

def active37813 : List Nat := [0,1,2]

def tree37813 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37813 : H12WitnessSearch.Good tree37813 := H12GlobalWitnessIndex.good

theorem leafIdentity37813 : H12AffineFastState.composeSystem env37813 rootObs = leafEnv37813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37813 rootObs == leafEnv37813) = true)

theorem terminalChecked37813 : H12PackedTerminal.terminalCheckFast leafEnv37813 active37813 tree37813 = true := by decide +kernel

def env37814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,138340,1024,32769,4161,4194304,16,21762,8193,65,4218145,5392,17664,56436,1364,4256860,256,21792,46092,63068]

theorem envBound37814 : H12AffineFastState.Bounded env37814 := by
  intro p hp
  have h : env37814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37791_37814 : H12AffineEnvironment.transform 6 9 env37791 = env37814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37791 == env37814) = true)

theorem identity37814 : scanCanonicalize (H12AffineFastState.compose env37814 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound37814 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,35189,1024,32769,4161,4194304,16,21762,8193,65,4218145,5392,17664,56436,1364,4256860,256,21792,46092,63068]

theorem envBound37815 : H12AffineFastState.Bounded env37815 := by
  intro p hp
  have h : env37815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37814_37815 : H12AffineEnvironment.transform 16 38161 env37814 = env37815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env37814 == env37815) = true)

theorem identity37815 : scanCanonicalize (H12AffineFastState.compose env37815 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound37815 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,35189,1024,32769,4161,62589,16,21762,8193,65,43356,5392,17664,56436,1364,33,256,21792,46092,63068]

theorem envBound37816 : H12AffineFastState.Bounded env37816 := by
  intro p hp
  have h : env37816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37815_37816 : H12AffineEnvironment.transform 21 62589 env37815 = env37816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env37815 == env37816) = true)

theorem identity37816 : scanCanonicalize (H12AffineFastState.compose env37816 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound37816 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,16401,23669,1024,21761,4161,8573,16,21762,8193,65,31836,5392,17664,2420,1364,33,256,21792,24844,9052]

theorem envBound37817 : H12AffineFastState.Bounded env37817 := by
  intro p hp
  have h : env37817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37816_37817 : H12AffineEnvironment.transform 14 21760 env37816 = env37817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env37816 == env37817) = true)

theorem identity37817 : scanCanonicalize (H12AffineFastState.compose env37817 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37817 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,342,5393,2421,1024,1,4161,8573,16,2,8193,65,10588,5392,4096,2420,1364,33,256,32,13324,9052]

theorem envBound37818 : H12AffineFastState.Bounded env37818 := by
  intro p hp
  have h : env37818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37817_37818 : H12AffineEnvironment.transform 13 5376 env37817 = env37818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37817 == env37818) = true)

theorem identity37818 : scanCanonicalize (H12AffineFastState.compose env37818 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37818 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37819 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,5376,0,294,5393,2309,1024,1,4145,8461,16,2,8193,49,10540,5392,4096,2308,1316,33,256,32,13324,9004]

theorem envBound37819 : H12AffineFastState.Bounded env37819 := by
  intro p hp
  have h : env37819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37818_37819 : H12AffineEnvironment.transform 5 48 env37818 = env37819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37818 == env37819) = true)

theorem identity37819 : scanCanonicalize (H12AffineFastState.compose env37819 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37819 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37820 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,269,5376,0,294,5393,2309,1024,1,4145,0,16,2,268,49,2081,5392,4096,2308,1316,33,256,32,5377,545]

theorem envBound37820 : H12AffineFastState.Bounded env37820 := by
  intro p hp
  have h : env37820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37819_37820 : H12AffineEnvironment.transform 12 269 env37819 = env37820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37819 == env37820) = true)

theorem identity37820 : scanCanonicalize (H12AffineFastState.compose env37820 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 299) := by decide +kernel

theorem selectedBound37820 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37821 : List Nat := [2,4,8,16,32,48,9,256,512,299,2048,4096,269,4139,0,294,4154,2309,299,1,4145,0,16,2,268,49,2081,4155,4096,2308,15,33,256,32,4138,545]

theorem envBound37821 : H12AffineFastState.Bounded env37821 := by
  intro p hp
  have h : env37821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37820_37821 : H12AffineEnvironment.transform 9 299 env37820 = env37821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 299 env37820 == env37821) = true)

theorem identity37821 : scanCanonicalize (H12AffineFastState.compose env37821 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37821 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env37822 : List Nat := [2,4,8,16,0,16,9,256,512,267,2048,4096,269,4107,0,262,4122,2309,267,1,4113,0,16,2,268,17,2049,4123,4096,2308,15,1,256,0,4106,513]

theorem envBound37822 : H12AffineFastState.Bounded env37822 := by
  intro p hp
  have h : env37822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37821_37822 : H12AffineEnvironment.transform 4 0 env37821 = env37822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37821 == env37822) = true)

theorem identity37822 : scanCanonicalize (H12AffineFastState.compose env37822 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37822 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37823 : List Nat := [2,4,8,10,0,10,9,256,512,267,2048,4096,269,4107,0,262,4096,2309,267,1,4107,0,10,2,268,11,2049,4097,4096,2308,15,1,256,0,4106,513]

theorem envBound37823 : H12AffineFastState.Bounded env37823 := by
  intro p hp
  have h : env37823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37822_37823 : H12AffineEnvironment.transform 3 10 env37822 = env37823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37822 == env37823) = true)

theorem identity37823 : scanCanonicalize (H12AffineFastState.compose env37823 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound37823 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37824 : List Nat := [2,4,8,10,0,10,9,256,512,267,783,4096,269,4107,0,262,4096,522,267,1,4107,0,10,2,268,11,782,4097,4096,523,15,1,256,0,4106,513]

theorem envBound37824 : H12AffineFastState.Bounded env37824 := by
  intro p hp
  have h : env37824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37823_37824 : H12AffineEnvironment.transform 10 783 env37823 = env37824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env37823 == env37824) = true)

theorem identity37824 : scanCanonicalize (H12AffineFastState.compose env37824 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound37824 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37825 : List Nat := [2,4,8,10,0,10,9,256,12,267,259,4096,269,4107,0,262,4096,6,267,1,4107,0,10,2,268,11,258,4097,4096,7,15,1,256,0,4106,13]

theorem envBound37825 : H12AffineFastState.Bounded env37825 := by
  intro p hp
  have h : env37825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37824_37825 : H12AffineEnvironment.transform 8 12 env37824 = env37825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env37824 == env37825) = true)

theorem identity37825 : scanCanonicalize (H12AffineFastState.compose env37825 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37825 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37826 : List Nat := [2,4,2,0,0,0,3,256,6,257,259,4096,263,4097,0,262,4096,6,257,1,4097,0,0,2,262,1,258,4097,4096,7,5,1,256,0,4096,7]

theorem envBound37826 : H12AffineFastState.Bounded env37826 := by
  intro p hp
  have h : env37826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37825_37826 : H12AffineEnvironment.transform 2 2 env37825 = env37826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37825 == env37826) = true)

theorem identity37826 : scanCanonicalize (H12AffineFastState.compose env37826 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 5) := by decide +kernel

theorem selectedBound37826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37827 : List Nat := [2,4,2,0,0,0,3,256,6,257,259,5,263,4,0,262,5,6,257,1,4,0,0,2,262,1,258,4,5,7,5,1,256,0,5,7]

theorem envBound37827 : H12AffineFastState.Bounded env37827 := by
  intro p hp
  have h : env37827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37826_37827 : H12AffineEnvironment.transform 11 5 env37826 = env37827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 5 env37826 == env37827) = true)

theorem identity37827 : scanCanonicalize (H12AffineFastState.compose env37827 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37827 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37828 : List Nat := [2,4,2,0,0,0,3,5,6,4,6,5,2,4,0,3,5,6,4,1,4,0,0,2,3,1,7,4,5,7,5,1,5,0,5,7]

theorem envBound37828 : H12AffineFastState.Bounded env37828 := by
  intro p hp
  have h : env37828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37827_37828 : H12AffineEnvironment.transform 7 5 env37827 = env37828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37827 == env37828) = true)

theorem identity37828 : scanCanonicalize (H12AffineFastState.compose env37828 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37828 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env37829 : List Nat := [0,4,0,0,0,0,1,5,4,4,4,5,0,4,0,1,5,4,4,1,4,0,0,0,1,1,5,4,5,5,5,1,5,0,5,5]

theorem envBound37829 : H12AffineFastState.Bounded env37829 := by
  intro p hp
  have h : env37829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37828_37829 : H12AffineEnvironment.transform 0 0 env37828 = env37829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37828 == env37829) = true)

def env37830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,17,98781,8328,65,4295167,5392,17665,67619,1500,4256860,256,21793,46212,74251]

theorem envBound37830 : H12AffineFastState.Bounded env37830 := by
  intro p hp
  have h : env37830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37789_37830 : H12AffineEnvironment.transform 22 17 env37789 = env37830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env37789 == env37830) = true)

theorem identity37830 : scanCanonicalize (H12AffineFastState.compose env37830 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound37830 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,201831,17,98781,8328,65,171416,5392,17665,67619,1500,254011,256,21793,46212,74251]

theorem envBound37831 : H12AffineFastState.Bounded env37831 := by
  intro p hp
  have h : env37831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37830_37831 : H12AffineEnvironment.transform 21 201831 env37830 = env37831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env37830 == env37831) = true)

def env37832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,201831,17,98645,8192,65,171280,5392,17665,67619,1364,254011,256,21793,46092,74251]

theorem envBound37832 : H12AffineFastState.Bounded env37832 := by
  intro p hp
  have h : env37832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37831_37832 : H12AffineEnvironment.transform 6 8 env37831 = env37832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37831 == env37832) = true)

theorem identity37832 : scanCanonicalize (H12AffineFastState.compose env37832 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound37832 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,179512,1024,32769,4161,156013,17,62559,8192,65,171280,5392,17665,32041,1364,169265,256,21793,46092,22273]

theorem envBound37833 : H12AffineFastState.Bounded env37833 := by
  intro p hp
  have h : env37833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37832_37833 : H12AffineEnvironment.transform 15 29962 env37832 = env37833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env37832 == env37833) = true)

theorem identity37833 : scanCanonicalize (H12AffineFastState.compose env37833 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound37833 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49169,32041,1024,32769,4161,41340,17,62559,8192,65,23809,5392,17665,32041,1364,21792,256,21793,46092,22273]

theorem envBound37834 : H12AffineFastState.Bounded env37834 := by
  intro p hp
  have h : env37834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37833_37834 : H12AffineEnvironment.transform 16 49169 env37833 = env37834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env37833 == env37834) = true)

theorem identity37834 : scanCanonicalize (H12AffineFastState.compose env37834 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound37834 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env37835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,8283,38208,10360,1024,32769,4161,41340,17,41230,8192,65,2128,5392,4176,10360,1364,113,256,112,46092,592]

theorem envBound37835 : H12AffineFastState.Bounded env37835 := by
  intro p hp
  have h : env37835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37834_37835 : H12AffineEnvironment.transform 13 5457 env37834 = env37835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env37834 == env37835) = true)

theorem identity37835 : scanCanonicalize (H12AffineFastState.compose env37835 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37835 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env37836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,8283,13340,10360,1024,8541,4161,32,17,82,8192,65,2128,5392,4176,10360,1364,113,256,112,5456,592]

theorem envBound37836 : H12AffineFastState.Bounded env37836 := by
  intro p hp
  have h : env37836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37835_37836 : H12AffineEnvironment.transform 14 8540 env37835 = env37836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37835 == env37836) = true)

theorem identity37836 : scanCanonicalize (H12AffineFastState.compose env37836 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound37836 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,5457,1344,1095,4096,3172,1024,1345,4161,32,17,82,1052,65,2128,5392,4176,3172,1364,113,256,112,5456,592]

theorem envBound37837 : H12AffineFastState.Bounded env37837 := by
  intro p hp
  have h : env37837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37836_37837 : H12AffineEnvironment.transform 12 1052 env37836 = env37837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env37836 == env37837) = true)

theorem identity37837 : scanCanonicalize (H12AffineFastState.compose env37837 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound37837 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env37838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1052,2420,1344,1095,3109,3172,1024,1345,3172,32,17,82,1052,65,2128,2357,3189,3172,1364,113,256,112,2421,592]

theorem envBound37838 : H12AffineFastState.Bounded env37838 := by
  intro p hp
  have h : env37838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37837_37838 : H12AffineEnvironment.transform 11 3109 env37837 = env37838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env37837 == env37838) = true)

theorem identity37838 : scanCanonicalize (H12AffineFastState.compose env37838 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37838 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env37839 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,268,2420,80,343,2357,2420,272,81,2420,32,17,82,268,65,2128,2357,2405,2420,68,113,256,112,2421,592]

theorem envBound37839 : H12AffineFastState.Bounded env37839 := by
  intro p hp
  have h : env37839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37838_37839 : H12AffineEnvironment.transform 9 272 env37838 = env37839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37838 == env37839) = true)

theorem identity37839 : scanCanonicalize (H12AffineFastState.compose env37839 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound37839 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37840 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,2144,89,2081,80,2,2144,2081,69,81,2081,32,17,82,89,65,2128,2144,2096,2081,68,113,85,112,2080,592]

theorem envBound37840 : H12AffineFastState.Bounded env37840 := by
  intro p hp
  have h : env37840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37839_37840 : H12AffineEnvironment.transform 7 85 env37839 = env37840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env37839 == env37840) = true)

theorem identity37840 : scanCanonicalize (H12AffineFastState.compose env37840 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37840 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env37841 : List Nat := [2,4,8,16,1,64,8,85,512,69,2048,2113,89,2048,80,2,2113,2048,69,81,2048,1,17,82,89,65,2128,2113,2065,2048,68,80,85,81,2049,592]

theorem envBound37841 : H12AffineFastState.Bounded env37841 := by
  intro p hp
  have h : env37841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37840_37841 : H12AffineEnvironment.transform 4 1 env37840 = env37841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37840 == env37841) = true)

def env37842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,201831,17,98644,8193,65,171281,5392,17665,67619,1365,254011,256,21793,46093,74251]

theorem envBound37842 : H12AffineFastState.Bounded env37842 := by
  intro p hp
  have h : env37842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37831_37842 : H12AffineEnvironment.transform 6 9 env37831 = env37842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37831 == env37842) = true)

theorem identity37842 : scanCanonicalize (H12AffineFastState.compose env37842 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37842 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223599,1024,8540,4161,201831,17,73737,8193,65,146508,5392,17665,67619,1365,213350,256,21793,5456,74251]

theorem envBound37843 : H12AffineFastState.Bounded env37843 := by
  intro p hp
  have h : env37843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37842_37843 : H12AffineEnvironment.transform 14 8541 env37842 = env37843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37842 == env37843) = true)

theorem identity37843 : scanCanonicalize (H12AffineFastState.compose env37843 (packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound37843 : packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS < 2^1333 := by decide +kernel

def env37844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,70963,31836,1024,8540,4161,340,17,73737,8193,65,76159,5392,17665,67619,1365,21589,256,21793,5456,74251]

theorem envBound37844 : H12AffineFastState.Bounded env37844 := by
  intro p hp
  have h : env37844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37843_37844 : H12AffineEnvironment.transform 16 70963 env37843 = env37844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env37843 == env37844) = true)

theorem identity37844 : scanCanonicalize (H12AffineFastState.compose env37844 (packedSelected [1,2,5,6,7,8,9,11,19,20,22,23,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37844 : packedSelected [1,2,5,6,7,8,9,11,19,20,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37845 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8312,65536,70678,31836,1024,8313,4161,113,17,73737,8193,65,75866,5173,17444,67619,1136,21589,37,21508,5237,74251]

theorem envBound37845 : H12AffineFastState.Bounded env37845 := by
  intro p hp
  have h : env37845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37844_37845 : H12AffineEnvironment.transform 7 37 env37844 = env37845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37844 == env37845) = true)

theorem identity37845 : scanCanonicalize (H12AffineFastState.compose env37845 (packedSelected [1,2,3,5,6,8,9,10,11,14,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound37845 : packedSelected [1,2,3,5,6,8,9,10,11,14,19,22,23] rootPS < 2^1333 := by decide +kernel

def env37846 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8312,21510,16400,31836,1024,8313,4161,113,17,29711,8193,65,31836,5173,17444,23589,1136,21589,37,21508,5237,30221]

theorem envBound37846 : H12AffineFastState.Bounded env37846 := by
  intro p hp
  have h : env37846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37845_37846 : H12AffineEnvironment.transform 15 21510 env37845 = env37846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env37845 == env37846) = true)

theorem identity37846 : scanCanonicalize (H12AffineFastState.compose env37846 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound37846 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37847 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13325,8312,8203,13341,2129,1024,8313,4161,113,17,2,8193,65,2129,5173,12329,10280,1136,8280,37,8201,5237,512]

theorem envBound37847 : H12AffineFastState.Bounded env37847 := by
  intro p hp
  have h : env37847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37846_37847 : H12AffineEnvironment.transform 13 13325 env37846 = env37847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env37846 == env37847) = true)

theorem identity37847 : scanCanonicalize (H12AffineFastState.compose env37847 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound37847 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37848 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1087,4096,8192,13325,8312,8203,13341,1134,1024,8313,4161,113,17,2,8193,65,1134,5173,12329,9239,1136,8280,37,8201,5237,512]

theorem envBound37848 : H12AffineFastState.Bounded env37848 := by
  intro p hp
  have h : env37848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37847_37848 : H12AffineEnvironment.transform 10 1087 env37847 = env37848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env37847 == env37848) = true)

theorem identity37848 : scanCanonicalize (H12AffineFastState.compose env37848 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 4137) := by decide +kernel

theorem selectedBound37848 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37849 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1087,4096,4137,1060,4177,4130,1076,1134,1024,4176,4161,113,17,2,4136,65,1134,5173,0,5182,1136,4209,37,4128,5237,512]

theorem envBound37849 : H12AffineFastState.Bounded env37849 := by
  intro p hp
  have h : env37849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37848_37849 : H12AffineEnvironment.transform 12 4137 env37848 = env37849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4137 env37848 == env37849) = true)

theorem identity37849 : scanCanonicalize (H12AffineFastState.compose env37849 (packedSelected [0,3,5,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound37849 : packedSelected [0,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env37850 : List Nat := [2,4,8,16,32,64,9,37,512,62,1,4096,4137,26,4177,4130,10,80,62,4176,4161,113,17,2,4136,65,80,4107,0,4096,78,4209,37,4128,4171,512]

theorem envBound37850 : H12AffineFastState.Bounded env37850 := by
  intro p hp
  have h : env37850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37849_37850 : H12AffineEnvironment.transform 9 62 env37849 = env37850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env37849 == env37850) = true)

theorem identity37850 : scanCanonicalize (H12AffineFastState.compose env37850 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37850 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37851 : List Nat := [2,4,8,16,32,16,9,37,512,62,1,4096,4137,26,4097,4130,10,0,62,4096,4113,33,17,2,4136,17,0,4107,0,4096,30,4129,37,4128,4123,512]

theorem envBound37851 : H12AffineFastState.Bounded env37851 := by
  intro p hp
  have h : env37851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37850_37851 : H12AffineEnvironment.transform 5 16 env37850 = env37851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37850 == env37851) = true)

theorem identity37851 : scanCanonicalize (H12AffineFastState.compose env37851 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound37851 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37852 : List Nat := [2,4,8,16,32,16,9,37,512,62,1,42,3,26,43,8,10,0,62,42,59,33,17,2,2,17,0,33,0,42,30,11,37,10,49,512]

theorem envBound37852 : H12AffineFastState.Bounded env37852 := by
  intro p hp
  have h : env37852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37851_37852 : H12AffineEnvironment.transform 11 42 env37851 = env37852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env37851 == env37852) = true)

theorem identity37852 : scanCanonicalize (H12AffineFastState.compose env37852 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37852 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37853 : List Nat := [2,4,8,16,1,16,9,4,512,31,1,11,3,26,10,8,10,0,31,11,26,0,17,2,2,17,0,0,0,11,30,11,4,10,16,512]

theorem envBound37853 : H12AffineFastState.Bounded env37853 := by
  intro p hp
  have h : env37853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37852_37853 : H12AffineEnvironment.transform 4 1 env37852 = env37853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37852 == env37853) = true)

theorem identity37853 : scanCanonicalize (H12AffineFastState.compose env37853 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound37853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37854 : List Nat := [2,4,8,16,1,16,9,4,4,31,1,11,3,26,10,8,10,0,31,11,26,0,17,2,2,17,0,0,0,11,30,11,4,10,16,4]

theorem envBound37854 : H12AffineFastState.Bounded env37854 := by
  intro p hp
  have h : env37854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37853_37854 : H12AffineEnvironment.transform 8 4 env37853 = env37854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env37853 == env37854) = true)

theorem identity37854 : scanCanonicalize (H12AffineFastState.compose env37854 (packedSelected [3,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound37854 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env37855 : List Nat := [2,4,1,16,1,16,0,4,4,22,1,2,3,19,3,1,3,0,22,2,19,0,17,2,2,17,0,0,0,2,23,2,4,3,16,4]

theorem envBound37855 : H12AffineFastState.Bounded env37855 := by
  intro p hp
  have h : env37855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37854_37855 : H12AffineEnvironment.transform 2 1 env37854 = env37855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env37854 == env37855) = true)

theorem identity37855 : scanCanonicalize (H12AffineFastState.compose env37855 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37855 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env37856 : List Nat := [1,4,1,16,1,16,0,4,4,21,1,1,0,16,0,1,0,0,21,1,16,0,17,1,1,17,0,0,0,1,20,1,4,0,16,4]

theorem envBound37856 : H12AffineFastState.Bounded env37856 := by
  intro p hp
  have h : env37856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37855_37856 : H12AffineEnvironment.transform 0 1 env37855 = env37856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37855 == env37856) = true)

theorem identity37856 : scanCanonicalize (H12AffineFastState.compose env37856 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound37856 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37857 : List Nat := [1,4,1,4,1,4,0,4,4,1,1,1,0,4,0,1,0,0,1,1,4,0,5,1,1,5,0,0,0,1,0,1,4,0,4,4]

theorem envBound37857 : H12AffineFastState.Bounded env37857 := by
  intro p hp
  have h : env37857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37856_37857 : H12AffineEnvironment.transform 3 4 env37856 = env37857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37856 == env37857) = true)

def env37858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784942,5393,10507601,8456242,10491277,4256861,256,8410417,8434836,10564186]

theorem envBound37858 : H12AffineFastState.Bounded env37858 := by
  intro p hp
  have h : env37858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37755_37858 : H12AffineEnvironment.transform 23 2199965 env37755 = env37858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env37755 == env37858) = true)

def env37859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,8388608,98781,8328,65,12683758,5393,8406289,8456242,8390093,4256861,256,8410417,8434836,8462874]

theorem envBound37859 : H12AffineFastState.Bounded env37859 := by
  intro p hp
  have h : env37859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37858_37859 : H12AffineEnvironment.transform 20 4160 env37858 = env37859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37858 == env37859) = true)

def env37860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,16,98781,8328,65,4295166,5393,17665,67618,1501,4256861,256,21793,46212,74250]

theorem envBound37860 : H12AffineFastState.Bounded env37860 := by
  intro p hp
  have h : env37860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37859_37860 : H12AffineEnvironment.transform 22 16 env37859 = env37860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env37859 == env37860) = true)

theorem identity37860 : scanCanonicalize (H12AffineFastState.compose env37860 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound37860 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212199,1024,29908,4160,4194304,16,95496,8328,65,4291883,5393,17665,67618,1501,4194440,256,21793,16465,74250]

theorem envBound37861 : H12AffineFastState.Bounded env37861 := by
  intro p hp
  have h : env37861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37860_37861 : H12AffineEnvironment.transform 14 29909 env37860 = env37861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env37860 == env37861) = true)

def env37862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212199,1024,8660,4160,4194304,16,73736,8328,65,4270123,5393,4097,67618,1501,4194440,256,33,5457,74250]

theorem envBound37862 : H12AffineFastState.Bounded env37862 := by
  intro p hp
  have h : env37862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37861_37862 : H12AffineEnvironment.transform 13 5376 env37861 = env37862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37861 == env37862) = true)

theorem identity37862 : scanCanonicalize (H12AffineFastState.compose env37862 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound37862 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70862,10281,1024,8660,4160,4194304,16,73736,8328,65,4270123,5393,4097,67618,1501,4194440,256,33,5457,74250]

theorem envBound37863 : H12AffineFastState.Bounded env37863 := by
  intro p hp
  have h : env37863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37862_37863 : H12AffineEnvironment.transform 16 70862 env37862 = env37863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env37862 == env37863) = true)

theorem identity37863 : scanCanonicalize (H12AffineFastState.compose env37863 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound37863 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,479,5393,10281,1024,8660,4160,4194304,16,8663,8328,65,4205044,5393,4097,2557,1501,4194440,256,33,5457,9173]

theorem envBound37864 : H12AffineFastState.Bounded env37864 := by
  intro p hp
  have h : env37864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37863_37864 : H12AffineEnvironment.transform 15 479 env37863 = env37864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env37863 == env37864) = true)

theorem identity37864 : scanCanonicalize (H12AffineFastState.compose env37864 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37864 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,479,5393,2557,1024,0,4160,4194304,16,3,348,65,4196384,5393,4097,2557,1501,4194440,256,33,5457,513]

theorem envBound37865 : H12AffineFastState.Bounded env37865 := by
  intro p hp
  have h : env37865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37864_37865 : H12AffineEnvironment.transform 12 468 env37864 = env37865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37864 == env37865) = true)

theorem identity37865 : scanCanonicalize (H12AffineFastState.compose env37865 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound37865 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,479,5393,2557,1024,0,4160,248,16,3,348,65,2264,5393,4097,2557,1501,112,256,33,5457,513]

theorem envBound37866 : H12AffineFastState.Bounded env37866 := by
  intro p hp
  have h : env37866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37865_37866 : H12AffineEnvironment.transform 21 248 env37865 = env37866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env37865 == env37866) = true)

def env37867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212199,1024,8661,4160,4194304,16,73737,8328,65,4270122,5393,4096,67618,1501,4194440,256,32,5456,74250]

theorem envBound37867 : H12AffineFastState.Bounded env37867 := by
  intro p hp
  have h : env37867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37861_37867 : H12AffineEnvironment.transform 13 5377 env37861 = env37867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37861 == env37867) = true)

theorem identity37867 : scanCanonicalize (H12AffineFastState.compose env37867 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound37867 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70726,10401,1024,8661,4160,4194304,16,73737,8328,65,4270122,5393,4096,67618,1501,4194440,256,32,5456,74250]

theorem envBound37868 : H12AffineFastState.Bounded env37868 := by
  intro p hp
  have h : env37868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37867_37868 : H12AffineEnvironment.transform 16 70726 env37867 = env37868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env37867 == env37868) = true)

theorem identity37868 : scanCanonicalize (H12AffineFastState.compose env37868 (packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37868 : packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env37869 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,65536,70678,10401,1024,8581,4112,4194304,16,73737,8328,17,4270122,5393,4096,67618,1421,4194440,256,32,5376,74250]

theorem envBound37869 : H12AffineFastState.Bounded env37869 := by
  intro p hp
  have h : env37869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37868_37869 : H12AffineEnvironment.transform 5 16 env37868 = env37869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37868 == env37869) = true)

theorem identity37869 : scanCanonicalize (H12AffineFastState.compose env37869 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound37869 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37870 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,8323,13461,10401,1024,8581,4112,4194304,16,138,8328,17,4196521,5393,4096,10401,1421,4194440,256,32,5376,649]

theorem envBound37870 : H12AffineFastState.Bounded env37870 := by
  intro p hp
  have h : env37870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37869_37870 : H12AffineEnvironment.transform 15 8323 env37869 = env37870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env37869 == env37870) = true)

theorem identity37870 : scanCanonicalize (H12AffineFastState.compose env37870 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound37870 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37871 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,8323,13461,10401,1024,8581,4112,33,16,138,8328,17,2184,5393,4096,10401,1421,169,256,32,5376,649]

theorem envBound37871 : H12AffineFastState.Bounded env37871 := by
  intro p hp
  have h : env37871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37870_37871 : H12AffineEnvironment.transform 21 33 env37870 = env37871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env37870 == env37871) = true)

theorem identity37871 : scanCanonicalize (H12AffineFastState.compose env37871 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound37871 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37872 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,160,5377,292,35,5173,2049,1024,293,4112,33,16,138,40,17,2184,5393,4096,2049,1421,169,256,32,5376,649]

theorem envBound37872 : H12AffineFastState.Bounded env37872 := by
  intro p hp
  have h : env37872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37871_37872 : H12AffineEnvironment.transform 12 160 env37871 = env37872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env37871 == env37872) = true)

theorem identity37872 : scanCanonicalize (H12AffineFastState.compose env37872 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37872 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37873 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,292,35,5173,2049,1024,293,4112,33,16,2,40,17,2048,5393,4096,2049,1285,33,256,32,5376,513]

theorem envBound37873 : H12AffineFastState.Bounded env37873 := by
  intro p hp
  have h : env37873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37872_37873 : H12AffineEnvironment.transform 6 8 env37872 = env37873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37872 == env37873) = true)

theorem identity37873 : scanCanonicalize (H12AffineFastState.compose env37873 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37873 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37874 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5173,2049,1024,1,4112,33,16,2,40,17,2048,5173,4096,2049,1057,33,36,32,5156,513]

theorem envBound37874 : H12AffineFastState.Bounded env37874 := by
  intro p hp
  have h : env37874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37873_37874 : H12AffineEnvironment.transform 7 36 env37873 = env37874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37873 == env37874) = true)

theorem identity37874 : scanCanonicalize (H12AffineFastState.compose env37874 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound37874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37875 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,0,40,1061,0,35,1077,2049,1024,1,16,33,16,2,40,17,2048,1077,0,2049,1057,33,36,32,1060,513]

theorem envBound37875 : H12AffineFastState.Bounded env37875 := by
  intro p hp
  have h : env37875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37874_37875 : H12AffineEnvironment.transform 11 0 env37874 = env37875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env37874 == env37875) = true)

theorem identity37875 : scanCanonicalize (H12AffineFastState.compose env37875 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37875 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37876 : List Nat := [2,4,8,16,32,16,8,36,0,1024,2048,0,40,1061,0,35,1077,2049,1024,1,16,33,16,2,40,17,2048,1077,0,2049,1057,33,36,32,1060,1]

theorem envBound37876 : H12AffineFastState.Bounded env37876 := by
  intro p hp
  have h : env37876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37875_37876 : H12AffineEnvironment.transform 8 0 env37875 = env37876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37875 == env37876) = true)

theorem identity37876 : scanCanonicalize (H12AffineFastState.compose env37876 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound37876 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37877 : List Nat := [2,4,8,16,32,16,8,36,0,36,2048,0,40,1,0,35,17,2049,36,1,16,33,16,2,40,17,2048,17,0,2049,5,33,36,32,0,1]

theorem envBound37877 : H12AffineFastState.Bounded env37877 := by
  intro p hp
  have h : env37877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37876_37877 : H12AffineEnvironment.transform 9 36 env37876 = env37877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env37876 == env37877) = true)

theorem identity37877 : scanCanonicalize (H12AffineFastState.compose env37877 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37877 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37878 : List Nat := [2,4,8,16,32,16,8,36,0,36,1,0,40,1,0,35,17,0,36,1,16,33,16,2,40,17,1,17,0,0,5,33,36,32,0,1]

theorem envBound37878 : H12AffineFastState.Bounded env37878 := by
  intro p hp
  have h : env37878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37877_37878 : H12AffineEnvironment.transform 10 1 env37877 = env37878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37877 == env37878) = true)

def env37879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,17,98781,8328,65,4295167,5393,17664,67619,1500,4256861,256,21792,46213,74251]

theorem envBound37879 : H12AffineFastState.Bounded env37879 := by
  intro p hp
  have h : env37879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37859_37879 : H12AffineEnvironment.transform 22 17 env37859 = env37879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env37859 == env37879) = true)

theorem identity37879 : scanCanonicalize (H12AffineFastState.compose env37879 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound37879 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,144492,17,98781,8328,65,245139,5393,17664,67619,1500,180273,256,21792,46213,74251]

theorem envBound37880 : H12AffineFastState.Bounded env37880 := by
  intro p hp
  have h : env37880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37879_37880 : H12AffineEnvironment.transform 21 144492 env37879 = env37880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env37879 == env37880) = true)

def env37881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,144492,17,98645,8192,65,245019,5393,17664,67619,1364,180273,256,21792,46093,74251]

theorem envBound37881 : H12AffineFastState.Bounded env37881 := by
  intro p hp
  have h : env37881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37880_37881 : H12AffineEnvironment.transform 6 8 env37880 = env37881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37880 == env37881) = true)

theorem identity37881 : scanCanonicalize (H12AffineFastState.compose env37881 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37881 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,236851,1024,32769,4160,144492,17,98645,8192,65,245019,5393,4097,67619,1364,169264,256,33,46093,74251]

theorem envBound37882 : H12AffineFastState.Bounded env37882 := by
  intro p hp
  have h : env37882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37881_37882 : H12AffineEnvironment.transform 13 5377 env37881 = env37882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37881 == env37882) = true)

theorem identity37882 : scanCanonicalize (H12AffineFastState.compose env37882 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound37882 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,67619,1024,32769,4160,41340,17,98645,8192,65,75787,5393,4097,67619,1364,32,256,33,46093,74251]

theorem envBound37883 : H12AffineFastState.Bounded env37883 := by
  intro p hp
  have h : env37883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37882_37883 : H12AffineEnvironment.transform 16 38160 env37882 = env37883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env37882 == env37883) = true)

theorem identity37883 : scanCanonicalize (H12AffineFastState.compose env37883 (packedSelected [1,3,5,8,10,11,12,15,16,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37883 : packedSelected [1,3,5,8,10,11,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env37884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38160,10280,1024,32769,4160,41340,17,41310,8192,65,2048,5393,4097,10280,1364,32,256,33,46093,512]

theorem envBound37884 : H12AffineFastState.Bounded env37884 := by
  intro p hp
  have h : env37884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37883_37884 : H12AffineEnvironment.transform 15 8203 env37883 = env37884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37883 == env37884) = true)

theorem identity37884 : scanCanonicalize (H12AffineFastState.compose env37884 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound37884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5377,32768,375,38160,2388,1024,32769,4160,32768,17,32802,380,65,2048,5393,4097,2388,1364,32,256,33,38257,512]

theorem envBound37885 : H12AffineFastState.Bounded env37885 := by
  intro p hp
  have h : env37885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37884_37885 : H12AffineEnvironment.transform 12 380 env37884 = env37885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env37884 == env37885) = true)

theorem identity37885 : scanCanonicalize (H12AffineFastState.compose env37885 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound37885 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5377,1077,375,4389,2388,1024,1076,4160,1077,17,1047,380,65,2048,5393,4097,2388,1364,32,256,33,4420,512]

theorem envBound37886 : H12AffineFastState.Bounded env37886 := by
  intro p hp
  have h : env37886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37885_37886 : H12AffineEnvironment.transform 14 1077 env37885 = env37886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env37885 == env37886) = true)

theorem identity37886 : scanCanonicalize (H12AffineFastState.compose env37886 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound37886 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env37887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,380,2341,1077,375,3329,2388,1024,1076,3172,1077,17,1047,380,65,2048,2357,3109,2388,1364,32,256,33,3424,512]

theorem envBound37887 : H12AffineFastState.Bounded env37887 := by
  intro p hp
  have h : env37887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37886_37887 : H12AffineEnvironment.transform 11 3108 env37886 = env37887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env37886 == env37887) = true)

theorem identity37887 : scanCanonicalize (H12AffineFastState.compose env37887 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound37887 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37888 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2113,380,2341,80,375,2404,2388,101,81,2049,80,17,114,380,65,2048,2357,2112,2388,305,32,256,33,2309,512]

theorem envBound37888 : H12AffineFastState.Bounded env37888 := by
  intro p hp
  have h : env37888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37887_37888 : H12AffineEnvironment.transform 9 101 env37887 = env37888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env37887 == env37888) = true)

theorem identity37888 : scanCanonicalize (H12AffineFastState.compose env37888 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37888 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env37889 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,301,2341,1,294,2357,2309,52,0,2049,1,17,35,301,16,2048,2357,2065,2309,305,32,256,33,2309,512]

theorem envBound37889 : H12AffineFastState.Bounded env37889 := by
  intro p hp
  have h : env37889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37888_37889 : H12AffineEnvironment.transform 5 17 env37888 = env37889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37888 == env37889) = true)

theorem identity37889 : scanCanonicalize (H12AffineFastState.compose env37889 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound37889 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37890 : List Nat := [2,4,8,16,32,17,8,256,512,52,277,261,301,48,1,294,32,16,52,0,276,1,17,35,301,16,277,32,260,16,305,32,256,33,16,512]

theorem envBound37890 : H12AffineFastState.Bounded env37890 := by
  intro p hp
  have h : env37890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37889_37890 : H12AffineEnvironment.transform 10 277 env37889 = env37890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env37889 == env37890) = true)

theorem identity37890 : scanCanonicalize (H12AffineFastState.compose env37890 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound37890 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37891 : List Nat := [2,4,8,16,32,17,8,31,512,52,10,26,50,48,1,57,32,16,52,0,11,1,17,35,50,16,10,32,27,16,46,32,31,33,16,512]

theorem envBound37891 : H12AffineFastState.Bounded env37891 := by
  intro p hp
  have h : env37891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37890_37891 : H12AffineEnvironment.transform 7 31 env37890 = env37891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env37890 == env37891) = true)

theorem identity37891 : scanCanonicalize (H12AffineFastState.compose env37891 (packedSelected [1,7] rootPS)) = affineNative (2^(8+1) ^^^ 56) := by decide +kernel

theorem selectedBound37891 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env37892 : List Nat := [2,4,8,16,32,17,8,31,56,52,10,26,50,48,1,57,32,16,52,0,11,1,17,35,50,16,10,32,27,16,46,32,31,33,16,56]

theorem envBound37892 : H12AffineFastState.Bounded env37892 := by
  intro p hp
  have h : env37892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37891_37892 : H12AffineEnvironment.transform 8 56 env37891 = env37892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 56 env37891 == env37892) = true)

theorem identity37892 : scanCanonicalize (H12AffineFastState.compose env37892 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37892 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37893 : List Nat := [2,4,8,16,0,17,8,31,24,20,10,26,18,16,1,25,0,16,20,0,11,1,17,3,18,16,10,0,27,16,14,0,31,1,16,24]

theorem envBound37893 : H12AffineFastState.Bounded env37893 := by
  intro p hp
  have h : env37893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37892_37893 : H12AffineEnvironment.transform 4 0 env37892 = env37893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37892 == env37893) = true)

theorem identity37893 : scanCanonicalize (H12AffineFastState.compose env37893 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37893 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37894 : List Nat := [0,4,8,16,0,17,8,29,24,20,8,24,16,16,1,25,0,16,20,0,9,1,17,1,16,16,8,0,25,16,12,0,29,1,16,24]

theorem envBound37894 : H12AffineFastState.Bounded env37894 := by
  intro p hp
  have h : env37894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37893_37894 : H12AffineEnvironment.transform 0 0 env37893 = env37894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37893 == env37894) = true)

theorem identity37894 : scanCanonicalize (H12AffineFastState.compose env37894 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound37894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37895 : List Nat := [0,4,8,5,0,4,8,8,13,1,8,13,5,5,1,12,0,5,1,0,9,1,4,1,5,5,8,0,12,5,12,0,8,1,5,13]

theorem envBound37895 : H12AffineFastState.Bounded env37895 := by
  intro p hp
  have h : env37895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37894_37895 : H12AffineEnvironment.transform 3 5 env37894 = env37895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37894 == env37895) = true)

def env37896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,144492,17,98644,8193,65,245018,5393,17664,67619,1365,180273,256,21792,46092,74251]

theorem envBound37896 : H12AffineFastState.Bounded env37896 := by
  intro p hp
  have h : env37896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37880_37896 : H12AffineEnvironment.transform 6 9 env37880 = env37896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37880 == env37896) = true)

theorem identity37896 : scanCanonicalize (H12AffineFastState.compose env37896 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37896 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223599,1024,8540,4160,144492,17,73737,8193,65,203847,5393,17664,67619,1365,156012,256,21792,5457,74251]

theorem envBound37897 : H12AffineFastState.Bounded env37897 := by
  intro p hp
  have h : env37897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37896_37897 : H12AffineEnvironment.transform 14 8541 env37896 = env37897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37896 == env37897) = true)

theorem identity37897 : scanCanonicalize (H12AffineFastState.compose env37897 (packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound37897 : packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS < 2^1333 := by decide +kernel

def env37898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,78959,23808,1024,8540,4160,65539,17,73737,8193,65,10280,5393,17664,67619,1365,87299,256,21792,5457,74251]

theorem envBound37898 : H12AffineFastState.Bounded env37898 := by
  intro p hp
  have h : env37898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37897_37898 : H12AffineEnvironment.transform 16 78959 env37897 = env37898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env37897 == env37898) = true)

theorem identity37898 : scanCanonicalize (H12AffineFastState.compose env37898 (packedSelected [0,3,7,9,10,14,16,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound37898 : packedSelected [0,3,7,9,10,14,16,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env37899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,30042,16693,23808,1024,8540,4160,30041,17,21843,8193,65,10280,5393,17664,32121,1365,8281,256,21792,5457,22353]

theorem envBound37899 : H12AffineFastState.Bounded env37899 := by
  intro p hp
  have h : env37899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37898_37899 : H12AffineEnvironment.transform 15 30042 env37898 = env37899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env37898 == env37899) = true)

theorem identity37899 : scanCanonicalize (H12AffineFastState.compose env37899 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37899 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37900 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8313,29822,16401,23588,1024,8312,4160,29821,17,21623,8193,65,10280,5173,17444,31837,1137,8281,36,21508,5237,22133]

theorem envBound37900 : H12AffineFastState.Bounded env37900 := by
  intro p hp
  have h : env37900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37899_37900 : H12AffineEnvironment.transform 7 36 env37899 = env37900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37899 == env37900) = true)

theorem identity37900 : scanCanonicalize (H12AffineFastState.compose env37900 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound37900 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env37901 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5237,8313,8203,5220,2129,1024,8312,4160,8200,17,2,8193,65,10280,5173,4177,10280,1137,8281,36,113,5237,512]

theorem envBound37901 : H12AffineFastState.Bounded env37901 := by
  intro p hp
  have h : env37901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37900_37901 : H12AffineEnvironment.transform 13 5237 env37900 = env37901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env37900 == env37901) = true)

theorem identity37901 : scanCanonicalize (H12AffineFastState.compose env37901 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound37901 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37902 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,1100,5237,1077,1095,5220,2129,1024,1076,4160,1092,17,2,1101,65,3172,5173,4177,3172,1137,1045,36,113,5237,512]

theorem envBound37902 : H12AffineFastState.Bounded env37902 := by
  intro p hp
  have h : env37902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37901_37902 : H12AffineEnvironment.transform 12 1100 env37901 = env37902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env37901 == env37902) = true)

theorem identity37902 : scanCanonicalize (H12AffineFastState.compose env37902 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37902 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37903 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,4096,88,4193,33,83,4208,2129,20,32,4160,80,17,2,89,65,2160,4129,4177,2160,101,1,36,113,4193,512]

theorem envBound37903 : H12AffineFastState.Bounded env37903 := by
  intro p hp
  have h : env37903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37902_37903 : H12AffineEnvironment.transform 9 20 env37902 = env37903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37902 == env37903) = true)

def env37904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,8388608,98780,8328,65,12683759,5393,8406288,8456242,8390092,4256861,256,8410417,8434836,8462875]

theorem envBound37904 : H12AffineFastState.Bounded env37904 := by
  intro p hp
  have h : env37904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37858_37904 : H12AffineEnvironment.transform 20 4161 env37858 = env37904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37858 == env37904) = true)

def env37905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,16,98780,8328,65,4295167,5393,17664,67618,1500,4256861,256,21793,46212,74251]

theorem envBound37905 : H12AffineFastState.Bounded env37905 := by
  intro p hp
  have h : env37905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37904_37905 : H12AffineEnvironment.transform 22 16 env37904 = env37905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env37904 == env37905) = true)

def env37906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,16,98644,8192,65,4295031,5393,17664,67618,1364,4256861,256,21793,46092,74251]

theorem envBound37906 : H12AffineFastState.Bounded env37906 := by
  intro p hp
  have h : env37906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37905_37906 : H12AffineEnvironment.transform 6 8 env37905 = env37906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37905 == env37906) = true)

theorem identity37906 : scanCanonicalize (H12AffineFastState.compose env37906 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound37906 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4161,4194304,16,98644,8192,65,4295031,5393,17664,67618,1364,4256861,256,21793,46092,74251]

theorem envBound37907 : H12AffineFastState.Bounded env37907 := by
  intro p hp
  have h : env37907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37906_37907 : H12AffineEnvironment.transform 16 122907 env37906 = env37907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env37906 == env37907) = true)

theorem identity37907 : scanCanonicalize (H12AffineFastState.compose env37907 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound37907 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env37908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4161,32801,16,98644,8192,65,67926,5393,17664,67618,1364,29820,256,21793,46092,74251]

theorem envBound37908 : H12AffineFastState.Bounded env37908 := by
  intro p hp
  have h : env37908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37907_37908 : H12AffineEnvironment.transform 21 32801 env37907 = env37908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env37907 == env37908) = true)

theorem identity37908 : scanCanonicalize (H12AffineFastState.compose env37908 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound37908 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1024,32769,4161,32801,16,8542,8192,65,43356,5393,17664,43048,1364,29820,256,21793,46092,33281]

theorem envBound37909 : H12AffineFastState.Bounded env37909 := by
  intro p hp
  have h : env37909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37908_37909 : H12AffineEnvironment.transform 15 40970 env37908 = env37909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env37908 == env37909) = true)

theorem identity37909 : scanCanonicalize (H12AffineFastState.compose env37909 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37909 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,16401,10281,1024,1,4161,33,16,8542,8192,65,10588,5393,17664,10280,1364,29820,256,21793,13324,513]

theorem envBound37910 : H12AffineFastState.Bounded env37910 := by
  intro p hp
  have h : env37910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37909_37910 : H12AffineEnvironment.transform 14 0 env37909 = env37910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37909 == env37910) = true)

theorem identity37910 : scanCanonicalize (H12AffineFastState.compose env37910 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37910 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env37911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,343,16401,2420,1024,1,4161,33,16,3,349,65,2049,5393,17664,2421,1364,21793,256,21793,5457,513]

theorem envBound37911 : H12AffineFastState.Bounded env37911 := by
  intro p hp
  have h : env37911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37910_37911 : H12AffineEnvironment.transform 12 349 env37910 = env37911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37910 == env37911) = true)

theorem identity37911 : scanCanonicalize (H12AffineFastState.compose env37911 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound37911 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,0,343,4096,2420,1024,1,4161,33,16,3,349,65,2049,5393,5393,2421,1364,1328,256,1328,5457,513]

theorem envBound37912 : H12AffineFastState.Bounded env37912 := by
  intro p hp
  have h : env37912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37911_37912 : H12AffineEnvironment.transform 13 4113 env37911 = env37912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env37911 == env37912) = true)

theorem identity37912 : scanCanonicalize (H12AffineFastState.compose env37912 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound37912 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37913 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8,4113,0,2,4096,2081,1024,1,4161,33,16,3,8,65,2049,5188,5188,2080,1025,1125,85,1125,5124,513]

theorem envBound37913 : H12AffineFastState.Bounded env37913 := by
  intro p hp
  have h : env37913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37912_37913 : H12AffineEnvironment.transform 7 85 env37912 = env37913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env37912 == env37913) = true)

theorem identity37913 : scanCanonicalize (H12AffineFastState.compose env37913 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37913 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env37914 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8,4113,0,2,4096,2081,1024,1,4113,33,16,3,8,17,2049,5140,5140,2080,1025,1077,5,1077,5124,513]

theorem envBound37914 : H12AffineFastState.Bounded env37914 := by
  intro p hp
  have h : env37914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37913_37914 : H12AffineEnvironment.transform 5 16 env37913 = env37914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37913 == env37914) = true)

theorem identity37914 : scanCanonicalize (H12AffineFastState.compose env37914 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound37914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37915 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,48,8,33,0,2,48,2081,1024,1,33,33,16,3,8,17,2049,1060,1060,2080,1025,1077,5,1077,1076,513]

theorem envBound37915 : H12AffineFastState.Bounded env37915 := by
  intro p hp
  have h : env37915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37914_37915 : H12AffineEnvironment.transform 11 48 env37914 = env37915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37914 == env37915) = true)

theorem identity37915 : scanCanonicalize (H12AffineFastState.compose env37915 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound37915 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37916 : List Nat := [2,4,8,16,32,16,8,5,512,1024,545,48,8,33,0,2,48,512,1024,1,33,33,16,3,8,17,544,1060,1060,513,1025,1077,5,1077,1076,513]

theorem envBound37916 : H12AffineFastState.Bounded env37916 := by
  intro p hp
  have h : env37916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37915_37916 : H12AffineEnvironment.transform 10 545 env37915 = env37916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env37915 == env37916) = true)

theorem identity37916 : scanCanonicalize (H12AffineFastState.compose env37916 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound37916 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37917 : List Nat := [2,4,8,16,32,16,8,5,512,564,545,48,8,33,0,2,48,512,564,1,33,33,16,3,8,17,544,528,528,513,565,513,5,513,512,513]

theorem envBound37917 : H12AffineFastState.Bounded env37917 := by
  intro p hp
  have h : env37917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37916_37917 : H12AffineEnvironment.transform 9 564 env37916 = env37917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env37916 == env37917) = true)

theorem identity37917 : scanCanonicalize (H12AffineFastState.compose env37917 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37917 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37918 : List Nat := [2,4,8,16,16,16,8,5,512,516,529,0,8,17,0,2,0,512,516,1,17,17,16,3,8,17,528,528,528,513,517,513,5,513,512,513]

theorem envBound37918 : H12AffineFastState.Bounded env37918 := by
  intro p hp
  have h : env37918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37917_37918 : H12AffineEnvironment.transform 4 16 env37917 = env37918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37917 == env37918) = true)

theorem identity37918 : scanCanonicalize (H12AffineFastState.compose env37918 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37919 : List Nat := [2,4,8,16,16,16,8,5,1,5,16,0,8,17,0,2,0,1,5,1,17,17,16,3,8,17,17,17,17,0,4,0,5,0,1,0]

theorem envBound37919 : H12AffineFastState.Bounded env37919 := by
  intro p hp
  have h : env37919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37918_37919 : H12AffineEnvironment.transform 8 1 env37918 = env37919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37918 == env37919) = true)

def env37920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,16,98645,8193,65,4295030,5393,17664,67618,1365,4256861,256,21793,46093,74251]

theorem envBound37920 : H12AffineFastState.Bounded env37920 := by
  intro p hp
  have h : env37920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37905_37920 : H12AffineEnvironment.transform 6 9 env37905 = env37920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37905 == env37920) = true)

theorem identity37920 : scanCanonicalize (H12AffineFastState.compose env37920 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound37920 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,35189,1024,32769,4161,4194304,16,98645,8193,65,4295030,5393,17664,67618,1365,4256861,256,21793,46093,74251]

theorem envBound37921 : H12AffineFastState.Bounded env37921 := by
  intro p hp
  have h : env37921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37920_37921 : H12AffineEnvironment.transform 16 82247 env37920 = env37921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env37920 == env37921) = true)

theorem identity37921 : scanCanonicalize (H12AffineFastState.compose env37921 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound37921 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,65536,70678,35189,1024,32769,4161,4194304,16,98645,8193,65,4295030,5393,4177,67618,1365,4235532,256,112,46093,74251]

theorem envBound37922 : H12AffineFastState.Bounded env37922 := by
  intro p hp
  have h : env37922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37921_37922 : H12AffineEnvironment.transform 13 5457 env37921 = env37922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env37921 == env37922) = true)

theorem identity37922 : scanCanonicalize (H12AffineFastState.compose env37922 (packedSelected [0,4,5,7,8,10,19,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37922 : packedSelected [0,4,5,7,8,10,19,22,24,28] rootPS < 2^1333 := by decide +kernel

def env37923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,343,5441,35189,1024,32769,4161,4194304,16,32770,8193,65,4229153,5393,4177,2421,1365,4235532,256,112,46093,9052]

theorem envBound37923 : H12AffineFastState.Bounded env37923 := by
  intro p hp
  have h : env37923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37922_37923 : H12AffineEnvironment.transform 15 343 env37922 = env37923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37922 == env37923) = true)

theorem identity37923 : scanCanonicalize (H12AffineFastState.compose env37923 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 8281) := by decide +kernel

theorem selectedBound37923 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env37924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,343,5441,35189,1024,32769,4161,8281,16,32770,8193,65,43128,5393,4177,2421,1365,33109,256,112,46093,9052]

theorem envBound37924 : H12AffineFastState.Bounded env37924 := by
  intro p hp
  have h : env37924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37923_37924 : H12AffineEnvironment.transform 21 8281 env37923 = env37924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8281 env37923 == env37924) = true)

theorem identity37924 : scanCanonicalize (H12AffineFastState.compose env37924 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound37924 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5457,32768,343,5441,35189,1024,32769,4161,32,16,32770,120,65,34817,5393,4177,2421,1365,33109,256,112,38004,805]

theorem envBound37925 : H12AffineFastState.Bounded env37925 := by
  intro p hp
  have h : env37925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37924_37925 : H12AffineEnvironment.transform 12 121 env37924 = env37925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env37924 == env37925) = true)

theorem identity37925 : scanCanonicalize (H12AffineFastState.compose env37925 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37925 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env37926 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5156,32768,34,5172,34816,1024,32769,4161,32,16,32770,120,65,34817,5220,4177,2048,1056,32800,117,112,38004,592]

theorem envBound37926 : H12AffineFastState.Bounded env37926 := by
  intro p hp
  have h : env37926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37925_37926 : H12AffineEnvironment.transform 7 117 env37925 = env37926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37925 == env37926) = true)

theorem identity37926 : scanCanonicalize (H12AffineFastState.compose env37926 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37926 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37927 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5156,0,34,5172,2048,1024,1,4161,32,16,2,120,65,2049,5220,4177,2048,1056,32,117,112,5236,592]

theorem envBound37927 : H12AffineFastState.Bounded env37927 := by
  intro p hp
  have h : env37927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37926_37927 : H12AffineEnvironment.transform 14 0 env37926 = env37927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37926 == env37927) = true)

theorem identity37927 : scanCanonicalize (H12AffineFastState.compose env37927 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound37927 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env37928 : List Nat := [2,4,8,16,32,64,9,117,512,68,2048,4096,121,4192,0,34,4208,2048,68,1,4161,32,16,2,120,65,2049,4128,4177,2048,100,32,117,112,4144,592]

theorem envBound37928 : H12AffineFastState.Bounded env37928 := by
  intro p hp
  have h : env37928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37927_37928 : H12AffineEnvironment.transform 9 68 env37927 = env37928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env37927 == env37928) = true)

theorem identity37928 : scanCanonicalize (H12AffineFastState.compose env37928 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37928 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env37929 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,4096,41,4144,0,34,4128,2048,20,1,4113,32,16,2,40,17,2049,4128,4097,2048,52,32,37,32,4144,512]

theorem envBound37929 : H12AffineFastState.Bounded env37929 := by
  intro p hp
  have h : env37929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37928_37929 : H12AffineEnvironment.transform 5 16 env37928 = env37929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37928 == env37929) = true)

theorem identity37929 : scanCanonicalize (H12AffineFastState.compose env37929 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound37929 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37930 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,2586,41,2602,0,34,2618,2048,20,1,2571,32,16,2,40,17,2049,2618,2587,2048,52,32,37,32,2602,512]

theorem envBound37930 : H12AffineFastState.Bounded env37930 := by
  intro p hp
  have h : env37930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37929_37930 : H12AffineEnvironment.transform 11 2586 env37929 = env37930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env37929 == env37930) = true)

theorem identity37930 : scanCanonicalize (H12AffineFastState.compose env37930 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound37930 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37931 : List Nat := [2,4,8,16,32,16,9,37,42,20,2048,2096,41,2048,0,34,2064,2048,20,1,2081,32,16,2,40,17,2049,2064,2097,2048,52,32,37,32,2048,42]

theorem envBound37931 : H12AffineFastState.Bounded env37931 := by
  intro p hp
  have h : env37931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37930_37931 : H12AffineEnvironment.transform 8 42 env37930 = env37931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env37930 == env37931) = true)

theorem identity37931 : scanCanonicalize (H12AffineFastState.compose env37931 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound37931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37932 : List Nat := [2,4,8,16,32,16,9,37,42,20,6,54,41,6,0,34,22,6,20,1,39,32,16,2,40,17,7,22,55,6,52,32,37,32,6,42]

theorem envBound37932 : H12AffineFastState.Bounded env37932 := by
  intro p hp
  have h : env37932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37931_37932 : H12AffineEnvironment.transform 10 6 env37931 = env37932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env37931 == env37932) = true)

theorem identity37932 : scanCanonicalize (H12AffineFastState.compose env37932 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound37932 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37933 : List Nat := [2,4,8,16,6,16,9,3,12,20,6,16,15,6,0,4,22,6,20,1,1,6,16,2,14,17,7,22,17,6,18,6,3,6,6,12]

theorem envBound37933 : H12AffineFastState.Bounded env37933 := by
  intro p hp
  have h : env37933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37932_37933 : H12AffineEnvironment.transform 4 6 env37932 = env37933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env37932 == env37933) = true)

theorem identity37933 : scanCanonicalize (H12AffineFastState.compose env37933 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound37933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37934 : List Nat := [2,4,8,4,6,4,9,3,12,0,6,4,15,6,0,4,2,6,0,1,1,6,4,2,14,5,7,2,5,6,6,6,3,6,6,12]

theorem envBound37934 : H12AffineFastState.Bounded env37934 := by
  intro p hp
  have h : env37934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37933_37934 : H12AffineEnvironment.transform 3 4 env37933 = env37934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37933 == env37934) = true)

theorem identity37934 : scanCanonicalize (H12AffineFastState.compose env37934 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37934 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37935 : List Nat := [2,2,8,2,0,2,9,3,10,0,0,2,9,0,0,2,2,0,0,1,1,0,2,2,8,3,1,2,3,0,0,0,3,0,0,10]

theorem envBound37935 : H12AffineFastState.Bounded env37935 := by
  intro p hp
  have h : env37935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37934_37935 : H12AffineEnvironment.transform 1 2 env37934 = env37935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37934 == env37935) = true)

def env37936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,17,98780,8328,65,4295166,5393,17665,67619,1501,4256861,256,21792,46213,74250]

theorem envBound37936 : H12AffineFastState.Bounded env37936 := by
  intro p hp
  have h : env37936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37904_37936 : H12AffineEnvironment.transform 22 17 env37904 = env37936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env37904 == env37936) = true)

theorem identity37936 : scanCanonicalize (H12AffineFastState.compose env37936 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180409) := by decide +kernel

theorem selectedBound37936 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180409,17,98780,8328,65,215367,5393,17665,67619,1501,144612,256,21792,46213,74250]

theorem envBound37937 : H12AffineFastState.Bounded env37937 := by
  intro p hp
  have h : env37937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37936_37937 : H12AffineEnvironment.transform 21 180409 env37936 = env37937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env37936 == env37937) = true)

def env37938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180273,17,98644,8192,65,215367,5393,17665,67619,1365,144492,256,21792,46093,74250]

theorem envBound37938 : H12AffineFastState.Bounded env37938 := by
  intro p hp
  have h : env37938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37937_37938 : H12AffineEnvironment.transform 6 8 env37937 = env37938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37937 == env37938) = true)

theorem identity37938 : scanCanonicalize (H12AffineFastState.compose env37938 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound37938 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70679,56357,1024,32769,4161,119846,17,98644,8192,65,23888,5393,17665,67619,1365,73851,256,21792,46093,74250]

theorem envBound37939 : H12AffineFastState.Bounded env37939 := by
  intro p hp
  have h : env37939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37938_37939 : H12AffineEnvironment.transform 16 70679 env37938 = env37939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env37938 == env37939) = true)

theorem identity37939 : scanCanonicalize (H12AffineFastState.compose env37939 (packedSelected [1,10,16,19,20,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound37939 : packedSelected [1,10,16,19,20,28] rootPS < 2^1333 := by decide +kernel

def env37940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,5441,56357,1024,32769,4161,54640,17,32770,8192,65,23888,5393,17665,2421,1365,8493,256,21792,46093,9052]

theorem envBound37940 : H12AffineFastState.Bounded env37940 := by
  intro p hp
  have h : env37940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37939_37940 : H12AffineEnvironment.transform 15 342 env37939 = env37940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env37939 == env37940) = true)

theorem identity37940 : scanCanonicalize (H12AffineFastState.compose env37940 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37940 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env37941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,5441,56357,1024,32769,4161,54640,17,32770,349,65,23888,5393,17665,2421,1365,112,256,21792,38224,513]

theorem envBound37941 : H12AffineFastState.Bounded env37941 := by
  intro p hp
  have h : env37941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37940_37941 : H12AffineEnvironment.transform 12 349 env37940 = env37941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37940 == env37941) = true)

def env37942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180272,17,98645,8193,65,215367,5393,17665,67619,1364,144493,256,21792,46092,74250]

theorem envBound37942 : H12AffineFastState.Bounded env37942 := by
  intro p hp
  have h : env37942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37937_37942 : H12AffineEnvironment.transform 6 9 env37937 = env37942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37937 == env37942) = true)

theorem identity37942 : scanCanonicalize (H12AffineFastState.compose env37942 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37942 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223599,1024,8540,4161,156013,17,73736,8193,65,215367,5393,17665,67619,1364,144493,256,21792,5457,74250]

theorem envBound37943 : H12AffineFastState.Bounded env37943 := by
  intro p hp
  have h : env37943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37942_37943 : H12AffineEnvironment.transform 14 8541 env37942 = env37943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37942 == env37943) = true)

theorem identity37943 : scanCanonicalize (H12AffineFastState.compose env37943 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound37943 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,67619,1024,8540,4161,33,17,73736,8193,65,75787,5393,17665,67619,1364,21793,256,21792,5457,74250]

theorem envBound37944 : H12AffineFastState.Bounded env37944 := by
  intro p hp
  have h : env37944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37943_37944 : H12AffineEnvironment.transform 16 24908 env37943 = env37944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env37943 == env37944) = true)

theorem identity37944 : scanCanonicalize (H12AffineFastState.compose env37944 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound37944 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env37945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8495,24908,10508,1024,8540,4161,33,17,295,8193,65,2340,5393,17665,10508,1364,21793,256,21792,5457,805]

theorem envBound37945 : H12AffineFastState.Bounded env37945 := by
  intro p hp
  have h : env37945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37944_37945 : H12AffineEnvironment.transform 15 8495 env37944 = env37945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env37944 == env37945) = true)

theorem identity37945 : scanCanonicalize (H12AffineFastState.compose env37945 (packedSelected [2,4,9,12,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37945 : packedSelected [2,4,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env37946 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8313,8203,24680,10280,1024,8312,4161,33,17,3,8193,65,2048,5173,17445,10280,1136,21509,36,21508,5237,513]

theorem envBound37946 : H12AffineFastState.Bounded env37946 := by
  intro p hp
  have h : env37946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37945_37946 : H12AffineEnvironment.transform 7 36 env37945 = env37946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37945 == env37946) = true)

theorem identity37946 : scanCanonicalize (H12AffineFastState.compose env37946 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound37946 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37947 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,12392,8313,8203,4096,10280,1024,8312,4161,33,17,3,8193,65,2048,5173,13389,10280,1136,9325,36,9324,5237,513]

theorem envBound37947 : H12AffineFastState.Bounded env37947 := by
  intro p hp
  have h : env37947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37946_37947 : H12AffineEnvironment.transform 13 12392 env37946 = env37947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env37946 == env37947) = true)

theorem identity37947 : scanCanonicalize (H12AffineFastState.compose env37947 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound37947 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env37948 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,4096,8192,12392,8313,8203,4096,10280,101,8312,4161,33,17,3,8193,65,2048,4176,12328,10280,21,8200,36,8201,4112,513]

theorem envBound37948 : H12AffineFastState.Bounded env37948 := by
  intro p hp
  have h : env37948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37947_37948 : H12AffineEnvironment.transform 9 101 env37947 = env37948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env37947 == env37948) = true)

theorem identity37948 : scanCanonicalize (H12AffineFastState.compose env37948 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37948 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37949 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,12344,8233,8203,4096,10280,53,8232,4113,33,17,3,8193,17,2048,4096,12328,10280,21,8200,36,8201,4112,513]

theorem envBound37949 : H12AffineFastState.Bounded env37949 := by
  intro p hp
  have h : env37949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37948_37949 : H12AffineEnvironment.transform 5 16 env37948 = env37949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37948 == env37949) = true)

theorem identity37949 : scanCanonicalize (H12AffineFastState.compose env37949 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37949 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37950 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,41,4113,0,34,4096,2049,53,1,4113,33,17,3,40,17,2048,4096,4097,2049,21,33,36,32,4112,513]

theorem envBound37950 : H12AffineFastState.Bounded env37950 := by
  intro p hp
  have h : env37950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37949_37950 : H12AffineEnvironment.transform 12 41 env37949 = env37950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37949 == env37950) = true)

theorem identity37950 : scanCanonicalize (H12AffineFastState.compose env37950 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound37950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37951 : List Nat := [2,4,8,4,32,4,9,36,512,33,2048,4096,41,4101,0,34,4096,2049,33,1,4101,33,5,3,40,5,2048,4096,4097,2049,1,33,36,32,4100,513]

theorem envBound37951 : H12AffineFastState.Bounded env37951 := by
  intro p hp
  have h : env37951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37950_37951 : H12AffineEnvironment.transform 3 4 env37950 = env37951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37950 == env37951) = true)

theorem identity37951 : scanCanonicalize (H12AffineFastState.compose env37951 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound37951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37952 : List Nat := [2,4,8,4,32,4,9,36,38,33,2048,4096,41,4101,0,34,4096,2049,33,1,4101,33,5,3,40,5,2048,4096,4097,2049,1,33,36,32,4100,39]

theorem envBound37952 : H12AffineFastState.Bounded env37952 := by
  intro p hp
  have h : env37952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37951_37952 : H12AffineEnvironment.transform 8 38 env37951 = env37952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env37951 == env37952) = true)

theorem identity37952 : scanCanonicalize (H12AffineFastState.compose env37952 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound37952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37953 : List Nat := [2,4,8,4,32,4,9,36,38,33,2048,1,41,4,0,34,1,2049,33,1,4,33,5,3,40,5,2048,1,0,2049,1,33,36,32,5,39]

theorem envBound37953 : H12AffineFastState.Bounded env37953 := by
  intro p hp
  have h : env37953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37952_37953 : H12AffineEnvironment.transform 11 1 env37952 = env37953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env37952 == env37953) = true)

theorem identity37953 : scanCanonicalize (H12AffineFastState.compose env37953 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound37953 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37954 : List Nat := [2,4,8,4,32,4,9,36,38,33,10,1,41,4,0,34,1,11,33,1,4,33,5,3,40,5,10,1,0,11,1,33,36,32,5,39]

theorem envBound37954 : H12AffineFastState.Bounded env37954 := by
  intro p hp
  have h : env37954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37953_37954 : H12AffineEnvironment.transform 10 10 env37953 = env37954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env37953 == env37954) = true)

theorem identity37954 : scanCanonicalize (H12AffineFastState.compose env37954 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37954 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37955 : List Nat := [2,4,8,4,1,4,9,5,7,0,10,1,8,4,0,3,1,11,0,1,4,0,5,3,9,5,10,1,0,11,1,0,5,1,5,6]

theorem envBound37955 : H12AffineFastState.Bounded env37955 := by
  intro p hp
  have h : env37955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37954_37955 : H12AffineEnvironment.transform 4 1 env37954 = env37955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37954 == env37955) = true)

theorem identity37955 : scanCanonicalize (H12AffineFastState.compose env37955 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound37955 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env37956 : List Nat := [2,4,7,4,1,4,6,5,7,0,5,1,7,4,0,3,1,4,0,1,4,0,5,3,6,5,5,1,0,4,1,0,5,1,5,6]

theorem envBound37956 : H12AffineFastState.Bounded env37956 := by
  intro p hp
  have h : env37956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37955_37956 : H12AffineEnvironment.transform 2 7 env37955 = env37956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env37955 == env37956) = true)

def env37957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound37957 : H12AffineFastState.Bounded env37957 := by
  intro p hp
  have h : env37957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37753_37957 : H12AffineEnvironment.transform 18 1025 env37753 = env37957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env37753 == env37957) = true)

theorem identity37957 : scanCanonicalize (H12AffineFastState.compose env37957 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661170) := by decide +kernel

theorem selectedBound37957 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661170,8328,65,4450482,10857535,10507601,8830977,371874,15027570,257,2485279,2428347,297844]

theorem envBound37958 : H12AffineFastState.Bounded env37958 := by
  intro p hp
  have h : env37958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37957_37958 : H12AffineEnvironment.transform 23 8661170 env37957 = env37958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661170 env37957 == env37958) = true)

def env37959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450362,10857535,10507601,8830977,371754,15027570,257,2485279,2428211,297844]

theorem envBound37959 : H12AffineFastState.Bounded env37959 := by
  intro p hp
  have h : env37959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37958_37959 : H12AffineEnvironment.transform 6 8 env37958 = env37959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37958 == env37959) = true)

theorem identity37959 : scanCanonicalize (H12AffineFastState.compose env37959 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 256366) := by decide +kernel

theorem selectedBound37959 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env37960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,256366,1025,32769,2097152,4194304,8388608,8634708,8192,65,4450362,10634577,10507601,8464751,148804,14853148,257,2229617,2286685,221722]

theorem envBound37960 : H12AffineFastState.Bounded env37960 := by
  intro p hp
  have h : env37960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37959_37960 : H12AffineEnvironment.transform 17 256366 env37959 = env37960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 256366 env37959 == env37960) = true)

def env37961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108926,1025,32769,2097152,4194304,8388608,8487236,8192,65,4302890,10487105,10507601,8464751,1364,14738444,257,2114913,2139213,74250]

theorem envBound37961 : H12AffineFastState.Bounded env37961 := by
  intro p hp
  have h : env37961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37960_37961 : H12AffineEnvironment.transform 16 16400 env37960 = env37961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37960 == env37961) = true)

theorem identity37961 : scanCanonicalize (H12AffineFastState.compose env37961 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4235628) := by decide +kernel

theorem selectedBound37961 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env37962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108926,1025,32769,2097152,4194304,4235628,4268072,8192,65,4302890,6333485,6353981,4294659,1364,2114912,257,2114913,2139213,74250]

theorem envBound37962 : H12AffineFastState.Bounded env37962 := by
  intro p hp
  have h : env37962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37961_37962 : H12AffineEnvironment.transform 22 4235628 env37961 = env37962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235628 env37961 == env37962) = true)

theorem identity37962 : scanCanonicalize (H12AffineFastState.compose env37962 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122860) := by decide +kernel

theorem selectedBound37962 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108926,1025,32769,2097152,2122860,2147584,2180164,8192,65,2214982,49217,36945,2223215,1364,2114912,257,2114913,2139213,74250]

theorem envBound37963 : H12AffineFastState.Bounded env37963 := by
  intro p hp
  have h : env37963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37962_37963 : H12AffineEnvironment.transform 21 2122860 env37962 = env37963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122860 env37962 == env37963) = true)

theorem identity37963 : scanCanonicalize (H12AffineFastState.compose env37963 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37963 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env37964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,67619,1025,8540,2097152,2122860,2122845,2180164,8192,65,2190619,24860,12556,2182450,1364,2114912,257,2114913,2098448,74250]

theorem envBound37964 : H12AffineFastState.Bounded env37964 := by
  intro p hp
  have h : env37964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37963_37964 : H12AffineEnvironment.transform 14 8541 env37963 = env37964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37963 == env37964) = true)

theorem identity37964 : scanCanonicalize (H12AffineFastState.compose env37964 (packedSelected [3,4,5,9,19] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound37964 : packedSelected [3,4,5,9,19] rootPS < 2^1333 := by decide +kernel

def env37965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,67619,1025,8540,17729,8493,8476,65797,8192,65,75866,24860,12556,67699,1364,33,257,32,16465,74250]

theorem envBound37965 : H12AffineFastState.Bounded env37965 := by
  intro p hp
  have h : env37965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37964_37965 : H12AffineEnvironment.transform 20 17729 env37964 = env37965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env37964 == env37965) = true)

def env37966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,2097152,4194304,8388608,8487237,8192,65,4302891,10487104,10507601,8464751,1365,14738445,257,2114912,2139212,74251]

theorem envBound37966 : H12AffineFastState.Bounded env37966 := by
  intro p hp
  have h : env37966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37960_37966 : H12AffineEnvironment.transform 16 16401 env37960 = env37966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37960 == env37966) = true)

theorem identity37966 : scanCanonicalize (H12AffineFastState.compose env37966 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound37966 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env37967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,2097152,4194304,4194353,4292980,8192,65,4302891,6292849,6313312,4270430,1365,2155580,257,2114912,2139212,74251]

theorem envBound37967 : H12AffineFastState.Bounded env37967 := by
  intro p hp
  have h : env37967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37966_37967 : H12AffineEnvironment.transform 22 4194353 env37966 = env37967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env37966 == env37967) = true)

theorem identity37967 : scanCanonicalize (H12AffineFastState.compose env37967 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2147632) := by decide +kernel

theorem selectedBound37967 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env37968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,2097152,2147632,2147585,2180164,8192,65,2190619,49217,36944,2223214,1365,2155580,257,2114912,2139212,74251]

theorem envBound37968 : H12AffineFastState.Bounded env37968 := by
  intro p hp
  have h : env37968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37967_37968 : H12AffineEnvironment.transform 21 2147632 env37967 = env37968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2147632 env37967 == env37968) = true)

def env37969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,50448,32,17,98644,8192,65,108555,49217,36944,76158,1365,8492,257,32880,24924,74251]

theorem envBound37969 : H12AffineFastState.Bounded env37969 := by
  intro p hp
  have h : env37969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37968_37969 : H12AffineEnvironment.transform 20 50448 env37968 = env37969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env37968 == env37969) = true)

theorem identity37969 : scanCanonicalize (H12AffineFastState.compose env37969 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37969 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env37970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,67619,1025,8541,25676,32,17,73736,8192,65,67927,24861,12556,76158,1365,8492,257,8492,24924,74251]

theorem envBound37970 : H12AffineFastState.Bounded env37970 := by
  intro p hp
  have h : env37970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37969_37970 : H12AffineEnvironment.transform 14 8540 env37969 = env37970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37969 == env37970) = true)

theorem identity37970 : scanCanonicalize (H12AffineFastState.compose env37970 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound37970 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env37971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,8540,65536,4389,67619,1025,8541,13688,32,17,73736,8192,65,67927,12329,12556,76158,1365,8492,257,8492,12392,74251]

theorem envBound37971 : H12AffineFastState.Bounded env37971 := by
  intro p hp
  have h : env37971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37970_37971 : H12AffineEnvironment.transform 13 4404 env37970 = env37971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env37970 == env37971) = true)

theorem identity37971 : scanCanonicalize (H12AffineFastState.compose env37971 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound37971 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,8540,35,4389,2048,1025,8541,13688,32,17,8235,8192,65,2420,12329,12556,10589,1365,8492,257,8492,12392,8744]

theorem envBound37972 : H12AffineFastState.Bounded env37972 := by
  intro p hp
  have h : env37972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37971_37972 : H12AffineEnvironment.transform 15 35 env37971 = env37972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env37971 == env37972) = true)

theorem identity37972 : scanCanonicalize (H12AffineFastState.compose env37972 (packedSelected [1,2,8,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound37972 : packedSelected [1,2,8,10,16] rootPS < 2^1333 := by decide +kernel

def env37973 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,4404,8540,35,4389,2048,321,8541,12344,32,17,8235,8192,65,2420,12329,12556,10589,21,8492,257,8492,12392,8744]

theorem envBound37973 : H12AffineFastState.Bounded env37973 := by
  intro p hp
  have h : env37973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37972_37973 : H12AffineEnvironment.transform 9 320 env37972 = env37973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env37972 == env37973) = true)

theorem identity37973 : scanCanonicalize (H12AffineFastState.compose env37973 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound37973 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env37974 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,2168,4404,2340,35,4389,2048,321,2341,6208,32,17,2131,2168,65,2420,6225,6516,293,21,2388,257,2388,6160,2640]

theorem envBound37974 : H12AffineFastState.Bounded env37974 := by
  intro p hp
  have h : env37974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37973_37974 : H12AffineEnvironment.transform 12 2168 env37973 = env37974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env37973 == env37974) = true)

theorem identity37974 : scanCanonicalize (H12AffineFastState.compose env37974 (packedSelected [0,4,6,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37974 : packedSelected [0,4,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env37975 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,2168,4161,2129,35,4176,2048,52,2128,6208,32,17,2131,2168,65,2049,6225,6145,80,21,2081,116,2081,6160,2640]

theorem envBound37975 : H12AffineFastState.Bounded env37975 := by
  intro p hp
  have h : env37975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37974_37975 : H12AffineEnvironment.transform 7 117 env37974 = env37975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37974 == env37975) = true)

theorem identity37975 : scanCanonicalize (H12AffineFastState.compose env37975 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound37975 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env37976 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,16,2168,81,2129,35,64,2048,52,2128,2128,32,17,2131,2168,65,2049,2113,2065,80,21,2081,116,2081,2048,2640]

theorem envBound37976 : H12AffineFastState.Bounded env37976 := by
  intro p hp
  have h : env37976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37975_37976 : H12AffineEnvironment.transform 11 16 env37975 = env37976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37975 == env37976) = true)

theorem identity37976 : scanCanonicalize (H12AffineFastState.compose env37976 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound37976 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37977 : List Nat := [2,4,8,16,32,64,8,117,512,53,80,16,40,81,1,35,64,80,52,0,0,32,17,3,40,65,81,17,65,80,21,113,116,113,80,512]

theorem envBound37977 : H12AffineFastState.Bounded env37977 := by
  intro p hp
  have h : env37977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37976_37977 : H12AffineEnvironment.transform 10 80 env37976 = env37977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env37976 == env37977) = true)

theorem identity37977 : scanCanonicalize (H12AffineFastState.compose env37977 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37978 : List Nat := [2,4,8,16,17,64,8,68,512,4,80,16,25,81,1,18,64,80,5,0,0,17,17,3,25,65,81,17,65,80,21,64,69,64,80,512]

theorem envBound37978 : H12AffineFastState.Bounded env37978 := by
  intro p hp
  have h : env37978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37977_37978 : H12AffineEnvironment.transform 4 17 env37977 = env37978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37977 == env37978) = true)

theorem identity37978 : scanCanonicalize (H12AffineFastState.compose env37978 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound37978 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37979 : List Nat := [2,4,8,16,17,64,8,68,64,4,80,16,25,81,1,18,64,80,5,0,0,17,17,3,25,65,81,17,65,80,21,64,69,64,80,64]

theorem envBound37979 : H12AffineFastState.Bounded env37979 := by
  intro p hp
  have h : env37979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37978_37979 : H12AffineEnvironment.transform 8 64 env37978 = env37979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env37978 == env37979) = true)

theorem identity37979 : scanCanonicalize (H12AffineFastState.compose env37979 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound37979 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37980 : List Nat := [2,4,8,16,17,0,8,4,0,4,16,16,25,17,1,18,0,16,5,0,0,17,17,3,25,1,17,17,1,16,21,0,5,0,16,0]

theorem envBound37980 : H12AffineFastState.Bounded env37980 := by
  intro p hp
  have h : env37980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37979_37980 : H12AffineEnvironment.transform 5 0 env37979 = env37980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37979 == env37980) = true)

theorem identity37980 : scanCanonicalize (H12AffineFastState.compose env37980 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37981 : List Nat := [2,4,8,1,0,0,8,4,0,4,1,1,8,0,1,3,0,1,5,0,0,0,0,3,8,1,0,0,1,1,4,0,5,0,1,0]

theorem envBound37981 : H12AffineFastState.Bounded env37981 := by
  intro p hp
  have h : env37981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37980_37981 : H12AffineEnvironment.transform 3 1 env37980 = env37981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37980 == env37981) = true)

theorem identity37981 : scanCanonicalize (H12AffineFastState.compose env37981 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound37981 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37982 : List Nat := [2,4,6,1,0,0,6,4,0,4,1,1,6,0,1,3,0,1,5,0,0,0,0,3,6,1,0,0,1,1,4,0,5,0,1,0]

theorem envBound37982 : H12AffineFastState.Bounded env37982 := by
  intro p hp
  have h : env37982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37981_37982 : H12AffineEnvironment.transform 2 6 env37981 = env37982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env37981 == env37982) = true)

def env37983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,50449,33,16,98645,8192,65,108554,49217,36944,76159,1365,8493,257,32881,24925,74251]

theorem envBound37983 : H12AffineFastState.Bounded env37983 := by
  intro p hp
  have h : env37983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37968_37983 : H12AffineEnvironment.transform 20 50449 env37968 = env37983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env37968 == env37983) = true)

theorem identity37983 : scanCanonicalize (H12AffineFastState.compose env37983 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37983 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env37984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,50449,33,16,41310,8192,65,34817,49217,36944,2420,1365,8493,257,32881,24925,512]

theorem envBound37984 : H12AffineFastState.Bounded env37984 := by
  intro p hp
  have h : env37984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37983_37984 : H12AffineEnvironment.transform 15 8203 env37983 = env37984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37983 == env37984) = true)

theorem identity37984 : scanCanonicalize (H12AffineFastState.compose env37984 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound37984 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,16384,32768,82,16401,35188,1025,32769,50449,33,16,33031,89,65,34817,49217,36944,2420,1365,372,257,32881,16644,512]

theorem envBound37985 : H12AffineFastState.Bounded env37985 := by
  intro p hp
  have h : env37985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37984_37985 : H12AffineEnvironment.transform 12 89 env37984 = env37985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env37984 == env37985) = true)

theorem identity37985 : scanCanonicalize (H12AffineFastState.compose env37985 (packedSelected [0,7,16] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound37985 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env37986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,16384,293,82,16401,2129,1025,292,17460,33,16,34,89,65,2340,16740,4469,2420,1365,372,257,340,16644,512]

theorem envBound37986 : H12AffineFastState.Bounded env37986 := by
  intro p hp
  have h : env37986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37985_37986 : H12AffineEnvironment.transform 14 293 env37985 = env37986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env37985 == env37986) = true)

theorem identity37986 : scanCanonicalize (H12AffineFastState.compose env37986 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37986 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,5377,293,82,5392,2129,1025,292,4405,33,16,34,89,65,2340,5221,4469,2420,1365,372,257,340,5125,512]

theorem envBound37987 : H12AffineFastState.Bounded env37987 := by
  intro p hp
  have h : env37987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37986_37987 : H12AffineEnvironment.transform 13 5377 env37986 = env37987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37986 == env37987) = true)

theorem identity37987 : scanCanonicalize (H12AffineFastState.compose env37987 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37987 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37988 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,89,5377,261,82,5392,2129,1025,260,4373,1,16,2,89,65,2308,5189,4437,2388,1365,340,257,340,5125,512]

theorem envBound37988 : H12AffineFastState.Bounded env37988 := by
  intro p hp
  have h : env37988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37987_37988 : H12AffineEnvironment.transform 4 0 env37987 = env37988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37987 == env37988) = true)

theorem identity37988 : scanCanonicalize (H12AffineFastState.compose env37988 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37988 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37989 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,9,5377,261,2,5392,2049,1025,260,4373,1,16,2,9,17,2308,5141,4357,2308,1285,260,257,260,5125,512]

theorem envBound37989 : H12AffineFastState.Bounded env37989 := by
  intro p hp
  have h : env37989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37988_37989 : H12AffineEnvironment.transform 5 16 env37988 = env37989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37988 == env37989) = true)

theorem identity37989 : scanCanonicalize (H12AffineFastState.compose env37989 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound37989 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env37990 : List Nat := [2,4,8,16,0,16,8,256,512,1024,529,4096,9,5377,261,2,5392,528,1025,260,4373,1,16,2,9,17,789,5141,4357,789,1285,260,257,260,5125,512]

theorem envBound37990 : H12AffineFastState.Bounded env37990 := by
  intro p hp
  have h : env37990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37989_37990 : H12AffineEnvironment.transform 10 529 env37989 = env37990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env37989 == env37990) = true)

theorem identity37990 : scanCanonicalize (H12AffineFastState.compose env37990 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound37990 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37991 : List Nat := [2,4,8,16,0,16,8,256,512,768,529,4096,9,4609,261,2,4624,528,769,260,4373,1,16,2,9,17,789,4885,4357,789,517,260,257,260,4869,512]

theorem envBound37991 : H12AffineFastState.Bounded env37991 := by
  intro p hp
  have h : env37991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37990_37991 : H12AffineEnvironment.transform 9 768 env37990 = env37991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env37990 == env37991) = true)

theorem identity37991 : scanCanonicalize (H12AffineFastState.compose env37991 (packedSelected [0,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37991 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env37992 : List Nat := [2,4,8,16,0,16,8,256,17,273,0,4096,9,4112,261,2,4097,1,272,260,4373,1,16,2,9,17,260,4356,4357,260,20,260,257,260,4372,17]

theorem envBound37992 : H12AffineFastState.Bounded env37992 := by
  intro p hp
  have h : env37992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37991_37992 : H12AffineEnvironment.transform 8 17 env37991 = env37992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37991 == env37992) = true)

theorem identity37992 : scanCanonicalize (H12AffineFastState.compose env37992 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 273) := by decide +kernel

theorem selectedBound37992 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37993 : List Nat := [2,4,8,16,0,16,8,256,17,273,0,273,9,257,261,2,272,1,272,260,4,1,16,2,9,17,260,21,20,260,20,260,257,260,5,17]

theorem envBound37993 : H12AffineFastState.Bounded env37993 := by
  intro p hp
  have h : env37993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37992_37993 : H12AffineEnvironment.transform 11 273 env37992 = env37993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 273 env37992 == env37993) = true)

theorem identity37993 : scanCanonicalize (H12AffineFastState.compose env37993 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound37993 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37994 : List Nat := [2,4,8,16,0,16,8,0,17,17,0,17,9,1,5,2,16,1,16,4,4,1,16,2,9,17,4,21,20,4,20,4,1,4,5,17]

theorem envBound37994 : H12AffineFastState.Bounded env37994 := by
  intro p hp
  have h : env37994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37993_37994 : H12AffineEnvironment.transform 7 0 env37993 = env37994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env37993 == env37994) = true)

theorem identity37994 : scanCanonicalize (H12AffineFastState.compose env37994 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37994 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37995 : List Nat := [2,4,8,0,0,0,8,0,1,1,0,1,9,1,5,2,0,1,0,4,4,1,0,2,9,1,4,5,4,4,4,4,1,4,5,1]

theorem envBound37995 : H12AffineFastState.Bounded env37995 := by
  intro p hp
  have h : env37995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37994_37995 : H12AffineEnvironment.transform 3 0 env37994 = env37995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37994 == env37995) = true)

def env37996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661051,8193,65,4450363,10857535,10507601,8830977,371755,15027570,257,2485279,2428210,297844]

theorem envBound37996 : H12AffineFastState.Bounded env37996 := by
  intro p hp
  have h : env37996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37958_37996 : H12AffineEnvironment.transform 6 9 env37958 = env37996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37958 == env37996) = true)

theorem identity37996 : scanCanonicalize (H12AffineFastState.compose env37996 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound37996 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env37997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,8429902,8193,65,4450363,10560842,10507601,8538484,75102,14795783,257,2188650,2196551,513]

theorem envBound37997 : H12AffineFastState.Bounded env37997 := by
  intro p hp
  have h : env37997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37996_37997 : H12AffineEnvironment.transform 17 35189 env37996 = env37997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env37996 == env37997) = true)

def env37998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,16,41310,8193,65,4450363,2172250,2118977,149860,75102,6407191,257,2188650,2196551,513]

theorem envBound37998 : H12AffineFastState.Bounded env37998 := by
  intro p hp
  have h : env37998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37997_37998 : H12AffineEnvironment.transform 22 16 env37997 = env37998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env37997 == env37998) = true)

theorem identity37998 : scanCanonicalize (H12AffineFastState.compose env37998 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound37998 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2172250,2118977,76159,75102,6407191,257,2188650,2196551,513]

theorem envBound37999 : H12AffineFastState.Bounded env37999 := by
  intro p hp
  have h : env37999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37998_37999 : H12AffineEnvironment.transform 16 90139 env37998 = env37999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env37998 == env37999) = true)

theorem identity37999 : scanCanonicalize (H12AffineFastState.compose env37999 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound37999 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1025,32769,2097152,4194304,16,41310,8193,65,4229152,2139148,2118977,43049,41992,6309185,257,2155580,2098449,513]

theorem envBound38000 : H12AffineFastState.Bounded env38000 := by
  intro p hp
  have h : env38000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37999_38000 : H12AffineEnvironment.transform 15 33110 env37999 = env38000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env37999 == env38000) = true)

theorem identity38000 : scanCanonicalize (H12AffineFastState.compose env38000 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38000 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env38001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1025,8541,2097152,4194304,16,2,8193,65,4204924,2098512,2118977,2421,1364,6309185,257,2114912,2098449,513]

theorem envBound38001 : H12AffineFastState.Bounded env38001 := by
  intro p hp
  have h : env38001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38000_38001 : H12AffineEnvironment.transform 14 8540 env38000 = env38001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38000 == env38001) = true)

theorem identity38001 : scanCanonicalize (H12AffineFastState.compose env38001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound38001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1025,8541,2097152,32,16,2,8193,65,10588,2098512,2118977,2421,1364,2114913,257,2114912,2098449,513]

theorem envBound38002 : H12AffineFastState.Bounded env38002 := by
  intro p hp
  have h : env38002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38001_38002 : H12AffineEnvironment.transform 21 32 env38001 = env38002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env38001 == env38002) = true)

theorem identity38002 : scanCanonicalize (H12AffineFastState.compose env38002 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound38002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1025,8541,25628,32,16,2,8193,65,10588,24908,12637,2421,1364,8573,257,8572,24845,513]

theorem envBound38003 : H12AffineFastState.Bounded env38003 := by
  intro p hp
  have h : env38003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38002_38003 : H12AffineEnvironment.transform 20 25628 env38002 = env38003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env38002 == env38003) = true)

theorem identity38003 : scanCanonicalize (H12AffineFastState.compose env38003 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound38003 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,16384,113,295,16401,2308,1025,112,17713,32,16,2,300,65,2161,16481,4208,2421,1364,80,257,81,16416,513]

theorem envBound38004 : H12AffineFastState.Bounded env38004 := by
  intro p hp
  have h : env38004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38003_38004 : H12AffineEnvironment.transform 12 301 env38003 = env38004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env38003 == env38004) = true)

theorem identity38004 : scanCanonicalize (H12AffineFastState.compose env38004 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38004 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38005 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,16384,32,295,16401,2308,1025,33,17713,32,16,2,300,16,2080,16432,4129,2340,1285,1,257,0,16416,513]

theorem envBound38005 : H12AffineFastState.Bounded env38005 := by
  intro p hp
  have h : env38005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38004_38005 : H12AffineEnvironment.transform 5 17 env38004 = env38005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38004 == env38005) = true)

theorem identity38005 : scanCanonicalize (H12AffineFastState.compose env38005 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38005 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env38006 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,16384,0,263,16401,2308,1025,1,17681,0,16,2,268,16,2048,16400,4097,2308,1285,1,257,0,16384,513]

theorem envBound38006 : H12AffineFastState.Bounded env38006 := by
  intro p hp
  have h : env38006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38005_38006 : H12AffineEnvironment.transform 4 0 env38005 = env38006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38005 == env38006) = true)

theorem identity38006 : scanCanonicalize (H12AffineFastState.compose env38006 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound38006 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38007 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,260,269,16384,0,263,16401,2308,1025,1,17681,0,16,2,268,16,2048,16400,261,2308,1285,1,257,0,16384,513]

theorem envBound38007 : H12AffineFastState.Bounded env38007 := by
  intro p hp
  have h : env38007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38006_38007 : H12AffineEnvironment.transform 11 260 env38006 = env38007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env38006 == env38007) = true)

theorem identity38007 : scanCanonicalize (H12AffineFastState.compose env38007 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1541) := by decide +kernel

theorem selectedBound38007 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38008 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,260,269,1541,0,263,1556,2308,1025,1,788,0,16,2,268,16,2048,1557,261,2308,1285,1,257,0,1541,513]

theorem envBound38008 : H12AffineFastState.Bounded env38008 := by
  intro p hp
  have h : env38008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38007_38008 : H12AffineEnvironment.transform 13 1541 env38007 = env38008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1541 env38007 == env38008) = true)

theorem identity38008 : scanCanonicalize (H12AffineFastState.compose env38008 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound38008 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38009 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,260,269,529,0,263,512,2308,21,1,788,0,16,2,268,16,2048,513,261,2308,273,1,257,0,529,513]

theorem envBound38009 : H12AffineFastState.Bounded env38009 := by
  intro p hp
  have h : env38009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38008_38009 : H12AffineEnvironment.transform 9 20 env38008 = env38009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38008 == env38009) = true)

theorem identity38009 : scanCanonicalize (H12AffineFastState.compose env38009 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound38009 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38010 : List Nat := [2,4,8,16,0,17,9,256,261,20,2048,260,269,276,0,263,261,2308,21,1,17,0,16,2,268,16,2048,260,261,2308,273,1,257,0,276,260]

theorem envBound38010 : H12AffineFastState.Bounded env38010 := by
  intro p hp
  have h : env38010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38009_38010 : H12AffineEnvironment.transform 8 261 env38009 = env38010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env38009 == env38010) = true)

theorem identity38010 : scanCanonicalize (H12AffineFastState.compose env38010 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound38010 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38011 : List Nat := [2,4,8,16,0,17,9,256,261,20,16,260,269,276,0,263,261,276,21,1,17,0,16,2,268,16,16,260,261,276,273,1,257,0,276,260]

theorem envBound38011 : H12AffineFastState.Bounded env38011 := by
  intro p hp
  have h : env38011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38010_38011 : H12AffineEnvironment.transform 10 16 env38010 = env38011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env38010 == env38011) = true)

def env38012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,17,41311,8193,65,4450363,2172251,2118976,149861,75102,6407190,257,2188650,2196551,513]

theorem envBound38012 : H12AffineFastState.Bounded env38012 := by
  intro p hp
  have h : env38012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37997_38012 : H12AffineEnvironment.transform 22 17 env37997 = env38012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env37997 == env38012) = true)

theorem identity38012 : scanCanonicalize (H12AffineFastState.compose env38012 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound38012 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env38013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,115735,4194304,17,41311,8193,65,4450363,57676,102743,149861,75102,4194305,257,41341,16464,513]

theorem envBound38013 : H12AffineFastState.Bounded env38013 := by
  intro p hp
  have h : env38013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38012_38013 : H12AffineEnvironment.transform 20 115735 env38012 = env38013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env38012 == env38013) = true)

def env38014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9293,1025,11577,92463,4194304,17,3175,8193,65,4408579,19572,81007,149861,75102,4194305,257,3141,16464,513]

theorem envBound38014 : H12AffineFastState.Bounded env38014 := by
  intro p hp
  have h : env38014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38013_38014 : H12AffineEnvironment.transform 14 11576 env38013 = env38014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env38013 == env38014) = true)

theorem identity38014 : scanCanonicalize (H12AffineFastState.compose env38014 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85282) := by decide +kernel

theorem selectedBound38014 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env38015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,85282,9293,1025,11577,92463,4194304,17,3175,8193,65,4196385,19572,81007,66631,75102,4194305,257,3141,16464,513]

theorem envBound38015 : H12AffineFastState.Bounded env38015 := by
  intro p hp
  have h : env38015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38014_38015 : H12AffineEnvironment.transform 16 85282 env38014 = env38015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85282 env38014 == env38015) = true)

theorem identity38015 : scanCanonicalize (H12AffineFastState.compose env38015 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound38015 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env38016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8540,65536,82246,9293,1025,8541,91467,4194304,17,3,8193,65,4195397,16400,77835,66631,75102,4194305,257,33,16464,513]

theorem envBound38016 : H12AffineFastState.Bounded env38016 := by
  intro p hp
  have h : env38016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38015_38016 : H12AffineEnvironment.transform 10 1124 env38015 = env38016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env38015 == env38016) = true)

def env38017 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,16384,8460,65536,82198,9245,1025,8461,91419,4194304,17,3,8193,17,4195349,16400,77835,66583,75022,4194305,257,33,16384,513]

theorem envBound38017 : H12AffineFastState.Bounded env38017 := by
  intro p hp
  have h : env38017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38016_38017 : H12AffineEnvironment.transform 5 16 env38016 = env38017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38016 == env38017) = true)

theorem identity38017 : scanCanonicalize (H12AffineFastState.compose env38017 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38017 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38018 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,16384,8460,8202,24860,9245,1025,8461,17681,4194304,17,3,8193,17,4195349,16400,4097,9245,1284,4194305,257,33,16384,513]

theorem envBound38018 : H12AffineFastState.Bounded env38018 := by
  intro p hp
  have h : env38018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38017_38018 : H12AffineEnvironment.transform 15 8202 env38017 = env38018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38017 == env38018) = true)

theorem identity38018 : scanCanonicalize (H12AffineFastState.compose env38018 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38018 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38019 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,269,16384,1,263,16401,1296,1025,0,17681,4194304,17,3,268,17,4195349,16400,4097,1296,1284,4194305,257,33,16384,513]

theorem envBound38019 : H12AffineFastState.Bounded env38019 := by
  intro p hp
  have h : env38019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38018_38019 : H12AffineEnvironment.transform 12 269 env38018 = env38019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38018 == env38019) = true)

theorem identity38019 : scanCanonicalize (H12AffineFastState.compose env38019 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound38019 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38020 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,269,16384,1,263,16401,1296,1025,0,17681,21509,17,3,268,17,20496,16400,4097,1296,1284,21508,257,33,16384,513]

theorem envBound38020 : H12AffineFastState.Bounded env38020 := by
  intro p hp
  have h : env38020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38019_38020 : H12AffineEnvironment.transform 21 21509 env38019 = env38020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env38019 == env38020) = true)

theorem identity38020 : scanCanonicalize (H12AffineFastState.compose env38020 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound38020 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38021 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,269,5156,1,263,5173,1296,1025,0,4405,33,17,3,268,17,1076,5172,4097,1296,1284,32,257,33,5156,513]

theorem envBound38021 : H12AffineFastState.Bounded env38021 := by
  intro p hp
  have h : env38021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38020_38021 : H12AffineEnvironment.transform 13 5156 env38020 = env38021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env38020 == env38021) = true)

def env38022 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,544,269,1540,1,263,1557,1296,1025,0,789,33,17,3,268,17,1076,1556,545,1296,1284,32,257,33,1540,513]

theorem envBound38022 : H12AffineFastState.Bounded env38022 := by
  intro p hp
  have h : env38022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38021_38022 : H12AffineEnvironment.transform 11 544 env38021 = env38022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env38021 == env38022) = true)

def env38023 : List Nat := [2,4,8,16,32,16,9,256,512,768,820,544,269,260,1,263,277,528,769,0,789,33,17,3,268,17,820,276,545,528,516,32,257,33,260,513]

theorem envBound38023 : H12AffineFastState.Bounded env38023 := by
  intro p hp
  have h : env38023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38022_38023 : H12AffineEnvironment.transform 9 768 env38022 = env38023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env38022 == env38023) = true)

theorem identity38023 : scanCanonicalize (H12AffineFastState.compose env38023 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound38023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38024 : List Nat := [2,4,8,16,32,16,9,256,277,21,33,309,269,260,1,263,277,261,20,0,0,33,17,3,268,17,33,276,308,261,273,32,257,33,260,276]

theorem envBound38024 : H12AffineFastState.Bounded env38024 := by
  intro p hp
  have h : env38024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38023_38024 : H12AffineEnvironment.transform 8 277 env38023 = env38024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env38023 == env38024) = true)

def env38025 : List Nat := [2,4,8,16,0,16,9,256,277,21,1,277,269,260,1,263,277,261,20,0,0,1,17,3,268,17,1,276,276,261,273,0,257,1,260,276]

theorem envBound38025 : H12AffineFastState.Bounded env38025 := by
  intro p hp
  have h : env38025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38024_38025 : H12AffineEnvironment.transform 4 0 env38024 = env38025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38024 == env38025) = true)

theorem identity38025 : scanCanonicalize (H12AffineFastState.compose env38025 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38026 : List Nat := [2,4,8,16,0,16,9,4,17,21,1,17,9,0,1,3,17,1,20,0,0,1,17,3,8,17,1,16,16,1,21,0,5,1,0,16]

theorem envBound38026 : H12AffineFastState.Bounded env38026 := by
  intro p hp
  have h : env38026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38025_38026 : H12AffineEnvironment.transform 7 4 env38025 = env38026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38025 == env38026) = true)

def leafEnv38026 : List Nat := [2,4,8,16,0,16,9,4,17,21,1,17,9,0,1,3,17,1,20,0,0,1,17,3,20,8,1,17,1,16,16,1,21,0,5,1,5,2,0,16,1,0,0]

def active38026 : List Nat := [0,1,2,3]

def tree38026 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38026 : H12WitnessSearch.Good tree38026 := H12GlobalWitnessIndex.good

theorem leafIdentity38026 : H12AffineFastState.composeSystem env38026 rootObs = leafEnv38026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38026 rootObs == leafEnv38026) = true)

theorem terminalChecked38026 : H12PackedTerminal.terminalCheckFast leafEnv38026 active38026 tree38026 = true := by decide +kernel

def env38027 : List Nat := [2,4,8,16,1,16,9,256,277,21,0,276,269,260,1,263,277,261,20,0,0,0,17,3,268,17,0,276,277,261,273,1,257,0,260,276]

theorem envBound38027 : H12AffineFastState.Bounded env38027 := by
  intro p hp
  have h : env38027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38024_38027 : H12AffineEnvironment.transform 4 1 env38024 = env38027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38024 == env38027) = true)

theorem identity38027 : scanCanonicalize (H12AffineFastState.compose env38027 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38028 : List Nat := [2,4,8,11,1,11,9,256,270,14,0,271,269,260,1,263,270,261,15,0,0,0,10,3,268,10,0,271,270,261,266,1,257,0,260,271]

theorem envBound38028 : H12AffineFastState.Bounded env38028 := by
  intro p hp
  have h : env38028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38027_38028 : H12AffineEnvironment.transform 3 11 env38027 = env38028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38027 == env38028) = true)

def leafEnv38028 : List Nat := [2,4,8,11,1,11,9,256,270,14,0,271,269,260,1,263,270,261,15,0,0,0,10,3,267,268,1,10,0,271,270,261,266,1,257,0,5,262,260,271,1,0,0]

def active38028 : List Nat := [0,1,2,7]

def tree38028 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38028 : H12WitnessSearch.Good tree38028 := H12GlobalWitnessIndex.good

theorem leafIdentity38028 : H12AffineFastState.composeSystem env38028 rootObs = leafEnv38028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38028 rootObs == leafEnv38028) = true)

theorem terminalChecked38028 : H12PackedTerminal.terminalCheckFast leafEnv38028 active38028 tree38028 = true := by decide +kernel

def env38029 : List Nat := [2,4,8,16,32,16,9,256,512,769,821,544,269,261,1,263,276,529,768,0,789,33,17,3,268,17,821,277,545,529,517,32,257,33,261,513]

theorem envBound38029 : H12AffineFastState.Bounded env38029 := by
  intro p hp
  have h : env38029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38022_38029 : H12AffineEnvironment.transform 9 769 env38022 = env38029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env38022 == env38029) = true)

theorem identity38029 : scanCanonicalize (H12AffineFastState.compose env38029 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38030 : List Nat := [2,4,8,16,32,16,9,5,512,516,560,544,8,0,1,2,17,529,517,0,528,33,17,3,9,17,560,16,545,529,517,32,4,33,0,513]

theorem envBound38030 : H12AffineFastState.Bounded env38030 := by
  intro p hp
  have h : env38030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38029_38030 : H12AffineEnvironment.transform 7 5 env38029 = env38030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38029 == env38030) = true)

def env38031 : List Nat := [2,4,8,16,32,16,9,5,48,52,0,16,8,0,1,2,17,33,53,0,32,33,17,3,9,17,0,16,17,33,53,32,4,33,0,49]

theorem envBound38031 : H12AffineFastState.Bounded env38031 := by
  intro p hp
  have h : env38031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38030_38031 : H12AffineEnvironment.transform 8 48 env38030 = env38031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38030 == env38031) = true)

end H12CloudChart0