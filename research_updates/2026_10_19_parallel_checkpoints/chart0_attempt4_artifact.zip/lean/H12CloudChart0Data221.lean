import H12CloudChart0Data220

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound55962 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79250,32240,1024,29909,4161,87295,65951,29831,8328,65,23889,70815,83086,32040,1500,22008,256,21792,16465,74251]

theorem envBound55963 : H12AffineFastState.Bounded env55963 := by
  intro p hp
  have h : env55963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55962_55963 : H12AffineEnvironment.transform 16 79250 env55962 = env55963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env55962 == env55963) = true)

theorem identity55963 : scanCanonicalize (H12AffineFastState.compose env55963 (packedSelected [5,8,10,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55963 : packedSelected [5,8,10,19,24,28] rootPS < 2^1333 := by decide +kernel

def env55964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,5528,32240,1024,29909,4161,29941,8597,29831,8328,65,23889,13461,25732,32040,1500,22008,256,21792,16465,513]

theorem envBound55964 : H12AffineFastState.Bounded env55964 := by
  intro p hp
  have h : env55964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55963_55964 : H12AffineEnvironment.transform 15 8202 env55963 = env55964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55963 == env55964) = true)

theorem identity55964 : scanCanonicalize (H12AffineFastState.compose env55964 (packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55964 : packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env55965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,21976,262,5528,23804,1024,21977,4161,22009,153,21899,388,65,23889,5529,17800,23588,1500,22008,256,21792,16465,513]

theorem envBound55965 : H12AffineFastState.Bounded env55965 := by
  intro p hp
  have h : env55965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55964_55965 : H12AffineEnvironment.transform 12 268 env55964 = env55965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55964 == env55965) = true)

theorem identity55965 : scanCanonicalize (H12AffineFastState.compose env55965 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55965 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,217,262,5528,2557,1024,216,4161,248,153,138,388,65,2128,5529,4233,2341,1500,249,256,33,5456,513]

theorem envBound55966 : H12AffineFastState.Bounded env55966 := by
  intro p hp
  have h : env55966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55965_55966 : H12AffineEnvironment.transform 13 5377 env55965 = env55966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55965 == env55966) = true)

theorem identity55966 : scanCanonicalize (H12AffineFastState.compose env55966 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound55966 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55967 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,268,4540,217,262,4389,2557,189,216,4161,248,153,138,388,65,2128,4388,4233,2341,353,249,256,33,4589,513]

theorem envBound55967 : H12AffineFastState.Bounded env55967 := by
  intro p hp
  have h : env55967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55966_55967 : H12AffineEnvironment.transform 9 189 env55966 = env55967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env55966 == env55967) = true)

theorem identity55967 : scanCanonicalize (H12AffineFastState.compose env55967 (packedSelected [2,6,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55967 : packedSelected [2,6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55968 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,268,4405,80,262,4389,2420,52,81,4161,113,16,3,269,65,2128,4388,4096,2341,353,112,256,33,4452,513]

theorem envBound55968 : H12AffineFastState.Bounded env55968 := by
  intro p hp
  have h : env55968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55967_55968 : H12AffineEnvironment.transform 6 9 env55967 = env55968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55967 == env55968) = true)

theorem identity55968 : scanCanonicalize (H12AffineFastState.compose env55968 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2666) := by decide +kernel

theorem selectedBound55968 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55969 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2666,268,2911,80,262,2895,2420,52,81,2603,113,16,3,269,65,2128,2894,2666,2341,353,112,256,33,2830,513]

theorem envBound55969 : H12AffineFastState.Bounded env55969 := by
  intro p hp
  have h : env55969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55968_55969 : H12AffineEnvironment.transform 11 2666 env55968 = env55969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2666 env55968 == env55969) = true)

theorem identity55969 : scanCanonicalize (H12AffineFastState.compose env55969 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound55969 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env55970 : List Nat := [2,4,8,16,26,64,9,256,512,14,2048,2640,268,2911,80,262,2895,2382,14,81,2577,75,16,3,269,65,2128,2894,2640,2335,347,74,256,27,2830,513]

theorem envBound55970 : H12AffineFastState.Bounded env55970 := by
  intro p hp
  have h : env55970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55969_55970 : H12AffineEnvironment.transform 4 26 env55969 = env55970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env55969 == env55970) = true)

theorem identity55970 : scanCanonicalize (H12AffineFastState.compose env55970 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55970 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55971 : List Nat := [2,4,8,16,26,17,9,256,512,14,2048,2561,268,2830,1,262,2846,2335,14,0,2577,26,16,3,269,16,2049,2847,2561,2335,266,27,256,27,2830,513]

theorem envBound55971 : H12AffineFastState.Bounded env55971 := by
  intro p hp
  have h : env55971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55970_55971 : H12AffineEnvironment.transform 5 17 env55970 = env55971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55970 == env55971) = true)

theorem identity55971 : scanCanonicalize (H12AffineFastState.compose env55971 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55971 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55972 : List Nat := [2,4,8,16,26,17,9,4,512,14,2048,2561,8,2570,1,2,2586,2075,14,0,2577,26,16,3,9,16,2049,2587,2561,2075,14,27,4,27,2570,513]

theorem envBound55972 : H12AffineFastState.Bounded env55972 := by
  intro p hp
  have h : env55972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55971_55972 : H12AffineEnvironment.transform 7 4 env55971 = env55972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55971 == env55972) = true)

theorem identity55972 : scanCanonicalize (H12AffineFastState.compose env55972 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound55972 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55973 : List Nat := [2,4,8,16,26,17,9,4,512,14,11,522,8,513,1,2,529,16,14,0,538,26,16,3,9,16,10,528,522,16,14,27,4,27,513,513]

theorem envBound55973 : H12AffineFastState.Bounded env55973 := by
  intro p hp
  have h : env55973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55972_55973 : H12AffineEnvironment.transform 10 11 env55972 = env55973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env55972 == env55973) = true)

theorem identity55973 : scanCanonicalize (H12AffineFastState.compose env55973 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55973 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55974 : List Nat := [2,4,2,16,16,17,3,4,512,4,1,512,2,513,1,2,529,16,4,0,528,16,16,3,3,16,0,528,512,16,4,17,4,17,513,513]

theorem envBound55974 : H12AffineFastState.Bounded env55974 := by
  intro p hp
  have h : env55974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55973_55974 : H12AffineEnvironment.transform 2 2 env55973 = env55974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55973 == env55974) = true)

theorem identity55974 : scanCanonicalize (H12AffineFastState.compose env55974 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound55974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55975 : List Nat := [2,4,2,16,16,17,3,4,5,4,1,5,2,4,1,2,20,16,4,0,21,16,16,3,3,16,0,21,5,16,4,17,4,17,4,4]

theorem envBound55975 : H12AffineFastState.Bounded env55975 := by
  intro p hp
  have h : env55975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55974_55975 : H12AffineEnvironment.transform 8 5 env55974 = env55975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env55974 == env55975) = true)

theorem identity55975 : scanCanonicalize (H12AffineFastState.compose env55975 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound55975 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55976 : List Nat := [2,4,2,4,4,5,3,4,5,4,1,5,2,4,1,2,0,4,4,0,1,4,4,3,3,4,0,1,5,4,4,5,4,5,4,4]

theorem envBound55976 : H12AffineFastState.Bounded env55976 := by
  intro p hp
  have h : env55976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55975_55976 : H12AffineEnvironment.transform 3 4 env55975 = env55976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env55975 == env55976) = true)

theorem identity55976 : scanCanonicalize (H12AffineFastState.compose env55976 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55976 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55977 : List Nat := [1,4,1,4,4,5,0,4,5,4,1,5,1,4,1,1,0,4,4,0,1,4,4,0,0,4,0,1,5,4,4,5,4,5,4,4]

theorem envBound55977 : H12AffineFastState.Bounded env55977 := by
  intro p hp
  have h : env55977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55976_55977 : H12AffineEnvironment.transform 0 1 env55976 = env55977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55976 == env55977) = true)

def env55978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32241,1024,29909,4161,156013,144396,213268,8328,65,23888,139532,160029,32040,1500,22009,256,21792,16465,74251]

theorem envBound55978 : H12AffineFastState.Bounded env55978 := by
  intro p hp
  have h : env55978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55961_55978 : H12AffineEnvironment.transform 17 32241 env55961 = env55978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env55961 == env55978) = true)

theorem identity55978 : scanCanonicalize (H12AffineFastState.compose env55978 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound55978 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79130,32241,1024,29909,4161,87159,65814,29710,8328,65,23888,70678,82951,32040,1500,22009,256,21792,16465,74251]

theorem envBound55979 : H12AffineFastState.Bounded env55979 := by
  intro p hp
  have h : env55979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55978_55979 : H12AffineEnvironment.transform 16 79130 env55978 = env55979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env55978 == env55979) = true)

theorem identity55979 : scanCanonicalize (H12AffineFastState.compose env55979 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30163) := by decide +kernel

theorem selectedBound55979 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env55980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30163,16585,32241,1024,29909,4161,8612,29893,29710,8328,65,23888,25029,12756,32040,1500,22009,256,21792,16465,22488]

theorem envBound55980 : H12AffineFastState.Bounded env55980 := by
  intro p hp
  have h : env55980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55979_55980 : H12AffineEnvironment.transform 15 30163 env55979 = env55980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30163 env55979 == env55980) = true)

theorem identity55980 : scanCanonicalize (H12AffineFastState.compose env55980 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound55980 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env55981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,263,13341,2341,1024,1,4161,8612,17,218,8328,65,10628,5393,12756,2556,1500,8493,256,8692,13445,8972]

theorem envBound55981 : H12AffineFastState.Bounded env55981 := by
  intro p hp
  have h : env55981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55980_55981 : H12AffineEnvironment.transform 13 13524 env55980 = env55981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env55980 == env55981) = true)

theorem identity55981 : scanCanonicalize (H12AffineFastState.compose env55981 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound55981 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env55982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5237,0,263,5308,2341,1024,1,4161,261,17,218,41,65,2341,5393,4469,2556,1500,396,256,341,5156,941]

theorem envBound55982 : H12AffineFastState.Bounded env55982 := by
  intro p hp
  have h : env55982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55981_55982 : H12AffineEnvironment.transform 12 161 env55981 = env55982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env55981 == env55982) = true)

theorem identity55982 : scanCanonicalize (H12AffineFastState.compose env55982 (packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55982 : packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env55983 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,161,5237,0,171,5308,2185,1024,1,4161,169,17,218,41,65,2185,5309,4313,2128,1136,32,172,249,5156,513]

theorem envBound55983 : H12AffineFastState.Bounded env55983 := by
  intro p hp
  have h : env55983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55982_55983 : H12AffineEnvironment.transform 7 172 env55982 = env55983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55982 == env55983) = true)

theorem identity55983 : scanCanonicalize (H12AffineFastState.compose env55983 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55983 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55984 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5157,0,171,5308,2185,1024,1,4113,169,17,138,41,17,2185,5309,4233,2048,1056,32,172,169,5156,513]

theorem envBound55984 : H12AffineFastState.Bounded env55984 := by
  intro p hp
  have h : env55984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55983_55984 : H12AffineEnvironment.transform 5 16 env55983 = env55984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55983 == env55984) = true)

theorem identity55984 : scanCanonicalize (H12AffineFastState.compose env55984 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound55984 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55985 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,4096,161,4248,0,171,4097,2185,189,1,4113,169,17,138,41,17,2185,4096,4233,2048,157,32,172,169,4249,513]

theorem envBound55985 : H12AffineFastState.Bounded env55985 := by
  intro p hp
  have h : env55985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55984_55985 : H12AffineEnvironment.transform 9 189 env55984 = env55985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env55984 == env55985) = true)

def env55986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513341,510001,8328,65,6705548,2510012,396525,2136508,2102684,6729200,256,21793,46212,2175563]

theorem envBound55986 : H12AffineFastState.Bounded env55986 := by
  intro p hp
  have h : env55986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55862_55986 : H12AffineEnvironment.transform 22 2513341 env55862 = env55986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513341 env55862 == env55986) = true)

def env55987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513341,510001,8328,65,2409524,2510012,396525,2136508,2102684,2373704,256,21793,46212,2175563]

theorem envBound55987 : H12AffineFastState.Bounded env55987 := by
  intro p hp
  have h : env55987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55986_55987 : H12AffineEnvironment.transform 21 169400 env55986 = env55987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env55986 == env55987) = true)

def env55988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,510001,8328,65,316532,417020,396525,35324,1500,272392,256,21793,46212,74251]

theorem envBound55988 : H12AffineFastState.Bounded env55988 := by
  intro p hp
  have h : env55988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55987_55988 : H12AffineEnvironment.transform 20 4160 env55987 = env55988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55987 == env55988) = true)

theorem identity55988 : scanCanonicalize (H12AffineFastState.compose env55988 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound55988 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,169400,412157,400622,8328,65,316532,417020,396525,35324,1500,272392,256,21793,46212,63188]

theorem envBound55989 : H12AffineFastState.Bounded env55989 := by
  intro p hp
  have h : env55989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55988_55989 : H12AffineEnvironment.transform 15 54495 env55988 = env55989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env55988 == env55989) = true)

def env55990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146912,1024,32769,4160,169400,29725,8462,8328,65,190868,24860,12557,35324,1500,136680,256,21793,46212,63188]

theorem envBound55990 : H12AffineFastState.Bounded env55990 := by
  intro p hp
  have h : env55990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55989_55990 : H12AffineEnvironment.transform 17 146912 env55989 = env55990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env55989 == env55990) = true)

theorem identity55990 : scanCanonicalize (H12AffineFastState.compose env55990 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55990 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30082,131072,146912,1024,8540,4160,144613,29725,8462,8328,65,149705,24860,12557,10401,1500,136680,256,21793,5593,22409]

theorem envBound55991 : H12AffineFastState.Bounded env55991 := by
  intro p hp
  have h : env55991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55990_55991 : H12AffineEnvironment.transform 14 8541 env55990 = env55991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55990 == env55991) = true)

theorem identity55991 : scanCanonicalize (H12AffineFastState.compose env55991 (packedSelected [0,3,4,5,7,8,17,22,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55991 : packedSelected [0,3,4,5,7,8,17,22,28] rootPS < 2^1333 := by decide +kernel

def env55992 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,30082,131072,146864,1024,8460,4112,144565,29725,8462,8328,17,149657,24860,12557,10401,1420,136632,256,21793,5513,22409]

theorem envBound55992 : H12AffineFastState.Bounded env55992 := by
  intro p hp
  have h : env55992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55991_55992 : H12AffineEnvironment.transform 5 16 env55991 = env55992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55991 == env55992) = true)

theorem identity55992 : scanCanonicalize (H12AffineFastState.compose env55992 (packedSelected [10,17,18,23,31] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55992 : packedSelected [10,17,18,23,31] rootPS < 2^1333 := by decide +kernel

def env55993 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,1,21646,131072,138428,1024,0,4112,136633,21777,2,388,17,149657,16400,4097,2477,1420,136632,256,21793,5513,22409]

theorem envBound55993 : H12AffineFastState.Bounded env55993 := by
  intro p hp
  have h : env55993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55992_55993 : H12AffineEnvironment.transform 12 268 env55992 = env55993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55992 == env55993) = true)

theorem identity55993 : scanCanonicalize (H12AffineFastState.compose env55993 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound55993 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env55994 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,1,262,131072,138428,1024,0,4112,136633,153,2,388,17,138513,5528,4097,2477,1420,136632,256,169,5513,513]

theorem envBound55994 : H12AffineFastState.Bounded env55994 := by
  intro p hp
  have h : env55994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55993_55994 : H12AffineEnvironment.transform 13 5512 env55993 = env55994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env55993 == env55994) = true)

theorem identity55994 : scanCanonicalize (H12AffineFastState.compose env55994 (packedSelected [1,8,10] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound55994 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env55995 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,1,262,5309,2049,1024,0,4112,260,153,2,388,17,2476,5528,4097,2477,1420,261,256,169,5513,513]

theorem envBound55995 : H12AffineFastState.Bounded env55995 := by
  intro p hp
  have h : env55995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55994_55995 : H12AffineEnvironment.transform 16 5309 env55994 = env55995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env55994 == env55995) = true)

theorem identity55995 : scanCanonicalize (H12AffineFastState.compose env55995 (packedSelected [0,2,6,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55995 : packedSelected [0,2,6,7,14] rootPS < 2^1333 := by decide +kernel

def env55996 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5172,2049,1024,0,4112,260,16,2,269,17,2341,5393,4097,2340,1285,261,256,32,5376,513]

theorem envBound55996 : H12AffineFastState.Bounded env55996 := by
  intro p hp
  have h : env55996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55995_55996 : H12AffineEnvironment.transform 6 9 env55995 = env55996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55995 == env55996) = true)

def env55997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146913,1024,32769,4160,169400,29724,8463,8328,65,190869,24861,12556,35324,1500,136681,256,21793,46212,63188]

theorem envBound55997 : H12AffineFastState.Bounded env55997 := by
  intro p hp
  have h : env55997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55989_55997 : H12AffineEnvironment.transform 17 146913 env55989 = env55997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env55989 == env55997) = true)

theorem identity55997 : scanCanonicalize (H12AffineFastState.compose env55997 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound55997 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,131072,146913,1024,8660,4160,144493,29724,8463,8328,65,149568,24861,12556,10281,1500,136681,256,21793,5457,22273]

theorem envBound55998 : H12AffineFastState.Bounded env55998 := by
  intro p hp
  have h : env55998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55997_55998 : H12AffineEnvironment.transform 14 8661 env55997 = env55998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env55997 == env55998) = true)

theorem identity55998 : scanCanonicalize (H12AffineFastState.compose env55998 (packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound55998 : packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS < 2^1333 := by decide +kernel

def env55999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,5529,10360,1024,8660,4160,8692,29724,8463,8328,65,24025,24861,12556,10281,1500,112,256,21793,5457,22273]

theorem envBound55999 : H12AffineFastState.Bounded env55999 := by
  intro p hp
  have h : env55999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55998_55999 : H12AffineEnvironment.transform 16 5529 env55998 = env55999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env55998 == env55999) = true)

theorem identity55999 : scanCanonicalize (H12AffineFastState.compose env55999 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound55999 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env56000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,80,21647,5529,2557,1024,81,4160,113,21913,138,269,65,24025,16536,4233,2476,1500,112,256,21793,5457,22273]

theorem envBound56000 : H12AffineFastState.Bounded env56000 := by
  intro p hp
  have h : env56000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55999_56000 : H12AffineEnvironment.transform 12 389 env55999 = env56000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env55999 == env56000) = true)

theorem identity56000 : scanCanonicalize (H12AffineFastState.compose env56000 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56000 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env56001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,80,399,5529,2557,1024,81,4160,113,153,138,269,65,2265,5528,4233,2476,1500,112,256,33,5457,513]

theorem envBound56001 : H12AffineFastState.Bounded env56001 := by
  intro p hp
  have h : env56001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56000_56001 : H12AffineEnvironment.transform 13 5376 env56000 = env56001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56000 == env56001) = true)

theorem identity56001 : scanCanonicalize (H12AffineFastState.compose env56001 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound56001 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env56002 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,389,4588,80,399,4469,2557,236,81,4160,113,153,138,269,65,2265,4468,4233,2476,304,112,256,33,4541,513]

theorem envBound56002 : H12AffineFastState.Bounded env56002 := by
  intro p hp
  have h : env56002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56001_56002 : H12AffineEnvironment.transform 9 236 env56001 = env56002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env56001 == env56002) = true)

theorem identity56002 : scanCanonicalize (H12AffineFastState.compose env56002 (packedSelected [0,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound56002 : packedSelected [0,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56003 : List Nat := [2,4,8,16,32,64,88,256,512,52,2048,4096,349,4404,80,343,4469,2341,52,81,4160,113,65,82,269,65,2049,4468,4177,2420,304,112,256,33,4453,513]

theorem envBound56003 : H12AffineFastState.Bounded env56003 := by
  intro p hp
  have h : env56003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56002_56003 : H12AffineEnvironment.transform 6 88 env56002 = env56003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env56002 == env56003) = true)

theorem identity56003 : scanCanonicalize (H12AffineFastState.compose env56003 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56003 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56004 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4404,0,263,4389,2341,52,1,4112,33,17,2,269,17,2049,4388,4097,2340,304,32,256,33,4405,513]

theorem envBound56004 : H12AffineFastState.Bounded env56004 := by
  intro p hp
  have h : env56004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56003_56004 : H12AffineEnvironment.transform 5 16 env56003 = env56004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56003 == env56004) = true)

theorem identity56004 : scanCanonicalize (H12AffineFastState.compose env56004 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56004 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56005 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,0,35,4097,2049,52,1,4112,33,17,2,41,17,2049,4096,4097,2048,20,32,36,33,4113,513]

theorem envBound56005 : H12AffineFastState.Bounded env56005 := by
  intro p hp
  have h : env56005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56004_56005 : H12AffineEnvironment.transform 7 36 env56004 = env56005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56004 == env56005) = true)

theorem identity56005 : scanCanonicalize (H12AffineFastState.compose env56005 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound56005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56006 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2096,41,2080,0,35,2097,2049,52,1,2080,33,17,2,41,17,2049,2096,2097,2048,20,32,36,33,2081,513]

theorem envBound56006 : H12AffineFastState.Bounded env56006 := by
  intro p hp
  have h : env56006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56005_56006 : H12AffineEnvironment.transform 11 2096 env56005 = env56006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env56005 == env56006) = true)

theorem identity56006 : scanCanonicalize (H12AffineFastState.compose env56006 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound56006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56007 : List Nat := [2,4,8,16,32,16,8,36,512,52,528,544,41,560,0,35,545,529,52,1,560,33,17,2,41,17,529,544,545,528,20,32,36,33,561,513]

theorem envBound56007 : H12AffineFastState.Bounded env56007 := by
  intro p hp
  have h : env56007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56006_56007 : H12AffineEnvironment.transform 10 528 env56006 = env56007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env56006 == env56007) = true)

theorem identity56007 : scanCanonicalize (H12AffineFastState.compose env56007 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56007 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56008 : List Nat := [2,4,8,16,0,16,8,4,512,20,528,512,9,528,0,3,513,529,20,1,528,1,17,2,9,17,529,512,513,528,20,0,4,1,529,513]

theorem envBound56008 : H12AffineFastState.Bounded env56008 := by
  intro p hp
  have h : env56008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56007_56008 : H12AffineEnvironment.transform 4 0 env56007 = env56008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56007 == env56008) = true)

def env56009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,510001,8328,65,316533,417021,396525,35325,1501,272393,256,21793,46212,74250]

theorem envBound56009 : H12AffineFastState.Bounded env56009 := by
  intro p hp
  have h : env56009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55987_56009 : H12AffineEnvironment.transform 20 4161 env55987 = env56009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55987 == env56009) = true)

theorem identity56009 : scanCanonicalize (H12AffineFastState.compose env56009 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound56009 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,169400,73755,41430,8328,65,245138,79130,91402,35325,1501,213486,256,21793,46212,74250]

theorem envBound56010 : H12AffineFastState.Bounded env56010 := by
  intro p hp
  have h : env56010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56009_56010 : H12AffineEnvironment.transform 17 223719 env56009 = env56010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env56009 == env56010) = true)

def env56011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67755,1024,32769,4161,62708,73755,41430,8328,65,122078,79130,91402,35325,1501,73890,256,21793,46212,74250]

theorem envBound56011 : H12AffineFastState.Bounded env56011 := by
  intro p hp
  have h : env56011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56010_56011 : H12AffineEnvironment.transform 16 24908 env56010 = env56011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env56010 == env56011) = true)

theorem identity56011 : scanCanonicalize (H12AffineFastState.compose env56011 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound56011 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env56012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,24908,67755,1024,136,4161,29821,73755,8543,8328,65,89175,79130,91402,2420,1501,73890,256,21793,13325,74250]

theorem envBound56012 : H12AffineFastState.Bounded env56012 := by
  intro p hp
  have h : env56012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56011_56012 : H12AffineEnvironment.transform 14 137 env56011 = env56012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env56011 == env56012) = true)

theorem identity56012 : scanCanonicalize (H12AffineFastState.compose env56012 (packedSelected [2,3,4,5,6,10,16,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56012 : packedSelected [2,3,4,5,6,10,16,17,22] rootPS < 2^1333 := by decide +kernel

def env56013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,5392,67755,1024,136,4161,33,73755,8543,8328,65,75787,79130,69974,2420,1501,73890,256,8573,13325,74250]

theorem envBound56013 : H12AffineFastState.Bounded env56013 := by
  intro p hp
  have h : env56013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56012_56013 : H12AffineEnvironment.transform 13 13404 env56012 = env56013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56012 == env56013) = true)

theorem identity56013 : scanCanonicalize (H12AffineFastState.compose env56013 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56013 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env56014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,5392,10400,1024,136,4161,33,16,8543,8328,65,2048,5393,12637,2420,1501,169,256,8573,13325,513]

theorem envBound56014 : H12AffineFastState.Bounded env56014 := by
  intro p hp
  have h : env56014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56013_56014 : H12AffineEnvironment.transform 15 8203 env56013 = env56014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56013 == env56014) = true)

theorem identity56014 : scanCanonicalize (H12AffineFastState.compose env56014 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound56014 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env56015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,478,5392,2421,1024,136,4161,33,16,138,349,65,2048,5393,4232,2420,1501,169,256,168,5592,513]

theorem envBound56015 : H12AffineFastState.Bounded env56015 := by
  intro p hp
  have h : env56015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56014_56015 : H12AffineEnvironment.transform 12 469 env56014 = env56015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env56014 == env56015) = true)

theorem identity56015 : scanCanonicalize (H12AffineFastState.compose env56015 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56015 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5392,2421,1024,1,4161,33,16,3,349,65,2048,5393,4097,2420,1364,32,256,33,5457,513]

theorem envBound56016 : H12AffineFastState.Bounded env56016 := by
  intro p hp
  have h : env56016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56015_56016 : H12AffineEnvironment.transform 6 9 env56015 = env56016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56015 == env56016) = true)

theorem identity56016 : scanCanonicalize (H12AffineFastState.compose env56016 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound56016 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,16,348,1296,0,343,1280,2421,1024,1,81,33,16,3,349,65,2048,1281,17,2420,1364,32,256,33,1345,513]

theorem envBound56017 : H12AffineFastState.Bounded env56017 := by
  intro p hp
  have h : env56017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56016_56017 : H12AffineEnvironment.transform 11 16 env56016 = env56017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env56016 == env56017) = true)

theorem identity56017 : scanCanonicalize (H12AffineFastState.compose env56017 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1604) := by decide +kernel

theorem selectedBound56017 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env56018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1604,16,348,1296,0,343,1280,1841,1024,1,81,33,16,3,349,65,1604,1281,17,1840,1364,32,256,33,1345,513]

theorem envBound56018 : H12AffineFastState.Bounded env56018 := by
  intro p hp
  have h : env56018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56017_56018 : H12AffineEnvironment.transform 10 1604 env56017 = env56018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1604 env56017 == env56018) = true)

theorem identity56018 : scanCanonicalize (H12AffineFastState.compose env56018 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound56018 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56019 : List Nat := [2,4,8,16,32,64,9,256,512,817,373,16,348,545,0,343,561,0,817,1,81,33,16,3,349,65,373,560,17,1,613,32,256,33,624,513]

theorem envBound56019 : H12AffineFastState.Bounded env56019 := by
  intro p hp
  have h : env56019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56018_56019 : H12AffineEnvironment.transform 9 817 env56018 = env56019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env56018 == env56019) = true)

theorem identity56019 : scanCanonicalize (H12AffineFastState.compose env56019 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound56019 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56020 : List Nat := [2,4,8,16,32,64,9,256,325,116,373,16,348,356,0,343,372,0,116,1,81,33,16,3,349,65,373,373,17,1,288,32,256,33,309,324]

theorem envBound56020 : H12AffineFastState.Bounded env56020 := by
  intro p hp
  have h : env56020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56019_56020 : H12AffineEnvironment.transform 8 325 env56019 = env56020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env56019 == env56020) = true)

theorem identity56020 : scanCanonicalize (H12AffineFastState.compose env56020 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56020 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env56021 : List Nat := [2,4,8,16,0,64,9,256,325,84,341,16,348,324,0,343,340,0,84,1,81,1,16,3,349,65,341,341,17,1,256,0,256,1,277,324]

theorem envBound56021 : H12AffineFastState.Bounded env56021 := by
  intro p hp
  have h : env56021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56020_56021 : H12AffineEnvironment.transform 4 0 env56020 = env56021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56020 == env56021) = true)

theorem identity56021 : scanCanonicalize (H12AffineFastState.compose env56021 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56021 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env56022 : List Nat := [2,4,8,16,0,64,9,4,65,84,81,16,88,64,0,83,80,0,84,1,81,1,16,3,89,65,81,81,17,1,4,0,4,1,17,64]

theorem envBound56022 : H12AffineFastState.Bounded env56022 := by
  intro p hp
  have h : env56022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56021_56022 : H12AffineEnvironment.transform 7 4 env56021 = env56022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56021 == env56022) = true)

theorem identity56022 : scanCanonicalize (H12AffineFastState.compose env56022 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56022 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56023 : List Nat := [2,4,8,1,0,64,9,4,65,69,64,1,73,64,0,66,65,0,69,1,64,1,1,3,72,65,64,64,0,1,4,0,4,1,0,64]

theorem envBound56023 : H12AffineFastState.Bounded env56023 := by
  intro p hp
  have h : env56023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56022_56023 : H12AffineEnvironment.transform 3 1 env56022 = env56023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56022 == env56023) = true)

theorem identity56023 : scanCanonicalize (H12AffineFastState.compose env56023 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56024 : List Nat := [2,4,8,1,0,0,9,4,1,5,0,1,9,0,0,2,1,0,5,1,0,1,1,3,8,1,0,0,0,1,4,0,4,1,0,0]

theorem envBound56024 : H12AffineFastState.Bounded env56024 := by
  intro p hp
  have h : env56024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56023_56024 : H12AffineEnvironment.transform 5 0 env56023 = env56024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56023 == env56024) = true)

def env56025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67754,1024,32769,4161,62709,73755,41430,8328,65,122079,79130,91402,35325,1501,73891,256,21793,46212,74250]

theorem envBound56025 : H12AffineFastState.Bounded env56025 := by
  intro p hp
  have h : env56025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56010_56025 : H12AffineEnvironment.transform 16 24909 env56010 = env56025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env56010 == env56025) = true)

theorem identity56025 : scanCanonicalize (H12AffineFastState.compose env56025 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 34283) := by decide +kernel

theorem selectedBound56025 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env56026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,34283,24909,36161,1024,32769,4161,62709,42480,41430,8328,65,22836,45297,57569,35325,1501,42312,256,21793,46212,42977]

theorem envBound56026 : H12AffineFastState.Bounded env56026 := by
  intro p hp
  have h : env56026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56025_56026 : H12AffineEnvironment.transform 15 34283 env56025 = env56026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34283 env56025 == env56026) = true)

theorem identity56026 : scanCanonicalize (H12AffineFastState.compose env56026 (packedSelected [0,1,4,7,11,17,19,22,23,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56026 : packedSelected [0,1,4,7,11,17,19,22,23,28,31] rootPS < 2^1333 := by decide +kernel

def env56027 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,33950,24632,35892,1024,32769,4161,62709,42117,41123,8328,65,22593,45297,57569,34952,1192,42045,117,21588,46212,42644]

theorem envBound56027 : H12AffineFastState.Bounded env56027 := by
  intro p hp
  have h : env56027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56026_56027 : H12AffineEnvironment.transform 7 117 env56026 = env56027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56026 == env56027) = true)

theorem identity56027 : scanCanonicalize (H12AffineFastState.compose env56027 (packedSelected [0,4,5,14,16,17,18,22,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound56027 : packedSelected [0,4,5,14,16,17,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56028 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,217,1095,24632,3309,1024,216,4161,29740,9308,8314,8328,65,22593,12328,24632,2129,1192,9444,117,21588,13405,9805]

theorem envBound56028 : H12AffineFastState.Bounded env56028 := by
  intro p hp
  have h : env56028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56027_56028 : H12AffineEnvironment.transform 14 217 env56027 = env56028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env56027 == env56028) = true)

theorem identity56028 : scanCanonicalize (H12AffineFastState.compose env56028 (packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound56028 : packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env56029 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5293,217,1095,13461,3309,1024,216,4161,8321,9308,8314,8328,65,3308,12328,13461,2129,1192,9444,117,249,13405,9805]

theorem envBound56029 : H12AffineFastState.Bounded env56029 := by
  intro p hp
  have h : env56029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56028_56029 : H12AffineEnvironment.transform 13 5293 env56028 = env56029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env56028 == env56029) = true)

theorem identity56029 : scanCanonicalize (H12AffineFastState.compose env56029 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound56029 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env56030 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,4096,8192,4296,217,34,12528,2184,101,216,4161,8321,8249,8314,8328,65,2185,12328,12528,2129,205,8321,117,249,12344,8744]

theorem envBound56030 : H12AffineFastState.Bounded env56030 := by
  intro p hp
  have h : env56030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56029_56030 : H12AffineEnvironment.transform 9 101 env56029 = env56030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env56029 == env56030) = true)

theorem identity56030 : scanCanonicalize (H12AffineFastState.compose env56030 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound56030 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env56031 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,2113,8192,2185,217,34,10417,2184,101,216,2048,8321,8249,8314,8328,65,2185,10345,10417,2129,205,8321,117,249,10361,8744]

theorem envBound56031 : H12AffineFastState.Bounded env56031 := by
  intro p hp
  have h : env56031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56030_56031 : H12AffineEnvironment.transform 11 2113 env56030 = env56031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env56030 == env56031) = true)

theorem identity56031 : scanCanonicalize (H12AffineFastState.compose env56031 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound56031 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env56032 : List Nat := [2,4,8,16,32,64,89,117,512,101,2048,2113,8192,2128,0,34,10344,2129,101,1,2048,8280,8249,8314,8273,65,2128,10345,10344,2129,20,8280,117,32,10361,8744]

theorem envBound56032 : H12AffineFastState.Bounded env56032 := by
  intro p hp
  have h : env56032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56031_56032 : H12AffineEnvironment.transform 6 89 env56031 = env56032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env56031 == env56032) = true)

theorem identity56032 : scanCanonicalize (H12AffineFastState.compose env56032 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56032 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56033 : List Nat := [2,4,8,16,32,64,89,117,512,101,1,64,8192,81,0,34,8297,80,101,1,1,8280,8249,8314,8273,65,81,8296,8297,80,20,8280,117,32,8312,8744]

theorem envBound56033 : H12AffineFastState.Bounded env56033 := by
  intro p hp
  have h : env56033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56032_56033 : H12AffineEnvironment.transform 10 1 env56032 = env56033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56032 == env56033) = true)

theorem identity56033 : scanCanonicalize (H12AffineFastState.compose env56033 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound56033 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56034 : List Nat := [2,4,8,16,32,64,89,117,512,101,1,64,41,81,0,34,64,80,101,1,1,113,16,83,120,65,81,65,64,80,20,113,117,32,81,513]

theorem envBound56034 : H12AffineFastState.Bounded env56034 := by
  intro p hp
  have h : env56034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56033_56034 : H12AffineEnvironment.transform 12 41 env56033 = env56034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env56033 == env56034) = true)

theorem identity56034 : scanCanonicalize (H12AffineFastState.compose env56034 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound56034 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56035 : List Nat := [2,4,8,16,32,26,3,47,512,63,1,26,41,11,0,34,26,10,63,1,1,43,16,9,34,27,11,27,26,10,20,43,47,32,11,513]

theorem envBound56035 : H12AffineFastState.Bounded env56035 := by
  intro p hp
  have h : env56035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56034_56035 : H12AffineEnvironment.transform 5 26 env56034 = env56035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env56034 == env56035) = true)

theorem identity56035 : scanCanonicalize (H12AffineFastState.compose env56035 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound56035 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56036 : List Nat := [2,4,8,5,32,15,3,47,512,42,1,15,41,11,0,34,15,10,42,1,1,43,5,9,34,14,11,14,15,10,1,43,47,32,11,513]

theorem envBound56036 : H12AffineFastState.Bounded env56036 := by
  intro p hp
  have h : env56036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56035_56036 : H12AffineEnvironment.transform 3 5 env56035 = env56036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env56035 == env56036) = true)

theorem identity56036 : scanCanonicalize (H12AffineFastState.compose env56036 (packedSelected [0,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 41) := by decide +kernel

theorem selectedBound56036 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env56037 : List Nat := [2,4,8,5,32,15,3,47,41,42,1,15,41,11,0,34,15,10,42,1,1,43,5,9,34,14,11,14,15,10,1,43,47,32,11,40]

theorem envBound56037 : H12AffineFastState.Bounded env56037 := by
  intro p hp
  have h : env56037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56036_56037 : H12AffineEnvironment.transform 8 41 env56036 = env56037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 41 env56036 == env56037) = true)

theorem identity56037 : scanCanonicalize (H12AffineFastState.compose env56037 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56037 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56038 : List Nat := [2,0,8,1,32,11,3,43,41,42,1,11,41,11,0,34,11,10,42,1,1,43,1,9,34,10,11,10,11,10,1,43,43,32,11,40]

theorem envBound56038 : H12AffineFastState.Bounded env56038 := by
  intro p hp
  have h : env56038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56037_56038 : H12AffineEnvironment.transform 1 0 env56037 = env56038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56037 == env56038) = true)

theorem identity56038 : scanCanonicalize (H12AffineFastState.compose env56038 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56038 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env56039 : List Nat := [2,0,8,1,10,11,3,1,3,0,1,11,3,11,0,8,11,10,0,1,1,1,1,9,8,10,11,10,11,10,1,1,1,10,11,2]

theorem envBound56039 : H12AffineFastState.Bounded env56039 := by
  intro p hp
  have h : env56039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56038_56039 : H12AffineEnvironment.transform 4 10 env56038 = env56039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56038 == env56039) = true)

def env56040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513341,510001,8328,65,2409525,2510012,396525,2136508,2102684,2373705,256,21793,46212,2175563]

theorem envBound56040 : H12AffineFastState.Bounded env56040 := by
  intro p hp
  have h : env56040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55986_56040 : H12AffineEnvironment.transform 21 169401 env55986 = env56040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env55986 == env56040) = true)

def env56041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,510001,8328,65,316533,417020,396525,35324,1500,272393,256,21793,46212,74251]

theorem envBound56041 : H12AffineFastState.Bounded env56041 := by
  intro p hp
  have h : env56041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56040_56041 : H12AffineEnvironment.transform 20 4160 env56040 = env56041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56040 == env56041) = true)

theorem identity56041 : scanCanonicalize (H12AffineFastState.compose env56041 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound56041 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,4160,169401,120015,21763,8328,65,215367,115150,102879,35324,1500,243003,256,21793,46212,74251]

theorem envBound56042 : H12AffineFastState.Bounded env56042 := by
  intro p hp
  have h : env56042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56041_56042 : H12AffineEnvironment.transform 17 236850 env56041 = env56042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env56041 == env56042) = true)

def env56043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4160,62709,120015,21763,8328,65,75787,115150,102879,35324,1500,119927,256,21793,46212,74251]

theorem envBound56043 : H12AffineFastState.Bounded env56043 := by
  intro p hp
  have h : env56043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56042_56043 : H12AffineEnvironment.transform 16 24908 env56042 = env56043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env56042 == env56043) = true)

def env56044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4160,62589,119879,21763,8192,65,75787,115014,102743,35188,1364,119927,256,21793,46092,74251]

theorem envBound56044 : H12AffineFastState.Bounded env56044 := by
  intro p hp
  have h : env56044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56043_56044 : H12AffineEnvironment.transform 6 8 env56043 = env56044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56043 == env56044) = true)

theorem identity56044 : scanCanonicalize (H12AffineFastState.compose env56044 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound56044 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,24908,35189,1024,32769,4160,62589,41292,21763,8192,65,23808,46157,58460,35188,1364,41340,256,21793,46092,22272]

theorem envBound56045 : H12AffineFastState.Bounded env56045 := by
  intro p hp
  have h : env56045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56044_56045 : H12AffineEnvironment.transform 15 29963 env56044 = env56045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env56044 == env56045) = true)

theorem identity56045 : scanCanonicalize (H12AffineFastState.compose env56045 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound56045 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env56046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,29963,24908,23668,1024,21760,4160,8572,29773,21763,8192,65,23808,24908,12637,23669,1364,29821,256,21793,24845,22272]

theorem envBound56046 : H12AffineFastState.Bounded env56046 := by
  intro p hp
  have h : env56046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56045_56046 : H12AffineEnvironment.transform 14 21761 env56045 = env56046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env56045 == env56046) = true)

theorem identity56046 : scanCanonicalize (H12AffineFastState.compose env56046 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56046 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env56047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,343,5392,10280,1024,8540,4160,8572,17,8543,8192,65,10588,5392,12637,10281,1364,33,256,8573,5457,9052]

theorem envBound56047 : H12AffineFastState.Bounded env56047 := by
  intro p hp
  have h : env56047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56046_56047 : H12AffineEnvironment.transform 13 13404 env56046 = env56047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56046 == env56047) = true)

theorem identity56047 : scanCanonicalize (H12AffineFastState.compose env56047 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56047 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56048 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12620,8541,343,4096,10280,272,8540,4160,8572,17,8543,8192,65,10588,4096,12637,10281,68,33,256,8573,4161,9052]

theorem envBound56048 : H12AffineFastState.Bounded env56048 := by
  intro p hp
  have h : env56048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56047_56048 : H12AffineEnvironment.transform 9 272 env56047 = env56048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56047 == env56048) = true)

theorem identity56048 : scanCanonicalize (H12AffineFastState.compose env56048 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound56048 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env56049 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2065,8192,10589,8541,343,2065,10280,272,8540,2129,8572,17,8543,8192,65,10588,2065,10572,10281,68,33,256,8573,2128,9052]

theorem envBound56049 : H12AffineFastState.Bounded env56049 := by
  intro p hp
  have h : env56049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56048_56049 : H12AffineEnvironment.transform 11 2065 env56048 = env56049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env56048 == env56049) = true)

theorem identity56049 : scanCanonicalize (H12AffineFastState.compose env56049 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound56049 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env56050 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2065,41,2420,372,343,2065,2049,272,373,2129,341,17,374,41,65,2421,2065,2405,2048,68,33,256,340,2128,885]

theorem envBound56050 : H12AffineFastState.Bounded env56050 := by
  intro p hp
  have h : env56050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56049_56050 : H12AffineEnvironment.transform 12 41 env56049 = env56050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env56049 == env56050) = true)

theorem identity56050 : scanCanonicalize (H12AffineFastState.compose env56050 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56050 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56051 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2065,41,2340,292,263,2065,2049,272,293,2049,261,17,294,41,17,2341,2065,2357,2048,20,33,256,260,2048,805]

theorem envBound56051 : H12AffineFastState.Bounded env56051 := by
  intro p hp
  have h : env56051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56050_56051 : H12AffineEnvironment.transform 5 16 env56050 = env56051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56050 == env56051) = true)

theorem identity56051 : scanCanonicalize (H12AffineFastState.compose env56051 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56051 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56052 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,16,41,293,292,263,16,0,272,293,0,261,17,294,41,17,292,16,308,1,20,33,256,260,1,805]

theorem envBound56052 : H12AffineFastState.Bounded env56052 := by
  intro p hp
  have h : env56052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56051_56052 : H12AffineEnvironment.transform 10 1 env56051 = env56052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56051 == env56052) = true)

theorem identity56052 : scanCanonicalize (H12AffineFastState.compose env56052 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56052 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56053 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,16,41,1,0,35,16,0,52,1,0,33,17,2,41,17,0,16,16,1,20,33,36,32,1,513]

theorem envBound56053 : H12AffineFastState.Bounded env56053 := by
  intro p hp
  have h : env56053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56052_56053 : H12AffineEnvironment.transform 7 36 env56052 = env56053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56052 == env56053) = true)

theorem identity56053 : scanCanonicalize (H12AffineFastState.compose env56053 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56054 : List Nat := [2,4,8,0,32,0,8,36,512,36,1,0,41,1,0,35,0,0,36,1,0,33,1,2,41,1,0,0,0,1,4,33,36,32,1,513]

theorem envBound56054 : H12AffineFastState.Bounded env56054 := by
  intro p hp
  have h : env56054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56053_56054 : H12AffineEnvironment.transform 3 0 env56053 = env56054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56053 == env56054) = true)

theorem identity56054 : scanCanonicalize (H12AffineFastState.compose env56054 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound56054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56055 : List Nat := [2,4,8,0,32,0,8,36,10,36,1,0,41,1,0,35,0,0,36,1,0,33,1,2,41,1,0,0,0,1,4,33,36,32,1,11]

theorem envBound56055 : H12AffineFastState.Bounded env56055 := by
  intro p hp
  have h : env56055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56054_56055 : H12AffineEnvironment.transform 8 10 env56054 = env56055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env56054 == env56055) = true)

def env56056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4160,62588,119878,21763,8193,65,75787,115015,102742,35189,1365,119927,256,21793,46093,74251]

theorem envBound56056 : H12AffineFastState.Bounded env56056 := by
  intro p hp
  have h : env56056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56043_56056 : H12AffineEnvironment.transform 6 9 env56043 = env56056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56043 == env56056) = true)

theorem identity56056 : scanCanonicalize (H12AffineFastState.compose env56056 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound56056 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24908,10281,1024,32769,4160,62588,17,21763,8193,65,64604,5392,17665,35189,1365,32,256,21793,46093,63068]

theorem envBound56057 : H12AffineFastState.Bounded env56057 := by
  intro p hp
  have h : env56057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56056_56057 : H12AffineEnvironment.transform 15 54359 env56056 = env56057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env56056 == env56057) = true)

theorem identity56057 : scanCanonicalize (H12AffineFastState.compose env56057 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound56057 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,24908,10281,1024,21760,4160,8573,17,21763,8193,65,10589,5392,17665,23668,1365,32,256,21793,24844,9053]

theorem envBound56058 : H12AffineFastState.Bounded env56058 := by
  intro p hp
  have h : env56058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56057_56058 : H12AffineEnvironment.transform 14 21761 env56057 = env56058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env56057 == env56058) = true)

theorem identity56058 : scanCanonicalize (H12AffineFastState.compose env56058 (packedSelected [1,8,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56058 : packedSelected [1,8,18,19,23] rootPS < 2^1333 := by decide +kernel

def env56059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21761,342,16449,2340,1024,21760,4160,112,17,21763,268,65,2128,5392,17665,23668,1365,32,256,21793,16385,592]

theorem envBound56059 : H12AffineFastState.Bounded env56059 := by
  intro p hp
  have h : env56059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56058_56059 : H12AffineEnvironment.transform 12 269 env56058 = env56059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56058 == env56059) = true)

theorem identity56059 : scanCanonicalize (H12AffineFastState.compose env56059 (packedSelected [3,5,7,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1361) := by decide +kernel

theorem selectedBound56059 : packedSelected [3,5,7,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env56060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1361,4096,269,16384,21761,342,16449,1141,1024,21760,4160,112,17,21763,268,65,1281,5392,17665,20773,1365,32,256,21793,16385,592]

theorem envBound56060 : H12AffineFastState.Bounded env56060 := by
  intro p hp
  have h : env56060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56059_56060 : H12AffineEnvironment.transform 10 1361 env56059 = env56060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1361 env56059 == env56060) = true)

theorem identity56060 : scanCanonicalize (H12AffineFastState.compose env56060 (packedSelected [0,2,3,5,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound56060 : packedSelected [0,2,3,5,7,14,16] rootPS < 2^1333 := by decide +kernel

def env56061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1361,4096,269,33,5408,342,96,1141,1024,5409,4160,112,17,5410,268,65,1281,5392,1312,4356,1365,32,256,5376,32,592]

theorem envBound56061 : H12AffineFastState.Bounded env56061 := by
  intro p hp
  have h : env56061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56060_56061 : H12AffineEnvironment.transform 13 33 env56060 = env56061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env56060 == env56061) = true)

def env56062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4160,62708,120015,21763,8328,65,75786,115150,102879,35324,1500,119926,256,21793,46212,74251]

theorem envBound56062 : H12AffineFastState.Bounded env56062 := by
  intro p hp
  have h : env56062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56042_56062 : H12AffineEnvironment.transform 16 24909 env56042 = env56062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env56042 == env56062) = true)

def env56063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4160,62588,119879,21763,8192,65,75786,115014,102743,35188,1364,119926,256,21793,46092,74251]

theorem envBound56063 : H12AffineFastState.Bounded env56063 := by
  intro p hp
  have h : env56063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56062_56063 : H12AffineEnvironment.transform 6 8 env56062 = env56063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56062 == env56063) = true)

theorem identity56063 : scanCanonicalize (H12AffineFastState.compose env56063 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56063 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,89378,1024,8540,4160,21793,95514,21763,8192,65,75786,90139,77834,10281,1364,95531,256,21793,5457,74251]

theorem envBound56064 : H12AffineFastState.Bounded env56064 := by
  intro p hp
  have h : env56064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56063_56064 : H12AffineEnvironment.transform 14 8541 env56063 = env56064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56063 == env56064) = true)

theorem identity56064 : scanCanonicalize (H12AffineFastState.compose env56064 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound56064 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env56065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21795,24909,2049,1024,8540,4160,21793,8249,21763,8192,65,32041,13624,25897,10281,1364,8200,256,21793,5457,30504]

theorem envBound56065 : H12AffineFastState.Bounded env56065 := by
  intro p hp
  have h : env56065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56064_56065 : H12AffineEnvironment.transform 15 21795 env56064 = env56065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env56064 == env56065) = true)

theorem identity56065 : scanCanonicalize (H12AffineFastState.compose env56065 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound56065 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,8282,5172,2049,1024,8540,4160,8280,8249,8314,8192,65,2128,13624,4176,10281,1364,8200,256,8280,5457,593]

theorem envBound56066 : H12AffineFastState.Bounded env56066 := by
  intro p hp
  have h : env56066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56065_56066 : H12AffineEnvironment.transform 13 13689 env56065 = env56066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env56065 == env56066) = true)

theorem identity56066 : scanCanonicalize (H12AffineFastState.compose env56066 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound56066 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env56067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5457,373,114,5172,2049,1024,372,4160,112,17,82,40,65,2128,5392,4176,2049,1364,32,256,112,5457,593]

theorem envBound56067 : H12AffineFastState.Bounded env56067 := by
  intro p hp
  have h : env56067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56066_56067 : H12AffineEnvironment.transform 12 40 env56066 = env56067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env56066 == env56067) = true)

theorem identity56067 : scanCanonicalize (H12AffineFastState.compose env56067 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56067 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56068 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5157,1,114,5172,2049,1024,0,4160,112,17,82,40,65,2128,5220,4176,2049,1056,32,116,112,5157,593]

theorem envBound56068 : H12AffineFastState.Bounded env56068 := by
  intro p hp
  have h : env56068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56067_56068 : H12AffineEnvironment.transform 7 116 env56067 = env56068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56067 == env56068) = true)

theorem identity56068 : scanCanonicalize (H12AffineFastState.compose env56068 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56068 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env56069 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5172,2049,1024,0,4113,33,17,3,40,16,2049,5173,4097,2049,1056,32,37,33,5157,512]

theorem envBound56069 : H12AffineFastState.Bounded env56069 := by
  intro p hp
  have h : env56069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56068_56069 : H12AffineEnvironment.transform 5 17 env56068 = env56069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56068 == env56069) = true)

theorem identity56069 : scanCanonicalize (H12AffineFastState.compose env56069 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound56069 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56070 : List Nat := [2,4,8,16,32,17,8,37,512,5,2048,4096,40,4128,1,35,4145,2049,5,0,4113,33,17,3,40,16,2049,4144,4097,2049,37,32,37,33,4128,512]

theorem envBound56070 : H12AffineFastState.Bounded env56070 := by
  intro p hp
  have h : env56070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56069_56070 : H12AffineEnvironment.transform 9 5 env56069 = env56070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env56069 == env56070) = true)

theorem identity56070 : scanCanonicalize (H12AffineFastState.compose env56070 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound56070 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56071 : List Nat := [2,4,8,16,32,17,8,37,512,5,2048,560,40,528,1,35,513,2049,5,0,545,33,17,3,40,16,2049,512,561,2049,37,32,37,33,528,512]

theorem envBound56071 : H12AffineFastState.Bounded env56071 := by
  intro p hp
  have h : env56071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56070_56071 : H12AffineEnvironment.transform 11 560 env56070 = env56071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env56070 == env56071) = true)

theorem identity56071 : scanCanonicalize (H12AffineFastState.compose env56071 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound56071 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56072 : List Nat := [2,4,8,16,32,17,8,37,512,5,17,560,40,528,1,35,513,16,5,0,545,33,17,3,40,16,16,512,561,16,37,32,37,33,528,512]

theorem envBound56072 : H12AffineFastState.Bounded env56072 := by
  intro p hp
  have h : env56072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56071_56072 : H12AffineEnvironment.transform 10 17 env56071 = env56072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env56071 == env56072) = true)

theorem identity56072 : scanCanonicalize (H12AffineFastState.compose env56072 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56072 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56073 : List Nat := [2,4,8,16,0,17,8,5,512,5,17,528,8,528,1,3,513,16,5,0,513,1,17,3,8,16,16,512,529,16,5,0,5,1,528,512]

theorem envBound56073 : H12AffineFastState.Bounded env56073 := by
  intro p hp
  have h : env56073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56072_56073 : H12AffineEnvironment.transform 4 0 env56072 = env56073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56072 == env56073) = true)

theorem identity56073 : scanCanonicalize (H12AffineFastState.compose env56073 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56073 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56074 : List Nat := [2,4,8,16,0,17,8,5,0,5,17,16,8,16,1,3,1,16,5,0,1,1,17,3,8,16,16,0,17,16,5,0,5,1,16,0]

theorem envBound56074 : H12AffineFastState.Bounded env56074 := by
  intro p hp
  have h : env56074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56073_56074 : H12AffineEnvironment.transform 8 0 env56073 = env56074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56073 == env56074) = true)

theorem identity56074 : scanCanonicalize (H12AffineFastState.compose env56074 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56075 : List Nat := [2,4,8,0,0,1,8,5,0,5,1,0,8,0,1,3,1,0,5,0,1,1,1,3,8,0,0,0,1,0,5,0,5,1,0,0]

theorem envBound56075 : H12AffineFastState.Bounded env56075 := by
  intro p hp
  have h : env56075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56074_56075 : H12AffineEnvironment.transform 3 0 env56074 = env56075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56074 == env56075) = true)

theorem identity56075 : scanCanonicalize (H12AffineFastState.compose env56075 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56076 : List Nat := [2,0,8,0,0,1,8,1,0,1,1,0,8,0,1,3,1,0,1,0,1,1,1,3,8,0,0,0,1,0,1,0,1,1,0,0]

theorem envBound56076 : H12AffineFastState.Bounded env56076 := by
  intro p hp
  have h : env56076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56075_56076 : H12AffineEnvironment.transform 1 0 env56075 = env56076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56075 == env56076) = true)

def env56077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4160,62589,119878,21763,8193,65,75786,115015,102742,35189,1365,119926,256,21793,46093,74251]

theorem envBound56077 : H12AffineFastState.Bounded env56077 := by
  intro p hp
  have h : env56077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56062_56077 : H12AffineEnvironment.transform 6 9 env56062 = env56077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56062 == env56077) = true)

theorem identity56077 : scanCanonicalize (H12AffineFastState.compose env56077 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound56077 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env56078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,343,24909,64808,1024,32769,4160,62589,54545,21763,8193,65,10589,49168,36865,35189,1365,54561,256,21793,46093,9052]

theorem envBound56078 : H12AffineFastState.Bounded env56078 := by
  intro p hp
  have h : env56078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56077_56078 : H12AffineEnvironment.transform 15 343 env56077 = env56078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env56077 == env56078) = true)

theorem identity56078 : scanCanonicalize (H12AffineFastState.compose env56078 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound56078 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env56079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,343,24909,10281,1024,21760,4160,8572,16,21763,8193,65,10589,5393,17664,23668,1365,32,256,21793,24844,9052]

theorem envBound56079 : H12AffineFastState.Bounded env56079 := by
  intro p hp
  have h : env56079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56078_56079 : H12AffineEnvironment.transform 14 21761 env56078 = env56079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env56078 == env56079) = true)

theorem identity56079 : scanCanonicalize (H12AffineFastState.compose env56079 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56079 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,16400,2420,1024,21760,4160,33,16,21763,348,65,2048,5393,17664,23668,1365,32,256,21793,16465,513]

theorem envBound56080 : H12AffineFastState.Bounded env56080 := by
  intro p hp
  have h : env56080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56079_56080 : H12AffineEnvironment.transform 12 349 env56079 = env56080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56079 == env56080) = true)

theorem identity56080 : scanCanonicalize (H12AffineFastState.compose env56080 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56080 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56081 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,262,16400,2341,1024,21760,4113,33,16,21763,269,16,2048,5393,17664,23589,1284,32,256,21793,16384,513]

theorem envBound56081 : H12AffineFastState.Bounded env56081 := by
  intro p hp
  have h : env56081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56080_56081 : H12AffineEnvironment.transform 5 17 env56080 = env56081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56080 == env56081) = true)

theorem identity56081 : scanCanonicalize (H12AffineFastState.compose env56081 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound56081 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56082 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,16384,18724,262,16400,2341,1024,18725,3124,33,16,18726,269,16,2048,2356,17664,16384,1284,32,256,18692,16384,513]

theorem envBound56082 : H12AffineFastState.Bounded env56082 := by
  intro p hp
  have h : env56082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56081_56082 : H12AffineEnvironment.transform 11 3109 env56081 = env56082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env56081 == env56082) = true)

theorem identity56082 : scanCanonicalize (H12AffineFastState.compose env56082 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 3898) := by decide +kernel

theorem selectedBound56082 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env56083 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,3898,1566,262,3882,2341,1024,1567,3124,33,16,1564,269,16,2048,2356,2618,3898,1284,32,256,1598,3898,513]

theorem envBound56083 : H12AffineFastState.Bounded env56083 := by
  intro p hp
  have h : env56083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56082_56083 : H12AffineEnvironment.transform 13 3898 env56082 = env56083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3898 env56082 == env56083) = true)

theorem identity56083 : scanCanonicalize (H12AffineFastState.compose env56083 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound56083 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env56084 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1819,830,268,33,1566,262,49,1598,1024,1567,815,33,16,1564,269,16,1819,1583,1313,33,1284,32,256,1598,33,513]

theorem envBound56084 : H12AffineFastState.Bounded env56084 := by
  intro p hp
  have h : env56084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56083_56084 : H12AffineEnvironment.transform 10 1819 env56083 = env56084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env56083 == env56084) = true)

theorem identity56084 : scanCanonicalize (H12AffineFastState.compose env56084 (packedSelected [0,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 826) := by decide +kernel

theorem selectedBound56084 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env56085 : List Nat := [2,4,8,16,32,17,9,256,512,826,33,830,268,33,292,262,49,260,826,293,815,33,16,294,269,16,33,277,539,33,574,32,256,260,33,513]

theorem envBound56085 : H12AffineFastState.Bounded env56085 := by
  intro p hp
  have h : env56085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56084_56085 : H12AffineEnvironment.transform 9 826 env56084 = env56085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 826 env56084 == env56085) = true)

theorem identity56085 : scanCanonicalize (H12AffineFastState.compose env56085 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound56085 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56086 : List Nat := [2,4,8,16,18,17,9,256,512,776,19,780,268,19,278,262,3,260,776,279,797,19,16,276,269,16,19,277,539,19,524,18,256,260,19,513]

theorem envBound56086 : H12AffineFastState.Bounded env56086 := by
  intro p hp
  have h : env56086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56085_56086 : H12AffineEnvironment.transform 4 18 env56085 = env56086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env56085 == env56086) = true)

def env56087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,510001,8328,65,316532,417021,396525,35325,1501,272392,256,21793,46212,74250]

theorem envBound56087 : H12AffineFastState.Bounded env56087 := by
  intro p hp
  have h : env56087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56040_56087 : H12AffineEnvironment.transform 20 4161 env56040 = env56087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56040 == env56087) = true)

theorem identity56087 : scanCanonicalize (H12AffineFastState.compose env56087 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56087 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,169401,412156,452666,8328,65,316532,417021,396525,35325,1501,272392,256,21793,46212,513]

theorem envBound56088 : H12AffineFastState.Bounded env56088 := by
  intro p hp
  have h : env56088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56087_56088 : H12AffineEnvironment.transform 15 8203 env56087 = env56088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56087 == env56088) = true)

def env56089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4161,54697,264684,305194,8328,65,316532,269549,281853,35325,1501,272392,256,21793,46212,513]

theorem envBound56089 : H12AffineFastState.Bounded env56089 := by
  intro p hp
  have h : env56089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56088_56089 : H12AffineEnvironment.transform 16 16400 env56088 = env56089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env56088 == env56089) = true)

def env56090 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4113,54697,264636,305194,8328,17,316452,269501,281773,35245,1421,272392,256,21793,46212,513]

theorem envBound56090 : H12AffineFastState.Bounded env56090 := by
  intro p hp
  have h : env56090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56089_56090 : H12AffineEnvironment.transform 5 16 env56089 = env56090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56089 == env56090) = true)

theorem identity56090 : scanCanonicalize (H12AffineFastState.compose env56090 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound56090 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env56091 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,4113,54697,8476,32906,8328,17,64644,13341,25613,35245,1421,168,256,21793,46212,513]

theorem envBound56091 : H12AffineFastState.Bounded env56091 := by
  intro p hp
  have h : env56091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56090_56091 : H12AffineEnvironment.transform 17 10400 env56090 = env56091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env56090 == env56091) = true)

theorem identity56091 : scanCanonicalize (H12AffineFastState.compose env56091 (packedSelected [1,3,4,5,8,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound56091 : packedSelected [1,3,4,5,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env56092 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8203,16400,10400,1024,29829,4113,8493,8476,29710,8328,17,2048,13341,25613,32041,1421,168,256,21793,16384,513]

theorem envBound56092 : H12AffineFastState.Bounded env56092 := by
  intro p hp
  have h : env56092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56091_56092 : H12AffineEnvironment.transform 14 29828 env56091 = env56092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env56091 == env56092) = true)

theorem identity56092 : scanCanonicalize (H12AffineFastState.compose env56092 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound56092 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env56093 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,1,8203,13461,10400,1024,0,4113,8493,8476,139,8328,17,2048,13341,4232,2476,1421,168,256,8612,13445,513]

theorem envBound56093 : H12AffineFastState.Bounded env56093 := by
  intro p hp
  have h : env56093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56092_56093 : H12AffineEnvironment.transform 13 13445 env56092 = env56093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env56092 == env56093) = true)

theorem identity56093 : scanCanonicalize (H12AffineFastState.compose env56093 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56093 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env56094 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,8203,13341,10280,1024,0,4113,8493,8476,3,8192,17,2048,13341,4096,2340,1285,32,256,8492,13325,513]

theorem envBound56094 : H12AffineFastState.Bounded env56094 := by
  intro p hp
  have h : env56094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56093_56094 : H12AffineEnvironment.transform 6 8 env56093 = env56094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56093 == env56094) = true)

theorem identity56094 : scanCanonicalize (H12AffineFastState.compose env56094 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56094 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56095 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1024,0,4113,33,16,3,268,17,2048,5393,4096,2340,1285,32,256,32,5377,513]

theorem envBound56095 : H12AffineFastState.Bounded env56095 := by
  intro p hp
  have h : env56095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56094_56095 : H12AffineEnvironment.transform 12 268 env56094 = env56095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56094 == env56095) = true)

theorem identity56095 : scanCanonicalize (H12AffineFastState.compose env56095 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound56095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56096 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1028,268,261,1,263,277,2340,1024,0,1045,33,16,3,268,17,2048,277,1028,2340,1285,32,256,32,261,513]

theorem envBound56096 : H12AffineFastState.Bounded env56096 := by
  intro p hp
  have h : env56096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56095_56096 : H12AffineEnvironment.transform 11 1028 env56095 = env56096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env56095 == env56096) = true)

theorem identity56096 : scanCanonicalize (H12AffineFastState.compose env56096 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56096 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56097 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,1028,40,33,1,35,49,2048,1024,0,1045,33,16,3,40,17,2048,49,1028,2048,1057,32,36,32,33,513]

theorem envBound56097 : H12AffineFastState.Bounded env56097 := by
  intro p hp
  have h : env56097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56096_56097 : H12AffineEnvironment.transform 7 36 env56096 = env56097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56096 == env56097) = true)

theorem identity56097 : scanCanonicalize (H12AffineFastState.compose env56097 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound56097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56098 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1045,1028,40,33,1,35,49,1045,1024,0,1045,33,16,3,40,17,1045,49,1028,1045,1057,32,36,32,33,513]

theorem envBound56098 : H12AffineFastState.Bounded env56098 := by
  intro p hp
  have h : env56098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56097_56098 : H12AffineEnvironment.transform 10 1045 env56097 = env56098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env56097 == env56098) = true)

theorem identity56098 : scanCanonicalize (H12AffineFastState.compose env56098 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound56098 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56099 : List Nat := [2,4,8,16,32,16,8,36,512,565,544,561,40,33,1,35,49,544,565,0,544,33,16,3,40,17,544,49,561,544,532,32,36,32,33,513]

theorem envBound56099 : H12AffineFastState.Bounded env56099 := by
  intro p hp
  have h : env56099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56098_56099 : H12AffineEnvironment.transform 9 565 env56098 = env56099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env56098 == env56099) = true)

theorem identity56099 : scanCanonicalize (H12AffineFastState.compose env56099 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56099 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56100 : List Nat := [2,4,8,1,32,1,8,36,512,548,544,544,40,33,1,35,32,544,548,0,544,33,1,3,40,0,544,32,544,544,517,32,36,32,33,513]

theorem envBound56100 : H12AffineFastState.Bounded env56100 := by
  intro p hp
  have h : env56100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56099_56100 : H12AffineEnvironment.transform 3 1 env56099 = env56100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56099 == env56100) = true)

theorem identity56100 : scanCanonicalize (H12AffineFastState.compose env56100 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56100 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56101 : List Nat := [2,4,8,1,32,1,8,36,0,36,32,32,40,33,1,35,32,32,36,0,32,33,1,3,40,0,32,32,32,32,5,32,36,32,33,1]

theorem envBound56101 : H12AffineFastState.Bounded env56101 := by
  intro p hp
  have h : env56101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56100_56101 : H12AffineEnvironment.transform 8 0 env56100 = env56101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56100 == env56101) = true)

theorem identity56101 : scanCanonicalize (H12AffineFastState.compose env56101 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56101 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56102 : List Nat := [2,4,8,1,1,1,8,5,0,5,1,1,9,0,1,2,1,1,5,0,1,0,1,3,9,0,1,1,1,1,5,1,5,1,0,1]

theorem envBound56102 : H12AffineFastState.Bounded env56102 := by
  intro p hp
  have h : env56102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56101_56102 : H12AffineEnvironment.transform 4 1 env56101 = env56102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56101 == env56102) = true)

def env56103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4112,54697,264637,305194,8328,16,316453,269500,281772,35244,1420,272392,256,21793,46212,513]

theorem envBound56103 : H12AffineFastState.Bounded env56103 := by
  intro p hp
  have h : env56103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56089_56103 : H12AffineEnvironment.transform 5 17 env56089 = env56103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56089 == env56103) = true)

theorem identity56103 : scanCanonicalize (H12AffineFastState.compose env56103 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound56103 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env56104 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8203,16400,262144,1024,8580,4112,29740,264637,264623,8328,16,292256,269500,281772,10281,1420,272392,256,21793,5377,513]

theorem envBound56104 : H12AffineFastState.Bounded env56104 := by
  intro p hp
  have h : env56104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56103_56104 : H12AffineEnvironment.transform 14 8581 env56103 = env56104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env56103 == env56104) = true)

theorem identity56104 : scanCanonicalize (H12AffineFastState.compose env56104 (packedSelected [1,5,7,8,14,17,18,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound56104 : packedSelected [1,5,7,8,14,17,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env56105 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,8581,8203,5528,262144,1024,8580,4112,8612,264637,264623,8328,16,270376,269500,268580,10281,1420,272392,256,169,5377,513]

theorem envBound56105 : H12AffineFastState.Bounded env56105 := by
  intro p hp
  have h : env56105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56104_56105 : H12AffineEnvironment.transform 13 5512 env56104 = env56105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env56104 == env56105) = true)

theorem identity56105 : scanCanonicalize (H12AffineFastState.compose env56105 (packedSelected [0,1,3,5,7,8,11,12,14,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound56105 : packedSelected [0,1,3,5,7,8,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56106 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,8192,4404,8581,8203,4388,262144,188,8580,4112,8612,264637,264623,8328,16,270376,268288,268580,10281,304,272392,256,169,4541,513]

theorem envBound56106 : H12AffineFastState.Bounded env56106 := by
  intro p hp
  have h : env56106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56105_56106 : H12AffineEnvironment.transform 9 188 env56105 = env56106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env56105 == env56106) = true)

theorem identity56106 : scanCanonicalize (H12AffineFastState.compose env56106 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound56106 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env56107 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,4404,1,399,4388,262144,188,0,4112,32,264637,264623,268,16,262572,268288,268580,2477,304,264588,256,169,4541,513]

theorem envBound56107 : H12AffineFastState.Bounded env56107 := by
  intro p hp
  have h : env56107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56106_56107 : H12AffineEnvironment.transform 12 388 env56106 = env56107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env56106 == env56107) = true)

theorem identity56107 : scanCanonicalize (H12AffineFastState.compose env56107 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound56107 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env56108 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,4404,1,399,4388,2476,188,0,4112,32,17,3,268,16,2048,4524,4232,2477,304,32,256,169,4541,513]

theorem envBound56108 : H12AffineFastState.Bounded env56108 := by
  intro p hp
  have h : env56108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56107_56108 : H12AffineEnvironment.transform 17 2476 env56107 = env56108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env56107 == env56108) = true)

theorem identity56108 : scanCanonicalize (H12AffineFastState.compose env56108 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 957) := by decide +kernel

theorem selectedBound56108 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56109 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,957,388,649,1,399,665,2476,188,0,941,32,17,3,268,16,2048,529,821,2477,304,32,256,169,512,513]

theorem envBound56109 : H12AffineFastState.Bounded env56109 := by
  intro p hp
  have h : env56109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56108_56109 : H12AffineEnvironment.transform 11 957 env56108 = env56109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 957 env56108 == env56109) = true)

theorem identity56109 : scanCanonicalize (H12AffineFastState.compose env56109 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound56109 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56110 : List Nat := [2,4,8,16,32,17,128,256,512,188,513,957,388,649,1,399,665,941,188,0,941,32,17,3,268,16,513,529,821,940,304,32,256,169,512,513]

theorem envBound56110 : H12AffineFastState.Bounded env56110 := by
  intro p hp
  have h : env56110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56109_56110 : H12AffineEnvironment.transform 10 513 env56109 = env56110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env56109 == env56110) = true)

theorem identity56110 : scanCanonicalize (H12AffineFastState.compose env56110 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56110 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56111 : List Nat := [2,4,8,16,32,17,9,256,512,53,513,820,269,512,1,262,528,804,53,0,804,32,17,3,268,16,513,529,821,805,304,32,256,32,512,513]

theorem envBound56111 : H12AffineFastState.Bounded env56111 := by
  intro p hp
  have h : env56111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56110_56111 : H12AffineEnvironment.transform 6 9 env56110 = env56111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56110 == env56111) = true)

theorem identity56111 : scanCanonicalize (H12AffineFastState.compose env56111 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56111 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56112 : List Nat := [2,4,8,16,16,17,9,256,512,5,513,772,269,512,1,262,528,788,5,0,788,16,17,3,268,16,513,529,773,789,256,16,256,16,512,513]

theorem envBound56112 : H12AffineFastState.Bounded env56112 := by
  intro p hp
  have h : env56112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56111_56112 : H12AffineEnvironment.transform 4 16 env56111 = env56112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56111 == env56112) = true)

theorem identity56112 : scanCanonicalize (H12AffineFastState.compose env56112 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56112 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56113 : List Nat := [2,4,8,0,0,1,9,256,512,5,513,772,269,512,1,262,512,772,5,0,772,0,1,3,268,0,513,513,773,773,256,0,256,0,512,513]

theorem envBound56113 : H12AffineFastState.Bounded env56113 := by
  intro p hp
  have h : env56113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56112_56113 : H12AffineEnvironment.transform 3 0 env56112 = env56113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56112 == env56113) = true)

def env56114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4161,54696,264685,305195,8328,65,316532,269548,281852,35325,1501,272392,256,21793,46212,513]

theorem envBound56114 : H12AffineFastState.Bounded env56114 := by
  intro p hp
  have h : env56114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56088_56114 : H12AffineEnvironment.transform 16 16401 env56088 = env56114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56088 == env56114) = true)

theorem identity56114 : scanCanonicalize (H12AffineFastState.compose env56114 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound56114 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,2557,1024,32769,4161,54696,16,41430,8328,65,56713,5393,17665,35325,1501,8693,256,21793,46212,513]

theorem envBound56115 : H12AffineFastState.Bounded env56115 := by
  intro p hp
  have h : env56115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56114_56115 : H12AffineEnvironment.transform 17 2557 env56114 = env56115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env56114 == env56115) = true)

theorem identity56115 : scanCanonicalize (H12AffineFastState.compose env56115 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound56115 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16401,2557,1024,21760,4161,169,16,29911,8328,65,2184,5393,17665,23804,1501,8693,256,21793,24965,513]

theorem envBound56116 : H12AffineFastState.Bounded env56116 := by
  intro p hp
  have h : env56116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56115_56116 : H12AffineEnvironment.transform 14 21761 env56115 = env56116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env56115 == env56116) = true)

theorem identity56116 : scanCanonicalize (H12AffineFastState.compose env56116 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56116 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env56117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,16401,2420,1024,21760,4161,32,16,29790,8193,65,2049,5393,17665,23669,1364,8572,256,21793,24844,513]

theorem envBound56117 : H12AffineFastState.Bounded env56117 := by
  intro p hp
  have h : env56117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56116_56117 : H12AffineEnvironment.transform 6 9 env56116 = env56117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56116 == env56117) = true)

theorem identity56117 : scanCanonicalize (H12AffineFastState.compose env56117 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound56117 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,13388,2420,1024,8541,4161,32,16,3,8193,65,2049,5393,12636,10280,1364,8572,256,8572,5457,513]

theorem envBound56118 : H12AffineFastState.Bounded env56118 := by
  intro p hp
  have h : env56118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56117_56118 : H12AffineEnvironment.transform 13 13405 env56117 = env56118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env56117 == env56118) = true)

theorem identity56118 : scanCanonicalize (H12AffineFastState.compose env56118 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound56118 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env56119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,81,8192,9228,8540,8203,9245,2420,1024,8541,16,32,16,3,8193,65,2049,1344,8461,10280,1364,8572,256,8572,1280,513]

theorem envBound56119 : H12AffineFastState.Bounded env56119 := by
  intro p hp
  have h : env56119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56118_56119 : H12AffineEnvironment.transform 11 81 env56118 = env56119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env56118 == env56119) = true)

theorem identity56119 : scanCanonicalize (H12AffineFastState.compose env56119 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56119 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,81,348,1360,0,343,1345,2420,1024,1,16,32,16,3,349,65,2049,1344,81,2420,1364,32,256,32,1280,513]

theorem envBound56120 : H12AffineFastState.Bounded env56120 := by
  intro p hp
  have h : env56120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56119_56120 : H12AffineEnvironment.transform 12 348 env56119 = env56120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56119 == env56120) = true)

theorem identity56120 : scanCanonicalize (H12AffineFastState.compose env56120 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1151) := by decide +kernel

theorem selectedBound56120 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1151,81,348,1360,0,343,1345,1291,1024,1,16,32,16,3,349,65,1150,1344,81,1291,1364,32,256,32,1280,513]

theorem envBound56121 : H12AffineFastState.Bounded env56121 := by
  intro p hp
  have h : env56121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56120_56121 : H12AffineEnvironment.transform 10 1151 env56120 = env56121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1151 env56120 == env56121) = true)

theorem identity56121 : scanCanonicalize (H12AffineFastState.compose env56121 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound56121 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56122 : List Nat := [2,4,8,16,32,64,9,256,512,47,80,81,348,383,0,343,366,292,47,1,16,32,16,3,349,65,81,367,81,292,379,32,256,32,303,513]

theorem envBound56122 : H12AffineFastState.Bounded env56122 := by
  intro p hp
  have h : env56122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56121_56122 : H12AffineEnvironment.transform 9 47 env56121 = env56122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env56121 == env56122) = true)

theorem identity56122 : scanCanonicalize (H12AffineFastState.compose env56122 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56122 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56123 : List Nat := [2,4,8,16,32,64,9,68,512,47,80,81,24,59,0,19,42,96,47,1,16,32,16,3,25,65,81,43,81,96,63,32,68,32,107,513]

theorem envBound56123 : H12AffineFastState.Bounded env56123 := by
  intro p hp
  have h : env56123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56122_56123 : H12AffineEnvironment.transform 7 68 env56122 = env56123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56122 == env56123) = true)

theorem identity56123 : scanCanonicalize (H12AffineFastState.compose env56123 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56123 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56124 : List Nat := [2,4,8,16,1,64,9,68,512,14,80,81,24,26,0,19,11,65,14,1,16,1,16,3,25,65,81,10,81,65,30,1,68,1,74,513]

theorem envBound56124 : H12AffineFastState.Bounded env56124 := by
  intro p hp
  have h : env56124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56123_56124 : H12AffineEnvironment.transform 4 1 env56123 = env56124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56123 == env56124) = true)

theorem identity56124 : scanCanonicalize (H12AffineFastState.compose env56124 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound56124 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env56125 : List Nat := [2,4,8,16,1,64,9,68,81,14,80,81,24,26,0,19,11,65,14,1,16,1,16,3,25,65,81,10,81,65,30,1,68,1,74,80]

theorem envBound56125 : H12AffineFastState.Bounded env56125 := by
  intro p hp
  have h : env56125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56124_56125 : H12AffineEnvironment.transform 8 81 env56124 = env56125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env56124 == env56125) = true)

theorem identity56125 : scanCanonicalize (H12AffineFastState.compose env56125 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 19) := by decide +kernel

theorem selectedBound56125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56126 : List Nat := [2,4,8,16,1,19,9,23,2,14,3,2,24,26,0,19,11,18,14,1,16,1,16,3,25,18,2,10,2,18,30,1,23,1,25,3]

theorem envBound56126 : H12AffineFastState.Bounded env56126 := by
  intro p hp
  have h : env56126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56125_56126 : H12AffineEnvironment.transform 5 19 env56125 = env56126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 19 env56125 == env56126) = true)

theorem identity56126 : scanCanonicalize (H12AffineFastState.compose env56126 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound56126 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env56127 : List Nat := [2,4,8,14,1,13,9,9,2,14,3,2,6,4,0,13,11,12,14,1,14,1,14,3,7,12,2,10,2,12,0,1,9,1,7,3]

theorem envBound56127 : H12AffineFastState.Bounded env56127 := by
  intro p hp
  have h : env56127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56126_56127 : H12AffineEnvironment.transform 3 14 env56126 = env56127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env56126 == env56127) = true)

theorem identity56127 : scanCanonicalize (H12AffineFastState.compose env56127 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56127 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env56128 : List Nat := [2,4,0,6,1,5,1,1,2,6,3,2,6,4,0,5,3,4,6,1,6,1,6,3,7,4,2,2,2,4,0,1,1,1,7,3]

theorem envBound56128 : H12AffineFastState.Bounded env56128 := by
  intro p hp
  have h : env56128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56127_56128 : H12AffineEnvironment.transform 2 0 env56127 = env56128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56127 == env56128) = true)

def env56129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound56129 : H12AffineFastState.Bounded env56129 := by
  intro p hp
  have h : env56129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55860_56129 : H12AffineEnvironment.transform 18 1025 env55860 = env56129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env55860 == env56129) = true)

theorem identity56129 : scanCanonicalize (H12AffineFastState.compose env56129 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272560) := by decide +kernel

theorem selectedBound56129 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272560,16777216,8328,65,21227697,18973836,2391520,190640,17149088,23160257,257,19262492,19205560,17075062]

theorem envBound56130 : H12AffineFastState.Bounded env56130 := by
  intro p hp
  have h : env56130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56129_56130 : H12AffineEnvironment.transform 22 272560 env56129 = env56130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272560 env56129 == env56130) = true)

def env56131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227577,18973700,2391400,190520,17148968,23160137,257,19262492,19205424,17075062]

theorem envBound56131 : H12AffineFastState.Bounded env56131 := by
  intro p hp
  have h : env56131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56130_56131 : H12AffineEnvironment.transform 6 8 env56130 = env56131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56130 == env56131) = true)

theorem identity56131 : scanCanonicalize (H12AffineFastState.compose env56131 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound56131 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env56132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,16777216,8192,65,21227577,18973700,2118977,190520,16876545,23160137,257,18990133,18949401,16819039]

theorem envBound56132 : H12AffineFastState.Bounded env56132 := by
  intro p hp
  have h : env56132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56131_56132 : H12AffineEnvironment.transform 17 10281 env56131 = env56132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56131 == env56132) = true)

theorem identity56132 : scanCanonicalize (H12AffineFastState.compose env56132 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound56132 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env56133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,41310,8192,65,4409703,2172250,2118977,190520,75103,6407191,257,2188651,2196551,513]

theorem envBound56133 : H12AffineFastState.Bounded env56133 := by
  intro p hp
  have h : env56133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56132_56133 : H12AffineEnvironment.transform 23 41310 env56132 = env56133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env56132 == env56133) = true)

def env56134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41310,8192,65,4409703,115014,45405,190520,75103,4268043,257,98679,90203,513]

theorem envBound56134 : H12AffineFastState.Bounded env56134 := by
  intro p hp
  have h : env56134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56133_56134 : H12AffineEnvironment.transform 20 58396 env56133 = env56134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env56133 == env56134) = true)

theorem identity56134 : scanCanonicalize (H12AffineFastState.compose env56134 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56134 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58396,4194304,17,41310,8192,65,4352364,57677,45405,190520,1364,4194304,257,41340,16464,513]

theorem envBound56135 : H12AffineFastState.Bounded env56135 := by
  intro p hp
  have h : env56135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56134_56135 : H12AffineEnvironment.transform 15 8203 env56134 = env56135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56134 == env56135) = true)

theorem identity56135 : scanCanonicalize (H12AffineFastState.compose env56135 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 147553) := by decide +kernel

theorem selectedBound56135 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env56136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58396,147553,17,41310,8192,65,10509,57677,45405,190520,1364,147553,257,41340,16464,513]

theorem envBound56136 : H12AffineFastState.Bounded env56136 := by
  intro p hp
  have h : env56136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56135_56136 : H12AffineEnvironment.transform 21 147553 env56135 = env56136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147553 env56135 == env56136) = true)

theorem identity56136 : scanCanonicalize (H12AffineFastState.compose env56136 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound56136 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env56137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24861,10281,1025,32769,58396,8572,17,41310,8192,65,10509,57677,45405,35109,1364,8572,257,41340,16464,513]

theorem envBound56137 : H12AffineFastState.Bounded env56137 := by
  intro p hp
  have h : env56137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56136_56137 : H12AffineEnvironment.transform 16 24861 env56136 = env56137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env56136 == env56137) = true)

theorem identity56137 : scanCanonicalize (H12AffineFastState.compose env56137 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56137 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,16448,2420,1025,32769,50497,33,17,32771,349,65,2128,49168,36864,35109,1364,33,257,32801,16464,513]

theorem envBound56138 : H12AffineFastState.Bounded env56138 := by
  intro p hp
  have h : env56138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56137_56138 : H12AffineEnvironment.transform 12 349 env56137 = env56138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56137 == env56138) = true)

theorem identity56138 : scanCanonicalize (H12AffineFastState.compose env56138 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56138 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56139 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,262,16400,2340,1025,32769,50449,33,17,32771,269,17,2048,49168,36864,35109,1284,33,257,32801,16384,513]

theorem envBound56139 : H12AffineFastState.Bounded env56139 := by
  intro p hp
  have h : env56139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56138_56139 : H12AffineEnvironment.transform 5 16 env56138 = env56139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56138 == env56139) = true)

theorem identity56139 : scanCanonicalize (H12AffineFastState.compose env56139 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound56139 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,32768,262,5173,2340,1025,32769,37172,33,17,32771,269,17,2048,37941,36864,35109,1284,33,257,32801,5157,513]

theorem envBound56140 : H12AffineFastState.Bounded env56140 := by
  intro p hp
  have h : env56140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56139_56140 : H12AffineEnvironment.transform 13 5157 env56139 = env56140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env56139 == env56140) = true)

theorem identity56140 : scanCanonicalize (H12AffineFastState.compose env56140 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound56140 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,1,262,5173,2340,1025,0,4405,33,17,2,269,17,2048,5172,4097,2340,1284,33,257,32,5157,513]

theorem envBound56141 : H12AffineFastState.Bounded env56141 := by
  intro p hp
  have h : env56141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56140_56141 : H12AffineEnvironment.transform 14 1 env56140 = env56141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env56140 == env56141) = true)

def env56142 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,269,2837,1,262,2821,2340,1025,0,3589,33,17,2,269,17,2048,2820,3889,2340,1284,33,257,32,2837,513]

theorem envBound56142 : H12AffineFastState.Bounded env56142 := by
  intro p hp
  have h : env56142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56141_56142 : H12AffineEnvironment.transform 11 3888 env56141 = env56142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env56141 == env56142) = true)

def env56143 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,269,1045,1,262,1029,1572,1025,0,261,33,17,2,269,17,1792,1028,49,1572,1284,33,257,32,1045,513]

theorem envBound56143 : H12AffineFastState.Bounded env56143 := by
  intro p hp
  have h : env56143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56142_56143 : H12AffineEnvironment.transform 10 1792 env56142 = env56143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env56142 == env56143) = true)

theorem identity56143 : scanCanonicalize (H12AffineFastState.compose env56143 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound56143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56144 : List Nat := [2,4,8,16,32,16,8,256,512,800,32,48,269,821,1,262,805,260,801,0,261,33,17,2,269,17,32,804,49,260,548,33,257,32,821,513]

theorem envBound56144 : H12AffineFastState.Bounded env56144 := by
  intro p hp
  have h : env56144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56143_56144 : H12AffineEnvironment.transform 9 800 env56143 = env56144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env56143 == env56144) = true)

def env56145 : List Nat := [2,4,8,16,32,16,8,256,276,52,32,48,269,33,1,262,49,260,53,0,261,33,17,2,269,17,32,48,49,260,304,33,257,32,33,277]

theorem envBound56145 : H12AffineFastState.Bounded env56145 := by
  intro p hp
  have h : env56145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56144_56145 : H12AffineEnvironment.transform 8 276 env56144 = env56145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env56144 == env56145) = true)

theorem identity56145 : scanCanonicalize (H12AffineFastState.compose env56145 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56146 : List Nat := [2,4,8,10,32,10,8,256,270,46,32,42,269,33,1,262,43,260,47,0,261,33,11,2,269,11,32,42,43,260,298,33,257,32,33,271]

theorem envBound56146 : H12AffineFastState.Bounded env56146 := by
  intro p hp
  have h : env56146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56145_56146 : H12AffineEnvironment.transform 3 10 env56145 = env56146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56145 == env56146) = true)

def leafEnv56146 : List Nat := [2,4,8,10,32,10,8,256,270,46,32,42,269,33,1,262,43,260,47,0,261,33,11,2,299,269,1,11,32,42,43,260,298,33,257,32,5,262,33,271,1,261,0]

def active56146 : List Nat := [0,1,2,4,7]

def tree56146 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56146 : H12WitnessSearch.Good tree56146 := H12GlobalWitnessIndex.good

theorem leafIdentity56146 : H12AffineFastState.composeSystem env56146 rootObs = leafEnv56146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56146 rootObs == leafEnv56146) = true)

theorem terminalChecked56146 : H12PackedTerminal.terminalCheckFast leafEnv56146 active56146 tree56146 = true := by decide +kernel

def env56147 : List Nat := [2,4,8,16,32,16,8,256,277,53,32,48,269,32,1,262,48,260,52,0,261,33,17,2,269,17,32,49,49,260,305,33,257,32,32,276]

theorem envBound56147 : H12AffineFastState.Bounded env56147 := by
  intro p hp
  have h : env56147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56144_56147 : H12AffineEnvironment.transform 8 277 env56144 = env56147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env56144 == env56147) = true)

def env56148 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,269,1044,1,262,1028,1573,1025,0,260,33,17,2,269,17,1793,1029,48,1573,1284,33,257,32,1044,513]

theorem envBound56148 : H12AffineFastState.Bounded env56148 := by
  intro p hp
  have h : env56148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56142_56148 : H12AffineEnvironment.transform 10 1793 env56142 = env56148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env56142 == env56148) = true)

theorem identity56148 : scanCanonicalize (H12AffineFastState.compose env56148 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound56148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56149 : List Nat := [2,4,8,16,32,16,8,256,48,1024,1329,49,269,1044,1,262,1028,1045,1025,0,260,33,17,2,269,17,1329,1029,48,1045,1284,33,257,32,1044,49]

theorem envBound56149 : H12AffineFastState.Bounded env56149 := by
  intro p hp
  have h : env56149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56148_56149 : H12AffineEnvironment.transform 8 48 env56148 = env56149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56148 == env56149) = true)

def env56150 : List Nat := [2,4,8,16,32,16,8,256,48,52,261,49,269,32,1,262,48,33,53,0,260,33,17,2,269,17,261,49,48,33,304,33,257,32,32,49]

theorem envBound56150 : H12AffineFastState.Bounded env56150 := by
  intro p hp
  have h : env56150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56149_56150 : H12AffineEnvironment.transform 9 52 env56149 = env56150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56149 == env56150) = true)

theorem identity56150 : scanCanonicalize (H12AffineFastState.compose env56150 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound56150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56151 : List Nat := [2,4,8,16,32,16,8,63,48,52,58,49,50,32,1,57,48,33,53,0,59,33,17,2,50,17,58,49,48,33,15,33,62,32,32,49]

theorem envBound56151 : H12AffineFastState.Bounded env56151 := by
  intro p hp
  have h : env56151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56150_56151 : H12AffineEnvironment.transform 7 63 env56150 = env56151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env56150 == env56151) = true)

def leafEnv56151 : List Nat := [2,4,8,16,32,16,8,63,48,52,58,49,50,32,1,57,48,33,53,0,59,33,17,2,14,50,1,17,58,49,48,33,15,33,62,32,5,57,32,49,1,59,0]

def active56151 : List Nat := [0,1,2,3,4]

def tree56151 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56151 : H12WitnessSearch.Good tree56151 := H12GlobalWitnessIndex.good

theorem leafIdentity56151 : H12AffineFastState.composeSystem env56151 rootObs = leafEnv56151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56151 rootObs == leafEnv56151) = true)

theorem terminalChecked56151 : H12PackedTerminal.terminalCheckFast leafEnv56151 active56151 tree56151 = true := by decide +kernel

def env56152 : List Nat := [2,4,8,16,32,16,8,256,48,53,260,49,269,33,1,262,49,32,52,0,260,33,17,2,269,17,260,48,48,32,305,33,257,32,33,49]

theorem envBound56152 : H12AffineFastState.Bounded env56152 := by
  intro p hp
  have h : env56152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56149_56152 : H12AffineEnvironment.transform 9 53 env56149 = env56152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56149 == env56152) = true)

def env56153 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,269,2836,1,262,2820,2340,1025,0,3588,33,17,2,269,17,2048,2821,3888,2340,1284,33,257,32,2836,513]

theorem envBound56153 : H12AffineFastState.Bounded env56153 := by
  intro p hp
  have h : env56153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56141_56153 : H12AffineEnvironment.transform 11 3889 env56141 = env56153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env56141 == env56153) = true)

def env56154 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,269,1044,1,262,1028,1572,1025,0,260,33,17,2,269,17,1792,1029,48,1572,1284,33,257,32,1044,513]

theorem envBound56154 : H12AffineFastState.Bounded env56154 := by
  intro p hp
  have h : env56154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56153_56154 : H12AffineEnvironment.transform 10 1792 env56153 = env56154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env56153 == env56154) = true)

theorem identity56154 : scanCanonicalize (H12AffineFastState.compose env56154 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound56154 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56155 : List Nat := [2,4,8,16,32,16,8,256,277,1024,1045,49,269,1044,1,262,1028,1329,1025,0,260,33,17,2,269,17,1045,1029,48,1329,1284,33,257,32,1044,276]

theorem envBound56155 : H12AffineFastState.Bounded env56155 := by
  intro p hp
  have h : env56155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56154_56155 : H12AffineEnvironment.transform 8 277 env56154 = env56155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env56154 == env56155) = true)

def env56156 : List Nat := [2,4,8,16,32,16,8,256,277,52,33,49,269,32,1,262,48,261,53,0,260,33,17,2,269,17,33,49,48,261,304,33,257,32,32,276]

theorem envBound56156 : H12AffineFastState.Bounded env56156 := by
  intro p hp
  have h : env56156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56155_56156 : H12AffineEnvironment.transform 9 52 env56155 = env56156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56155 == env56156) = true)

theorem identity56156 : scanCanonicalize (H12AffineFastState.compose env56156 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56157 : List Nat := [2,4,8,10,32,10,8,256,271,46,33,43,269,32,1,262,42,261,47,0,260,33,11,2,269,11,33,43,42,261,298,33,257,32,32,270]

theorem envBound56157 : H12AffineFastState.Bounded env56157 := by
  intro p hp
  have h : env56157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56156_56157 : H12AffineEnvironment.transform 3 10 env56156 = env56157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56156 == env56157) = true)

def leafEnv56157 : List Nat := [2,4,8,10,32,10,8,256,271,46,33,43,269,32,1,262,42,261,47,0,260,33,11,2,299,269,1,11,33,43,42,261,298,33,257,32,5,262,32,270,1,260,0]

def active56157 : List Nat := [0,1,2,4,7]

def tree56157 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56157 : H12WitnessSearch.Good tree56157 := H12GlobalWitnessIndex.good

theorem leafIdentity56157 : H12AffineFastState.composeSystem env56157 rootObs = leafEnv56157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56157 rootObs == leafEnv56157) = true)

theorem terminalChecked56157 : H12PackedTerminal.terminalCheckFast leafEnv56157 active56157 tree56157 = true := by decide +kernel

def env56158 : List Nat := [2,4,8,16,32,16,8,256,277,53,32,49,269,33,1,262,49,260,52,0,260,33,17,2,269,17,32,48,48,260,305,33,257,32,33,276]

theorem envBound56158 : H12AffineFastState.Bounded env56158 := by
  intro p hp
  have h : env56158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56155_56158 : H12AffineEnvironment.transform 9 53 env56155 = env56158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56155 == env56158) = true)

def env56159 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,269,1045,1,262,1029,1573,1025,0,261,33,17,2,269,17,1793,1028,49,1573,1284,33,257,32,1045,513]

theorem envBound56159 : H12AffineFastState.Bounded env56159 := by
  intro p hp
  have h : env56159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56153_56159 : H12AffineEnvironment.transform 10 1793 env56153 = env56159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env56153 == env56159) = true)

theorem identity56159 : scanCanonicalize (H12AffineFastState.compose env56159 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound56159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56160 : List Nat := [2,4,8,16,32,16,8,256,512,517,260,48,269,528,1,262,512,32,516,0,261,33,17,2,269,17,260,513,49,32,769,33,257,32,528,513]

theorem envBound56160 : H12AffineFastState.Bounded env56160 := by
  intro p hp
  have h : env56160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56159_56160 : H12AffineEnvironment.transform 9 517 env56159 = env56160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env56159 == env56160) = true)

def env56161 : List Nat := [2,4,8,16,32,16,8,256,48,53,260,48,269,32,1,262,48,32,52,0,261,33,17,2,269,17,260,49,49,32,305,33,257,32,32,49]

theorem envBound56161 : H12AffineFastState.Bounded env56161 := by
  intro p hp
  have h : env56161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56160_56161 : H12AffineEnvironment.transform 8 48 env56160 = env56161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56160 == env56161) = true)

def env56162 : List Nat := [2,4,8,16,32,16,8,256,49,52,260,48,269,33,1,262,49,32,53,0,261,33,17,2,269,17,260,48,49,32,304,33,257,32,33,48]

theorem envBound56162 : H12AffineFastState.Bounded env56162 := by
  intro p hp
  have h : env56162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56160_56162 : H12AffineEnvironment.transform 8 49 env56160 = env56162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56160 == env56162) = true)

theorem identity56162 : scanCanonicalize (H12AffineFastState.compose env56162 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound56162 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56163 : List Nat := [2,4,8,16,32,16,8,63,49,52,59,48,50,33,1,57,49,32,53,0,58,33,17,2,50,17,59,48,49,32,15,33,62,32,33,48]

theorem envBound56163 : H12AffineFastState.Bounded env56163 := by
  intro p hp
  have h : env56163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56162_56163 : H12AffineEnvironment.transform 7 63 env56162 = env56163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env56162 == env56163) = true)

def leafEnv56163 : List Nat := [2,4,8,16,32,16,8,63,49,52,59,48,50,33,1,57,49,32,53,0,58,33,17,2,14,50,1,17,59,48,49,32,15,33,62,32,5,57,33,48,1,58,0]

def active56163 : List Nat := [0,1,2,3,4]

def tree56163 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56163 : H12WitnessSearch.Good tree56163 := H12GlobalWitnessIndex.good

theorem leafIdentity56163 : H12AffineFastState.composeSystem env56163 rootObs = leafEnv56163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56163 rootObs == leafEnv56163) = true)

theorem terminalChecked56163 : H12PackedTerminal.terminalCheckFast leafEnv56163 active56163 tree56163 = true := by decide +kernel

def env56164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41310,8192,65,4409703,115015,45404,190520,75103,4268042,257,98678,90202,513]

theorem envBound56164 : H12AffineFastState.Bounded env56164 := by
  intro p hp
  have h : env56164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56133_56164 : H12AffineEnvironment.transform 20 58397 env56133 = env56164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env56133 == env56164) = true)

def env56165 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41230,8192,17,4409655,114967,45324,190520,75023,4268042,257,98598,90122,513]

theorem envBound56165 : H12AffineFastState.Bounded env56165 := by
  intro p hp
  have h : env56165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56164_56165 : H12AffineEnvironment.transform 5 16 env56164 = env56165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56164 == env56165) = true)

theorem identity56165 : scanCanonicalize (H12AffineFastState.compose env56165 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound56165 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env56166 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1025,32769,58397,4194304,17,41230,8192,17,4385084,24860,45324,190520,34052,4227073,257,8493,49153,513]

theorem envBound56166 : H12AffineFastState.Bounded env56166 := by
  intro p hp
  have h : env56166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56165_56166 : H12AffineEnvironment.transform 15 40971 env56165 = env56166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env56165 == env56166) = true)

theorem identity56166 : scanCanonicalize (H12AffineFastState.compose env56166 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155965) := by decide +kernel

theorem selectedBound56166 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56167 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1025,32769,58397,155965,17,41230,8192,17,34817,24860,45324,190520,34052,188732,257,8493,49153,513]

theorem envBound56167 : H12AffineFastState.Bounded env56167 := by
  intro p hp
  have h : env56167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56166_56167 : H12AffineEnvironment.transform 21 155965 env56166 = env56167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155965 env56166 == env56167) = true)

theorem identity56167 : scanCanonicalize (H12AffineFastState.compose env56167 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound56167 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56168 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1025,32769,58397,8492,17,41230,8192,17,34817,24860,45324,43049,34052,41261,257,8493,49153,513]

theorem envBound56168 : H12AffineFastState.Bounded env56168 := by
  intro p hp
  have h : env56168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56167_56168 : H12AffineEnvironment.transform 16 16401 env56167 = env56168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56167 == env56168) = true)

def env56169 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41231,8192,16,4409654,114966,45325,190520,75022,4268042,257,98599,90123,513]

theorem envBound56169 : H12AffineFastState.Bounded env56169 := by
  intro p hp
  have h : env56169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56164_56169 : H12AffineEnvironment.transform 5 17 env56164 = env56169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56164 == env56169) = true)

theorem identity56169 : scanCanonicalize (H12AffineFastState.compose env56169 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound56169 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env56170 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,246071,17,41231,8192,16,34817,114966,45325,190520,75022,188733,257,98599,90123,513]

theorem envBound56170 : H12AffineFastState.Bounded env56170 := by
  intro p hp
  have h : env56170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56169_56170 : H12AffineEnvironment.transform 21 246071 env56169 = env56170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env56169 == env56170) = true)

theorem identity56170 : scanCanonicalize (H12AffineFastState.compose env56170 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56170 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env56171 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,65536,131072,10281,1025,1,25629,213303,17,8463,8192,16,2049,82198,12557,157752,75022,155965,257,65831,90123,513]

theorem envBound56171 : H12AffineFastState.Bounded env56171 := by
  intro p hp
  have h : env56171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56170_56171 : H12AffineEnvironment.transform 14 0 env56170 = env56171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56170 == env56171) = true)

theorem identity56171 : scanCanonicalize (H12AffineFastState.compose env56171 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound56171 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56172 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,262,131072,10281,1025,1,25629,147505,17,8463,8192,16,2049,16400,12557,157752,9224,155965,257,33,24845,513]

theorem envBound56172 : H12AffineFastState.Bounded env56172 := by
  intro p hp
  have h : env56172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56171_56172 : H12AffineEnvironment.transform 15 262 env56171 = env56172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env56171 == env56172) = true)

theorem identity56172 : scanCanonicalize (H12AffineFastState.compose env56172 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound56172 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env56173 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,262,16401,10281,1025,1,25629,32,17,8463,8192,16,2049,16400,12557,10281,9224,8492,257,33,24845,513]

theorem envBound56173 : H12AffineFastState.Bounded env56173 := by
  intro p hp
  have h : env56173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56172_56173 : H12AffineEnvironment.transform 16 16401 env56172 = env56173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56172 == env56173) = true)

theorem identity56173 : scanCanonicalize (H12AffineFastState.compose env56173 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56173 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env56174 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,262,16401,2341,1025,1,17681,32,17,3,268,16,2049,16400,4097,2341,1284,32,257,33,16385,513]

theorem envBound56174 : H12AffineFastState.Bounded env56174 := by
  intro p hp
  have h : env56174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56173_56174 : H12AffineEnvironment.transform 12 268 env56173 = env56174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56173 == env56174) = true)

theorem identity56174 : scanCanonicalize (H12AffineFastState.compose env56174 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound56174 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56175 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4388,0,262,4405,2341,1025,1,5173,32,17,3,268,16,2049,4404,4097,2341,1284,32,257,33,4389,513]

theorem envBound56175 : H12AffineFastState.Bounded env56175 := by
  intro p hp
  have h : env56175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56174_56175 : H12AffineEnvironment.transform 13 4388 env56174 = env56175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env56174 == env56175) = true)

theorem identity56175 : scanCanonicalize (H12AffineFastState.compose env56175 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound56175 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56176 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,513,268,805,0,262,820,2341,1025,1,1588,32,17,3,268,16,2049,821,512,2341,1284,32,257,33,804,513]

theorem envBound56176 : H12AffineFastState.Bounded env56176 := by
  intro p hp
  have h : env56176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56175_56176 : H12AffineEnvironment.transform 11 513 env56175 = env56176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env56175 == env56176) = true)

theorem identity56176 : scanCanonicalize (H12AffineFastState.compose env56176 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound56176 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56177 : List Nat := [2,4,8,16,32,17,8,256,512,768,2048,513,268,805,0,262,820,2341,769,1,308,32,17,3,268,16,2049,821,512,2341,516,32,257,33,804,513]

theorem envBound56177 : H12AffineFastState.Bounded env56177 := by
  intro p hp
  have h : env56177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56176_56177 : H12AffineEnvironment.transform 9 768 env56176 = env56177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env56176 == env56177) = true)

theorem identity56177 : scanCanonicalize (H12AffineFastState.compose env56177 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound56177 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56178 : List Nat := [2,4,8,16,32,17,8,53,512,565,2048,513,57,528,0,51,513,2064,564,1,1,32,17,3,57,16,2049,512,512,2064,516,32,52,33,529,513]

theorem envBound56178 : H12AffineFastState.Bounded env56178 := by
  intro p hp
  have h : env56178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56177_56178 : H12AffineEnvironment.transform 7 53 env56177 = env56178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env56177 == env56178) = true)

theorem identity56178 : scanCanonicalize (H12AffineFastState.compose env56178 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound56178 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56179 : List Nat := [2,4,8,16,32,17,8,53,512,565,16,513,57,528,0,51,513,0,564,1,1,32,17,3,57,16,17,512,512,0,516,32,52,33,529,513]

theorem envBound56179 : H12AffineFastState.Bounded env56179 := by
  intro p hp
  have h : env56179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56178_56179 : H12AffineEnvironment.transform 10 16 env56178 = env56179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env56178 == env56179) = true)

theorem identity56179 : scanCanonicalize (H12AffineFastState.compose env56179 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound56179 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56180 : List Nat := [2,4,8,16,32,17,8,53,32,21,16,33,57,48,0,51,33,0,20,1,1,32,17,3,57,16,17,32,32,0,36,32,52,33,49,33]

theorem envBound56180 : H12AffineFastState.Bounded env56180 := by
  intro p hp
  have h : env56180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56179_56180 : H12AffineEnvironment.transform 8 32 env56179 = env56180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env56179 == env56180) = true)

def env56181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272441,16777216,8193,65,21227576,18973701,2391401,190521,17148969,23160136,257,19262492,19205425,17075062]

theorem envBound56181 : H12AffineFastState.Bounded env56181 := by
  intro p hp
  have h : env56181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56130_56181 : H12AffineEnvironment.transform 6 9 env56130 = env56181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56130 == env56181) = true)

theorem identity56181 : scanCanonicalize (H12AffineFastState.compose env56181 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound56181 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env56182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,41293,16777216,8193,65,21227576,18973701,2159645,190521,16852317,23160136,257,18965864,18973765,16777730]

theorem envBound56182 : H12AffineFastState.Bounded env56182 := by
  intro p hp
  have h : env56182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56181_56182 : H12AffineEnvironment.transform 17 35188 env56181 = env56182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env56181 == env56182) = true)

theorem identity56182 : scanCanonicalize (H12AffineFastState.compose env56182 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 221208) := by decide +kernel

theorem selectedBound56182 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env56183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,41293,221208,8193,65,4229152,2286621,2159645,190521,148805,6423888,257,2229616,2286685,221722]

theorem envBound56183 : H12AffineFastState.Bounded env56183 := by
  intro p hp
  have h : env56183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56182_56183 : H12AffineEnvironment.transform 23 221208 env56182 = env56183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 221208 env56182 == env56183) = true)

def env56184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1025,32769,2097152,4194304,41293,98644,8193,65,4229152,2098513,2159645,2421,41993,6349852,257,2155580,2098449,99158]

theorem envBound56184 : H12AffineFastState.Bounded env56184 := by
  intro p hp
  have h : env56184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56183_56184 : H12AffineEnvironment.transform 16 57676 env56183 = env56184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env56183 == env56184) = true)

theorem identity56184 : scanCanonicalize (H12AffineFastState.compose env56184 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound56184 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1025,32769,2097152,4194304,41293,3,8193,65,4229152,2098513,2159645,2421,41993,6349852,257,2155580,2098449,513]

theorem envBound56185 : H12AffineFastState.Bounded env56185 := by
  intro p hp
  have h : env56185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56184_56185 : H12AffineEnvironment.transform 15 33111 env56184 = env56185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env56184 == env56185) = true)

theorem identity56185 : scanCanonicalize (H12AffineFastState.compose env56185 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound56185 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1025,32769,2097152,41341,41293,3,8193,65,10589,2098513,2159645,2421,41993,2114913,257,2155580,2098449,513]

theorem envBound56186 : H12AffineFastState.Bounded env56186 := by
  intro p hp
  have h : env56186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56185_56186 : H12AffineEnvironment.transform 21 41341 env56185 = env56186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env56185 == env56186) = true)

theorem identity56186 : scanCanonicalize (H12AffineFastState.compose env56186 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound56186 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8282,16449,10361,1025,8460,2097152,112,64,3,8193,65,10589,2098513,2118928,2421,1284,2114913,257,2114865,2098449,513]

theorem envBound56187 : H12AffineFastState.Bounded env56187 := by
  intro p hp
  have h : env56187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56186_56187 : H12AffineEnvironment.transform 14 8461 env56186 = env56187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env56186 == env56187) = true)

theorem identity56187 : scanCanonicalize (H12AffineFastState.compose env56187 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56188 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,10280,1025,8460,2097152,33,17,3,8193,16,10508,2098432,2118928,2340,1284,2114864,257,2114865,2098449,513]

theorem envBound56188 : H12AffineFastState.Bounded env56188 := by
  intro p hp
  have h : env56188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56187_56188 : H12AffineEnvironment.transform 5 17 env56187 = env56188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56187 == env56188) = true)

theorem identity56188 : scanCanonicalize (H12AffineFastState.compose env56188 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56188 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56189 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,8192,16384,8461,8203,16400,10280,52,8460,2097152,33,17,3,8193,16,10508,2097461,2117925,2340,305,2113797,257,2113796,2097444,513]

theorem envBound56189 : H12AffineFastState.Bounded env56189 := by
  intro p hp
  have h : env56189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56188_56189 : H12AffineEnvironment.transform 9 53 env56188 = env56189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56188 == env56189) = true)

theorem identity56189 : scanCanonicalize (H12AffineFastState.compose env56189 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound56189 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56190 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,40,16384,293,35,16400,2048,52,292,2097152,33,17,3,41,16,2340,2097461,2117925,2340,305,2113797,257,2113796,2097444,513]

theorem envBound56190 : H12AffineFastState.Bounded env56190 := by
  intro p hp
  have h : env56190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56189_56190 : H12AffineEnvironment.transform 12 40 env56189 = env56190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env56189 == env56190) = true)

theorem identity56190 : scanCanonicalize (H12AffineFastState.compose env56190 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56190 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56191 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,40,16384,0,35,16400,2048,52,1,2097152,33,17,3,41,16,2049,2097168,2117632,2049,20,2113568,36,2113569,2097153,513]

theorem envBound56191 : H12AffineFastState.Bounded env56191 := by
  intro p hp
  have h : env56191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56190_56191 : H12AffineEnvironment.transform 7 37 env56190 = env56191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56190 == env56191) = true)

theorem identity56191 : scanCanonicalize (H12AffineFastState.compose env56191 (packedSelected [1,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound56191 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env56192 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,40,4112,0,35,4096,2048,52,1,2097152,33,17,3,41,16,2049,2097168,2097168,2049,20,2101296,36,2101297,2097153,513]

theorem envBound56192 : H12AffineFastState.Bounded env56192 := by
  intro p hp
  have h : env56192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56191_56192 : H12AffineEnvironment.transform 13 4112 env56191 = env56192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env56191 == env56192) = true)

theorem identity56192 : scanCanonicalize (H12AffineFastState.compose env56192 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound56192 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56193 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,4096,40,4112,0,35,4096,48,52,1,2097152,33,17,3,41,16,49,2097168,2097168,49,20,2101296,36,2101297,2097153,513]

theorem envBound56193 : H12AffineFastState.Bounded env56193 := by
  intro p hp
  have h : env56193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56192_56193 : H12AffineEnvironment.transform 10 48 env56192 = env56193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env56192 == env56193) = true)

theorem identity56193 : scanCanonicalize (H12AffineFastState.compose env56193 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound56193 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56194 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,40,48,0,35,32,48,52,1,2097152,33,17,3,41,16,49,2097168,2097168,49,20,2097168,36,2097169,2097153,513]

theorem envBound56194 : H12AffineFastState.Bounded env56194 := by
  intro p hp
  have h : env56194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56193_56194 : H12AffineEnvironment.transform 11 32 env56193 = env56194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env56193 == env56194) = true)

theorem identity56194 : scanCanonicalize (H12AffineFastState.compose env56194 (packedSelected [0,1,5] rootPS)) = affineNative (2^(20+1) ^^^ 48) := by decide +kernel

theorem selectedBound56194 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env56195 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,40,48,0,35,32,48,52,1,48,33,17,3,41,16,49,32,32,49,20,32,36,33,49,513]

theorem envBound56195 : H12AffineFastState.Bounded env56195 := by
  intro p hp
  have h : env56195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56194_56195 : H12AffineEnvironment.transform 20 48 env56194 = env56195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 48 env56194 == env56195) = true)

def leafEnv56195 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,40,48,0,35,32,48,52,1,48,33,17,3,21,41,1,16,49,32,32,49,20,32,36,33,5,34,49,513,1,49,0]

def active56195 : List Nat := [0,1,2,3,4,8]

def tree56195 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56195 : H12WitnessSearch.Good tree56195 := H12GlobalWitnessIndex.good

theorem leafIdentity56195 : H12AffineFastState.composeSystem env56195 rootObs = leafEnv56195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56195 rootObs == leafEnv56195) = true)

theorem terminalChecked56195 : H12PackedTerminal.terminalCheckFast leafEnv56195 active56195 tree56195 = true := by decide +kernel

def env56196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35188,1025,32769,2097152,4194304,41293,98645,8193,65,4229152,2098512,2159645,2420,41992,6349853,257,2155581,2098448,99159]

theorem envBound56196 : H12AffineFastState.Bounded env56196 := by
  intro p hp
  have h : env56196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56183_56196 : H12AffineEnvironment.transform 16 57677 env56183 = env56196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env56183 == env56196) = true)

def env56197 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,57401,34816,1025,32769,2097152,4194304,41017,98337,8193,65,4229152,2098212,2159645,2048,41992,6349853,117,2155581,2098276,98851]

theorem envBound56197 : H12AffineFastState.Bounded env56197 := by
  intro p hp
  have h : env56197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56196_56197 : H12AffineEnvironment.transform 7 116 env56196 = env56197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56196 == env56197) = true)

theorem identity56197 : scanCanonicalize (H12AffineFastState.compose env56197 (packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2114581) := by decide +kernel

theorem selectedBound56197 : packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env56198 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,57401,34816,1025,32769,2097152,2114581,41017,98337,8193,65,2149429,2098212,2159645,2048,41992,40968,117,2155581,2098276,98851]

theorem envBound56198 : H12AffineFastState.Bounded env56198 := by
  intro p hp
  have h : env56198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56197_56198 : H12AffineEnvironment.transform 21 2114581 env56197 = env56198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114581 env56197 == env56198) = true)

theorem identity56198 : scanCanonicalize (H12AffineFastState.compose env56198 (packedSelected [4,9,12,14,15,16,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound56198 : packedSelected [4,9,12,14,15,16,38,41] rootPS < 2^1333 := by decide +kernel

def env56199 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,57401,34816,1025,32769,91198,73771,41017,98337,8193,65,108555,90138,102435,2048,41992,40968,117,98307,90202,98851]

theorem envBound56199 : H12AffineFastState.Bounded env56199 := by
  intro p hp
  have h : env56199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56198_56199 : H12AffineEnvironment.transform 20 91198 env56198 = env56199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env56198 == env56199) = true)

theorem identity56199 : scanCanonicalize (H12AffineFastState.compose env56199 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound56199 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env56200 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,32768,65536,49216,34816,1025,32769,83015,65618,32832,98337,120,65,100466,82019,102435,2048,33905,32881,117,98307,81955,98851]

theorem envBound56200 : H12AffineFastState.Bounded env56200 := by
  intro p hp
  have h : env56200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56199_56200 : H12AffineEnvironment.transform 12 121 env56199 = env56200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env56199 == env56200) = true)

theorem identity56200 : scanCanonicalize (H12AffineFastState.compose env56200 (packedSelected [1,2,4,6,8,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound56200 : packedSelected [1,2,4,6,8,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env56201 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,80,65536,16400,2128,1025,81,83015,65618,16,65649,120,65,67618,82019,69747,2048,1057,33,117,65619,81955,66163]

theorem envBound56201 : H12AffineFastState.Bounded env56201 := by
  intro p hp
  have h : env56201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56200_56201 : H12AffineEnvironment.transform 14 80 env56200 = env56201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env56200 == env56201) = true)

theorem identity56201 : scanCanonicalize (H12AffineFastState.compose env56201 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound56201 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56202 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,80,21510,16400,2128,1025,81,4161,21588,16,21623,120,65,23588,5221,17525,2048,1057,33,117,21589,5157,22133]

theorem envBound56202 : H12AffineFastState.Bounded env56202 := by
  intro p hp
  have h : env56202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56201_56202 : H12AffineEnvironment.transform 15 21510 env56201 = env56202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env56201 == env56202) = true)

def env56203 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,57400,34817,1025,32769,2097152,4194304,41016,98336,8193,65,4229152,2098213,2159645,2049,41992,6349853,116,2155581,2098277,98850]

theorem envBound56203 : H12AffineFastState.Bounded env56203 := by
  intro p hp
  have h : env56203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56196_56203 : H12AffineEnvironment.transform 7 117 env56196 = env56203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56196 == env56203) = true)

theorem identity56203 : scanCanonicalize (H12AffineFastState.compose env56203 (packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2212919) := by decide +kernel

theorem selectedBound56203 : packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env56204 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,57400,34817,1025,32769,2097152,2212919,41016,98336,8193,65,2182167,2098213,2159645,2049,41992,73770,116,2155581,2098277,98850]

theorem envBound56204 : H12AffineFastState.Bounded env56204 := by
  intro p hp
  have h : env56204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56203_56204 : H12AffineEnvironment.transform 21 2212919 env56203 = env56204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2212919 env56203 == env56204) = true)

theorem identity56204 : scanCanonicalize (H12AffineFastState.compose env56204 (packedSelected [4,9,12,14,15,16,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound56204 : packedSelected [4,9,12,14,15,16,38,41] rootPS < 2^1333 := by decide +kernel

def env56205 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,57400,34817,1025,32769,58396,73771,41016,98336,8193,65,108555,57401,4097,2049,41992,73770,116,33,57465,98850]

theorem envBound56205 : H12AffineFastState.Bounded env56205 := by
  intro p hp
  have h : env56205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56204_56205 : H12AffineEnvironment.transform 20 58396 env56204 = env56205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env56204 == env56205) = true)

theorem identity56205 : scanCanonicalize (H12AffineFastState.compose env56205 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound56205 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env56206 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,41051,57400,34817,1025,32769,58396,32880,41016,8315,8193,65,2128,57401,4097,2049,41992,32881,116,33,57465,8825]

theorem envBound56206 : H12AffineFastState.Bounded env56206 := by
  intro p hp
  have h : env56206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56205_56206 : H12AffineEnvironment.transform 15 41051 env56205 = env56206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env56205 == env56206) = true)

theorem identity56206 : scanCanonicalize (H12AffineFastState.compose env56206 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,15,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound56206 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env56207 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,80,8203,24680,2129,1025,81,25676,32,8296,8315,8193,65,2128,24681,4097,2049,9304,33,116,33,24617,8825]

theorem envBound56207 : H12AffineFastState.Bounded env56207 := by
  intro p hp
  have h : env56207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56206_56207 : H12AffineEnvironment.transform 14 80 env56206 = env56207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env56206 == env56207) = true)

theorem identity56207 : scanCanonicalize (H12AffineFastState.compose env56207 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound56207 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env56208 : List Nat := [2,4,8,16,32,64,9,117,512,1024,529,4096,8192,16384,80,8203,24680,576,1025,81,25676,32,8296,8315,8193,65,577,24681,4097,528,9304,33,116,33,24617,8825]

theorem envBound56208 : H12AffineFastState.Bounded env56208 := by
  intro p hp
  have h : env56208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56207_56208 : H12AffineEnvironment.transform 10 529 env56207 = env56208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env56207 == env56208) = true)

theorem identity56208 : scanCanonicalize (H12AffineFastState.compose env56208 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound56208 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env56209 : List Nat := [2,4,8,16,32,64,9,117,512,1024,529,4096,8192,13405,80,8203,5173,576,1025,81,4113,32,8296,8315,8193,65,577,5172,4097,528,9304,33,116,33,5236,8825]

theorem envBound56209 : H12AffineFastState.Bounded env56209 := by
  intro p hp
  have h : env56209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56208_56209 : H12AffineEnvironment.transform 13 13405 env56208 = env56209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env56208 == env56209) = true)

theorem identity56209 : scanCanonicalize (H12AffineFastState.compose env56209 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56209 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env56210 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,4096,8192,13324,1,8203,5173,529,1025,0,4113,32,8249,8234,8193,16,528,5172,4097,528,9225,33,37,33,5157,8744]

theorem envBound56210 : H12AffineFastState.Bounded env56210 := by
  intro p hp
  have h : env56210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56209_56210 : H12AffineEnvironment.transform 5 17 env56209 = env56210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56209 == env56210) = true)

theorem identity56210 : scanCanonicalize (H12AffineFastState.compose env56210 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 4665) := by decide +kernel

theorem selectedBound56210 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env56211 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,4096,4665,1589,1,4658,5173,529,1025,0,4113,32,4608,4627,4664,16,528,5172,4097,528,5680,33,37,33,5157,4113]

theorem envBound56211 : H12AffineFastState.Bounded env56211 := by
  intro p hp
  have h : env56211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56210_56211 : H12AffineEnvironment.transform 12 4665 env56210 = env56211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4665 env56210 == env56211) = true)

theorem identity56211 : scanCanonicalize (H12AffineFastState.compose env56211 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56211 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env56212 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,4096,4665,512,1,4658,4096,529,52,0,4113,32,4608,4627,4664,16,528,4097,4097,528,4613,33,37,33,4112,4113]

theorem envBound56212 : H12AffineFastState.Bounded env56212 := by
  intro p hp
  have h : env56212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56211_56212 : H12AffineEnvironment.transform 9 53 env56211 = env56212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56211 == env56212) = true)

theorem identity56212 : scanCanonicalize (H12AffineFastState.compose env56212 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56212 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56213 : List Nat := [2,4,8,16,32,17,9,36,0,53,17,4096,4153,0,1,4146,4096,17,52,0,4113,32,4096,4115,4152,16,16,4097,4097,16,4101,33,37,33,4112,4113]

theorem envBound56213 : H12AffineFastState.Bounded env56213 := by
  intro p hp
  have h : env56213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56212_56213 : H12AffineEnvironment.transform 8 0 env56212 = env56213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56212 == env56213) = true)

theorem identity56213 : scanCanonicalize (H12AffineFastState.compose env56213 (packedSelected [10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound56213 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env56214 : List Nat := [2,4,8,16,32,17,9,36,0,53,17,17,40,0,1,35,17,17,52,0,0,32,17,2,41,16,16,16,16,16,20,33,37,33,1,0]

theorem envBound56214 : H12AffineFastState.Bounded env56214 := by
  intro p hp
  have h : env56214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56213_56214 : H12AffineEnvironment.transform 11 17 env56213 = env56214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env56213 == env56214) = true)

theorem identity56214 : scanCanonicalize (H12AffineFastState.compose env56214 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56215 : List Nat := [2,4,8,16,1,17,9,5,0,20,17,17,9,0,1,2,17,17,21,0,0,1,17,2,8,16,16,16,16,16,20,0,4,0,1,0]

theorem envBound56215 : H12AffineFastState.Bounded env56215 := by
  intro p hp
  have h : env56215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56214_56215 : H12AffineEnvironment.transform 4 1 env56214 = env56215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56214 == env56215) = true)

end H12CloudChart0