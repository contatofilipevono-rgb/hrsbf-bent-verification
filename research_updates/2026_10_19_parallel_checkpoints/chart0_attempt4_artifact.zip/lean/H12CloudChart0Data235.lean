import H12CloudChart0Data234

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans59619_59620 : H12AffineEnvironment.transform 11 1109 env59619 = env59620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env59619 == env59620) = true)

theorem identity59620 : scanCanonicalize (H12AffineFastState.compose env59620 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound59620 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59621 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1408,1029,2128,65536,65799,3260,1025,2128,68782,1417,64,3158,1289,17,68915,1028,65879,66898,65542,68094,256,65674,65799,0]

theorem envBound59621 : H12AffineFastState.Bounded env59621 := by
  intro p hp
  have h : env59621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59620_59621 : H12AffineEnvironment.transform 17 3260 env59620 = env59621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env59620 == env59621) = true)

theorem identity59621 : scanCanonicalize (H12AffineFastState.compose env59621 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59621 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59622 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1244,1109,1408,1029,1164,65536,65799,96,1025,1164,65650,1417,64,138,1289,17,66031,1028,65879,66898,65542,66850,256,65674,65799,0]

theorem envBound59622 : H12AffineFastState.Bounded env59622 := by
  intro p hp
  have h : env59622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59621_59622 : H12AffineEnvironment.transform 10 1244 env59621 = env59622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59621 == env59622) = true)

theorem identity59622 : scanCanonicalize (H12AffineFastState.compose env59622 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59622 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59623 : List Nat := [2,4,8,16,32,64,128,256,0,408,324,461,24,413,276,65536,65799,96,409,276,65650,17,64,138,145,17,66031,412,65879,65738,65542,65722,256,65674,65799,0]

theorem envBound59623 : H12AffineFastState.Bounded env59623 := by
  intro p hp
  have h : env59623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59622_59623 : H12AffineEnvironment.transform 9 408 env59622 = env59623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59622 == env59623) = true)

theorem identity59623 : scanCanonicalize (H12AffineFastState.compose env59623 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59623 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59624 : List Nat := [2,4,8,16,17,64,128,256,0,408,324,461,24,413,276,65536,65799,81,409,276,65603,17,64,138,145,17,66014,412,65879,65738,65542,65675,256,65674,65799,0]

theorem envBound59624 : H12AffineFastState.Bounded env59624 := by
  intro p hp
  have h : env59624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59623_59624 : H12AffineEnvironment.transform 4 17 env59623 = env59624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59623 == env59624) = true)

theorem identity59624 : scanCanonicalize (H12AffineFastState.compose env59624 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59625 : List Nat := [2,4,8,16,17,64,128,256,0,408,324,461,24,413,276,154,413,81,409,276,217,17,64,138,145,17,324,412,461,80,156,17,256,16,413,0]

theorem envBound59625 : H12AffineFastState.Bounded env59625 := by
  intro p hp
  have h : env59625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59624_59625 : H12AffineEnvironment.transform 15 154 env59624 = env59625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59624 == env59625) = true)

theorem identity59625 : scanCanonicalize (H12AffineFastState.compose env59625 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59625 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59626 : List Nat := [2,4,8,16,17,64,128,214,0,78,146,27,24,75,194,154,75,81,79,194,217,17,64,138,145,17,146,74,27,80,156,17,214,16,75,0]

theorem envBound59626 : H12AffineFastState.Bounded env59626 := by
  intro p hp
  have h : env59626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59625_59626 : H12AffineEnvironment.transform 7 214 env59625 = env59626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59625 == env59626) = true)

theorem identity59626 : scanCanonicalize (H12AffineFastState.compose env59626 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59626 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59627 : List Nat := [2,4,8,16,17,64,89,15,0,78,75,27,24,75,27,67,75,81,79,27,0,17,64,83,72,17,75,74,27,80,69,17,15,16,75,0]

theorem envBound59627 : H12AffineFastState.Bounded env59627 := by
  intro p hp
  have h : env59627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59626_59627 : H12AffineEnvironment.transform 6 89 env59626 = env59627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59626 == env59627) = true)

theorem identity59627 : scanCanonicalize (H12AffineFastState.compose env59627 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59628 : List Nat := [2,4,8,16,17,17,8,15,0,31,26,27,24,26,27,18,26,0,30,27,0,17,17,2,25,17,26,27,27,1,20,17,15,16,26,0]

theorem envBound59628 : H12AffineFastState.Bounded env59628 := by
  intro p hp
  have h : env59628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59627_59628 : H12AffineEnvironment.transform 5 17 env59627 = env59628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59627 == env59628) = true)

def env59629 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,68783,1417,65,3158,1289,16,333275,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound59629 : H12AffineFastState.Bounded env59629 := by
  intro p hp
  have h : env59629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59618_59629 : H12AffineEnvironment.transform 12 1409 env59618 = env59629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59618 == env59629) = true)

theorem identity59629 : scanCanonicalize (H12AffineFastState.compose env59629 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound59629 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59630 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5458,1,262144,1025,2128,6653,1417,65,3158,1289,16,262281,4177,81,4096,5460,7340,256,5592,1,1]

theorem envBound59630 : H12AffineFastState.Bounded env59630 := by
  intro p hp
  have h : env59630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59629_59630 : H12AffineEnvironment.transform 15 5458 env59629 = env59630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env59629 == env59630) = true)

theorem identity59630 : scanCanonicalize (H12AffineFastState.compose env59630 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59630 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59631 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,5458,1,262144,1025,1448,5125,1417,65,430,1289,16,262281,4177,81,4096,5460,4436,256,5592,1,1]

theorem envBound59631 : H12AffineFastState.Bounded env59631 := by
  intro p hp
  have h : env59631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59630_59631 : H12AffineEnvironment.transform 10 1528 env59630 = env59631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59630 == env59631) = true)

theorem identity59631 : scanCanonicalize (H12AffineFastState.compose env59631 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59631 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59632 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1448,5458,1,5324,1025,1448,5125,1417,65,430,1289,16,5189,4177,81,4096,5460,4436,256,5592,1,1]

theorem envBound59632 : H12AffineFastState.Bounded env59632 := by
  intro p hp
  have h : env59632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59631_59632 : H12AffineEnvironment.transform 17 5324 env59631 = env59632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59631 == env59632) = true)

theorem identity59632 : scanCanonicalize (H12AffineFastState.compose env59632 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound59632 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59633 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,372,1409,292,1448,1062,1,1464,1025,1448,1393,1417,65,430,1289,16,1329,293,81,372,1056,32,256,1196,1,1]

theorem envBound59633 : H12AffineFastState.Bounded env59633 := by
  intro p hp
  have h : env59633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59632_59633 : H12AffineEnvironment.transform 11 372 env59632 = env59633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env59632 == env59633) = true)

theorem identity59633 : scanCanonicalize (H12AffineFastState.compose env59633 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59633 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59634 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,137,1148,217,1109,1062,1,1093,1025,1109,1164,1140,65,83,1268,16,1228,216,81,137,1056,32,253,1196,1,1]

theorem envBound59634 : H12AffineFastState.Bounded env59634 := by
  intro p hp
  have h : env59634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59633_59634 : H12AffineEnvironment.transform 7 253 env59633 = env59634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59633 == env59634) = true)

theorem identity59634 : scanCanonicalize (H12AffineFastState.compose env59634 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59634 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59635 : List Nat := [2,4,8,16,32,64,128,253,0,140,137,137,240,217,217,170,1,201,141,217,0,248,65,83,120,16,64,216,81,137,172,32,253,32,1,1]

theorem envBound59635 : H12AffineFastState.Bounded env59635 := by
  intro p hp
  have h : env59635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59634_59635 : H12AffineEnvironment.transform 9 140 env59634 = env59635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59634 == env59635) = true)

theorem identity59635 : scanCanonicalize (H12AffineFastState.compose env59635 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound59635 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59636 : List Nat := [2,4,8,16,32,49,128,140,0,140,137,137,129,168,168,170,1,184,141,168,0,137,48,34,9,16,49,169,32,137,172,32,140,32,1,1]

theorem envBound59636 : H12AffineFastState.Bounded env59636 := by
  intro p hp
  have h : env59636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59635_59636 : H12AffineEnvironment.transform 5 49 env59635 = env59636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env59635 == env59636) = true)

theorem identity59636 : scanCanonicalize (H12AffineFastState.compose env59636 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound59636 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59637 : List Nat := [2,4,8,8,32,41,128,140,0,140,137,137,129,168,168,170,1,160,141,168,0,137,40,34,9,8,41,169,32,137,172,32,140,32,1,1]

theorem envBound59637 : H12AffineFastState.Bounded env59637 := by
  intro p hp
  have h : env59637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59636_59637 : H12AffineEnvironment.transform 3 8 env59636 = env59637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env59636 == env59637) = true)

theorem identity59637 : scanCanonicalize (H12AffineFastState.compose env59637 (packedSelected [1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound59637 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59638 : List Nat := [2,4,8,8,32,41,11,7,0,7,2,2,10,35,35,33,1,43,6,35,0,2,40,34,9,8,41,34,32,2,39,32,7,32,1,1]

theorem envBound59638 : H12AffineFastState.Bounded env59638 := by
  intro p hp
  have h : env59638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59637_59638 : H12AffineEnvironment.transform 6 11 env59637 = env59638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env59637 == env59638) = true)

theorem identity59638 : scanCanonicalize (H12AffineFastState.compose env59638 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59638 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59639 : List Nat := [2,4,8,8,11,2,11,7,0,7,2,2,10,8,8,10,1,0,6,8,0,2,3,9,9,8,2,9,11,2,12,11,7,11,1,1]

theorem envBound59639 : H12AffineFastState.Bounded env59639 := by
  intro p hp
  have h : env59639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59638_59639 : H12AffineEnvironment.transform 4 11 env59638 = env59639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59638 == env59639) = true)

theorem identity59639 : scanCanonicalize (H12AffineFastState.compose env59639 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59640 : List Nat := [1,4,8,8,8,1,8,4,0,4,1,1,9,8,8,9,1,0,5,8,0,1,0,9,9,8,1,9,8,1,12,8,4,8,1,1]

theorem envBound59640 : H12AffineFastState.Bounded env59640 := by
  intro p hp
  have h : env59640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59639_59640 : H12AffineEnvironment.transform 0 1 env59639 = env59640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59639 == env59640) = true)

theorem identity59640 : scanCanonicalize (H12AffineFastState.compose env59640 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59640 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59641 : List Nat := [1,4,1,1,1,1,1,4,0,4,1,1,0,1,1,0,1,0,5,1,0,1,0,0,0,1,1,0,1,1,5,1,4,1,1,1]

theorem envBound59641 : H12AffineFastState.Bounded env59641 := by
  intro p hp
  have h : env59641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59640_59641 : H12AffineEnvironment.transform 2 1 env59640 = env59641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59640 == env59641) = true)

def env59642 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1289,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59642 : H12AffineFastState.Bounded env59642 := by
  intro p hp
  have h : env59642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59616_59642 : H12AffineEnvironment.transform 8 1 env59616 = env59642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59616 == env59642) = true)

theorem identity59642 : scanCanonicalize (H12AffineFastState.compose env59642 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound59642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59643 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,68782,1417,9664,3159,1289,9617,333275,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59643 : H12AffineFastState.Bounded env59643 := by
  intro p hp
  have h : env59643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59642_59643 : H12AffineEnvironment.transform 20 68782 env59642 = env59643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env59642 == env59643) = true)

def env59644 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,68782,1417,64,3159,1289,17,333275,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound59644 : H12AffineFastState.Bounded env59644 := by
  intro p hp
  have h : env59644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59643_59644 : H12AffineEnvironment.transform 12 1408 env59643 = env59644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59643 == env59644) = true)

theorem identity59644 : scanCanonicalize (H12AffineFastState.compose env59644 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound59644 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59645 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,68782,1417,64,3159,1289,17,328079,1029,65878,66899,65542,68095,256,65674,65798,1]

theorem envBound59645 : H12AffineFastState.Bounded env59645 := by
  intro p hp
  have h : env59645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59644_59645 : H12AffineEnvironment.transform 11 1108 env59644 = env59645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env59644 == env59645) = true)

theorem identity59645 : scanCanonicalize (H12AffineFastState.compose env59645 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound59645 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59646 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2129,65536,65798,3260,1025,2129,68782,1417,64,3159,1289,17,68915,1029,65878,66899,65542,68095,256,65674,65798,1]

theorem envBound59646 : H12AffineFastState.Bounded env59646 := by
  intro p hp
  have h : env59646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59645_59646 : H12AffineEnvironment.transform 17 3260 env59645 = env59646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env59645 == env59646) = true)

theorem identity59646 : scanCanonicalize (H12AffineFastState.compose env59646 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59646 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59647 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1245,1108,1408,1028,1164,65536,65798,97,1025,1164,65651,1417,64,138,1289,17,66030,1029,65878,66899,65542,66850,256,65674,65798,1]

theorem envBound59647 : H12AffineFastState.Bounded env59647 := by
  intro p hp
  have h : env59647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59646_59647 : H12AffineEnvironment.transform 10 1245 env59646 = env59647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59646 == env59647) = true)

theorem identity59647 : scanCanonicalize (H12AffineFastState.compose env59647 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59647 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59648 : List Nat := [2,4,8,16,32,64,128,256,1,408,325,460,24,412,276,65536,65798,97,409,276,65651,17,64,138,145,17,66030,413,65878,65739,65542,65722,256,65674,65798,1]

theorem envBound59648 : H12AffineFastState.Bounded env59648 := by
  intro p hp
  have h : env59648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59647_59648 : H12AffineEnvironment.transform 9 408 env59647 = env59648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59647 == env59648) = true)

theorem identity59648 : scanCanonicalize (H12AffineFastState.compose env59648 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59648 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59649 : List Nat := [2,4,8,16,17,64,128,256,1,408,325,460,24,412,276,65536,65798,80,409,276,65602,17,64,138,145,17,66015,413,65878,65739,65542,65675,256,65674,65798,1]

theorem envBound59649 : H12AffineFastState.Bounded env59649 := by
  intro p hp
  have h : env59649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59648_59649 : H12AffineEnvironment.transform 4 17 env59648 = env59649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59648 == env59649) = true)

theorem identity59649 : scanCanonicalize (H12AffineFastState.compose env59649 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59649 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59650 : List Nat := [2,4,8,16,17,64,128,256,1,408,325,460,24,412,276,154,412,80,409,276,216,17,64,138,145,17,325,413,460,81,156,17,256,16,412,1]

theorem envBound59650 : H12AffineFastState.Bounded env59650 := by
  intro p hp
  have h : env59650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59649_59650 : H12AffineEnvironment.transform 15 154 env59649 = env59650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59649 == env59650) = true)

theorem identity59650 : scanCanonicalize (H12AffineFastState.compose env59650 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59650 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59651 : List Nat := [2,4,8,16,17,64,128,215,1,79,146,27,24,75,195,154,75,80,78,195,216,17,64,138,145,17,146,74,27,81,156,17,215,16,75,1]

theorem envBound59651 : H12AffineFastState.Bounded env59651 := by
  intro p hp
  have h : env59651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59650_59651 : H12AffineEnvironment.transform 7 215 env59650 = env59651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59650 == env59651) = true)

def env59652 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,68782,1417,65,3159,1289,16,333275,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound59652 : H12AffineFastState.Bounded env59652 := by
  intro p hp
  have h : env59652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59643_59652 : H12AffineEnvironment.transform 12 1409 env59643 = env59652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59643 == env59652) = true)

theorem identity59652 : scanCanonicalize (H12AffineFastState.compose env59652 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound59652 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59653 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5458,1,262144,1025,2129,6652,1417,65,3159,1289,16,262281,4177,81,4097,5460,7341,256,5592,1,0]

theorem envBound59653 : H12AffineFastState.Bounded env59653 := by
  intro p hp
  have h : env59653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59652_59653 : H12AffineEnvironment.transform 15 5458 env59652 = env59653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env59652 == env59653) = true)

theorem identity59653 : scanCanonicalize (H12AffineFastState.compose env59653 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59653 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59654 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,5458,1,262144,1025,1448,5125,1417,65,430,1289,16,262281,4177,81,4097,5460,4436,256,5592,1,0]

theorem envBound59654 : H12AffineFastState.Bounded env59654 := by
  intro p hp
  have h : env59654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59653_59654 : H12AffineEnvironment.transform 10 1529 env59653 = env59654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59653 == env59654) = true)

theorem identity59654 : scanCanonicalize (H12AffineFastState.compose env59654 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5324) := by decide +kernel

theorem selectedBound59654 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59655 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1448,5458,1,5324,1025,1448,5125,1417,65,430,1289,16,5189,4177,81,4097,5460,4436,256,5592,1,0]

theorem envBound59655 : H12AffineFastState.Bounded env59655 := by
  intro p hp
  have h : env59655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59654_59655 : H12AffineEnvironment.transform 17 5324 env59654 = env59655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5324 env59654 == env59655) = true)

theorem identity59655 : scanCanonicalize (H12AffineFastState.compose env59655 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound59655 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59656 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,372,1409,292,1448,1062,1,1464,1025,1448,1393,1417,65,430,1289,16,1329,293,81,373,1056,32,256,1196,1,0]

theorem envBound59656 : H12AffineFastState.Bounded env59656 := by
  intro p hp
  have h : env59656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59655_59656 : H12AffineEnvironment.transform 11 372 env59655 = env59656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env59655 == env59656) = true)

theorem identity59656 : scanCanonicalize (H12AffineFastState.compose env59656 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59656 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59657 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,136,1149,216,1108,1062,1,1092,1025,1108,1165,1141,65,82,1269,16,1229,217,81,137,1056,32,252,1196,1,0]

theorem envBound59657 : H12AffineFastState.Bounded env59657 := by
  intro p hp
  have h : env59657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59656_59657 : H12AffineEnvironment.transform 7 252 env59656 = env59657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59656 == env59657) = true)

theorem identity59657 : scanCanonicalize (H12AffineFastState.compose env59657 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59657 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59658 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1029,136,1069,136,1028,1062,1,1044,1025,1028,1165,1061,17,2,1189,16,1181,137,1,137,1056,32,172,1196,1,0]

theorem envBound59658 : H12AffineFastState.Bounded env59658 := by
  intro p hp
  have h : env59658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59657_59658 : H12AffineEnvironment.transform 5 16 env59657 = env59658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59657 == env59658) = true)

theorem identity59658 : scanCanonicalize (H12AffineFastState.compose env59658 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 159) := by decide +kernel

theorem selectedBound59658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59659 : List Nat := [2,4,8,16,32,16,128,172,1,159,154,136,178,136,155,185,1,139,158,155,18,186,17,2,58,16,2,137,1,137,191,32,172,51,1,0]

theorem envBound59659 : H12AffineFastState.Bounded env59659 := by
  intro p hp
  have h : env59659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59658_59659 : H12AffineEnvironment.transform 9 159 env59658 = env59659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 159 env59658 == env59659) = true)

theorem identity59659 : scanCanonicalize (H12AffineFastState.compose env59659 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59659 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59660 : List Nat := [2,4,8,3,32,3,128,172,1,140,137,136,161,136,136,170,1,139,141,136,1,169,2,2,41,3,2,137,1,137,172,32,172,32,1,0]

theorem envBound59660 : H12AffineFastState.Bounded env59660 := by
  intro p hp
  have h : env59660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59659_59660 : H12AffineEnvironment.transform 3 3 env59659 = env59660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59659 == env59660) = true)

theorem identity59660 : scanCanonicalize (H12AffineFastState.compose env59660 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound59660 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59661 : List Nat := [2,4,8,3,32,3,42,6,1,38,35,34,11,34,34,0,1,33,39,34,1,3,2,2,41,3,2,35,1,35,6,32,6,32,1,0]

theorem envBound59661 : H12AffineFastState.Bounded env59661 := by
  intro p hp
  have h : env59661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59660_59661 : H12AffineEnvironment.transform 6 42 env59660 = env59661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env59660 == env59661) = true)

theorem identity59661 : scanCanonicalize (H12AffineFastState.compose env59661 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59661 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env59662 : List Nat := [2,4,0,3,32,3,34,6,1,38,35,34,3,34,34,0,1,33,39,34,1,3,2,2,33,3,2,35,1,35,6,32,6,32,1,0]

theorem envBound59662 : H12AffineFastState.Bounded env59662 := by
  intro p hp
  have h : env59662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59661_59662 : H12AffineEnvironment.transform 2 0 env59661 = env59662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59661 == env59662) = true)

theorem identity59662 : scanCanonicalize (H12AffineFastState.compose env59662 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound59662 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59663 : List Nat := [2,4,0,3,3,3,1,6,1,5,0,1,3,1,1,0,1,2,4,1,1,3,2,2,2,3,2,0,1,0,6,3,6,3,1,0]

theorem envBound59663 : H12AffineFastState.Bounded env59663 := by
  intro p hp
  have h : env59663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59662_59663 : H12AffineEnvironment.transform 4 3 env59662 = env59663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env59662 == env59663) = true)

theorem identity59663 : scanCanonicalize (H12AffineFastState.compose env59663 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59663 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59664 : List Nat := [1,4,0,0,0,0,1,5,1,5,0,1,0,1,1,0,1,1,4,1,1,0,1,1,1,0,1,0,1,0,5,0,5,0,1,0]

theorem envBound59664 : H12AffineFastState.Bounded env59664 := by
  intro p hp
  have h : env59664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59663_59664 : H12AffineEnvironment.transform 0 1 env59663 = env59664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59663 == env59664) = true)

def env59665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3671,1288,9616,2366324,4177,77954,67410,65543,68607,256,65674,78034,10113]

theorem envBound59665 : H12AffineFastState.Bounded env59665 := by
  intro p hp
  have h : env59665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59615_59665 : H12AffineEnvironment.transform 22 9665 env59615 = env59665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59615 == env59665) = true)

def env59666 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound59666 : H12AffineFastState.Bounded env59666 := by
  intro p hp
  have h : env59666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59665_59666 : H12AffineEnvironment.transform 8 0 env59665 = env59666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59665 == env59666) = true)

theorem identity59666 : scanCanonicalize (H12AffineFastState.compose env59666 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound59666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59667 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,5374,9260,262144,1025,2128,2097152,1417,9665,3159,1288,9616,2365812,4177,9340,4524,5369,7425,256,5236,9260,9601]

theorem envBound59667 : H12AffineFastState.Bounded env59667 := by
  intro p hp
  have h : env59667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59666_59667 : H12AffineEnvironment.transform 15 5374 env59666 = env59667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env59666 == env59667) = true)

def env59668 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,2097152,1417,65,3159,1288,16,2365812,4177,508,4524,5369,7425,256,5236,428,1]

theorem envBound59668 : H12AffineFastState.Bounded env59668 := by
  intro p hp
  have h : env59668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59667_59668 : H12AffineEnvironment.transform 12 1408 env59667 = env59668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59667 == env59668) = true)

theorem identity59668 : scanCanonicalize (H12AffineFastState.compose env59668 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59668 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59669 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,6653,1417,65,3159,1288,16,262281,4177,508,4524,5369,7425,256,5236,428,1]

theorem envBound59669 : H12AffineFastState.Bounded env59669 := by
  intro p hp
  have h : env59669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59668_59669 : H12AffineEnvironment.transform 20 6653 env59668 = env59669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59668 == env59669) = true)

theorem identity59669 : scanCanonicalize (H12AffineFastState.compose env59669 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59669 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59670 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,5374,428,262144,1025,1448,5125,1417,65,431,1288,16,262281,4177,508,4524,5369,4345,256,5236,428,1]

theorem envBound59670 : H12AffineFastState.Bounded env59670 := by
  intro p hp
  have h : env59670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59669_59670 : H12AffineEnvironment.transform 10 1528 env59669 = env59670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59669 == env59670) = true)

theorem identity59670 : scanCanonicalize (H12AffineFastState.compose env59670 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59670 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59671 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1448,5374,428,5325,1025,1448,5125,1417,65,431,1288,16,5188,4177,508,4524,5369,4345,256,5236,428,1]

theorem envBound59671 : H12AffineFastState.Bounded env59671 := by
  intro p hp
  have h : env59671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59670_59671 : H12AffineEnvironment.transform 17 5325 env59670 = env59671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59670 == env59671) = true)

theorem identity59671 : scanCanonicalize (H12AffineFastState.compose env59671 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound59671 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59672 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,216,1408,136,1448,1062,428,1045,1025,1448,1245,1417,65,431,1288,16,1180,137,508,372,1057,33,256,1196,428,1]

theorem envBound59672 : H12AffineFastState.Bounded env59672 := by
  intro p hp
  have h : env59672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59671_59672 : H12AffineEnvironment.transform 11 216 env59671 = env59672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env59671 == env59672) = true)

theorem identity59672 : scanCanonicalize (H12AffineFastState.compose env59672 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59672 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59673 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,216,1148,136,1108,1062,80,1045,1025,1108,1245,1141,65,83,1268,16,1180,137,0,136,1057,33,252,1196,80,1]

theorem envBound59673 : H12AffineFastState.Bounded env59673 := by
  intro p hp
  have h : env59673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59672_59673 : H12AffineEnvironment.transform 7 252 env59672 = env59673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59672 == env59673) = true)

theorem identity59673 : scanCanonicalize (H12AffineFastState.compose env59673 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59673 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59674 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1028,136,1068,136,1028,1062,0,1045,1025,1028,1165,1061,17,3,1188,16,1180,137,0,136,1057,33,172,1196,0,1]

theorem envBound59674 : H12AffineFastState.Bounded env59674 := by
  intro p hp
  have h : env59674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59673_59674 : H12AffineEnvironment.transform 5 16 env59673 = env59674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59673 == env59674) = true)

theorem identity59674 : scanCanonicalize (H12AffineFastState.compose env59674 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound59674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59675 : List Nat := [2,4,8,16,32,16,128,172,0,23,19,136,59,136,19,49,0,2,22,19,154,50,17,3,179,16,139,137,0,136,54,33,172,187,0,1]

theorem envBound59675 : H12AffineFastState.Bounded env59675 := by
  intro p hp
  have h : env59675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59674_59675 : H12AffineEnvironment.transform 9 23 env59674 = env59675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env59674 == env59675) = true)

theorem identity59675 : scanCanonicalize (H12AffineFastState.compose env59675 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound59675 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59676 : List Nat := [2,4,8,16,32,16,26,54,0,23,19,18,59,18,19,49,0,2,22,19,0,50,17,3,41,16,17,19,0,18,54,33,54,33,0,1]

theorem envBound59676 : H12AffineFastState.Bounded env59676 := by
  intro p hp
  have h : env59676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59675_59676 : H12AffineEnvironment.transform 6 26 env59675 = env59676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env59675 == env59676) = true)

theorem identity59676 : scanCanonicalize (H12AffineFastState.compose env59676 (packedSelected [3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59676 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59677 : List Nat := [2,4,8,16,17,16,26,7,0,23,19,18,10,18,19,0,0,2,22,19,0,3,17,3,24,16,17,19,0,18,7,16,7,16,0,1]

theorem envBound59677 : H12AffineFastState.Bounded env59677 := by
  intro p hp
  have h : env59677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59676_59677 : H12AffineEnvironment.transform 4 17 env59676 = env59677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59676 == env59677) = true)

theorem identity59677 : scanCanonicalize (H12AffineFastState.compose env59677 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59677 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env59678 : List Nat := [2,4,8,9,8,9,3,7,0,14,10,11,10,11,10,0,0,2,15,10,0,3,8,3,1,9,8,10,0,11,7,9,7,9,0,1]

theorem envBound59678 : H12AffineFastState.Bounded env59678 := by
  intro p hp
  have h : env59678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59677_59678 : H12AffineEnvironment.transform 3 9 env59677 = env59678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59677 == env59678) = true)

theorem identity59678 : scanCanonicalize (H12AffineFastState.compose env59678 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59678 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59679 : List Nat := [2,4,0,1,0,1,3,7,0,6,2,3,2,3,2,0,0,2,7,2,0,3,0,3,1,1,0,2,0,3,7,1,7,1,0,1]

theorem envBound59679 : H12AffineFastState.Bounded env59679 := by
  intro p hp
  have h : env59679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59678_59679 : H12AffineEnvironment.transform 2 0 env59678 = env59679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59678 == env59679) = true)

theorem identity59679 : scanCanonicalize (H12AffineFastState.compose env59679 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59679 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env59680 : List Nat := [1,4,0,1,0,1,0,4,0,5,1,0,1,0,1,0,0,1,4,1,0,0,0,0,1,1,0,1,0,0,4,1,4,1,0,1]

theorem envBound59680 : H12AffineFastState.Bounded env59680 := by
  intro p hp
  have h : env59680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59679_59680 : H12AffineEnvironment.transform 0 1 env59679 = env59680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59679 == env59680) = true)

def env59681 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5374,429,262144,1025,2128,2097152,1417,64,3159,1288,17,2365812,4177,509,4524,5369,7425,256,5236,429,0]

theorem envBound59681 : H12AffineFastState.Bounded env59681 := by
  intro p hp
  have h : env59681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59667_59681 : H12AffineEnvironment.transform 12 1409 env59667 = env59681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59667 == env59681) = true)

theorem identity59681 : scanCanonicalize (H12AffineFastState.compose env59681 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound59681 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59682 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5374,429,262144,1025,2128,3076,1417,64,3159,1288,17,267632,4177,509,4524,5369,7425,256,5236,429,0]

theorem envBound59682 : H12AffineFastState.Bounded env59682 := by
  intro p hp
  have h : env59682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59681_59682 : H12AffineEnvironment.transform 20 3076 env59681 = env59682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env59681 == env59682) = true)

theorem identity59682 : scanCanonicalize (H12AffineFastState.compose env59682 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59682 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59683 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5374,429,6377,1025,2128,3076,1417,64,3159,1288,17,3481,4177,509,4524,5369,7425,256,5236,429,0]

theorem envBound59683 : H12AffineFastState.Bounded env59683 := by
  intro p hp
  have h : env59683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59682_59683 : H12AffineEnvironment.transform 17 6377 env59682 = env59683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59682 == env59683) = true)

theorem identity59683 : scanCanonicalize (H12AffineFastState.compose env59683 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59683 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59684 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1409,413,2128,1331,429,2340,1025,2128,3076,1417,64,3159,1288,17,3481,412,509,97,1332,3276,256,1465,429,0]

theorem envBound59684 : H12AffineFastState.Bounded env59684 := by
  intro p hp
  have h : env59684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59683_59684 : H12AffineEnvironment.transform 11 461 env59683 = env59684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59683 == env59684) = true)

theorem identity59684 : scanCanonicalize (H12AffineFastState.compose env59684 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59684 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59685 : List Nat := [2,4,8,16,17,64,128,256,0,1024,2048,461,1409,413,2128,1282,412,2325,1025,2128,3076,1417,64,3159,1288,17,3481,412,460,80,1285,3276,256,1416,412,0]

theorem envBound59685 : H12AffineFastState.Bounded env59685 := by
  intro p hp
  have h : env59685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59684_59685 : H12AffineEnvironment.transform 4 17 env59684 = env59685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59684 == env59685) = true)

theorem identity59685 : scanCanonicalize (H12AffineFastState.compose env59685 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59685 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59686 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1245,461,1409,413,1165,1282,412,1480,1025,1165,217,1417,64,138,1288,17,324,412,460,80,1285,17,256,1416,412,0]

theorem envBound59686 : H12AffineFastState.Bounded env59686 := by
  intro p hp
  have h : env59686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59685_59686 : H12AffineEnvironment.transform 10 1245 env59685 = env59686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59685 == env59686) = true)

theorem identity59686 : scanCanonicalize (H12AffineFastState.compose env59686 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59686 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59687 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1245,146,1246,194,1165,1117,195,1175,1025,1165,217,1238,64,138,1111,17,27,195,147,80,1114,17,95,1239,195,0]

theorem envBound59687 : H12AffineFastState.Bounded env59687 := by
  intro p hp
  have h : env59687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59686_59687 : H12AffineEnvironment.transform 7 95 env59686 = env59687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59686 == env59687) = true)

theorem identity59687 : scanCanonicalize (H12AffineFastState.compose env59687 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59687 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59688 : List Nat := [2,4,8,16,17,64,128,95,0,199,26,146,25,194,74,154,195,80,198,74,217,17,64,138,144,17,27,195,147,80,157,17,95,16,195,0]

theorem envBound59688 : H12AffineFastState.Bounded env59688 := by
  intro p hp
  have h : env59688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59687_59688 : H12AffineEnvironment.transform 9 199 env59687 = env59688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59687 == env59688) = true)

def env59689 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1288,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound59689 : H12AffineFastState.Bounded env59689 := by
  intro p hp
  have h : env59689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59665_59689 : H12AffineEnvironment.transform 8 1 env59665 = env59689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59665 == env59689) = true)

theorem identity59689 : scanCanonicalize (H12AffineFastState.compose env59689 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound59689 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59690 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,12670,428,262144,1025,2129,2097152,1417,9665,3158,1288,9616,2365813,4177,508,13357,12665,14464,256,12788,428,9600]

theorem envBound59690 : H12AffineFastState.Bounded env59690 := by
  intro p hp
  have h : env59690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59689_59690 : H12AffineEnvironment.transform 15 12670 env59689 = env59690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env59689 == env59690) = true)

def env59691 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,2097152,1417,65,3158,1288,16,2365813,4177,508,4525,5369,7424,256,5236,428,0]

theorem envBound59691 : H12AffineFastState.Bounded env59691 := by
  intro p hp
  have h : env59691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59690_59691 : H12AffineEnvironment.transform 12 1408 env59690 = env59691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59690 == env59691) = true)

theorem identity59691 : scanCanonicalize (H12AffineFastState.compose env59691 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59691 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59692 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,6652,1417,65,3158,1288,16,262281,4177,508,4525,5369,7424,256,5236,428,0]

theorem envBound59692 : H12AffineFastState.Bounded env59692 := by
  intro p hp
  have h : env59692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59691_59692 : H12AffineEnvironment.transform 20 6652 env59691 = env59692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59691 == env59692) = true)

theorem identity59692 : scanCanonicalize (H12AffineFastState.compose env59692 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59692 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59693 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,5374,428,262144,1025,1448,5125,1417,65,431,1288,16,262281,4177,508,4525,5369,4345,256,5236,428,0]

theorem envBound59693 : H12AffineFastState.Bounded env59693 := by
  intro p hp
  have h : env59693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59692_59693 : H12AffineEnvironment.transform 10 1529 env59692 = env59693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59692 == env59693) = true)

theorem identity59693 : scanCanonicalize (H12AffineFastState.compose env59693 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59693 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59694 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1448,5374,428,5325,1025,1448,5125,1417,65,431,1288,16,5188,4177,508,4525,5369,4345,256,5236,428,0]

theorem envBound59694 : H12AffineFastState.Bounded env59694 := by
  intro p hp
  have h : env59694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59693_59694 : H12AffineEnvironment.transform 17 5325 env59693 = env59694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59693 == env59694) = true)

theorem identity59694 : scanCanonicalize (H12AffineFastState.compose env59694 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound59694 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59695 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,216,1408,136,1448,1062,428,1045,1025,1448,1245,1417,65,431,1288,16,1180,137,508,373,1057,33,256,1196,428,0]

theorem envBound59695 : H12AffineFastState.Bounded env59695 := by
  intro p hp
  have h : env59695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59694_59695 : H12AffineEnvironment.transform 11 216 env59694 = env59695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env59694 == env59695) = true)

theorem identity59695 : scanCanonicalize (H12AffineFastState.compose env59695 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59695 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59696 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,216,1149,136,1109,1062,81,1045,1025,1109,1245,1140,65,82,1269,16,1180,137,1,136,1057,33,253,1196,81,0]

theorem envBound59696 : H12AffineFastState.Bounded env59696 := by
  intro p hp
  have h : env59696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59695_59696 : H12AffineEnvironment.transform 7 253 env59695 = env59696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59695 == env59696) = true)

theorem identity59696 : scanCanonicalize (H12AffineFastState.compose env59696 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59696 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59697 : List Nat := [2,4,8,16,32,64,128,253,1,141,137,216,240,136,216,171,81,152,140,216,80,249,65,82,120,16,17,137,1,136,172,33,253,33,81,0]

theorem envBound59697 : H12AffineFastState.Bounded env59697 := by
  intro p hp
  have h : env59697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59696_59697 : H12AffineEnvironment.transform 9 141 env59696 = env59697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59696 == env59697) = true)

theorem identity59697 : scanCanonicalize (H12AffineFastState.compose env59697 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59697 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env59698 : List Nat := [2,4,8,16,32,1,128,188,1,141,137,153,177,136,153,171,16,152,140,153,17,184,0,19,57,16,17,137,1,136,172,33,188,33,16,0]

theorem envBound59698 : H12AffineFastState.Bounded env59698 := by
  intro p hp
  have h : env59698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59697_59698 : H12AffineEnvironment.transform 5 1 env59697 = env59698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59697 == env59698) = true)

theorem identity59698 : scanCanonicalize (H12AffineFastState.compose env59698 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound59698 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59699 : List Nat := [2,4,8,16,32,1,56,4,1,53,49,33,9,48,33,19,16,32,52,33,17,0,0,19,57,16,17,49,1,48,20,33,4,33,16,0]

theorem envBound59699 : H12AffineFastState.Bounded env59699 := by
  intro p hp
  have h : env59699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59698_59699 : H12AffineEnvironment.transform 6 56 env59698 = env59699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env59698 == env59699) = true)

theorem identity59699 : scanCanonicalize (H12AffineFastState.compose env59699 (packedSelected [0,1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59699 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env59700 : List Nat := [1,4,8,16,32,1,56,4,1,53,49,33,9,48,33,16,16,32,52,33,17,0,0,16,57,16,17,49,1,48,20,33,4,33,16,0]

theorem envBound59700 : H12AffineFastState.Bounded env59700 := by
  intro p hp
  have h : env59700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59699_59700 : H12AffineEnvironment.transform 0 1 env59699 = env59700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59699 == env59700) = true)

theorem identity59700 : scanCanonicalize (H12AffineFastState.compose env59700 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound59700 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59701 : List Nat := [1,4,8,16,24,1,0,4,1,13,9,25,9,8,25,16,16,24,12,25,17,0,0,16,1,16,17,9,1,8,20,25,4,25,16,0]

theorem envBound59701 : H12AffineFastState.Bounded env59701 := by
  intro p hp
  have h : env59701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59700_59701 : H12AffineEnvironment.transform 4 24 env59700 = env59701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env59700 == env59701) = true)

theorem identity59701 : scanCanonicalize (H12AffineFastState.compose env59701 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59701 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59702 : List Nat := [1,4,8,1,9,1,0,4,1,13,9,8,9,8,8,1,1,9,12,8,0,0,0,1,1,1,0,9,1,8,5,8,4,8,1,0]

theorem envBound59702 : H12AffineFastState.Bounded env59702 := by
  intro p hp
  have h : env59702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59701_59702 : H12AffineEnvironment.transform 3 1 env59701 = env59702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59701 == env59702) = true)

theorem identity59702 : scanCanonicalize (H12AffineFastState.compose env59702 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59702 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59703 : List Nat := [1,4,0,1,1,1,0,4,1,5,1,0,1,0,0,1,1,1,4,0,0,0,0,1,1,1,0,1,1,0,5,0,4,0,1,0]

theorem envBound59703 : H12AffineFastState.Bounded env59703 := by
  intro p hp
  have h : env59703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59702_59703 : H12AffineEnvironment.transform 2 0 env59702 = env59703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59702 == env59703) = true)

def env59704 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5375,428,262144,1025,2129,2097152,1417,64,3158,1288,17,2365813,4177,508,4524,5368,7425,256,5237,428,1]

theorem envBound59704 : H12AffineFastState.Bounded env59704 := by
  intro p hp
  have h : env59704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59690_59704 : H12AffineEnvironment.transform 12 1409 env59690 = env59704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59690 == env59704) = true)

theorem identity59704 : scanCanonicalize (H12AffineFastState.compose env59704 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound59704 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59705 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5375,428,262144,1025,2129,3076,1417,64,3158,1288,17,267633,4177,508,4524,5368,7425,256,5237,428,1]

theorem envBound59705 : H12AffineFastState.Bounded env59705 := by
  intro p hp
  have h : env59705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59704_59705 : H12AffineEnvironment.transform 20 3076 env59704 = env59705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env59704 == env59705) = true)

theorem identity59705 : scanCanonicalize (H12AffineFastState.compose env59705 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59705 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59706 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5375,428,6376,1025,2129,3076,1417,64,3158,1288,17,3481,4177,508,4524,5368,7425,256,5237,428,1]

theorem envBound59706 : H12AffineFastState.Bounded env59706 := by
  intro p hp
  have h : env59706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59705_59706 : H12AffineEnvironment.transform 17 6376 env59705 = env59706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59705 == env59706) = true)

theorem identity59706 : scanCanonicalize (H12AffineFastState.compose env59706 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59706 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59707 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1409,412,2129,1331,428,2340,1025,2129,3076,1417,64,3158,1288,17,3481,413,508,96,1332,3277,256,1465,428,1]

theorem envBound59707 : H12AffineFastState.Bounded env59707 := by
  intro p hp
  have h : env59707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59706_59707 : H12AffineEnvironment.transform 11 460 env59706 = env59707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59706 == env59707) = true)

theorem identity59707 : scanCanonicalize (H12AffineFastState.compose env59707 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1261) := by decide +kernel

theorem selectedBound59707 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59708 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1261,460,1409,412,1212,1331,428,1481,1025,1212,233,1417,64,187,1288,17,372,413,508,96,1332,32,256,1465,428,1]

theorem envBound59708 : H12AffineFastState.Bounded env59708 := by
  intro p hp
  have h : env59708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59707_59708 : H12AffineEnvironment.transform 10 1261 env59707 = env59708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1261 env59707 == env59708) = true)

theorem identity59708 : scanCanonicalize (H12AffineFastState.compose env59708 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59708 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59709 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1244,460,1409,412,1165,1282,413,1481,1025,1165,216,1417,64,138,1288,17,325,413,461,81,1285,17,256,1416,413,1]

theorem envBound59709 : H12AffineFastState.Bounded env59709 := by
  intro p hp
  have h : env59709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59708_59709 : H12AffineEnvironment.transform 4 17 env59708 = env59709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59708 == env59709) = true)

theorem identity59709 : scanCanonicalize (H12AffineFastState.compose env59709 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59709 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59710 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1244,147,1246,195,1165,1117,194,1174,1025,1165,216,1238,64,138,1111,17,26,194,146,81,1114,17,95,1239,194,1]

theorem envBound59710 : H12AffineFastState.Bounded env59710 := by
  intro p hp
  have h : env59710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59709_59710 : H12AffineEnvironment.transform 7 95 env59709 = env59710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59709 == env59710) = true)

theorem identity59710 : scanCanonicalize (H12AffineFastState.compose env59710 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59710 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59711 : List Nat := [2,4,8,16,17,64,128,95,1,199,27,147,25,195,74,154,194,81,198,74,216,17,64,138,144,17,26,194,146,81,157,17,95,16,194,1]

theorem envBound59711 : H12AffineFastState.Bounded env59711 := by
  intro p hp
  have h : env59711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59710_59711 : H12AffineEnvironment.transform 9 199 env59710 = env59711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59710 == env59711) = true)

def env59712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,33554432,8388689,134217728,4177,77954,4260570,8463814,149237955,256,136649727,78034,33563273]

theorem envBound59712 : H12AffineFastState.Bounded env59712 := by
  intro p hp
  have h : env59712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58982_59712 : H12AffineEnvironment.transform 14 2641 env58982 = env59712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2641 env58982 == env59712) = true)

def env59713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,8397000,8388689,134217728,4177,77954,4260570,8463814,149237955,256,136649727,78034,8389185]

theorem envBound59713 : H12AffineFastState.Bounded env59713 := by
  intro p hp
  have h : env59713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59712_59713 : H12AffineEnvironment.transform 24 8397000 env59712 = env59713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397000 env59712 == env59713) = true)

def env59714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399767,8397000,8388689,6561532,4177,77954,4260570,8463814,8465983,256,4261123,78034,8389185]

theorem envBound59714 : H12AffineFastState.Bounded env59714 := by
  intro p hp
  have h : env59714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59713_59714 : H12AffineEnvironment.transform 26 6561532 env59713 = env59714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env59713 == env59714) = true)

def env59715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399767,8397000,8388689,2366324,4177,77954,67410,8463814,8465983,256,65675,78034,8389185]

theorem envBound59715 : H12AffineFastState.Bounded env59715 := by
  intro p hp
  have h : env59715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59714_59715 : H12AffineEnvironment.transform 21 1416 env59714 = env59715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59714 == env59715) = true)

def env59716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3671,1288,9617,2366324,4177,77954,67410,65542,68607,256,65675,78034,10113]

theorem envBound59716 : H12AffineFastState.Bounded env59716 := by
  intro p hp
  have h : env59716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59715_59716 : H12AffineEnvironment.transform 22 9664 env59715 = env59716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59715 == env59716) = true)

def env59717 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1288,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59717 : H12AffineFastState.Bounded env59717 := by
  intro p hp
  have h : env59717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59716_59717 : H12AffineEnvironment.transform 8 0 env59716 = env59717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59716 == env59717) = true)

theorem identity59717 : scanCanonicalize (H12AffineFastState.compose env59717 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 77299) := by decide +kernel

theorem selectedBound59717 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59718 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,77299,1416,9664,3159,1288,9617,341127,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59718 : H12AffineFastState.Bounded env59718 := by
  intro p hp
  have h : env59718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59717_59718 : H12AffineEnvironment.transform 20 77299 env59717 = env59718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77299 env59717 == env59718) = true)

def env59719 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,67699,1416,64,3159,1288,17,332039,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound59719 : H12AffineFastState.Bounded env59719 := by
  intro p hp
  have h : env59719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59718_59719 : H12AffineEnvironment.transform 12 1408 env59718 = env59719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59718 == env59719) = true)

theorem identity59719 : scanCanonicalize (H12AffineFastState.compose env59719 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound59719 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59720 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4494,1244,262144,1025,2129,6653,1416,64,3159,1288,17,262281,4177,1164,5340,4488,6257,256,4357,1244,1]

theorem envBound59720 : H12AffineFastState.Bounded env59720 := by
  intro p hp
  have h : env59720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59719_59720 : H12AffineEnvironment.transform 15 4494 env59719 = env59720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env59719 == env59720) = true)

theorem identity59720 : scanCanonicalize (H12AffineFastState.compose env59720 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59720 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59721 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,4494,1244,262144,1025,1448,5124,1416,64,430,1288,17,262281,4177,1164,5340,4488,5512,256,4357,1244,1]

theorem envBound59721 : H12AffineFastState.Bounded env59721 := by
  intro p hp
  have h : env59721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59720_59721 : H12AffineEnvironment.transform 10 1529 env59720 = env59721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59720 == env59721) = true)

theorem identity59721 : scanCanonicalize (H12AffineFastState.compose env59721 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound59721 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59722 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,4494,1244,1377,1025,1448,5124,1416,64,430,1288,17,1512,4177,1164,5340,4488,5512,256,4357,1244,1]

theorem envBound59722 : H12AffineFastState.Bounded env59722 := by
  intro p hp
  have h : env59722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59721_59722 : H12AffineEnvironment.transform 17 1377 env59721 = env59722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env59721 == env59722) = true)

theorem identity59722 : scanCanonicalize (H12AffineFastState.compose env59722 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound59722 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59723 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1449,1408,1529,1448,1063,1244,1377,1025,1448,429,1416,64,430,1288,17,1512,1528,1164,373,1057,33,256,1196,1244,1]

theorem envBound59723 : H12AffineFastState.Bounded env59723 := by
  intro p hp
  have h : env59723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59722_59723 : H12AffineEnvironment.transform 11 1449 env59722 = env59723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env59722 == env59723) = true)

theorem identity59723 : scanCanonicalize (H12AffineFastState.compose env59723 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59723 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59724 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,1109,1148,1029,1108,1063,1244,1181,1025,1108,81,1140,64,82,1268,17,1044,1028,1164,137,1057,33,252,1196,1244,1]

theorem envBound59724 : H12AffineFastState.Bounded env59724 := by
  intro p hp
  have h : env59724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59723_59724 : H12AffineEnvironment.transform 7 252 env59723 = env59724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59723 == env59724) = true)

theorem identity59724 : scanCanonicalize (H12AffineFastState.compose env59724 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59724 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59725 : List Nat := [2,4,8,16,32,64,128,252,0,141,136,216,241,136,217,170,81,16,140,217,81,249,64,82,121,17,153,137,1,137,172,33,252,33,81,1]

theorem envBound59725 : H12AffineFastState.Bounded env59725 := by
  intro p hp
  have h : env59725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59724_59725 : H12AffineEnvironment.transform 9 141 env59724 = env59725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59724 == env59725) = true)

theorem identity59725 : scanCanonicalize (H12AffineFastState.compose env59725 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59725 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env59726 : List Nat := [2,4,8,16,32,64,89,37,0,84,81,1,40,81,0,115,81,16,85,0,81,32,64,82,121,17,64,80,1,80,117,33,37,33,81,1]

theorem envBound59726 : H12AffineFastState.Bounded env59726 := by
  intro p hp
  have h : env59726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59725_59726 : H12AffineEnvironment.transform 6 89 env59725 = env59726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59725 == env59726) = true)

theorem identity59726 : scanCanonicalize (H12AffineFastState.compose env59726 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound59726 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59727 : List Nat := [2,4,8,8,32,64,65,37,0,76,73,1,40,73,0,107,73,8,77,0,73,32,64,74,97,9,64,72,1,72,109,33,37,33,73,1]

theorem envBound59727 : H12AffineFastState.Bounded env59727 := by
  intro p hp
  have h : env59727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59726_59727 : H12AffineEnvironment.transform 3 8 env59726 = env59727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env59726 == env59727) = true)

theorem identity59727 : scanCanonicalize (H12AffineFastState.compose env59727 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59727 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59728 : List Nat := [2,4,8,8,10,64,65,15,0,76,73,1,2,73,0,65,73,8,77,0,73,10,64,74,75,9,64,72,1,72,71,11,15,11,73,1]

theorem envBound59728 : H12AffineFastState.Bounded env59728 := by
  intro p hp
  have h : env59728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59727_59728 : H12AffineEnvironment.transform 4 10 env59727 = env59728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59727 == env59728) = true)

theorem identity59728 : scanCanonicalize (H12AffineFastState.compose env59728 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59728 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59729 : List Nat := [2,4,8,8,10,1,0,15,0,13,8,1,2,8,0,0,8,8,12,0,8,10,1,11,10,9,1,9,1,9,6,11,15,11,8,1]

theorem envBound59729 : H12AffineFastState.Bounded env59729 := by
  intro p hp
  have h : env59729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59728_59729 : H12AffineEnvironment.transform 5 1 env59728 = env59729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59728 == env59729) = true)

theorem identity59729 : scanCanonicalize (H12AffineFastState.compose env59729 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59729 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59730 : List Nat := [1,4,8,8,9,1,0,12,0,13,8,1,1,8,0,0,8,8,12,0,8,9,1,8,9,9,1,9,1,9,5,8,12,8,8,1]

theorem envBound59730 : H12AffineFastState.Bounded env59730 := by
  intro p hp
  have h : env59730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59729_59730 : H12AffineEnvironment.transform 0 1 env59729 = env59730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59729 == env59730) = true)

theorem identity59730 : scanCanonicalize (H12AffineFastState.compose env59730 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59730 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env59731 : List Nat := [1,4,0,0,1,1,0,4,0,5,0,1,1,0,0,0,0,0,4,0,0,1,1,0,1,1,1,1,1,1,5,0,4,0,0,1]

theorem envBound59731 : H12AffineFastState.Bounded env59731 := by
  intro p hp
  have h : env59731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59730_59731 : H12AffineEnvironment.transform 2 0 env59730 = env59731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59730 == env59731) = true)

def env59732 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,67698,1416,65,3159,1288,16,332038,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound59732 : H12AffineFastState.Bounded env59732 := by
  intro p hp
  have h : env59732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59718_59732 : H12AffineEnvironment.transform 12 1409 env59718 = env59732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59718 == env59732) = true)

theorem identity59732 : scanCanonicalize (H12AffineFastState.compose env59732 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59732 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59733 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,67698,1416,65,3159,1288,16,328078,217,66955,66898,65542,68095,256,65675,67035,0]

theorem envBound59733 : H12AffineFastState.Bounded env59733 := by
  intro p hp
  have h : env59733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59732_59733 : H12AffineEnvironment.transform 11 136 env59732 = env59733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59732 == env59733) = true)

theorem identity59733 : scanCanonicalize (H12AffineFastState.compose env59733 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound59733 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59734 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,65536,67035,65983,1025,2129,67698,1416,65,3159,1288,16,49,217,66955,66898,65542,68095,256,65675,67035,0]

theorem envBound59734 : H12AffineFastState.Bounded env59734 := by
  intro p hp
  have h : env59734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59733_59734 : H12AffineEnvironment.transform 17 65983 env59733 = env59734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env59733 == env59734) = true)

theorem identity59734 : scanCanonicalize (H12AffineFastState.compose env59734 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound59734 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59735 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,1095,412,1528,1025,2129,3125,1416,65,3159,1288,16,49,217,460,277,1089,3512,256,1228,412,0]

theorem envBound59735 : H12AffineFastState.Bounded env59735 := by
  intro p hp
  have h : env59735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59734_59735 : H12AffineEnvironment.transform 15 1095 env59734 = env59735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env59734 == env59735) = true)

theorem identity59735 : scanCanonicalize (H12AffineFastState.compose env59735 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59735 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59736 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1245,136,1409,216,1164,1095,412,1528,1025,1164,232,1416,65,138,1288,16,49,217,460,277,1089,357,256,1228,412,0]

theorem envBound59736 : H12AffineFastState.Bounded env59736 := by
  intro p hp
  have h : env59736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59735_59736 : H12AffineEnvironment.transform 10 1245 env59735 = env59736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59735 == env59736) = true)

theorem identity59736 : scanCanonicalize (H12AffineFastState.compose env59736 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59736 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59737 : List Nat := [2,4,8,16,32,64,128,256,0,424,373,136,41,216,292,495,412,80,425,292,232,32,65,138,160,16,49,217,460,277,489,357,256,356,412,0]

theorem envBound59737 : H12AffineFastState.Bounded env59737 := by
  intro p hp
  have h : env59737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59736_59737 : H12AffineEnvironment.transform 9 424 env59736 = env59737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59736 == env59737) = true)

theorem identity59737 : scanCanonicalize (H12AffineFastState.compose env59737 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59737 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59738 : List Nat := [2,4,8,16,32,64,128,69,0,237,48,136,41,216,97,170,217,80,236,97,232,32,65,138,160,16,49,217,137,80,172,32,69,33,217,0]

theorem envBound59738 : H12AffineFastState.Bounded env59738 := by
  intro p hp
  have h : env59738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59737_59738 : H12AffineEnvironment.transform 7 69 env59737 = env59738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59737 == env59738) = true)

theorem identity59738 : scanCanonicalize (H12AffineFastState.compose env59738 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound59738 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59739 : List Nat := [2,4,8,16,32,58,128,63,0,151,48,136,41,162,27,170,163,42,150,27,146,32,59,138,160,16,49,163,137,42,172,32,63,33,163,0]

theorem envBound59739 : H12AffineFastState.Bounded env59739 := by
  intro p hp
  have h : env59739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59738_59739 : H12AffineEnvironment.transform 5 58 env59738 = env59739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env59738 == env59739) = true)

def env59740 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1288,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59740 : H12AffineFastState.Bounded env59740 := by
  intro p hp
  have h : env59740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59716_59740 : H12AffineEnvironment.transform 8 1 env59716 = env59740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59716 == env59740) = true)

theorem identity59740 : scanCanonicalize (H12AffineFastState.compose env59740 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 67698) := by decide +kernel

theorem selectedBound59740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59741 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,67698,1416,9664,3158,1288,9617,332039,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59741 : H12AffineFastState.Bounded env59741 := by
  intro p hp
  have h : env59741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59740_59741 : H12AffineEnvironment.transform 20 67698 env59740 = env59741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67698 env59740 == env59741) = true)

def env59742 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,67698,1416,64,3158,1288,17,332039,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound59742 : H12AffineFastState.Bounded env59742 := by
  intro p hp
  have h : env59742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59741_59742 : H12AffineEnvironment.transform 12 1408 env59741 = env59742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59741 == env59742) = true)

theorem identity59742 : scanCanonicalize (H12AffineFastState.compose env59742 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound59742 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59743 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4494,1244,262144,1025,2128,6652,1416,64,3158,1288,17,262281,4177,1164,5341,4488,6256,256,4357,1244,0]

theorem envBound59743 : H12AffineFastState.Bounded env59743 := by
  intro p hp
  have h : env59743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59742_59743 : H12AffineEnvironment.transform 15 4494 env59742 = env59743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env59742 == env59743) = true)

theorem identity59743 : scanCanonicalize (H12AffineFastState.compose env59743 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59743 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59744 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,4494,1244,262144,1025,1448,5124,1416,64,430,1288,17,262281,4177,1164,5341,4488,5512,256,4357,1244,0]

theorem envBound59744 : H12AffineFastState.Bounded env59744 := by
  intro p hp
  have h : env59744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59743_59744 : H12AffineEnvironment.transform 10 1528 env59743 = env59744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59743 == env59744) = true)

theorem identity59744 : scanCanonicalize (H12AffineFastState.compose env59744 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound59744 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59745 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,4494,1244,1377,1025,1448,5124,1416,64,430,1288,17,1512,4177,1164,5341,4488,5512,256,4357,1244,0]

theorem envBound59745 : H12AffineFastState.Bounded env59745 := by
  intro p hp
  have h : env59745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59744_59745 : H12AffineEnvironment.transform 17 1377 env59744 = env59745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env59744 == env59745) = true)

theorem identity59745 : scanCanonicalize (H12AffineFastState.compose env59745 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound59745 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59746 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1449,1408,1529,1448,1063,1244,1377,1025,1448,429,1416,64,430,1288,17,1512,1528,1164,372,1057,33,256,1196,1244,0]

theorem envBound59746 : H12AffineFastState.Bounded env59746 := by
  intro p hp
  have h : env59746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59745_59746 : H12AffineEnvironment.transform 11 1449 env59745 = env59746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env59745 == env59746) = true)

theorem identity59746 : scanCanonicalize (H12AffineFastState.compose env59746 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59746 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59747 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,1108,1149,1028,1109,1063,1244,1180,1025,1109,80,1141,64,83,1269,17,1045,1029,1164,137,1057,33,253,1196,1244,0]

theorem envBound59747 : H12AffineFastState.Bounded env59747 := by
  intro p hp
  have h : env59747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59746_59747 : H12AffineEnvironment.transform 7 253 env59746 = env59747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59746 == env59747) = true)

theorem identity59747 : scanCanonicalize (H12AffineFastState.compose env59747 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59747 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59748 : List Nat := [2,4,8,16,32,16,128,173,1,1024,1029,1028,1069,1028,1029,1063,1164,1180,1025,1029,0,1061,16,3,1189,17,1045,1029,1164,137,1057,33,173,1196,1164,0]

theorem envBound59748 : H12AffineFastState.Bounded env59748 := by
  intro p hp
  have h : env59748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59747_59748 : H12AffineEnvironment.transform 5 16 env59747 = env59748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59747 == env59748) = true)

theorem identity59748 : scanCanonicalize (H12AffineFastState.compose env59748 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 142) := by decide +kernel

theorem selectedBound59748 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59749 : List Nat := [2,4,8,16,32,16,128,173,1,142,139,138,163,138,139,169,2,18,143,139,0,171,16,3,43,17,155,139,2,137,175,33,173,34,2,0]

theorem envBound59749 : H12AffineFastState.Bounded env59749 := by
  intro p hp
  have h : env59749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59748_59749 : H12AffineEnvironment.transform 9 142 env59748 = env59749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 142 env59748 == env59749) = true)

theorem identity59749 : scanCanonicalize (H12AffineFastState.compose env59749 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound59749 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59750 : List Nat := [2,4,8,16,32,16,11,38,1,5,0,1,40,1,0,34,2,18,4,0,0,32,16,3,43,17,16,0,2,2,36,33,38,34,2,0]

theorem envBound59750 : H12AffineFastState.Bounded env59750 := by
  intro p hp
  have h : env59750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59749_59750 : H12AffineEnvironment.transform 6 11 env59749 = env59750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env59749 == env59750) = true)

theorem identity59750 : scanCanonicalize (H12AffineFastState.compose env59750 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59751 : List Nat := [2,4,8,1,32,1,11,38,1,5,0,1,40,1,0,34,2,3,4,0,0,32,1,3,43,0,1,0,2,2,36,33,38,34,2,0]

theorem envBound59751 : H12AffineFastState.Bounded env59751 := by
  intro p hp
  have h : env59751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59750_59751 : H12AffineEnvironment.transform 3 1 env59750 = env59751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59750 == env59751) = true)

theorem identity59751 : scanCanonicalize (H12AffineFastState.compose env59751 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59751 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59752 : List Nat := [1,4,8,1,32,1,8,37,1,5,0,1,40,1,0,33,1,0,4,0,0,32,1,0,40,0,1,0,1,1,36,33,37,33,1,0]

theorem envBound59752 : H12AffineFastState.Bounded env59752 := by
  intro p hp
  have h : env59752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59751_59752 : H12AffineEnvironment.transform 0 1 env59751 = env59752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59751 == env59752) = true)

theorem identity59752 : scanCanonicalize (H12AffineFastState.compose env59752 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59753 : List Nat := [1,4,8,1,0,1,8,5,1,5,0,1,8,1,0,1,1,0,4,0,0,0,1,0,8,0,1,0,1,1,4,1,5,1,1,0]

theorem envBound59753 : H12AffineFastState.Bounded env59753 := by
  intro p hp
  have h : env59753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59752_59753 : H12AffineEnvironment.transform 4 0 env59752 = env59753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59752 == env59753) = true)

theorem identity59753 : scanCanonicalize (H12AffineFastState.compose env59753 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59753 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59754 : List Nat := [1,4,0,1,0,1,0,5,1,5,0,1,0,1,0,1,1,0,4,0,0,0,1,0,0,0,1,0,1,1,4,1,5,1,1,0]

theorem envBound59754 : H12AffineFastState.Bounded env59754 := by
  intro p hp
  have h : env59754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59753_59754 : H12AffineEnvironment.transform 2 0 env59753 = env59754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59753 == env59754) = true)

def env59755 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,67698,1416,65,3158,1288,16,332039,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound59755 : H12AffineFastState.Bounded env59755 := by
  intro p hp
  have h : env59755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59741_59755 : H12AffineEnvironment.transform 12 1409 env59741 = env59755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59741 == env59755) = true)

theorem identity59755 : scanCanonicalize (H12AffineFastState.compose env59755 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59755 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59756 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1409,217,2128,65536,67034,262144,1025,2128,67698,1416,65,3158,1288,16,328078,216,66954,66899,65542,68094,256,65675,67034,1]

theorem envBound59756 : H12AffineFastState.Bounded env59756 := by
  intro p hp
  have h : env59756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59755_59756 : H12AffineEnvironment.transform 11 137 env59755 = env59756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59755 == env59756) = true)

theorem identity59756 : scanCanonicalize (H12AffineFastState.compose env59756 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound59756 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59757 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1409,217,2128,65536,67034,65982,1025,2128,67698,1416,65,3158,1288,16,48,216,66954,66899,65542,68094,256,65675,67034,1]

theorem envBound59757 : H12AffineFastState.Bounded env59757 := by
  intro p hp
  have h : env59757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59756_59757 : H12AffineEnvironment.transform 17 65982 env59756 = env59757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env59756 == env59757) = true)

theorem identity59757 : scanCanonicalize (H12AffineFastState.compose env59757 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound59757 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59758 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1409,217,2128,1095,413,1529,1025,2128,3125,1416,65,3158,1288,16,48,216,461,276,1089,3513,256,1228,413,1]

theorem envBound59758 : H12AffineFastState.Bounded env59758 := by
  intro p hp
  have h : env59758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59757_59758 : H12AffineEnvironment.transform 15 1095 env59757 = env59758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env59757 == env59758) = true)

theorem identity59758 : scanCanonicalize (H12AffineFastState.compose env59758 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59758 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59759 : List Nat := [2,4,8,16,32,64,128,68,1,1024,2048,137,1221,217,2128,1095,217,1213,1025,2128,3125,1228,65,3158,1100,16,48,216,137,80,1089,3325,68,1228,217,1]

theorem envBound59759 : H12AffineFastState.Bounded env59759 := by
  intro p hp
  have h : env59759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59758_59759 : H12AffineEnvironment.transform 7 68 env59758 = env59759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59758 == env59759) = true)

theorem identity59759 : scanCanonicalize (H12AffineFastState.compose env59759 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound59759 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59760 : List Nat := [2,4,8,16,32,64,128,68,1,1024,1070,137,1221,217,1150,1095,217,1213,1025,1150,27,1228,65,120,1100,16,48,216,137,80,1089,211,68,1228,217,1]

theorem envBound59760 : H12AffineFastState.Bounded env59760 := by
  intro p hp
  have h : env59760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59759_59760 : H12AffineEnvironment.transform 10 1070 env59759 = env59760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env59759 == env59760) = true)

theorem identity59760 : scanCanonicalize (H12AffineFastState.compose env59760 (packedSelected [0,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59760 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env59761 : List Nat := [2,4,8,16,32,64,114,68,1,1024,1070,123,1079,43,1150,1095,43,1103,1025,1150,27,1086,65,120,1100,16,48,42,123,80,1089,33,68,1086,43,1]

theorem envBound59761 : H12AffineFastState.Bounded env59761 := by
  intro p hp
  have h : env59761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59760_59761 : H12AffineEnvironment.transform 6 114 env59760 = env59761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59760 == env59761) = true)

theorem identity59761 : scanCanonicalize (H12AffineFastState.compose env59761 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound59761 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59762 : List Nat := [2,4,8,16,32,64,114,68,1,30,48,123,41,43,96,89,43,81,31,96,27,32,65,120,82,16,48,42,123,80,95,33,68,32,43,1]

theorem envBound59762 : H12AffineFastState.Bounded env59762 := by
  intro p hp
  have h : env59762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59761_59762 : H12AffineEnvironment.transform 9 30 env59761 = env59762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env59761 == env59762) = true)

def env59763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3670,1289,9616,2366324,4177,77954,67410,65543,68606,256,65675,78034,10112]

theorem envBound59763 : H12AffineFastState.Bounded env59763 := by
  intro p hp
  have h : env59763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59715_59763 : H12AffineEnvironment.transform 22 9665 env59715 = env59763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59715 == env59763) = true)

def env59764 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound59764 : H12AffineFastState.Bounded env59764 := by
  intro p hp
  have h : env59764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59763_59764 : H12AffineEnvironment.transform 8 0 env59763 = env59764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59763 == env59764) = true)

theorem identity59764 : scanCanonicalize (H12AffineFastState.compose env59764 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound59764 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59765 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,4130,8432,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2365812,4177,8352,5488,4133,6620,256,4265,8432,9600]

theorem envBound59765 : H12AffineFastState.Bounded env59765 := by
  intro p hp
  have h : env59765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59764_59765 : H12AffineEnvironment.transform 15 4130 env59764 = env59765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env59764 == env59765) = true)

def env59766 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4130,1392,262144,1025,2129,2097152,1416,65,3158,1289,16,2365812,4177,1312,5488,4133,6620,256,4265,1392,0]

theorem envBound59766 : H12AffineFastState.Bounded env59766 := by
  intro p hp
  have h : env59766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59765_59766 : H12AffineEnvironment.transform 12 1408 env59765 = env59766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59765 == env59766) = true)

theorem identity59766 : scanCanonicalize (H12AffineFastState.compose env59766 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound59766 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59767 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4130,1392,262144,1025,2129,2265,1416,65,3158,1289,16,266669,4177,1312,5488,4133,6620,256,4265,1392,0]

theorem envBound59767 : H12AffineFastState.Bounded env59767 := by
  intro p hp
  have h : env59767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59766_59767 : H12AffineEnvironment.transform 20 2265 env59766 = env59767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env59766 == env59767) = true)

theorem identity59767 : scanCanonicalize (H12AffineFastState.compose env59767 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound59767 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59768 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4130,1392,277,1025,2129,2265,1416,65,3158,1289,16,4280,4177,1312,5488,4133,6620,256,4265,1392,0]

theorem envBound59768 : H12AffineFastState.Bounded env59768 := by
  intro p hp
  have h : env59768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59767_59768 : H12AffineEnvironment.transform 17 277 env59767 = env59768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env59767 == env59768) = true)

theorem identity59768 : scanCanonicalize (H12AffineFastState.compose env59768 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59768 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59769 : List Nat := [2,4,8,16,32,64,128,256,0,236,2048,4096,364,4176,2129,4130,412,277,237,2129,2265,356,65,2234,485,16,4280,4177,460,4508,4133,6620,256,4265,412,0]

theorem envBound59769 : H12AffineFastState.Bounded env59769 := by
  intro p hp
  have h : env59769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59768_59769 : H12AffineEnvironment.transform 9 236 env59768 = env59769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59768 == env59769) = true)

theorem identity59769 : scanCanonicalize (H12AffineFastState.compose env59769 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2556) := by decide +kernel

theorem selectedBound59769 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59770 : List Nat := [2,4,8,16,32,64,128,256,0,236,2048,2556,364,2476,2129,2526,412,277,237,2129,2265,356,65,2234,485,16,2372,2477,460,2144,2521,32,256,2389,412,0]

theorem envBound59770 : H12AffineFastState.Bounded env59770 := by
  intro p hp
  have h : env59770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59769_59770 : H12AffineEnvironment.transform 11 2556 env59769 = env59770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2556 env59769 == env59770) = true)

theorem identity59770 : scanCanonicalize (H12AffineFastState.compose env59770 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59770 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59771 : List Nat := [2,4,8,16,32,64,128,256,0,236,48,460,364,412,97,494,412,277,237,97,233,356,65,138,485,16,372,413,460,80,489,32,256,357,412,0]

theorem envBound59771 : H12AffineFastState.Bounded env59771 := by
  intro p hp
  have h : env59771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59770_59771 : H12AffineEnvironment.transform 10 48 env59770 = env59771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59770 == env59771) = true)

theorem identity59771 : scanCanonicalize (H12AffineFastState.compose env59771 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59771 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59772 : List Nat := [2,4,8,16,32,64,128,182,0,236,48,122,218,42,97,88,42,163,237,97,233,210,65,138,83,16,194,43,122,80,95,32,182,211,42,0]

theorem envBound59772 : H12AffineFastState.Bounded env59772 := by
  intro p hp
  have h : env59772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59771_59772 : H12AffineEnvironment.transform 7 182 env59771 = env59772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59771 == env59772) = true)

theorem identity59772 : scanCanonicalize (H12AffineFastState.compose env59772 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59772 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59773 : List Nat := [2,4,8,16,32,64,114,68,0,30,48,122,40,42,97,88,42,81,31,97,27,32,65,120,83,16,48,43,122,80,95,32,68,33,42,0]

theorem envBound59773 : H12AffineFastState.Bounded env59773 := by
  intro p hp
  have h : env59773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59772_59773 : H12AffineEnvironment.transform 6 114 env59772 = env59773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59772 == env59773) = true)

def env59774 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,2097152,1416,64,3158,1289,17,2365812,4177,1313,5488,4133,6620,256,4265,1393,1]

theorem envBound59774 : H12AffineFastState.Bounded env59774 := by
  intro p hp
  have h : env59774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59765_59774 : H12AffineEnvironment.transform 12 1409 env59765 = env59774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59765 == env59774) = true)

theorem identity59774 : scanCanonicalize (H12AffineFastState.compose env59774 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59774 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59775 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,6653,1416,64,3158,1289,17,262281,4177,1313,5488,4133,6620,256,4265,1393,1]

theorem envBound59775 : H12AffineFastState.Bounded env59775 := by
  intro p hp
  have h : env59775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59774_59775 : H12AffineEnvironment.transform 20 6653 env59774 = env59775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59774 == env59775) = true)

theorem identity59775 : scanCanonicalize (H12AffineFastState.compose env59775 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59775 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59776 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,4130,1393,262144,1025,1448,5124,1416,64,431,1289,17,262281,4177,1313,5488,4133,5157,256,4265,1393,1]

theorem envBound59776 : H12AffineFastState.Bounded env59776 := by
  intro p hp
  have h : env59776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59775_59776 : H12AffineEnvironment.transform 10 1529 env59775 = env59776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59775 == env59776) = true)

theorem identity59776 : scanCanonicalize (H12AffineFastState.compose env59776 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound59776 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59777 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,4130,1393,1228,1025,1448,5124,1416,64,431,1289,17,1093,4177,1313,5488,4133,5157,256,4265,1393,1]

theorem envBound59777 : H12AffineFastState.Bounded env59777 := by
  intro p hp
  have h : env59777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59776_59777 : H12AffineEnvironment.transform 17 1228 env59776 = env59777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env59776 == env59777) = true)

theorem identity59777 : scanCanonicalize (H12AffineFastState.compose env59777 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59777 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59778 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1029,1409,1109,1448,1063,1393,1228,1025,1448,1,1416,64,431,1289,17,1093,1108,1313,373,1056,32,256,1196,1393,1]

theorem envBound59778 : H12AffineFastState.Bounded env59778 := by
  intro p hp
  have h : env59778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59777_59778 : H12AffineEnvironment.transform 11 1029 env59777 = env59778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59777 == env59778) = true)

theorem identity59778 : scanCanonicalize (H12AffineFastState.compose env59778 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59778 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59779 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,1029,1148,1109,1109,1063,1164,1228,1025,1109,1,1141,64,82,1268,17,1093,1108,1244,136,1056,32,253,1196,1164,1]

theorem envBound59779 : H12AffineFastState.Bounded env59779 := by
  intro p hp
  have h : env59779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59778_59779 : H12AffineEnvironment.transform 7 253 env59778 = env59779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59778 == env59779) = true)

theorem identity59779 : scanCanonicalize (H12AffineFastState.compose env59779 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59779 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59780 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1028,1029,1068,1029,1029,1063,1164,1180,1025,1029,1,1061,16,2,1188,17,1045,1028,1164,136,1056,32,173,1196,1164,1]

theorem envBound59780 : H12AffineFastState.Bounded env59780 := by
  intro p hp
  have h : env59780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59779_59780 : H12AffineEnvironment.transform 5 16 env59779 = env59780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59779 == env59780) = true)

theorem identity59780 : scanCanonicalize (H12AffineFastState.compose env59780 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 7) := by decide +kernel

theorem selectedBound59780 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59781 : List Nat := [2,4,8,16,32,16,128,173,0,7,3,2,43,2,2,32,139,155,6,2,1,34,16,2,163,17,18,3,139,136,39,32,173,171,139,1]

theorem envBound59781 : H12AffineFastState.Bounded env59781 := by
  intro p hp
  have h : env59781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59780_59781 : H12AffineEnvironment.transform 9 7 env59780 = env59781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 7 env59780 == env59781) = true)

theorem identity59781 : scanCanonicalize (H12AffineFastState.compose env59781 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59781 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59782 : List Nat := [0,4,8,16,32,16,128,173,0,5,1,0,41,0,0,32,137,153,4,0,1,32,16,0,161,17,16,1,137,136,37,32,173,169,137,1]

theorem envBound59782 : H12AffineFastState.Bounded env59782 := by
  intro p hp
  have h : env59782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59781_59782 : H12AffineEnvironment.transform 0 0 env59781 = env59782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59781 == env59782) = true)

theorem identity59782 : scanCanonicalize (H12AffineFastState.compose env59782 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59783 : List Nat := [0,4,8,0,32,0,128,173,0,5,1,0,41,0,0,32,137,137,4,0,1,32,0,0,161,1,0,1,137,136,37,32,173,169,137,1]

theorem envBound59783 : H12AffineFastState.Bounded env59783 := by
  intro p hp
  have h : env59783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59782_59783 : H12AffineEnvironment.transform 3 0 env59782 = env59783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59782 == env59783) = true)

theorem identity59783 : scanCanonicalize (H12AffineFastState.compose env59783 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59783 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59784 : List Nat := [0,4,8,0,32,0,9,36,0,5,1,0,41,0,0,32,0,0,4,0,1,32,0,0,40,1,0,1,0,1,37,32,36,32,0,1]

theorem envBound59784 : H12AffineFastState.Bounded env59784 := by
  intro p hp
  have h : env59784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59783_59784 : H12AffineEnvironment.transform 6 9 env59783 = env59784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59783 == env59784) = true)

def env59785 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1289,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound59785 : H12AffineFastState.Bounded env59785 := by
  intro p hp
  have h : env59785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59763_59785 : H12AffineEnvironment.transform 8 1 env59763 = env59785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59763 == env59785) = true)

theorem identity59785 : scanCanonicalize (H12AffineFastState.compose env59785 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 13731) := by decide +kernel

theorem selectedBound59785 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59786 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,13731,1393,262144,1025,2128,2097152,1416,9665,3159,1289,9616,2365813,4177,1313,12528,13732,15452,256,13608,1393,9601]

theorem envBound59786 : H12AffineFastState.Bounded env59786 := by
  intro p hp
  have h : env59786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59785_59786 : H12AffineEnvironment.transform 15 13731 env59785 = env59786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13731 env59785 == env59786) = true)

def env59787 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4131,1393,262144,1025,2128,2097152,1416,65,3159,1289,16,2365813,4177,1313,5488,4132,6620,256,4264,1393,1]

theorem envBound59787 : H12AffineFastState.Bounded env59787 := by
  intro p hp
  have h : env59787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59786_59787 : H12AffineEnvironment.transform 12 1408 env59786 = env59787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59786 == env59787) = true)

theorem identity59787 : scanCanonicalize (H12AffineFastState.compose env59787 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound59787 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59788 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4131,1393,262144,1025,2128,2265,1416,65,3159,1289,16,266668,4177,1313,5488,4132,6620,256,4264,1393,1]

theorem envBound59788 : H12AffineFastState.Bounded env59788 := by
  intro p hp
  have h : env59788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59787_59788 : H12AffineEnvironment.transform 20 2265 env59787 = env59788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env59787 == env59788) = true)

theorem identity59788 : scanCanonicalize (H12AffineFastState.compose env59788 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound59788 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59789 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4131,1393,276,1025,2128,2265,1416,65,3159,1289,16,4280,4177,1313,5488,4132,6620,256,4264,1393,1]

theorem envBound59789 : H12AffineFastState.Bounded env59789 := by
  intro p hp
  have h : env59789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59788_59789 : H12AffineEnvironment.transform 17 276 env59788 = env59789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env59788 == env59789) = true)

theorem identity59789 : scanCanonicalize (H12AffineFastState.compose env59789 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59789 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59790 : List Nat := [2,4,8,16,32,64,128,256,1,236,2048,4096,364,4176,2128,4131,413,276,237,2128,2265,356,65,2235,485,16,4280,4177,461,4508,4132,6620,256,4264,413,1]

theorem envBound59790 : H12AffineFastState.Bounded env59790 := by
  intro p hp
  have h : env59790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59789_59790 : H12AffineEnvironment.transform 9 236 env59789 = env59790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59789 == env59790) = true)

theorem identity59790 : scanCanonicalize (H12AffineFastState.compose env59790 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59790 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59791 : List Nat := [2,4,8,16,32,64,128,256,1,236,49,4096,364,4176,97,4131,413,276,237,97,232,356,65,138,485,16,4280,4177,461,4508,4132,4589,256,4264,413,1]

theorem envBound59791 : H12AffineFastState.Bounded env59791 := by
  intro p hp
  have h : env59791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59790_59791 : H12AffineEnvironment.transform 10 49 env59790 = env59791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59790 == env59791) = true)

theorem identity59791 : scanCanonicalize (H12AffineFastState.compose env59791 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59791 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env59792 : List Nat := [2,4,8,16,32,64,128,256,1,236,49,461,364,413,97,494,413,276,237,97,232,356,65,138,485,16,373,412,461,81,489,32,256,357,413,1]

theorem envBound59792 : H12AffineFastState.Bounded env59792 := by
  intro p hp
  have h : env59792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59791_59792 : H12AffineEnvironment.transform 11 461 env59791 = env59792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59791 == env59792) = true)

theorem identity59792 : scanCanonicalize (H12AffineFastState.compose env59792 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59792 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59793 : List Nat := [2,4,8,16,32,64,128,182,1,236,49,123,218,43,97,88,43,162,237,97,232,210,65,138,83,16,195,42,123,81,95,32,182,211,43,1]

theorem envBound59793 : H12AffineFastState.Bounded env59793 := by
  intro p hp
  have h : env59793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59792_59793 : H12AffineEnvironment.transform 7 182 env59792 = env59793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59792 == env59793) = true)

theorem identity59793 : scanCanonicalize (H12AffineFastState.compose env59793 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59793 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59794 : List Nat := [2,4,8,16,32,64,114,68,1,30,49,123,40,43,97,88,43,80,31,97,26,32,65,120,83,16,49,42,123,81,95,32,68,33,43,1]

theorem envBound59794 : H12AffineFastState.Bounded env59794 := by
  intro p hp
  have h : env59794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59793_59794 : H12AffineEnvironment.transform 6 114 env59793 = env59794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59793 == env59794) = true)

def env59795 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,2097152,1416,64,3159,1289,17,2365813,4177,1313,5489,4133,6621,256,4265,1393,0]

theorem envBound59795 : H12AffineFastState.Bounded env59795 := by
  intro p hp
  have h : env59795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59786_59795 : H12AffineEnvironment.transform 12 1409 env59786 = env59795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59786 == env59795) = true)

theorem identity59795 : scanCanonicalize (H12AffineFastState.compose env59795 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59795 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59796 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,6652,1416,64,3159,1289,17,262281,4177,1313,5489,4133,6621,256,4265,1393,0]

theorem envBound59796 : H12AffineFastState.Bounded env59796 := by
  intro p hp
  have h : env59796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59795_59796 : H12AffineEnvironment.transform 20 6652 env59795 = env59796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59795 == env59796) = true)

theorem identity59796 : scanCanonicalize (H12AffineFastState.compose env59796 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59796 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59797 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,4130,1393,262144,1025,1448,5124,1416,64,431,1289,17,262281,4177,1313,5489,4133,5157,256,4265,1393,0]

theorem envBound59797 : H12AffineFastState.Bounded env59797 := by
  intro p hp
  have h : env59797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59796_59797 : H12AffineEnvironment.transform 10 1528 env59796 = env59797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59796 == env59797) = true)

theorem identity59797 : scanCanonicalize (H12AffineFastState.compose env59797 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound59797 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59798 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1448,4130,1393,1228,1025,1448,5124,1416,64,431,1289,17,1093,4177,1313,5489,4133,5157,256,4265,1393,0]

theorem envBound59798 : H12AffineFastState.Bounded env59798 := by
  intro p hp
  have h : env59798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59797_59798 : H12AffineEnvironment.transform 17 1228 env59797 = env59798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env59797 == env59798) = true)

theorem identity59798 : scanCanonicalize (H12AffineFastState.compose env59798 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59798 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59799 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1029,1409,1109,1448,1063,1393,1228,1025,1448,1,1416,64,431,1289,17,1093,1108,1313,372,1056,32,256,1196,1393,0]

theorem envBound59799 : H12AffineFastState.Bounded env59799 := by
  intro p hp
  have h : env59799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59798_59799 : H12AffineEnvironment.transform 11 1029 env59798 = env59799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59798 == env59799) = true)

theorem identity59799 : scanCanonicalize (H12AffineFastState.compose env59799 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59799 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59800 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,1029,1149,1109,1108,1063,1165,1228,1025,1108,1,1140,64,83,1269,17,1093,1108,1245,136,1056,32,252,1196,1165,0]

theorem envBound59800 : H12AffineFastState.Bounded env59800 := by
  intro p hp
  have h : env59800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59799_59800 : H12AffineEnvironment.transform 7 252 env59799 = env59800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59799 == env59800) = true)

theorem identity59800 : scanCanonicalize (H12AffineFastState.compose env59800 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59800 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59801 : List Nat := [2,4,8,16,32,64,128,252,1,140,136,137,241,217,216,171,1,64,141,216,1,248,64,83,121,17,201,216,81,136,172,32,252,32,1,0]

theorem envBound59801 : H12AffineFastState.Bounded env59801 := by
  intro p hp
  have h : env59801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59800_59801 : H12AffineEnvironment.transform 9 140 env59800 = env59801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59800 == env59801) = true)

theorem identity59801 : scanCanonicalize (H12AffineFastState.compose env59801 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound59801 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59802 : List Nat := [2,4,8,16,32,64,121,5,1,117,113,112,8,32,33,82,1,64,116,33,1,1,64,83,121,17,48,33,81,113,85,32,5,32,1,0]

theorem envBound59802 : H12AffineFastState.Bounded env59802 := by
  intro p hp
  have h : env59802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59801_59802 : H12AffineEnvironment.transform 6 121 env59801 = env59802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env59801 == env59802) = true)

theorem identity59802 : scanCanonicalize (H12AffineFastState.compose env59802 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59802 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59803 : List Nat := [2,4,0,16,32,64,113,5,1,117,113,112,0,32,33,82,1,64,116,33,1,1,64,83,113,17,48,33,81,113,85,32,5,32,1,0]

theorem envBound59803 : H12AffineFastState.Bounded env59803 := by
  intro p hp
  have h : env59803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59802_59803 : H12AffineEnvironment.transform 2 0 env59802 = env59803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59802 == env59803) = true)

theorem identity59803 : scanCanonicalize (H12AffineFastState.compose env59803 (packedSelected [1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 34) := by decide +kernel

theorem selectedBound59803 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59804 : List Nat := [2,4,0,16,32,34,19,5,1,23,19,18,0,32,33,48,1,34,22,33,1,1,34,49,19,17,48,33,51,19,55,32,5,32,1,0]

theorem envBound59804 : H12AffineFastState.Bounded env59804 := by
  intro p hp
  have h : env59804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59803_59804 : H12AffineEnvironment.transform 5 34 env59803 = env59804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 34 env59803 == env59804) = true)

theorem identity59804 : scanCanonicalize (H12AffineFastState.compose env59804 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound59804 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59805 : List Nat := [2,4,0,16,3,1,19,5,1,23,19,18,0,3,2,19,1,1,22,2,1,1,1,18,19,17,19,2,16,19,20,3,5,3,1,0]

theorem envBound59805 : H12AffineFastState.Bounded env59805 := by
  intro p hp
  have h : env59805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59804_59805 : H12AffineEnvironment.transform 4 3 env59804 = env59805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env59804 == env59805) = true)

theorem identity59805 : scanCanonicalize (H12AffineFastState.compose env59805 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59806 : List Nat := [2,4,0,3,3,1,0,5,1,4,0,1,0,3,2,0,1,1,5,2,1,1,1,1,0,2,0,2,3,0,7,3,5,3,1,0]

theorem envBound59806 : H12AffineFastState.Bounded env59806 := by
  intro p hp
  have h : env59806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59805_59806 : H12AffineEnvironment.transform 3 3 env59805 = env59806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59805 == env59806) = true)

def env59807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399767,8397000,8388689,2366325,4177,77954,67411,8463814,8465983,256,65674,78034,8389185]

theorem envBound59807 : H12AffineFastState.Bounded env59807 := by
  intro p hp
  have h : env59807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59714_59807 : H12AffineEnvironment.transform 21 1417 env59714 = env59807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59714 == env59807) = true)

def env59808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3671,1288,9617,2366325,4177,77954,67411,65542,68607,256,65674,78034,10113]

theorem envBound59808 : H12AffineFastState.Bounded env59808 := by
  intro p hp
  have h : env59808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59807_59808 : H12AffineEnvironment.transform 22 9664 env59807 = env59808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59807 == env59808) = true)

def env59809 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1288,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59809 : H12AffineFastState.Bounded env59809 := by
  intro p hp
  have h : env59809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59808_59809 : H12AffineEnvironment.transform 8 0 env59808 = env59809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59808 == env59809) = true)

theorem identity59809 : scanCanonicalize (H12AffineFastState.compose env59809 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59809 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59810 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,66734,1417,9664,3159,1288,9617,335323,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59810 : H12AffineFastState.Bounded env59810 := by
  intro p hp
  have h : env59810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59809_59810 : H12AffineEnvironment.transform 20 66734 env59809 = env59810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59809 == env59810) = true)

def env59811 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,66734,1417,64,3159,1288,17,335323,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound59811 : H12AffineFastState.Bounded env59811 := by
  intro p hp
  have h : env59811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59810_59811 : H12AffineEnvironment.transform 12 1408 env59810 = env59811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59810 == env59811) = true)

theorem identity59811 : scanCanonicalize (H12AffineFastState.compose env59811 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7506) := by decide +kernel

theorem selectedBound59811 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59812 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7506,2048,262144,1025,2129,6652,1417,64,3159,1288,17,262281,4177,2128,6145,7508,5293,256,7640,2048,1]

theorem envBound59812 : H12AffineFastState.Bounded env59812 := by
  intro p hp
  have h : env59812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59811_59812 : H12AffineEnvironment.transform 15 7506 env59811 = env59812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7506 env59811 == env59812) = true)

theorem identity59812 : scanCanonicalize (H12AffineFastState.compose env59812 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59812 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59813 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,4267,1529,262144,1025,1448,5125,1417,64,430,1288,17,262281,4177,1449,5624,4269,5293,256,4129,1529,1]

theorem envBound59813 : H12AffineFastState.Bounded env59813 := by
  intro p hp
  have h : env59813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59812_59813 : H12AffineEnvironment.transform 10 1529 env59812 = env59813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59812 == env59813) = true)

theorem identity59813 : scanCanonicalize (H12AffineFastState.compose env59813 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound59813 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59814 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1448,4267,1529,1093,1025,1448,5125,1417,64,430,1288,17,1228,4177,1449,5624,4269,5293,256,4129,1529,1]

theorem envBound59814 : H12AffineFastState.Bounded env59814 := by
  intro p hp
  have h : env59814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59813_59814 : H12AffineEnvironment.transform 17 1093 env59813 = env59814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env59813 == env59814) = true)

theorem identity59814 : scanCanonicalize (H12AffineFastState.compose env59814 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59814 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59815 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1164,1408,1244,1448,1063,1529,1093,1025,1448,137,1417,64,430,1288,17,1228,1245,1449,372,1057,33,256,1197,1529,1]

theorem envBound59815 : H12AffineFastState.Bounded env59815 := by
  intro p hp
  have h : env59815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59814_59815 : H12AffineEnvironment.transform 11 1164 env59814 = env59815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59814 == env59815) = true)

theorem identity59815 : scanCanonicalize (H12AffineFastState.compose env59815 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59815 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59816 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,1164,1148,1244,1108,1063,1029,1093,1025,1108,137,1141,64,82,1268,17,1228,1245,1109,136,1057,33,252,1197,1029,1]

theorem envBound59816 : H12AffineFastState.Bounded env59816 := by
  intro p hp
  have h : env59816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59815_59816 : H12AffineEnvironment.transform 7 252 env59815 = env59816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59815 == env59816) = true)

theorem identity59816 : scanCanonicalize (H12AffineFastState.compose env59816 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59816 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59817 : List Nat := [2,4,8,16,32,64,128,252,0,140,137,0,240,80,216,171,137,201,141,216,137,249,64,82,120,17,64,81,217,136,173,33,252,33,137,1]

theorem envBound59817 : H12AffineFastState.Bounded env59817 := by
  intro p hp
  have h : env59817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59816_59817 : H12AffineEnvironment.transform 9 140 env59816 = env59817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59816 == env59817) = true)

theorem identity59817 : scanCanonicalize (H12AffineFastState.compose env59817 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound59817 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59818 : List Nat := [2,4,8,16,32,64,25,101,0,21,16,0,105,80,65,50,16,80,20,65,16,96,64,82,120,17,64,81,64,17,52,33,101,33,16,1]

theorem envBound59818 : H12AffineFastState.Bounded env59818 := by
  intro p hp
  have h : env59818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59817_59818 : H12AffineEnvironment.transform 6 25 env59817 = env59818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env59817 == env59818) = true)

theorem identity59818 : scanCanonicalize (H12AffineFastState.compose env59818 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound59818 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59819 : List Nat := [2,4,8,16,32,49,25,20,0,21,16,0,24,33,48,50,16,33,20,48,16,17,49,35,9,17,49,32,49,17,52,33,20,33,16,1]

theorem envBound59819 : H12AffineFastState.Bounded env59819 := by
  intro p hp
  have h : env59819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59818_59819 : H12AffineEnvironment.transform 5 49 env59818 = env59819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env59818 == env59819) = true)

theorem identity59819 : scanCanonicalize (H12AffineFastState.compose env59819 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59819 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59820 : List Nat := [1,4,8,16,32,49,25,20,0,21,16,0,24,33,48,49,16,33,20,48,16,17,49,32,9,17,49,32,49,17,52,33,20,33,16,1]

theorem envBound59820 : H12AffineFastState.Bounded env59820 := by
  intro p hp
  have h : env59820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59819_59820 : H12AffineEnvironment.transform 0 1 env59819 = env59820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59819 == env59820) = true)

theorem identity59820 : scanCanonicalize (H12AffineFastState.compose env59820 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound59820 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env59821 : List Nat := [1,4,8,16,24,9,25,20,0,21,16,0,24,25,8,9,16,25,20,8,16,17,9,24,9,17,9,24,9,17,12,25,20,25,16,1]

theorem envBound59821 : H12AffineFastState.Bounded env59821 := by
  intro p hp
  have h : env59821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59820_59821 : H12AffineEnvironment.transform 4 24 env59820 = env59821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env59820 == env59821) = true)

theorem identity59821 : scanCanonicalize (H12AffineFastState.compose env59821 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59821 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59822 : List Nat := [1,4,0,16,16,1,17,20,0,21,16,0,16,17,0,1,16,17,20,0,16,17,1,16,1,17,1,16,1,17,4,17,20,17,16,1]

theorem envBound59822 : H12AffineFastState.Bounded env59822 := by
  intro p hp
  have h : env59822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59821_59822 : H12AffineEnvironment.transform 2 0 env59821 = env59822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59821 == env59822) = true)

theorem identity59822 : scanCanonicalize (H12AffineFastState.compose env59822 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59822 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59823 : List Nat := [1,4,0,0,0,1,1,4,0,5,0,0,0,1,0,1,0,1,4,0,0,1,1,0,1,1,1,0,1,1,4,1,4,1,0,1]

theorem envBound59823 : H12AffineFastState.Bounded env59823 := by
  intro p hp
  have h : env59823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59822_59823 : H12AffineEnvironment.transform 3 0 env59822 = env59823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59822 == env59823) = true)

def env59824 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,66734,1417,65,3159,1288,16,335323,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound59824 : H12AffineFastState.Bounded env59824 := by
  intro p hp
  have h : env59824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59810_59824 : H12AffineEnvironment.transform 12 1409 env59810 = env59824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59810 == env59824) = true)

theorem identity59824 : scanCanonicalize (H12AffineFastState.compose env59824 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59824 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59825 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,66734,1417,65,3159,1288,16,328079,3077,67927,66899,65542,68095,256,65674,67847,0]

theorem envBound59825 : H12AffineFastState.Bounded env59825 := by
  intro p hp
  have h : env59825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59824_59825 : H12AffineEnvironment.transform 11 3156 env59824 = env59825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59824 == env59825) = true)

theorem identity59825 : scanCanonicalize (H12AffineFastState.compose env59825 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound59825 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59826 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,65536,67847,68962,1025,2129,66734,1417,65,3159,1288,16,3309,3077,67927,66899,65542,68095,256,65674,67847,0]

theorem envBound59826 : H12AffineFastState.Bounded env59826 := by
  intro p hp
  have h : env59826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59825_59826 : H12AffineEnvironment.transform 17 68962 env59825 = env59826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env59825 == env59826) = true)

theorem identity59826 : scanCanonicalize (H12AffineFastState.compose env59826 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59826 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59827 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,2202,413,1528,1025,2129,3124,1417,65,3159,1288,16,3309,3077,461,3529,2204,357,256,2064,413,0]

theorem envBound59827 : H12AffineFastState.Bounded env59827 := by
  intro p hp
  have h : env59827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59826_59827 : H12AffineEnvironment.transform 15 2202 env59826 = env59827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59826 == env59827) = true)

theorem identity59827 : scanCanonicalize (H12AffineFastState.compose env59827 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59827 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59828 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1245,137,1409,217,1164,1095,413,1528,1025,1164,233,1417,65,138,1288,16,48,216,461,276,1089,357,256,1229,413,0]

theorem envBound59828 : H12AffineFastState.Bounded env59828 := by
  intro p hp
  have h : env59828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59827_59828 : H12AffineEnvironment.transform 10 1245 env59827 = env59828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59827 == env59828) = true)

theorem identity59828 : scanCanonicalize (H12AffineFastState.compose env59828 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59828 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59829 : List Nat := [2,4,8,16,32,64,128,256,0,425,372,137,40,217,293,494,413,81,424,293,233,32,65,138,161,16,48,216,461,276,488,357,256,356,413,0]

theorem envBound59829 : H12AffineFastState.Bounded env59829 := by
  intro p hp
  have h : env59829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59828_59829 : H12AffineEnvironment.transform 9 425 env59828 = env59829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59828 == env59829) = true)

theorem identity59829 : scanCanonicalize (H12AffineFastState.compose env59829 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59829 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59830 : List Nat := [2,4,8,16,32,64,128,69,0,236,49,137,40,217,96,171,216,81,237,96,233,32,65,138,161,16,48,216,136,81,173,32,69,33,216,0]

theorem envBound59830 : H12AffineFastState.Bounded env59830 := by
  intro p hp
  have h : env59830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59829_59830 : H12AffineEnvironment.transform 7 69 env59829 = env59830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59829 == env59830) = true)

theorem identity59830 : scanCanonicalize (H12AffineFastState.compose env59830 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound59830 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59831 : List Nat := [2,4,8,16,32,58,128,63,0,150,49,137,40,163,26,171,162,43,151,26,147,32,59,138,161,16,48,162,136,43,173,32,63,33,162,0]

theorem envBound59831 : H12AffineFastState.Bounded env59831 := by
  intro p hp
  have h : env59831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59830_59831 : H12AffineEnvironment.transform 5 58 env59830 = env59831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env59830 == env59831) = true)

def env59832 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1288,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59832 : H12AffineFastState.Bounded env59832 := by
  intro p hp
  have h : env59832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59808_59832 : H12AffineEnvironment.transform 8 1 env59808 = env59832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59808 == env59832) = true)

theorem identity59832 : scanCanonicalize (H12AffineFastState.compose env59832 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 74030) := by decide +kernel

theorem selectedBound59832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59833 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,74030,1417,9664,3158,1288,9617,342106,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59833 : H12AffineFastState.Bounded env59833 := by
  intro p hp
  have h : env59833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59832_59833 : H12AffineEnvironment.transform 20 74030 env59832 = env59833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 74030 env59832 == env59833) = true)

def env59834 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,66734,1417,64,3158,1288,17,335322,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound59834 : H12AffineFastState.Bounded env59834 := by
  intro p hp
  have h : env59834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59833_59834 : H12AffineEnvironment.transform 12 1408 env59833 = env59834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59833 == env59834) = true)

theorem identity59834 : scanCanonicalize (H12AffineFastState.compose env59834 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7507) := by decide +kernel

theorem selectedBound59834 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59835 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7507,2049,262144,1025,2128,6653,1417,64,3158,1288,17,262281,4177,2129,6145,7509,5293,256,7641,2049,0]

theorem envBound59835 : H12AffineFastState.Bounded env59835 := by
  intro p hp
  have h : env59835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59834_59835 : H12AffineEnvironment.transform 15 7507 env59834 = env59835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7507 env59834 == env59835) = true)

theorem identity59835 : scanCanonicalize (H12AffineFastState.compose env59835 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59835 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59836 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,4267,1529,262144,1025,1448,5125,1417,64,430,1288,17,262281,4177,1449,5625,4269,5293,256,4129,1529,0]

theorem envBound59836 : H12AffineFastState.Bounded env59836 := by
  intro p hp
  have h : env59836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59835_59836 : H12AffineEnvironment.transform 10 1528 env59835 = env59836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59835 == env59836) = true)

theorem identity59836 : scanCanonicalize (H12AffineFastState.compose env59836 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound59836 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59837 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1448,4267,1529,1093,1025,1448,5125,1417,64,430,1288,17,1228,4177,1449,5625,4269,5293,256,4129,1529,0]

theorem envBound59837 : H12AffineFastState.Bounded env59837 := by
  intro p hp
  have h : env59837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59836_59837 : H12AffineEnvironment.transform 17 1093 env59836 = env59837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env59836 == env59837) = true)

theorem identity59837 : scanCanonicalize (H12AffineFastState.compose env59837 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59837 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59838 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1164,1408,1244,1448,1063,1529,1093,1025,1448,137,1417,64,430,1288,17,1228,1245,1449,373,1057,33,256,1197,1529,0]

theorem envBound59838 : H12AffineFastState.Bounded env59838 := by
  intro p hp
  have h : env59838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59837_59838 : H12AffineEnvironment.transform 11 1164 env59837 = env59838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59837 == env59838) = true)

theorem identity59838 : scanCanonicalize (H12AffineFastState.compose env59838 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59838 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59839 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,1164,1149,1244,1109,1063,1028,1093,1025,1109,137,1140,64,83,1269,17,1228,1245,1108,136,1057,33,253,1197,1028,0]

theorem envBound59839 : H12AffineFastState.Bounded env59839 := by
  intro p hp
  have h : env59839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59838_59839 : H12AffineEnvironment.transform 7 253 env59838 = env59839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59838 == env59839) = true)

theorem identity59839 : scanCanonicalize (H12AffineFastState.compose env59839 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59839 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59840 : List Nat := [2,4,8,16,32,16,128,173,1,1024,1029,1164,1069,1164,1029,1063,1028,1045,1025,1029,137,1060,16,3,1189,17,1180,1165,1028,136,1057,33,173,1197,1028,0]

theorem envBound59840 : H12AffineFastState.Bounded env59840 := by
  intro p hp
  have h : env59840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59839_59840 : H12AffineEnvironment.transform 5 16 env59839 = env59840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59839 == env59840) = true)

theorem identity59840 : scanCanonicalize (H12AffineFastState.compose env59840 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 143) := by decide +kernel

theorem selectedBound59840 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59841 : List Nat := [2,4,8,16,32,16,128,173,1,143,138,3,162,3,138,168,139,154,142,138,137,171,16,3,42,17,19,2,139,136,174,33,173,34,139,0]

theorem envBound59841 : H12AffineFastState.Bounded env59841 := by
  intro p hp
  have h : env59841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59840_59841 : H12AffineEnvironment.transform 9 143 env59840 = env59841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 143 env59840 == env59841) = true)

theorem identity59841 : scanCanonicalize (H12AffineFastState.compose env59841 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59841 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59842 : List Nat := [2,4,8,16,32,16,27,54,1,20,17,3,57,3,17,51,16,1,21,17,18,48,16,3,42,17,19,2,16,19,53,33,54,34,16,0]

theorem envBound59842 : H12AffineFastState.Bounded env59842 := by
  intro p hp
  have h : env59842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59841_59842 : H12AffineEnvironment.transform 6 27 env59841 = env59842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59841 == env59842) = true)

theorem identity59842 : scanCanonicalize (H12AffineFastState.compose env59842 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59842 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env59843 : List Nat := [2,4,8,16,2,16,27,20,1,20,17,3,27,3,17,17,16,1,21,17,18,18,16,3,8,17,19,2,16,19,23,3,20,0,16,0]

theorem envBound59843 : H12AffineFastState.Bounded env59843 := by
  intro p hp
  have h : env59843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59842_59843 : H12AffineEnvironment.transform 4 2 env59842 = env59843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59842 == env59843) = true)

theorem identity59843 : scanCanonicalize (H12AffineFastState.compose env59843 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59843 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59844 : List Nat := [2,4,2,16,2,16,17,20,1,20,17,3,17,3,17,17,16,1,21,17,18,18,16,3,2,17,19,2,16,19,23,3,20,0,16,0]

theorem envBound59844 : H12AffineFastState.Bounded env59844 := by
  intro p hp
  have h : env59844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59843_59844 : H12AffineEnvironment.transform 2 2 env59843 = env59844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59843 == env59844) = true)

def env59845 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,66735,1417,65,3158,1288,16,335323,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound59845 : H12AffineFastState.Bounded env59845 := by
  intro p hp
  have h : env59845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59833_59845 : H12AffineEnvironment.transform 12 1409 env59833 = env59845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59833 == env59845) = true)

theorem identity59845 : scanCanonicalize (H12AffineFastState.compose env59845 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59845 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59846 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,66735,1417,65,3158,1288,16,328079,3077,67927,66898,65542,68094,256,65674,67847,1]

theorem envBound59846 : H12AffineFastState.Bounded env59846 := by
  intro p hp
  have h : env59846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59845_59846 : H12AffineEnvironment.transform 11 3156 env59845 = env59846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59845 == env59846) = true)

theorem identity59846 : scanCanonicalize (H12AffineFastState.compose env59846 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound59846 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59847 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,65536,67847,68962,1025,2128,66735,1417,65,3158,1288,16,3309,3077,67927,66898,65542,68094,256,65674,67847,1]

theorem envBound59847 : H12AffineFastState.Bounded env59847 := by
  intro p hp
  have h : env59847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59846_59847 : H12AffineEnvironment.transform 17 68962 env59846 = env59847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env59846 == env59847) = true)

theorem identity59847 : scanCanonicalize (H12AffineFastState.compose env59847 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59847 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59848 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,2203,412,1529,1025,2128,3124,1417,65,3158,1288,16,3309,3077,460,3529,2205,357,256,2065,412,1]

theorem envBound59848 : H12AffineFastState.Bounded env59848 := by
  intro p hp
  have h : env59848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59847_59848 : H12AffineEnvironment.transform 15 2203 env59847 = env59848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59847 == env59848) = true)

theorem identity59848 : scanCanonicalize (H12AffineFastState.compose env59848 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1432) := by decide +kernel

theorem selectedBound59848 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59849 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1432,460,1409,412,1480,1283,412,1529,1025,1480,428,1417,65,462,1288,16,373,413,460,81,1285,357,256,1417,412,1]

theorem envBound59849 : H12AffineFastState.Bounded env59849 := by
  intro p hp
  have h : env59849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59848_59849 : H12AffineEnvironment.transform 10 1432 env59848 = env59849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1432 env59848 == env59849) = true)

theorem identity59849 : scanCanonicalize (H12AffineFastState.compose env59849 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59849 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59850 : List Nat := [2,4,8,16,32,64,114,256,1,1024,1386,318,1395,366,1338,1283,366,1291,1025,1338,350,1403,65,316,1288,16,373,367,318,81,1285,357,256,1403,366,1]

theorem envBound59850 : H12AffineFastState.Bounded env59850 := by
  intro p hp
  have h : env59850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59849_59850 : H12AffineEnvironment.transform 6 114 env59849 = env59850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59849 == env59850) = true)

theorem identity59850 : scanCanonicalize (H12AffineFastState.compose env59850 (packedSelected [0,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59850 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env59851 : List Nat := [2,4,8,16,32,64,114,68,1,1024,1070,122,1079,42,1150,1095,42,1103,1025,1150,26,1087,65,120,1100,16,49,43,122,81,1089,33,68,1087,42,1]

theorem envBound59851 : H12AffineFastState.Bounded env59851 := by
  intro p hp
  have h : env59851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59850_59851 : H12AffineEnvironment.transform 7 68 env59850 = env59851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59850 == env59851) = true)

theorem identity59851 : scanCanonicalize (H12AffineFastState.compose env59851 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound59851 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59852 : List Nat := [2,4,8,16,32,64,114,68,1,31,49,122,40,42,97,88,42,80,30,97,26,32,65,120,83,16,49,43,122,81,94,33,68,32,42,1]

theorem envBound59852 : H12AffineFastState.Bounded env59852 := by
  intro p hp
  have h : env59852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59851_59852 : H12AffineEnvironment.transform 9 31 env59851 = env59852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env59851 == env59852) = true)

def env59853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3670,1289,9616,2366325,4177,77954,67411,65543,68606,256,65674,78034,10112]

theorem envBound59853 : H12AffineFastState.Bounded env59853 := by
  intro p hp
  have h : env59853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59807_59853 : H12AffineEnvironment.transform 22 9665 env59807 = env59853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59807 == env59853) = true)

def env59854 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3158,1289,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound59854 : H12AffineFastState.Bounded env59854 := by
  intro p hp
  have h : env59854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59853_59854 : H12AffineEnvironment.transform 8 0 env59853 = env59854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59853 == env59854) = true)

theorem identity59854 : scanCanonicalize (H12AffineFastState.compose env59854 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 14718) := by decide +kernel

theorem selectedBound59854 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59855 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,14718,2476,262144,1025,2129,2097152,1417,9665,3158,1289,9616,2365813,4177,2556,15405,14713,12416,256,14836,2476,9600]

theorem envBound59855 : H12AffineFastState.Bounded env59855 := by
  intro p hp
  have h : env59855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59854_59855 : H12AffineEnvironment.transform 15 14718 env59854 = env59855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14718 env59854 == env59855) = true)

def env59856 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,2097152,1417,65,3158,1289,16,2365813,4177,2556,6573,7417,5376,256,7284,2476,0]

theorem envBound59856 : H12AffineFastState.Bounded env59856 := by
  intro p hp
  have h : env59856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59855_59856 : H12AffineEnvironment.transform 12 1408 env59855 = env59856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59855 == env59856) = true)

theorem identity59856 : scanCanonicalize (H12AffineFastState.compose env59856 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59856 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59857 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,1029,1417,65,3158,1289,16,269680,4177,2556,6573,7417,5376,256,7284,2476,0]

theorem envBound59857 : H12AffineFastState.Bounded env59857 := by
  intro p hp
  have h : env59857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59856_59857 : H12AffineEnvironment.transform 20 1029 env59856 = env59857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1029 env59856 == env59857) = true)

theorem identity59857 : scanCanonicalize (H12AffineFastState.compose env59857 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound59857 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59858 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7422,2476,3528,1025,2129,1029,1417,65,3158,1289,16,4280,4177,2556,6573,7417,5376,256,7284,2476,0]

theorem envBound59858 : H12AffineFastState.Bounded env59858 := by
  intro p hp
  have h : env59858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59857_59858 : H12AffineEnvironment.transform 17 3528 env59857 = env59858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env59857 == env59858) = true)

theorem identity59858 : scanCanonicalize (H12AffineFastState.compose env59858 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59858 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59859 : List Nat := [2,4,8,16,32,64,128,256,0,1024,49,4096,1408,4176,96,5327,413,1529,1025,96,1029,1417,65,1127,1289,16,4280,4177,461,4508,5320,5376,256,5189,413,0]

theorem envBound59859 : H12AffineFastState.Bounded env59859 := by
  intro p hp
  have h : env59859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59858_59859 : H12AffineEnvironment.transform 10 49 env59858 = env59859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59858 == env59859) = true)

theorem identity59859 : scanCanonicalize (H12AffineFastState.compose env59859 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound59859 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59860 : List Nat := [2,4,8,16,32,64,128,256,0,1024,49,1312,1408,1392,96,495,413,1529,1025,96,1029,1417,65,1127,1289,16,1432,1393,461,1212,488,32,256,357,413,0]

theorem envBound59860 : H12AffineFastState.Bounded env59860 := by
  intro p hp
  have h : env59860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59859_59860 : H12AffineEnvironment.transform 11 1312 env59859 = env59860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env59859 == env59860) = true)

theorem identity59860 : scanCanonicalize (H12AffineFastState.compose env59860 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59860 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59861 : List Nat := [2,4,8,16,32,64,128,256,0,237,49,461,365,413,96,495,413,276,236,96,232,356,65,138,484,16,373,412,461,81,488,32,256,357,413,0]

theorem envBound59861 : H12AffineFastState.Bounded env59861 := by
  intro p hp
  have h : env59861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59860_59861 : H12AffineEnvironment.transform 9 237 env59860 = env59861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59860 == env59861) = true)

theorem identity59861 : scanCanonicalize (H12AffineFastState.compose env59861 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59861 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59862 : List Nat := [2,4,8,16,32,64,128,182,0,237,49,123,219,43,96,89,43,162,236,96,232,210,65,138,82,16,195,42,123,81,94,32,182,211,43,0]

theorem envBound59862 : H12AffineFastState.Bounded env59862 := by
  intro p hp
  have h : env59862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59861_59862 : H12AffineEnvironment.transform 7 182 env59861 = env59862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59861 == env59862) = true)

theorem identity59862 : scanCanonicalize (H12AffineFastState.compose env59862 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59862 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59863 : List Nat := [2,4,8,16,32,64,114,68,0,31,49,123,41,43,96,89,43,80,30,96,26,32,65,120,82,16,49,42,123,81,94,32,68,33,43,0]

theorem envBound59863 : H12AffineFastState.Bounded env59863 := by
  intro p hp
  have h : env59863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59862_59863 : H12AffineEnvironment.transform 6 114 env59862 = env59863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59862 == env59863) = true)

def env59864 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7423,2476,262144,1025,2129,2097152,1417,64,3158,1289,17,2365813,4177,2556,6572,7416,5377,256,7285,2476,1]

theorem envBound59864 : H12AffineFastState.Bounded env59864 := by
  intro p hp
  have h : env59864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59855_59864 : H12AffineEnvironment.transform 12 1409 env59855 = env59864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59855 == env59864) = true)

theorem identity59864 : scanCanonicalize (H12AffineFastState.compose env59864 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59864 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59865 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7423,2476,262144,1025,2129,6652,1417,64,3158,1289,17,262281,4177,2556,6572,7416,5377,256,7285,2476,1]

theorem envBound59865 : H12AffineFastState.Bounded env59865 := by
  intro p hp
  have h : env59865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59864_59865 : H12AffineEnvironment.transform 20 6652 env59864 = env59865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59864 == env59865) = true)

theorem identity59865 : scanCanonicalize (H12AffineFastState.compose env59865 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59865 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59866 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,4358,1109,262144,1025,1448,5125,1417,64,431,1289,17,262281,4177,1029,5205,4353,5377,256,4492,1109,1]

theorem envBound59866 : H12AffineFastState.Bounded env59866 := by
  intro p hp
  have h : env59866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59865_59866 : H12AffineEnvironment.transform 10 1529 env59865 = env59866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59865 == env59866) = true)

theorem identity59866 : scanCanonicalize (H12AffineFastState.compose env59866 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound59866 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59867 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1448,4358,1109,1513,1025,1448,5125,1417,64,431,1289,17,1376,4177,1029,5205,4353,5377,256,4492,1109,1]

theorem envBound59867 : H12AffineFastState.Bounded env59867 := by
  intro p hp
  have h : env59867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59866_59867 : H12AffineEnvironment.transform 17 1513 env59866 = env59867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env59866 == env59867) = true)

theorem identity59867 : scanCanonicalize (H12AffineFastState.compose env59867 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound59867 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59868 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1313,1409,1393,1448,1063,1109,1513,1025,1448,292,1417,64,431,1289,17,1376,1392,1029,372,1056,32,256,1197,1109,1]

theorem envBound59868 : H12AffineFastState.Bounded env59868 := by
  intro p hp
  have h : env59868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59867_59868 : H12AffineEnvironment.transform 11 1313 env59867 = env59868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env59867 == env59868) = true)

theorem identity59868 : scanCanonicalize (H12AffineFastState.compose env59868 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59868 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59869 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,1244,1148,1164,1109,1063,1109,1044,1025,1109,217,1140,64,82,1268,17,1181,1165,1029,137,1056,32,253,1197,1109,1]

theorem envBound59869 : H12AffineFastState.Bounded env59869 := by
  intro p hp
  have h : env59869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59868_59869 : H12AffineEnvironment.transform 7 253 env59868 = env59869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59868 == env59869) = true)

theorem identity59869 : scanCanonicalize (H12AffineFastState.compose env59869 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59869 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59870 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1028,1164,1068,1164,1029,1063,1029,1044,1025,1029,137,1060,16,2,1188,17,1181,1165,1029,137,1056,32,173,1197,1029,1]

theorem envBound59870 : H12AffineFastState.Bounded env59870 := by
  intro p hp
  have h : env59870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59869_59870 : H12AffineEnvironment.transform 5 16 env59869 = env59870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59869 == env59870) = true)

theorem identity59870 : scanCanonicalize (H12AffineFastState.compose env59870 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound59870 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59871 : List Nat := [2,4,8,16,32,16,128,173,0,6,2,138,42,138,3,33,3,18,7,3,137,34,16,2,162,17,155,139,3,137,38,32,173,171,3,1]

theorem envBound59871 : H12AffineFastState.Bounded env59871 := by
  intro p hp
  have h : env59871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59870_59871 : H12AffineEnvironment.transform 9 6 env59870 = env59871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env59870 == env59871) = true)

theorem identity59871 : scanCanonicalize (H12AffineFastState.compose env59871 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59871 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59872 : List Nat := [2,4,8,3,32,3,128,173,0,6,2,138,42,138,3,33,3,1,7,3,137,34,3,2,162,2,136,139,3,137,38,32,173,171,3,1]

theorem envBound59872 : H12AffineFastState.Bounded env59872 := by
  intro p hp
  have h : env59872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59871_59872 : H12AffineEnvironment.transform 3 3 env59871 = env59872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59871 == env59872) = true)

theorem identity59872 : scanCanonicalize (H12AffineFastState.compose env59872 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound59872 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env59873 : List Nat := [2,4,8,3,32,3,40,5,0,6,2,34,42,34,3,33,3,1,7,3,33,34,3,2,10,2,32,35,3,33,38,32,5,3,3,1]

theorem envBound59873 : H12AffineFastState.Bounded env59873 := by
  intro p hp
  have h : env59873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59872_59873 : H12AffineEnvironment.transform 6 40 env59872 = env59873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env59872 == env59873) = true)

theorem identity59873 : scanCanonicalize (H12AffineFastState.compose env59873 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59873 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59874 : List Nat := [2,4,8,3,11,3,3,5,0,6,2,9,1,9,3,10,3,1,7,3,10,9,3,2,10,2,11,8,3,10,13,11,5,3,3,1]

theorem envBound59874 : H12AffineFastState.Bounded env59874 := by
  intro p hp
  have h : env59874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59873_59874 : H12AffineEnvironment.transform 4 11 env59873 = env59874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59873 == env59874) = true)

theorem identity59874 : scanCanonicalize (H12AffineFastState.compose env59874 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59874 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59875 : List Nat := [2,4,1,3,2,3,3,5,0,6,2,0,1,0,3,3,3,1,7,3,3,0,3,2,3,2,2,1,3,3,4,2,5,3,3,1]

theorem envBound59875 : H12AffineFastState.Bounded env59875 := by
  intro p hp
  have h : env59875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59874_59875 : H12AffineEnvironment.transform 2 1 env59874 = env59875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59874 == env59875) = true)

def env59876 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound59876 : H12AffineFastState.Bounded env59876 := by
  intro p hp
  have h : env59876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59853_59876 : H12AffineEnvironment.transform 8 1 env59853 = env59876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59853 == env59876) = true)

theorem identity59876 : scanCanonicalize (H12AffineFastState.compose env59876 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59876 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59877 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,7422,11308,262144,1025,2128,2097152,1417,9665,3159,1289,9616,2365812,4177,11388,6572,7417,5377,256,7284,11308,9601]

end H12CloudChart0