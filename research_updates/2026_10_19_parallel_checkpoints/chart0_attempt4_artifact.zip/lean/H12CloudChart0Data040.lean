import H12CloudChart0Data039

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans9969_9970 : H12AffineEnvironment.transform 23 2 env9969 = env9970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env9969 == env9970) = true)

theorem identity9970 : scanCanonicalize (H12AffineFastState.compose env9970 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound9970 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env9971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,4160,62589,119878,2,8192,64,108555,103494,102742,23668,20565,98679,256,32,57612,96011]

theorem envBound9971 : H12AffineFastState.Bounded env9971 := by
  intro p hp
  have h : env9971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9970_9971 : H12AffineEnvironment.transform 16 90138 env9970 = env9971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env9970 == env9971) = true)

theorem identity9971 : scanCanonicalize (H12AffineFastState.compose env9971 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound9971 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env9972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90138,10280,1024,1,4160,29821,87110,2,8192,64,75787,70726,69974,23668,20565,65911,256,32,24844,96011]

theorem envBound9972 : H12AffineFastState.Bounded env9972 := by
  intro p hp
  have h : env9972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9971_9972 : H12AffineEnvironment.transform 14 0 env9971 = env9972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env9971 == env9972) = true)

theorem identity9972 : scanCanonicalize (H12AffineFastState.compose env9972 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound9972 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env9973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,16400,10280,1024,1,4160,29821,29772,2,8192,64,2049,13388,12636,23668,20565,8573,256,32,24844,22273]

theorem envBound9973 : H12AffineFastState.Bounded env9973 := by
  intro p hp
  have h : env9973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9972_9973 : H12AffineEnvironment.transform 15 8202 env9972 = env9973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env9972 == env9973) = true)

theorem identity9973 : scanCanonicalize (H12AffineFastState.compose env9973 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound9973 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env9974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,0,8202,5440,10280,1024,1,4160,8493,8476,2,8192,64,2049,13388,12636,2340,1285,8573,256,32,13404,593]

theorem envBound9974 : H12AffineFastState.Bounded env9974 := by
  intro p hp
  have h : env9974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9973_9974 : H12AffineEnvironment.transform 13 5456 env9973 = env9974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env9973 == env9974) = true)

theorem identity9974 : scanCanonicalize (H12AffineFastState.compose env9974 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9974 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env9975 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5237,0,8202,5221,10280,1024,1,4160,8200,8249,2,8192,64,2049,13388,12409,2049,1056,8280,37,32,13404,593]

theorem envBound9975 : H12AffineFastState.Bounded env9975 := by
  intro p hp
  have h : env9975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9974_9975 : H12AffineEnvironment.transform 7 37 env9974 = env9975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9974 == env9975) = true)

theorem identity9975 : scanCanonicalize (H12AffineFastState.compose env9975 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound9975 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env9976 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5237,0,115,5221,2129,1024,1,4160,113,64,2,121,64,2049,5173,4096,2049,1056,33,37,32,5157,593]

theorem envBound9976 : H12AffineFastState.Bounded env9976 := by
  intro p hp
  have h : env9976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9975_9976 : H12AffineEnvironment.transform 12 121 env9975 = env9976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env9975 == env9976) = true)

theorem identity9976 : scanCanonicalize (H12AffineFastState.compose env9976 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9976 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9977 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,4096,8,5124,0,2,5140,2080,1024,1,4145,0,49,2,8,49,2049,5173,4096,2049,1056,33,37,32,5157,544]

theorem envBound9977 : H12AffineFastState.Bounded env9977 := by
  intro p hp
  have h : env9977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9976_9977 : H12AffineEnvironment.transform 5 49 env9976 = env9977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9976 == env9977) = true)

theorem identity9977 : scanCanonicalize (H12AffineFastState.compose env9977 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9977 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env9978 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,8,5124,0,2,5140,2049,1024,1,4112,0,16,2,8,16,2049,5140,4096,2049,1025,0,4,1,5124,513]

theorem envBound9978 : H12AffineFastState.Bounded env9978 := by
  intro p hp
  have h : env9978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9977_9978 : H12AffineEnvironment.transform 4 1 env9977 = env9978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9977 == env9978) = true)

theorem identity9978 : scanCanonicalize (H12AffineFastState.compose env9978 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound9978 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9979 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,4096,8,4112,0,2,4096,2049,20,1,4112,0,16,2,8,16,2049,4096,4096,2049,21,0,4,1,4112,513]

theorem envBound9979 : H12AffineFastState.Bounded env9979 := by
  intro p hp
  have h : env9979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9978_9979 : H12AffineEnvironment.transform 9 20 env9978 = env9979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env9978 == env9979) = true)

theorem identity9979 : scanCanonicalize (H12AffineFastState.compose env9979 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound9979 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9980 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,17,8,1,0,2,17,2049,20,1,1,0,16,2,8,16,2049,17,17,2049,21,0,4,1,1,513]

theorem envBound9980 : H12AffineFastState.Bounded env9980 := by
  intro p hp
  have h : env9980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9979_9980 : H12AffineEnvironment.transform 11 17 env9979 = env9980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9979 == env9980) = true)

def env9981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62588,119879,16777216,8193,64,16959506,16880709,102743,212078,16797782,16875893,256,16777250,16834831,16873225]

theorem envBound9981 : H12AffineFastState.Bounded env9981 := by
  intro p hp
  have h : env9981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9968_9981 : H12AffineEnvironment.transform 6 9 env9968 = env9981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9968 == env9981) = true)

theorem identity9981 : scanCanonicalize (H12AffineFastState.compose env9981 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound9981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62588,119879,41311,8193,64,158029,79130,102743,212078,61705,73770,256,41341,16464,120406]

theorem envBound9982 : H12AffineFastState.Bounded env9982 := by
  intro p hp
  have h : env9982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9981_9982 : H12AffineEnvironment.transform 23 41311 env9981 = env9982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env9981 == env9982) = true)

theorem identity9982 : scanCanonicalize (H12AffineFastState.compose env9982 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound9982 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env9983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46157,10281,1024,32769,4160,62588,119879,41311,8193,64,56576,79130,102743,100387,61705,73770,256,41341,16464,120406]

theorem envBound9983 : H12AffineFastState.Bounded env9983 := by
  intro p hp
  have h : env9983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9982_9983 : H12AffineEnvironment.transform 16 46157 env9982 = env9983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env9982 == env9983) = true)

theorem identity9983 : scanCanonicalize (H12AffineFastState.compose env9983 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound9983 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,65536,4096,10281,1024,9292,4160,20529,94218,1298,8193,64,31053,79130,79130,76910,21828,73770,256,1328,16464,94747]

theorem envBound9984 : H12AffineFastState.Bounded env9984 := by
  intro p hp
  have h : env9984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9983_9984 : H12AffineEnvironment.transform 14 9293 env9983 = env9984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env9983 == env9984) = true)

theorem identity9984 : scanCanonicalize (H12AffineFastState.compose env9984 (packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound9984 : packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env9985 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8541,65536,4096,10281,272,8540,4160,20529,94218,2,8193,64,31053,77834,77834,76158,20564,73770,256,32,16464,94747]

theorem envBound9985 : H12AffineFastState.Bounded env9985 := by
  intro p hp
  have h : env9985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9984_9985 : H12AffineEnvironment.transform 9 272 env9984 = env9985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env9984 == env9985) = true)

theorem identity9985 : scanCanonicalize (H12AffineFastState.compose env9985 (packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound9985 : packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env9986 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8541,115,4096,10281,272,8540,4160,20529,28793,2,8193,64,31053,12409,12409,10509,20564,8281,256,32,16464,29288]

theorem envBound9986 : H12AffineFastState.Bounded env9986 := by
  intro p hp
  have h : env9986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9985_9986 : H12AffineEnvironment.transform 15 115 env9985 = env9986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env9985 == env9986) = true)

theorem identity9986 : scanCanonicalize (H12AffineFastState.compose env9986 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound9986 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env9987 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4452,8541,115,4096,10281,272,8540,4160,341,8477,2,8193,64,10281,12409,12409,10509,304,8281,256,32,4404,8972]

theorem envBound9987 : H12AffineFastState.Bounded env9987 := by
  intro p hp
  have h : env9987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9986_9987 : H12AffineEnvironment.transform 13 4452 env9986 = env9987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env9986 == env9987) = true)

theorem identity9987 : scanCanonicalize (H12AffineFastState.compose env9987 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound9987 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env9988 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,269,4452,80,115,4096,2340,272,81,4160,341,16,2,268,64,2340,4468,4468,2048,304,340,256,32,4404,513]

theorem envBound9988 : H12AffineFastState.Bounded env9988 := by
  intro p hp
  have h : env9988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9987_9988 : H12AffineEnvironment.transform 12 269 env9987 = env9988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env9987 == env9988) = true)

theorem identity9988 : scanCanonicalize (H12AffineFastState.compose env9988 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 625) := by decide +kernel

theorem selectedBound9988 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env9989 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,625,269,789,80,115,625,2340,272,81,561,341,16,2,268,64,2340,773,773,2048,304,340,256,32,837,513]

theorem envBound9989 : H12AffineFastState.Bounded env9989 := by
  intro p hp
  have h : env9989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9988_9989 : H12AffineEnvironment.transform 11 625 env9988 = env9989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 625 env9988 == env9989) = true)

theorem identity9989 : scanCanonicalize (H12AffineFastState.compose env9989 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9989 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env9990 : List Nat := [2,4,8,16,32,48,9,256,512,272,2048,513,269,789,32,3,513,2340,272,33,561,293,16,2,268,48,2340,773,773,2048,304,292,256,32,821,513]

theorem envBound9990 : H12AffineFastState.Bounded env9990 := by
  intro p hp
  have h : env9990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9989_9990 : H12AffineEnvironment.transform 5 48 env9989 = env9990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9989 == env9990) = true)

theorem identity9990 : scanCanonicalize (H12AffineFastState.compose env9990 (packedSelected [0,3,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound9990 : packedSelected [0,3,4,11] rootPS < 2^1333 := by decide +kernel

def env9991 : List Nat := [2,4,8,16,32,48,9,256,512,272,33,513,269,789,32,3,513,261,272,33,561,293,16,2,268,48,261,773,773,33,304,292,256,32,821,513]

theorem envBound9991 : H12AffineFastState.Bounded env9991 := by
  intro p hp
  have h : env9991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9990_9991 : H12AffineEnvironment.transform 10 33 env9990 = env9991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env9990 == env9991) = true)

theorem identity9991 : scanCanonicalize (H12AffineFastState.compose env9991 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound9991 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env9992 : List Nat := [2,4,8,16,32,48,9,256,16,272,33,17,269,261,32,3,17,261,272,33,33,293,16,2,268,48,261,277,277,33,304,292,256,32,293,17]

theorem envBound9992 : H12AffineFastState.Bounded env9992 := by
  intro p hp
  have h : env9992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9991_9992 : H12AffineEnvironment.transform 8 16 env9991 = env9992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env9991 == env9992) = true)

theorem identity9992 : scanCanonicalize (H12AffineFastState.compose env9992 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9992 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env9993 : List Nat := [2,4,8,16,32,48,9,36,16,52,33,17,41,33,32,3,17,33,52,33,33,1,16,2,40,48,33,49,49,33,20,0,36,32,1,17]

theorem envBound9993 : H12AffineFastState.Bounded env9993 := by
  intro p hp
  have h : env9993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9992_9993 : H12AffineEnvironment.transform 7 36 env9992 = env9993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9992 == env9993) = true)

theorem identity9993 : scanCanonicalize (H12AffineFastState.compose env9993 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9994 : List Nat := [2,4,8,16,17,1,9,21,16,5,16,17,24,16,17,3,17,16,5,16,16,1,16,2,25,1,16,0,0,16,20,0,21,17,1,17]

theorem envBound9994 : H12AffineFastState.Bounded env9994 := by
  intro p hp
  have h : env9994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9993_9994 : H12AffineEnvironment.transform 4 17 env9993 = env9994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9993 == env9994) = true)

theorem identity9994 : scanCanonicalize (H12AffineFastState.compose env9994 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9995 : List Nat := [2,4,8,1,0,1,9,4,1,5,1,0,9,1,0,3,0,1,5,1,1,1,1,2,8,1,1,0,0,1,5,0,4,0,1,0]

theorem envBound9995 : H12AffineFastState.Bounded env9995 := by
  intro p hp
  have h : env9995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9994_9995 : H12AffineEnvironment.transform 3 1 env9994 = env9995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9994 == env9995) = true)

def env9996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4160,62708,120014,16777216,8328,64,16959643,16880844,102878,212079,16797919,16875892,256,16777250,16834950,16873225]

theorem envBound9996 : H12AffineFastState.Bounded env9996 := by
  intro p hp
  have h : env9996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9967_9996 : H12AffineEnvironment.transform 17 10401 env9967 = env9996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env9967 == env9996) = true)

def env9997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62588,119878,16777216,8192,64,16959507,16880708,102742,212079,16797783,16875892,256,16777250,16834830,16873225]

theorem envBound9997 : H12AffineFastState.Bounded env9997 := by
  intro p hp
  have h : env9997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9996_9997 : H12AffineEnvironment.transform 6 8 env9996 = env9997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9996 == env9997) = true)

theorem identity9997 : scanCanonicalize (H12AffineFastState.compose env9997 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 119892) := by decide +kernel

theorem selectedBound9997 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62588,119878,119892,8192,64,203847,16400,102742,212079,99331,21792,256,119926,79194,41821]

theorem envBound9998 : H12AffineFastState.Bounded env9998 := by
  intro p hp
  have h : env9998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9997_9998 : H12AffineEnvironment.transform 23 119892 env9997 = env9998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119892 env9997 == env9998) = true)

theorem identity9998 : scanCanonicalize (H12AffineFastState.compose env9998 (packedSelected [1,3,4,5,7,8,9,10,14,16,19,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound9998 : packedSelected [1,3,4,5,7,8,9,10,14,16,19,20,27,35] rootPS < 2^1333 := by decide +kernel

def env9999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,4160,62588,119878,119892,8192,64,31837,16400,102742,23669,99331,21792,256,119926,79194,41821]

theorem envBound9999 : H12AffineFastState.Bounded env9999 := by
  intro p hp
  have h : env9999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9998_9999 : H12AffineEnvironment.transform 16 90138 env9998 = env9999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env9998 == env9999) = true)

theorem identity9999 : scanCanonicalize (H12AffineFastState.compose env9999 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound9999 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79131,10281,1024,32769,4160,41341,98631,98645,8192,64,10588,5393,102742,2420,99331,33,256,98679,79194,41821]

theorem envBound10000 : H12AffineFastState.Bounded env10000 := by
  intro p hp
  have h : env10000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9999_10000 : H12AffineEnvironment.transform 13 5377 env9999 = env10000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env9999 == env10000) = true)

theorem identity10000 : scanCanonicalize (H12AffineFastState.compose env10000 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10000 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env10001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,10281,1024,8541,4160,33,73755,73737,8192,64,10588,5393,77834,2420,75103,33,256,73771,79194,513]

theorem envBound10001 : H12AffineFastState.Bounded env10001 := by
  intro p hp
  have h : env10001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10000_10001 : H12AffineEnvironment.transform 14 8540 env10000 = env10001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10000 == env10001) = true)

theorem identity10001 : scanCanonicalize (H12AffineFastState.compose env10001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound10001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9499,4096,10281,1024,8541,4160,33,1280,1298,8192,64,10588,5393,5393,2420,68,33,256,1328,4161,513]

theorem envBound10002 : H12AffineFastState.Bounded env10002 := by
  intro p hp
  have h : env10002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10001_10002 : H12AffineEnvironment.transform 15 9499 env10001 = env10002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env10001 == env10002) = true)

theorem identity10002 : scanCanonicalize (H12AffineFastState.compose env10002 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound10002 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env10003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,8192,2340,8540,9499,3109,10281,1024,8541,3173,33,1280,1298,8192,64,10588,2356,2356,2420,68,33,256,1328,3172,513]

theorem envBound10003 : H12AffineFastState.Bounded env10003 := by
  intro p hp
  have h : env10003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10002_10003 : H12AffineEnvironment.transform 11 3109 env10002 = env10003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env10002 == env10003) = true)

theorem identity10003 : scanCanonicalize (H12AffineFastState.compose env10003 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10003 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10004 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,8192,2340,8540,8203,2357,10281,272,8541,2421,33,16,2,8192,64,10588,2356,2356,2420,68,33,256,32,2420,513]

theorem envBound10004 : H12AffineFastState.Bounded env10004 := by
  intro p hp
  have h : env10004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10003_10004 : H12AffineEnvironment.transform 9 272 env10003 = env10004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10003 == env10004) = true)

theorem identity10004 : scanCanonicalize (H12AffineFastState.compose env10004 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 364) := by decide +kernel

theorem selectedBound10004 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10005 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,364,2340,48,359,2357,2373,272,49,2421,33,16,2,364,64,2096,2356,2356,2420,68,33,256,32,2420,513]

theorem envBound10005 : H12AffineFastState.Bounded env10005 := by
  intro p hp
  have h : env10005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10004_10005 : H12AffineEnvironment.transform 12 364 env10004 = env10005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 364 env10004 == env10005) = true)

theorem identity10005 : scanCanonicalize (H12AffineFastState.compose env10005 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10005 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env10006 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,2357,317,2340,48,310,2357,2324,272,49,2340,33,16,2,317,17,2096,2356,2356,2341,21,33,256,32,2341,513]

theorem envBound10006 : H12AffineFastState.Bounded env10006 := by
  intro p hp
  have h : env10006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10005_10006 : H12AffineEnvironment.transform 5 17 env10005 = env10006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10005 == env10006) = true)

theorem identity10006 : scanCanonicalize (H12AffineFastState.compose env10006 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound10006 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10007 : List Nat := [2,4,8,16,32,17,8,256,512,272,561,772,317,789,48,310,772,805,272,49,789,33,16,2,317,17,513,773,773,788,21,33,256,32,788,513]

theorem envBound10007 : H12AffineFastState.Bounded env10007 := by
  intro p hp
  have h : env10007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10006_10007 : H12AffineEnvironment.transform 10 561 env10006 = env10007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env10006 == env10007) = true)

theorem identity10007 : scanCanonicalize (H12AffineFastState.compose env10007 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound10007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10008 : List Nat := [2,4,8,16,32,17,8,256,32,272,17,292,317,309,48,310,292,261,272,49,309,33,16,2,317,17,33,293,293,308,21,33,256,32,308,33]

theorem envBound10008 : H12AffineFastState.Bounded env10008 := by
  intro p hp
  have h : env10008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10007_10008 : H12AffineEnvironment.transform 8 32 env10007 = env10008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env10007 == env10008) = true)

theorem identity10008 : scanCanonicalize (H12AffineFastState.compose env10008 (packedSelected [1,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound10008 : packedSelected [1,5,9] rootPS < 2^1333 := by decide +kernel

def env10009 : List Nat := [2,4,8,16,32,17,8,52,32,36,17,16,9,1,48,2,16,49,36,49,1,33,16,2,9,17,33,17,17,0,21,33,52,32,0,33]

theorem envBound10009 : H12AffineFastState.Bounded env10009 := by
  intro p hp
  have h : env10009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10008_10009 : H12AffineEnvironment.transform 7 52 env10008 = env10009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env10008 == env10009) = true)

theorem identity10009 : scanCanonicalize (H12AffineFastState.compose env10009 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10010 : List Nat := [2,4,8,0,32,1,8,36,32,36,1,0,9,1,32,2,0,33,36,33,1,33,0,2,9,1,33,1,1,0,5,33,36,32,0,33]

theorem envBound10010 : H12AffineFastState.Bounded env10010 := by
  intro p hp
  have h : env10010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10009_10010 : H12AffineEnvironment.transform 3 0 env10009 = env10010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10009 == env10010) = true)

theorem identity10010 : scanCanonicalize (H12AffineFastState.compose env10010 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10010 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10011 : List Nat := [2,4,8,0,1,1,8,5,1,5,1,0,9,1,1,2,0,0,5,0,1,0,0,2,9,1,0,1,1,0,5,0,5,1,0,0]

theorem envBound10011 : H12AffineFastState.Bounded env10011 := by
  intro p hp
  have h : env10011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10010_10011 : H12AffineEnvironment.transform 4 1 env10010 = env10011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10010 == env10011) = true)

def env10012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119879,16777216,8193,64,16959506,16880709,102743,212079,16797782,16875892,256,16777250,16834831,16873225]

theorem envBound10012 : H12AffineFastState.Bounded env10012 := by
  intro p hp
  have h : env10012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9996_10012 : H12AffineEnvironment.transform 6 9 env9996 = env10012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9996 == env10012) = true)

theorem identity10012 : scanCanonicalize (H12AffineFastState.compose env10012 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound10012 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119879,95496,8193,64,245018,57677,102743,212079,75102,62588,256,95530,103431,513]

theorem envBound10013 : H12AffineFastState.Bounded env10013 := by
  intro p hp
  have h : env10013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10012_10013 : H12AffineEnvironment.transform 23 95496 env10012 = env10013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env10012 == env10013) = true)

theorem identity10013 : scanCanonicalize (H12AffineFastState.compose env10013 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound10013 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env10014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,4160,62589,119879,95496,8193,64,89174,57677,102743,122147,75102,62588,256,95530,103431,513]

theorem envBound10014 : H12AffineFastState.Bounded env10014 := by
  intro p hp
  have h : env10014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10013_10014 : H12AffineEnvironment.transform 16 57676 env10013 = env10014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env10013 == env10014) = true)

theorem identity10014 : scanCanonicalize (H12AffineFastState.compose env10014 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound10014 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env10015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62810,57676,10280,1024,32769,4160,62589,8477,32850,8193,64,43276,57677,25613,10361,53252,62588,256,32880,24925,513]

theorem envBound10015 : H12AffineFastState.Bounded env10015 := by
  intro p hp
  have h : env10015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10014_10015 : H12AffineEnvironment.transform 15 62810 env10014 = env10015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env10014 == env10015) = true)

theorem identity10015 : scanCanonicalize (H12AffineFastState.compose env10015 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound10015 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env10016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,342,5440,10280,1024,29709,4160,113,8477,29790,8193,64,23808,5441,25613,10361,9224,112,256,29820,24925,513]

theorem envBound10016 : H12AffineFastState.Bounded env10016 := by
  intro p hp
  have h : env10016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10015_10016 : H12AffineEnvironment.transform 14 29708 env10015 = env10016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env10015 == env10016) = true)

theorem identity10016 : scanCanonicalize (H12AffineFastState.compose env10016 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10016 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21760,342,5440,2340,1024,21761,4160,113,17,21842,269,64,23808,5441,17665,2421,1284,112,256,21872,16465,513]

theorem envBound10017 : H12AffineFastState.Bounded env10017 := by
  intro p hp
  have h : env10017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10016_10017 : H12AffineEnvironment.transform 12 268 env10016 = env10017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10016 == env10017) = true)

def env10018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318548,120015,16777216,8328,64,16959643,16880845,102878,464079,16797918,17148373,256,16777250,16834950,16873224]

theorem envBound10018 : H12AffineFastState.Bounded env10018 := by
  intro p hp
  have h : env10018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9966_10018 : H12AffineEnvironment.transform 20 4161 env9966 = env10018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env9966 == env10018) = true)

theorem identity10018 : scanCanonicalize (H12AffineFastState.compose env10018 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound10018 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318548,120015,95497,8328,64,245138,57796,102878,464079,75223,318684,256,95531,103567,513]

theorem envBound10019 : H12AffineFastState.Bounded env10019 := by
  intro p hp
  have h : env10019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10018_10019 : H12AffineEnvironment.transform 23 95497 env10018 = env10019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env10018 == env10019) = true)

def env10020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318548,119879,95497,8192,64,245018,57676,102742,463943,75103,318548,256,95531,103431,513]

theorem envBound10020 : H12AffineFastState.Bounded env10020 := by
  intro p hp
  have h : env10020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10019_10020 : H12AffineEnvironment.transform 6 8 env10019 = env10020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10019 == env10020) = true)

theorem identity10020 : scanCanonicalize (H12AffineFastState.compose env10020 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10020 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,4161,318548,119879,95497,8192,64,56576,57676,102742,291933,75103,318548,256,95531,103431,513]

theorem envBound10021 : H12AffineFastState.Bounded env10021 := by
  intro p hp
  have h : env10021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10020_10021 : H12AffineEnvironment.transform 16 90138 env10020 = env10021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10020 == env10021) = true)

def env10022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,4161,62588,119879,95497,8192,64,56576,57676,102742,23669,75103,62588,256,95531,103431,513]

theorem envBound10022 : H12AffineFastState.Bounded env10022 := by
  intro p hp
  have h : env10022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10021_10022 : H12AffineEnvironment.transform 17 10280 env10021 = env10022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10021 == env10022) = true)

theorem identity10022 : scanCanonicalize (H12AffineFastState.compose env10022 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound10022 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46157,10280,1024,32769,4161,62588,16,41310,8192,64,56576,57676,17665,23669,61704,62588,256,41340,16464,513]

theorem envBound10023 : H12AffineFastState.Bounded env10023 := by
  intro p hp
  have h : env10023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10022_10023 : H12AffineEnvironment.transform 15 54359 env10022 = env10023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env10022 == env10023) = true)

theorem identity10023 : scanCanonicalize (H12AffineFastState.compose env10023 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound10023 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7285,32768,34850,46157,10280,1024,32769,4161,43017,16,41310,8192,64,33141,48441,6516,0,44413,43017,256,41340,7205,513]

theorem envBound10024 : H12AffineFastState.Bounded env10024 := by
  intro p hp
  have h : env10024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10023_10024 : H12AffineEnvironment.transform 13 7285 env10023 = env10024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env10023 == env10024) = true)

theorem identity10024 : scanCanonicalize (H12AffineFastState.compose env10024 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10024 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7285,8540,10622,5393,10280,1024,8541,4161,2389,16,2,8192,64,8233,7269,6516,0,3105,2389,256,32,7205,513]

theorem envBound10025 : H12AffineFastState.Bounded env10025 := by
  intro p hp
  have h : env10025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10024_10025 : H12AffineEnvironment.transform 14 8540 env10024 = env10025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10024 == env10025) = true)

theorem identity10025 : scanCanonicalize (H12AffineFastState.compose env10025 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound10025 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,4112,8540,9499,5393,9293,1024,8541,4161,1328,16,2,8192,64,8233,4096,5393,0,68,1328,256,32,4160,513]

theorem envBound10026 : H12AffineFastState.Bounded env10026 := by
  intro p hp
  have h : env10026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10025_10026 : H12AffineEnvironment.transform 10 1125 env10025 = env10026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env10025 == env10026) = true)

theorem identity10026 : scanCanonicalize (H12AffineFastState.compose env10026 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10026 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env10027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,121,4112,293,1378,5393,1076,1024,292,4161,1328,16,2,121,64,80,4096,5393,0,68,1328,256,32,4160,513]

theorem envBound10027 : H12AffineFastState.Bounded env10027 := by
  intro p hp
  have h : env10027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10026_10027 : H12AffineEnvironment.transform 12 121 env10026 = env10027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10026 == env10027) = true)

theorem identity10027 : scanCanonicalize (H12AffineFastState.compose env10027 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound10027 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env10028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,96,121,112,293,1378,1393,1076,1024,292,33,1328,16,2,121,64,80,96,1393,0,68,1328,256,32,32,513]

theorem envBound10028 : H12AffineFastState.Bounded env10028 := by
  intro p hp
  have h : env10028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10027_10028 : H12AffineEnvironment.transform 11 96 env10027 = env10028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env10027 == env10028) = true)

theorem identity10028 : scanCanonicalize (H12AffineFastState.compose env10028 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10028 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env10029 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1125,96,121,112,0,1095,1108,1076,1024,1,33,1045,16,2,121,64,80,96,1108,0,68,1045,37,32,32,513]

theorem envBound10029 : H12AffineFastState.Bounded env10029 := by
  intro p hp
  have h : env10029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10028_10029 : H12AffineEnvironment.transform 7 37 env10028 = env10029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10028 == env10029) = true)

theorem identity10029 : scanCanonicalize (H12AffineFastState.compose env10029 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10029 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env10030 : List Nat := [2,4,8,16,17,64,8,20,512,1024,1108,81,72,65,0,1095,1108,1029,1024,1,16,1045,16,2,72,64,80,81,1108,0,68,1045,20,17,17,513]

theorem envBound10030 : H12AffineFastState.Bounded env10030 := by
  intro p hp
  have h : env10030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10029_10030 : H12AffineEnvironment.transform 4 17 env10029 = env10030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10029 == env10030) = true)

theorem identity10030 : scanCanonicalize (H12AffineFastState.compose env10030 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound10030 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env10031 : List Nat := [2,4,8,16,17,64,8,20,512,85,1,81,72,65,0,18,1,80,85,1,16,64,16,2,72,64,80,81,1,0,68,64,20,17,17,513]

theorem envBound10031 : H12AffineFastState.Bounded env10031 := by
  intro p hp
  have h : env10031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10030_10031 : H12AffineEnvironment.transform 9 85 env10030 = env10031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env10030 == env10031) = true)

theorem identity10031 : scanCanonicalize (H12AffineFastState.compose env10031 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10031 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10032 : List Nat := [2,4,8,1,0,64,8,5,512,68,1,64,72,65,0,3,1,65,68,1,1,64,1,2,72,64,65,64,1,0,68,64,5,0,0,513]

theorem envBound10032 : H12AffineFastState.Bounded env10032 := by
  intro p hp
  have h : env10032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10031_10032 : H12AffineEnvironment.transform 3 1 env10031 = env10032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10031 == env10032) = true)

theorem identity10032 : scanCanonicalize (H12AffineFastState.compose env10032 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound10032 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10033 : List Nat := [2,4,8,1,0,1,8,5,512,5,1,1,9,0,0,3,1,0,5,1,1,1,1,2,9,1,0,1,1,0,5,1,5,0,0,513]

theorem envBound10033 : H12AffineFastState.Bounded env10033 := by
  intro p hp
  have h : env10033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10032_10033 : H12AffineEnvironment.transform 5 1 env10032 = env10033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env10032 == env10033) = true)

theorem identity10033 : scanCanonicalize (H12AffineFastState.compose env10033 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10034 : List Nat := [2,4,8,1,0,1,8,5,0,5,1,1,9,0,0,3,1,0,5,1,1,1,1,2,9,1,0,1,1,0,5,1,5,0,0,1]

theorem envBound10034 : H12AffineFastState.Bounded env10034 := by
  intro p hp
  have h : env10034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10033_10034 : H12AffineEnvironment.transform 8 0 env10033 = env10034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10033 == env10034) = true)

def env10035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,4161,62589,119879,95497,8192,64,56576,57676,102742,23668,75103,62589,256,95531,103431,513]

theorem envBound10035 : H12AffineFastState.Bounded env10035 := by
  intro p hp
  have h : env10035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10021_10035 : H12AffineEnvironment.transform 17 10281 env10021 = env10035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10021 == env10035) = true)

theorem identity10035 : scanCanonicalize (H12AffineFastState.compose env10035 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound10035 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,4161,62589,42077,1299,8192,64,56576,57676,57676,23668,21829,62589,256,1329,58397,513]

theorem envBound10036 : H12AffineFastState.Bounded env10036 := by
  intro p hp
  have h : env10036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10035_10036 : H12AffineEnvironment.transform 15 28698 env10035 = env10036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env10035 == env10036) = true)

theorem identity10036 : scanCanonicalize (H12AffineFastState.compose env10036 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10036 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10281,1024,8541,4161,21793,1281,1299,8192,64,31836,16400,16400,23668,21829,21793,256,1329,17729,513]

theorem envBound10037 : H12AffineFastState.Bounded env10037 := by
  intro p hp
  have h : env10037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10036_10037 : H12AffineEnvironment.transform 14 8540 env10036 = env10037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10036 == env10037) = true)

theorem identity10037 : scanCanonicalize (H12AffineFastState.compose env10037 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 11292) := by decide +kernel

theorem selectedBound10037 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env10038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,11292,8540,7174,4096,10281,1024,8541,4161,14653,1281,1299,8192,64,4160,11276,11276,12392,14681,14653,256,1329,10589,513]

theorem envBound10038 : H12AffineFastState.Bounded env10038 := by
  intro p hp
  have h : env10038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10037_10038 : H12AffineEnvironment.transform 13 11292 env10037 = env10038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11292 env10037 == env10038) = true)

theorem identity10038 : scanCanonicalize (H12AffineFastState.compose env10038 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound10038 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env10039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6428,5376,6208,7174,4096,4405,1024,6209,4161,33,1281,1299,6428,64,4160,5392,5392,2420,69,33,256,1329,4161,513]

theorem envBound10039 : H12AffineFastState.Bounded env10039 := by
  intro p hp
  have h : env10039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10038_10039 : H12AffineEnvironment.transform 12 6428 env10038 = env10039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env10038 == env10039) = true)

theorem identity10039 : scanCanonicalize (H12AffineFastState.compose env10039 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound10039 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env10040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1337,2341,1125,35,3109,3344,1024,1124,3172,33,1281,1299,1337,64,3173,2357,2357,2420,69,33,256,1329,3172,513]

theorem envBound10040 : H12AffineFastState.Bounded env10040 := by
  intro p hp
  have h : env10040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10039_10040 : H12AffineEnvironment.transform 11 3109 env10039 = env10040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env10039 == env10040) = true)

theorem identity10040 : scanCanonicalize (H12AffineFastState.compose env10040 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10040 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env10041 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2064,268,2341,80,35,2064,2341,53,81,2129,33,308,294,268,64,2128,2357,2357,2420,69,33,256,260,2129,513]

theorem envBound10041 : H12AffineFastState.Bounded env10041 := by
  intro p hp
  have h : env10041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10040_10041 : H12AffineEnvironment.transform 9 53 env10040 = env10041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10040 == env10041) = true)

theorem identity10041 : scanCanonicalize (H12AffineFastState.compose env10041 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 884) := by decide +kernel

theorem selectedBound10041 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10042 : List Nat := [2,4,8,16,32,64,8,256,512,53,884,868,268,593,80,35,868,593,53,81,805,33,308,294,268,64,804,577,577,512,69,33,256,260,805,513]

theorem envBound10042 : H12AffineFastState.Bounded env10042 := by
  intro p hp
  have h : env10042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10041_10042 : H12AffineEnvironment.transform 10 884 env10041 = env10042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 884 env10041 == env10042) = true)

theorem identity10042 : scanCanonicalize (H12AffineFastState.compose env10042 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10042 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10043 : List Nat := [2,4,8,16,32,17,8,256,512,53,805,821,268,512,1,35,821,512,53,0,805,33,308,294,268,17,804,528,528,512,20,33,256,260,805,513]

theorem envBound10043 : H12AffineFastState.Bounded env10043 := by
  intro p hp
  have h : env10043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10042_10043 : H12AffineEnvironment.transform 5 17 env10042 = env10043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10042 == env10043) = true)

theorem identity10043 : scanCanonicalize (H12AffineFastState.compose env10043 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound10043 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env10044 : List Nat := [2,4,8,16,32,17,8,256,308,53,17,1,268,308,1,35,1,308,53,0,17,33,308,294,268,17,16,292,292,308,20,33,256,260,17,309]

theorem envBound10044 : H12AffineFastState.Bounded env10044 := by
  intro p hp
  have h : env10044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10043_10044 : H12AffineEnvironment.transform 8 308 env10043 = env10044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env10043 == env10044) = true)

theorem identity10044 : scanCanonicalize (H12AffineFastState.compose env10044 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10044 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10045 : List Nat := [2,4,8,0,32,1,8,256,292,37,1,1,268,292,1,35,1,292,37,0,1,33,292,294,268,1,0,292,292,292,4,33,256,260,1,293]

theorem envBound10045 : H12AffineFastState.Bounded env10045 := by
  intro p hp
  have h : env10045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10044_10045 : H12AffineEnvironment.transform 3 0 env10044 = env10045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10044 == env10045) = true)

theorem identity10045 : scanCanonicalize (H12AffineFastState.compose env10045 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10045 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10046 : List Nat := [2,4,8,0,32,1,8,36,0,37,1,1,40,0,1,35,1,0,37,0,1,33,0,2,40,1,0,0,0,0,4,33,36,32,1,1]

theorem envBound10046 : H12AffineFastState.Bounded env10046 := by
  intro p hp
  have h : env10046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10045_10046 : H12AffineEnvironment.transform 7 36 env10045 = env10046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10045 == env10046) = true)

theorem identity10046 : scanCanonicalize (H12AffineFastState.compose env10046 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10047 : List Nat := [2,4,8,0,1,1,8,5,0,4,1,1,9,0,1,2,1,0,4,0,1,0,0,2,9,1,0,0,0,0,4,0,5,1,1,1]

theorem envBound10047 : H12AffineFastState.Bounded env10047 := by
  intro p hp
  have h : env10047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10046_10047 : H12AffineEnvironment.transform 4 1 env10046 = env10047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10046 == env10047) = true)

def env10048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318548,119878,95497,8193,64,245019,57677,102743,463942,75102,318549,256,95531,103430,513]

theorem envBound10048 : H12AffineFastState.Bounded env10048 := by
  intro p hp
  have h : env10048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10019_10048 : H12AffineEnvironment.transform 6 9 env10019 = env10048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10019 == env10048) = true)

def env10049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119878,95497,8193,64,245019,57677,102743,212078,75102,62589,256,95531,103430,513]

theorem envBound10049 : H12AffineFastState.Bounded env10049 := by
  intro p hp
  have h : env10049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10048_10049 : H12AffineEnvironment.transform 17 10280 env10048 = env10049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10048 == env10049) = true)

theorem identity10049 : scanCanonicalize (H12AffineFastState.compose env10049 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound10049 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env10050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,4161,62588,119878,95497,8193,64,89175,57677,102743,122146,75102,62589,256,95531,103430,513]

theorem envBound10050 : H12AffineFastState.Bounded env10050 := by
  intro p hp
  have h : env10050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10049_10050 : H12AffineEnvironment.transform 16 57676 env10049 = env10050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env10049 == env10050) = true)

theorem identity10050 : scanCanonicalize (H12AffineFastState.compose env10050 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound10050 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env10051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62811,57676,10280,1024,32769,4161,62588,8477,32850,8193,64,43276,57677,25612,10361,53253,62589,256,32880,24925,513]

theorem envBound10051 : H12AffineFastState.Bounded env10051 := by
  intro p hp
  have h : env10051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10050_10051 : H12AffineEnvironment.transform 15 62811 env10050 = env10051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env10050 == env10051) = true)

theorem identity10051 : scanCanonicalize (H12AffineFastState.compose env10051 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound10051 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env10052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,342,5441,10280,1024,29708,4161,113,8477,29791,8193,64,23809,5440,25612,10361,9224,112,256,29821,24925,513]

theorem envBound10052 : H12AffineFastState.Bounded env10052 := by
  intro p hp
  have h : env10052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10051_10052 : H12AffineEnvironment.transform 14 29709 env10051 = env10052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env10051 == env10052) = true)

theorem identity10052 : scanCanonicalize (H12AffineFastState.compose env10052 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10052 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21761,342,5441,2340,1024,21760,4161,113,17,21843,269,64,23809,5440,17664,2421,1284,112,256,21873,16465,513]

theorem envBound10053 : H12AffineFastState.Bounded env10053 := by
  intro p hp
  have h : env10053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10052_10053 : H12AffineEnvironment.transform 12 268 env10052 = env10053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10052 == env10053) = true)

def env10054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62589,119878,95497,8193,64,245019,57677,102743,212079,75102,62588,256,95531,103430,513]

theorem envBound10054 : H12AffineFastState.Bounded env10054 := by
  intro p hp
  have h : env10054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10048_10054 : H12AffineEnvironment.transform 17 10281 env10048 = env10054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10048 == env10054) = true)

theorem identity10054 : scanCanonicalize (H12AffineFastState.compose env10054 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound10054 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4161,62589,16,41311,8193,64,158029,57677,17665,190521,61704,62588,256,41341,16464,513]

theorem envBound10055 : H12AffineFastState.Bounded env10055 := by
  intro p hp
  have h : env10055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10054_10055 : H12AffineEnvironment.transform 15 54358 env10054 = env10055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env10054 == env10055) = true)

theorem identity10055 : scanCanonicalize (H12AffineFastState.compose env10055 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound10055 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46156,10281,1024,32769,4161,62589,16,41311,8193,64,56577,57677,17665,23669,61704,62588,256,41341,16464,513]

theorem envBound10056 : H12AffineFastState.Bounded env10056 := by
  intro p hp
  have h : env10056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10055_10056 : H12AffineEnvironment.transform 16 46156 env10055 = env10056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env10055 == env10056) = true)

theorem identity10056 : scanCanonicalize (H12AffineFastState.compose env10056 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound10056 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28698,4096,10281,1024,9293,4161,20529,16,1299,8193,64,31053,17665,17665,23669,21828,20528,256,1329,16464,513]

theorem envBound10057 : H12AffineFastState.Bounded env10057 := by
  intro p hp
  have h : env10057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10056_10057 : H12AffineEnvironment.transform 14 9292 env10056 = env10057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env10056 == env10057) = true)

theorem identity10057 : scanCanonicalize (H12AffineFastState.compose env10057 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5213) := by decide +kernel

theorem selectedBound10057 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5213,16384,4113,17479,4096,7284,1024,4112,4161,20529,16,1299,5212,64,19728,17665,17665,23669,21828,20528,256,1329,16464,513]

theorem envBound10058 : H12AffineFastState.Bounded env10058 := by
  intro p hp
  have h : env10058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10057_10058 : H12AffineEnvironment.transform 12 5213 env10057 = env10058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5213 env10057 == env10058) = true)

theorem identity10058 : scanCanonicalize (H12AffineFastState.compose env10058 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound10058 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env10059 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,4152,16384,4113,16418,4096,6161,101,4112,4161,20529,16,374,4153,64,18805,16740,16740,22544,20769,20528,256,340,16464,513]

theorem envBound10059 : H12AffineFastState.Bounded env10059 := by
  intro p hp
  have h : env10059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10058_10059 : H12AffineEnvironment.transform 9 101 env10058 = env10059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env10058 == env10059) = true)

theorem identity10059 : scanCanonicalize (H12AffineFastState.compose env10059 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound10059 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10060 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,4152,4144,4113,4114,4096,6161,101,4112,4161,1,16,374,4153,64,6469,4436,4436,2080,273,0,256,340,4192,513]

theorem envBound10060 : H12AffineFastState.Bounded env10060 := by
  intro p hp
  have h : env10060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10059_10060 : H12AffineEnvironment.transform 13 4144 env10059 = env10060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env10059 == env10060) = true)

theorem identity10060 : scanCanonicalize (H12AffineFastState.compose env10060 (packedSelected [0,3,6,7,8,11,24] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound10060 : packedSelected [0,3,6,7,8,11,24] rootPS < 2^1333 := by decide +kernel

def env10061 : List Nat := [2,4,8,16,32,64,9,256,33,101,2048,4096,4152,4144,4113,4114,4096,6161,101,4112,4161,1,16,374,4153,64,6469,4436,4436,2080,273,0,256,340,4192,32]

theorem envBound10061 : H12AffineFastState.Bounded env10061 := by
  intro p hp
  have h : env10061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10060_10061 : H12AffineEnvironment.transform 8 33 env10060 = env10061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10060 == env10061) = true)

theorem identity10061 : scanCanonicalize (H12AffineFastState.compose env10061 (packedSelected [0,1,3,7,8,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound10061 : packedSelected [0,1,3,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env10062 : List Nat := [2,4,8,16,32,64,9,256,33,101,2048,277,301,293,260,263,277,2308,101,261,340,1,16,374,300,64,2128,65,65,2080,273,0,256,340,373,32]

theorem envBound10062 : H12AffineFastState.Bounded env10062 := by
  intro p hp
  have h : env10062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10061_10062 : H12AffineEnvironment.transform 11 277 env10061 = env10062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env10061 == env10062) = true)

theorem identity10062 : scanCanonicalize (H12AffineFastState.compose env10062 (packedSelected [2,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound10062 : packedSelected [2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10063 : List Nat := [2,4,8,16,32,64,9,256,33,101,324,277,301,293,260,263,277,64,101,261,340,1,16,374,300,64,276,65,65,356,273,0,256,340,373,32]

theorem envBound10063 : H12AffineFastState.Bounded env10063 := by
  intro p hp
  have h : env10063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10062_10063 : H12AffineEnvironment.transform 10 324 env10062 = env10063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env10062 == env10063) = true)

theorem identity10063 : scanCanonicalize (H12AffineFastState.compose env10063 (packedSelected [3,4] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound10063 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env10064 : List Nat := [2,4,8,16,32,64,9,85,33,101,17,64,120,112,81,82,64,64,101,80,1,1,16,35,121,64,65,65,65,49,68,0,85,1,32,32]

theorem envBound10064 : H12AffineFastState.Bounded env10064 := by
  intro p hp
  have h : env10064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10063_10064 : H12AffineEnvironment.transform 7 85 env10063 = env10064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env10063 == env10064) = true)

theorem identity10064 : scanCanonicalize (H12AffineFastState.compose env10064 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10064 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env10065 : List Nat := [2,4,8,16,16,64,9,85,17,85,17,64,72,64,81,82,64,64,85,80,1,1,16,19,73,64,65,65,65,1,68,0,85,1,16,16]

theorem envBound10065 : H12AffineFastState.Bounded env10065 := by
  intro p hp
  have h : env10065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10064_10065 : H12AffineEnvironment.transform 4 16 env10064 = env10065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10064 == env10065) = true)

theorem identity10065 : scanCanonicalize (H12AffineFastState.compose env10065 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10065 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10066 : List Nat := [2,4,8,1,1,64,9,68,0,68,0,64,72,64,64,67,64,64,68,65,1,1,1,2,73,64,65,65,65,1,68,0,68,1,1,1]

theorem envBound10066 : H12AffineFastState.Bounded env10066 := by
  intro p hp
  have h : env10066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10065_10066 : H12AffineEnvironment.transform 3 1 env10065 = env10066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10065 == env10066) = true)

def env10067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound10067 : H12AffineFastState.Bounded env10067 := by
  intro p hp
  have h : env10067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9861_10067 : H12AffineEnvironment.transform 18 1025 env9861 = env10067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9861 == env10067) = true)

theorem identity10067 : scanCanonicalize (H12AffineFastState.compose env10067 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237454) := by decide +kernel

theorem selectedBound10067 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237454,8328,64,15066127,237699,10507600,8830977,10723359,4407758,257,8642723,8585478,10651592]

theorem envBound10068 : H12AffineFastState.Bounded env10068 := by
  intro p hp
  have h : env10068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10067_10068 : H12AffineEnvironment.transform 23 2237454 env10067 = env10068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237454 env10067 == env10068) = true)

def env10069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066127,115151,10507600,8692045,10600787,4268162,257,8487407,8478794,10544772]

theorem envBound10069 : H12AffineFastState.Bounded env10069 := by
  intro p hp
  have h : env10069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10068_10069 : H12AffineEnvironment.transform 16 24908 env10068 = env10069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env10068 == env10069) = true)

def env10070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114834,8328,16,15066127,115103,10507520,8691997,10600707,4268162,257,8487359,8478746,10544772]

theorem envBound10070 : H12AffineFastState.Bounded env10070 := by
  intro p hp
  have h : env10070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10069_10070 : H12AffineEnvironment.transform 5 16 env10069 = env10070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10069 == env10070) = true)

theorem identity10070 : scanCanonicalize (H12AffineFastState.compose env10070 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10070 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env10071 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,8388608,2114834,8328,16,14797863,115103,10507520,8423733,10600707,4268162,257,8487359,8478746,10544772]

theorem envBound10071 : H12AffineFastState.Bounded env10071 := by
  intro p hp
  have h : env10071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10070_10071 : H12AffineEnvironment.transform 17 10280 env10070 = env10071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10070 == env10071) = true)

def env10072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,8388608,2114834,8192,16,14797863,114967,10507520,8423733,10600707,4268042,257,8487223,8478746,10544652]

theorem envBound10072 : H12AffineFastState.Bounded env10072 := by
  intro p hp
  have h : env10072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10071_10072 : H12AffineEnvironment.transform 6 8 env10071 = env10072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10071 == env10072) = true)

theorem identity10072 : scanCanonicalize (H12AffineFastState.compose env10072 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 2155533) := by decide +kernel

theorem selectedBound10072 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10073 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,2155533,2114834,8192,16,4270122,114967,45325,2125112,75022,4268042,257,2188602,2196503,513]

theorem envBound10073 : H12AffineFastState.Bounded env10073 := by
  intro p hp
  have h : env10073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10072_10073 : H12AffineEnvironment.transform 22 2155533 env10072 = env10073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env10072 == env10073) = true)

theorem identity10073 : scanCanonicalize (H12AffineFastState.compose env10073 (packedSelected [2,3,4,5,6,9,10,12,15,16,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 2221371) := by decide +kernel

theorem selectedBound10073 : packedSelected [2,3,4,5,6,9,10,12,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env10074 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,2221371,2155533,2114834,8192,16,2149649,114967,45325,2125112,75022,2147633,257,2188602,2196503,513]

theorem envBound10074 : H12AffineFastState.Bounded env10074 := by
  intro p hp
  have h : env10074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10073_10074 : H12AffineEnvironment.transform 21 2221371 env10073 = env10074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2221371 env10073 == env10074) = true)

theorem identity10074 : scanCanonicalize (H12AffineFastState.compose env10074 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 124186) := by decide +kernel

theorem selectedBound10074 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10075 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,124186,33,65815,106504,8192,16,75787,114967,45325,100386,75022,73771,257,32800,24845,513]

theorem envBound10075 : H12AffineFastState.Bounded env10075 := by
  intro p hp
  have h : env10075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10074_10075 : H12AffineEnvironment.transform 20 124186 env10074 = env10075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124186 env10074 == env10075) = true)

def env10076 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,8388608,2114834,8193,16,14797863,114966,10507520,8423733,10600707,4268043,257,8487222,8478746,10544653]

theorem envBound10076 : H12AffineFastState.Bounded env10076 := by
  intro p hp
  have h : env10076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10071_10076 : H12AffineEnvironment.transform 6 9 env10071 = env10076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10071 == env10076) = true)

theorem identity10076 : scanCanonicalize (H12AffineFastState.compose env10076 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound10076 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10077 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,17681,4194304,8388608,3,8193,16,12683574,114966,8392721,8423733,8487954,4268043,257,8487222,8478746,8430364]

theorem envBound10077 : H12AffineFastState.Bounded env10077 := by
  intro p hp
  have h : env10077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10076_10077 : H12AffineEnvironment.transform 20 17681 env10076 = env10077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env10076 == env10077) = true)

theorem identity10077 : scanCanonicalize (H12AffineFastState.compose env10077 (packedSelected [0,3,4,5,10,12,14,15,20,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound10077 : packedSelected [0,3,4,5,10,12,14,15,20,22,27] rootPS < 2^1333 := by decide +kernel

def env10078 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8233,65536,24860,10280,1025,8232,17681,4194304,8388608,3,8193,16,12658975,90431,8392721,8399132,8463419,4268043,257,8462623,8478746,8389429]

theorem envBound10078 : H12AffineFastState.Bounded env10078 := by
  intro p hp
  have h : env10078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10077_10078 : H12AffineEnvironment.transform 14 8233 env10077 = env10078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env10077 == env10078) = true)

theorem identity10078 : scanCanonicalize (H12AffineFastState.compose env10078 (packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS)) = affineNative (2^(22+1) ^^^ 4194581) := by decide +kernel

theorem selectedBound10078 : packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env10079 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8233,65536,24860,10280,1025,8232,17681,4194304,4194581,3,8193,16,75786,90431,4198660,4204553,4269358,4268043,257,4268042,4284687,4194848]

theorem envBound10079 : H12AffineFastState.Bounded env10079 := by
  intro p hp
  have h : env10079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10078_10079 : H12AffineEnvironment.transform 22 4194581 env10078 = env10079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194581 env10078 == env10079) = true)

theorem identity10079 : scanCanonicalize (H12AffineFastState.compose env10079 (packedSelected [0,1,2,6,7,8,11,17,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 87299) := by decide +kernel

theorem selectedBound10079 : packedSelected [0,1,2,6,7,8,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env10080 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8233,65536,24860,10280,1025,8232,17681,87299,87062,3,8193,16,75786,90431,82951,97546,28717,29960,257,29961,13324,87843]

theorem envBound10080 : H12AffineFastState.Bounded env10080 := by
  intro p hp
  have h : env10080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10079_10080 : H12AffineEnvironment.transform 21 87299 env10079 = env10080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87299 env10079 == env10080) = true)

theorem identity10080 : scanCanonicalize (H12AffineFastState.compose env10080 (packedSelected [0,4,7,9,11,12,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound10080 : packedSelected [0,4,7,9,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env10081 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8233,28699,24860,10280,1025,8232,17681,9496,9229,3,8193,16,22545,4388,13340,3345,28717,29960,257,29961,13324,10040]

theorem envBound10081 : H12AffineFastState.Bounded env10081 := by
  intro p hp
  have h : env10081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10080_10081 : H12AffineEnvironment.transform 15 28699 env10080 = env10081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env10080 == env10081) = true)

theorem identity10081 : scanCanonicalize (H12AffineFastState.compose env10081 (packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound10081 : packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env10082 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,16384,1076,21510,17665,3125,1025,1077,17681,261,16,3,1052,16,22545,4388,4097,3345,21552,20757,257,20756,4113,805]

theorem envBound10082 : H12AffineFastState.Bounded env10082 := by
  intro p hp
  have h : env10082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10081_10082 : H12AffineEnvironment.transform 12 1053 env10081 = env10082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env10081 == env10082) = true)

theorem identity10082 : scanCanonicalize (H12AffineFastState.compose env10082 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound10082 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10083 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,4405,1076,1331,5172,3125,1025,1077,5156,261,16,3,1052,16,2340,4388,4097,3345,1285,32,257,33,4113,805]

theorem envBound10083 : H12AffineFastState.Bounded env10083 := by
  intro p hp
  have h : env10083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10082_10083 : H12AffineEnvironment.transform 13 4405 env10082 = env10083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env10082 == env10083) = true)

def env10084 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114835,8328,17,15066127,115102,10507521,8691996,10600706,4268162,257,8487358,8478747,10544772]

theorem envBound10084 : H12AffineFastState.Bounded env10084 := by
  intro p hp
  have h : env10084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10069_10084 : H12AffineEnvironment.transform 5 17 env10069 = env10084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10069 == env10084) = true)

def env10085 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2101248,2114835,8328,17,4584463,115102,17665,2404636,119042,4268162,257,2199998,2191387,63108]

theorem envBound10085 : H12AffineFastState.Bounded env10085 := by
  intro p hp
  have h : env10085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10084_10085 : H12AffineEnvironment.transform 22 2101248 env10084 = env10085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101248 env10084 == env10085) = true)

def env10086 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,121999,115102,17665,2404636,119042,329730,257,2199998,2191387,63108]

theorem envBound10086 : H12AffineFastState.Bounded env10086 := by
  intro p hp
  have h : env10086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10085_10086 : H12AffineEnvironment.transform 21 272512 env10085 = env10086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10085 == env10086) = true)

theorem identity10086 : scanCanonicalize (H12AffineFastState.compose env10086 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10086 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10087 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,24861,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,64645,57748,17665,2404636,61704,272392,257,2142644,2117649,63108]

theorem envBound10087 : H12AffineFastState.Bounded env10087 := by
  intro p hp
  have h : env10087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10086_10087 : H12AffineEnvironment.transform 15 8202 env10086 = env10087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10086 == env10087) = true)

def env10088 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16829,262144,1025,32769,2097152,264224,2101248,2114835,40,17,56357,49460,17665,2396604,53672,264360,257,2134292,2117649,54820]

theorem envBound10088 : H12AffineFastState.Bounded env10088 := by
  intro p hp
  have h : env10088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10087_10088 : H12AffineEnvironment.transform 12 160 env10087 = env10088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env10087 == env10088) = true)

theorem identity10088 : scanCanonicalize (H12AffineFastState.compose env10088 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound10088 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env10089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16829,2476,1025,32769,2097152,396,2101248,2114835,40,17,56357,49460,17665,2136080,53672,260,257,2134292,2117649,54820]

theorem envBound10089 : H12AffineFastState.Bounded env10089 := by
  intro p hp
  have h : env10089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10088_10089 : H12AffineEnvironment.transform 17 2476 env10088 = env10089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env10088 == env10089) = true)

theorem identity10089 : scanCanonicalize (H12AffineFastState.compose env10089 (packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10089 : packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env10090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,1,170,16829,2476,1025,0,2097152,396,2101248,2114835,40,17,23588,16693,17665,2103313,20905,260,257,2101525,2117649,22053]

theorem envBound10090 : H12AffineFastState.Bounded env10090 := by
  intro p hp
  have h : env10090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10089_10090 : H12AffineEnvironment.transform 14 1 env10089 = env10090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10089 == env10090) = true)

theorem identity10090 : scanCanonicalize (H12AffineFastState.compose env10090 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound10090 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env10091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,1,170,16829,2476,1025,0,17816,396,21912,139,40,17,23588,16693,17665,23945,20905,260,257,21645,5513,22053]

theorem envBound10091 : H12AffineFastState.Bounded env10091 := by
  intro p hp
  have h : env10091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10090_10091 : H12AffineEnvironment.transform 20 17816 env10090 = env10091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env10090 == env10091) = true)

theorem identity10091 : scanCanonicalize (H12AffineFastState.compose env10091 (packedSelected [0,1,2,3,5,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound10091 : packedSelected [0,1,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env10092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,1212,1,170,1281,2476,1025,0,292,396,4388,139,40,17,6296,1417,445,6453,5397,260,257,4145,5513,4761]

theorem envBound10092 : H12AffineFastState.Bounded env10092 := by
  intro p hp
  have h : env10092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10091_10092 : H12AffineEnvironment.transform 13 1212 env10091 = env10092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env10091 == env10092) = true)

theorem identity10092 : scanCanonicalize (H12AffineFastState.compose env10092 (packedSelected [0,2,3,4,5,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10092 : packedSelected [0,2,3,4,5,12,15] rootPS < 2^1333 := by decide +kernel

def env10093 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,1077,1,35,1281,2341,1025,0,292,261,4388,2,40,17,6161,1280,308,6453,5397,260,257,4145,5376,4624]

theorem envBound10093 : H12AffineFastState.Bounded env10093 := by
  intro p hp
  have h : env10093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10092_10093 : H12AffineEnvironment.transform 6 9 env10092 = env10093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10092 == env10093) = true)

theorem identity10093 : scanCanonicalize (H12AffineFastState.compose env10093 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound10093 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env10094 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,41,1077,1,35,1281,2341,1025,0,292,261,17,2,40,17,2340,1280,308,2048,1056,260,257,260,1077,805]

theorem envBound10094 : H12AffineFastState.Bounded env10094 := by
  intro p hp
  have h : env10094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10093_10094 : H12AffineEnvironment.transform 11 309 env10093 = env10094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env10093 == env10094) = true)

theorem identity10094 : scanCanonicalize (H12AffineFastState.compose env10094 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10094 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10095 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,309,41,293,1,35,17,2341,273,0,292,261,17,2,40,17,2340,16,308,2048,304,260,257,260,293,805]

theorem envBound10095 : H12AffineFastState.Bounded env10095 := by
  intro p hp
  have h : env10095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10094_10095 : H12AffineEnvironment.transform 9 272 env10094 = env10095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10094 == env10095) = true)

theorem identity10095 : scanCanonicalize (H12AffineFastState.compose env10095 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound10095 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env10096 : List Nat := [2,4,8,16,32,17,9,256,512,272,292,309,41,293,1,35,17,1,273,0,292,261,17,2,40,17,0,16,308,292,304,260,257,260,293,805]

theorem envBound10096 : H12AffineFastState.Bounded env10096 := by
  intro p hp
  have h : env10096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10095_10096 : H12AffineEnvironment.transform 10 292 env10095 = env10096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env10095 == env10096) = true)

theorem identity10096 : scanCanonicalize (H12AffineFastState.compose env10096 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10096 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10097 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,17,41,1,1,35,17,1,53,0,0,33,17,2,40,17,0,16,16,0,20,32,37,32,1,513]

theorem envBound10097 : H12AffineFastState.Bounded env10097 := by
  intro p hp
  have h : env10097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10096_10097 : H12AffineEnvironment.transform 7 36 env10096 = env10097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10096 == env10097) = true)

theorem identity10097 : scanCanonicalize (H12AffineFastState.compose env10097 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10098 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,1,1,3,17,1,21,0,0,1,17,2,8,17,0,16,16,0,20,0,5,0,1,513]

theorem envBound10098 : H12AffineFastState.Bounded env10098 := by
  intro p hp
  have h : env10098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10097_10098 : H12AffineEnvironment.transform 4 0 env10097 = env10098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10097 == env10098) = true)

theorem identity10098 : scanCanonicalize (H12AffineFastState.compose env10098 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound10098 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10099 : List Nat := [2,4,8,16,0,17,9,4,16,20,0,17,9,1,1,3,17,1,21,0,0,1,17,2,8,17,0,16,16,0,20,0,5,0,1,17]

theorem envBound10099 : H12AffineFastState.Bounded env10099 := by
  intro p hp
  have h : env10099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10098_10099 : H12AffineEnvironment.transform 8 16 env10098 = env10099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env10098 == env10099) = true)

def env10100 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16828,262144,1025,32769,2097152,264225,2101248,2114835,41,17,56356,49461,17665,2396605,53673,264361,257,2134293,2117649,54821]

theorem envBound10100 : H12AffineFastState.Bounded env10100 := by
  intro p hp
  have h : env10100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10087_10100 : H12AffineEnvironment.transform 12 161 env10087 = env10100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env10087 == env10100) = true)

theorem identity10100 : scanCanonicalize (H12AffineFastState.compose env10100 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound10100 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env10101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16828,2340,1025,32769,2097152,261,2101248,2114835,41,17,56356,49461,17665,2136217,53673,397,257,2134293,2117649,54821]

theorem envBound10101 : H12AffineFastState.Bounded env10101 := by
  intro p hp
  have h : env10101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10100_10101 : H12AffineEnvironment.transform 17 2340 env10100 = env10101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env10100 == env10101) = true)

theorem identity10101 : scanCanonicalize (H12AffineFastState.compose env10101 (packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound10101 : packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS < 2^1333 := by decide +kernel

def env10102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5157,32768,171,5529,2340,1025,32769,2097152,261,2101248,2101558,41,17,34817,38160,4388,2136217,34188,397,257,2134293,2098228,33280]

theorem envBound10102 : H12AffineFastState.Bounded env10102 := by
  intro p hp
  have h : env10102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10101_10102 : H12AffineEnvironment.transform 13 5157 env10101 = env10102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env10101 == env10102) = true)

theorem identity10102 : scanCanonicalize (H12AffineFastState.compose env10102 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound10102 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env10103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5157,136,171,5529,2340,1025,137,2097152,261,2101248,2101558,41,17,2185,5528,4388,2103313,1284,397,257,2101661,2098228,648]

theorem envBound10103 : H12AffineFastState.Bounded env10103 := by
  intro p hp
  have h : env10103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10102_10103 : H12AffineEnvironment.transform 14 136 env10102 = env10103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env10102 == env10103) = true)

theorem identity10103 : scanCanonicalize (H12AffineFastState.compose env10103 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 4540) := by decide +kernel

theorem selectedBound10103 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10104 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5157,136,171,5529,2340,1025,137,4540,261,444,138,41,17,2185,5528,4388,2477,1284,397,257,33,5512,648]

theorem envBound10104 : H12AffineFastState.Bounded env10104 := by
  intro p hp
  have h : env10104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10103_10104 : H12AffineEnvironment.transform 20 4540 env10103 = env10104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4540 env10103 == env10104) = true)

theorem identity10104 : scanCanonicalize (H12AffineFastState.compose env10104 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound10104 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10105 : List Nat := [2,4,8,16,32,17,128,256,512,1024,293,4096,161,5157,136,171,5529,1,1025,137,4540,261,444,138,41,17,428,5528,4388,136,1284,397,257,33,5512,648]

theorem envBound10105 : H12AffineFastState.Bounded env10105 := by
  intro p hp
  have h : env10105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10104_10105 : H12AffineEnvironment.transform 10 293 env10104 = env10105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env10104 == env10105) = true)

theorem identity10105 : scanCanonicalize (H12AffineFastState.compose env10105 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound10105 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env10106 : List Nat := [2,4,8,16,32,17,128,256,512,1024,293,153,161,1212,136,171,1280,1,1025,137,293,261,444,138,41,17,428,1281,445,136,1284,397,257,33,1297,648]

theorem envBound10106 : H12AffineFastState.Bounded env10106 := by
  intro p hp
  have h : env10106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10105_10106 : H12AffineEnvironment.transform 11 153 env10105 = env10106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env10105 == env10106) = true)

theorem identity10106 : scanCanonicalize (H12AffineFastState.compose env10106 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10106 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env10107 : List Nat := [2,4,8,16,32,17,128,36,512,1024,1,153,161,1212,136,171,1060,1,1025,137,1,33,152,138,41,17,136,1061,153,136,1056,169,37,33,1077,648]

theorem envBound10107 : H12AffineFastState.Bounded env10107 := by
  intro p hp
  have h : env10107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10106_10107 : H12AffineEnvironment.transform 7 36 env10106 = env10107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10106 == env10107) = true)

theorem identity10107 : scanCanonicalize (H12AffineFastState.compose env10107 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10107 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env10108 : List Nat := [2,4,8,16,1,17,128,5,512,1024,1,153,128,1181,136,138,1029,1,1025,137,1,0,152,138,8,17,136,1028,153,136,1025,136,4,0,1044,648]

theorem envBound10108 : H12AffineFastState.Bounded env10108 := by
  intro p hp
  have h : env10108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10107_10108 : H12AffineEnvironment.transform 4 1 env10107 = env10108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10107 == env10108) = true)

theorem identity10108 : scanCanonicalize (H12AffineFastState.compose env10108 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 156) := by decide +kernel

theorem selectedBound10108 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10109 : List Nat := [2,4,8,16,1,17,128,5,156,1024,1,153,128,1181,136,138,1029,1,1025,137,1,0,152,138,8,17,136,1028,153,136,1025,136,4,0,1044,20]

theorem envBound10109 : H12AffineFastState.Bounded env10109 := by
  intro p hp
  have h : env10109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10108_10109 : H12AffineEnvironment.transform 8 156 env10108 = env10109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 156 env10108 == env10109) = true)

theorem identity10109 : scanCanonicalize (H12AffineFastState.compose env10109 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound10109 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env10110 : List Nat := [2,4,8,16,1,17,128,5,156,21,1,153,128,136,136,138,16,1,20,137,1,0,152,138,8,17,136,17,153,136,20,136,4,0,1,20]

theorem envBound10110 : H12AffineFastState.Bounded env10110 := by
  intro p hp
  have h : env10110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10109_10110 : H12AffineEnvironment.transform 9 21 env10109 = env10110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env10109 == env10110) = true)

theorem identity10110 : scanCanonicalize (H12AffineFastState.compose env10110 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound10110 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10111 : List Nat := [2,4,8,16,1,17,27,5,7,21,1,2,27,19,19,17,16,1,20,18,1,0,3,17,8,17,19,17,2,19,20,19,4,0,1,20]

theorem envBound10111 : H12AffineFastState.Bounded env10111 := by
  intro p hp
  have h : env10111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10110_10111 : H12AffineEnvironment.transform 6 27 env10110 = env10111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env10110 == env10111) = true)

theorem identity10111 : scanCanonicalize (H12AffineFastState.compose env10111 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound10111 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10112 : List Nat := [2,4,8,3,1,2,8,5,7,6,1,2,8,0,0,2,3,1,7,1,1,0,3,2,8,2,0,2,2,0,7,0,4,0,1,7]

theorem envBound10112 : H12AffineFastState.Bounded env10112 := by
  intro p hp
  have h : env10112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10111_10112 : H12AffineEnvironment.transform 3 3 env10111 = env10112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env10111 == env10112) = true)

def env10113 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272513,2101248,2114835,8328,17,121998,115102,17665,2404636,119042,329731,257,2199998,2191387,63108]

theorem envBound10113 : H12AffineFastState.Bounded env10113 := by
  intro p hp
  have h : env10113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10085_10113 : H12AffineEnvironment.transform 21 272513 env10085 = env10113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10085 == env10113) = true)

theorem identity10113 : scanCanonicalize (H12AffineFastState.compose env10113 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound10113 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10114 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,77851,272513,73755,95496,8328,17,121998,115102,17665,360711,119042,329731,257,41381,16384,63108]

theorem envBound10114 : H12AffineFastState.Bounded env10114 := by
  intro p hp
  have h : env10114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10113_10114 : H12AffineEnvironment.transform 20 77851 env10113 = env10114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env10113 == env10114) = true)

def env10115 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,77851,272513,73755,95496,8328,17,121998,115102,17665,360711,119042,329731,257,41349,16384,63108]

theorem envBound10115 : H12AffineFastState.Bounded env10115 := by
  intro p hp
  have h : env10115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10114_10115 : H12AffineEnvironment.transform 4 0 env10114 = env10115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10114 == env10115) = true)

theorem identity10115 : scanCanonicalize (H12AffineFastState.compose env10115 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56460) := by decide +kernel

theorem selectedBound10115 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env10116 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,56460,1025,32769,77851,62477,73755,95496,8328,17,121998,115102,17665,89483,119042,119951,257,41349,16384,63108]

theorem envBound10116 : H12AffineFastState.Bounded env10116 := by
  intro p hp
  have h : env10116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10115_10116 : H12AffineEnvironment.transform 17 56460 env10115 = env10116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56460 env10115 == env10116) = true)

theorem identity10116 : scanCanonicalize (H12AffineFastState.compose env10116 (packedSelected [2,6,9,11,14,17,19,22,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound10116 : packedSelected [2,6,9,11,14,17,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env10117 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,29831,24861,56460,1025,32769,17564,62477,21660,399,8328,17,43017,46361,17665,10508,42373,40968,257,41349,16384,63108]

theorem envBound10117 : H12AffineFastState.Bounded env10117 := by
  intro p hp
  have h : env10117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10116_10117 : H12AffineEnvironment.transform 15 29831 env10116 = env10117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env10116 == env10117) = true)

theorem identity10117 : scanCanonicalize (H12AffineFastState.compose env10117 (packedSelected [0,2,3,4,5,7,10,11,12,14,15,16,17,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13696) := by decide +kernel

theorem selectedBound10117 : packedSelected [0,2,3,4,5,7,10,11,12,14,15,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env10118 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,13696,32768,263,5277,43276,1025,32769,12572,33165,8476,399,8328,17,43017,46361,12417,10508,42373,40968,257,41349,13696,33540]

theorem envBound10118 : H12AffineFastState.Bounded env10118 := by
  intro p hp
  have h : env10118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10117_10118 : H12AffineEnvironment.transform 13 13696 env10117 = env10118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13696 env10117 == env10118) = true)

theorem identity10118 : scanCanonicalize (H12AffineFastState.compose env10118 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound10118 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10119 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,13696,137,263,5277,10629,1025,136,12572,260,8476,399,8328,17,10368,13712,12417,10508,9484,8321,257,8460,13696,909]

theorem envBound10119 : H12AffineFastState.Bounded env10119 := by
  intro p hp
  have h : env10119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10118_10119 : H12AffineEnvironment.transform 14 137 env10118 = env10119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env10118 == env10119) = true)

theorem identity10119 : scanCanonicalize (H12AffineFastState.compose env10119 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound10119 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10120 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8,5512,137,263,5277,2445,1025,136,4372,260,276,399,128,17,2184,5528,4233,2308,1284,137,257,260,5512,909]

theorem envBound10120 : H12AffineFastState.Bounded env10120 := by
  intro p hp
  have h : env10120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10119_10120 : H12AffineEnvironment.transform 12 8 env10119 = env10120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env10119 == env10120) = true)

theorem identity10120 : scanCanonicalize (H12AffineFastState.compose env10120 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10120 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10121 : List Nat := [2,4,8,16,0,17,128,4,512,1024,2048,4096,8,5260,137,3,5277,2185,1025,136,4112,0,16,139,128,17,2184,5276,4233,2048,1024,137,5,0,5260,649]

theorem envBound10121 : H12AffineFastState.Bounded env10121 := by
  intro p hp
  have h : env10121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10120_10121 : H12AffineEnvironment.transform 7 4 env10120 = env10121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10120 == env10121) = true)

theorem identity10121 : scanCanonicalize (H12AffineFastState.compose env10121 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10121 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10122 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5125,0,3,5140,2048,1025,1,4112,0,16,2,9,17,2049,5141,4096,2048,1024,0,5,0,5125,512]

theorem envBound10122 : H12AffineFastState.Bounded env10122 := by
  intro p hp
  have h : env10122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10121_10122 : H12AffineEnvironment.transform 6 9 env10121 = env10122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10121 == env10122) = true)

theorem identity10122 : scanCanonicalize (H12AffineFastState.compose env10122 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound10122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10123 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1045,8,16,0,3,1,2048,1025,1,1029,0,16,2,9,17,2049,0,1045,2048,1024,0,5,0,16,512]

theorem envBound10123 : H12AffineFastState.Bounded env10123 := by
  intro p hp
  have h : env10123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10122_10123 : H12AffineEnvironment.transform 11 1045 env10122 = env10123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env10122 == env10123) = true)

theorem identity10123 : scanCanonicalize (H12AffineFastState.compose env10123 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound10123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10124 : List Nat := [2,4,8,16,0,17,9,4,512,1024,27,1045,8,16,0,3,1,27,1025,1,1029,0,16,2,9,17,26,0,1045,27,1024,0,5,0,16,512]

theorem envBound10124 : H12AffineFastState.Bounded env10124 := by
  intro p hp
  have h : env10124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10123_10124 : H12AffineEnvironment.transform 10 27 env10123 = env10124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env10123 == env10124) = true)

theorem identity10124 : scanCanonicalize (H12AffineFastState.compose env10124 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound10124 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10125 : List Nat := [2,4,8,16,0,17,9,4,512,30,27,11,8,16,0,3,1,27,31,1,27,0,16,2,9,17,26,0,11,27,30,0,5,0,16,512]

theorem envBound10125 : H12AffineFastState.Bounded env10125 := by
  intro p hp
  have h : env10125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10124_10125 : H12AffineEnvironment.transform 9 30 env10124 = env10125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env10124 == env10125) = true)

theorem identity10125 : scanCanonicalize (H12AffineFastState.compose env10125 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10125 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10126 : List Nat := [2,4,8,11,0,10,9,4,512,5,0,11,8,11,0,3,1,0,4,1,0,0,11,2,9,10,1,0,11,0,5,0,5,0,11,512]

theorem envBound10126 : H12AffineFastState.Bounded env10126 := by
  intro p hp
  have h : env10126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10125_10126 : H12AffineEnvironment.transform 3 11 env10125 = env10126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10125 == env10126) = true)

theorem identity10126 : scanCanonicalize (H12AffineFastState.compose env10126 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound10126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10127 : List Nat := [2,1,8,11,0,10,9,1,512,0,0,11,8,11,0,3,1,0,1,1,0,0,11,2,9,10,1,0,11,0,0,0,0,0,11,512]

theorem envBound10127 : H12AffineFastState.Bounded env10127 := by
  intro p hp
  have h : env10127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10126_10127 : H12AffineEnvironment.transform 1 1 env10126 = env10127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env10126 == env10127) = true)

def env10128 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,77851,272513,73755,95496,8328,17,121998,115102,17665,360711,119042,329731,257,41348,16384,63108]

theorem envBound10128 : H12AffineFastState.Bounded env10128 := by
  intro p hp
  have h : env10128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10114_10128 : H12AffineEnvironment.transform 4 1 env10114 = env10128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10114 == env10128) = true)

theorem identity10128 : scanCanonicalize (H12AffineFastState.compose env10128 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 10248) := by decide +kernel

theorem selectedBound10128 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env10129 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10248,1025,32769,77851,137,73755,95496,8328,17,121998,115102,17665,108815,119042,73739,257,41348,16384,63108]

theorem envBound10129 : H12AffineFastState.Bounded env10129 := by
  intro p hp
  have h : env10129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10128_10129 : H12AffineEnvironment.transform 17 10248 env10128 = env10129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10248 env10128 == env10129) = true)

theorem identity10129 : scanCanonicalize (H12AffineFastState.compose env10129 (packedSelected [0,1,3,4,5,7,8,10,17,18,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound10129 : packedSelected [0,1,3,4,5,7,8,10,17,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env10130 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,137,65536,24861,10248,1025,136,77851,137,73755,95496,8328,17,89095,82199,17665,76166,86411,73739,257,8461,16384,30221]

theorem envBound10130 : H12AffineFastState.Bounded env10130 := by
  intro p hp
  have h : env10130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10129_10130 : H12AffineEnvironment.transform 14 137 env10129 = env10130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env10129 == env10130) = true)

theorem identity10130 : scanCanonicalize (H12AffineFastState.compose env10130 (packedSelected [1,4,8,11,17,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 1424) := by decide +kernel

theorem selectedBound10130 : packedSelected [1,4,8,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10131 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,1424,16384,137,65536,17549,3480,1025,136,71051,137,66955,86168,1304,17,89095,82199,17665,68630,86411,66971,257,1181,16384,21405]

theorem envBound10131 : H12AffineFastState.Bounded env10131 := by
  intro p hp
  have h : env10131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10130_10131 : H12AffineEnvironment.transform 12 1424 env10130 = env10131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1424 env10130 == env10131) = true)

theorem identity10131 : scanCanonicalize (H12AffineFastState.compose env10131 (packedSelected [0,1,2,3,5,6,7,8,10,12,15,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound10131 : packedSelected [0,1,2,3,5,6,7,8,10,12,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env10132 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,1424,16384,137,1047,17549,3480,1025,136,4508,137,412,21647,1304,17,22544,17664,17665,2049,21916,396,257,1181,16384,21405]

theorem envBound10132 : H12AffineFastState.Bounded env10132 := by
  intro p hp
  have h : env10132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10131_10132 : H12AffineEnvironment.transform 15 1047 env10131 = env10132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env10131 == env10132) = true)

theorem identity10132 : scanCanonicalize (H12AffineFastState.compose env10132 (packedSelected [2,3,4,5,6,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5261) := by decide +kernel

theorem selectedBound10132 : packedSelected [2,3,4,5,6,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env10133 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,1424,5261,137,1047,4096,3480,1025,136,4508,137,412,2,1304,17,3229,4493,4492,2049,273,396,257,1181,5261,1808]

theorem envBound10133 : H12AffineFastState.Bounded env10133 := by
  intro p hp
  have h : env10133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10132_10133 : H12AffineEnvironment.transform 13 5261 env10132 = env10133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5261 env10132 == env10133) = true)

theorem identity10133 : scanCanonicalize (H12AffineFastState.compose env10133 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound10133 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10134 : List Nat := [2,4,8,16,1,17,128,256,512,156,2048,4096,268,4113,137,139,4096,2308,157,136,4508,137,412,2,388,17,2049,4493,4492,2049,273,396,257,1,4113,908]

theorem envBound10134 : H12AffineFastState.Bounded env10134 := by
  intro p hp
  have h : env10134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10133_10134 : H12AffineEnvironment.transform 9 156 env10133 = env10134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env10133 == env10134) = true)

theorem identity10134 : scanCanonicalize (H12AffineFastState.compose env10134 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10134 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10135 : List Nat := [2,4,8,16,1,17,128,4,512,156,2048,4096,8,4113,137,139,4096,2048,157,136,4248,137,152,2,128,17,2049,4233,4232,2049,21,136,5,1,4113,648]

theorem envBound10135 : H12AffineFastState.Bounded env10135 := by
  intro p hp
  have h : env10135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10134_10135 : H12AffineEnvironment.transform 7 4 env10134 = env10135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10134 == env10135) = true)

theorem identity10135 : scanCanonicalize (H12AffineFastState.compose env10135 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound10135 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10136 : List Nat := [2,4,8,16,1,17,128,4,512,156,131,4096,8,4113,137,139,4096,131,157,136,4248,137,152,2,128,17,130,4233,4232,130,21,136,5,1,4113,648]

theorem envBound10136 : H12AffineFastState.Bounded env10136 := by
  intro p hp
  have h : env10136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10135_10136 : H12AffineEnvironment.transform 10 131 env10135 = env10136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env10135 == env10136) = true)

theorem identity10136 : scanCanonicalize (H12AffineFastState.compose env10136 (packedSelected [1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 543) := by decide +kernel

theorem selectedBound10136 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env10137 : List Nat := [2,4,8,16,1,17,128,4,512,156,131,543,8,526,137,139,543,131,157,136,647,137,152,2,128,17,130,662,663,130,21,136,5,1,526,648]

theorem envBound10137 : H12AffineFastState.Bounded env10137 := by
  intro p hp
  have h : env10137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10136_10137 : H12AffineEnvironment.transform 11 543 env10136 = env10137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 543 env10136 == env10137) = true)

theorem identity10137 : scanCanonicalize (H12AffineFastState.compose env10137 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound10137 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10138 : List Nat := [2,4,8,16,1,17,128,4,30,156,131,1,8,16,137,139,1,131,157,136,153,137,152,2,128,17,130,136,137,130,21,136,5,1,16,150]

theorem envBound10138 : H12AffineFastState.Bounded env10138 := by
  intro p hp
  have h : env10138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10137_10138 : H12AffineEnvironment.transform 8 30 env10137 = env10138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env10137 == env10138) = true)

theorem identity10138 : scanCanonicalize (H12AffineFastState.compose env10138 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound10138 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env10139 : List Nat := [2,4,8,16,1,17,20,4,30,8,23,1,8,16,29,31,1,23,9,28,13,29,12,2,20,17,22,28,29,22,21,28,5,1,16,2]

theorem envBound10139 : H12AffineFastState.Bounded env10139 := by
  intro p hp
  have h : env10139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10138_10139 : H12AffineEnvironment.transform 6 20 env10138 = env10139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env10138 == env10139) = true)

theorem identity10139 : scanCanonicalize (H12AffineFastState.compose env10139 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound10139 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env10140 : List Nat := [2,4,8,7,1,6,3,4,9,8,0,1,8,7,10,8,1,0,9,11,13,10,12,2,3,6,1,11,10,1,2,11,5,1,7,2]

theorem envBound10140 : H12AffineFastState.Bounded env10140 := by
  intro p hp
  have h : env10140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10139_10140 : H12AffineEnvironment.transform 3 7 env10139 = env10140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env10139 == env10140) = true)

theorem identity10140 : scanCanonicalize (H12AffineFastState.compose env10140 (packedSelected [2,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound10140 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env10141 : List Nat := [2,4,5,7,1,6,3,4,4,5,0,1,5,7,7,5,1,0,4,6,0,7,1,2,3,6,1,6,7,1,2,6,5,1,7,2]

theorem envBound10141 : H12AffineFastState.Bounded env10141 := by
  intro p hp
  have h : env10141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10140_10141 : H12AffineEnvironment.transform 2 5 env10140 = env10141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env10140 == env10141) = true)

theorem identity10141 : scanCanonicalize (H12AffineFastState.compose env10141 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound10141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10142 : List Nat := [2,3,2,0,1,1,3,3,3,2,0,1,2,0,0,2,1,0,3,1,0,0,1,2,3,1,1,1,0,1,2,1,2,1,0,2]

theorem envBound10142 : H12AffineFastState.Bounded env10142 := by
  intro p hp
  have h : env10142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10141_10142 : H12AffineEnvironment.transform 1 3 env10141 = env10142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env10141 == env10142) = true)

theorem identity10142 : scanCanonicalize (H12AffineFastState.compose env10142 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10143 : List Nat := [0,1,0,0,1,1,1,1,1,0,0,1,0,0,0,0,1,0,1,1,0,0,1,0,1,1,1,1,0,1,0,1,0,1,0,0]

theorem envBound10143 : H12AffineFastState.Bounded env10143 := by
  intro p hp
  have h : env10143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10142_10143 : H12AffineEnvironment.transform 0 0 env10142 = env10143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10142 == env10143) = true)

def env10144 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2101249,2114835,8328,17,4584462,115102,17664,2404637,119043,4268162,257,2199999,2191386,63109]

theorem envBound10144 : H12AffineFastState.Bounded env10144 := by
  intro p hp
  have h : env10144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10084_10144 : H12AffineEnvironment.transform 22 2101249 env10084 = env10144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101249 env10084 == env10144) = true)

def env10145 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,121998,115102,17664,2404637,119043,329730,257,2199999,2191386,63109]

theorem envBound10145 : H12AffineFastState.Bounded env10145 := by
  intro p hp
  have h : env10145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10144_10145 : H12AffineEnvironment.transform 21 272512 env10144 = env10145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10144 == env10145) = true)

theorem identity10145 : scanCanonicalize (H12AffineFastState.compose env10145 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound10145 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10146 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,24861,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,2048,5392,17664,2404637,1421,318604,257,2114865,2139284,63109]

theorem envBound10146 : H12AffineFastState.Bounded env10146 := by
  intro p hp
  have h : env10146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10145_10146 : H12AffineEnvironment.transform 15 54414 env10145 = env10146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env10145 == env10146) = true)

theorem identity10146 : scanCanonicalize (H12AffineFastState.compose env10146 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound10146 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env10147 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24861,262144,1025,29829,2097152,272512,2101249,2114835,8328,17,2048,5392,17664,2377113,1421,272392,257,2114865,2117648,513]

theorem envBound10147 : H12AffineFastState.Bounded env10147 := by
  intro p hp
  have h : env10147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10146_10147 : H12AffineEnvironment.transform 14 29828 env10146 = env10147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env10146 == env10147) = true)

theorem identity10147 : scanCanonicalize (H12AffineFastState.compose env10147 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound10147 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env10148 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24861,262144,1025,29829,281653,272512,285748,264486,8328,17,2048,5392,17664,2476,1421,272392,257,264452,269349,513]

theorem envBound10148 : H12AffineFastState.Bounded env10148 := by
  intro p hp
  have h : env10148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10147_10148 : H12AffineEnvironment.transform 20 281653 env10147 = env10148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env10147 == env10148) = true)

theorem identity10148 : scanCanonicalize (H12AffineFastState.compose env10148 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound10148 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env10149 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24861,23725,1025,29829,4248,29741,153,21899,8328,17,2048,5392,17664,2476,1421,29861,257,21929,16520,513]

theorem envBound10149 : H12AffineFastState.Bounded env10149 := by
  intro p hp
  have h : env10149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10148_10149 : H12AffineEnvironment.transform 17 23725 env10148 = env10149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env10148 == env10149) = true)

theorem identity10149 : scanCanonicalize (H12AffineFastState.compose env10149 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound10149 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env10150 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,1,8202,5528,10280,1025,0,4248,168,153,8462,8328,17,2048,5392,12677,2476,1421,32,257,8492,13325,513]

theorem envBound10150 : H12AffineFastState.Bounded env10150 := by
  intro p hp
  have h : env10150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10149_10150 : H12AffineEnvironment.transform 13 13445 env10149 = env10150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env10149 == env10150) = true)

theorem identity10150 : scanCanonicalize (H12AffineFastState.compose env10150 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10150 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10151 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,8202,5393,10280,1025,0,4113,33,16,8462,8193,17,2048,5392,12556,2341,1284,32,257,8492,13325,513]

theorem envBound10151 : H12AffineFastState.Bounded env10151 := by
  intro p hp
  have h : env10151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10150_10151 : H12AffineEnvironment.transform 6 9 env10150 = env10151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10150 == env10151) = true)

theorem identity10151 : scanCanonicalize (H12AffineFastState.compose env10151 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10151 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10152 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1025,0,4113,33,16,2,269,17,2048,5392,4096,2341,1284,32,257,32,5377,513]

theorem envBound10152 : H12AffineFastState.Bounded env10152 := by
  intro p hp
  have h : env10152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10151_10152 : H12AffineEnvironment.transform 12 268 env10151 = env10152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10151 == env10152) = true)

theorem identity10152 : scanCanonicalize (H12AffineFastState.compose env10152 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound10152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10153 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,17,268,1297,1,262,1280,2340,1025,0,0,33,16,2,269,17,2048,1281,17,2341,1284,32,257,32,1296,513]

theorem envBound10153 : H12AffineFastState.Bounded env10153 := by
  intro p hp
  have h : env10153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10152_10153 : H12AffineEnvironment.transform 11 17 env10152 = env10153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env10152 == env10153) = true)

theorem identity10153 : scanCanonicalize (H12AffineFastState.compose env10153 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound10153 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10154 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1818,17,268,1297,1,262,1280,1598,1025,0,0,33,16,2,269,17,1818,1281,17,1599,1284,32,257,32,1296,513]

theorem envBound10154 : H12AffineFastState.Bounded env10154 := by
  intro p hp
  have h : env10154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10153_10154 : H12AffineEnvironment.transform 10 1818 env10153 = env10154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env10153 == env10154) = true)

theorem identity10154 : scanCanonicalize (H12AffineFastState.compose env10154 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound10154 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10155 : List Nat := [2,4,8,16,32,17,9,256,512,543,261,17,268,782,1,262,799,33,542,0,0,33,16,2,269,17,261,798,17,32,795,32,257,32,783,513]

theorem envBound10155 : H12AffineFastState.Bounded env10155 := by
  intro p hp
  have h : env10155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10154_10155 : H12AffineEnvironment.transform 9 543 env10154 = env10155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env10154 == env10155) = true)

theorem identity10155 : scanCanonicalize (H12AffineFastState.compose env10155 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10155 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10156 : List Nat := [2,4,8,16,1,17,9,256,512,543,261,17,268,782,1,262,799,0,542,0,0,0,16,2,269,17,261,798,17,1,795,1,257,1,783,513]

theorem envBound10156 : H12AffineFastState.Bounded env10156 := by
  intro p hp
  have h : env10156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10155_10156 : H12AffineEnvironment.transform 4 1 env10155 = env10156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10155 == env10156) = true)

def env10157 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272513,2101249,2114835,8328,17,121999,115102,17664,2404637,119043,329731,257,2199999,2191386,63109]

theorem envBound10157 : H12AffineFastState.Bounded env10157 := by
  intro p hp
  have h : env10157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10144_10157 : H12AffineEnvironment.transform 21 272513 env10144 = env10157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10144 == env10157) = true)

theorem identity10157 : scanCanonicalize (H12AffineFastState.compose env10157 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound10157 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10158 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,115870,272513,119967,98701,8328,17,121999,115102,17664,357763,119043,329731,257,21793,46212,63109]

theorem envBound10158 : H12AffineFastState.Bounded env10158 := by
  intro p hp
  have h : env10158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10157_10158 : H12AffineEnvironment.transform 20 115870 env10157 = env10158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env10157 == env10158) = true)

def env10159 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,115734,272393,119831,98565,8192,17,121863,114966,17664,357643,119043,329731,257,21793,46092,62989]

theorem envBound10159 : H12AffineFastState.Bounded env10159 := by
  intro p hp
  have h : env10159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10158_10159 : H12AffineEnvironment.transform 6 8 env10158 = env10159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10158 == env10159) = true)

theorem identity10159 : scanCanonicalize (H12AffineFastState.compose env10159 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10159 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env10160 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24861,262144,1025,8460,91419,272393,95514,73736,8192,17,97546,90139,17664,357643,94222,329731,257,21793,5377,22272]

theorem envBound10160 : H12AffineFastState.Bounded env10160 := by
  intro p hp
  have h : env10160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10159_10160 : H12AffineEnvironment.transform 14 8461 env10159 = env10160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10159 == env10160) = true)

theorem identity10160 : scanCanonicalize (H12AffineFastState.compose env10160 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound10160 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10161 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24861,67618,1025,8460,91419,73771,95514,73736,8192,17,97546,90139,17664,32041,94222,33,257,21793,5377,22272]

theorem envBound10161 : H12AffineFastState.Bounded env10161 := by
  intro p hp
  have h : env10161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10160_10161 : H12AffineEnvironment.transform 17 67618 env10160 = env10161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env10160 == env10161) = true)

theorem identity10161 : scanCanonicalize (H12AffineFastState.compose env10161 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound10161 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env10162 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,263,24861,2341,1025,8460,25628,8492,29725,8463,8192,17,31757,24860,17664,32041,28937,33,257,21793,5377,22272]

theorem envBound10162 : H12AffineFastState.Bounded env10162 := by
  intro p hp
  have h : env10162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10161_10162 : H12AffineEnvironment.transform 15 263 env10161 = env10162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env10161 == env10162) = true)

theorem identity10162 : scanCanonicalize (H12AffineFastState.compose env10162 (packedSelected [0,7,11,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10162 : packedSelected [0,7,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env10163 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,8192,16384,8461,263,24861,1077,1025,8460,25628,8492,29725,8463,8192,17,28957,24860,17664,28729,28937,33,257,21793,5377,22272]

theorem envBound10163 : H12AffineFastState.Bounded env10163 := by
  intro p hp
  have h : env10163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10162_10163 : H12AffineEnvironment.transform 10 1296 env10162 = env10163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env10162 == env10163) = true)

theorem identity10163 : scanCanonicalize (H12AffineFastState.compose env10163 (packedSelected [0,1,4,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound10163 : packedSelected [0,1,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env10164 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,1060,8192,16384,8461,263,24861,1077,1025,8460,25628,8492,24633,8463,8192,17,25913,24860,17664,25629,25901,33,257,16645,293,17188]

theorem envBound10164 : H12AffineFastState.Bounded env10164 := by
  intro p hp
  have h : env10164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10163_10164 : H12AffineEnvironment.transform 11 1060 env10163 = env10164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env10163 == env10164) = true)

theorem identity10164 : scanCanonicalize (H12AffineFastState.compose env10164 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 8233) := by decide +kernel

theorem selectedBound10164 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env10165 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,1060,8192,8233,8461,263,308,1077,1025,8460,1077,8492,16,8463,8192,17,1296,309,9513,1076,1284,33,257,8492,293,8973]

theorem envBound10165 : H12AffineFastState.Bounded env10165 := by
  intro p hp
  have h : env10165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10164_10165 : H12AffineEnvironment.transform 13 8233 env10164 = env10165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8233 env10164 == env10165) = true)

theorem identity10165 : scanCanonicalize (H12AffineFastState.compose env10165 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound10165 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10166 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,1060,1336,1297,1077,263,308,1077,1025,1076,1077,1044,16,1079,1336,17,1296,309,17,1076,1284,33,257,1044,293,1589]

theorem envBound10166 : H12AffineFastState.Bounded env10166 := by
  intro p hp
  have h : env10166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10165_10166 : H12AffineEnvironment.transform 12 1336 env10165 = env10166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env10165 == env10166) = true)

theorem identity10166 : scanCanonicalize (H12AffineFastState.compose env10166 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10166 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10167 : List Nat := [2,4,8,16,32,17,8,256,512,53,293,17,269,292,0,263,308,0,52,1,0,33,16,2,269,17,293,309,17,1,305,33,257,33,293,512]

theorem envBound10167 : H12AffineFastState.Bounded env10167 := by
  intro p hp
  have h : env10167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10166_10167 : H12AffineEnvironment.transform 9 53 env10166 = env10167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10166 == env10167) = true)

theorem identity10167 : scanCanonicalize (H12AffineFastState.compose env10167 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10168 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,17,40,1,0,34,17,0,52,1,0,33,16,2,40,17,0,16,17,1,20,33,36,33,0,512]

theorem envBound10168 : H12AffineFastState.Bounded env10168 := by
  intro p hp
  have h : env10168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10167_10168 : H12AffineEnvironment.transform 7 37 env10167 = env10168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10167 == env10168) = true)

theorem identity10168 : scanCanonicalize (H12AffineFastState.compose env10168 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound10168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10169 : List Nat := [2,1,8,16,32,17,8,32,512,48,0,17,40,1,0,34,17,0,49,1,0,33,16,2,40,17,0,16,17,1,17,33,33,33,0,512]

theorem envBound10169 : H12AffineFastState.Bounded env10169 := by
  intro p hp
  have h : env10169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10168_10169 : H12AffineEnvironment.transform 1 1 env10168 = env10169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env10168 == env10169) = true)

theorem identity10169 : scanCanonicalize (H12AffineFastState.compose env10169 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10170 : List Nat := [0,1,8,16,32,17,8,32,512,48,0,17,40,1,0,32,17,0,49,1,0,33,16,0,40,17,0,16,17,1,17,33,33,33,0,512]

theorem envBound10170 : H12AffineFastState.Bounded env10170 := by
  intro p hp
  have h : env10170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10169_10170 : H12AffineEnvironment.transform 0 0 env10169 = env10170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10169 == env10170) = true)

theorem identity10170 : scanCanonicalize (H12AffineFastState.compose env10170 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound10170 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10171 : List Nat := [0,1,8,16,32,17,8,32,40,48,0,17,40,1,0,32,17,0,49,1,0,33,16,0,40,17,0,16,17,1,17,33,33,33,0,40]

theorem envBound10171 : H12AffineFastState.Bounded env10171 := by
  intro p hp
  have h : env10171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10170_10171 : H12AffineEnvironment.transform 8 40 env10170 = env10171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env10170 == env10171) = true)

theorem identity10171 : scanCanonicalize (H12AffineFastState.compose env10171 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound10171 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10172 : List Nat := [0,1,8,16,9,17,8,9,1,25,0,17,1,1,0,9,17,0,24,1,0,8,16,0,1,17,0,16,17,1,17,8,8,8,0,1]

theorem envBound10172 : H12AffineFastState.Bounded env10172 := by
  intro p hp
  have h : env10172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10171_10172 : H12AffineEnvironment.transform 4 9 env10171 = env10172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env10171 == env10172) = true)

theorem identity10172 : scanCanonicalize (H12AffineFastState.compose env10172 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound10172 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10173 : List Nat := [0,1,8,8,9,9,8,9,1,1,0,9,1,1,0,9,9,0,0,1,0,8,8,0,1,9,0,8,9,1,9,8,8,8,0,1]

theorem envBound10173 : H12AffineFastState.Bounded env10173 := by
  intro p hp
  have h : env10173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10172_10173 : H12AffineEnvironment.transform 3 8 env10172 = env10173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env10172 == env10173) = true)

theorem identity10173 : scanCanonicalize (H12AffineFastState.compose env10173 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10173 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10174 : List Nat := [0,1,0,0,1,1,0,1,1,1,0,1,1,1,0,1,1,0,0,1,0,0,0,0,1,1,0,0,1,1,1,0,0,0,0,1]

theorem envBound10174 : H12AffineFastState.Bounded env10174 := by
  intro p hp
  have h : env10174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10173_10174 : H12AffineEnvironment.transform 2 0 env10173 = env10174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10173 == env10174) = true)

def env10175 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,115735,272392,119830,98564,8193,17,121862,114967,17664,357642,119043,329731,257,21793,46093,62988]

theorem envBound10175 : H12AffineFastState.Bounded env10175 := by
  intro p hp
  have h : env10175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10158_10175 : H12AffineEnvironment.transform 6 9 env10158 = env10175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10158 == env10175) = true)

theorem identity10175 : scanCanonicalize (H12AffineFastState.compose env10175 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 41263) := by decide +kernel

theorem selectedBound10175 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env10176 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,41263,24861,262144,1025,32769,25912,272392,30009,8235,8193,17,32041,24632,17664,316453,28716,305452,257,21793,46093,62988]

theorem envBound10176 : H12AffineFastState.Bounded env10176 := by
  intro p hp
  have h : env10176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10175_10176 : H12AffineEnvironment.transform 15 41263 env10175 = env10176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41263 env10175 == env10176) = true)

theorem identity10176 : scanCanonicalize (H12AffineFastState.compose env10176 (packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound10176 : packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env10177 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,16384,32768,33031,16693,262144,1025,32769,17680,264224,21777,3,41,17,23809,16400,17664,316453,20484,297220,257,21793,37925,54820]

theorem envBound10177 : H12AffineFastState.Bounded env10177 := by
  intro p hp
  have h : env10177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10176_10177 : H12AffineEnvironment.transform 12 40 env10176 = env10177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env10176 == env10177) = true)

theorem identity10177 : scanCanonicalize (H12AffineFastState.compose env10177 (packedSelected [1,8,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10177 : packedSelected [1,8,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10178 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,32768,33031,5173,262144,1025,32769,4112,264224,17,3,41,17,2049,5392,4096,295205,1284,297220,257,33,37925,33572]

theorem envBound10178 : H12AffineFastState.Bounded env10178 := by
  intro p hp
  have h : env10178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10177_10178 : H12AffineEnvironment.transform 13 5376 env10177 = env10178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10177 == env10178) = true)

theorem identity10178 : scanCanonicalize (H12AffineFastState.compose env10178 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10178 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10179 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,9,5376,32768,33031,5140,262144,1025,32769,4112,264193,17,3,8,17,2049,5392,4096,295172,1284,297220,257,0,37892,33541]

theorem envBound10179 : H12AffineFastState.Bounded env10179 := by
  intro p hp
  have h : env10179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10178_10179 : H12AffineEnvironment.transform 4 1 env10178 = env10179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10178 == env10179) = true)

theorem identity10179 : scanCanonicalize (H12AffineFastState.compose env10179 (packedSelected [1,8,10,12,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound10179 : packedSelected [1,8,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10180 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,9,5376,32768,33031,5140,2048,1025,32769,4112,1,17,3,8,17,2049,5392,4096,35076,1284,33028,257,0,37892,33541]

theorem envBound10180 : H12AffineFastState.Bounded env10180 := by
  intro p hp
  have h : env10180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10179_10180 : H12AffineEnvironment.transform 17 2048 env10179 = env10180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env10179 == env10180) = true)

theorem identity10180 : scanCanonicalize (H12AffineFastState.compose env10180 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10180 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10181 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,9,5376,0,263,5140,2048,1025,1,4112,1,17,3,8,17,2049,5392,4096,2308,1284,260,257,0,5124,773]

theorem envBound10181 : H12AffineFastState.Bounded env10181 := by
  intro p hp
  have h : env10181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10180_10181 : H12AffineEnvironment.transform 14 0 env10180 = env10181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10180 == env10181) = true)

theorem identity10181 : scanCanonicalize (H12AffineFastState.compose env10181 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10181 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10182 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5125,0,2,5140,2048,1025,1,4112,1,17,3,8,17,2049,5141,4096,2049,1025,1,4,0,5124,512]

theorem envBound10182 : H12AffineFastState.Bounded env10182 := by
  intro p hp
  have h : env10182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10181_10182 : H12AffineEnvironment.transform 7 5 env10181 = env10182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10181 == env10182) = true)

def env10183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066127,115150,10507600,8692044,10600786,4268163,257,8487406,8478795,10544773]

theorem envBound10183 : H12AffineFastState.Bounded env10183 := by
  intro p hp
  have h : env10183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10068_10183 : H12AffineEnvironment.transform 16 24909 env10068 = env10183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env10068 == env10183) = true)

def env10184 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114835,8328,16,15066127,115102,10507520,8691996,10600706,4268163,257,8487358,8478747,10544773]

theorem envBound10184 : H12AffineFastState.Bounded env10184 := by
  intro p hp
  have h : env10184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10183_10184 : H12AffineEnvironment.transform 5 16 env10183 = env10184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10183 == env10184) = true)

theorem identity10184 : scanCanonicalize (H12AffineFastState.compose env10184 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2155532) := by decide +kernel

theorem selectedBound10184 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env10185 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2155532,2114835,8328,16,4521987,115102,45324,2376976,75022,4268163,257,2188722,2196503,649]

theorem envBound10185 : H12AffineFastState.Bounded env10185 := by
  intro p hp
  have h : env10185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10184_10185 : H12AffineEnvironment.transform 22 2155532 env10184 = env10185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env10184 == env10185) = true)

def env10186 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,2114864,2155532,2114835,8328,16,2442547,115102,45324,2376976,75022,2188723,257,2188722,2196503,649]

theorem envBound10186 : H12AffineFastState.Bounded env10186 := by
  intro p hp
  have h : env10186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10185_10186 : H12AffineEnvironment.transform 21 2114864 env10185 = env10186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114864 env10185 == env10186) = true)

theorem identity10186 : scanCanonicalize (H12AffineFastState.compose env10186 (packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10186 : packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS < 2^1333 := by decide +kernel

def env10187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,2114864,2155532,2114835,8328,16,2190619,115102,45324,2125112,75022,2188723,257,2188722,2196503,649]

theorem envBound10187 : H12AffineFastState.Bounded env10187 := by
  intro p hp
  have h : env10187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10186_10187 : H12AffineEnvironment.transform 17 10280 env10186 = env10187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10186 == env10187) = true)

theorem identity10187 : scanCanonicalize (H12AffineFastState.compose env10187 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 124307) := by decide +kernel

theorem selectedBound10187 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env10188 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,124307,106659,65951,106624,8328,16,34952,115102,45324,100523,75022,32800,257,32801,24964,649]

theorem envBound10188 : H12AffineFastState.Bounded env10188 := by
  intro p hp
  have h : env10188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10187_10188 : H12AffineEnvironment.transform 20 124307 env10187 = env10188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124307 env10187 == env10188) = true)

theorem identity10188 : scanCanonicalize (H12AffineFastState.compose env10188 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10188 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env10189 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,262,24861,10280,1025,32769,58517,41381,153,41350,8328,16,34952,49304,45324,35245,9224,32800,257,32801,24964,649]

theorem envBound10189 : H12AffineFastState.Bounded env10189 := by
  intro p hp
  have h : env10189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10188_10189 : H12AffineEnvironment.transform 15 262 env10188 = env10189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10188 == env10189) = true)

theorem identity10189 : scanCanonicalize (H12AffineFastState.compose env10189 (packedSelected [1,3,5,8,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound10189 : packedSelected [1,3,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env10190 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,32768,262,16537,2476,1025,32769,50449,32801,153,32770,268,16,34952,49304,37000,35245,1420,32800,257,32801,16384,649]

theorem envBound10190 : H12AffineFastState.Bounded env10190 := by
  intro p hp
  have h : env10190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10189_10190 : H12AffineEnvironment.transform 12 388 env10189 = env10190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env10189 == env10190) = true)

theorem identity10190 : scanCanonicalize (H12AffineFastState.compose env10190 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10190 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env10191 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,262,16401,2340,1025,32769,50449,32801,17,32770,268,16,34816,49168,36864,35109,1284,32800,257,32801,16384,513]

theorem envBound10191 : H12AffineFastState.Bounded env10191 := by
  intro p hp
  have h : env10191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10190_10191 : H12AffineEnvironment.transform 6 8 env10190 = env10191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10190 == env10191) = true)

theorem identity10191 : scanCanonicalize (H12AffineFastState.compose env10191 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 1291) := by decide +kernel

theorem selectedBound10191 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env10192 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1291,262,16401,2340,1025,1290,16410,1322,17,1289,268,16,3339,17691,5387,3118,1284,1323,257,1322,16384,513]

theorem envBound10192 : H12AffineFastState.Bounded env10192 := by
  intro p hp
  have h : env10192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10191_10192 : H12AffineEnvironment.transform 14 1291 env10191 = env10192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1291 env10191 == env10192) = true)

theorem identity10192 : scanCanonicalize (H12AffineFastState.compose env10192 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound10192 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10193 : List Nat := [2,4,8,16,32,16,8,256,512,267,2048,4096,268,16384,0,262,16401,2340,266,1,16410,33,17,2,268,16,2048,16400,4096,2341,15,32,257,33,16384,513]

theorem envBound10193 : H12AffineFastState.Bounded env10193 := by
  intro p hp
  have h : env10193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10192_10193 : H12AffineEnvironment.transform 9 267 env10192 = env10193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env10192 == env10193) = true)

theorem identity10193 : scanCanonicalize (H12AffineFastState.compose env10193 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound10193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10194 : List Nat := [2,4,8,16,32,16,8,256,512,267,2048,4096,268,4356,0,262,4373,2340,266,1,4382,33,17,2,268,16,2048,4372,4096,2341,15,32,257,33,4356,513]

theorem envBound10194 : H12AffineFastState.Bounded env10194 := by
  intro p hp
  have h : env10194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10193_10194 : H12AffineEnvironment.transform 13 4356 env10193 = env10194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env10193 == env10194) = true)

theorem identity10194 : scanCanonicalize (H12AffineFastState.compose env10194 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound10194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10195 : List Nat := [2,4,8,16,32,16,8,256,512,267,2048,2096,268,2356,0,262,2341,2340,266,1,2350,33,17,2,268,16,2048,2340,2096,2341,15,32,257,33,2356,513]

theorem envBound10195 : H12AffineFastState.Bounded env10195 := by
  intro p hp
  have h : env10195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10194_10195 : H12AffineEnvironment.transform 11 2096 env10194 = env10195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env10194 == env10195) = true)

theorem identity10195 : scanCanonicalize (H12AffineFastState.compose env10195 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound10195 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10196 : List Nat := [2,4,8,16,32,16,8,256,49,267,2048,2096,268,2356,0,262,2341,2340,266,1,2350,33,17,2,268,16,2048,2340,2096,2341,15,32,257,33,2356,48]

theorem envBound10196 : H12AffineFastState.Bounded env10196 := by
  intro p hp
  have h : env10196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10195_10196 : H12AffineEnvironment.transform 8 49 env10195 = env10196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env10195 == env10196) = true)

theorem identity10196 : scanCanonicalize (H12AffineFastState.compose env10196 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound10196 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10197 : List Nat := [2,4,8,16,32,16,8,256,49,267,309,261,268,1,0,262,16,17,266,1,27,33,17,2,268,16,309,17,261,16,15,32,257,33,1,48]

theorem envBound10197 : H12AffineFastState.Bounded env10197 := by
  intro p hp
  have h : env10197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10196_10197 : H12AffineEnvironment.transform 10 309 env10196 = env10197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env10196 == env10197) = true)

theorem identity10197 : scanCanonicalize (H12AffineFastState.compose env10197 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound10197 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10198 : List Nat := [2,4,8,16,32,16,8,52,49,63,1,49,56,1,0,50,16,17,62,1,27,33,17,2,56,16,1,17,49,16,15,32,53,33,1,48]

theorem envBound10198 : H12AffineFastState.Bounded env10198 := by
  intro p hp
  have h : env10198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10197_10198 : H12AffineEnvironment.transform 7 52 env10197 = env10198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env10197 == env10198) = true)

theorem identity10198 : scanCanonicalize (H12AffineFastState.compose env10198 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound10198 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10199 : List Nat := [2,2,8,16,32,16,8,50,49,57,1,49,56,1,0,50,16,17,56,1,27,33,17,2,56,16,1,17,49,16,9,32,51,33,1,48]

theorem envBound10199 : H12AffineFastState.Bounded env10199 := by
  intro p hp
  have h : env10199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10198_10199 : H12AffineEnvironment.transform 1 2 env10198 = env10199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env10198 == env10199) = true)

theorem identity10199 : scanCanonicalize (H12AffineFastState.compose env10199 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10199 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env10200 : List Nat := [2,2,8,16,0,16,8,18,17,25,1,17,24,1,0,18,16,17,24,1,27,1,17,2,24,16,1,17,17,16,9,0,19,1,1,16]

theorem envBound10200 : H12AffineFastState.Bounded env10200 := by
  intro p hp
  have h : env10200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10199_10200 : H12AffineEnvironment.transform 4 0 env10199 = env10200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10199 == env10200) = true)

def env10201 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,2114865,2155532,2114835,8328,16,2442546,115102,45324,2376976,75022,2188722,257,2188722,2196503,649]

theorem envBound10201 : H12AffineFastState.Bounded env10201 := by
  intro p hp
  have h : env10201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10185_10201 : H12AffineEnvironment.transform 21 2114865 env10185 = env10201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114865 env10185 == env10201) = true)

theorem identity10201 : scanCanonicalize (H12AffineFastState.compose env10201 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10201 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10202 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,2114865,2155532,2114835,8192,16,2442546,114966,45324,2376976,75022,2188602,257,2188602,2196503,513]

theorem envBound10202 : H12AffineFastState.Bounded env10202 := by
  intro p hp
  have h : env10202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10201_10202 : H12AffineEnvironment.transform 6 8 env10201 = env10202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10201 == env10202) = true)

theorem identity10202 : scanCanonicalize (H12AffineFastState.compose env10202 (packedSelected [0,7,16,19,21,26] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound10202 : packedSelected [0,7,16,19,21,26] rootPS < 2^1333 := by decide +kernel

def env10203 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,58397,41260,17,41230,8192,16,368943,114966,45324,303373,75022,98599,257,98599,90122,513]

theorem envBound10203 : H12AffineFastState.Bounded env10203 := by
  intro p hp
  have h : env10203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10202_10203 : H12AffineEnvironment.transform 20 58397 env10202 = env10203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env10202 == env10203) = true)

theorem identity10203 : scanCanonicalize (H12AffineFastState.compose env10203 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10203 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10204 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,58397,41260,17,41230,8192,16,100615,114966,45324,35109,75022,98599,257,98599,90122,513]

theorem envBound10204 : H12AffineFastState.Bounded env10204 := by
  intro p hp
  have h : env10204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10203_10204 : H12AffineEnvironment.transform 17 10280 env10203 = env10204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10203 == env10204) = true)

theorem identity10204 : scanCanonicalize (H12AffineFastState.compose env10204 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound10204 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env10205 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,24861,10280,1025,32769,58397,41260,17,41230,8192,16,10509,24860,45324,35109,34052,8493,257,8493,49152,513]

theorem envBound10205 : H12AffineFastState.Bounded env10205 := by
  intro p hp
  have h : env10205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10204_10205 : H12AffineEnvironment.transform 15 40970 env10204 = env10205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env10204 == env10205) = true)

theorem identity10205 : scanCanonicalize (H12AffineFastState.compose env10205 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10205 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10206 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,263,24861,10280,1025,8460,17680,33,17,3,8192,16,10509,24860,4097,10280,9225,8493,257,8493,24845,513]

theorem envBound10206 : H12AffineFastState.Bounded env10206 := by
  intro p hp
  have h : env10206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10205_10206 : H12AffineEnvironment.transform 14 8461 env10205 = env10206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10205 == env10206) = true)

theorem identity10206 : scanCanonicalize (H12AffineFastState.compose env10206 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound10206 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env10207 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,8192,16384,8461,263,24861,10280,1025,8460,17680,33,17,3,8192,16,10509,24860,1589,10280,9225,8493,257,8493,24845,513]

theorem envBound10207 : H12AffineFastState.Bounded env10207 := by
  intro p hp
  have h : env10207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10206_10207 : H12AffineEnvironment.transform 11 1588 env10206 = env10207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env10206 == env10207) = true)

theorem identity10207 : scanCanonicalize (H12AffineFastState.compose env10207 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound10207 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env10208 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,8192,10508,8461,263,2065,10280,1025,8460,11292,33,17,3,8192,16,10509,2064,1589,10280,9225,8493,257,8493,2049,513]

theorem envBound10208 : H12AffineFastState.Bounded env10208 := by
  intro p hp
  have h : env10208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10207_10208 : H12AffineEnvironment.transform 13 10508 env10207 = env10208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env10207 == env10208) = true)

theorem identity10208 : scanCanonicalize (H12AffineFastState.compose env10208 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1036) := by decide +kernel

theorem selectedBound10208 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10209 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,1036,3328,1281,263,2065,3108,1025,1280,2064,33,17,3,1036,16,3329,2064,1589,3108,5,1313,257,1313,2049,513]

theorem envBound10209 : H12AffineFastState.Bounded env10209 := by
  intro p hp
  have h : env10209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10208_10209 : H12AffineEnvironment.transform 12 1036 env10208 = env10209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1036 env10208 == env10209) = true)

theorem identity10209 : scanCanonicalize (H12AffineFastState.compose env10209 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound10209 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10210 : List Nat := [2,4,8,16,32,16,8,256,309,1024,2048,1281,1036,3328,1281,263,2065,3108,1025,1280,2064,33,17,3,1036,16,3329,2064,1280,3108,5,1313,257,1313,2049,308]

theorem envBound10210 : H12AffineFastState.Bounded env10210 := by
  intro p hp
  have h : env10210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10209_10210 : H12AffineEnvironment.transform 8 309 env10209 = env10210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env10209 == env10210) = true)

theorem identity10210 : scanCanonicalize (H12AffineFastState.compose env10210 (packedSelected [1,5,14] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound10210 : packedSelected [1,5,14] rootPS < 2^1333 := by decide +kernel

def env10211 : List Nat := [2,4,8,16,32,16,8,256,309,257,2048,0,269,2049,0,263,2065,2341,256,1,2064,33,17,3,269,16,2048,2064,1,2341,5,32,257,32,2049,308]

theorem envBound10211 : H12AffineFastState.Bounded env10211 := by
  intro p hp
  have h : env10211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10210_10211 : H12AffineEnvironment.transform 9 257 env10210 = env10211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env10210 == env10211) = true)

theorem identity10211 : scanCanonicalize (H12AffineFastState.compose env10211 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10212 : List Nat := [2,4,8,16,17,16,8,256,260,257,2048,0,269,2049,0,263,2065,2324,256,1,2064,16,17,3,269,16,2048,2064,1,2324,5,17,257,17,2049,261]

theorem envBound10212 : H12AffineFastState.Bounded env10212 := by
  intro p hp
  have h : env10212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10211_10212 : H12AffineEnvironment.transform 4 17 env10211 = env10212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10211 == env10212) = true)

theorem identity10212 : scanCanonicalize (H12AffineFastState.compose env10212 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10212 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10213 : List Nat := [2,4,8,1,0,1,8,256,260,257,2048,0,269,2049,0,263,2048,2309,256,1,2049,1,0,3,269,1,2048,2049,1,2309,5,0,257,0,2049,261]

theorem envBound10213 : H12AffineFastState.Bounded env10213 := by
  intro p hp
  have h : env10213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10212_10213 : H12AffineEnvironment.transform 3 1 env10212 = env10213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10212 == env10213) = true)

theorem identity10213 : scanCanonicalize (H12AffineFastState.compose env10213 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10214 : List Nat := [2,4,8,1,0,1,8,256,260,257,0,0,269,1,0,263,0,261,256,1,1,1,0,3,269,1,0,1,1,261,5,0,257,0,1,261]

theorem envBound10214 : H12AffineFastState.Bounded env10214 := by
  intro p hp
  have h : env10214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10213_10214 : H12AffineEnvironment.transform 10 0 env10213 = env10214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10213 == env10214) = true)

theorem identity10214 : scanCanonicalize (H12AffineFastState.compose env10214 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10214 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10215 : List Nat := [2,4,8,1,0,1,8,5,1,4,0,0,8,1,0,2,0,0,5,1,1,1,0,3,8,1,0,1,1,0,5,0,4,0,1,0]

theorem envBound10215 : H12AffineFastState.Bounded env10215 := by
  intro p hp
  have h : env10215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10214_10215 : H12AffineEnvironment.transform 7 5 env10214 = env10215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10214 == env10215) = true)

def env10216 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114834,8328,17,15066127,115103,10507521,8691997,10600707,4268163,257,8487359,8478746,10544773]

theorem envBound10216 : H12AffineFastState.Bounded env10216 := by
  intro p hp
  have h : env10216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10183_10216 : H12AffineEnvironment.transform 5 17 env10183 = env10216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10183 == env10216) = true)

theorem identity10216 : scanCanonicalize (H12AffineFastState.compose env10216 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2411556) := by decide +kernel

theorem selectedBound10216 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env10217 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2411556,2114834,8328,17,4270123,115103,301349,2125113,331047,4268163,257,2444699,2468926,273057]

theorem envBound10217 : H12AffineFastState.Bounded env10217 := by
  intro p hp
  have h : env10217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10216_10217 : H12AffineEnvironment.transform 22 2411556 env10216 = env10217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2411556 env10216 == env10217) = true)

def env10218 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,32,2411556,2114834,8328,17,75787,115103,301349,2125113,331047,73891,257,2444699,2468926,273057]

theorem envBound10218 : H12AffineFastState.Bounded env10218 := by
  intro p hp
  have h : env10218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10217_10218 : H12AffineEnvironment.transform 21 32 env10217 = env10218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env10217 == env10218) = true)

theorem identity10218 : scanCanonicalize (H12AffineFastState.compose env10218 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound10218 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env10219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,67754,1025,32769,2097152,32,2213006,2114834,8328,17,75787,115103,102799,2125113,1421,73891,257,2114865,2139284,74251]

theorem envBound10219 : H12AffineFastState.Bounded env10219 := by
  intro p hp
  have h : env10219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10218_10219 : H12AffineEnvironment.transform 17 67754 env10218 = env10219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env10218 == env10219) = true)

theorem identity10219 : scanCanonicalize (H12AffineFastState.compose env10219 (packedSelected [16,17,19,20,21,26] rootPS)) = affineNative (2^(20+1) ^^^ 50585) := by decide +kernel

theorem selectedBound10219 : packedSelected [16,17,19,20,21,26] rootPS < 2^1333 := by decide +kernel

def env10220 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,67754,1025,32769,50585,32,65815,32907,8328,17,75787,115103,102799,43168,1421,73891,257,32936,24845,74251]

theorem envBound10220 : H12AffineFastState.Bounded env10220 := by
  intro p hp
  have h : env10220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10219_10220 : H12AffineEnvironment.transform 20 50585 env10219 = env10220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50585 env10219 == env10220) = true)

theorem identity10220 : scanCanonicalize (H12AffineFastState.compose env10220 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound10220 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env10221 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40970,24860,43168,1025,32769,50585,32,41245,32907,8328,17,34817,24981,12677,43168,1421,32937,257,32936,24845,33281]

theorem envBound10221 : H12AffineFastState.Bounded env10221 := by
  intro p hp
  have h : env10221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10220_10221 : H12AffineEnvironment.transform 15 40970 env10220 = env10221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env10220 == env10221) = true)

theorem identity10221 : scanCanonicalize (H12AffineFastState.compose env10221 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound10221 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10222 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,33167,16537,35109,1025,32769,50585,32,32920,32907,269,17,34817,16400,4096,35109,1421,32937,257,32936,16520,33281]

theorem envBound10222 : H12AffineFastState.Bounded env10222 := by
  intro p hp
  have h : env10222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10221_10222 : H12AffineEnvironment.transform 12 389 env10221 = env10222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env10221 == env10222) = true)

theorem identity10222 : scanCanonicalize (H12AffineFastState.compose env10222 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound10222 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env10223 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,16384,32768,32803,16537,34953,1025,32769,50229,32,32920,32907,161,17,34817,16400,4096,34953,1057,32937,173,32936,16520,33281]

theorem envBound10223 : H12AffineFastState.Bounded env10223 := by
  intro p hp
  have h : env10223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10222_10223 : H12AffineEnvironment.transform 7 172 env10222 = env10223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env10222 == env10223) = true)

theorem identity10223 : scanCanonicalize (H12AffineFastState.compose env10223 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound10223 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10224 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,16384,136,171,16537,2049,1025,137,17597,32,16,3,161,17,2185,16400,4096,2049,1057,33,173,32,16520,649]

theorem envBound10224 : H12AffineFastState.Bounded env10224 := by
  intro p hp
  have h : env10224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0