import H12CloudChart0Data187

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans47607_47608 : H12AffineEnvironment.transform 11 309 env47607 = env47608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env47607 == env47608) = true)

theorem identity47608 : scanCanonicalize (H12AffineFastState.compose env47608 (packedSelected [0,2,6,7,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound47608 : packedSelected [0,2,6,7,12,14] rootPS < 2^1333 := by decide +kernel

def env47609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,309,1336,1345,1296,1095,65,80,1025,1297,292,261,64,3,1337,64,1345,1141,64,0,1285,341,257,341,1297,804]

theorem envBound47609 : H12AffineFastState.Bounded env47609 := by
  intro p hp
  have h : env47609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47608_47609 : H12AffineEnvironment.transform 10 1125 env47608 = env47609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env47608 == env47609) = true)

theorem identity47609 : scanCanonicalize (H12AffineFastState.compose env47609 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47609 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env47610 : List Nat := [2,4,8,16,32,64,9,256,512,101,0,309,349,292,373,34,65,80,100,372,292,261,64,3,348,64,292,16,64,0,352,341,257,341,372,804]

theorem envBound47610 : H12AffineFastState.Bounded env47610 := by
  intro p hp
  have h : env47610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47609_47610 : H12AffineEnvironment.transform 9 101 env47609 = env47610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47609 == env47610) = true)

theorem identity47610 : scanCanonicalize (H12AffineFastState.compose env47610 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47610 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env47611 : List Nat := [2,4,8,16,32,16,9,256,512,53,0,309,269,292,293,34,17,0,52,292,292,261,16,3,268,16,292,16,16,0,304,261,257,261,292,804]

theorem envBound47611 : H12AffineFastState.Bounded env47611 := by
  intro p hp
  have h : env47611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47610_47611 : H12AffineEnvironment.transform 5 16 env47610 = env47611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47610 == env47611) = true)

theorem identity47611 : scanCanonicalize (H12AffineFastState.compose env47611 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47611 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47612 : List Nat := [2,4,8,16,0,16,9,256,512,21,0,277,269,260,261,2,17,0,20,260,260,261,16,3,268,16,260,16,16,0,272,261,257,261,260,772]

theorem envBound47612 : H12AffineFastState.Bounded env47612 := by
  intro p hp
  have h : env47612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47611_47612 : H12AffineEnvironment.transform 4 0 env47611 = env47612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47611 == env47612) = true)

theorem identity47612 : scanCanonicalize (H12AffineFastState.compose env47612 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47612 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47613 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,17,9,0,1,2,17,0,20,0,0,1,16,3,8,16,0,16,16,0,20,1,5,1,0,512]

theorem envBound47613 : H12AffineFastState.Bounded env47613 := by
  intro p hp
  have h : env47613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47612_47613 : H12AffineEnvironment.transform 7 4 env47612 = env47613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47612 == env47613) = true)

theorem identity47613 : scanCanonicalize (H12AffineFastState.compose env47613 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound47613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47614 : List Nat := [2,4,8,16,0,16,9,4,17,21,0,17,9,0,1,2,17,0,20,0,0,1,16,3,8,16,0,16,16,0,20,1,5,1,0,17]

theorem envBound47614 : H12AffineFastState.Bounded env47614 := by
  intro p hp
  have h : env47614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47613_47614 : H12AffineEnvironment.transform 8 17 env47613 = env47614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env47613 == env47614) = true)

theorem identity47614 : scanCanonicalize (H12AffineFastState.compose env47614 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound47614 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47615 : List Nat := [2,4,8,14,0,14,9,4,15,11,0,15,9,0,1,2,15,0,10,0,0,1,14,3,8,14,0,14,14,0,10,1,5,1,0,15]

theorem envBound47615 : H12AffineFastState.Bounded env47615 := by
  intro p hp
  have h : env47615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47614_47615 : H12AffineEnvironment.transform 3 14 env47614 = env47615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env47614 == env47615) = true)

def env47616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590877,2098512,17664,2363457,2102685,6349852,257,21793,46213,2175562]

theorem envBound47616 : H12AffineFastState.Bounded env47616 := by
  intro p hp
  have h : env47616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47547_47616 : H12AffineEnvironment.transform 16 49169 env47547 = env47616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47547 == env47616) = true)

def env47617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144541,2098512,17664,2363457,2102685,2411676,257,21793,46213,2175562]

theorem envBound47617 : H12AffineFastState.Bounded env47617 := by
  intro p hp
  have h : env47617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47616_47617 : H12AffineEnvironment.transform 21 272512 env47616 = env47617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47616 == env47617) = true)

theorem identity47617 : scanCanonicalize (H12AffineFastState.compose env47617 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound47617 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272512,17,98780,8328,64,43356,5393,17664,262144,1500,318685,257,21793,46213,74251]

theorem envBound47618 : H12AffineFastState.Bounded env47618 := by
  intro p hp
  have h : env47618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47617_47618 : H12AffineEnvironment.transform 20 4161 env47617 = env47618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47617 == env47618) = true)

theorem identity47618 : scanCanonicalize (H12AffineFastState.compose env47618 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47618 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env47619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272512,17,41430,8328,64,43356,5393,17664,262144,1500,318685,257,21793,46213,513]

theorem envBound47619 : H12AffineFastState.Bounded env47619 := by
  intro p hp
  have h : env47619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47618_47619 : H12AffineEnvironment.transform 15 8202 env47618 = env47619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47618 == env47619) = true)

theorem identity47619 : scanCanonicalize (H12AffineFastState.compose env47619 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound47619 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env47620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,35324,1025,32769,4161,41340,17,41430,8328,64,43356,5393,17664,35324,1500,21793,257,21793,46213,513]

theorem envBound47620 : H12AffineFastState.Bounded env47620 := by
  intro p hp
  have h : env47620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47619_47620 : H12AffineEnvironment.transform 17 35324 env47619 = env47620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env47619 == env47620) = true)

theorem identity47620 : scanCanonicalize (H12AffineFastState.compose env47620 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47620 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,342,49169,35324,1025,32769,4161,32800,17,32906,468,64,34816,5393,17664,35324,1500,21793,257,21793,38361,513]

theorem envBound47621 : H12AffineFastState.Bounded env47621 := by
  intro p hp
  have h : env47621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47620_47621 : H12AffineEnvironment.transform 12 348 env47620 = env47621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47620 == env47621) = true)

theorem identity47621 : scanCanonicalize (H12AffineFastState.compose env47621 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47621 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env47622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49169,35188,1025,32769,4161,32800,17,32770,348,64,34816,5393,17664,35188,1364,21793,257,21793,38225,513]

theorem envBound47622 : H12AffineFastState.Bounded env47622 := by
  intro p hp
  have h : env47622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47621_47622 : H12AffineEnvironment.transform 6 8 env47621 = env47622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47621 == env47622) = true)

theorem identity47622 : scanCanonicalize (H12AffineFastState.compose env47622 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound47622 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,342,5392,23669,1025,21760,4161,21793,17,21763,348,64,23809,5393,17664,23669,1364,21793,257,21793,16464,513]

theorem envBound47623 : H12AffineFastState.Bounded env47623 := by
  intro p hp
  have h : env47623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47622_47623 : H12AffineEnvironment.transform 14 21761 env47622 = env47623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env47622 == env47623) = true)

theorem identity47623 : scanCanonicalize (H12AffineFastState.compose env47623 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47623 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1025,1,4161,32,17,2,348,64,2048,5393,4097,2420,1364,32,257,32,5457,513]

theorem envBound47624 : H12AffineFastState.Bounded env47624 := by
  intro p hp
  have h : env47624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47623_47624 : H12AffineEnvironment.transform 13 5377 env47623 = env47624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47623 == env47624) = true)

theorem identity47624 : scanCanonicalize (H12AffineFastState.compose env47624 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47625 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4113,0,342,4096,2420,273,1,4161,32,17,2,348,64,2048,4097,4097,2420,68,32,257,32,4161,513]

theorem envBound47625 : H12AffineFastState.Bounded env47625 := by
  intro p hp
  have h : env47625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47624_47625 : H12AffineEnvironment.transform 9 272 env47624 = env47625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47624 == env47625) = true)

theorem identity47625 : scanCanonicalize (H12AffineFastState.compose env47625 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound47625 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47626 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,64,348,81,0,342,64,2420,273,1,1,32,17,2,348,64,2048,65,65,2420,68,32,257,32,1,513]

theorem envBound47626 : H12AffineFastState.Bounded env47626 := by
  intro p hp
  have h : env47626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47625_47626 : H12AffineEnvironment.transform 11 64 env47625 = env47626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env47625 == env47626) = true)

theorem identity47626 : scanCanonicalize (H12AffineFastState.compose env47626 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47626 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47627 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,64,121,81,0,115,64,2129,52,1,1,32,17,2,121,64,2048,65,65,2129,68,32,36,32,1,513]

theorem envBound47627 : H12AffineFastState.Bounded env47627 := by
  intro p hp
  have h : env47627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47626_47627 : H12AffineEnvironment.transform 7 37 env47626 = env47627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47626 == env47627) = true)

theorem identity47627 : scanCanonicalize (H12AffineFastState.compose env47627 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47627 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47628 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,17,40,0,0,34,17,2048,52,1,1,32,17,2,40,17,2048,16,16,2048,21,32,36,32,1,513]

theorem envBound47628 : H12AffineFastState.Bounded env47628 := by
  intro p hp
  have h : env47628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47627_47628 : H12AffineEnvironment.transform 5 17 env47627 = env47628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47627 == env47628) = true)

theorem identity47628 : scanCanonicalize (H12AffineFastState.compose env47628 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound47628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47629 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,17,40,0,0,34,17,33,52,1,1,32,17,2,40,17,33,16,16,33,21,32,36,32,1,513]

theorem envBound47629 : H12AffineFastState.Bounded env47629 := by
  intro p hp
  have h : env47629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47628_47629 : H12AffineEnvironment.transform 10 33 env47628 = env47629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env47628 == env47629) = true)

theorem identity47629 : scanCanonicalize (H12AffineFastState.compose env47629 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47630 : List Nat := [2,4,8,16,16,17,8,21,512,5,17,17,24,0,0,18,17,17,4,1,1,16,17,2,24,17,17,16,16,17,21,16,20,16,1,513]

theorem envBound47630 : H12AffineFastState.Bounded env47630 := by
  intro p hp
  have h : env47630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47629_47630 : H12AffineEnvironment.transform 4 16 env47629 = env47630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47629 == env47630) = true)

theorem identity47630 : scanCanonicalize (H12AffineFastState.compose env47630 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47630 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47631 : List Nat := [2,4,8,0,0,1,8,5,512,5,1,1,8,0,0,2,1,1,4,1,1,0,1,2,8,1,1,0,0,1,5,0,4,0,1,513]

theorem envBound47631 : H12AffineFastState.Bounded env47631 := by
  intro p hp
  have h : env47631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47630_47631 : H12AffineEnvironment.transform 3 0 env47630 = env47631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47630 == env47631) = true)

def env47632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144540,2098512,17664,2363457,2102685,2411677,257,21793,46213,2175562]

theorem envBound47632 : H12AffineFastState.Bounded env47632 := by
  intro p hp
  have h : env47632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47616_47632 : H12AffineEnvironment.transform 21 272513 env47616 = env47632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47616 == env47632) = true)

def env47633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101328,98644,8192,64,2144540,2098512,17664,2363457,2102549,2411541,257,21793,46093,2175562]

theorem envBound47633 : H12AffineFastState.Bounded env47633 := by
  intro p hp
  have h : env47633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47632_47633 : H12AffineEnvironment.transform 6 8 env47632 = env47633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47632 == env47633) = true)

def env47634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,16,98644,8192,64,43356,5392,17664,262145,1365,318549,257,21793,46093,74250]

theorem envBound47634 : H12AffineFastState.Bounded env47634 := by
  intro p hp
  have h : env47634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47633_47634 : H12AffineEnvironment.transform 20 4160 env47633 = env47634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47633 == env47634) = true)

theorem identity47634 : scanCanonicalize (H12AffineFastState.compose env47634 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound47634 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130095,1025,32769,4160,119846,16,98644,8192,64,43356,5392,17664,130094,1365,73850,257,21793,46093,74250]

theorem envBound47635 : H12AffineFastState.Bounded env47635 := by
  intro p hp
  have h : env47635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47634_47635 : H12AffineEnvironment.transform 17 130095 env47634 = env47635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env47634 == env47635) = true)

theorem identity47635 : scanCanonicalize (H12AffineFastState.compose env47635 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound47635 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,65536,46109,100387,1025,32769,4160,106538,16,98644,8192,64,43356,5392,12556,100386,1365,73850,257,8493,46093,74250]

theorem envBound47636 : H12AffineFastState.Bounded env47636 := by
  intro p hp
  have h : env47636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47635_47636 : H12AffineEnvironment.transform 13 13324 env47635 = env47636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env47635 == env47636) = true)

theorem identity47636 : scanCanonicalize (H12AffineFastState.compose env47636 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47636 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env47637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,8203,46109,43048,1025,32769,4160,32801,16,41311,8192,64,43356,5392,12556,43049,1365,113,257,8493,46093,513]

theorem envBound47637 : H12AffineFastState.Bounded env47637 := by
  intro p hp
  have h : env47637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47636_47637 : H12AffineEnvironment.transform 15 8203 env47636 = env47637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47636 == env47637) = true)

theorem identity47637 : scanCanonicalize (H12AffineFastState.compose env47637 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47637 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,1,8203,13340,10281,1025,0,4160,32,16,8542,8192,64,10589,5392,12556,10280,1365,113,257,8493,13324,513]

theorem envBound47638 : H12AffineFastState.Bounded env47638 := by
  intro p hp
  have h : env47638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47637_47638 : H12AffineEnvironment.transform 14 1 env47637 = env47638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47637 == env47638) = true)

theorem identity47638 : scanCanonicalize (H12AffineFastState.compose env47638 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound47638 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env47639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,8192,13324,1,8203,13340,8460,1025,0,4160,32,16,8542,8192,64,8312,5392,12556,8461,1365,113,257,8493,13324,513]

theorem envBound47639 : H12AffineFastState.Bounded env47639 := by
  intro p hp
  have h : env47639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47638_47639 : H12AffineEnvironment.transform 10 293 env47638 = env47639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env47638 == env47639) = true)

theorem identity47639 : scanCanonicalize (H12AffineFastState.compose env47639 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound47639 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env47640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,5133,1,1,5126,17,5377,1025,0,4160,32,16,5459,5133,64,5237,5392,1281,5376,1365,113,257,5408,1,513]

theorem envBound47640 : H12AffineFastState.Bounded env47640 := by
  intro p hp
  have h : env47640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47639_47640 : H12AffineEnvironment.transform 12 5133 env47639 = env47640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env47639 == env47640) = true)

theorem identity47640 : scanCanonicalize (H12AffineFastState.compose env47640 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound47640 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,17,1052,1,1,1047,17,1296,1025,0,81,32,16,1346,1052,64,1124,1281,1281,1297,1365,113,257,1329,1,513]

theorem envBound47641 : H12AffineFastState.Bounded env47641 := by
  intro p hp
  have h : env47641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47640_47641 : H12AffineEnvironment.transform 11 17 env47640 = env47641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47640 == env47641) = true)

theorem identity47641 : scanCanonicalize (H12AffineFastState.compose env47641 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47641 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47642 : List Nat := [2,4,8,16,32,64,8,256,512,272,293,17,268,1,1,263,17,0,273,0,81,32,16,82,268,64,372,17,17,1,69,113,257,33,1,513]

theorem envBound47642 : H12AffineFastState.Bounded env47642 := by
  intro p hp
  have h : env47642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47641_47642 : H12AffineEnvironment.transform 9 272 env47641 = env47642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47641 == env47642) = true)

theorem identity47642 : scanCanonicalize (H12AffineFastState.compose env47642 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47642 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47643 : List Nat := [2,4,8,16,32,17,8,256,512,272,293,17,268,1,1,263,17,0,273,0,0,32,16,3,268,17,293,17,17,1,20,32,257,33,1,513]

theorem envBound47643 : H12AffineFastState.Bounded env47643 := by
  intro p hp
  have h : env47643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47642_47643 : H12AffineEnvironment.transform 5 17 env47642 = env47643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47642 == env47643) = true)

def env47644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,98644,8192,64,43357,5393,17664,262144,1364,318548,257,21793,46093,74251]

theorem envBound47644 : H12AffineFastState.Bounded env47644 := by
  intro p hp
  have h : env47644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47633_47644 : H12AffineEnvironment.transform 20 4161 env47633 = env47644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47633 == env47644) = true)

theorem identity47644 : scanCanonicalize (H12AffineFastState.compose env47644 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47644 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,33,17,98644,8192,64,43357,5393,17664,10280,1364,62588,257,21793,46093,74251]

theorem envBound47645 : H12AffineFastState.Bounded env47645 := by
  intro p hp
  have h : env47645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47644_47645 : H12AffineEnvironment.transform 17 10280 env47644 = env47645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47644 == env47645) = true)

theorem identity47645 : scanCanonicalize (H12AffineFastState.compose env47645 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47645 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env47646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10280,1025,8541,4161,33,17,73736,8192,64,2049,5393,17664,10280,1364,21792,257,21793,5457,74251]

theorem envBound47646 : H12AffineFastState.Bounded env47646 := by
  intro p hp
  have h : env47646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47645_47646 : H12AffineEnvironment.transform 14 8540 env47645 = env47646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47645 == env47646) = true)

theorem identity47646 : scanCanonicalize (H12AffineFastState.compose env47646 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound47646 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env47647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8283,24909,10280,1025,8541,4161,33,17,83,8192,64,2049,5393,17664,10280,1364,21792,257,21793,5457,592]

theorem envBound47647 : H12AffineFastState.Bounded env47647 := by
  intro p hp
  have h : env47647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47646_47647 : H12AffineEnvironment.transform 15 8283 env47646 = env47647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env47646 == env47647) = true)

theorem identity47647 : scanCanonicalize (H12AffineFastState.compose env47647 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47647 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env47648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,262,16400,2421,1025,0,4161,33,17,83,349,64,2049,5393,17664,2421,1364,21792,257,21793,5457,592]

theorem envBound47648 : H12AffineFastState.Bounded env47648 := by
  intro p hp
  have h : env47648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47647_47648 : H12AffineEnvironment.transform 12 349 env47647 = env47648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47647 == env47648) = true)

theorem identity47648 : scanCanonicalize (H12AffineFastState.compose env47648 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47648 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env47649 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,16384,1,262,16400,2388,1025,0,4161,0,17,83,349,64,2049,5393,17664,2388,1364,21761,257,21760,5457,592]

theorem envBound47649 : H12AffineFastState.Bounded env47649 := by
  intro p hp
  have h : env47649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47648_47649 : H12AffineEnvironment.transform 4 1 env47648 = env47649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47648 == env47649) = true)

theorem identity47649 : scanCanonicalize (H12AffineFastState.compose env47649 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47649 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47650 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,268,16384,1,262,16400,2309,1025,0,4112,0,17,2,268,17,2049,5393,17664,2309,1285,21761,257,21760,5376,513]

theorem envBound47650 : H12AffineFastState.Bounded env47650 := by
  intro p hp
  have h : env47650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47649_47650 : H12AffineEnvironment.transform 5 17 env47649 = env47650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47649 == env47650) = true)

theorem identity47650 : scanCanonicalize (H12AffineFastState.compose env47650 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound47650 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47651 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,2048,268,16384,1,262,16400,2309,1025,0,2064,0,17,2,268,17,2049,3345,17664,2309,1285,19713,257,19712,3328,513]

theorem envBound47651 : H12AffineFastState.Bounded env47651 := by
  intro p hp
  have h : env47651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47650_47651 : H12AffineEnvironment.transform 11 2048 env47650 = env47651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env47650 == env47651) = true)

theorem identity47651 : scanCanonicalize (H12AffineFastState.compose env47651 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound47651 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47652 : List Nat := [2,4,8,16,1,17,8,256,512,31,2048,2048,268,16384,1,262,16400,2309,30,0,2064,0,17,2,268,17,2049,2318,16671,2309,282,18718,257,18719,2335,513]

theorem envBound47652 : H12AffineFastState.Bounded env47652 := by
  intro p hp
  have h : env47652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47651_47652 : H12AffineEnvironment.transform 9 31 env47651 = env47652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env47651 == env47652) = true)

theorem identity47652 : scanCanonicalize (H12AffineFastState.compose env47652 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 2334) := by decide +kernel

theorem selectedBound47652 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env47653 : List Nat := [2,4,8,16,1,17,8,256,512,31,2048,2048,268,2334,1,262,2318,2309,30,0,2064,0,17,2,268,17,2049,2318,2049,2309,282,0,257,1,2335,513]

theorem envBound47653 : H12AffineFastState.Bounded env47653 := by
  intro p hp
  have h : env47653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47652_47653 : H12AffineEnvironment.transform 13 2334 env47652 = env47653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2334 env47652 == env47653) = true)

theorem identity47653 : scanCanonicalize (H12AffineFastState.compose env47653 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47653 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47654 : List Nat := [2,4,8,10,1,11,8,256,512,5,2048,2048,268,2308,1,262,2318,2309,4,0,2058,0,11,2,268,11,2049,2318,2049,2309,256,0,257,1,2309,513]

theorem envBound47654 : H12AffineFastState.Bounded env47654 := by
  intro p hp
  have h : env47654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47653_47654 : H12AffineEnvironment.transform 3 10 env47653 = env47654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47653 == env47654) = true)

theorem identity47654 : scanCanonicalize (H12AffineFastState.compose env47654 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound47654 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47655 : List Nat := [2,4,8,10,1,11,8,14,512,5,2048,2048,2,2058,1,8,2048,2059,4,0,2058,0,11,2,2,11,2049,2048,2049,2059,14,0,15,1,2059,513]

theorem envBound47655 : H12AffineFastState.Bounded env47655 := by
  intro p hp
  have h : env47655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47654_47655 : H12AffineEnvironment.transform 7 14 env47654 = env47655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env47654 == env47655) = true)

theorem identity47655 : scanCanonicalize (H12AffineFastState.compose env47655 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 515) := by decide +kernel

theorem selectedBound47655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47656 : List Nat := [2,4,8,10,1,11,8,14,512,5,515,515,2,521,1,8,515,520,4,0,521,0,11,2,2,11,514,515,514,520,14,0,15,1,520,513]

theorem envBound47656 : H12AffineFastState.Bounded env47656 := by
  intro p hp
  have h : env47656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47655_47656 : H12AffineEnvironment.transform 10 515 env47655 = env47656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 515 env47655 == env47656) = true)

theorem identity47656 : scanCanonicalize (H12AffineFastState.compose env47656 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound47656 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47657 : List Nat := [2,4,8,10,1,11,8,14,10,5,9,9,2,3,1,8,9,2,4,0,3,0,11,2,2,11,8,9,8,2,14,0,15,1,2,11]

theorem envBound47657 : H12AffineFastState.Bounded env47657 := by
  intro p hp
  have h : env47657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47656_47657 : H12AffineEnvironment.transform 8 10 env47656 = env47657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env47656 == env47657) = true)

theorem identity47657 : scanCanonicalize (H12AffineFastState.compose env47657 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47657 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47658 : List Nat := [0,4,8,8,1,9,8,12,8,5,9,9,0,1,1,8,9,0,4,0,1,0,9,0,0,9,8,9,8,0,12,0,13,1,0,9]

theorem envBound47658 : H12AffineFastState.Bounded env47658 := by
  intro p hp
  have h : env47658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47657_47658 : H12AffineEnvironment.transform 0 0 env47657 = env47658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47657 == env47658) = true)

theorem identity47658 : scanCanonicalize (H12AffineFastState.compose env47658 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47659 : List Nat := [0,4,4,4,1,5,4,0,4,5,5,5,0,1,1,4,5,0,4,0,1,0,5,0,0,5,4,5,4,0,0,0,1,1,0,5]

theorem envBound47659 : H12AffineFastState.Bounded env47659 := by
  intro p hp
  have h : env47659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47658_47659 : H12AffineEnvironment.transform 2 4 env47658 = env47659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47658 == env47659) = true)

def env47660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101328,98645,8193,64,2144540,2098512,17664,2363457,2102548,2411540,257,21793,46092,2175562]

theorem envBound47660 : H12AffineFastState.Bounded env47660 := by
  intro p hp
  have h : env47660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47632_47660 : H12AffineEnvironment.transform 6 9 env47632 = env47660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47632 == env47660) = true)

theorem identity47660 : scanCanonicalize (H12AffineFastState.compose env47660 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 110666) := by decide +kernel

theorem selectedBound47660 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env47661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,110666,272392,106522,98645,8193,64,67926,111898,17664,368651,107870,359518,257,21793,46092,33280]

theorem envBound47661 : H12AffineFastState.Bounded env47661 := by
  intro p hp
  have h : env47661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47660_47661 : H12AffineEnvironment.transform 20 110666 env47660 = env47661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110666 env47660 == env47661) = true)

theorem identity47661 : scanCanonicalize (H12AffineFastState.compose env47661 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47661 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,49169,262144,1025,32769,102678,264532,98630,98645,349,64,67926,103494,17664,360791,99330,351490,257,21793,38224,33280]

theorem envBound47662 : H12AffineFastState.Bounded env47662 := by
  intro p hp
  have h : env47662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47661_47662 : H12AffineEnvironment.transform 12 348 env47661 = env47662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47661 == env47662) = true)

theorem identity47662 : scanCanonicalize (H12AffineFastState.compose env47662 (packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound47662 : packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env47663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54278,49169,262144,1025,32769,17680,264532,21824,21843,349,64,56656,16448,17664,283985,20484,297220,257,21793,38224,33280]

theorem envBound47663 : H12AffineFastState.Bounded env47663 := by
  intro p hp
  have h : env47663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47662_47663 : H12AffineEnvironment.transform 15 54278 env47662 = env47663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env47662 == env47663) = true)

theorem identity47663 : scanCanonicalize (H12AffineFastState.compose env47663 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound47663 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env47664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,33110,38209,262144,1025,32769,4160,264532,16,3,349,64,34816,5392,4176,262145,1364,297220,257,113,38224,33280]

theorem envBound47664 : H12AffineFastState.Bounded env47664 := by
  intro p hp
  have h : env47664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47663_47664 : H12AffineEnvironment.transform 13 5456 env47663 = env47664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env47663 == env47664) = true)

theorem identity47664 : scanCanonicalize (H12AffineFastState.compose env47664 (packedSelected [0,1,2,4,6,7,8,9,10,12,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 36112) := by decide +kernel

theorem selectedBound47664 : packedSelected [0,1,2,4,6,7,8,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env47665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,33110,38209,36112,1025,32769,4160,33860,16,3,349,64,34816,5392,4176,36113,1364,1044,257,113,38224,33280]

theorem envBound47665 : H12AffineFastState.Bounded env47665 := by
  intro p hp
  have h : env47665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47664_47665 : H12AffineEnvironment.transform 17 36112 env47664 = env47665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 36112 env47664 == env47665) = true)

theorem identity47665 : scanCanonicalize (H12AffineFastState.compose env47665 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47665 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,1,343,5440,3345,1025,0,4160,1093,16,3,349,64,2049,5392,4176,3344,1364,1044,257,113,5457,513]

theorem envBound47666 : H12AffineFastState.Bounded env47666 := by
  intro p hp
  have h : env47666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47665_47666 : H12AffineEnvironment.transform 14 1 env47665 = env47666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47665 == env47666) = true)

theorem identity47666 : scanCanonicalize (H12AffineFastState.compose env47666 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound47666 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47667 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,348,4112,1,343,4096,2129,321,0,4160,261,16,3,349,64,2049,4176,4176,2128,20,340,257,113,4113,513]

theorem envBound47667 : H12AffineFastState.Bounded env47667 := by
  intro p hp
  have h : env47667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47666_47667 : H12AffineEnvironment.transform 9 320 env47666 = env47667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47666 == env47667) = true)

theorem identity47667 : scanCanonicalize (H12AffineFastState.compose env47667 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47667 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47668 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4112,1,262,4096,2048,272,0,4113,261,16,3,268,17,2049,4097,4097,2049,20,261,257,32,4113,513]

theorem envBound47668 : H12AffineFastState.Bounded env47668 := by
  intro p hp
  have h : env47668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47667_47668 : H12AffineEnvironment.transform 5 17 env47667 = env47668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47667 == env47668) = true)

theorem identity47668 : scanCanonicalize (H12AffineFastState.compose env47668 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound47668 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47669 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,269,16,1,262,0,2048,272,0,17,261,16,3,268,17,2049,1,1,2049,20,261,257,32,17,513]

theorem envBound47669 : H12AffineFastState.Bounded env47669 := by
  intro p hp
  have h : env47669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47668_47669 : H12AffineEnvironment.transform 11 0 env47668 = env47669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env47668 == env47669) = true)

theorem identity47669 : scanCanonicalize (H12AffineFastState.compose env47669 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound47669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47670 : List Nat := [2,4,8,16,32,17,9,256,512,273,554,0,269,16,1,262,0,554,272,0,17,261,16,3,268,17,555,1,1,555,20,261,257,32,17,513]

theorem envBound47670 : H12AffineFastState.Bounded env47670 := by
  intro p hp
  have h : env47670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47669_47670 : H12AffineEnvironment.transform 10 554 env47669 = env47670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env47669 == env47670) = true)

def env47671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound47671 : H12AffineFastState.Bounded env47671 := by
  intro p hp
  have h : env47671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46918_47671 : H12AffineEnvironment.transform 25 65 env46918 = env47671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env46918 == env47671) = true)

def env47672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound47672 : H12AffineFastState.Bounded env47672 := by
  intro p hp
  have h : env47672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47671_47672 : H12AffineEnvironment.transform 26 30393344 env47671 = env47672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env47671 == env47672) = true)

def env47673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound47673 : H12AffineFastState.Bounded env47673 := by
  intro p hp
  have h : env47673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47672_47673 : H12AffineEnvironment.transform 18 1024 env47672 = env47673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env47672 == env47673) = true)

theorem identity47673 : scanCanonicalize (H12AffineFastState.compose env47673 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396461) := by decide +kernel

theorem selectedBound47673 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,8388608,16777216,8328,65,29868032,17270816,8804860,8830976,25265168,21457260,256,25675776,25635236,25207751]

theorem envBound47674 : H12AffineFastState.Bounded env47674 := by
  intro p hp
  have h : env47674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47673_47674 : H12AffineEnvironment.transform 20 396461 env47673 = env47674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396461 env47673 == env47674) = true)

def env47675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,8388608,8887584,8328,65,4218144,8393984,8804860,8830976,399664,12645452,256,21792,46212,474855]

theorem envBound47675 : H12AffineFastState.Bounded env47675 := by
  intro p hp
  have h : env47675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47674_47675 : H12AffineEnvironment.transform 23 8887584 env47674 = env47675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887584 env47674 == env47675) = true)

def env47676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452648,95496,8328,65,4218144,458024,45524,10280,399664,4594788,256,21792,46212,474855]

theorem envBound47676 : H12AffineFastState.Bounded env47676 := by
  intro p hp
  have h : env47676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47675_47676 : H12AffineEnvironment.transform 22 452648 env47675 = env47676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env47675 == env47676) = true)

def env47677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452648,95496,8328,65,292256,458024,45524,10280,399664,144612,256,21792,46212,474855]

theorem envBound47677 : H12AffineFastState.Bounded env47677 := by
  intro p hp
  have h : env47677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47676_47677 : H12AffineEnvironment.transform 21 272512 env47676 = env47677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47676 == env47677) = true)

theorem identity47677 : scanCanonicalize (H12AffineFastState.compose env47677 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound47677 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4161,144492,62660,95496,8328,65,158028,57796,45524,10280,1500,144612,256,21792,46212,74251]

theorem envBound47678 : H12AffineFastState.Bounded env47678 := by
  intro p hp
  have h : env47678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47677_47678 : H12AffineEnvironment.transform 17 138476 env47677 = env47678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env47677 == env47678) = true)

theorem identity47678 : scanCanonicalize (H12AffineFastState.compose env47678 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47678 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env47679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138476,1024,32769,4161,144492,62660,21762,8328,65,158028,57796,45524,10280,1500,144612,256,21792,46212,513]

theorem envBound47679 : H12AffineFastState.Bounded env47679 := by
  intro p hp
  have h : env47679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47678_47679 : H12AffineEnvironment.transform 15 8202 env47678 = env47679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47678 == env47679) = true)

theorem identity47679 : scanCanonicalize (H12AffineFastState.compose env47679 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound47679 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env47680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,2421,1024,32769,4161,8693,62660,21762,8328,65,31957,57796,45524,10280,1500,8573,256,21792,46212,513]

theorem envBound47680 : H12AffineFastState.Bounded env47680 := by
  intro p hp
  have h : env47680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47679_47680 : H12AffineEnvironment.transform 16 5529 env47679 = env47680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env47679 == env47680) = true)

theorem identity47680 : scanCanonicalize (H12AffineFastState.compose env47680 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47680 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env47681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,5529,2421,1024,32769,4161,33,54544,21762,348,65,23809,49168,36864,2556,1500,169,256,21792,38224,513]

theorem envBound47681 : H12AffineFastState.Bounded env47681 := by
  intro p hp
  have h : env47681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47680_47681 : H12AffineEnvironment.transform 12 468 env47680 = env47681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47680 == env47681) = true)

theorem identity47681 : scanCanonicalize (H12AffineFastState.compose env47681 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound47681 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env47682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,32768,478,5529,2421,1024,32769,4161,33,34048,1298,348,65,3345,36864,36864,2556,1500,169,256,1328,38224,513]

theorem envBound47682 : H12AffineFastState.Bounded env47682 := by
  intro p hp
  have h : env47682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47681_47682 : H12AffineEnvironment.transform 13 4112 env47681 = env47682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env47681 == env47682) = true)

theorem identity47682 : scanCanonicalize (H12AffineFastState.compose env47682 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 7561) := by decide +kernel

theorem selectedBound47682 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env47683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,7561,478,5529,2421,1024,7560,4161,33,6281,1298,348,65,3345,3465,3465,2556,1500,169,256,1328,2265,513]

theorem envBound47683 : H12AffineFastState.Bounded env47683 := by
  intro p hp
  have h : env47683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47682_47683 : H12AffineEnvironment.transform 14 7561 env47682 = env47683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7561 env47682 == env47683) = true)

theorem identity47683 : scanCanonicalize (H12AffineFastState.compose env47683 (packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47683 : packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4112,7425,342,5393,2421,1024,7424,4161,33,6145,1298,348,65,3345,3329,3329,2420,1364,33,256,1328,2129,513]

theorem envBound47684 : H12AffineFastState.Bounded env47684 := by
  intro p hp
  have h : env47684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47683_47684 : H12AffineEnvironment.transform 6 8 env47683 = env47684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47683 == env47684) = true)

theorem identity47684 : scanCanonicalize (H12AffineFastState.compose env47684 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47684 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47685 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4112,6160,342,4096,2421,273,6161,4161,33,6145,3,348,65,2048,2064,2064,2420,69,33,256,33,2129,513]

theorem envBound47685 : H12AffineFastState.Bounded env47685 := by
  intro p hp
  have h : env47685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47684_47685 : H12AffineEnvironment.transform 9 273 env47684 = env47685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47684 == env47685) = true)

theorem identity47685 : scanCanonicalize (H12AffineFastState.compose env47685 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound47685 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env47686 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2064,348,2048,0,342,2064,2421,273,1,2129,33,17,3,348,65,2048,2064,2064,2420,69,33,256,33,2129,513]

theorem envBound47686 : H12AffineFastState.Bounded env47686 := by
  intro p hp
  have h : env47686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47685_47686 : H12AffineEnvironment.transform 11 2064 env47685 = env47686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env47685 == env47686) = true)

theorem identity47686 : scanCanonicalize (H12AffineFastState.compose env47686 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound47686 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47687 : List Nat := [2,4,8,16,32,64,8,52,512,37,2048,2064,104,2048,0,98,2064,2113,37,1,2129,33,17,3,104,65,2048,2064,2064,2112,69,33,52,33,2129,513]

theorem envBound47687 : H12AffineFastState.Bounded env47687 := by
  intro p hp
  have h : env47687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47686_47687 : H12AffineEnvironment.transform 7 52 env47686 = env47687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env47686 == env47687) = true)

theorem identity47687 : scanCanonicalize (H12AffineFastState.compose env47687 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound47687 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47688 : List Nat := [2,4,8,16,32,64,8,52,512,37,513,529,104,513,0,98,529,576,37,1,592,33,17,3,104,65,513,529,529,577,69,33,52,33,592,513]

theorem envBound47688 : H12AffineFastState.Bounded env47688 := by
  intro p hp
  have h : env47688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47687_47688 : H12AffineEnvironment.transform 10 513 env47687 = env47688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env47687 == env47688) = true)

theorem identity47688 : scanCanonicalize (H12AffineFastState.compose env47688 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47688 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47689 : List Nat := [2,4,8,16,32,64,8,52,1,37,0,16,104,0,0,98,16,65,37,1,81,33,17,3,104,65,0,16,16,64,69,33,52,33,81,0]

theorem envBound47689 : H12AffineFastState.Bounded env47689 := by
  intro p hp
  have h : env47689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47688_47689 : H12AffineEnvironment.transform 8 1 env47688 = env47689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47688 == env47689) = true)

theorem identity47689 : scanCanonicalize (H12AffineFastState.compose env47689 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47690 : List Nat := [2,4,8,1,32,64,8,37,1,37,0,1,104,0,0,98,1,65,37,1,64,33,0,3,104,65,0,1,1,64,69,33,37,33,64,0]

theorem envBound47690 : H12AffineFastState.Bounded env47690 := by
  intro p hp
  have h : env47690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47689_47690 : H12AffineEnvironment.transform 3 1 env47689 = env47690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47689 == env47690) = true)

theorem identity47690 : scanCanonicalize (H12AffineFastState.compose env47690 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47691 : List Nat := [2,4,2,1,32,64,2,37,1,37,0,1,98,0,0,98,1,65,37,1,64,33,0,3,98,65,0,1,1,64,69,33,37,33,64,0]

theorem envBound47691 : H12AffineFastState.Bounded env47691 := by
  intro p hp
  have h : env47691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47690_47691 : H12AffineEnvironment.transform 2 2 env47690 = env47691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47690 == env47691) = true)

theorem identity47691 : scanCanonicalize (H12AffineFastState.compose env47691 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47691 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47692 : List Nat := [2,4,2,1,32,0,2,37,1,37,0,1,34,0,0,34,1,1,37,1,0,33,0,3,34,1,0,1,1,0,5,33,37,33,0,0]

theorem envBound47692 : H12AffineFastState.Bounded env47692 := by
  intro p hp
  have h : env47692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47691_47692 : H12AffineEnvironment.transform 5 0 env47691 = env47692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47691 == env47692) = true)

def env47693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452648,95496,8328,65,292257,458024,45524,10280,399664,144613,256,21792,46212,474855]

theorem envBound47693 : H12AffineFastState.Bounded env47693 := by
  intro p hp
  have h : env47693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47676_47693 : H12AffineEnvironment.transform 21 272513 env47676 = env47693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47676 == env47693) = true)

theorem identity47693 : scanCanonicalize (H12AffineFastState.compose env47693 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound47693 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396461,272513,400636,95496,8328,65,292257,395772,17664,10280,399664,144613,256,21792,16464,474855]

theorem envBound47694 : H12AffineFastState.Bounded env47694 := by
  intro p hp
  have h : env47694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47693_47694 : H12AffineEnvironment.transform 14 29908 env47693 = env47694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env47693 == env47694) = true)

def env47695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140301,33,144476,95496,8328,65,23809,139612,17664,10280,143760,144613,256,21792,16464,202311]

theorem envBound47695 : H12AffineFastState.Bounded env47695 := by
  intro p hp
  have h : env47695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47694_47695 : H12AffineEnvironment.transform 17 10400 env47694 = env47695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47694 == env47695) = true)

theorem identity47695 : scanCanonicalize (H12AffineFastState.compose env47695 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound47695 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env47696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,131072,10400,1024,29909,140301,33,144476,29910,8328,65,23809,139612,17664,10280,143760,144613,256,21792,16464,137113]

theorem envBound47696 : H12AffineFastState.Bounded env47696 := by
  intro p hp
  have h : env47696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47695_47696 : H12AffineEnvironment.transform 15 478 env47695 = env47696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env47695 == env47696) = true)

theorem identity47696 : scanCanonicalize (H12AffineFastState.compose env47696 (packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound47696 : packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,5528,10400,1024,29909,12693,33,8644,29910,8328,65,23809,13508,17664,10280,9224,8573,256,21792,16464,513]

theorem envBound47697 : H12AffineFastState.Bounded env47697 := by
  intro p hp
  have h : env47697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47696_47697 : H12AffineEnvironment.transform 16 5528 env47696 = env47697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env47696 == env47697) = true)

theorem identity47697 : scanCanonicalize (H12AffineFastState.compose env47697 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound47697 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,478,5528,2421,1024,21760,4160,33,17,21763,349,65,23809,5393,17664,2557,1501,168,256,21792,16464,513]

theorem envBound47698 : H12AffineFastState.Bounded env47698 := by
  intro p hp
  have h : env47698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47697_47698 : H12AffineEnvironment.transform 12 469 env47697 = env47698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env47697 == env47698) = true)

theorem identity47698 : scanCanonicalize (H12AffineFastState.compose env47698 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound47698 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env47699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,478,5528,2421,1024,137,4160,33,17,138,349,65,2184,5393,4233,2557,1501,168,256,169,5593,513]

theorem envBound47699 : H12AffineFastState.Bounded env47699 := by
  intro p hp
  have h : env47699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47698_47699 : H12AffineEnvironment.transform 13 5513 env47698 = env47699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47698 == env47699) = true)

theorem identity47699 : scanCanonicalize (H12AffineFastState.compose env47699 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47699 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env47700 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,160,5372,136,171,5357,2048,1024,137,4160,33,17,138,40,65,2184,5220,4233,2184,1192,168,117,169,5292,513]

theorem envBound47700 : H12AffineFastState.Bounded env47700 := by
  intro p hp
  have h : env47700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47699_47700 : H12AffineEnvironment.transform 7 117 env47699 = env47700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47699 == env47700) = true)

theorem identity47700 : scanCanonicalize (H12AffineFastState.compose env47700 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound47700 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47701 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,120,5156,80,115,5173,2048,1024,81,4160,33,17,82,40,65,2128,5220,4177,2128,1136,112,117,113,5236,513]

theorem envBound47701 : H12AffineFastState.Bounded env47701 := by
  intro p hp
  have h : env47701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47700_47701 : H12AffineEnvironment.transform 6 88 env47700 = env47701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env47700 == env47701) = true)

def env47702 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,35,5173,2048,1024,1,4112,33,17,2,40,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound47702 : H12AffineFastState.Bounded env47702 := by
  intro p hp
  have h : env47702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47701_47702 : H12AffineEnvironment.transform 5 16 env47701 = env47702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47701 == env47702) = true)

def env47703 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1044,0,35,1029,2048,1024,1,32,33,17,2,40,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound47703 : H12AffineFastState.Bounded env47703 := by
  intro p hp
  have h : env47703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47702_47703 : H12AffineEnvironment.transform 11 48 env47702 = env47703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47702 == env47703) = true)

theorem identity47703 : scanCanonicalize (H12AffineFastState.compose env47703 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound47703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47704 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1045,48,40,1044,0,35,1029,1045,1024,1,32,33,17,2,40,17,1045,1028,49,1045,1056,32,37,33,1044,513]

theorem envBound47704 : H12AffineFastState.Bounded env47704 := by
  intro p hp
  have h : env47704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47703_47704 : H12AffineEnvironment.transform 10 1045 env47703 = env47704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env47703 == env47704) = true)

def env47705 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,40,32,0,35,49,33,52,1,32,33,17,2,40,17,33,48,49,33,20,32,37,33,32,513]

theorem envBound47705 : H12AffineFastState.Bounded env47705 := by
  intro p hp
  have h : env47705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47704_47705 : H12AffineEnvironment.transform 9 52 env47704 = env47705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47704 == env47705) = true)

def env47706 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,48,40,33,0,35,48,32,53,1,32,33,17,2,40,17,32,49,49,32,21,32,37,33,33,513]

theorem envBound47706 : H12AffineFastState.Bounded env47706 := by
  intro p hp
  have h : env47706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47704_47706 : H12AffineEnvironment.transform 9 53 env47704 = env47706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47704 == env47706) = true)

theorem identity47706 : scanCanonicalize (H12AffineFastState.compose env47706 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47706 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47707 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,48,40,33,0,35,48,32,53,1,32,33,17,2,40,17,32,49,49,32,21,32,37,33,33,42]

theorem envBound47707 : H12AffineFastState.Bounded env47707 := by
  intro p hp
  have h : env47707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47706_47707 : H12AffineEnvironment.transform 8 43 env47706 = env47707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47706 == env47707) = true)

def leafEnv47707 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,48,40,33,0,35,48,32,53,1,32,33,17,2,21,40,1,17,32,49,49,32,21,32,37,33,4,35,33,42,1,32,0]

def active47707 : List Nat := [0,1,2,3,4]

def tree47707 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47707 : H12WitnessSearch.Good tree47707 := H12GlobalWitnessIndex.good

theorem leafIdentity47707 : H12AffineFastState.composeSystem env47707 rootObs = leafEnv47707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47707 rootObs == leafEnv47707) = true)

theorem terminalChecked47707 : H12PackedTerminal.terminalCheckFast leafEnv47707 active47707 tree47707 = true := by decide +kernel

def env47708 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1045,0,35,1028,2048,1024,1,33,33,17,2,40,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound47708 : H12AffineFastState.Bounded env47708 := by
  intro p hp
  have h : env47708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47702_47708 : H12AffineEnvironment.transform 11 49 env47702 = env47708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47702 == env47708) = true)

theorem identity47708 : scanCanonicalize (H12AffineFastState.compose env47708 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound47708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47709 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,49,40,1045,0,35,1028,33,1024,1,33,33,17,2,40,17,33,1029,48,33,1056,32,37,33,1045,513]

theorem envBound47709 : H12AffineFastState.Bounded env47709 := by
  intro p hp
  have h : env47709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47708_47709 : H12AffineEnvironment.transform 10 33 env47708 = env47709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env47708 == env47709) = true)

def env47710 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,49,40,33,0,35,48,33,52,1,33,33,17,2,40,17,33,49,48,33,20,32,37,33,33,513]

theorem envBound47710 : H12AffineFastState.Bounded env47710 := by
  intro p hp
  have h : env47710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47709_47710 : H12AffineEnvironment.transform 9 52 env47709 = env47710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47709 == env47710) = true)

def env47711 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,40,32,0,35,49,33,53,1,33,33,17,2,40,17,33,48,48,33,21,32,37,33,32,513]

theorem envBound47711 : H12AffineFastState.Bounded env47711 := by
  intro p hp
  have h : env47711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47709_47711 : H12AffineEnvironment.transform 9 53 env47709 = env47711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47709 == env47711) = true)

theorem identity47711 : scanCanonicalize (H12AffineFastState.compose env47711 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound47711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47712 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,49,40,32,0,35,49,33,53,1,33,33,17,2,40,17,33,48,48,33,21,32,37,33,32,43]

theorem envBound47712 : H12AffineFastState.Bounded env47712 := by
  intro p hp
  have h : env47712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47711_47712 : H12AffineEnvironment.transform 8 42 env47711 = env47712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env47711 == env47712) = true)

def leafEnv47712 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,49,40,32,0,35,49,33,53,1,33,33,17,2,21,40,1,17,33,48,48,33,21,32,37,33,4,35,32,43,1,33,0]

def active47712 : List Nat := [0,1,2,3,4]

def tree47712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47712 : H12WitnessSearch.Good tree47712 := H12GlobalWitnessIndex.good

theorem leafIdentity47712 : H12AffineFastState.composeSystem env47712 rootObs = leafEnv47712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47712 rootObs == leafEnv47712) = true)

theorem terminalChecked47712 : H12PackedTerminal.terminalCheckFast leafEnv47712 active47712 tree47712 = true := by decide +kernel

def env47713 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4113,33,17,3,40,16,2049,5173,4096,2049,1057,33,36,32,5157,513]

theorem envBound47713 : H12AffineFastState.Bounded env47713 := by
  intro p hp
  have h : env47713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47701_47713 : H12AffineEnvironment.transform 5 17 env47701 = env47713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47701 == env47713) = true)

theorem identity47713 : scanCanonicalize (H12AffineFastState.compose env47713 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47714 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4112,1,34,4097,2048,52,0,4113,33,17,3,40,16,2049,4097,4096,2049,21,33,36,32,4113,513]

theorem envBound47714 : H12AffineFastState.Bounded env47714 := by
  intro p hp
  have h : env47714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47713_47714 : H12AffineEnvironment.transform 9 52 env47713 = env47714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47713 == env47714) = true)

theorem identity47714 : scanCanonicalize (H12AffineFastState.compose env47714 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound47714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47715 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,32,41,48,1,34,33,2048,52,0,49,33,17,3,40,16,2049,33,32,2049,21,33,36,32,49,513]

theorem envBound47715 : H12AffineFastState.Bounded env47715 := by
  intro p hp
  have h : env47715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47714_47715 : H12AffineEnvironment.transform 11 32 env47714 = env47715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env47714 == env47715) = true)

theorem identity47715 : scanCanonicalize (H12AffineFastState.compose env47715 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound47715 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47716 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,41,48,1,34,33,49,52,0,49,33,17,3,40,16,48,33,32,48,21,33,36,32,49,513]

theorem envBound47716 : H12AffineFastState.Bounded env47716 := by
  intro p hp
  have h : env47716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47715_47716 : H12AffineEnvironment.transform 10 49 env47715 = env47716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env47715 == env47716) = true)

def leafEnv47716 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,41,48,1,34,33,49,52,0,49,33,17,3,21,40,1,16,48,33,32,48,21,33,36,32,4,35,49,513,1,48,0]

def active47716 : List Nat := [0,1,2,3,4,8]

def tree47716 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47716 : H12WitnessSearch.Good tree47716 := H12GlobalWitnessIndex.good

theorem leafIdentity47716 : H12AffineFastState.composeSystem env47716 rootObs = leafEnv47716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47716 rootObs == leafEnv47716) = true)

theorem terminalChecked47716 : H12PackedTerminal.terminalCheckFast leafEnv47716 active47716 tree47716 = true := by decide +kernel

def env47717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140300,32,144477,95496,8328,65,23808,139613,17664,10280,143761,144613,256,21792,16464,202310]

theorem envBound47717 : H12AffineFastState.Bounded env47717 := by
  intro p hp
  have h : env47717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47694_47717 : H12AffineEnvironment.transform 17 10401 env47694 = env47717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47694 == env47717) = true)

theorem identity47717 : scanCanonicalize (H12AffineFastState.compose env47717 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound47717 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env47718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,10401,1024,29909,82966,32,87111,95496,8328,65,23808,82247,17664,10280,86411,87295,256,21792,16464,30300]

theorem envBound47718 : H12AffineFastState.Bounded env47718 := by
  intro p hp
  have h : env47718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47717_47718 : H12AffineEnvironment.transform 16 90138 env47717 = env47718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env47717 == env47718) = true)

theorem identity47718 : scanCanonicalize (H12AffineFastState.compose env47718 (packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound47718 : packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21646,13460,10401,1024,29909,4248,32,201,8582,8328,65,23808,5577,17664,10280,1285,113,256,21792,16464,30300]

theorem envBound47719 : H12AffineFastState.Bounded env47719 := by
  intro p hp
  have h : env47719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47718_47719 : H12AffineEnvironment.transform 15 21646 env47718 = env47719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env47718 == env47719) = true)

theorem identity47719 : scanCanonicalize (H12AffineFastState.compose env47719 (packedSelected [5,8,10,16,19,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47719 : packedSelected [5,8,10,16,19,20,24,28] rootPS < 2^1333 := by decide +kernel

def env47720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,8403,13460,10401,1024,136,4248,32,201,8582,8328,65,10589,5577,12637,10280,1285,113,256,8573,13325,513]

theorem envBound47720 : H12AffineFastState.Bounded env47720 := by
  intro p hp
  have h : env47720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47719_47720 : H12AffineEnvironment.transform 13 13405 env47719 = env47720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47719 == env47720) = true)

theorem identity47720 : scanCanonicalize (H12AffineFastState.compose env47720 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47720 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8283,13340,10281,1024,0,4112,32,65,8462,8192,65,10589,5441,12637,10280,1285,113,256,8573,13325,513]

theorem envBound47721 : H12AffineFastState.Bounded env47721 := by
  intro p hp
  have h : env47721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47720_47721 : H12AffineEnvironment.transform 6 8 env47720 = env47721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47720 == env47721) = true)

theorem identity47721 : scanCanonicalize (H12AffineFastState.compose env47721 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound47721 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env47722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2396,7425,1,2311,7488,373,1024,0,4112,32,65,2130,2396,65,1,5441,6145,372,1285,113,256,2081,7505,513]

theorem envBound47722 : H12AffineFastState.Bounded env47722 := by
  intro p hp
  have h : env47722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47721_47722 : H12AffineEnvironment.transform 12 2396 env47721 = env47722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env47721 == env47722) = true)

theorem identity47722 : scanCanonicalize (H12AffineFastState.compose env47722 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound47722 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,2396,1345,1,2311,1280,373,1024,0,2128,32,65,2130,2396,65,1,3329,65,372,1285,113,256,2081,1297,513]

theorem envBound47723 : H12AffineFastState.Bounded env47723 := by
  intro p hp
  have h : env47723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47722_47723 : H12AffineEnvironment.transform 11 2112 env47722 = env47723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env47722 == env47723) = true)

theorem identity47723 : scanCanonicalize (H12AffineFastState.compose env47723 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound47723 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env47724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1281,1053,1345,1,1094,1280,373,1024,0,1297,32,65,1299,1053,65,1,64,65,372,1285,113,256,1376,1297,513]

theorem envBound47724 : H12AffineFastState.Bounded env47724 := by
  intro p hp
  have h : env47724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47723_47724 : H12AffineEnvironment.transform 10 1345 env47723 = env47724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env47723 == env47724) = true)

theorem identity47724 : scanCanonicalize (H12AffineFastState.compose env47724 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47724 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env47725 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,16,268,80,1,343,17,373,273,0,0,32,65,2,268,65,1,64,65,372,20,113,256,113,0,513]

theorem envBound47725 : H12AffineFastState.Bounded env47725 := by
  intro p hp
  have h : env47725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47724_47725 : H12AffineEnvironment.transform 9 273 env47724 = env47725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47724 == env47725) = true)

theorem identity47725 : scanCanonicalize (H12AffineFastState.compose env47725 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47725 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47726 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,16,41,80,1,114,17,80,52,0,0,32,65,2,41,65,1,64,65,81,20,113,37,113,0,513]

theorem envBound47726 : H12AffineFastState.Bounded env47726 := by
  intro p hp
  have h : env47726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47725_47726 : H12AffineEnvironment.transform 7 37 env47725 = env47726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47725 == env47726) = true)

theorem identity47726 : scanCanonicalize (H12AffineFastState.compose env47726 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound47726 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env47727 : List Nat := [2,4,8,16,32,64,8,37,113,52,80,16,41,80,1,114,17,80,52,0,0,32,65,2,41,65,1,64,65,81,20,113,37,113,0,112]

theorem envBound47727 : H12AffineFastState.Bounded env47727 := by
  intro p hp
  have h : env47727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47726_47727 : H12AffineEnvironment.transform 8 113 env47726 = env47727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env47726 == env47727) = true)

theorem identity47727 : scanCanonicalize (H12AffineFastState.compose env47727 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47728 : List Nat := [2,4,8,16,32,16,8,37,33,52,0,16,41,0,1,34,17,0,52,0,0,32,17,2,41,17,1,16,17,1,20,33,37,33,0,32]

theorem envBound47728 : H12AffineFastState.Bounded env47728 := by
  intro p hp
  have h : env47728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47727_47728 : H12AffineEnvironment.transform 5 16 env47727 = env47728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47727 == env47728) = true)

theorem identity47728 : scanCanonicalize (H12AffineFastState.compose env47728 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47729 : List Nat := [2,4,8,16,17,16,8,20,16,5,0,16,24,0,1,19,17,0,5,0,0,17,17,2,24,17,1,16,17,1,20,16,20,16,0,17]

theorem envBound47729 : H12AffineFastState.Bounded env47729 := by
  intro p hp
  have h : env47729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47728_47729 : H12AffineEnvironment.transform 4 17 env47728 = env47729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47728 == env47729) = true)

def env47730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452649,95497,8328,65,4218144,458025,45525,10281,399664,4594789,256,21792,46212,474855]

theorem envBound47730 : H12AffineFastState.Bounded env47730 := by
  intro p hp
  have h : env47730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47675_47730 : H12AffineEnvironment.transform 22 452649 env47675 = env47730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env47675 == env47730) = true)

def env47731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452649,95497,8328,65,292256,458025,45525,10281,399664,144613,256,21792,46212,474855]

theorem envBound47731 : H12AffineFastState.Bounded env47731 := by
  intro p hp
  have h : env47731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47730_47731 : H12AffineEnvironment.transform 21 272512 env47730 = env47731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47730 == env47731) = true)

theorem identity47731 : scanCanonicalize (H12AffineFastState.compose env47731 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound47731 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58516,180409,16,95497,8328,65,171417,5392,45525,10281,61705,144613,256,21792,46212,120542]

theorem envBound47732 : H12AffineFastState.Bounded env47732 := by
  intro p hp
  have h : env47732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47731_47732 : H12AffineEnvironment.transform 17 190521 env47731 = env47732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env47731 == env47732) = true)

def env47733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58396,180273,16,95497,8192,65,171281,5392,45405,10281,61705,144493,256,21792,46092,120406]

theorem envBound47733 : H12AffineFastState.Bounded env47733 := by
  intro p hp
  have h : env47733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47732_47733 : H12AffineEnvironment.transform 6 8 env47732 = env47733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47732 == env47733) = true)

theorem identity47733 : scanCanonicalize (H12AffineFastState.compose env47733 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound47733 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58396,32,16,95497,8192,65,23808,5392,45405,10281,61705,62588,256,21792,46092,120406]

theorem envBound47734 : H12AffineFastState.Bounded env47734 := by
  intro p hp
  have h : env47734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47733_47734 : H12AffineEnvironment.transform 16 49169 env47733 = env47734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47733 == env47734) = true)

theorem identity47734 : scanCanonicalize (H12AffineFastState.compose env47734 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound47734 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21510,49169,10280,1024,32769,58396,32,16,8463,8192,65,23808,5392,45405,10281,61705,62588,256,21792,46092,33360]

theorem envBound47735 : H12AffineFastState.Bounded env47735 := by
  intro p hp
  have h : env47735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47734_47735 : H12AffineEnvironment.transform 15 21510 env47734 = env47735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env47734 == env47735) = true)

theorem identity47735 : scanCanonicalize (H12AffineFastState.compose env47735 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47735 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env47736 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,21510,49169,10280,1024,32769,58396,32,16,8463,8192,17,23808,5392,45325,10281,61705,62508,256,21792,46092,33280]

theorem envBound47736 : H12AffineFastState.Bounded env47736 := by
  intro p hp
  have h : env47736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47735_47736 : H12AffineEnvironment.transform 5 16 env47735 = env47736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47735 == env47736) = true)

theorem identity47736 : scanCanonicalize (H12AffineFastState.compose env47736 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47736 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env47737 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,21510,16401,10280,1024,1,25628,32,16,8463,8192,17,23808,5392,12557,10281,28937,29740,256,21792,13324,512]

theorem envBound47737 : H12AffineFastState.Bounded env47737 := by
  intro p hp
  have h : env47737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47736_47737 : H12AffineEnvironment.transform 14 0 env47736 = env47737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47736 == env47737) = true)

theorem identity47737 : scanCanonicalize (H12AffineFastState.compose env47737 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound47737 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47738 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,301,16384,0,21510,16401,2309,1024,1,17713,32,16,34,301,17,23808,5392,4128,2308,20516,21761,256,21792,5409,512]

theorem envBound47738 : H12AffineFastState.Bounded env47738 := by
  intro p hp
  have h : env47738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47737_47738 : H12AffineEnvironment.transform 12 301 env47737 = env47738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env47737 == env47738) = true)

theorem identity47738 : scanCanonicalize (H12AffineFastState.compose env47738 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47738 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47739 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,301,5376,0,262,5393,2309,1024,1,4145,32,16,34,301,17,2048,5392,4128,2308,1316,1,256,32,5409,512]

theorem envBound47739 : H12AffineFastState.Bounded env47739 := by
  intro p hp
  have h : env47739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47738_47739 : H12AffineEnvironment.transform 13 5376 env47738 = env47739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47738 == env47739) = true)

theorem identity47739 : scanCanonicalize (H12AffineFastState.compose env47739 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound47739 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env47740 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1312,301,32,0,262,49,2309,1024,1,1297,32,16,34,301,17,2048,48,1280,2308,1316,1,256,32,1,512]

theorem envBound47740 : H12AffineFastState.Bounded env47740 := by
  intro p hp
  have h : env47740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47739_47740 : H12AffineEnvironment.transform 11 1312 env47739 = env47740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env47739 == env47740) = true)

theorem identity47740 : scanCanonicalize (H12AffineFastState.compose env47740 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47740 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47741 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,48,301,32,0,262,49,2309,272,1,1,32,16,34,301,17,2048,48,16,2308,52,1,256,32,1,512]

theorem envBound47741 : H12AffineFastState.Bounded env47741 := by
  intro p hp
  have h : env47741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47740_47741 : H12AffineEnvironment.transform 9 272 env47740 = env47741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47740 == env47741) = true)

theorem identity47741 : scanCanonicalize (H12AffineFastState.compose env47741 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound47741 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47742 : List Nat := [2,4,8,16,32,16,8,256,512,272,292,48,301,32,0,262,49,33,272,1,1,32,16,34,301,17,292,48,16,32,52,1,256,32,1,512]

theorem envBound47742 : H12AffineFastState.Bounded env47742 := by
  intro p hp
  have h : env47742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47741_47742 : H12AffineEnvironment.transform 10 292 env47741 = env47742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env47741 == env47742) = true)

theorem identity47742 : scanCanonicalize (H12AffineFastState.compose env47742 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47742 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47743 : List Nat := [2,4,8,16,32,16,8,5,512,21,33,48,40,32,0,3,49,33,21,1,1,32,16,34,40,17,33,48,16,32,52,1,5,32,1,512]

theorem envBound47743 : H12AffineFastState.Bounded env47743 := by
  intro p hp
  have h : env47743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47742_47743 : H12AffineEnvironment.transform 7 5 env47742 = env47743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47742 == env47743) = true)

def env47744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58397,180272,16,95497,8193,65,171280,5392,45404,10281,61705,144492,256,21792,46093,120407]

theorem envBound47744 : H12AffineFastState.Bounded env47744 := by
  intro p hp
  have h : env47744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47732_47744 : H12AffineEnvironment.transform 6 9 env47732 = env47744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47732 == env47744) = true)

theorem identity47744 : scanCanonicalize (H12AffineFastState.compose env47744 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound47744 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,35188,1024,32769,58397,41341,16,95497,8193,65,64605,5392,45404,10281,61705,21793,256,21792,46093,120407]

theorem envBound47745 : H12AffineFastState.Bounded env47745 := by
  intro p hp
  have h : env47745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47744_47745 : H12AffineEnvironment.transform 16 24909 env47744 = env47745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env47744 == env47745) = true)

theorem identity47745 : scanCanonicalize (H12AffineFastState.compose env47745 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound47745 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env47746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,24909,35188,1024,32769,58397,41341,16,54530,8193,65,64605,5392,45404,10281,61705,21793,256,21792,46093,30300]

theorem envBound47746 : H12AffineFastState.Bounded env47746 := by
  intro p hp
  have h : env47746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47745_47746 : H12AffineEnvironment.transform 15 40971 env47745 = env47746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env47745 == env47746) = true)

theorem identity47746 : scanCanonicalize (H12AffineFastState.compose env47746 (packedSelected [1,3,4,8,9,10,12,14,15,18,19,20,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound47746 : packedSelected [1,3,4,8,9,10,12,14,15,18,19,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21540,29743,24909,23888,1024,21541,12345,30041,16,294,8193,65,10361,5392,25976,10281,9517,21793,256,21792,24617,30300]

theorem envBound47747 : H12AffineFastState.Bounded env47747 := by
  intro p hp
  have h : env47747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47746_47747 : H12AffineEnvironment.transform 14 21540 env47746 = env47747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env47746 == env47747) = true)

theorem identity47747 : scanCanonicalize (H12AffineFastState.compose env47747 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound47747 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env47748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21540,21591,16693,23888,1024,21541,4161,21793,16,294,121,65,2049,5392,17664,2129,1365,21793,256,21792,16465,22052]

theorem envBound47748 : H12AffineFastState.Bounded env47748 := by
  intro p hp
  have h : env47748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47747_47748 : H12AffineEnvironment.transform 12 120 env47747 = env47748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env47747 == env47748) = true)

theorem identity47748 : scanCanonicalize (H12AffineFastState.compose env47748 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound47748 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env47749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5456,372,263,5221,2048,1024,373,4161,113,16,294,121,65,2049,5392,4176,2129,1365,113,256,112,5377,884]

theorem envBound47749 : H12AffineFastState.Bounded env47749 := by
  intro p hp
  have h : env47749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47748_47749 : H12AffineEnvironment.transform 13 5456 env47748 = env47749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env47748 == env47749) = true)

def env47750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452649,95497,8328,65,292257,458025,45525,10281,399664,144612,256,21792,46212,474855]

theorem envBound47750 : H12AffineFastState.Bounded env47750 := by
  intro p hp
  have h : env47750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47730_47750 : H12AffineEnvironment.transform 21 272513 env47730 = env47750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47730 == env47750) = true)

def env47751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272393,452649,95497,8192,65,292137,458025,45405,10281,399664,144492,256,21792,46092,474735]

theorem envBound47751 : H12AffineFastState.Bounded env47751 := by
  intro p hp
  have h : env47751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47750_47751 : H12AffineEnvironment.transform 6 8 env47750 = env47751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47750 == env47751) = true)

def env47752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272393,272441,95497,8192,65,292137,277817,45405,10281,317728,62588,256,21792,46092,392831]

theorem envBound47752 : H12AffineFastState.Bounded env47752 := by
  intro p hp
  have h : env47752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47751_47752 : H12AffineEnvironment.transform 16 49168 env47751 = env47752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47751 == env47752) = true)

theorem identity47752 : scanCanonicalize (H12AffineFastState.compose env47752 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47752 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58397,33,17,95497,8192,65,23809,5393,45405,10281,61704,62588,256,21792,46092,120407]

theorem envBound47753 : H12AffineFastState.Bounded env47753 := by
  intro p hp
  have h : env47753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47752_47753 : H12AffineEnvironment.transform 17 10280 env47752 = env47753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47752 == env47753) = true)

theorem identity47753 : scanCanonicalize (H12AffineFastState.compose env47753 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound47753 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,10280,1024,32769,58397,33,17,41230,8192,65,23809,5393,45405,10281,61704,62588,256,21792,46092,592]

theorem envBound47754 : H12AffineFastState.Bounded env47754 := by
  intro p hp
  have h : env47754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47753_47754 : H12AffineEnvironment.transform 15 54279 env47753 = env47754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env47753 == env47754) = true)

theorem identity47754 : scanCanonicalize (H12AffineFastState.compose env47754 (packedSelected [2,4,6,11,16,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound47754 : packedSelected [2,4,6,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env47755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,342,5441,10280,1024,21840,12620,33,17,29791,8192,65,23809,5393,25612,10281,9305,8493,256,21792,24925,592]

theorem envBound47755 : H12AffineFastState.Bounded env47755 := by
  intro p hp
  have h : env47755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47754_47755 : H12AffineEnvironment.transform 14 21841 env47754 = env47755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env47754 == env47755) = true)

theorem identity47755 : scanCanonicalize (H12AffineFastState.compose env47755 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47755 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env47756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21841,342,5441,2340,1024,21840,4160,33,17,21843,268,65,23809,5393,17664,2341,1365,33,256,21792,16465,592]

theorem envBound47756 : H12AffineFastState.Bounded env47756 := by
  intro p hp
  have h : env47756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47755_47756 : H12AffineEnvironment.transform 12 268 env47755 = env47756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47755 == env47756) = true)

def env47757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272393,272440,95497,8192,65,292137,277816,45405,10281,317729,62589,256,21792,46092,392830]

theorem envBound47757 : H12AffineFastState.Bounded env47757 := by
  intro p hp
  have h : env47757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47751_47757 : H12AffineEnvironment.transform 16 49169 env47751 = env47757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47751 == env47757) = true)

theorem identity47757 : scanCanonicalize (H12AffineFastState.compose env47757 (packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound47757 : packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env47758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10360,1024,32769,58444,113,64,95497,8192,65,23889,5440,45405,10281,61785,62589,256,21792,46092,120326]

theorem envBound47758 : H12AffineFastState.Bounded env47758 := by
  intro p hp
  have h : env47758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47757_47758 : H12AffineEnvironment.transform 17 10360 env47757 = env47758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env47757 == env47758) = true)

theorem identity47758 : scanCanonicalize (H12AffineFastState.compose env47758 (packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound47758 : packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env47759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,49169,10360,1024,32769,58444,113,64,8543,8192,65,23889,5440,45405,10281,61785,62589,256,21792,46092,33360]

theorem envBound47759 : H12AffineFastState.Bounded env47759 := by
  intro p hp
  have h : env47759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47758_47759 : H12AffineEnvironment.transform 15 21590 env47758 = env47759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env47758 == env47759) = true)

theorem identity47759 : scanCanonicalize (H12AffineFastState.compose env47759 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47759 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env47760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21590,16400,10360,1024,0,25677,113,64,8543,8192,65,23889,5440,12636,10281,29016,29820,256,21792,13325,593]

theorem envBound47760 : H12AffineFastState.Bounded env47760 := by
  intro p hp
  have h : env47760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47759_47760 : H12AffineEnvironment.transform 14 1 env47759 = env47760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47759 == env47760) = true)

theorem identity47760 : scanCanonicalize (H12AffineFastState.compose env47760 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47760 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env47761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21590,16400,2341,1024,0,17680,113,64,2,349,65,23889,5440,4097,2420,20485,21793,256,21792,5456,593]

theorem envBound47761 : H12AffineFastState.Bounded env47761 := by
  intro p hp
  have h : env47761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47760_47761 : H12AffineEnvironment.transform 12 349 env47760 = env47761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47760 == env47761) = true)

theorem identity47761 : scanCanonicalize (H12AffineFastState.compose env47761 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound47761 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5157,1,115,5173,2341,1024,0,4405,113,64,2,349,65,2420,5440,4097,2420,1056,260,256,261,5456,593]

theorem envBound47762 : H12AffineFastState.Bounded env47762 := by
  intro p hp
  have h : env47762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47761_47762 : H12AffineEnvironment.transform 13 5157 env47761 = env47762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env47761 == env47762) = true)

theorem identity47762 : scanCanonicalize (H12AffineFastState.compose env47762 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47762 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env47763 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,5157,1,115,5173,2048,1024,0,4112,113,64,2,120,65,2129,5221,4097,2129,1056,33,37,32,5237,593]

theorem envBound47763 : H12AffineFastState.Bounded env47763 := by
  intro p hp
  have h : env47763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47762_47763 : H12AffineEnvironment.transform 7 37 env47762 = env47763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47762 == env47763) = true)

theorem identity47763 : scanCanonicalize (H12AffineFastState.compose env47763 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound47763 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47764 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3076,120,2081,1,115,2097,2048,1024,0,3092,113,64,2,120,65,2129,2145,3077,2129,1056,33,37,32,2161,593]

theorem envBound47764 : H12AffineFastState.Bounded env47764 := by
  intro p hp
  have h : env47764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47763_47764 : H12AffineEnvironment.transform 11 3076 env47763 = env47764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env47763 == env47764) = true)

theorem identity47764 : scanCanonicalize (H12AffineFastState.compose env47764 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47764 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47765 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3076,41,2081,1,34,2097,2048,1024,0,3092,32,17,2,41,16,2048,2096,3077,2048,1056,33,37,32,2080,512]

theorem envBound47765 : H12AffineFastState.Bounded env47765 := by
  intro p hp
  have h : env47765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47764_47765 : H12AffineEnvironment.transform 5 17 env47764 = env47765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47764 == env47765) = true)

theorem identity47765 : scanCanonicalize (H12AffineFastState.compose env47765 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47766 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,3076,8,2048,1,3,2064,2048,1024,0,3092,1,17,2,8,16,2048,2065,3077,2048,1025,0,4,1,2049,512]

theorem envBound47766 : H12AffineFastState.Bounded env47766 := by
  intro p hp
  have h : env47766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47765_47766 : H12AffineEnvironment.transform 4 1 env47765 = env47766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47765 == env47766) = true)

theorem identity47766 : scanCanonicalize (H12AffineFastState.compose env47766 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound47766 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47767 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,8,2048,1,3,2064,2048,20,0,2048,1,17,2,8,16,2048,2065,2065,2048,21,0,4,1,2049,512]

theorem envBound47767 : H12AffineFastState.Bounded env47767 := by
  intro p hp
  have h : env47767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47766_47767 : H12AffineEnvironment.transform 9 20 env47766 = env47767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env47766 == env47767) = true)

def env47768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272392,452649,95497,8193,65,292136,458025,45404,10281,399664,144493,256,21792,46093,474734]

theorem envBound47768 : H12AffineFastState.Bounded env47768 := by
  intro p hp
  have h : env47768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47750_47768 : H12AffineEnvironment.transform 6 9 env47750 = env47768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47750 == env47768) = true)

def env47769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272392,272441,95497,8193,65,292136,277817,45404,10281,317728,62589,256,21792,46093,392830]

theorem envBound47769 : H12AffineFastState.Bounded env47769 := by
  intro p hp
  have h : env47769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47768_47769 : H12AffineEnvironment.transform 16 49168 env47768 = env47769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47768 == env47769) = true)

theorem identity47769 : scanCanonicalize (H12AffineFastState.compose env47769 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47769 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24909,262144,1024,8540,290153,272392,272441,95497,8193,65,292136,277817,4097,10281,292989,21792,256,21792,5456,352035]

theorem envBound47770 : H12AffineFastState.Bounded env47770 := by
  intro p hp
  have h : env47770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47769_47770 : H12AffineEnvironment.transform 14 8541 env47769 = env47770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47769 == env47770) = true)

theorem identity47770 : scanCanonicalize (H12AffineFastState.compose env47770 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound47770 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8541,65536,5221,262144,1024,8540,268353,272392,272441,65569,8193,65,262144,277817,4097,10281,265557,8200,256,8200,5456,338443]

theorem envBound47771 : H12AffineFastState.Bounded env47771 := by
  intro p hp
  have h : env47771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47770_47771 : H12AffineEnvironment.transform 13 13608 env47770 = env47771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env47770 == env47771) = true)

theorem identity47771 : scanCanonicalize (H12AffineFastState.compose env47771 (packedSelected [0,8,9,10,12,15,16,18,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound47771 : packedSelected [0,8,9,10,12,15,16,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env47772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8541,65536,5221,2420,1024,8540,4405,8572,8525,65569,8193,65,2420,13389,4097,10281,1057,8200,256,8200,5456,74623]

theorem envBound47772 : H12AffineFastState.Bounded env47772 := by
  intro p hp
  have h : env47772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47771_47772 : H12AffineEnvironment.transform 17 2420 env47771 = env47772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env47771 == env47772) = true)

theorem identity47772 : scanCanonicalize (H12AffineFastState.compose env47772 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound47772 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env47773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8541,342,5221,2420,1024,8540,4405,8572,8525,375,8193,65,2420,13389,4097,10281,1057,8200,256,8200,5456,8745]

theorem envBound47773 : H12AffineFastState.Bounded env47773 := by
  intro p hp
  have h : env47773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47772_47773 : H12AffineEnvironment.transform 15 342 env47772 = env47773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env47772 == env47773) = true)

theorem identity47773 : scanCanonicalize (H12AffineFastState.compose env47773 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound47773 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env47774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3101,6453,3392,342,5221,2420,1024,3393,4405,3425,3408,375,3100,65,2420,6224,4097,1076,1057,3093,256,3093,5456,3636]

theorem envBound47774 : H12AffineFastState.Bounded env47774 := by
  intro p hp
  have h : env47774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47773_47774 : H12AffineEnvironment.transform 12 3101 env47773 = env47774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env47773 == env47774) = true)

theorem identity47774 : scanCanonicalize (H12AffineFastState.compose env47774 (packedSelected [0,4,7,9,10,11,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47774 : packedSelected [0,4,7,9,10,11,16,19] rootPS < 2^1333 := by decide +kernel

def env47775 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,3101,6209,3124,34,5221,2048,1024,3125,4161,3093,3108,3,3100,65,2048,6224,4097,1076,1057,3093,116,3093,5156,3636]

theorem envBound47775 : H12AffineFastState.Bounded env47775 := by
  intro p hp
  have h : env47775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47774_47775 : H12AffineEnvironment.transform 7 116 env47774 = env47775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47774 == env47775) = true)

theorem identity47775 : scanCanonicalize (H12AffineFastState.compose env47775 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound47775 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env47776 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1141,4096,104,5172,65,34,5221,1141,1024,64,4161,96,81,3,105,65,1141,5157,4097,1076,1057,96,116,96,5156,577]

theorem envBound47776 : H12AffineFastState.Bounded env47776 := by
  intro p hp
  have h : env47776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47775_47776 : H12AffineEnvironment.transform 10 1141 env47775 = env47776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env47775 == env47776) = true)

theorem identity47776 : scanCanonicalize (H12AffineFastState.compose env47776 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47776 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env47777 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1141,1076,104,0,65,34,81,1141,1024,64,1141,96,81,3,105,65,1141,17,1077,1076,1057,96,116,96,16,577]

theorem envBound47777 : H12AffineFastState.Bounded env47777 := by
  intro p hp
  have h : env47777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47776_47777 : H12AffineEnvironment.transform 11 1076 env47776 = env47777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env47776 == env47777) = true)

theorem identity47777 : scanCanonicalize (H12AffineFastState.compose env47777 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound47777 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47778 : List Nat := [2,4,8,16,32,64,9,116,512,21,96,33,104,0,65,34,81,96,21,64,96,96,81,3,105,65,96,17,32,33,52,96,116,96,16,577]

theorem envBound47778 : H12AffineFastState.Bounded env47778 := by
  intro p hp
  have h : env47778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47777_47778 : H12AffineEnvironment.transform 9 21 env47777 = env47778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env47777 == env47778) = true)

theorem identity47778 : scanCanonicalize (H12AffineFastState.compose env47778 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47778 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env47779 : List Nat := [2,4,8,16,0,64,9,84,512,21,64,1,72,0,65,2,81,64,21,64,64,64,81,3,73,65,64,17,0,1,20,64,84,64,16,577]

theorem envBound47779 : H12AffineFastState.Bounded env47779 := by
  intro p hp
  have h : env47779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47778_47779 : H12AffineEnvironment.transform 4 0 env47778 = env47779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47778 == env47779) = true)

theorem identity47779 : scanCanonicalize (H12AffineFastState.compose env47779 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47779 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47780 : List Nat := [2,4,8,16,0,17,9,5,512,21,17,1,25,0,16,2,0,17,21,17,17,17,0,3,24,16,17,17,0,1,20,17,5,17,16,528]

theorem envBound47780 : H12AffineFastState.Bounded env47780 := by
  intro p hp
  have h : env47780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47779_47780 : H12AffineEnvironment.transform 5 17 env47779 = env47780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47779 == env47780) = true)

def env47781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272392,272440,95497,8193,65,292136,277816,45404,10281,317729,62588,256,21792,46093,392831]

theorem envBound47781 : H12AffineFastState.Bounded env47781 := by
  intro p hp
  have h : env47781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47768_47781 : H12AffineEnvironment.transform 16 49169 env47768 = env47781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47768 == env47781) = true)

theorem identity47781 : scanCanonicalize (H12AffineFastState.compose env47781 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47781 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,17729,41340,41292,95497,8193,65,64604,46156,45404,10281,20565,62588,256,21792,46093,96011]

theorem envBound47782 : H12AffineFastState.Bounded env47782 := by
  intro p hp
  have h : env47782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47781_47782 : H12AffineEnvironment.transform 17 35188 env47781 = env47782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47781 == env47782) = true)

theorem identity47782 : scanCanonicalize (H12AffineFastState.compose env47782 (packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound47782 : packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS < 2^1333 := by decide +kernel

def env47783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,65536,16741,2048,1024,373,17729,8200,8248,95497,8193,65,32040,13624,12328,10281,20565,29960,256,21792,13689,96011]

theorem envBound47783 : H12AffineFastState.Bounded env47783 := by
  intro p hp
  have h : env47783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47782_47783 : H12AffineEnvironment.transform 14 372 env47782 = env47783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env47782 == env47783) = true)

theorem identity47783 : scanCanonicalize (H12AffineFastState.compose env47783 (packedSelected [2,6,8,9,10,11,12,14,15,16,20,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47783 : packedSelected [2,6,8,9,10,11,12,14,15,16,20,22,23,28] rootPS < 2^1333 := by decide +kernel

def env47784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,372,65536,13624,2048,1024,373,12572,8200,8248,65876,8193,65,2421,13624,12328,10281,9224,341,256,8573,13689,66390]

theorem envBound47784 : H12AffineFastState.Bounded env47784 := by
  intro p hp
  have h : env47784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47783_47784 : H12AffineEnvironment.transform 13 13405 env47783 = env47784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47783 == env47784) = true)

theorem identity47784 : scanCanonicalize (H12AffineFastState.compose env47784 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47784 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env47785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,372,65536,5393,2048,1024,373,4405,33,17,65876,40,65,2421,5393,4097,2048,1057,341,256,340,5456,66390]

theorem envBound47785 : H12AffineFastState.Bounded env47785 := by
  intro p hp
  have h : env47785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47784_47785 : H12AffineEnvironment.transform 12 41 env47784 = env47785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47784 == env47785) = true)

theorem identity47785 : scanCanonicalize (H12AffineFastState.compose env47785 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47785 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47786 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,41,4113,372,65536,4468,2048,101,373,4405,33,17,65876,40,65,2421,4468,4097,2048,68,341,256,340,4405,66390]

theorem envBound47786 : H12AffineFastState.Bounded env47786 := by
  intro p hp
  have h : env47786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47785_47786 : H12AffineEnvironment.transform 9 101 env47785 = env47786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47785 == env47786) = true)

theorem identity47786 : scanCanonicalize (H12AffineFastState.compose env47786 (packedSelected [2,4,6,9,11,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound47786 : packedSelected [2,4,6,9,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env47787 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,41,4113,372,115,4468,2048,101,373,4405,33,17,295,40,65,2421,4468,4097,2048,68,341,256,340,4405,805]

theorem envBound47787 : H12AffineFastState.Bounded env47787 := by
  intro p hp
  have h : env47787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47786_47787 : H12AffineEnvironment.transform 15 115 env47786 = env47787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env47786 == env47787) = true)

theorem identity47787 : scanCanonicalize (H12AffineFastState.compose env47787 (packedSelected [2,3,4,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2431) := by decide +kernel

theorem selectedBound47787 : packedSelected [2,3,4,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47788 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2431,41,2414,372,115,2059,2048,101,373,2122,33,17,295,40,65,2421,2059,2430,2048,68,341,256,340,2122,805]

theorem envBound47788 : H12AffineFastState.Bounded env47788 := by
  intro p hp
  have h : env47788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47787_47788 : H12AffineEnvironment.transform 11 2431 env47787 = env47788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2431 env47787 == env47788) = true)

theorem identity47788 : scanCanonicalize (H12AffineFastState.compose env47788 (packedSelected [3,4,7,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47788 : packedSelected [3,4,7,8,15] rootPS < 2^1333 := by decide +kernel

def env47789 : List Nat := [2,4,8,16,32,64,9,37,512,101,2048,2138,41,2123,81,115,2059,2048,101,80,2122,33,17,2,40,65,2128,2059,2139,2048,68,112,37,113,2122,512]

theorem envBound47789 : H12AffineFastState.Bounded env47789 := by
  intro p hp
  have h : env47789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47788_47789 : H12AffineEnvironment.transform 7 37 env47788 = env47789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47788 == env47789) = true)

theorem identity47789 : scanCanonicalize (H12AffineFastState.compose env47789 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47789 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47790 : List Nat := [2,4,8,16,7,64,9,2,512,66,2048,2138,14,2123,81,84,2059,2048,66,80,2122,6,17,2,15,65,2128,2059,2139,2048,68,87,2,86,2122,512]

theorem envBound47790 : H12AffineFastState.Bounded env47790 := by
  intro p hp
  have h : env47790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47789_47790 : H12AffineEnvironment.transform 4 7 env47789 = env47790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47789 == env47790) = true)

theorem identity47790 : scanCanonicalize (H12AffineFastState.compose env47790 (packedSelected [2,6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47790 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47791 : List Nat := [2,3,8,16,0,64,9,2,512,66,2048,2138,9,2123,81,83,2059,2048,66,80,2122,1,17,2,8,65,2128,2059,2139,2048,67,80,2,81,2122,512]

theorem envBound47791 : H12AffineFastState.Bounded env47791 := by
  intro p hp
  have h : env47791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47790_47791 : H12AffineEnvironment.transform 1 3 env47790 = env47791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47790 == env47791) = true)

theorem identity47791 : scanCanonicalize (H12AffineFastState.compose env47791 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 83) := by decide +kernel

theorem selectedBound47791 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env47792 : List Nat := [2,3,8,16,0,64,9,2,512,66,83,9,9,24,81,83,88,83,66,80,25,1,17,2,8,65,3,88,8,83,67,80,2,81,25,512]

theorem envBound47792 : H12AffineFastState.Bounded env47792 := by
  intro p hp
  have h : env47792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47791_47792 : H12AffineEnvironment.transform 10 83 env47791 = env47792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 83 env47791 == env47792) = true)

theorem identity47792 : scanCanonicalize (H12AffineFastState.compose env47792 (packedSelected [0,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound47792 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env47793 : List Nat := [2,3,8,9,0,64,9,2,512,66,74,9,9,1,72,74,65,74,66,73,0,1,8,2,8,65,3,65,8,74,67,73,2,72,0,512]

theorem envBound47793 : H12AffineFastState.Bounded env47793 := by
  intro p hp
  have h : env47793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47792_47793 : H12AffineEnvironment.transform 3 9 env47792 = env47793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env47792 == env47793) = true)

theorem identity47793 : scanCanonicalize (H12AffineFastState.compose env47793 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47793 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47794 : List Nat := [2,3,3,2,0,64,2,2,512,66,65,2,2,1,67,65,65,65,66,66,0,1,3,2,3,65,3,65,3,65,67,66,2,67,0,512]

theorem envBound47794 : H12AffineFastState.Bounded env47794 := by
  intro p hp
  have h : env47794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47793_47794 : H12AffineEnvironment.transform 2 3 env47793 = env47794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47793 == env47794) = true)

theorem identity47794 : scanCanonicalize (H12AffineFastState.compose env47794 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound47794 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47795 : List Nat := [2,3,3,2,0,3,2,2,512,1,2,2,2,1,0,2,2,2,1,1,0,1,3,2,3,2,3,2,3,2,0,1,2,0,0,512]

theorem envBound47795 : H12AffineFastState.Bounded env47795 := by
  intro p hp
  have h : env47795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47794_47795 : H12AffineEnvironment.transform 5 3 env47794 = env47795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env47794 == env47795) = true)

theorem identity47795 : scanCanonicalize (H12AffineFastState.compose env47795 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47795 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47796 : List Nat := [0,1,1,0,0,1,0,0,512,1,0,0,0,1,0,0,0,0,1,1,0,1,1,0,1,0,1,0,1,0,0,1,0,0,0,512]

theorem envBound47796 : H12AffineFastState.Bounded env47796 := by
  intro p hp
  have h : env47796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47795_47796 : H12AffineEnvironment.transform 0 0 env47795 = env47796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47795 == env47796) = true)

def env47797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,8388608,8887585,8328,65,4218145,8393985,8804860,8830976,399665,12645453,256,21793,46213,474854]

theorem envBound47797 : H12AffineFastState.Bounded env47797 := by
  intro p hp
  have h : env47797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47674_47797 : H12AffineEnvironment.transform 23 8887585 env47674 = env47797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887585 env47674 == env47797) = true)

def env47798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452648,95497,8328,65,4218145,458025,45524,10280,399665,4594789,256,21793,46213,474854]

theorem envBound47798 : H12AffineFastState.Bounded env47798 := by
  intro p hp
  have h : env47798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47797_47798 : H12AffineEnvironment.transform 22 452648 env47797 = env47798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env47797 == env47798) = true)

def env47799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452648,95497,8328,65,292257,458025,45524,10280,399665,144613,256,21793,46213,474854]

theorem envBound47799 : H12AffineFastState.Bounded env47799 := by
  intro p hp
  have h : env47799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47798_47799 : H12AffineEnvironment.transform 21 272512 env47798 = env47799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47798 == env47799) = true)

theorem identity47799 : scanCanonicalize (H12AffineFastState.compose env47799 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47799 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396461,272512,452648,21763,8328,65,292257,458025,45524,10280,399665,144613,256,21793,46213,401132]

theorem envBound47800 : H12AffineFastState.Bounded env47800 := by
  intro p hp
  have h : env47800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47799_47800 : H12AffineEnvironment.transform 15 8202 env47799 = env47800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47799 == env47800) = true)

def env47801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396325,272392,452648,21763,8192,65,292137,458025,45404,10280,399665,144493,256,21793,46093,400996]

theorem envBound47801 : H12AffineFastState.Bounded env47801 := by
  intro p hp
  have h : env47801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47800_47801 : H12AffineEnvironment.transform 6 8 env47800 = env47801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47800 == env47801) = true)

theorem identity47801 : scanCanonicalize (H12AffineFastState.compose env47801 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound47801 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env47802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,23668,1024,32769,151633,29820,177244,21763,8192,65,10589,172381,45404,10280,148805,144493,256,21793,46093,147984]

theorem envBound47802 : H12AffineFastState.Bounded env47802 := by
  intro p hp
  have h : env47802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47801_47802 : H12AffineEnvironment.transform 17 23668 env47801 = env47802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env47801 == env47802) = true)

theorem identity47802 : scanCanonicalize (H12AffineFastState.compose env47802 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound47802 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env47803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,131072,23668,1024,21761,151633,29820,155996,21763,8192,65,10589,160861,25692,10280,148805,144493,256,21793,24845,147984]

theorem envBound47803 : H12AffineFastState.Bounded env47803 := by
  intro p hp
  have h : env47803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47802_47803 : H12AffineEnvironment.transform 14 21760 env47802 = env47803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env47802 == env47803) = true)

theorem identity47803 : scanCanonicalize (H12AffineFastState.compose env47803 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound47803 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env47804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,24909,23668,1024,21761,12572,29820,17,21763,8192,65,10589,5392,25692,10280,9224,21792,256,21793,24845,9053]

theorem envBound47804 : H12AffineFastState.Bounded env47804 := by
  intro p hp
  have h : env47804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47803_47804 : H12AffineEnvironment.transform 16 24909 env47803 = env47804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env47803 == env47804) = true)

theorem identity47804 : scanCanonicalize (H12AffineFastState.compose env47804 (packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 9750) := by decide +kernel

theorem selectedBound47804 : packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env47805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9750,13078,8202,1883,14946,1024,13079,12572,4714,17,13077,8192,65,10589,5392,586,10280,9224,13110,256,13111,1819,9053]

theorem envBound47805 : H12AffineFastState.Bounded env47805 := by
  intro p hp
  have h : env47805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47804_47805 : H12AffineEnvironment.transform 13 9750 env47804 = env47805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9750 env47804 == env47805) = true)

def env47806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396324,272393,452648,21763,8193,65,292136,458025,45405,10280,399665,144492,256,21793,46092,400997]

theorem envBound47806 : H12AffineFastState.Bounded env47806 := by
  intro p hp
  have h : env47806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47800_47806 : H12AffineEnvironment.transform 6 9 env47800 = env47806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47800 == env47806) = true)

theorem identity47806 : scanCanonicalize (H12AffineFastState.compose env47806 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 182336) := by decide +kernel

theorem selectedBound47806 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env47807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182336,1024,32769,50276,188489,8296,21763,8193,65,179560,13673,45405,10280,53617,144492,256,21793,46092,54821]

theorem envBound47807 : H12AffineFastState.Bounded env47807 := by
  intro p hp
  have h : env47807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47806_47807 : H12AffineEnvironment.transform 17 182336 env47806 = env47807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182336 env47806 == env47807) = true)

theorem identity47807 : scanCanonicalize (H12AffineFastState.compose env47807 (packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound47807 : packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env47808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,8202,131072,149521,1024,80,17461,155672,8296,21763,8193,65,146745,13673,12556,10280,20768,144492,256,21793,13405,22132]

theorem envBound47808 : H12AffineFastState.Bounded env47808 := by
  intro p hp
  have h : env47808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47807_47808 : H12AffineEnvironment.transform 14 81 env47807 = env47808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env47807 == env47808) = true)

theorem identity47808 : scanCanonicalize (H12AffineFastState.compose env47808 (packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound47808 : packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,81,8202,131072,146793,1024,80,12621,136544,8296,8315,8193,65,146745,13673,12556,10280,9304,144492,256,8281,13405,8972]

theorem envBound47809 : H12AffineFastState.Bounded env47809 := by
  intro p hp
  have h : env47809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47808_47809 : H12AffineEnvironment.transform 13 13688 env47808 = env47809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env47808 == env47809) = true)

theorem identity47809 : scanCanonicalize (H12AffineFastState.compose env47809 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound47809 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,81,8202,5172,10589,1024,80,12621,340,8296,8315,8193,65,10509,13673,12556,10280,9304,8280,256,8281,13405,8972]

theorem envBound47810 : H12AffineFastState.Bounded env47810 := by
  intro p hp
  have h : env47810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47809_47810 : H12AffineEnvironment.transform 16 5172 env47809 = env47810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env47809 == env47810) = true)

theorem identity47810 : scanCanonicalize (H12AffineFastState.compose env47810 (packedSelected [0,1,2,3,4,5,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7545) := by decide +kernel

theorem selectedBound47810 : packedSelected [0,1,2,3,4,5,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env47811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,2049,81,7539,5172,5156,1024,80,3124,340,7441,7426,7544,65,5236,2064,3189,5457,6433,7457,256,7456,2340,7797]

theorem envBound47811 : H12AffineFastState.Bounded env47811 := by
  intro p hp
  have h : env47811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47810_47811 : H12AffineEnvironment.transform 12 7545 env47810 = env47811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7545 env47810 == env47811) = true)

theorem identity47811 : scanCanonicalize (H12AffineFastState.compose env47811 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47811 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env47812 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,7465,2049,1,7459,5172,5156,1024,0,3124,260,7441,7426,7464,17,5156,2064,3109,5377,6433,7457,256,7456,2340,7717]

theorem envBound47812 : H12AffineFastState.Bounded env47812 := by
  intro p hp
  have h : env47812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47811_47812 : H12AffineEnvironment.transform 5 16 env47811 = env47812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47811 == env47812) = true)

theorem identity47812 : scanCanonicalize (H12AffineFastState.compose env47812 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47812 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env47813 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,6201,2049,1,6195,4388,4404,272,0,2340,260,6145,6162,6200,17,4404,2064,2357,4113,6433,6193,256,6192,2340,6965]

theorem envBound47813 : H12AffineFastState.Bounded env47813 := by
  intro p hp
  have h : env47813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47812_47813 : H12AffineEnvironment.transform 9 272 env47812 = env47813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47812 == env47813) = true)

theorem identity47813 : scanCanonicalize (H12AffineFastState.compose env47813 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47813 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env47814 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,6201,2049,1,6195,4096,4112,52,0,2048,32,6145,6162,6200,17,4112,2064,2065,4113,6149,6193,36,6192,2048,6673]

theorem envBound47814 : H12AffineFastState.Bounded env47814 := by
  intro p hp
  have h : env47814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47813_47814 : H12AffineEnvironment.transform 7 36 env47813 = env47814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47813 == env47814) = true)

theorem identity47814 : scanCanonicalize (H12AffineFastState.compose env47814 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound47814 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47815 : List Nat := [2,4,8,16,32,16,9,36,37,52,2048,4096,6201,2049,1,6195,4096,4112,52,0,2048,32,6145,6162,6200,17,4112,2064,2065,4113,6149,6193,36,6192,2048,6196]

theorem envBound47815 : H12AffineFastState.Bounded env47815 := by
  intro p hp
  have h : env47815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47814_47815 : H12AffineEnvironment.transform 8 37 env47814 = env47815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env47814 == env47815) = true)

theorem identity47815 : scanCanonicalize (H12AffineFastState.compose env47815 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound47815 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47816 : List Nat := [2,4,8,16,32,16,9,36,37,52,2048,48,2057,2049,1,2051,48,32,52,0,2048,32,2097,2082,2056,17,32,2064,2065,33,2101,2049,36,2048,2048,2052]

theorem envBound47816 : H12AffineFastState.Bounded env47816 := by
  intro p hp
  have h : env47816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47815_47816 : H12AffineEnvironment.transform 11 48 env47815 = env47816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47815 == env47816) = true)

theorem identity47816 : scanCanonicalize (H12AffineFastState.compose env47816 (packedSelected [2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound47816 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env47817 : List Nat := [2,4,8,16,32,16,9,36,37,52,32,48,41,33,1,35,48,32,52,0,32,32,17,2,40,17,32,48,49,33,21,33,36,32,32,36]

theorem envBound47817 : H12AffineFastState.Bounded env47817 := by
  intro p hp
  have h : env47817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47816_47817 : H12AffineEnvironment.transform 10 32 env47816 = env47817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env47816 == env47817) = true)

theorem identity47817 : scanCanonicalize (H12AffineFastState.compose env47817 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47817 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47818 : List Nat := [2,2,8,16,32,16,9,34,35,50,32,48,41,33,1,35,48,32,50,0,32,32,17,2,40,17,32,48,49,33,19,33,34,32,32,34]

theorem envBound47818 : H12AffineFastState.Bounded env47818 := by
  intro p hp
  have h : env47818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47817_47818 : H12AffineEnvironment.transform 1 2 env47817 = env47818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47817 == env47818) = true)

theorem identity47818 : scanCanonicalize (H12AffineFastState.compose env47818 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47819 : List Nat := [2,2,8,16,0,16,9,2,3,18,0,16,9,1,1,3,16,0,18,0,0,0,17,2,8,17,0,16,17,1,19,1,2,0,0,2]

theorem envBound47819 : H12AffineFastState.Bounded env47819 := by
  intro p hp
  have h : env47819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47818_47819 : H12AffineEnvironment.transform 4 0 env47818 = env47819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47818 == env47819) = true)

theorem identity47819 : scanCanonicalize (H12AffineFastState.compose env47819 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound47819 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47820 : List Nat := [2,2,1,16,0,16,0,2,3,18,0,16,0,1,1,3,16,0,18,0,0,0,17,2,1,17,0,16,17,1,19,1,2,0,0,2]

theorem envBound47820 : H12AffineFastState.Bounded env47820 := by
  intro p hp
  have h : env47820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47819_47820 : H12AffineEnvironment.transform 2 1 env47819 = env47820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env47819 == env47820) = true)

def env47821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452648,95497,8328,65,292256,458025,45524,10280,399665,144612,256,21793,46213,474854]

theorem envBound47821 : H12AffineFastState.Bounded env47821 := by
  intro p hp
  have h : env47821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47798_47821 : H12AffineEnvironment.transform 21 272513 env47798 = env47821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47798 == env47821) = true)

theorem identity47821 : scanCanonicalize (H12AffineFastState.compose env47821 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound47821 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,115871,254131,73754,95497,8328,65,245138,79131,45524,10280,119043,144612,256,21793,46213,63188]

theorem envBound47822 : H12AffineFastState.Bounded env47822 := by
  intro p hp
  have h : env47822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47821_47822 : H12AffineEnvironment.transform 17 247858 env47821 = env47822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env47821 == env47822) = true)

def env47823 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,115871,254131,73754,95497,8328,17,245138,79131,45444,10280,119043,144564,256,21793,46213,63108]

theorem envBound47823 : H12AffineFastState.Bounded env47823 := by
  intro p hp
  have h : env47823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47822_47823 : H12AffineEnvironment.transform 5 16 env47822 = env47823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47822 == env47823) = true)

theorem identity47823 : scanCanonicalize (H12AffineFastState.compose env47823 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound47823 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,57628,76078,1024,32769,115871,65967,73754,95497,8328,17,89230,79131,45444,10280,119043,54696,256,21793,46213,63108]

theorem envBound47824 : H12AffineFastState.Bounded env47824 := by
  intro p hp
  have h : env47824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47823_47824 : H12AffineEnvironment.transform 16 57628 env47823 = env47824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env47823 == env47824) = true)

theorem identity47824 : scanCanonicalize (H12AffineFastState.compose env47824 (packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47824 : packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47825 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,57628,76078,1024,32769,115735,65831,73754,95497,8192,17,89094,79131,45324,10280,119043,54560,256,21793,46093,62988]

theorem envBound47825 : H12AffineFastState.Bounded env47825 := by
  intro p hp
  have h : env47825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47824_47825 : H12AffineEnvironment.transform 6 8 env47824 = env47825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47824 == env47825) = true)

theorem identity47825 : scanCanonicalize (H12AffineFastState.compose env47825 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound47825 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47826 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,57628,64808,1024,32769,4113,54561,62492,41231,8192,17,34816,57629,45324,10280,1285,54560,256,21793,46093,62988]

theorem envBound47826 : H12AffineFastState.Bounded env47826 := by
  intro p hp
  have h : env47826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47825_47826 : H12AffineEnvironment.transform 15 54278 env47825 = env47826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env47825 == env47826) = true)

theorem identity47826 : scanCanonicalize (H12AffineFastState.compose env47826 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound47826 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env47827 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,5393,2341,1024,29708,4113,8492,17,21762,8192,17,31757,5392,17665,10280,1285,8493,256,21793,16384,513]

theorem envBound47827 : H12AffineFastState.Bounded env47827 := by
  intro p hp
  have h : env47827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47826_47827 : H12AffineEnvironment.transform 14 29709 env47826 = env47827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env47826 == env47827) = true)

theorem identity47827 : scanCanonicalize (H12AffineFastState.compose env47827 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47827 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47828 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8203,5393,2341,1024,8460,4113,8492,17,2,8192,17,10509,5392,4097,10280,1285,8493,256,33,5376,513]

theorem envBound47828 : H12AffineFastState.Bounded env47828 := by
  intro p hp
  have h : env47828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47827_47828 : H12AffineEnvironment.transform 13 5376 env47827 = env47828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47827 == env47828) = true)

theorem identity47828 : scanCanonicalize (H12AffineFastState.compose env47828 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47828 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47829 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8233,8203,5173,2049,1024,8232,4113,8200,17,2,8192,17,10281,5172,4097,10280,1057,8201,36,33,5156,513]

theorem envBound47829 : H12AffineFastState.Bounded env47829 := by
  intro p hp
  have h : env47829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47828_47829 : H12AffineEnvironment.transform 7 36 env47828 = env47829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47828 == env47829) = true)

theorem identity47829 : scanCanonicalize (H12AffineFastState.compose env47829 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47829 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47830 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5173,2049,1024,1,4113,33,17,2,41,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound47830 : H12AffineFastState.Bounded env47830 := by
  intro p hp
  have h : env47830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47829_47830 : H12AffineEnvironment.transform 12 41 env47829 = env47830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47829 == env47830) = true)

def env47831 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,0,34,1029,2049,1024,1,33,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound47831 : H12AffineFastState.Bounded env47831 := by
  intro p hp
  have h : env47831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47830_47831 : H12AffineEnvironment.transform 11 48 env47830 = env47831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47830 == env47831) = true)

theorem identity47831 : scanCanonicalize (H12AffineFastState.compose env47831 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound47831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47832 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,48,41,1044,0,34,1029,2049,1024,1,33,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,49]

theorem envBound47832 : H12AffineFastState.Bounded env47832 := by
  intro p hp
  have h : env47832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47831_47832 : H12AffineEnvironment.transform 8 48 env47831 = env47832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47831 == env47832) = true)

def env47833 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,41,32,0,34,49,2049,52,1,33,33,17,2,41,17,2048,48,49,2049,21,32,36,33,32,49]

theorem envBound47833 : H12AffineFastState.Bounded env47833 := by
  intro p hp
  have h : env47833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47832_47833 : H12AffineEnvironment.transform 9 52 env47832 = env47833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47832 == env47833) = true)

def env47834 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,41,33,0,34,48,2049,53,1,33,33,17,2,41,17,2048,49,49,2049,20,32,36,33,33,49]

theorem envBound47834 : H12AffineFastState.Bounded env47834 := by
  intro p hp
  have h : env47834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47832_47834 : H12AffineEnvironment.transform 9 53 env47832 = env47834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47832 == env47834) = true)

theorem identity47834 : scanCanonicalize (H12AffineFastState.compose env47834 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47835 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,42,41,33,0,34,42,2049,47,1,33,33,11,2,41,11,2048,43,43,2049,14,32,36,33,33,43]

theorem envBound47835 : H12AffineFastState.Bounded env47835 := by
  intro p hp
  have h : env47835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47834_47835 : H12AffineEnvironment.transform 3 10 env47834 = env47835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47834 == env47835) = true)

def leafEnv47835 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,42,41,33,0,34,42,2049,47,1,33,33,11,2,14,41,1,11,2048,43,43,2049,14,32,36,33,4,34,33,43,1,33,0]

def active47835 : List Nat := [0,1,2,4,10]

def tree47835 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47835 : H12WitnessSearch.Good tree47835 := H12GlobalWitnessIndex.good

theorem leafIdentity47835 : H12AffineFastState.composeSystem env47835 rootObs = leafEnv47835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47835 rootObs == leafEnv47835) = true)

theorem terminalChecked47835 : H12PackedTerminal.terminalCheckFast leafEnv47835 active47835 tree47835 = true := by decide +kernel

def env47836 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,0,34,1028,2049,1024,1,32,33,17,2,41,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound47836 : H12AffineFastState.Bounded env47836 := by
  intro p hp
  have h : env47836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47830_47836 : H12AffineEnvironment.transform 11 49 env47830 = env47836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47830 == env47836) = true)

theorem identity47836 : scanCanonicalize (H12AffineFastState.compose env47836 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound47836 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47837 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,49,41,529,0,34,512,2049,516,1,32,33,17,2,41,17,2048,513,48,2049,549,32,36,33,529,513]

theorem envBound47837 : H12AffineFastState.Bounded env47837 := by
  intro p hp
  have h : env47837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47836_47837 : H12AffineEnvironment.transform 9 516 env47836 = env47837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env47836 == env47837) = true)

def env47838 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,41,33,0,34,48,2049,52,1,32,33,17,2,41,17,2048,49,48,2049,21,32,36,33,33,49]

theorem envBound47838 : H12AffineFastState.Bounded env47838 := by
  intro p hp
  have h : env47838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47837_47838 : H12AffineEnvironment.transform 8 48 env47837 = env47838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47837 == env47838) = true)

def env47839 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,41,32,0,34,49,2049,53,1,32,33,17,2,41,17,2048,48,48,2049,20,32,36,33,32,48]

theorem envBound47839 : H12AffineFastState.Bounded env47839 := by
  intro p hp
  have h : env47839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47837_47839 : H12AffineEnvironment.transform 8 49 env47837 = env47839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47837 == env47839) = true)

theorem identity47839 : scanCanonicalize (H12AffineFastState.compose env47839 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47840 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,43,41,32,0,34,43,2049,47,1,32,33,11,2,41,11,2048,42,42,2049,14,32,36,33,32,42]

theorem envBound47840 : H12AffineFastState.Bounded env47840 := by
  intro p hp
  have h : env47840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47839_47840 : H12AffineEnvironment.transform 3 10 env47839 = env47840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47839 == env47840) = true)

def leafEnv47840 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,43,41,32,0,34,43,2049,47,1,32,33,11,2,14,41,1,11,2048,42,42,2049,14,32,36,33,4,34,32,42,1,32,0]

def active47840 : List Nat := [0,1,2,4,10]

def tree47840 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47840 : H12WitnessSearch.Good tree47840 := H12GlobalWitnessIndex.good

theorem leafIdentity47840 : H12AffineFastState.composeSystem env47840 rootObs = leafEnv47840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47840 rootObs == leafEnv47840) = true)

theorem terminalChecked47840 : H12PackedTerminal.terminalCheckFast leafEnv47840 active47840 tree47840 = true := by decide +kernel

def env47841 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,115871,254131,73754,95497,8328,16,245138,79131,45445,10280,119043,144565,256,21793,46213,63109]

theorem envBound47841 : H12AffineFastState.Bounded env47841 := by
  intro p hp
  have h : env47841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47822_47841 : H12AffineEnvironment.transform 5 17 env47822 = env47841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47822 == env47841) = true)

theorem identity47841 : scanCanonicalize (H12AffineFastState.compose env47841 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound47841 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,79131,64809,1024,32769,115871,54696,73754,95497,8328,16,34953,79131,45445,10280,119043,65966,256,21793,46213,63109]

theorem envBound47842 : H12AffineFastState.Bounded env47842 := by
  intro p hp
  have h : env47842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47841_47842 : H12AffineEnvironment.transform 16 79131 env47841 = env47842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env47841 == env47842) = true)

theorem identity47842 : scanCanonicalize (H12AffineFastState.compose env47842 (packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound47842 : packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS < 2^1333 := by decide +kernel

def env47843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,79131,2477,1024,29829,77851,8492,73754,95497,8328,16,31757,79131,17665,10280,75143,65966,256,21793,16385,513]

theorem envBound47843 : H12AffineFastState.Bounded env47843 := by
  intro p hp
  have h : env47843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47842_47843 : H12AffineEnvironment.transform 14 29828 env47842 = env47843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env47842 == env47843) = true)

theorem identity47843 : scanCanonicalize (H12AffineFastState.compose env47843 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound47843 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21760,65536,70815,2477,1024,21761,70047,168,65950,87181,268,16,23945,70815,17665,2476,66563,65966,256,21793,16385,513]

theorem envBound47844 : H12AffineFastState.Bounded env47844 := by
  intro p hp
  have h : env47844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47843_47844 : H12AffineEnvironment.transform 12 388 env47843 = env47844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env47843 == env47844) = true)

theorem identity47844 : scanCanonicalize (H12AffineFastState.compose env47844 (packedSelected [2,3,4,5,6,9,10,14,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound47844 : packedSelected [2,3,4,5,6,9,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env47845 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,388,16384,20632,65536,69895,2477,408,20633,70047,168,65950,86293,268,16,22545,69895,16537,2476,65947,65966,256,20665,16385,513]

theorem envBound47845 : H12AffineFastState.Bounded env47845 := by
  intro p hp
  have h : env47845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47844_47845 : H12AffineEnvironment.transform 9 408 env47844 = env47845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env47844 == env47845) = true)

theorem identity47845 : scanCanonicalize (H12AffineFastState.compose env47845 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound47845 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env47846 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,388,4112,136,65536,69895,2477,408,137,70047,168,65950,65797,268,16,2049,69895,4233,2476,65947,65966,256,169,4113,513]

theorem envBound47846 : H12AffineFastState.Bounded env47846 := by
  intro p hp
  have h : env47846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47845_47846 : H12AffineEnvironment.transform 13 4112 env47845 = env47846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env47845 == env47846) = true)

theorem identity47846 : scanCanonicalize (H12AffineFastState.compose env47846 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47846 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47847 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4112,1,65536,69895,2340,273,0,69910,33,65815,65797,268,16,2049,69895,4096,2341,65810,65831,256,32,4113,513]

theorem envBound47847 : H12AffineFastState.Bounded env47847 := by
  intro p hp
  have h : env47847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47846_47847 : H12AffineEnvironment.transform 6 9 env47846 = env47847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47846 == env47847) = true)

theorem identity47847 : scanCanonicalize (H12AffineFastState.compose env47847 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound47847 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env47848 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,269,2049,1,65536,67862,2340,273,0,67847,33,65815,65797,268,16,2049,67862,2065,2341,65810,65831,256,32,2048,513]

theorem envBound47848 : H12AffineFastState.Bounded env47848 := by
  intro p hp
  have h : env47848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47847_47848 : H12AffineEnvironment.transform 11 2065 env47847 = env47848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env47847 == env47848) = true)

theorem identity47848 : scanCanonicalize (H12AffineFastState.compose env47848 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound47848 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47849 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,269,2049,1,35,2357,2340,273,0,2340,33,308,294,268,16,2049,2357,2065,2341,305,260,256,32,2048,513]

theorem envBound47849 : H12AffineFastState.Bounded env47849 := by
  intro p hp
  have h : env47849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47848_47849 : H12AffineEnvironment.transform 15 35 env47848 = env47849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env47848 == env47849) = true)

theorem identity47849 : scanCanonicalize (H12AffineFastState.compose env47849 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound47849 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47850 : List Nat := [2,4,8,16,32,17,9,256,32,273,2048,2065,269,2049,1,35,2357,2340,273,0,2340,33,308,294,268,16,2049,2357,2065,2341,305,260,256,32,2048,33]

theorem envBound47850 : H12AffineFastState.Bounded env47850 := by
  intro p hp
  have h : env47850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47849_47850 : H12AffineEnvironment.transform 8 32 env47849 = env47850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env47849 == env47850) = true)

def env47851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452649,95496,8328,65,4218145,458024,45525,10281,399665,4594788,256,21793,46213,474854]

theorem envBound47851 : H12AffineFastState.Bounded env47851 := by
  intro p hp
  have h : env47851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47797_47851 : H12AffineEnvironment.transform 22 452649 env47797 = env47851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env47797 == env47851) = true)

def env47852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452649,95496,8328,65,292257,458024,45525,10281,399665,144612,256,21793,46213,474854]

theorem envBound47852 : H12AffineFastState.Bounded env47852 := by
  intro p hp
  have h : env47852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47851_47852 : H12AffineEnvironment.transform 21 272512 env47851 = env47852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47851 == env47852) = true)

theorem identity47852 : scanCanonicalize (H12AffineFastState.compose env47852 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound47852 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,396461,272512,452649,41430,8328,65,292257,458024,45525,10281,399665,144612,256,21793,46213,453176]

theorem envBound47853 : H12AffineFastState.Bounded env47853 := by
  intro p hp
  have h : env47853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47852_47853 : H12AffineEnvironment.transform 15 54494 env47852 = env47853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env47852 == env47853) = true)

def env47854 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,396461,272512,452649,41350,8328,17,292257,458024,45445,10281,399665,144564,256,21793,46213,453176]

theorem envBound47854 : H12AffineFastState.Bounded env47854 := by
  intro p hp
  have h : env47854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47853_47854 : H12AffineEnvironment.transform 5 16 env47853 = env47854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47853 == env47854) = true)

theorem identity47854 : scanCanonicalize (H12AffineFastState.compose env47854 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound47854 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env47855 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,35244,1024,32769,165121,41260,156037,41350,8328,17,64525,160900,45445,10281,168093,144564,256,21793,46213,156564]

theorem envBound47855 : H12AffineFastState.Bounded env47855 := by
  intro p hp
  have h : env47855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47854_47855 : H12AffineEnvironment.transform 17 35244 env47854 = env47855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env47854 == env47855) = true)

theorem identity47855 : scanCanonicalize (H12AffineFastState.compose env47855 (packedSelected [0,1,4,5,7,8,10,16,17,18,20,22,23,24,31] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound47855 : packedSelected [0,1,4,5,7,8,10,16,17,18,20,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env47856 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,262,131072,23588,1024,21897,151689,29860,156037,29710,8328,17,10629,160900,25613,10281,148757,144564,256,21793,24845,156564]

theorem envBound47856 : H12AffineFastState.Bounded env47856 := by
  intro p hp
  have h : env47856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47855_47856 : H12AffineEnvironment.transform 14 21896 env47855 = env47856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env47855 == env47856) = true)

theorem identity47856 : scanCanonicalize (H12AffineFastState.compose env47856 (packedSelected [0,1,4,5,7,8,17,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound47856 : packedSelected [0,1,4,5,7,8,17,22,24] rootPS < 2^1333 := by decide +kernel

def env47857 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21896,262,131072,23588,1024,21897,151689,21793,147456,21899,269,17,2048,152833,17800,2476,148757,136497,256,21793,16520,147985]

theorem envBound47857 : H12AffineFastState.Bounded env47857 := by
  intro p hp
  have h : env47857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47856_47857 : H12AffineEnvironment.transform 12 389 env47856 = env47857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env47856 == env47857) = true)

theorem identity47857 : scanCanonicalize (H12AffineFastState.compose env47857 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47857 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47858 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,21760,262,131072,23588,1024,21761,151553,21793,147456,21763,269,17,2048,152833,17664,2340,148757,136497,256,21793,16384,147985]

theorem envBound47858 : H12AffineFastState.Bounded env47858 := by
  intro p hp
  have h : env47858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47857_47858 : H12AffineEnvironment.transform 6 8 env47857 = env47858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47857 == env47858) = true)

theorem identity47858 : scanCanonicalize (H12AffineFastState.compose env47858 (packedSelected [0,2,3,5,6,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound47858 : packedSelected [0,2,3,5,6,9,10,12] rootPS < 2^1333 := by decide +kernel

def env47859 : List Nat := [2,4,8,16,32,16,8,256,512,532,2048,4096,269,16384,21268,262,131072,23088,532,21269,151553,21301,147456,21271,269,17,2048,152341,17172,2340,148225,135973,256,21301,16384,147985]

theorem envBound47859 : H12AffineFastState.Bounded env47859 := by
  intro p hp
  have h : env47859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47858_47859 : H12AffineEnvironment.transform 9 532 env47858 = env47859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env47858 == env47859) = true)

theorem identity47859 : scanCanonicalize (H12AffineFastState.compose env47859 (packedSelected [0,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 6154) := by decide +kernel

theorem selectedBound47859 : packedSelected [0,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47860 : List Nat := [2,4,8,16,32,16,8,256,512,532,2048,4096,269,16384,21268,262,6154,23088,532,21269,18443,21301,22538,21271,269,17,2048,19231,17172,2340,23307,2863,256,21301,16384,23067]

theorem envBound47860 : H12AffineFastState.Bounded env47860 := by
  intro p hp
  have h : env47860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47859_47860 : H12AffineEnvironment.transform 16 6154 env47859 = env47860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6154 env47859 == env47860) = true)

theorem identity47860 : scanCanonicalize (H12AffineFastState.compose env47860 (packedSelected [0,2,4,6,14,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound47860 : packedSelected [0,2,4,6,14,15,16] rootPS < 2^1333 := by decide +kernel

def env47861 : List Nat := [2,4,8,16,32,16,8,256,512,532,783,4096,269,16384,21268,262,4869,20799,532,21269,17156,21301,21253,21271,269,17,783,16400,17172,555,20484,32,256,21301,16384,20756]

theorem envBound47861 : H12AffineFastState.Bounded env47861 := by
  intro p hp
  have h : env47861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47860_47861 : H12AffineEnvironment.transform 10 783 env47860 = env47861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env47860 == env47861) = true)

theorem identity47861 : scanCanonicalize (H12AffineFastState.compose env47861 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound47861 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47862 : List Nat := [2,4,8,16,32,16,8,256,512,532,783,539,269,16384,16655,262,286,17188,532,16654,17156,16686,16670,16652,269,17,783,16400,17172,555,16927,32,256,16686,16384,17167]

theorem envBound47862 : H12AffineFastState.Bounded env47862 := by
  intro p hp
  have h : env47862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47861_47862 : H12AffineEnvironment.transform 11 539 env47861 = env47862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env47861 == env47862) = true)

def env47863 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,396461,272512,452649,41351,8328,16,292257,458024,45444,10281,399665,144565,256,21793,46213,453176]

theorem envBound47863 : H12AffineFastState.Bounded env47863 := by
  intro p hp
  have h : env47863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47853_47863 : H12AffineEnvironment.transform 5 17 env47853 = env47863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47853 == env47863) = true)

end H12CloudChart0