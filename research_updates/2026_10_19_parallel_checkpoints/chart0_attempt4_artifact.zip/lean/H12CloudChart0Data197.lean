import H12CloudChart0Data196

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound49887 : H12AffineFastState.Bounded env49887 := by
  intro p hp
  have h : env49887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49843_49887 : H12AffineEnvironment.transform 16 16401 env49843 = env49887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49843 == env49887) = true)

theorem identity49887 : scanCanonicalize (H12AffineFastState.compose env49887 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49887 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env49888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,2097152,4194304,16,16777216,8192,65,21039476,18949464,2118977,2421,16852316,23160136,257,18965865,18949401,16777730]

theorem envBound49888 : H12AffineFastState.Bounded env49888 := by
  intro p hp
  have h : env49888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49887_49888 : H12AffineEnvironment.transform 14 8540 env49887 = env49888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49887 == env49888) = true)

theorem identity49888 : scanCanonicalize (H12AffineFastState.compose env49888 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 65876) := by decide +kernel

theorem selectedBound49888 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env49889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,2097152,4194304,16,65876,8192,65,4196384,2106380,2118977,2421,9224,6317084,257,2122813,2106445,66390]

theorem envBound49889 : H12AffineFastState.Bounded env49889 := by
  intro p hp
  have h : env49889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49888_49889 : H12AffineEnvironment.transform 23 65876 env49888 = env49889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65876 env49888 == env49889) = true)

theorem identity49889 : scanCanonicalize (H12AffineFastState.compose env49889 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound49889 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS < 2^1333 := by decide +kernel

def env49890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,17680,4194304,16,65876,8192,65,4196384,24860,4177,2421,9224,4202764,257,8493,24925,66390]

theorem envBound49890 : H12AffineFastState.Bounded env49890 := by
  intro p hp
  have h : env49890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49889_49890 : H12AffineEnvironment.transform 20 17680 env49889 = env49890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env49889 == env49890) = true)

theorem identity49890 : scanCanonicalize (H12AffineFastState.compose env49890 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound49890 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env49891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1025,8541,17680,8572,16,65876,8192,65,10588,24860,4177,2421,9224,112,257,8493,24925,66390]

theorem envBound49891 : H12AffineFastState.Bounded env49891 := by
  intro p hp
  have h : env49891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49890_49891 : H12AffineEnvironment.transform 21 8572 env49890 = env49891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env49890 == env49891) = true)

theorem identity49891 : scanCanonicalize (H12AffineFastState.compose env49891 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49891 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env49892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,65536,16401,2421,1025,1,17680,32,16,65876,348,65,2048,16448,4177,2421,1364,112,257,113,16385,66390]

theorem envBound49892 : H12AffineFastState.Bounded env49892 := by
  intro p hp
  have h : env49892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49891_49892 : H12AffineEnvironment.transform 12 348 env49891 = env49892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49891 == env49892) = true)

theorem identity49892 : scanCanonicalize (H12AffineFastState.compose env49892 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound49892 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env49893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2144,348,16384,0,65536,16401,2421,1025,1,17680,32,16,65876,348,65,2048,16448,2097,2421,1364,112,257,113,16385,66390]

theorem envBound49893 : H12AffineFastState.Bounded env49893 := by
  intro p hp
  have h : env49893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49892_49893 : H12AffineEnvironment.transform 11 2144 env49892 = env49893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env49892 == env49893) = true)

theorem identity49893 : scanCanonicalize (H12AffineFastState.compose env49893 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49893 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49894 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,2064,300,16384,0,65536,16401,2309,1025,1,17680,32,16,65828,300,49,2048,16432,2097,2309,1316,0,257,1,16385,66342]

theorem envBound49894 : H12AffineFastState.Bounded env49894 := by
  intro p hp
  have h : env49894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49893_49894 : H12AffineEnvironment.transform 5 48 env49893 = env49894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49893 == env49894) = true)

theorem identity49894 : scanCanonicalize (H12AffineFastState.compose env49894 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49894 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49895 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,2064,268,16384,0,65536,16401,2309,1025,1,17680,0,16,65796,268,17,2048,16400,2065,2309,1284,0,257,1,16385,66310]

theorem envBound49895 : H12AffineFastState.Bounded env49895 := by
  intro p hp
  have h : env49895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49894_49895 : H12AffineEnvironment.transform 4 0 env49894 = env49895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49894 == env49895) = true)

theorem identity49895 : scanCanonicalize (H12AffineFastState.compose env49895 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(13+1) ^^^ 1044) := by decide +kernel

theorem selectedBound49895 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env49896 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,2064,268,1044,0,65536,1029,2309,1025,1,260,0,16,65796,268,17,2048,1028,2065,2309,1284,0,257,1,1045,66310]

theorem envBound49896 : H12AffineFastState.Bounded env49896 := by
  intro p hp
  have h : env49896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49895_49896 : H12AffineEnvironment.transform 13 1044 env49895 = env49896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1044 env49895 == env49896) = true)

theorem identity49896 : scanCanonicalize (H12AffineFastState.compose env49896 (packedSelected [0,2,3,4,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound49896 : packedSelected [0,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env49897 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,2064,268,0,0,65536,17,2309,21,1,260,0,16,65796,268,17,2048,16,2065,2309,272,0,257,1,1,66310]

theorem envBound49897 : H12AffineFastState.Bounded env49897 := by
  intro p hp
  have h : env49897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49896_49897 : H12AffineEnvironment.transform 9 20 env49896 = env49897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env49896 == env49897) = true)

theorem identity49897 : scanCanonicalize (H12AffineFastState.compose env49897 (packedSelected [1,2,8] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound49897 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env49898 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,2064,268,0,0,262,17,2309,21,1,260,0,16,2,268,17,2048,16,2065,2309,272,0,257,1,1,512]

theorem envBound49898 : H12AffineFastState.Bounded env49898 := by
  intro p hp
  have h : env49898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49897_49898 : H12AffineEnvironment.transform 15 262 env49897 = env49898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env49897 == env49898) = true)

theorem identity49898 : scanCanonicalize (H12AffineFastState.compose env49898 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound49898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49899 : List Nat := [2,4,8,16,0,16,8,256,512,20,0,16,268,0,0,262,17,261,21,1,260,0,16,2,268,17,0,16,17,261,272,0,257,1,1,512]

theorem envBound49899 : H12AffineFastState.Bounded env49899 := by
  intro p hp
  have h : env49899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49898_49899 : H12AffineEnvironment.transform 10 0 env49898 = env49899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env49898 == env49899) = true)

theorem identity49899 : scanCanonicalize (H12AffineFastState.compose env49899 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound49899 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49900 : List Nat := [2,4,8,4,0,4,8,256,512,0,0,4,268,0,0,262,5,261,1,1,260,0,4,2,268,5,0,4,5,261,260,0,257,1,1,512]

theorem envBound49900 : H12AffineFastState.Bounded env49900 := by
  intro p hp
  have h : env49900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49899_49900 : H12AffineEnvironment.transform 3 4 env49899 = env49900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env49899 == env49900) = true)

def env49901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575540,18973701,10507601,8538485,25265168,23160137,257,27378724,27337993,25207631]

theorem envBound49901 : H12AffineFastState.Bounded env49901 := by
  intro p hp
  have h : env49901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49792_49901 : H12AffineEnvironment.transform 6 9 env49792 = env49901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49792 == env49901) = true)

theorem identity49901 : scanCanonicalize (H12AffineFastState.compose env49901 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 8634708) := by decide +kernel

theorem selectedBound49901 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env49902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,8634708,8193,65,4229152,10634577,10507601,8538485,148804,14853149,257,2229616,2286685,221723]

theorem envBound49902 : H12AffineFastState.Bounded env49902 := by
  intro p hp
  have h : env49902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49901_49902 : H12AffineEnvironment.transform 23 8634708 env49901 = env49902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8634708 env49901 == env49902) = true)

def env49903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,98644,8193,65,4229152,2098513,2233681,2421,148804,6349853,257,2229616,2286685,221723]

theorem envBound49903 : H12AffineFastState.Bounded env49903 := by
  intro p hp
  have h : env49903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49902_49903 : H12AffineEnvironment.transform 22 147456 env49902 = env49903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env49902 == env49903) = true)

theorem identity49903 : scanCanonicalize (H12AffineFastState.compose env49903 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49903 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,73754,98644,8193,65,4229152,2098513,2192715,2421,75102,6349853,257,2188650,2196551,513]

theorem envBound49904 : H12AffineFastState.Bounded env49904 := by
  intro p hp
  have h : env49904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49903_49904 : H12AffineEnvironment.transform 16 90138 env49903 = env49904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49903 == env49904) = true)

theorem identity49904 : scanCanonicalize (H12AffineFastState.compose env49904 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound49904 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env49905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,98678,73754,98644,8193,65,67926,2098513,2192715,2421,75102,2188651,257,2188650,2196551,513]

theorem envBound49905 : H12AffineFastState.Bounded env49905 := by
  intro p hp
  have h : env49905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49904_49905 : H12AffineEnvironment.transform 21 98678 env49904 = env49905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env49904 == env49905) = true)

theorem identity49905 : scanCanonicalize (H12AffineFastState.compose env49905 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(20+1) ^^^ 111883) := by decide +kernel

theorem selectedBound49905 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env49906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,111883,98678,73754,98644,8193,65,67926,110682,49216,2421,75102,53344,257,53345,12620,513]

theorem envBound49906 : H12AffineFastState.Bounded env49906 := by
  intro p hp
  have h : env49906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49905_49906 : H12AffineEnvironment.transform 20 111883 env49905 = env49906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111883 env49905 == env49906) = true)

theorem identity49906 : scanCanonicalize (H12AffineFastState.compose env49906 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49906 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env49907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1025,8541,70743,73770,73754,73736,8193,65,67926,69894,24860,2421,75102,28988,257,28989,12620,513]

theorem envBound49907 : H12AffineFastState.Bounded env49907 := by
  intro p hp
  have h : env49907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49906_49907 : H12AffineEnvironment.transform 14 8540 env49906 = env49907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49906 == env49907) = true)

theorem identity49907 : scanCanonicalize (H12AffineFastState.compose env49907 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound49907 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10280,1025,8541,25677,20528,20480,20498,8193,65,31052,24860,24860,2421,21828,28988,257,28989,12620,513]

theorem envBound49908 : H12AffineFastState.Bounded env49908 := by
  intro p hp
  have h : env49908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49907_49908 : H12AffineEnvironment.transform 15 28698 env49907 = env49908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env49907 == env49908) = true)

theorem identity49908 : scanCanonicalize (H12AffineFastState.compose env49908 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound49908 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env49909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2049,8540,14363,4096,10280,1025,8541,11340,6193,6145,6163,8193,65,12621,10525,10525,2421,7493,14653,257,14652,12620,513]

theorem envBound49909 : H12AffineFastState.Bounded env49909 := by
  intro p hp
  have h : env49909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49908_49909 : H12AffineEnvironment.transform 13 2049 env49908 = env49909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env49908 == env49909) = true)

theorem identity49909 : scanCanonicalize (H12AffineFastState.compose env49909 (packedSelected [3,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound49909 : packedSelected [3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,2049,1076,7539,4096,3392,1025,1077,2340,6193,6145,6163,1385,65,5157,3189,3189,2421,7493,7253,257,7252,5156,513]

theorem envBound49910 : H12AffineFastState.Bounded env49910 := by
  intro p hp
  have h : env49910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49909_49910 : H12AffineEnvironment.transform 12 1384 env49909 = env49910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env49909 == env49910) = true)

theorem identity49910 : scanCanonicalize (H12AffineFastState.compose env49910 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49910 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env49911 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,269,2049,81,6422,4096,2341,100,80,2340,6193,6145,6163,268,65,4160,2064,2064,2421,6432,6192,257,6193,4161,513]

theorem envBound49911 : H12AffineFastState.Bounded env49911 := by
  intro p hp
  have h : env49911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49910_49911 : H12AffineEnvironment.transform 9 101 env49910 = env49911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49910 == env49911) = true)

theorem identity49911 : scanCanonicalize (H12AffineFastState.compose env49911 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound49911 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49912 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2064,269,2049,81,262,2064,2341,100,80,2340,33,17,3,268,65,2128,2064,2064,2421,304,32,257,33,2129,513]

theorem envBound49912 : H12AffineFastState.Bounded env49912 := by
  intro p hp
  have h : env49912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49911_49912 : H12AffineEnvironment.transform 11 2064 env49911 = env49912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env49911 == env49912) = true)

theorem identity49912 : scanCanonicalize (H12AffineFastState.compose env49912 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49912 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49913 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2064,121,2049,81,114,2064,2129,100,80,2128,33,17,3,120,65,2128,2064,2064,2049,68,32,117,33,2129,513]

theorem envBound49913 : H12AffineFastState.Bounded env49913 := by
  intro p hp
  have h : env49913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49912_49913 : H12AffineEnvironment.transform 7 116 env49912 = env49913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49912 == env49913) = true)

theorem identity49913 : scanCanonicalize (H12AffineFastState.compose env49913 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound49913 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49914 : List Nat := [2,4,8,16,32,64,9,116,512,101,97,113,121,96,81,114,113,48,100,80,49,33,17,3,120,65,49,113,113,96,68,32,117,33,48,513]

theorem envBound49914 : H12AffineFastState.Bounded env49914 := by
  intro p hp
  have h : env49914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49913_49914 : H12AffineEnvironment.transform 10 97 env49913 = env49914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env49913 == env49914) = true)

theorem identity49914 : scanCanonicalize (H12AffineFastState.compose env49914 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49914 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49915 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,40,49,0,35,32,48,53,1,49,33,17,3,41,16,49,32,32,49,21,32,36,33,48,513]

theorem envBound49915 : H12AffineFastState.Bounded env49915 := by
  intro p hp
  have h : env49915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49914_49915 : H12AffineEnvironment.transform 5 17 env49914 = env49915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49914 == env49915) = true)

def leafEnv49915 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,40,49,0,35,32,48,53,1,49,33,17,3,20,41,1,16,49,32,32,49,21,32,36,33,5,34,48,513,1,48,0]

def active49915 : List Nat := [0,1,2,3,4,8]

def tree49915 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49915 : H12WitnessSearch.Good tree49915 := H12GlobalWitnessIndex.good

theorem leafIdentity49915 : H12AffineFastState.composeSystem env49915 rootObs = leafEnv49915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49915 rootObs == leafEnv49915) = true)

theorem terminalChecked49915 : H12PackedTerminal.terminalCheckFast leafEnv49915 active49915 tree49915 = true := by decide +kernel

def env49916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,98645,8193,65,4229152,2098512,2233680,2420,148804,6349852,257,2229616,2286685,221723]

theorem envBound49916 : H12AffineFastState.Bounded env49916 := by
  intro p hp
  have h : env49916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49902_49916 : H12AffineEnvironment.transform 22 147457 env49902 = env49916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env49902 == env49916) = true)

def env49917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,98645,8193,65,4229152,2098512,2118976,2420,1364,6349852,257,2114912,2139213,74251]

theorem envBound49917 : H12AffineFastState.Bounded env49917 := by
  intro p hp
  have h : env49917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49916_49917 : H12AffineEnvironment.transform 16 16400 env49916 = env49917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49916 == env49917) = true)

theorem identity49917 : scanCanonicalize (H12AffineFastState.compose env49917 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49917 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env49918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,2097152,4194304,17,73737,8193,65,4204924,2098512,2118976,2420,1364,6309184,257,2114912,2098449,74251]

theorem envBound49918 : H12AffineFastState.Bounded env49918 := by
  intro p hp
  have h : env49918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49917_49918 : H12AffineEnvironment.transform 14 8540 env49917 = env49918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49917 == env49918) = true)

theorem identity49918 : scanCanonicalize (H12AffineFastState.compose env49918 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound49918 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env49919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28698,16400,10280,1025,8541,2097152,4194304,17,20499,8193,65,4204924,2098512,2118976,2420,1364,6309184,257,2114912,2098449,21009]

theorem envBound49919 : H12AffineFastState.Bounded env49919 := by
  intro p hp
  have h : env49919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49918_49919 : H12AffineEnvironment.transform 15 28698 env49918 = env49919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env49918 == env49919) = true)

theorem identity49919 : scanCanonicalize (H12AffineFastState.compose env49919 (packedSelected [0,4,7,11,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound49919 : packedSelected [0,4,7,11,17,18,22] rootPS < 2^1333 := by decide +kernel

def env49920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1125,21795,16400,3345,1025,1124,2097152,4194304,17,20499,1336,65,4197445,2098512,2118976,2420,1364,6309184,257,2114912,2098449,21009]

theorem envBound49920 : H12AffineFastState.Bounded env49920 := by
  intro p hp
  have h : env49920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49919_49920 : H12AffineEnvironment.transform 12 1337 env49919 = env49920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env49919 == env49920) = true)

theorem identity49920 : scanCanonicalize (H12AffineFastState.compose env49920 (packedSelected [3,5,10,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 2101572) := by decide +kernel

theorem selectedBound49920 : packedSelected [3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env49921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1125,21795,16400,3345,1025,1124,2097152,2101572,17,20499,1336,65,2104577,2098512,2118976,2420,1364,21508,257,2114912,2098449,21009]

theorem envBound49921 : H12AffineFastState.Bounded env49921 := by
  intro p hp
  have h : env49921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49920_49921 : H12AffineEnvironment.transform 21 2101572 env49920 = env49921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101572 env49920 == env49921) = true)

theorem identity49921 : scanCanonicalize (H12AffineFastState.compose env49921 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 16756) := by decide +kernel

theorem selectedBound49921 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env49922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1125,21795,16400,3345,1025,1124,16756,20528,17,20499,1336,65,23669,17444,5172,2420,1364,21508,257,1044,17509,21009]

theorem envBound49922 : H12AffineFastState.Bounded env49922 := by
  intro p hp
  have h : env49922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49921_49922 : H12AffineEnvironment.transform 20 16756 env49921 = env49922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16756 env49921 == env49922) = true)

theorem identity49922 : scanCanonicalize (H12AffineFastState.compose env49922 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound49922 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,2048,1125,7459,2064,3345,1025,1124,2420,6192,17,6163,1336,65,5237,3108,5172,2420,1364,7172,257,1044,3173,6673]

theorem envBound49923 : H12AffineFastState.Bounded env49923 := by
  intro p hp
  have h : env49923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49922_49923 : H12AffineEnvironment.transform 13 2048 env49922 = env49923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env49922 == env49923) = true)

theorem identity49923 : scanCanonicalize (H12AffineFastState.compose env49923 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound49923 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,16,1337,2048,1125,3379,2064,3345,1025,1124,2420,2080,17,2051,1336,65,1125,3108,1060,2420,1364,3092,257,1044,3173,2561]

theorem envBound49924 : H12AffineFastState.Bounded env49924 := by
  intro p hp
  have h : env49924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49923_49924 : H12AffineEnvironment.transform 11 16 env49923 = env49924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49923 == env49924) = true)

theorem identity49924 : scanCanonicalize (H12AffineFastState.compose env49924 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound49924 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env49925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1076,16,1337,1076,1125,263,1060,293,1025,1124,1344,1044,17,1079,1336,65,1125,16,1060,1344,1364,32,257,1044,81,1589]

theorem envBound49925 : H12AffineFastState.Bounded env49925 := by
  intro p hp
  have h : env49925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49924_49925 : H12AffineEnvironment.transform 10 1076 env49924 = env49925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env49924 == env49925) = true)

theorem identity49925 : scanCanonicalize (H12AffineFastState.compose env49925 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49925 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49926 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1076,16,1052,1076,1125,34,1060,0,1025,1124,1125,1044,17,1079,1053,65,1125,16,1060,1125,1137,32,36,1044,81,1589]

theorem envBound49926 : H12AffineFastState.Bounded env49926 := by
  intro p hp
  have h : env49926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49925_49926 : H12AffineEnvironment.transform 7 37 env49925 = env49926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49925 == env49926) = true)

def env49927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,98645,8193,65,4229152,2098512,2118977,2420,1365,6349852,257,2114913,2139212,74250]

theorem envBound49927 : H12AffineFastState.Bounded env49927 := by
  intro p hp
  have h : env49927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49916_49927 : H12AffineEnvironment.transform 16 16401 env49916 = env49927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49916 == env49927) = true)

theorem identity49927 : scanCanonicalize (H12AffineFastState.compose env49927 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound49927 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env49928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,73771,16,98645,8193,65,108555,2098512,2118977,2420,1365,2212919,257,2114913,2139212,74250]

theorem envBound49928 : H12AffineFastState.Bounded env49928 := by
  intro p hp
  have h : env49928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49927_49928 : H12AffineEnvironment.transform 21 73771 env49927 = env49928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env49927 == env49928) = true)

theorem identity49928 : scanCanonicalize (H12AffineFastState.compose env49928 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 124187) := by decide +kernel

theorem selectedBound49928 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env49929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,124187,73771,16,98645,8193,65,108555,122955,110682,2420,1365,8492,257,106618,82263,74250]

theorem envBound49929 : H12AffineFastState.Bounded env49929 := by
  intro p hp
  have h : env49929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49928_49929 : H12AffineEnvironment.transform 20 124187 env49928 = env49929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124187 env49928 == env49929) = true)

theorem identity49929 : scanCanonicalize (H12AffineFastState.compose env49929 (packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound49929 : packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env49930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,16401,35188,1025,32769,58397,8493,16,32851,8193,65,43277,57677,45404,2420,1365,8492,257,41340,16465,8972]

theorem envBound49930 : H12AffineFastState.Bounded env49930 := by
  intro p hp
  have h : env49930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49929_49930 : H12AffineEnvironment.transform 15 262 env49929 = env49930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env49929 == env49930) = true)

theorem identity49930 : scanCanonicalize (H12AffineFastState.compose env49930 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49930 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env49931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,262,16401,10281,1025,8540,17728,8493,16,8462,8193,65,2128,16400,4097,2420,1365,8492,257,33,16465,8972]

theorem envBound49931 : H12AffineFastState.Bounded env49931 := by
  intro p hp
  have h : env49931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49930_49931 : H12AffineEnvironment.transform 14 8541 env49930 = env49931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49930 == env49931) = true)

theorem identity49931 : scanCanonicalize (H12AffineFastState.compose env49931 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound49931 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8541,262,13673,10281,1025,8540,12344,8493,16,8462,8193,65,2128,13672,4097,2420,1365,8492,257,33,13609,8972]

theorem envBound49932 : H12AffineFastState.Bounded env49932 := by
  intro p hp
  have h : env49932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49931_49932 : H12AffineEnvironment.transform 13 13688 env49931 = env49932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env49931 == env49932) = true)

theorem identity49932 : scanCanonicalize (H12AffineFastState.compose env49932 (packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49932 : packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env49933 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13324,8233,114,13341,10281,1025,8232,12344,8281,16,8314,8193,65,2128,13340,4097,2048,1057,8280,117,33,13405,8824]

theorem envBound49933 : H12AffineFastState.Bounded env49933 := by
  intro p hp
  have h : env49933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49932_49933 : H12AffineEnvironment.transform 7 116 env49932 = env49933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49932 == env49933) = true)

theorem identity49933 : scanCanonicalize (H12AffineFastState.compose env49933 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound49933 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49934 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,5236,81,114,5221,2129,1025,80,4160,33,16,2,121,65,2128,5220,4097,2048,1057,32,117,33,5157,512]

theorem envBound49934 : H12AffineFastState.Bounded env49934 := by
  intro p hp
  have h : env49934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49933_49934 : H12AffineEnvironment.transform 12 120 env49933 = env49934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env49933 == env49934) = true)

def env49935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374097,4294967296,525568,4308116844,27337992,25733063]

theorem envBound49935 : H12AffineFastState.Bounded env49935 := by
  intro p hp
  have h : env49935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43993_49935 : H12AffineEnvironment.transform 28 77616401 env43993 = env49935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env43993 == env49935) = true)

def env49936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound49936 : H12AffineFastState.Bounded env49936 := by
  intro p hp
  have h : env49936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49935_49936 : H12AffineEnvironment.transform 31 145662400 env49935 = env49936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env49935 == env49936) = true)

def env49937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound49937 : H12AffineFastState.Bounded env49937 := by
  intro p hp
  have h : env49937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49936_49937 : H12AffineEnvironment.transform 29 155254784 env49936 = env49937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env49936 == env49937) = true)

def env49938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound49938 : H12AffineFastState.Bounded env49938 := by
  intro p hp
  have h : env49938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49937_49938 : H12AffineEnvironment.transform 25 64 env49937 = env49938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env49937 == env49938) = true)

def env49939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound49939 : H12AffineFastState.Bounded env49939 := by
  intro p hp
  have h : env49939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49938_49939 : H12AffineEnvironment.transform 26 30393344 env49938 = env49939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env49938 == env49939) = true)

def env49940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound49940 : H12AffineFastState.Bounded env49940 := by
  intro p hp
  have h : env49940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49939_49940 : H12AffineEnvironment.transform 18 1024 env49939 = env49940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env49939 == env49940) = true)

theorem identity49940 : scanCanonicalize (H12AffineFastState.compose env49940 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound49940 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188616,8328,64,15115592,57797,10507601,8830976,10543449,4194440,256,8430052,8405056,10602127]

theorem envBound49941 : H12AffineFastState.Bounded env49941 := by
  intro p hp
  have h : env49941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49940_49941 : H12AffineEnvironment.transform 23 2188616 env49940 = env49941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env49940 == env49941) = true)

def env49942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62660,2188616,8328,64,6705548,57797,2138517,406724,2102685,4194440,256,21792,46212,2175563]

theorem envBound49942 : H12AffineFastState.Bounded env49942 := by
  intro p hp
  have h : env49942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49941_49942 : H12AffineEnvironment.transform 22 62660 env49941 = env49942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env49941 == env49942) = true)

def env49943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62660,2188616,8328,64,158028,57797,2138517,406724,2102685,2373704,256,21792,46212,2175563]

theorem envBound49943 : H12AffineFastState.Bounded env49943 := by
  intro p hp
  have h : env49943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49942_49943 : H12AffineEnvironment.transform 21 2373824 env49942 = env49943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env49942 == env49943) = true)

theorem identity49943 : scanCanonicalize (H12AffineFastState.compose env49943 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound49943 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329866,62660,21762,8328,64,158028,57797,102879,406724,75223,329730,256,21792,46212,513]

theorem envBound49944 : H12AffineFastState.Bounded env49944 := by
  intro p hp
  have h : env49944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49943_49944 : H12AffineEnvironment.transform 20 77898 env49943 = env49944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env49943 == env49944) = true)

def env49945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329730,62540,21762,8192,64,158028,57677,102743,406604,75103,329730,256,21792,46092,513]

theorem envBound49945 : H12AffineFastState.Bounded env49945 := by
  intro p hp
  have h : env49945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49944_49945 : H12AffineEnvironment.transform 6 8 env49944 = env49945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49944 == env49945) = true)

theorem identity49945 : scanCanonicalize (H12AffineFastState.compose env49945 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49945 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,77898,329730,62540,21762,8192,64,67926,57677,102743,349270,75103,329730,256,21792,46092,513]

theorem envBound49946 : H12AffineFastState.Bounded env49946 := by
  intro p hp
  have h : env49946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49945_49946 : H12AffineEnvironment.transform 16 90138 env49945 = env49946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49945 == env49946) = true)

def env49947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,77898,73770,62540,21762,8192,64,67926,57677,102743,97406,75103,73770,256,21792,46092,513]

theorem envBound49947 : H12AffineFastState.Bounded env49947 := by
  intro p hp
  have h : env49947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49946_49947 : H12AffineEnvironment.transform 17 10280 env49946 = env49947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49946 == env49947) = true)

theorem identity49947 : scanCanonicalize (H12AffineFastState.compose env49947 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound49947 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10280,1024,29789,77898,73770,16,21762,8192,64,67926,5393,91403,97406,75103,73770,256,21792,16464,513]

theorem envBound49948 : H12AffineFastState.Bounded env49948 := by
  intro p hp
  have h : env49948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49947_49948 : H12AffineEnvironment.transform 14 29788 env49947 = env49948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env49947 == env49948) = true)

theorem identity49948 : scanCanonicalize (H12AffineFastState.compose env49948 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 31791) := by decide +kernel

theorem selectedBound49948 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env49949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,31791,7221,10280,1024,29789,19557,23557,16,21762,8192,64,30073,5393,6436,81,22896,23557,256,21792,16464,513]

theorem envBound49949 : H12AffineFastState.Bounded env49949 := by
  intro p hp
  have h : env49949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49948_49949 : H12AffineEnvironment.transform 15 31791 env49948 = env49949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31791 env49948 == env49949) = true)

theorem identity49949 : scanCanonicalize (H12AffineFastState.compose env49949 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49949 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,10543,7221,10280,1024,8541,6501,2309,16,2,8192,64,8313,5393,6436,81,3184,2309,256,32,5456,513]

theorem envBound49950 : H12AffineFastState.Bounded env49950 := by
  intro p hp
  have h : env49950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49949_49950 : H12AffineEnvironment.transform 13 5376 env49949 = env49950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49949 == env49950) = true)

theorem identity49950 : scanCanonicalize (H12AffineFastState.compose env49950 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound49950 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,1296,3427,7221,3172,1024,1297,6501,2309,16,2,1100,64,1077,5393,6436,81,3184,2309,256,32,5456,513]

theorem envBound49951 : H12AffineFastState.Bounded env49951 := by
  intro p hp
  have h : env49951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49950_49951 : H12AffineEnvironment.transform 12 1100 env49950 = env49951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env49950 == env49951) = true)

theorem identity49951 : scanCanonicalize (H12AffineFastState.compose env49951 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound49951 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env49952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,1100,5376,1296,34,4468,293,1024,1297,5156,1092,16,2,1100,64,1077,5393,5221,81,305,1092,256,32,5456,513]

theorem envBound49952 : H12AffineFastState.Bounded env49952 := by
  intro p hp
  have h : env49952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49951_49952 : H12AffineEnvironment.transform 10 1345 env49951 = env49952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env49951 == env49952) = true)

theorem identity49952 : scanCanonicalize (H12AffineFastState.compose env49952 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49952 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49953 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1077,4096,1100,5236,1124,34,4096,81,1024,1125,5156,1092,16,2,1100,64,1077,5221,5221,81,69,1092,116,32,5156,513]

theorem envBound49953 : H12AffineFastState.Bounded env49953 := by
  intro p hp
  have h : env49953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49952_49953 : H12AffineEnvironment.transform 7 116 env49952 = env49953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49952 == env49953) = true)

theorem identity49953 : scanCanonicalize (H12AffineFastState.compose env49953 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49953 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49954 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,4096,1052,5156,1076,34,4096,1,1024,1077,5156,1044,16,2,1052,16,1077,5173,5173,1,21,1044,36,32,5156,513]

theorem envBound49954 : H12AffineFastState.Bounded env49954 := by
  intro p hp
  have h : env49954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49953_49954 : H12AffineEnvironment.transform 5 16 env49953 = env49954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49953 == env49954) = true)

theorem identity49954 : scanCanonicalize (H12AffineFastState.compose env49954 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound49954 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env49955 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,1044,1052,48,1076,34,1044,1,1024,1077,48,1044,16,2,1052,16,1077,33,33,1,21,1044,36,32,48,513]

theorem envBound49955 : H12AffineFastState.Bounded env49955 := by
  intro p hp
  have h : env49955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49954_49955 : H12AffineEnvironment.transform 11 1044 env49954 = env49955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env49954 == env49955) = true)

def env49956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,77898,73771,62540,21762,8192,64,67926,57677,102743,97407,75103,73771,256,21792,46092,513]

theorem envBound49956 : H12AffineFastState.Bounded env49956 := by
  intro p hp
  have h : env49956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49946_49956 : H12AffineEnvironment.transform 17 10281 env49946 = env49956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49946 == env49956) = true)

theorem identity49956 : scanCanonicalize (H12AffineFastState.compose env49956 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound49956 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,16464,20529,62540,21762,8192,64,31052,57677,57677,3173,21829,20529,256,21792,46092,513]

theorem envBound49957 : H12AffineFastState.Bounded env49957 := by
  intro p hp
  have h : env49957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49956_49957 : H12AffineEnvironment.transform 15 28698 env49956 = env49957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env49956 == env49957) = true)

theorem identity49957 : scanCanonicalize (H12AffineFastState.compose env49957 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49957 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10281,1024,8541,16464,20529,21776,21762,8192,64,31052,16401,16401,3173,21829,20529,256,21792,5456,513]

theorem envBound49958 : H12AffineFastState.Bounded env49958 := by
  intro p hp
  have h : env49958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49957_49958 : H12AffineEnvironment.transform 14 8540 env49957 = env49958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49957 == env49958) = true)

theorem identity49958 : scanCanonicalize (H12AffineFastState.compose env49958 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound49958 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env49959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,1344,21510,4096,3125,1024,1345,16464,20529,21776,21762,1052,64,23888,16401,16401,3173,21829,20529,256,21792,5456,513]

theorem envBound49959 : H12AffineFastState.Bounded env49959 := by
  intro p hp
  have h : env49959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49958_49959 : H12AffineEnvironment.transform 12 1052 env49958 = env49959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env49958 == env49959) = true)

theorem identity49959 : scanCanonicalize (H12AffineFastState.compose env49959 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49959 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env49960 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,121,16384,293,20579,4096,2128,101,292,16464,20529,20853,20839,121,64,22837,16401,16401,2048,20768,20529,256,20805,4405,513]

theorem envBound49960 : H12AffineFastState.Bounded env49960 := by
  intro p hp
  have h : env49960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49959_49960 : H12AffineEnvironment.transform 9 101 env49959 = env49960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49959 == env49960) = true)

theorem identity49960 : scanCanonicalize (H12AffineFastState.compose env49960 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 2420) := by decide +kernel

theorem selectedBound49960 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env49961 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,121,2420,293,6423,4096,2128,101,292,2340,6469,6145,6163,121,64,4161,2405,2405,2048,6228,6469,256,6193,4405,513]

theorem envBound49961 : H12AffineFastState.Bounded env49961 := by
  intro p hp
  have h : env49961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49960_49961 : H12AffineEnvironment.transform 13 2420 env49960 = env49961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2420 env49960 == env49961) = true)

def env49962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329731,62541,21762,8193,64,158028,57676,102742,406605,75102,329730,256,21792,46093,513]

theorem envBound49962 : H12AffineFastState.Bounded env49962 := by
  intro p hp
  have h : env49962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49944_49962 : H12AffineEnvironment.transform 6 9 env49944 = env49962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49944 == env49962) = true)

def env49963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77898,73771,62541,21762,8193,64,158028,57676,102742,138341,75102,73770,256,21792,46093,513]

theorem envBound49963 : H12AffineFastState.Bounded env49963 := by
  intro p hp
  have h : env49963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49962_49963 : H12AffineEnvironment.transform 17 10280 env49962 = env49963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49962 == env49963) = true)

def env49964 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,73771,62493,21762,8193,16,157980,57628,102662,138293,75022,73770,256,21792,46093,513]

theorem envBound49964 : H12AffineFastState.Bounded env49964 := by
  intro p hp
  have h : env49964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49963_49964 : H12AffineEnvironment.transform 5 16 env49963 = env49964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49963 == env49964) = true)

theorem identity49964 : scanCanonicalize (H12AffineFastState.compose env49964 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49964 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env49965 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,10280,1024,1,77850,73771,29725,21762,8193,16,157980,24860,69894,138293,75022,73770,256,21792,13325,513]

theorem envBound49965 : H12AffineFastState.Bounded env49965 := by
  intro p hp
  have h : env49965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49964_49965 : H12AffineEnvironment.transform 14 0 env49964 = env49965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49964 == env49965) = true)

theorem identity49965 : scanCanonicalize (H12AffineFastState.compose env49965 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound49965 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env49966 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,16400,10280,1024,1,77850,73771,29725,21762,8193,16,10508,24860,69894,23589,75022,73770,256,21792,13325,513]

theorem envBound49966 : H12AffineFastState.Bounded env49966 := by
  intro p hp
  have h : env49966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49965_49966 : H12AffineEnvironment.transform 16 16400 env49965 = env49966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49965 == env49966) = true)

theorem identity49966 : scanCanonicalize (H12AffineFastState.compose env49966 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49966 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49967 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,8202,16400,10280,1024,1,4112,33,29725,21762,8193,16,10508,24860,12556,23589,1284,32,256,21792,13325,513]

theorem envBound49967 : H12AffineFastState.Bounded env49967 := by
  intro p hp
  have h : env49967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49966_49967 : H12AffineEnvironment.transform 15 8202 env49966 = env49967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49966 == env49967) = true)

theorem identity49967 : scanCanonicalize (H12AffineFastState.compose env49967 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound49967 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49968 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1024,1,4112,33,16,8463,8193,16,10508,5393,12556,10280,1284,32,256,8493,13325,513]

theorem envBound49968 : H12AffineFastState.Bounded env49968 := by
  intro p hp
  have h : env49968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49967_49968 : H12AffineEnvironment.transform 13 13325 env49967 = env49968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env49967 == env49968) = true)

theorem identity49968 : scanCanonicalize (H12AffineFastState.compose env49968 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49968 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49969 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1024,1,4112,33,16,3,269,16,2048,5393,4096,2340,1284,32,256,33,5377,513]

theorem envBound49969 : H12AffineFastState.Bounded env49969 := by
  intro p hp
  have h : env49969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49968_49969 : H12AffineEnvironment.transform 12 268 env49968 = env49969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49968 == env49969) = true)

theorem identity49969 : scanCanonicalize (H12AffineFastState.compose env49969 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49970 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5172,2049,1024,1,4112,33,16,3,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound49970 : H12AffineFastState.Bounded env49970 := by
  intro p hp
  have h : env49970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49969_49970 : H12AffineEnvironment.transform 7 37 env49969 = env49970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49969 == env49970) = true)

def env49971 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,0,35,1028,2049,1024,1,32,33,16,3,40,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound49971 : H12AffineFastState.Bounded env49971 := by
  intro p hp
  have h : env49971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49970_49971 : H12AffineEnvironment.transform 11 48 env49970 = env49971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49970 == env49971) = true)

theorem identity49971 : scanCanonicalize (H12AffineFastState.compose env49971 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49972 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,41,32,0,35,48,2049,52,1,32,33,16,3,40,16,2048,48,48,2049,21,32,37,33,32,513]

theorem envBound49972 : H12AffineFastState.Bounded env49972 := by
  intro p hp
  have h : env49972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49971_49972 : H12AffineEnvironment.transform 9 52 env49971 = env49972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49971 == env49972) = true)

theorem identity49972 : scanCanonicalize (H12AffineFastState.compose env49972 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49973 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,0,2,17,2049,21,1,1,0,16,3,9,16,2048,17,17,2049,21,1,4,0,1,513]

theorem envBound49973 : H12AffineFastState.Bounded env49973 := by
  intro p hp
  have h : env49973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49972_49973 : H12AffineEnvironment.transform 4 1 env49972 = env49973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49972 == env49973) = true)

def leafEnv49973 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,0,2,17,2049,21,1,1,0,16,3,21,9,1,16,2048,17,17,2049,21,1,4,0,4,3,1,513,1,1,0]

def active49973 : List Nat := [0,1,2,3,8,10]

def tree49973 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49973 : H12WitnessSearch.Good tree49973 := H12GlobalWitnessIndex.good

theorem leafIdentity49973 : H12AffineFastState.composeSystem env49973 rootObs = leafEnv49973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49973 rootObs == leafEnv49973) = true)

theorem terminalChecked49973 : H12PackedTerminal.terminalCheckFast leafEnv49973 active49973 tree49973 = true := by decide +kernel

def env49974 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,0,35,1029,2049,1024,1,33,33,16,3,40,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound49974 : H12AffineFastState.Bounded env49974 := by
  intro p hp
  have h : env49974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49970_49974 : H12AffineEnvironment.transform 11 49 env49970 = env49974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49970 == env49974) = true)

def env49975 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,73771,62492,21762,8193,17,157981,57629,102663,138292,75023,73770,256,21792,46093,513]

theorem envBound49975 : H12AffineFastState.Bounded env49975 := by
  intro p hp
  have h : env49975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49963_49975 : H12AffineEnvironment.transform 5 17 env49963 = env49975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49963 == env49975) = true)

theorem identity49975 : scanCanonicalize (H12AffineFastState.compose env49975 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound49975 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env49976 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77851,73771,62492,21762,8193,17,67846,57629,102663,97327,75023,73770,256,21792,46093,513]

theorem envBound49976 : H12AffineFastState.Bounded env49976 := by
  intro p hp
  have h : env49976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49975_49976 : H12AffineEnvironment.transform 16 90139 env49975 = env49976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env49975 == env49976) = true)

theorem identity49976 : scanCanonicalize (H12AffineFastState.compose env49976 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound49976 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49977 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,65536,90139,10280,1024,21760,77851,73771,8477,21762,8193,17,67846,13340,82950,97327,75023,73770,256,21792,24844,513]

theorem envBound49977 : H12AffineFastState.Bounded env49977 := by
  intro p hp
  have h : env49977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49976_49977 : H12AffineEnvironment.transform 14 21761 env49976 = env49977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env49976 == env49977) = true)

theorem identity49977 : scanCanonicalize (H12AffineFastState.compose env49977 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound49977 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49978 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,29962,5393,10280,1024,21760,17681,21793,8477,21762,8193,17,31756,13340,12556,2341,20485,21792,256,21792,24844,513]

theorem envBound49978 : H12AffineFastState.Bounded env49978 := by
  intro p hp
  have h : env49978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49977_49978 : H12AffineEnvironment.transform 15 29962 env49977 = env49978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env49977 == env49978) = true)

theorem identity49978 : scanCanonicalize (H12AffineFastState.compose env49978 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound49978 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env49979 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13608,8233,34,5393,10280,1024,8232,12345,8201,8477,8234,8193,17,2340,13340,12556,2341,9517,8200,256,8200,5156,513]

theorem envBound49979 : H12AffineFastState.Bounded env49979 := by
  intro p hp
  have h : env49979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49978_49979 : H12AffineEnvironment.transform 13 13608 env49978 = env49979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env49978 == env49979) = true)

theorem identity49979 : scanCanonicalize (H12AffineFastState.compose env49979 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49979 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49980 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,1,34,5393,2048,1024,0,4113,33,309,2,41,17,2340,5172,4388,2341,1285,32,256,32,5156,513]

theorem envBound49980 : H12AffineFastState.Bounded env49980 := by
  intro p hp
  have h : env49980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49979_49980 : H12AffineEnvironment.transform 12 40 env49979 = env49980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49979 == env49980) = true)

theorem identity49980 : scanCanonicalize (H12AffineFastState.compose env49980 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound49980 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49981 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,308,40,1076,1,34,1061,2048,1024,0,293,33,309,2,41,17,2340,1280,16,2341,1285,32,256,32,1296,513]

theorem envBound49981 : H12AffineFastState.Bounded env49981 := by
  intro p hp
  have h : env49981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49980_49981 : H12AffineEnvironment.transform 11 308 env49980 = env49981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env49980 == env49981) = true)

theorem identity49981 : scanCanonicalize (H12AffineFastState.compose env49981 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49981 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env49982 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,308,40,1076,1,34,1061,1077,1024,0,293,33,309,2,41,17,1297,1280,16,1296,1285,32,256,32,1296,513]

theorem envBound49982 : H12AffineFastState.Bounded env49982 := by
  intro p hp
  have h : env49982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49981_49982 : H12AffineEnvironment.transform 10 1077 env49981 = env49982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env49981 == env49982) = true)

theorem identity49982 : scanCanonicalize (H12AffineFastState.compose env49982 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound49982 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49983 : List Nat := [2,4,8,16,32,17,9,256,512,304,261,308,40,260,1,34,277,261,304,0,293,33,309,2,41,17,33,48,16,32,53,32,256,32,32,513]

theorem envBound49983 : H12AffineFastState.Bounded env49983 := by
  intro p hp
  have h : env49983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49982_49983 : H12AffineEnvironment.transform 9 304 env49982 = env49983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env49982 == env49983) = true)

theorem identity49983 : scanCanonicalize (H12AffineFastState.compose env49983 (packedSelected [0,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 43) := by decide +kernel

theorem selectedBound49983 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env49984 : List Nat := [2,4,8,16,32,17,9,43,512,27,46,31,40,47,1,34,62,46,27,0,14,33,30,2,41,17,33,48,16,32,53,32,43,32,32,513]

theorem envBound49984 : H12AffineFastState.Bounded env49984 := by
  intro p hp
  have h : env49984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49983_49984 : H12AffineEnvironment.transform 7 43 env49983 = env49984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 43 env49983 == env49984) = true)

theorem identity49984 : scanCanonicalize (H12AffineFastState.compose env49984 (packedSelected [2,14] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound49984 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env49985 : List Nat := [2,4,7,16,32,17,6,36,512,20,33,16,39,32,1,34,49,33,20,0,1,33,17,2,38,17,33,48,16,32,53,32,36,32,32,513]

theorem envBound49985 : H12AffineFastState.Bounded env49985 := by
  intro p hp
  have h : env49985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49984_49985 : H12AffineEnvironment.transform 2 7 env49984 = env49985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env49984 == env49985) = true)

theorem identity49985 : scanCanonicalize (H12AffineFastState.compose env49985 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound49985 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49986 : List Nat := [2,4,7,16,32,17,6,36,5,20,33,16,39,32,1,34,49,33,20,0,1,33,17,2,38,17,33,48,16,32,53,32,36,32,32,4]

theorem envBound49986 : H12AffineFastState.Bounded env49986 := by
  intro p hp
  have h : env49986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49985_49986 : H12AffineEnvironment.transform 8 5 env49985 = env49986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env49985 == env49986) = true)

theorem identity49986 : scanCanonicalize (H12AffineFastState.compose env49986 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49987 : List Nat := [0,4,5,16,32,17,4,36,5,20,33,16,37,32,1,32,49,33,20,0,1,33,17,0,36,17,33,48,16,32,53,32,36,32,32,4]

theorem envBound49987 : H12AffineFastState.Bounded env49987 := by
  intro p hp
  have h : env49987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49986_49987 : H12AffineEnvironment.transform 0 0 env49986 = env49987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49986 == env49987) = true)

def env49988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77898,73770,62541,21762,8193,64,158028,57676,102742,138340,75102,73771,256,21792,46093,513]

theorem envBound49988 : H12AffineFastState.Bounded env49988 := by
  intro p hp
  have h : env49988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49962_49988 : H12AffineEnvironment.transform 17 10281 env49962 = env49988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49962 == env49988) = true)

theorem identity49988 : scanCanonicalize (H12AffineFastState.compose env49988 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49988 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,77898,73770,16,21762,8193,64,158028,5393,91403,138340,75102,73771,256,21792,16464,513]

theorem envBound49989 : H12AffineFastState.Bounded env49989 := by
  intro p hp
  have h : env49989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49988_49989 : H12AffineEnvironment.transform 14 29789 env49988 = env49989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49988 == env49989) = true)

theorem identity49989 : scanCanonicalize (H12AffineFastState.compose env49989 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49989 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10281,1024,29788,77898,73770,16,21762,8193,64,67926,5393,91403,97406,75102,73771,256,21792,16464,513]

theorem envBound49990 : H12AffineFastState.Bounded env49990 := by
  intro p hp
  have h : env49990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49989_49990 : H12AffineEnvironment.transform 16 90138 env49989 = env49990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49989 == env49990) = true)

theorem identity49990 : scanCanonicalize (H12AffineFastState.compose env49990 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound49990 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,28698,4096,10281,1024,29788,16464,20528,16,21762,8193,64,31052,5393,5393,3172,21828,20529,256,21792,16464,513]

theorem envBound49991 : H12AffineFastState.Bounded env49991 := by
  intro p hp
  have h : env49991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49990_49991 : H12AffineEnvironment.transform 15 28698 env49990 = env49991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env49990 == env49991) = true)

theorem identity49991 : scanCanonicalize (H12AffineFastState.compose env49991 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound49991 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env49992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,16464,17431,4096,7204,1024,16465,16464,20528,16,21762,5132,64,19777,5393,5393,3172,21828,20529,256,21792,16464,513]

theorem envBound49992 : H12AffineFastState.Bounded env49992 := by
  intro p hp
  have h : env49992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49991_49992 : H12AffineEnvironment.transform 12 5133 env49991 = env49992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env49991 == env49992) = true)

theorem identity49992 : scanCanonicalize (H12AffineFastState.compose env49992 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound49992 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env49993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,16384,16464,17431,1061,2049,1024,16465,16464,17429,16,16679,41,64,19777,308,308,3172,16737,17428,256,16645,16464,513]

theorem envBound49993 : H12AffineFastState.Bounded env49993 := by
  intro p hp
  have h : env49993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49992_49993 : H12AffineEnvironment.transform 11 1061 env49992 = env49993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env49992 == env49993) = true)

theorem identity49993 : scanCanonicalize (H12AffineFastState.compose env49993 (packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound49993 : packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env49994 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,3393,3345,2390,1061,2049,1024,3344,3345,2388,16,3174,41,64,0,308,308,3172,3104,2389,256,3140,3345,513]

theorem envBound49994 : H12AffineFastState.Bounded env49994 := by
  intro p hp
  have h : env49994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49993_49994 : H12AffineEnvironment.transform 13 3393 env49993 = env49994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env49993 == env49994) = true)

theorem identity49994 : scanCanonicalize (H12AffineFastState.compose env49994 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49994 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env49995 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,64,40,2340,2420,2390,64,2049,101,2421,2420,2388,16,2051,41,64,0,308,308,2049,2117,2389,256,2081,2420,513]

theorem envBound49995 : H12AffineFastState.Bounded env49995 := by
  intro p hp
  have h : env49995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49994_49995 : H12AffineEnvironment.transform 9 101 env49994 = env49995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49994 == env49995) = true)

theorem identity49995 : scanCanonicalize (H12AffineFastState.compose env49995 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound49995 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env49996 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,64,40,81,1,35,64,372,101,0,1,33,16,374,41,64,0,308,308,372,304,32,256,340,1,513]

theorem envBound49996 : H12AffineFastState.Bounded env49996 := by
  intro p hp
  have h : env49996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49995_49996 : H12AffineEnvironment.transform 10 373 env49995 = env49996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env49995 == env49996) = true)

theorem identity49996 : scanCanonicalize (H12AffineFastState.compose env49996 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49997 : List Nat := [2,4,8,16,32,0,9,256,512,37,309,0,40,17,1,35,0,308,37,0,1,33,16,310,41,0,0,308,308,308,304,32,256,276,1,513]

theorem envBound49997 : H12AffineFastState.Bounded env49997 := by
  intro p hp
  have h : env49997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49996_49997 : H12AffineEnvironment.transform 5 0 env49996 = env49997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49996 == env49997) = true)

theorem identity49997 : scanCanonicalize (H12AffineFastState.compose env49997 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound49997 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49998 : List Nat := [2,4,8,16,32,0,9,256,309,37,309,0,40,17,1,35,0,308,37,0,1,33,16,310,41,0,0,308,308,308,304,32,256,276,1,308]

theorem envBound49998 : H12AffineFastState.Bounded env49998 := by
  intro p hp
  have h : env49998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49997_49998 : H12AffineEnvironment.transform 8 309 env49997 = env49998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env49997 == env49998) = true)

theorem identity49998 : scanCanonicalize (H12AffineFastState.compose env49998 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49998 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49999 : List Nat := [2,4,8,16,32,0,9,36,17,37,17,0,40,17,1,35,0,16,37,0,1,33,16,18,41,0,0,16,16,16,20,32,36,48,1,16]

theorem envBound49999 : H12AffineFastState.Bounded env49999 := by
  intro p hp
  have h : env49999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49998_49999 : H12AffineEnvironment.transform 7 36 env49998 = env49999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49998 == env49999) = true)

theorem identity49999 : scanCanonicalize (H12AffineFastState.compose env49999 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50000 : List Nat := [2,4,8,16,1,0,9,5,17,4,17,0,9,17,1,2,0,16,4,0,1,0,16,18,8,0,0,16,16,16,20,1,5,17,1,16]

theorem envBound50000 : H12AffineFastState.Bounded env50000 := by
  intro p hp
  have h : env50000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49999_50000 : H12AffineEnvironment.transform 4 1 env49999 = env50000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49999 == env50000) = true)

theorem identity50000 : scanCanonicalize (H12AffineFastState.compose env50000 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50000 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50001 : List Nat := [2,4,8,1,1,0,9,5,0,4,0,0,9,0,1,2,0,1,4,0,1,0,1,3,8,0,0,1,1,1,5,1,5,0,1,1]

theorem envBound50001 : H12AffineFastState.Bounded env50001 := by
  intro p hp
  have h : env50001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50000_50001 : H12AffineEnvironment.transform 3 1 env50000 = env50001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50000 == env50001) = true)

def env50002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62660,2188616,8328,64,158029,57797,2138517,406724,2102685,2373705,256,21792,46212,2175563]

theorem envBound50002 : H12AffineFastState.Bounded env50002 := by
  intro p hp
  have h : env50002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49942_50002 : H12AffineEnvironment.transform 21 2373825 env49942 = env50002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env49942 == env50002) = true)

theorem identity50002 : scanCanonicalize (H12AffineFastState.compose env50002 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50002 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,2373825,16,2188616,8328,64,158029,5393,2118977,406724,2102685,2373705,256,21792,16464,2175563]

theorem envBound50003 : H12AffineFastState.Bounded env50003 := by
  intro p hp
  have h : env50003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50002_50003 : H12AffineEnvironment.transform 14 29908 env50002 = env50003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50002 == env50003) = true)

def env50004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,2373825,16,2175048,8328,64,146509,5393,2097217,406724,2102685,2373705,256,32,5456,2175563]

theorem envBound50004 : H12AffineFastState.Bounded env50004 := by
  intro p hp
  have h : env50004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50003_50004 : H12AffineEnvironment.transform 13 5376 env50003 = env50004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50003 == env50004) = true)

def env50005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,262144,1024,8661,2097152,2373825,16,2175048,8328,64,10589,5393,2097217,270804,2102685,2373705,256,32,5456,2175563]

theorem envBound50005 : H12AffineFastState.Bounded env50005 := by
  intro p hp
  have h : env50005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50004_50005 : H12AffineEnvironment.transform 16 5392 env50004 = env50005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env50004 == env50005) = true)

theorem identity50005 : scanCanonicalize (H12AffineFastState.compose env50005 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound50005 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env50006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,262144,1024,8661,77898,329867,16,2,8328,64,10589,5393,77835,270804,75223,329731,256,32,5456,513]

theorem envBound50006 : H12AffineFastState.Bounded env50006 := by
  intro p hp
  have h : env50006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50005_50006 : H12AffineEnvironment.transform 20 77898 env50005 = env50006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env50005 == env50006) = true)

theorem identity50006 : scanCanonicalize (H12AffineFastState.compose env50006 (packedSelected [0,2,4,6,11,14,18,20,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound50006 : packedSelected [0,2,4,6,11,14,18,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env50007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,10281,1024,8661,77898,73890,16,2,8328,64,10589,5393,77835,2557,75223,73770,256,32,5456,513]

theorem envBound50007 : H12AffineFastState.Bounded env50007 := by
  intro p hp
  have h : env50007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50006_50007 : H12AffineEnvironment.transform 17 10281 env50006 = env50007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50006 == env50007) = true)

theorem identity50007 : scanCanonicalize (H12AffineFastState.compose env50007 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound50007 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,170,5392,10281,1024,8661,12512,8200,16,2,8328,64,10589,5393,12449,2557,9597,8320,256,32,5456,513]

theorem envBound50008 : H12AffineFastState.Bounded env50008 := by
  intro p hp
  have h : env50008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50007_50008 : H12AffineEnvironment.transform 15 170 env50007 = env50008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env50007 == env50008) = true)

theorem identity50008 : scanCanonicalize (H12AffineFastState.compose env50008 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound50008 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env50009 : List Nat := [2,4,8,16,32,64,128,256,512,204,2048,4096,8192,4556,8660,170,4572,10281,204,8661,12512,8200,16,2,8328,64,10589,4573,12449,2557,8625,8320,256,32,4508,513]

theorem envBound50009 : H12AffineFastState.Bounded env50009 := by
  intro p hp
  have h : env50009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50008_50009 : H12AffineEnvironment.transform 9 204 env50008 = env50009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env50008 == env50009) = true)

theorem identity50009 : scanCanonicalize (H12AffineFastState.compose env50009 (packedSelected [1,2,3,4,5,6,8,9,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound50009 : packedSelected [1,2,3,4,5,6,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env50010 : List Nat := [2,4,8,16,32,64,128,256,512,204,2048,308,8192,248,8660,170,232,10281,204,8661,8660,8200,16,2,8328,64,10589,233,8597,2557,8625,8320,256,32,168,513]

theorem envBound50010 : H12AffineFastState.Bounded env50010 := by
  intro p hp
  have h : env50010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50009_50010 : H12AffineEnvironment.transform 11 308 env50009 = env50010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env50009 == env50010) = true)

theorem identity50010 : scanCanonicalize (H12AffineFastState.compose env50010 (packedSelected [0,1,2,4,7,8,9,19] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound50010 : packedSelected [0,1,2,4,7,8,9,19] rootPS < 2^1333 := by decide +kernel

def env50011 : List Nat := [2,4,8,16,32,64,128,256,512,204,2048,308,160,248,372,170,232,2185,204,373,372,168,16,2,40,64,2557,233,309,2557,273,32,256,32,168,513]

theorem envBound50011 : H12AffineFastState.Bounded env50011 := by
  intro p hp
  have h : env50011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50010_50011 : H12AffineEnvironment.transform 12 160 env50010 = env50011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env50010 == env50011) = true)

theorem identity50011 : scanCanonicalize (H12AffineFastState.compose env50011 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound50011 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50012 : List Nat := [2,4,8,16,32,64,128,220,512,204,2048,232,160,248,168,170,232,2185,204,169,168,168,16,2,40,64,2081,233,233,2081,205,32,220,32,168,513]

theorem envBound50012 : H12AffineFastState.Bounded env50012 := by
  intro p hp
  have h : env50012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50011_50012 : H12AffineEnvironment.transform 7 220 env50011 = env50012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env50011 == env50012) = true)

theorem identity50012 : scanCanonicalize (H12AffineFastState.compose env50012 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound50012 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50013 : List Nat := [2,4,8,16,32,64,41,117,512,101,2048,65,9,81,1,3,65,2080,101,0,1,1,16,2,40,64,2081,64,64,2081,100,32,117,32,1,513]

theorem envBound50013 : H12AffineFastState.Bounded env50013 := by
  intro p hp
  have h : env50013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50012_50013 : H12AffineEnvironment.transform 6 41 env50012 = env50013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env50012 == env50013) = true)

theorem identity50013 : scanCanonicalize (H12AffineFastState.compose env50013 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50014 : List Nat := [2,4,8,16,32,16,41,37,512,53,2048,17,9,1,1,3,17,2080,53,0,1,1,16,2,40,16,2081,16,16,2081,52,32,37,32,1,513]

theorem envBound50014 : H12AffineFastState.Bounded env50014 := by
  intro p hp
  have h : env50014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50013_50014 : H12AffineEnvironment.transform 5 16 env50013 = env50014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50013 == env50014) = true)

theorem identity50014 : scanCanonicalize (H12AffineFastState.compose env50014 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50014 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50015 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,17,9,1,1,3,17,2049,20,0,1,1,16,2,9,16,2048,16,16,2048,21,1,4,1,1,513]

theorem envBound50015 : H12AffineFastState.Bounded env50015 := by
  intro p hp
  have h : env50015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50014_50015 : H12AffineEnvironment.transform 4 1 env50014 = env50015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50014 == env50015) = true)

theorem identity50015 : scanCanonicalize (H12AffineFastState.compose env50015 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound50015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50016 : List Nat := [2,4,8,16,1,16,8,4,512,20,529,17,9,1,1,3,17,528,20,0,1,1,16,2,9,16,529,16,16,529,21,1,4,1,1,513]

theorem envBound50016 : H12AffineFastState.Bounded env50016 := by
  intro p hp
  have h : env50016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50015_50016 : H12AffineEnvironment.transform 10 529 env50015 = env50016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env50015 == env50016) = true)

theorem identity50016 : scanCanonicalize (H12AffineFastState.compose env50016 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50016 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50017 : List Nat := [2,4,8,0,1,0,8,4,512,4,513,1,9,1,1,3,1,512,4,0,1,1,0,2,9,0,513,0,0,513,5,1,4,1,1,513]

theorem envBound50017 : H12AffineFastState.Bounded env50017 := by
  intro p hp
  have h : env50017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50016_50017 : H12AffineEnvironment.transform 3 0 env50016 = env50017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50016 == env50017) = true)

def env50018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5393,262144,1024,8661,2097152,2373825,16,2175048,8328,64,10588,5393,2097217,270805,2102685,2373705,256,32,5456,2175563]

theorem envBound50018 : H12AffineFastState.Bounded env50018 := by
  intro p hp
  have h : env50018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50004_50018 : H12AffineEnvironment.transform 16 5393 env50004 = env50018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env50004 == env50018) = true)

def env50019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,5393,262144,1024,8581,2097152,2373777,16,2175000,8328,16,10508,5393,2097169,270725,2102685,2373657,256,32,5376,2175515]

theorem envBound50019 : H12AffineFastState.Bounded env50019 := by
  intro p hp
  have h : env50019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50018_50019 : H12AffineEnvironment.transform 5 16 env50018 = env50019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50018 == env50019) = true)

theorem identity50019 : scanCanonicalize (H12AffineFastState.compose env50019 (packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS)) = affineNative (2^(20+1) ^^^ 334011) := by decide +kernel

theorem selectedBound50019 : packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS < 2^1333 := by decide +kernel

def env50020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,5393,262144,1024,8581,334011,73770,16,272547,8328,16,10508,5393,333994,270725,331046,73890,256,32,5376,273056]

theorem envBound50020 : H12AffineFastState.Bounded env50020 := by
  intro p hp
  have h : env50020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50019_50020 : H12AffineEnvironment.transform 20 334011 env50019 = env50020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 334011 env50019 == env50020) = true)

theorem identity50020 : scanCanonicalize (H12AffineFastState.compose env50020 (packedSelected [0,4,7,11,12,15,16,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound50020 : packedSelected [0,4,7,11,12,15,16,20,22,23] rootPS < 2^1333 := by decide +kernel

def env50021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,398,5393,262144,1024,8581,268597,8612,16,272547,8328,16,10508,5393,268580,270725,265384,8492,256,32,5376,273056]

theorem envBound50021 : H12AffineFastState.Bounded env50021 := by
  intro p hp
  have h : env50021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50020_50021 : H12AffineEnvironment.transform 15 398 env50020 = env50021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env50020 == env50021) = true)

theorem identity50021 : scanCanonicalize (H12AffineFastState.compose env50021 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound50021 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env50022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5376,0,398,5393,262144,1024,1,268597,32,16,264487,268,16,2184,5393,268580,262145,265384,168,256,32,5376,264996]

theorem envBound50022 : H12AffineFastState.Bounded env50022 := by
  intro p hp
  have h : env50022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50021_50022 : H12AffineEnvironment.transform 12 388 env50021 = env50022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env50021 == env50022) = true)

theorem identity50022 : scanCanonicalize (H12AffineFastState.compose env50022 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound50022 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env50023 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,300,5376,0,294,5393,262144,1024,1,268597,32,16,264487,268,16,2080,5393,268580,262145,265216,0,256,32,5376,264996]

theorem envBound50023 : H12AffineFastState.Bounded env50023 := by
  intro p hp
  have h : env50023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50022_50023 : H12AffineEnvironment.transform 6 40 env50022 = env50023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env50022 == env50023) = true)

theorem identity50023 : scanCanonicalize (H12AffineFastState.compose env50023 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound50023 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50024 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,300,5376,0,294,5393,2340,1024,1,4113,32,16,3,268,16,2080,5393,4096,2341,1316,0,256,32,5376,512]

theorem envBound50024 : H12AffineFastState.Bounded env50024 := by
  intro p hp
  have h : env50024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50023_50024 : H12AffineEnvironment.transform 17 2340 env50023 = env50024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env50023 == env50024) = true)

theorem identity50024 : scanCanonicalize (H12AffineFastState.compose env50024 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50024 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50025 : List Nat := [2,4,8,16,32,16,40,256,512,53,2048,4096,300,4405,0,294,4388,2340,53,1,4113,32,16,3,268,16,2080,4388,4096,2341,273,0,256,32,4405,512]

theorem envBound50025 : H12AffineFastState.Bounded env50025 := by
  intro p hp
  have h : env50025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50024_50025 : H12AffineEnvironment.transform 9 53 env50024 = env50025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50024 == env50025) = true)

theorem identity50025 : scanCanonicalize (H12AffineFastState.compose env50025 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50025 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50026 : List Nat := [2,4,8,16,32,16,40,37,512,53,2048,4096,9,4112,0,3,4097,2049,53,1,4113,32,16,3,41,16,2080,4097,4096,2048,52,0,37,32,4112,512]

theorem envBound50026 : H12AffineFastState.Bounded env50026 := by
  intro p hp
  have h : env50026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50025_50026 : H12AffineEnvironment.transform 7 37 env50025 = env50026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50025 == env50026) = true)

theorem identity50026 : scanCanonicalize (H12AffineFastState.compose env50026 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound50026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50027 : List Nat := [2,4,8,16,32,16,40,37,31,53,2048,4096,9,4112,0,3,4097,2049,53,1,4113,32,16,3,41,16,2080,4097,4096,2048,52,0,37,32,4112,31]

theorem envBound50027 : H12AffineFastState.Bounded env50027 := by
  intro p hp
  have h : env50027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50026_50027 : H12AffineEnvironment.transform 8 31 env50026 = env50027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env50026 == env50027) = true)

def env50028 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,65536,5393,262144,1024,8580,2097152,2373776,16,2175001,8328,17,10509,5393,2097168,270724,2102685,2373656,256,32,5377,2175514]

theorem envBound50028 : H12AffineFastState.Bounded env50028 := by
  intro p hp
  have h : env50028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50018_50028 : H12AffineEnvironment.transform 5 17 env50018 = env50028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50018 == env50028) = true)

theorem identity50028 : scanCanonicalize (H12AffineFastState.compose env50028 (packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound50028 : packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS < 2^1333 := by decide +kernel

def env50029 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,1,65536,5393,262144,1024,0,2097152,2365716,16,2167197,268,17,2185,5393,2097168,262144,2102685,2365852,256,32,5377,2167710]

theorem envBound50029 : H12AffineFastState.Bounded env50029 := by
  intro p hp
  have h : env50029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50028_50029 : H12AffineEnvironment.transform 12 388 env50028 = env50029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env50028 == env50029) = true)

theorem identity50029 : scanCanonicalize (H12AffineFastState.compose env50029 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 268733) := by decide +kernel

theorem selectedBound50029 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env50030 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,1,65536,5393,262144,1024,0,268733,169,16,329760,268,17,2185,5393,268717,262144,265248,33,256,32,5377,330275]

theorem envBound50030 : H12AffineFastState.Bounded env50030 := by
  intro p hp
  have h : env50030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50029_50030 : H12AffineEnvironment.transform 20 268733 env50029 = env50030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268733 env50029 == env50030) = true)

theorem identity50030 : scanCanonicalize (H12AffineFastState.compose env50030 (packedSelected [0,2,3,4,5,6,7,10,11,12,16,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound50030 : packedSelected [0,2,3,4,5,6,7,10,11,12,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50031 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5293,1,65536,5308,262144,1024,0,268304,169,16,329760,161,17,2185,5308,268288,262144,265248,33,173,32,5292,330275]

theorem envBound50031 : H12AffineFastState.Bounded env50031 := by
  intro p hp
  have h : env50031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50030_50031 : H12AffineEnvironment.transform 7 173 env50030 = env50031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env50030 == env50031) = true)

theorem identity50031 : scanCanonicalize (H12AffineFastState.compose env50031 (packedSelected [0,6,7,11,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 67722) := by decide +kernel

theorem selectedBound50031 : packedSelected [0,6,7,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50032 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5293,1,65536,5308,67722,1024,0,69786,169,16,170,161,17,2185,5308,69770,67722,66730,33,173,32,5292,681]

theorem envBound50032 : H12AffineFastState.Bounded env50032 := by
  intro p hp
  have h : env50032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50031_50032 : H12AffineEnvironment.transform 17 67722 env50031 = env50032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67722 env50031 == env50032) = true)

theorem identity50032 : scanCanonicalize (H12AffineFastState.compose env50032 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound50032 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50033 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5293,1,3,5308,2185,1024,0,4249,169,16,170,161,17,2185,5308,4233,2185,1193,33,173,32,5292,681]

theorem envBound50033 : H12AffineFastState.Bounded env50033 := by
  intro p hp
  have h : env50033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50032_50033 : H12AffineEnvironment.transform 15 3 env50032 = env50033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env50032 == env50033) = true)

theorem identity50033 : scanCanonicalize (H12AffineFastState.compose env50033 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50033 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50034 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,3,5173,2048,1024,0,4112,32,16,35,40,17,2048,5173,4096,2048,1056,33,36,32,5157,544]

theorem envBound50034 : H12AffineFastState.Bounded env50034 := by
  intro p hp
  have h : env50034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50033_50034 : H12AffineEnvironment.transform 6 9 env50033 = env50034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50033 == env50034) = true)

theorem identity50034 : scanCanonicalize (H12AffineFastState.compose env50034 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50034 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50035 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,1,3,5141,2048,1024,0,4112,0,16,3,8,17,2048,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound50035 : H12AffineFastState.Bounded env50035 := by
  intro p hp
  have h : env50035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50034_50035 : H12AffineEnvironment.transform 4 0 env50034 = env50035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50034 == env50035) = true)

theorem identity50035 : scanCanonicalize (H12AffineFastState.compose env50035 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound50035 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50036 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,3076,9,2048,1,3,2065,2048,1024,0,3092,0,16,3,8,17,2048,2065,3076,2048,1024,1,4,0,2049,512]

theorem envBound50036 : H12AffineFastState.Bounded env50036 := by
  intro p hp
  have h : env50036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50035_50036 : H12AffineEnvironment.transform 11 3076 env50035 = env50036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env50035 == env50036) = true)

theorem identity50036 : scanCanonicalize (H12AffineFastState.compose env50036 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50036 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50037 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,2065,9,2048,1,3,2065,2048,21,0,2049,0,16,3,8,17,2048,2065,2065,2048,21,1,4,0,2049,512]

theorem envBound50037 : H12AffineFastState.Bounded env50037 := by
  intro p hp
  have h : env50037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50036_50037 : H12AffineEnvironment.transform 9 21 env50036 = env50037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50036 == env50037) = true)

theorem identity50037 : scanCanonicalize (H12AffineFastState.compose env50037 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50037 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50038 : List Nat := [2,4,8,16,0,17,9,4,0,21,2048,2065,9,2048,1,3,2065,2048,21,0,2049,0,16,3,8,17,2048,2065,2065,2048,21,1,4,0,2049,0]

theorem envBound50038 : H12AffineFastState.Bounded env50038 := by
  intro p hp
  have h : env50038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50037_50038 : H12AffineEnvironment.transform 8 0 env50037 = env50038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50037 == env50038) = true)

theorem identity50038 : scanCanonicalize (H12AffineFastState.compose env50038 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound50038 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50039 : List Nat := [2,4,8,5,0,4,9,4,0,0,2048,2052,9,2048,1,3,2052,2048,0,0,2049,0,5,3,8,4,2048,2052,2052,2048,0,1,4,0,2049,0]

theorem envBound50039 : H12AffineFastState.Bounded env50039 := by
  intro p hp
  have h : env50039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50038_50039 : H12AffineEnvironment.transform 3 5 env50038 = env50039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env50038 == env50039) = true)

def leafEnv50039 : List Nat := [2,4,8,5,0,4,9,4,0,0,2048,2052,9,2048,1,3,2052,2048,0,0,2049,0,5,3,0,8,1,4,2048,2052,2052,2048,0,1,4,0,4,2,2049,0,1,2048,0]

def active50039 : List Nat := [0,1,2,10]

def tree50039 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50039 : H12WitnessSearch.Good tree50039 := H12GlobalWitnessIndex.good

theorem leafIdentity50039 : H12AffineFastState.composeSystem env50039 rootObs = leafEnv50039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50039 rootObs == leafEnv50039) = true)

theorem terminalChecked50039 : H12PackedTerminal.terminalCheckFast leafEnv50039 active50039 tree50039 = true := by decide +kernel

def env50040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,2373825,16,2175049,8328,64,146508,5393,2097216,406724,2102685,2373705,256,33,5457,2175563]

theorem envBound50040 : H12AffineFastState.Bounded env50040 := by
  intro p hp
  have h : env50040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50003_50040 : H12AffineEnvironment.transform 13 5377 env50003 = env50040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50003 == env50040) = true)

theorem identity50040 : scanCanonicalize (H12AffineFastState.compose env50040 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50040 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50041 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,2097152,2373704,16,2175049,8193,64,146508,5393,2097216,406605,2102548,2373705,256,33,5457,2175563]

theorem envBound50041 : H12AffineFastState.Bounded env50041 := by
  intro p hp
  have h : env50041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50040_50041 : H12AffineEnvironment.transform 6 9 env50040 = env50041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50040 == env50041) = true)

def env50042 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5392,262144,1024,8541,2097152,2373704,16,2175049,8193,64,10588,5393,2097216,270685,2102548,2373705,256,33,5457,2175563]

theorem envBound50042 : H12AffineFastState.Bounded env50042 := by
  intro p hp
  have h : env50042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50041_50042 : H12AffineEnvironment.transform 16 5392 env50041 = env50042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env50041 == env50042) = true)

theorem identity50042 : scanCanonicalize (H12AffineFastState.compose env50042 (packedSelected [0,4,7,11,18,22,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound50042 : packedSelected [0,4,7,11,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env50043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5392,262144,1024,8541,4160,272392,16,73737,8193,64,10588,5393,4096,270685,1364,272393,256,33,5457,74251]

theorem envBound50043 : H12AffineFastState.Bounded env50043 := by
  intro p hp
  have h : env50043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50042_50043 : H12AffineEnvironment.transform 20 4160 env50042 = env50043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50042 == env50043) = true)

theorem identity50043 : scanCanonicalize (H12AffineFastState.compose env50043 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound50043 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,2,5392,262144,1024,8541,4160,272392,16,8203,8193,64,10588,5393,4096,270685,1364,272393,256,33,5457,8713]

theorem envBound50044 : H12AffineFastState.Bounded env50044 := by
  intro p hp
  have h : env50044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50043_50044 : H12AffineEnvironment.transform 15 2 env50043 = env50044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env50043 == env50044) = true)

theorem identity50044 : scanCanonicalize (H12AffineFastState.compose env50044 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound50044 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,2,5392,2080,1024,8541,4160,8232,16,8203,8193,64,10588,5393,4096,10621,1364,8233,256,33,5457,8713]

theorem envBound50045 : H12AffineFastState.Bounded env50045 := by
  intro p hp
  have h : env50045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50044_50045 : H12AffineEnvironment.transform 17 2080 env50044 = env50045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env50044 == env50045) = true)

theorem identity50045 : scanCanonicalize (H12AffineFastState.compose env50045 (packedSelected [1,3,5,6,8,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50045 : packedSelected [1,3,5,6,8,11,12,16] rootPS < 2^1333 := by decide +kernel

def env50046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,2,5392,2080,1024,81,4160,292,16,263,269,64,2128,5393,4096,2161,1364,293,256,33,5457,773]

theorem envBound50046 : H12AffineFastState.Bounded env50046 := by
  intro p hp
  have h : env50046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50045_50046 : H12AffineEnvironment.transform 12 268 env50045 = env50046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50045 == env50046) = true)

theorem identity50046 : scanCanonicalize (H12AffineFastState.compose env50046 (packedSelected [0,4,5,6,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 830) := by decide +kernel

theorem selectedBound50046 : packedSelected [0,4,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,830,268,1599,80,2,1582,2080,1024,81,894,292,16,263,269,64,2128,1583,830,2161,1364,293,256,33,1647,773]

theorem envBound50047 : H12AffineFastState.Bounded env50047 := by
  intro p hp
  have h : env50047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50046_50047 : H12AffineEnvironment.transform 11 830 env50046 = env50047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 830 env50046 == env50047) = true)

theorem identity50047 : scanCanonicalize (H12AffineFastState.compose env50047 (packedSelected [1,2,4,5,6,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50047 : packedSelected [1,2,4,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env50048 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,571,9,1599,80,2,1582,2080,1024,81,635,33,16,2,8,64,2128,1583,571,2161,1105,32,5,33,1647,512]

theorem envBound50048 : H12AffineFastState.Bounded env50048 := by
  intro p hp
  have h : env50048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50047_50048 : H12AffineEnvironment.transform 7 5 env50047 = env50048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50047 == env50048) = true)

theorem identity50048 : scanCanonicalize (H12AffineFastState.compose env50048 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1615) := by decide +kernel

theorem selectedBound50048 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50049 : List Nat := [2,4,8,16,32,64,9,5,512,1024,1615,571,9,1599,80,2,1582,1647,1024,81,635,33,16,2,8,64,1567,1583,571,1598,1105,32,5,33,1647,512]

theorem envBound50049 : H12AffineFastState.Bounded env50049 := by
  intro p hp
  have h : env50049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50048_50049 : H12AffineEnvironment.transform 10 1615 env50048 = env50049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1615 env50048 == env50049) = true)

theorem identity50049 : scanCanonicalize (H12AffineFastState.compose env50049 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50049 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50050 : List Nat := [2,4,8,16,32,64,9,5,512,20,603,571,9,555,80,2,570,635,20,81,635,33,16,2,8,64,523,571,571,554,69,32,5,33,635,512]

theorem envBound50050 : H12AffineFastState.Bounded env50050 := by
  intro p hp
  have h : env50050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50049_50050 : H12AffineEnvironment.transform 9 20 env50049 = env50050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50049 == env50050) = true)

theorem identity50050 : scanCanonicalize (H12AffineFastState.compose env50050 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound50050 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50051 : List Nat := [2,4,8,16,32,64,9,5,122,20,33,65,9,81,80,2,64,1,20,81,1,33,16,2,8,64,113,65,65,80,69,32,5,33,1,122]

theorem envBound50051 : H12AffineFastState.Bounded env50051 := by
  intro p hp
  have h : env50051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50050_50051 : H12AffineEnvironment.transform 8 122 env50050 = env50051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env50050 == env50051) = true)

theorem identity50051 : scanCanonicalize (H12AffineFastState.compose env50051 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50051 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50052 : List Nat := [2,4,8,16,32,48,9,5,10,20,33,49,9,33,32,2,48,1,20,33,1,33,16,2,8,48,1,49,49,32,53,32,5,33,1,10]

theorem envBound50052 : H12AffineFastState.Bounded env50052 := by
  intro p hp
  have h : env50052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50051_50052 : H12AffineEnvironment.transform 5 48 env50051 = env50052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50051 == env50052) = true)

theorem identity50052 : scanCanonicalize (H12AffineFastState.compose env50052 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound50052 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50053 : List Nat := [2,4,8,14,32,46,9,5,10,10,33,47,9,33,32,2,46,1,10,33,1,33,14,2,8,46,1,47,47,32,43,32,5,33,1,10]

theorem envBound50053 : H12AffineFastState.Bounded env50053 := by
  intro p hp
  have h : env50053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50052_50053 : H12AffineEnvironment.transform 3 14 env50052 = env50053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env50052 == env50053) = true)

theorem identity50053 : scanCanonicalize (H12AffineFastState.compose env50053 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50054 : List Nat := [0,4,8,12,32,44,9,5,8,8,33,45,9,33,32,0,44,1,8,33,1,33,12,0,8,44,1,45,45,32,41,32,5,33,1,8]

theorem envBound50054 : H12AffineFastState.Bounded env50054 := by
  intro p hp
  have h : env50054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50053_50054 : H12AffineEnvironment.transform 0 0 env50053 = env50054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50053 == env50054) = true)

def env50055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5393,262144,1024,8541,2097152,2373704,16,2175049,8193,64,10589,5393,2097216,270684,2102548,2373705,256,33,5457,2175563]

theorem envBound50055 : H12AffineFastState.Bounded env50055 := by
  intro p hp
  have h : env50055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50041_50055 : H12AffineEnvironment.transform 16 5393 env50041 = env50055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env50041 == env50055) = true)

theorem identity50055 : scanCanonicalize (H12AffineFastState.compose env50055 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound50055 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env50056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5393,262144,1024,8541,77898,329730,16,3,8193,64,10589,5393,77834,270684,75102,329731,256,33,5457,513]

theorem envBound50056 : H12AffineFastState.Bounded env50056 := by
  intro p hp
  have h : env50056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50055_50056 : H12AffineEnvironment.transform 20 77898 env50055 = env50056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env50055 == env50056) = true)

theorem identity50056 : scanCanonicalize (H12AffineFastState.compose env50056 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound50056 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5393,67618,1024,8541,77898,32,16,3,8193,64,10589,5393,77834,76158,75102,33,256,33,5457,513]

theorem envBound50057 : H12AffineFastState.Bounded env50057 := by
  intro p hp
  have h : env50057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50056_50057 : H12AffineEnvironment.transform 17 67618 env50056 = env50057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env50056 == env50057) = true)

theorem identity50057 : scanCanonicalize (H12AffineFastState.compose env50057 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound50057 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env50058 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8192,5205,8200,65536,5189,67618,1024,8201,77898,32,16,3,8193,64,10249,5189,77834,75818,74762,33,84,33,5125,513]

theorem envBound50058 : H12AffineFastState.Bounded env50058 := by
  intro p hp
  have h : env50058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50057_50058 : H12AffineEnvironment.transform 7 84 env50057 = env50058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env50057 == env50058) = true)

theorem identity50058 : scanCanonicalize (H12AffineFastState.compose env50058 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50058 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50059 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8192,5205,8200,8202,5189,10280,1024,8201,4160,32,16,3,8193,64,10249,5189,4096,2080,1024,33,84,33,5125,513]

theorem envBound50059 : H12AffineFastState.Bounded env50059 := by
  intro p hp
  have h : env50059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50058_50059 : H12AffineEnvironment.transform 15 8202 env50058 = env50059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50058 == env50059) = true)

theorem identity50059 : scanCanonicalize (H12AffineFastState.compose env50059 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50059 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50060 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8192,5125,8200,8202,5141,10280,1024,8201,4112,32,16,3,8193,16,10249,5141,4096,2080,1024,33,4,33,5125,513]

theorem envBound50060 : H12AffineFastState.Bounded env50060 := by
  intro p hp
  have h : env50060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50059_50060 : H12AffineEnvironment.transform 5 16 env50059 = env50060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50059 == env50060) = true)

theorem identity50060 : scanCanonicalize (H12AffineFastState.compose env50060 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50060 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50061 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,40,5125,32,34,5141,2048,1024,33,4112,32,16,3,41,16,2081,5141,4096,2080,1024,33,4,33,5125,513]

theorem envBound50061 : H12AffineFastState.Bounded env50061 := by
  intro p hp
  have h : env50061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50060_50061 : H12AffineEnvironment.transform 12 40 env50060 = env50061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50060 == env50061) = true)

theorem identity50061 : scanCanonicalize (H12AffineFastState.compose env50061 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound50061 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50062 : List Nat := [2,4,8,16,32,16,9,4,512,1024,32,4096,40,5125,32,34,5141,32,1024,33,4112,32,16,3,41,16,1,5141,4096,0,1024,33,4,33,5125,513]

theorem envBound50062 : H12AffineFastState.Bounded env50062 := by
  intro p hp
  have h : env50062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50061_50062 : H12AffineEnvironment.transform 10 32 env50061 = env50062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env50061 == env50062) = true)

theorem identity50062 : scanCanonicalize (H12AffineFastState.compose env50062 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50062 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50063 : List Nat := [2,4,8,16,32,16,9,4,0,1024,32,4096,40,5125,32,34,5141,32,1024,33,4112,32,16,3,41,16,1,5141,4096,0,1024,33,4,33,5125,1]

theorem envBound50063 : H12AffineFastState.Bounded env50063 := by
  intro p hp
  have h : env50063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50062_50063 : H12AffineEnvironment.transform 8 0 env50062 = env50063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50062 == env50063) = true)

theorem identity50063 : scanCanonicalize (H12AffineFastState.compose env50063 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50063 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env50064 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1,4096,9,5125,1,3,5141,1,1024,0,4112,1,16,3,8,16,1,5141,4096,0,1024,0,4,0,5125,1]

theorem envBound50064 : H12AffineFastState.Bounded env50064 := by
  intro p hp
  have h : env50064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50063_50064 : H12AffineEnvironment.transform 4 1 env50063 = env50064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50063 == env50064) = true)

theorem identity50064 : scanCanonicalize (H12AffineFastState.compose env50064 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound50064 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50065 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1,1029,9,0,1,3,16,1,1024,0,1045,1,16,3,8,16,1,16,1029,0,1024,0,4,0,0,1]

theorem envBound50065 : H12AffineFastState.Bounded env50065 := by
  intro p hp
  have h : env50065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50064_50065 : H12AffineEnvironment.transform 11 1029 env50064 = env50065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env50064 == env50065) = true)

theorem identity50065 : scanCanonicalize (H12AffineFastState.compose env50065 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50065 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50066 : List Nat := [2,4,8,1,1,1,9,4,0,1024,1,1029,9,0,1,3,1,1,1024,0,1028,1,1,3,8,1,1,1,1029,0,1024,0,4,0,0,1]

theorem envBound50066 : H12AffineFastState.Bounded env50066 := by
  intro p hp
  have h : env50066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50065_50066 : H12AffineEnvironment.transform 3 1 env50065 = env50066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50065 == env50066) = true)

def env50067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62661,2188616,8328,64,6705549,57797,2138516,406725,2102684,4194440,256,21793,46213,2175562]

theorem envBound50067 : H12AffineFastState.Bounded env50067 := by
  intro p hp
  have h : env50067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49941_50067 : H12AffineEnvironment.transform 22 62661 env49941 = env50067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env49941 == env50067) = true)

def env50068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62661,2188616,8328,64,158029,57797,2138516,406725,2102684,2373704,256,21793,46213,2175562]

theorem envBound50068 : H12AffineFastState.Bounded env50068 := by
  intro p hp
  have h : env50068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50067_50068 : H12AffineEnvironment.transform 21 2373824 env50067 = env50068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env50067 == env50068) = true)

theorem identity50068 : scanCanonicalize (H12AffineFastState.compose env50068 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound50068 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,392286,62661,41430,8328,64,158029,57797,91402,406725,119042,392406,256,21793,46213,63188]

theorem envBound50069 : H12AffineFastState.Bounded env50069 := by
  intro p hp
  have h : env50069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50068_50069 : H12AffineEnvironment.transform 20 115870 env50068 = env50069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env50068 == env50069) = true)

def env50070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115870,119926,62661,41430,8328,64,158029,57797,91402,138477,119042,120062,256,21793,46213,63188]

theorem envBound50070 : H12AffineFastState.Bounded env50070 := by
  intro p hp
  have h : env50070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50069_50070 : H12AffineEnvironment.transform 17 10280 env50069 = env50070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50069 == env50070) = true)

def env50071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102814,98678,41413,41430,8328,64,146509,46277,77834,138477,99330,98814,256,33,46213,41940]

theorem envBound50071 : H12AffineFastState.Bounded env50071 := by
  intro p hp
  have h : env50071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50070_50071 : H12AffineEnvironment.transform 13 5376 env50070 = env50071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50070 == env50071) = true)

theorem identity50071 : scanCanonicalize (H12AffineFastState.compose env50071 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102679,98678,41292,41311,8193,64,146509,46156,77834,138340,99330,98679,256,33,46092,41821]

theorem envBound50072 : H12AffineFastState.Bounded env50072 := by
  intro p hp
  have h : env50072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50071_50072 : H12AffineEnvironment.transform 6 9 env50071 = env50072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50071 == env50072) = true)

theorem identity50072 : scanCanonicalize (H12AffineFastState.compose env50072 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50072 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env50073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,77899,73770,16,3,8193,64,146509,5392,77834,138340,75102,73771,256,33,5456,513]

theorem envBound50073 : H12AffineFastState.Bounded env50073 := by
  intro p hp
  have h : env50073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50072_50073 : H12AffineEnvironment.transform 14 8540 env50072 = env50073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50072 == env50073) = true)

theorem identity50073 : scanCanonicalize (H12AffineFastState.compose env50073 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound50073 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env50074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,70678,10280,1024,8541,77899,73770,16,3,8193,64,75867,5392,77834,67698,75102,73771,256,33,5456,513]

theorem envBound50074 : H12AffineFastState.Bounded env50074 := by
  intro p hp
  have h : env50074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50073_50074 : H12AffineEnvironment.transform 16 70678 env50073 = env50074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env50073 == env50074) = true)

theorem identity50074 : scanCanonicalize (H12AffineFastState.compose env50074 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50074 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50075 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,65536,70678,10280,1024,8461,77851,73770,16,3,8193,16,75787,5392,77834,67618,75022,73771,256,33,5376,513]

theorem envBound50075 : H12AffineFastState.Bounded env50075 := by
  intro p hp
  have h : env50075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50074_50075 : H12AffineEnvironment.transform 5 16 env50074 = env50075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50074 == env50075) = true)

theorem identity50075 : scanCanonicalize (H12AffineFastState.compose env50075 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50075 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50076 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,65536,70678,2340,1024,1,69911,65830,16,3,269,16,67847,5392,69894,67618,66562,65831,256,33,5376,513]

theorem envBound50076 : H12AffineFastState.Bounded env50076 := by
  intro p hp
  have h : env50076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50075_50076 : H12AffineEnvironment.transform 12 268 env50075 = env50076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50075 == env50076) = true)

theorem identity50076 : scanCanonicalize (H12AffineFastState.compose env50076 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound50076 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50077 : List Nat := [2,4,8,16,32,16,9,256,512,1024,560,4096,268,5376,0,65536,70678,788,1024,1,69911,65830,16,3,269,16,66359,5392,69894,66066,66562,65831,256,33,5376,513]

theorem envBound50077 : H12AffineFastState.Bounded env50077 := by
  intro p hp
  have h : env50077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50076_50077 : H12AffineEnvironment.transform 10 560 env50076 = env50077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env50076 == env50077) = true)

theorem identity50077 : scanCanonicalize (H12AffineFastState.compose env50077 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound50077 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env50078 : List Nat := [2,4,8,16,32,16,9,256,512,1024,560,529,268,1809,0,65536,67079,788,1024,1,66310,65830,16,3,269,16,66359,1793,66327,66066,66562,65831,256,33,1809,513]

theorem envBound50078 : H12AffineFastState.Bounded env50078 := by
  intro p hp
  have h : env50078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50077_50078 : H12AffineEnvironment.transform 11 529 env50077 = env50078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env50077 == env50078) = true)

theorem identity50078 : scanCanonicalize (H12AffineFastState.compose env50078 (packedSelected [0,4,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound50078 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env50079 : List Nat := [2,4,8,16,32,16,9,256,512,1024,560,529,268,1809,0,262,1793,788,1024,1,512,32,16,3,269,16,561,1793,529,788,1284,33,256,33,1809,513]

theorem envBound50079 : H12AffineFastState.Bounded env50079 := by
  intro p hp
  have h : env50079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50078_50079 : H12AffineEnvironment.transform 15 262 env50078 = env50079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env50078 == env50079) = true)

theorem identity50079 : scanCanonicalize (H12AffineFastState.compose env50079 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50079 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50080 : List Nat := [2,4,8,16,0,16,9,256,512,1024,528,529,268,1809,0,262,1793,788,1024,1,512,0,16,3,269,16,529,1793,529,788,1284,1,256,1,1809,513]

theorem envBound50080 : H12AffineFastState.Bounded env50080 := by
  intro p hp
  have h : env50080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50079_50080 : H12AffineEnvironment.transform 4 0 env50079 = env50080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50079 == env50080) = true)

theorem identity50080 : scanCanonicalize (H12AffineFastState.compose env50080 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50080 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50081 : List Nat := [2,4,8,16,0,16,9,256,1,1024,17,16,268,1296,0,262,1280,277,1024,1,1,0,16,3,269,16,16,1280,16,277,1284,1,256,1,1296,0]

theorem envBound50081 : H12AffineFastState.Bounded env50081 := by
  intro p hp
  have h : env50081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50080_50081 : H12AffineEnvironment.transform 8 1 env50080 = env50081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50080 == env50081) = true)

def env50082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102815,98679,41412,41430,8328,64,146508,46276,77835,138477,99331,98815,256,32,46213,41941]

theorem envBound50082 : H12AffineFastState.Bounded env50082 := by
  intro p hp
  have h : env50082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50070_50082 : H12AffineEnvironment.transform 13 5377 env50070 = env50082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50070 == env50082) = true)

def env50083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,5392,10280,1024,32769,102815,98679,41412,41430,8328,64,10588,46276,77835,2557,99331,98815,256,32,46213,41941]

theorem envBound50083 : H12AffineFastState.Bounded env50083 := by
  intro p hp
  have h : env50083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50082_50083 : H12AffineEnvironment.transform 16 5392 env50082 = env50083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env50082 == env50083) = true)

theorem identity50083 : scanCanonicalize (H12AffineFastState.compose env50083 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound50083 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,5392,10280,1024,8661,77899,73891,16,2,8328,64,10588,5392,77835,2557,75223,73771,256,32,5457,513]

theorem envBound50084 : H12AffineFastState.Bounded env50084 := by
  intro p hp
  have h : env50084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50083_50084 : H12AffineEnvironment.transform 14 8660 env50083 = env50084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env50083 == env50084) = true)

theorem identity50084 : scanCanonicalize (H12AffineFastState.compose env50084 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound50084 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,65536,5392,2556,1024,1,70047,65911,16,2,348,64,2184,5392,70111,2557,66563,66047,256,32,5457,513]

theorem envBound50085 : H12AffineFastState.Bounded env50085 := by
  intro p hp
  have h : env50085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50084_50085 : H12AffineEnvironment.transform 12 468 env50084 = env50085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env50084 == env50085) = true)

theorem identity50085 : scanCanonicalize (H12AffineFastState.compose env50085 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound50085 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,479,5392,2556,1024,1,4160,168,16,2,348,64,2184,5392,4096,2557,1500,32,256,32,5457,513]

theorem envBound50086 : H12AffineFastState.Bounded env50086 := by
  intro p hp
  have h : env50086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50085_50086 : H12AffineEnvironment.transform 15 479 env50085 = env50086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env50085 == env50086) = true)

theorem identity50086 : scanCanonicalize (H12AffineFastState.compose env50086 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50086 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5392,2420,1024,1,4160,32,16,2,348,64,2048,5392,4096,2421,1364,32,256,32,5457,513]

theorem envBound50087 : H12AffineFastState.Bounded env50087 := by
  intro p hp
  have h : env50087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50086_50087 : H12AffineEnvironment.transform 6 8 env50086 = env50087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50086 == env50087) = true)

theorem identity50087 : scanCanonicalize (H12AffineFastState.compose env50087 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1792) := by decide +kernel

theorem selectedBound50087 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1792,348,513,0,343,528,2420,1024,1,1856,32,16,2,348,64,2048,528,1792,2421,1364,32,256,32,593,513]

theorem envBound50088 : H12AffineFastState.Bounded env50088 := by
  intro p hp
  have h : env50088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50087_50088 : H12AffineEnvironment.transform 11 1792 env50087 = env50088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1792 env50087 == env50088) = true)

theorem identity50088 : scanCanonicalize (H12AffineFastState.compose env50088 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1652) := by decide +kernel

theorem selectedBound50088 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1652,1792,348,513,0,343,528,1792,1024,1,1856,32,16,2,348,64,1652,528,1792,1793,1364,32,256,32,593,513]

theorem envBound50089 : H12AffineFastState.Bounded env50089 := by
  intro p hp
  have h : env50089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50088_50089 : H12AffineEnvironment.transform 10 1652 env50088 = env50089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1652 env50088 == env50089) = true)

theorem identity50089 : scanCanonicalize (H12AffineFastState.compose env50089 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound50089 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50090 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1652,1620,8,513,0,3,528,1620,1024,1,1556,32,16,2,8,64,1652,528,1620,1621,1024,32,84,32,593,513]

theorem envBound50090 : H12AffineFastState.Bounded env50090 := by
  intro p hp
  have h : env50090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50089_50090 : H12AffineEnvironment.transform 7 84 env50089 = env50090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env50089 == env50090) = true)

theorem identity50090 : scanCanonicalize (H12AffineFastState.compose env50090 (packedSelected [2,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50090 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env50091 : List Nat := [2,4,8,16,32,64,8,84,0,1024,1140,1108,8,1,0,3,16,1108,1024,1,1044,32,16,2,8,64,1140,16,1108,1109,1024,32,84,32,81,1]

theorem envBound50091 : H12AffineFastState.Bounded env50091 := by
  intro p hp
  have h : env50091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50090_50091 : H12AffineEnvironment.transform 8 0 env50090 = env50091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50090 == env50091) = true)

theorem identity50091 : scanCanonicalize (H12AffineFastState.compose env50091 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound50091 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50092 : List Nat := [2,4,8,16,32,64,8,84,0,116,0,32,8,1,0,3,16,32,116,1,96,32,16,2,8,64,0,16,32,33,116,32,84,32,81,1]

theorem envBound50092 : H12AffineFastState.Bounded env50092 := by
  intro p hp
  have h : env50092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50091_50092 : H12AffineEnvironment.transform 9 116 env50091 = env50092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env50091 == env50092) = true)

theorem identity50092 : scanCanonicalize (H12AffineFastState.compose env50092 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound50092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50093 : List Nat := [2,4,8,16,32,32,8,52,0,20,0,32,8,1,0,3,16,32,20,1,0,32,16,2,8,32,0,16,32,33,20,32,52,32,49,1]

theorem envBound50093 : H12AffineFastState.Bounded env50093 := by
  intro p hp
  have h : env50093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50092_50093 : H12AffineEnvironment.transform 5 32 env50092 = env50093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env50092 == env50093) = true)

theorem identity50093 : scanCanonicalize (H12AffineFastState.compose env50093 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50094 : List Nat := [2,4,8,16,16,16,8,4,0,20,0,16,8,1,0,3,16,16,20,1,0,16,16,2,8,16,0,16,16,17,20,16,4,16,1,1]

theorem envBound50094 : H12AffineFastState.Bounded env50094 := by
  intro p hp
  have h : env50094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50093_50094 : H12AffineEnvironment.transform 4 16 env50093 = env50094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50093 == env50094) = true)

theorem identity50094 : scanCanonicalize (H12AffineFastState.compose env50094 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50094 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50095 : List Nat := [2,4,8,0,0,0,8,4,0,4,0,0,8,1,0,3,0,0,4,1,0,0,0,2,8,0,0,0,0,1,4,0,4,0,1,1]

theorem envBound50095 : H12AffineFastState.Bounded env50095 := by
  intro p hp
  have h : env50095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50094_50095 : H12AffineEnvironment.transform 3 0 env50094 = env50095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50094 == env50095) = true)

def env50096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,5393,10280,1024,32769,102815,98679,41412,41430,8328,64,10589,46276,77835,2556,99331,98815,256,32,46213,41941]

theorem envBound50096 : H12AffineFastState.Bounded env50096 := by
  intro p hp
  have h : env50096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50082_50096 : H12AffineEnvironment.transform 16 5393 env50082 = env50096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env50082 == env50096) = true)

def env50097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115870,119927,62661,41430,8328,64,158029,57797,91402,138476,119042,120063,256,21793,46213,63188]

theorem envBound50097 : H12AffineFastState.Bounded env50097 := by
  intro p hp
  have h : env50097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50069_50097 : H12AffineEnvironment.transform 17 10281 env50069 = env50097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50069 == env50097) = true)

def env50098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102814,98679,41413,41430,8328,64,146509,46277,77834,138476,99330,98815,256,33,46213,41940]

theorem envBound50098 : H12AffineFastState.Bounded env50098 := by
  intro p hp
  have h : env50098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50097_50098 : H12AffineEnvironment.transform 13 5376 env50097 = env50098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50097 == env50098) = true)

theorem identity50098 : scanCanonicalize (H12AffineFastState.compose env50098 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50098 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,78018,73771,153,138,8328,64,146509,5529,77834,138476,75102,73891,256,33,5593,648]

theorem envBound50099 : H12AffineFastState.Bounded env50099 := by
  intro p hp
  have h : env50099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50098_50099 : H12AffineEnvironment.transform 14 8540 env50098 = env50099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50098 == env50099) = true)

theorem identity50099 : scanCanonicalize (H12AffineFastState.compose env50099 (packedSelected [0,2,3,5,6,7,11,12,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 13438) := by decide +kernel

theorem selectedBound50099 : packedSelected [0,2,3,5,6,7,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env50100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,13438,131072,10281,1024,8541,1212,5205,153,138,8328,64,146509,5529,1140,138476,4384,5341,256,33,5593,648]

theorem envBound50100 : H12AffineFastState.Bounded env50100 := by
  intro p hp
  have h : env50100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50099_50100 : H12AffineEnvironment.transform 15 13438 env50099 = env50100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13438 env50099 == env50100) = true)

theorem identity50100 : scanCanonicalize (H12AffineFastState.compose env50100 (packedSelected [1,2,4,6,8,10,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 9308) := by decide +kernel

theorem selectedBound50100 : packedSelected [1,2,4,6,8,10,15,20,22] rootPS < 2^1333 := by decide +kernel

def env50101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,13438,9308,10281,1024,8541,1212,5205,153,138,8328,64,6161,5529,1140,14512,4384,5341,256,33,5593,648]

theorem envBound50101 : H12AffineFastState.Bounded env50101 := by
  intro p hp
  have h : env50101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50100_50101 : H12AffineEnvironment.transform 16 9308 env50100 = env50101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 9308 env50100 == env50101) = true)

theorem identity50101 : scanCanonicalize (H12AffineFastState.compose env50101 (packedSelected [0,1,2,4,6,8,9,10,15,16,18,23,27] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50101 : packedSelected [0,1,2,4,6,8,9,10,15,16,18,23,27] rootPS < 2^1333 := by decide +kernel

def env50102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,17,8192,1297,8540,9327,9308,10281,1024,8541,1212,1092,153,138,8328,64,2048,1416,1140,10401,305,1228,256,33,1480,648]

theorem envBound50102 : H12AffineFastState.Bounded env50102 := by
  intro p hp
  have h : env50102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50101_50102 : H12AffineEnvironment.transform 11 17 env50101 = env50102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50101 == env50102) = true)

theorem identity50102 : scanCanonicalize (H12AffineFastState.compose env50102 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound50102 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env50103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,217,17,8192,1297,8540,9327,9308,8432,1024,8541,1212,1092,153,138,8328,64,217,1416,1140,8312,305,1228,256,33,1480,648]

theorem envBound50103 : H12AffineFastState.Bounded env50103 := by
  intro p hp
  have h : env50103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50102_50103 : H12AffineEnvironment.transform 10 217 env50102 = env50103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env50102 == env50103) = true)

theorem identity50103 : scanCanonicalize (H12AffineFastState.compose env50103 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50103 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env50104 : List Nat := [2,4,8,16,32,64,128,256,512,273,217,17,8192,0,8540,8574,8525,8432,273,8541,429,341,153,138,8328,64,217,153,357,8312,305,477,256,33,217,648]

theorem envBound50104 : H12AffineFastState.Bounded env50104 := by
  intro p hp
  have h : env50104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50103_50104 : H12AffineEnvironment.transform 9 273 env50103 = env50104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50103 == env50104) = true)

theorem identity50104 : scanCanonicalize (H12AffineFastState.compose env50104 (packedSelected [1,3,5,6,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound50104 : packedSelected [1,3,5,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env50105 : List Nat := [2,4,8,16,32,64,128,256,512,273,217,17,9,0,341,375,324,249,273,340,429,341,153,138,129,64,217,153,357,113,305,477,256,33,217,648]

theorem envBound50105 : H12AffineFastState.Bounded env50105 := by
  intro p hp
  have h : env50105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50104_50105 : H12AffineEnvironment.transform 12 9 env50104 = env50105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env50104 == env50105) = true)

theorem identity50105 : scanCanonicalize (H12AffineFastState.compose env50105 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound50105 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env50106 : List Nat := [2,4,8,16,32,64,41,256,512,273,112,17,9,0,341,375,324,80,273,340,260,341,48,35,40,64,112,48,357,113,305,372,256,33,112,545]

theorem envBound50106 : H12AffineFastState.Bounded env50106 := by
  intro p hp
  have h : env50106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50105_50106 : H12AffineEnvironment.transform 6 41 env50105 = env50106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env50105 == env50106) = true)

theorem identity50106 : scanCanonicalize (H12AffineFastState.compose env50106 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound50106 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50107 : List Nat := [2,4,8,16,32,64,41,256,308,273,112,17,9,0,341,375,324,80,273,340,260,341,48,35,40,64,112,48,357,113,305,372,256,33,112,277]

theorem envBound50107 : H12AffineFastState.Bounded env50107 := by
  intro p hp
  have h : env50107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50106_50107 : H12AffineEnvironment.transform 8 308 env50106 = env50107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env50106 == env50107) = true)

theorem identity50107 : scanCanonicalize (H12AffineFastState.compose env50107 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50107 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50108 : List Nat := [2,4,8,16,32,48,41,256,308,273,0,17,9,0,293,263,308,32,273,292,260,293,48,35,40,48,0,48,277,1,305,260,256,33,0,277]

theorem envBound50108 : H12AffineFastState.Bounded env50108 := by
  intro p hp
  have h : env50108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50107_50108 : H12AffineEnvironment.transform 5 48 env50107 = env50108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50107 == env50108) = true)

theorem identity50108 : scanCanonicalize (H12AffineFastState.compose env50108 (packedSelected [1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50108 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env50109 : List Nat := [2,4,8,16,32,48,41,4,48,21,0,17,9,0,33,3,48,32,21,32,0,33,48,35,40,48,0,48,17,1,53,0,4,33,0,17]

theorem envBound50109 : H12AffineFastState.Bounded env50109 := by
  intro p hp
  have h : env50109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50108_50109 : H12AffineEnvironment.transform 7 4 env50108 = env50109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50108 == env50109) = true)

theorem identity50109 : scanCanonicalize (H12AffineFastState.compose env50109 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50109 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50110 : List Nat := [2,4,8,1,32,33,41,4,33,4,0,0,9,0,33,3,33,32,4,32,0,33,33,35,40,33,0,33,0,1,36,0,4,33,0,0]

theorem envBound50110 : H12AffineFastState.Bounded env50110 := by
  intro p hp
  have h : env50110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50109_50110 : H12AffineEnvironment.transform 3 1 env50109 = env50110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50109 == env50110) = true)

theorem identity50110 : scanCanonicalize (H12AffineFastState.compose env50110 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50110 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50111 : List Nat := [2,4,8,1,1,0,8,4,0,4,0,0,9,0,0,3,0,1,4,1,0,0,0,2,9,0,0,0,0,1,5,0,4,0,0,0]

theorem envBound50111 : H12AffineFastState.Bounded env50111 := by
  intro p hp
  have h : env50111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50110_50111 : H12AffineEnvironment.transform 4 1 env50110 = env50111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50110 == env50111) = true)

theorem identity50111 : scanCanonicalize (H12AffineFastState.compose env50111 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound50111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50112 : List Nat := [2,4,7,1,1,0,7,4,0,4,0,0,6,0,0,3,0,1,4,1,0,0,0,2,6,0,0,0,0,1,5,0,4,0,0,0]

theorem envBound50112 : H12AffineFastState.Bounded env50112 := by
  intro p hp
  have h : env50112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50111_50112 : H12AffineEnvironment.transform 2 7 env50111 = env50112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env50111 == env50112) = true)

def env50113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102815,98678,41412,41430,8328,64,146508,46276,77835,138476,99331,98814,256,32,46213,41941]

theorem envBound50113 : H12AffineFastState.Bounded env50113 := by
  intro p hp
  have h : env50113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50097_50113 : H12AffineEnvironment.transform 13 5377 env50097 = env50113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50097 == env50113) = true)

theorem identity50113 : scanCanonicalize (H12AffineFastState.compose env50113 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound50113 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10281,1024,8661,77899,73890,16,2,8328,64,146508,5392,77835,138476,75223,73770,256,32,5457,513]

theorem envBound50114 : H12AffineFastState.Bounded env50114 := by
  intro p hp
  have h : env50114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50113_50114 : H12AffineEnvironment.transform 14 8660 env50113 = env50114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env50113 == env50114) = true)

theorem identity50114 : scanCanonicalize (H12AffineFastState.compose env50114 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound50114 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79131,10281,1024,8661,77899,73890,16,2,8328,64,67927,5392,77835,76279,75223,73770,256,32,5457,513]

theorem envBound50115 : H12AffineFastState.Bounded env50115 := by
  intro p hp
  have h : env50115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50114_50115 : H12AffineEnvironment.transform 16 79131 env50114 = env50115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env50114 == env50115) = true)

theorem identity50115 : scanCanonicalize (H12AffineFastState.compose env50115 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound50115 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,9499,4096,10281,1024,8661,5456,1465,16,2,8328,64,11340,5392,5392,3308,204,1329,256,32,5457,513]

theorem envBound50116 : H12AffineFastState.Bounded env50116 := by
  intro p hp
  have h : env50116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50115_50116 : H12AffineEnvironment.transform 15 9499 env50115 = env50116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env50115 == env50116) = true)

theorem identity50116 : scanCanonicalize (H12AffineFastState.compose env50116 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50116 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5377,509,1330,4096,2048,1024,508,5456,1465,16,2,161,64,3173,5392,5392,3308,204,1329,256,32,5457,513]

theorem envBound50117 : H12AffineFastState.Bounded env50117 := by
  intro p hp
  have h : env50117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50116_50117 : H12AffineEnvironment.transform 12 41 env50116 = env50117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50116 == env50117) = true)

theorem identity50117 : scanCanonicalize (H12AffineFastState.compose env50117 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50117 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env50118 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,41,5157,217,1046,4096,2048,1024,216,5236,1181,16,2,161,64,3173,5172,5172,3308,204,1045,36,32,5237,513]

theorem envBound50118 : H12AffineFastState.Bounded env50118 := by
  intro p hp
  have h : env50118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50117_50118 : H12AffineEnvironment.transform 7 36 env50117 = env50118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50117 == env50118) = true)

theorem identity50118 : scanCanonicalize (H12AffineFastState.compose env50118 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound50118 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50119 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,544,41,1541,217,1046,544,2048,1024,216,1620,1181,16,2,161,64,3173,1556,1556,3308,204,1045,36,32,1621,513]

theorem envBound50119 : H12AffineFastState.Bounded env50119 := by
  intro p hp
  have h : env50119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50118_50119 : H12AffineEnvironment.transform 11 544 env50118 = env50119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env50118 == env50119) = true)

theorem identity50119 : scanCanonicalize (H12AffineFastState.compose env50119 (packedSelected [6,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound50119 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env50120 : List Nat := [2,4,8,16,32,64,40,36,512,1024,2048,544,41,1541,113,1046,544,2048,1024,112,1620,1077,16,2,9,64,3173,1556,1556,3140,100,1045,36,32,1621,513]

theorem envBound50120 : H12AffineFastState.Bounded env50120 := by
  intro p hp
  have h : env50120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50119_50120 : H12AffineEnvironment.transform 6 40 env50119 = env50120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env50119 == env50120) = true)

def env50121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62661,2188616,8328,64,158028,57797,2138516,406725,2102684,2373705,256,21793,46213,2175562]

theorem envBound50121 : H12AffineFastState.Bounded env50121 := by
  intro p hp
  have h : env50121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50067_50121 : H12AffineEnvironment.transform 21 2373825 env50067 = env50121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env50067 == env50121) = true)

theorem identity50121 : scanCanonicalize (H12AffineFastState.compose env50121 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound50121 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329866,62661,21763,8328,64,158028,57797,102879,406725,75223,329730,256,21793,46213,513]

theorem envBound50122 : H12AffineFastState.Bounded env50122 := by
  intro p hp
  have h : env50122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50121_50122 : H12AffineEnvironment.transform 20 77899 env50121 = env50122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env50121 == env50122) = true)

def env50123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329730,62541,21763,8192,64,158028,57677,102743,406605,75103,329730,256,21793,46093,513]

theorem envBound50123 : H12AffineFastState.Bounded env50123 := by
  intro p hp
  have h : env50123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50122_50123 : H12AffineEnvironment.transform 6 8 env50122 = env50123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50122 == env50123) = true)

theorem identity50123 : scanCanonicalize (H12AffineFastState.compose env50123 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound50123 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,77899,329730,62541,21763,8192,64,67926,57677,102743,349271,75103,329730,256,21793,46093,513]

theorem envBound50124 : H12AffineFastState.Bounded env50124 := by
  intro p hp
  have h : env50124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50123_50124 : H12AffineEnvironment.transform 16 90138 env50123 = env50124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env50123 == env50124) = true)

def env50125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,77899,73770,62541,21763,8192,64,67926,57677,102743,97407,75103,73770,256,21793,46093,513]

theorem envBound50125 : H12AffineFastState.Bounded env50125 := by
  intro p hp
  have h : env50125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50124_50125 : H12AffineEnvironment.transform 17 10280 env50124 = env50125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50124 == env50125) = true)

theorem identity50125 : scanCanonicalize (H12AffineFastState.compose env50125 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound50125 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10280,1024,29788,77899,73770,16,21763,8192,64,67926,5392,91402,97407,75103,73770,256,21793,16464,513]

theorem envBound50126 : H12AffineFastState.Bounded env50126 := by
  intro p hp
  have h : env50126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50125_50126 : H12AffineEnvironment.transform 14 29789 env50125 = env50126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env50125 == env50126) = true)

theorem identity50126 : scanCanonicalize (H12AffineFastState.compose env50126 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 31790) := by decide +kernel

theorem selectedBound50126 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,31790,7220,10280,1024,29788,19557,23556,16,21763,8192,64,30072,5392,6436,81,22897,23556,256,21793,16464,513]

theorem envBound50127 : H12AffineFastState.Bounded env50127 := by
  intro p hp
  have h : env50127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50126_50127 : H12AffineEnvironment.transform 15 31790 env50126 = env50127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31790 env50126 == env50127) = true)

theorem identity50127 : scanCanonicalize (H12AffineFastState.compose env50127 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,10543,7220,10280,1024,8541,6500,2309,16,2,8192,64,8313,5392,6436,81,3184,2309,256,32,5457,513]

theorem envBound50128 : H12AffineFastState.Bounded env50128 := by
  intro p hp
  have h : env50128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50127_50128 : H12AffineEnvironment.transform 13 5377 env50127 = env50128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50127 == env50128) = true)

theorem identity50128 : scanCanonicalize (H12AffineFastState.compose env50128 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound50128 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5377,1297,3426,7220,3173,1024,1296,6500,2309,16,2,1101,64,1076,5392,6436,81,3184,2309,256,32,5457,513]

theorem envBound50129 : H12AffineFastState.Bounded env50129 := by
  intro p hp
  have h : env50129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50128_50129 : H12AffineEnvironment.transform 12 1101 env50128 = env50129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env50128 == env50129) = true)

theorem identity50129 : scanCanonicalize (H12AffineFastState.compose env50129 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound50129 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env50130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,1101,5377,1297,34,4468,293,1024,1296,5156,1093,16,2,1101,64,1076,5392,5220,81,304,1093,256,32,5457,513]

theorem envBound50130 : H12AffineFastState.Bounded env50130 := by
  intro p hp
  have h : env50130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50129_50130 : H12AffineEnvironment.transform 10 1344 env50129 = env50130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env50129 == env50130) = true)

theorem identity50130 : scanCanonicalize (H12AffineFastState.compose env50130 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound50130 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env50131 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,4096,40,4452,372,34,4468,293,101,373,4161,32,16,2,40,64,81,4469,4097,81,304,32,256,32,4404,513]

theorem envBound50131 : H12AffineFastState.Bounded env50131 := by
  intro p hp
  have h : env50131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50130_50131 : H12AffineEnvironment.transform 9 101 env50130 = env50131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env50130 == env50131) = true)

theorem identity50131 : scanCanonicalize (H12AffineFastState.compose env50131 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50131 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50132 : List Nat := [2,4,8,16,32,16,8,256,512,53,293,4096,40,4404,292,34,4388,293,53,293,4113,32,16,2,40,16,1,4389,4097,1,304,32,256,32,4404,513]

theorem envBound50132 : H12AffineFastState.Bounded env50132 := by
  intro p hp
  have h : env50132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50131_50132 : H12AffineEnvironment.transform 5 16 env50131 = env50132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50131 == env50132) = true)

theorem identity50132 : scanCanonicalize (H12AffineFastState.compose env50132 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50132 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50133 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,4096,40,4113,1,34,4097,0,53,0,4113,32,16,2,40,16,1,4096,4097,1,21,32,37,32,4113,513]

theorem envBound50133 : H12AffineFastState.Bounded env50133 := by
  intro p hp
  have h : env50133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50132_50133 : H12AffineEnvironment.transform 7 37 env50132 = env50133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50132 == env50133) = true)

theorem identity50133 : scanCanonicalize (H12AffineFastState.compose env50133 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50134 : List Nat := [2,4,8,16,32,16,8,37,0,53,0,4096,40,4113,1,34,4097,0,53,0,4113,32,16,2,40,16,1,4096,4097,1,21,32,37,32,4113,1]

theorem envBound50134 : H12AffineFastState.Bounded env50134 := by
  intro p hp
  have h : env50134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50133_50134 : H12AffineEnvironment.transform 8 0 env50133 = env50134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50133 == env50134) = true)

theorem identity50134 : scanCanonicalize (H12AffineFastState.compose env50134 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50135 : List Nat := [2,4,8,16,11,16,8,14,0,30,0,4096,3,4113,1,9,4097,0,30,0,4113,11,16,2,3,16,1,4096,4097,1,21,11,14,11,4113,1]

theorem envBound50135 : H12AffineFastState.Bounded env50135 := by
  intro p hp
  have h : env50135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50134_50135 : H12AffineEnvironment.transform 4 11 env50134 = env50135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50134 == env50135) = true)

theorem identity50135 : scanCanonicalize (H12AffineFastState.compose env50135 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50135 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50136 : List Nat := [2,4,8,16,11,16,8,14,0,30,0,17,3,0,1,9,16,0,30,0,0,11,16,2,3,16,1,17,16,1,21,11,14,11,0,1]

theorem envBound50136 : H12AffineFastState.Bounded env50136 := by
  intro p hp
  have h : env50136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50135_50136 : H12AffineEnvironment.transform 11 17 env50135 = env50136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50135 == env50136) = true)

def env50137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,77899,73771,62541,21763,8192,64,67926,57677,102743,97406,75103,73771,256,21793,46093,513]

theorem envBound50137 : H12AffineFastState.Bounded env50137 := by
  intro p hp
  have h : env50137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50124_50137 : H12AffineEnvironment.transform 17 10281 env50124 = env50137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50124 == env50137) = true)

theorem identity50137 : scanCanonicalize (H12AffineFastState.compose env50137 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound50137 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,16465,20529,62541,21763,8192,64,31052,57677,57677,3172,21829,20529,256,21793,46093,513]

theorem envBound50138 : H12AffineFastState.Bounded env50138 := by
  intro p hp
  have h : env50138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50137_50138 : H12AffineEnvironment.transform 15 28698 env50137 = env50138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env50137 == env50138) = true)

theorem identity50138 : scanCanonicalize (H12AffineFastState.compose env50138 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50138 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,4096,10281,1024,8541,16465,20529,21777,21763,8192,64,31052,16401,16401,3172,21829,20529,256,21793,5457,513]

theorem envBound50139 : H12AffineFastState.Bounded env50139 := by
  intro p hp
  have h : env50139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50138_50139 : H12AffineEnvironment.transform 14 8540 env50138 = env50139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50138 == env50139) = true)

theorem identity50139 : scanCanonicalize (H12AffineFastState.compose env50139 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound50139 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env50140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,1345,21511,4096,3124,1024,1344,16465,20529,21777,21763,1053,64,23889,16401,16401,3172,21829,20529,256,21793,5457,513]

theorem envBound50140 : H12AffineFastState.Bounded env50140 := by
  intro p hp
  have h : env50140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50139_50140 : H12AffineEnvironment.transform 12 1053 env50139 = env50140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env50139 == env50140) = true)

theorem identity50140 : scanCanonicalize (H12AffineFastState.compose env50140 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound50140 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env50141 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,120,16384,292,20578,4096,2129,101,293,16465,20529,20852,20838,120,64,22836,16401,16401,2049,20768,20529,256,20804,4404,513]

theorem envBound50141 : H12AffineFastState.Bounded env50141 := by
  intro p hp
  have h : env50141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50140_50141 : H12AffineEnvironment.transform 9 101 env50140 = env50141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env50140 == env50141) = true)

theorem identity50141 : scanCanonicalize (H12AffineFastState.compose env50141 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound50141 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0