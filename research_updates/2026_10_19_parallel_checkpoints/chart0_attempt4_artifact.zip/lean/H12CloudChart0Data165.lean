import H12CloudChart0Data164

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env41820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10280,1024,8540,4161,8493,16,3,8192,65,10509,5392,4097,10280,1365,8493,256,33,5457,513]

theorem envBound41820 : H12AffineFastState.Bounded env41820 := by
  intro p hp
  have h : env41820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41819_41820 : H12AffineEnvironment.transform 21 8493 env41819 = env41820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env41819 == env41820) = true)

theorem identity41820 : scanCanonicalize (H12AffineFastState.compose env41820 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41820 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5441,2340,1024,80,4161,33,16,3,268,65,2049,5392,4097,2340,1365,33,256,33,5457,513]

theorem envBound41821 : H12AffineFastState.Bounded env41821 := by
  intro p hp
  have h : env41821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41820_41821 : H12AffineEnvironment.transform 12 268 env41820 = env41821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41820 == env41821) = true)

theorem identity41821 : scanCanonicalize (H12AffineFastState.compose env41821 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound41821 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,268,5376,81,263,5441,1124,1024,80,4161,33,16,3,268,65,1345,5392,4097,1124,1365,33,256,33,5457,513]

theorem envBound41822 : H12AffineFastState.Bounded env41822 := by
  intro p hp
  have h : env41822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41821_41822 : H12AffineEnvironment.transform 10 1344 env41821 = env41822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env41821 == env41822) = true)

theorem identity41822 : scanCanonicalize (H12AffineFastState.compose env41822 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41822 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41823 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,4096,120,5236,81,115,5173,1124,1024,80,4161,33,16,3,120,65,1077,5220,4097,1124,1057,33,116,33,5157,513]

theorem envBound41823 : H12AffineFastState.Bounded env41823 := by
  intro p hp
  have h : env41823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41822_41823 : H12AffineEnvironment.transform 7 116 env41822 = env41823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41822 == env41823) = true)

theorem identity41823 : scanCanonicalize (H12AffineFastState.compose env41823 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound41823 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env41824 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,1061,120,81,81,115,16,1124,1024,80,1124,33,16,3,120,65,1077,65,1060,1124,1057,33,116,33,0,513]

theorem envBound41824 : H12AffineFastState.Bounded env41824 := by
  intro p hp
  have h : env41824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41823_41824 : H12AffineEnvironment.transform 11 1061 env41823 = env41824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env41823 == env41824) = true)

theorem identity41824 : scanCanonicalize (H12AffineFastState.compose env41824 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41824 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env41825 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,1061,41,0,0,34,16,1077,1024,1,1077,33,16,3,41,16,1077,16,1060,1077,1057,33,37,33,0,513]

theorem envBound41825 : H12AffineFastState.Bounded env41825 := by
  intro p hp
  have h : env41825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41824_41825 : H12AffineEnvironment.transform 5 17 env41824 = env41825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41824 == env41825) = true)

def env41826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212079,1024,8661,4161,4194304,16,73737,8328,65,4270243,5392,4096,67754,1501,4194440,256,32,5456,74250]

theorem envBound41826 : H12AffineFastState.Bounded env41826 := by
  intro p hp
  have h : env41826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41815_41826 : H12AffineEnvironment.transform 13 5377 env41815 = env41826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41815 == env41826) = true)

theorem identity41826 : scanCanonicalize (H12AffineFastState.compose env41826 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound41826 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70863,10400,1024,8661,4161,4194304,16,73737,8328,65,4270243,5392,4096,67754,1501,4194440,256,32,5456,74250]

theorem envBound41827 : H12AffineFastState.Bounded env41827 := by
  intro p hp
  have h : env41827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41826_41827 : H12AffineEnvironment.transform 16 70863 env41826 = env41827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env41826 == env41827) = true)

theorem identity41827 : scanCanonicalize (H12AffineFastState.compose env41827 (packedSelected [0,1,2,5,6,10,12,14,15,16,18,20,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound41827 : packedSelected [0,1,2,5,6,10,12,14,15,16,18,20,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env41828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70863,10400,1024,8661,4161,8612,16,73737,8328,65,67847,5392,4096,67754,1501,8492,256,32,5456,74250]

theorem envBound41828 : H12AffineFastState.Bounded env41828 := by
  intro p hp
  have h : env41828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41827_41828 : H12AffineEnvironment.transform 21 8612 env41827 = env41828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env41827 == env41828) = true)

theorem identity41828 : scanCanonicalize (H12AffineFastState.compose env41828 (packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound41828 : packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS < 2^1333 := by decide +kernel

def env41829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,65536,70863,2421,1024,0,4161,113,16,66012,349,65,67847,5392,4096,67754,1501,249,256,32,5456,66527]

theorem envBound41829 : H12AffineFastState.Bounded env41829 := by
  intro p hp
  have h : env41829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41828_41829 : H12AffineEnvironment.transform 12 469 env41828 = env41829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env41828 == env41829) = true)

theorem identity41829 : scanCanonicalize (H12AffineFastState.compose env41829 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound41829 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env41830 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5377,1,65536,70678,2421,1024,0,4161,113,16,65797,349,65,67847,5392,4096,67699,1284,32,256,32,5456,66310]

theorem envBound41830 : H12AffineFastState.Bounded env41830 := by
  intro p hp
  have h : env41830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41829_41830 : H12AffineEnvironment.transform 6 89 env41829 = env41830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env41829 == env41830) = true)

theorem identity41830 : scanCanonicalize (H12AffineFastState.compose env41830 (packedSelected [0,3,4,5,7,9,10,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 2163) := by decide +kernel

theorem selectedBound41830 : packedSelected [0,3,4,5,7,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env41831 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5377,1,2163,7269,2421,1024,0,4161,113,16,2422,349,65,372,5392,4096,0,1284,32,256,32,5456,2933]

theorem envBound41831 : H12AffineFastState.Bounded env41831 := by
  intro p hp
  have h : env41831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41830_41831 : H12AffineEnvironment.transform 15 2163 env41830 = env41831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2163 env41830 == env41831) = true)

theorem identity41831 : scanCanonicalize (H12AffineFastState.compose env41831 (packedSelected [1,2,3,4,5,6,8,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound41831 : packedSelected [1,2,3,4,5,6,8,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41832 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3109,268,2340,1,2163,64,2421,1024,0,3172,113,16,2422,349,65,372,2357,3109,0,1284,32,256,32,2421,2933]

theorem envBound41832 : H12AffineFastState.Bounded env41832 := by
  intro p hp
  have h : env41832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41831_41832 : H12AffineEnvironment.transform 11 3109 env41831 = env41832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env41831 == env41832) = true)

theorem identity41832 : scanCanonicalize (H12AffineFastState.compose env41832 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41832 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env41833 : List Nat := [2,4,8,16,32,64,89,256,512,53,2048,2064,268,2340,1,2163,64,2421,53,0,2129,113,16,2422,349,65,372,2357,2064,0,305,32,256,32,2421,2933]

theorem envBound41833 : H12AffineFastState.Bounded env41833 := by
  intro p hp
  have h : env41833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41832_41833 : H12AffineEnvironment.transform 9 53 env41832 = env41833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41832 == env41833) = true)

theorem identity41833 : scanCanonicalize (H12AffineFastState.compose env41833 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound41833 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41834 : List Nat := [2,4,8,16,32,64,89,256,512,53,372,356,268,80,1,263,64,1,53,0,293,113,16,2,349,65,372,65,356,0,305,32,256,32,1,513]

theorem envBound41834 : H12AffineFastState.Bounded env41834 := by
  intro p hp
  have h : env41834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41833_41834 : H12AffineEnvironment.transform 10 372 env41833 = env41834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env41833 == env41834) = true)

theorem identity41834 : scanCanonicalize (H12AffineFastState.compose env41834 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound41834 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41835 : List Nat := [2,4,8,16,32,64,89,256,10,53,372,356,268,80,1,263,64,1,53,0,293,113,16,2,349,65,372,65,356,0,305,32,256,32,1,11]

theorem envBound41835 : H12AffineFastState.Bounded env41835 := by
  intro p hp
  have h : env41835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41834_41835 : H12AffineEnvironment.transform 8 10 env41834 = env41835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env41834 == env41835) = true)

theorem identity41835 : scanCanonicalize (H12AffineFastState.compose env41835 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41835 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env41836 : List Nat := [2,4,8,16,32,17,8,256,10,53,293,309,268,1,1,263,17,1,53,0,293,32,16,2,268,16,293,16,309,0,305,32,256,32,1,11]

theorem envBound41836 : H12AffineFastState.Bounded env41836 := by
  intro p hp
  have h : env41836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41835_41836 : H12AffineEnvironment.transform 5 17 env41835 = env41836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41835 == env41836) = true)

theorem identity41836 : scanCanonicalize (H12AffineFastState.compose env41836 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41837 : List Nat := [2,4,8,16,32,17,8,4,10,53,33,49,8,1,1,3,17,1,53,0,33,32,16,2,8,16,33,16,49,0,53,32,4,32,1,11]

theorem envBound41837 : H12AffineFastState.Bounded env41837 := by
  intro p hp
  have h : env41837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41836_41837 : H12AffineEnvironment.transform 7 4 env41836 = env41837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41836 == env41837) = true)

theorem identity41837 : scanCanonicalize (H12AffineFastState.compose env41837 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41837 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41838 : List Nat := [2,4,8,16,10,17,8,4,10,31,11,27,8,1,1,3,17,1,31,0,11,10,16,2,8,16,11,16,27,0,31,10,4,10,1,11]

theorem envBound41838 : H12AffineFastState.Bounded env41838 := by
  intro p hp
  have h : env41838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41837_41838 : H12AffineEnvironment.transform 4 10 env41837 = env41838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41837 == env41838) = true)

theorem identity41838 : scanCanonicalize (H12AffineFastState.compose env41838 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound41838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41839 : List Nat := [2,4,6,16,4,17,6,4,4,17,5,21,6,1,1,3,17,1,17,0,5,4,16,2,6,16,5,16,21,0,17,4,4,4,1,5]

theorem envBound41839 : H12AffineFastState.Bounded env41839 := by
  intro p hp
  have h : env41839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41838_41839 : H12AffineEnvironment.transform 2 6 env41838 = env41839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env41838 == env41839) = true)

theorem identity41839 : scanCanonicalize (H12AffineFastState.compose env41839 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41839 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41840 : List Nat := [2,4,6,0,4,1,6,4,4,1,5,5,6,1,1,3,1,1,1,0,5,4,0,2,6,0,5,0,5,0,1,4,4,4,1,5]

theorem envBound41840 : H12AffineFastState.Bounded env41840 := by
  intro p hp
  have h : env41840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41839_41840 : H12AffineEnvironment.transform 3 0 env41839 = env41840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41839 == env41840) = true)

theorem identity41840 : scanCanonicalize (H12AffineFastState.compose env41840 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41840 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41841 : List Nat := [2,2,0,0,2,1,0,2,2,1,3,3,0,1,1,3,1,1,1,0,3,2,0,2,0,0,3,0,3,0,1,2,2,2,1,3]

theorem envBound41841 : H12AffineFastState.Bounded env41841 := by
  intro p hp
  have h : env41841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41840_41841 : H12AffineEnvironment.transform 1 2 env41840 = env41841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41840 == env41841) = true)

def env41842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760179,5393,10507600,8497518,10491277,4256860,256,8410416,8434837,10564186]

theorem envBound41842 : H12AffineFastState.Bounded env41842 := by
  intro p hp
  have h : env41842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41744_41842 : H12AffineEnvironment.transform 23 2199965 env41744 = env41842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env41744 == env41842) = true)

def env41843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270243,5393,17664,2210110,1501,4256860,256,2114912,2139333,74250]

theorem envBound41843 : H12AffineFastState.Bounded env41843 := by
  intro p hp
  have h : env41843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41842_41843 : H12AffineEnvironment.transform 22 2101328 env41842 = env41843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env41842 == env41843) = true)

def env41844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98781,8328,65,4270243,5393,17664,108926,1501,4256860,256,21792,46213,74250]

theorem envBound41844 : H12AffineFastState.Bounded env41844 := by
  intro p hp
  have h : env41844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41843_41844 : H12AffineEnvironment.transform 20 4160 env41843 = env41844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41843 == env41844) = true)

theorem identity41844 : scanCanonicalize (H12AffineFastState.compose env41844 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound41844 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179633,1024,32769,4160,4194304,16,21762,8328,65,4258940,5393,17664,32161,1501,4256860,256,21792,46213,63189]

theorem envBound41845 : H12AffineFastState.Bounded env41845 := by
  intro p hp
  have h : env41845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41844_41845 : H12AffineEnvironment.transform 15 54495 env41844 = env41845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env41844 == env41845) = true)

def env41846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4160,4194304,16,21762,8192,65,4258940,5393,17664,32041,1365,4256860,256,21792,46093,63069]

theorem envBound41846 : H12AffineFastState.Bounded env41846 := by
  intro p hp
  have h : env41846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41845_41846 : H12AffineEnvironment.transform 6 8 env41845 = env41846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41845 == env41846) = true)

theorem identity41846 : scanCanonicalize (H12AffineFastState.compose env41846 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound41846 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10280,1024,32769,4160,4194304,16,21762,8192,65,4258940,5393,17664,32041,1365,4256860,256,21792,46093,63069]

theorem envBound41847 : H12AffineFastState.Bounded env41847 := by
  intro p hp
  have h : env41847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41846_41847 : H12AffineEnvironment.transform 16 38161 env41846 = env41847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env41846 == env41847) = true)

theorem identity41847 : scanCanonicalize (H12AffineFastState.compose env41847 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound41847 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env41848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10280,1024,32769,4160,41261,16,21762,8192,65,23889,5393,17664,32041,1365,21873,256,21792,46093,63069]

theorem envBound41848 : H12AffineFastState.Bounded env41848 := by
  intro p hp
  have h : env41848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41847_41848 : H12AffineEnvironment.transform 21 41261 env41847 = env41848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env41847 == env41848) = true)

theorem identity41848 : scanCanonicalize (H12AffineFastState.compose env41848 (packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41848 : packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env41849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38161,10280,1024,32769,4160,41261,16,3,8192,65,2128,5393,4097,10280,1365,112,256,33,46093,41820]

theorem envBound41849 : H12AffineFastState.Bounded env41849 := by
  intro p hp
  have h : env41849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41848_41849 : H12AffineEnvironment.transform 13 5377 env41848 = env41849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41848 == env41849) = true)

theorem identity41849 : scanCanonicalize (H12AffineFastState.compose env41849 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41849 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,343,5392,10280,1024,0,4160,8492,16,3,8192,65,2128,5393,4097,10280,1365,112,256,33,13324,9053]

theorem envBound41850 : H12AffineFastState.Bounded env41850 := by
  intro p hp
  have h : env41850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41849_41850 : H12AffineEnvironment.transform 14 1 env41849 = env41850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41849 == env41850) = true)

theorem identity41850 : scanCanonicalize (H12AffineFastState.compose env41850 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41850 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5392,2420,1024,0,4160,112,16,3,348,65,2128,5393,4097,2420,1365,112,256,33,5456,513]

theorem envBound41851 : H12AffineFastState.Bounded env41851 := by
  intro p hp
  have h : env41851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41850_41851 : H12AffineEnvironment.transform 12 348 env41850 = env41851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41850 == env41851) = true)

def env41852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4160,4194304,16,21762,8193,65,4258940,5393,17664,32040,1364,4256860,256,21792,46092,63068]

theorem envBound41852 : H12AffineFastState.Bounded env41852 := by
  intro p hp
  have h : env41852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41845_41852 : H12AffineEnvironment.transform 6 9 env41845 = env41852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41845 == env41852) = true)

theorem identity41852 : scanCanonicalize (H12AffineFastState.compose env41852 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound41852 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,35188,1024,32769,4160,4194304,16,21762,8193,65,4258940,5393,17664,32040,1364,4256860,256,21792,46092,63068]

theorem envBound41853 : H12AffineFastState.Bounded env41853 := by
  intro p hp
  have h : env41853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41852_41853 : H12AffineEnvironment.transform 16 13388 env41852 = env41853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env41852 == env41853) = true)

theorem identity41853 : scanCanonicalize (H12AffineFastState.compose env41853 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41853 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env41854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,13388,35188,1024,32769,4160,4194304,16,2,8193,65,4237692,5393,4096,10280,1364,4235612,256,32,46092,41820]

theorem envBound41854 : H12AffineFastState.Bounded env41854 := by
  intro p hp
  have h : env41854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41853_41854 : H12AffineEnvironment.transform 13 5376 env41853 = env41854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41853 == env41854) = true)

theorem identity41854 : scanCanonicalize (H12AffineFastState.compose env41854 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41854 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env41855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,32768,33110,5220,35188,1024,32769,4160,4194304,16,2,41,65,4229460,5393,4096,2048,1364,4227444,256,32,37924,33652]

theorem envBound41855 : H12AffineFastState.Bounded env41855 := by
  intro p hp
  have h : env41855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41854_41855 : H12AffineEnvironment.transform 12 40 env41854 = env41855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41854 == env41855) = true)

theorem identity41855 : scanCanonicalize (H12AffineFastState.compose env41855 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound41855 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env41856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,32768,33110,5220,35188,1024,32769,4160,32801,16,2,41,65,2421,5393,4096,2048,1364,341,256,32,37924,33652]

theorem envBound41856 : H12AffineFastState.Bounded env41856 := by
  intro p hp
  have h : env41856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41855_41856 : H12AffineEnvironment.transform 21 32801 env41855 = env41856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env41855 == env41856) = true)

theorem identity41856 : scanCanonicalize (H12AffineFastState.compose env41856 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41856 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env41857 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5236,32768,32802,5220,34816,1024,32769,4160,32801,16,2,41,65,2049,5221,4096,2048,1056,33,116,32,37924,33280]

theorem envBound41857 : H12AffineFastState.Bounded env41857 := by
  intro p hp
  have h : env41857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41856_41857 : H12AffineEnvironment.transform 7 116 env41856 = env41857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41856 == env41857) = true)

theorem identity41857 : scanCanonicalize (H12AffineFastState.compose env41857 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound41857 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41858 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5236,33,3,5220,2081,1024,32,4160,0,16,2,41,65,2049,5221,4096,2048,1056,33,116,32,5125,545]

theorem envBound41858 : H12AffineFastState.Bounded env41858 := by
  intro p hp
  have h : env41858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41857_41858 : H12AffineEnvironment.transform 14 33 env41857 = env41858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env41857 == env41858) = true)

theorem identity41858 : scanCanonicalize (H12AffineFastState.compose env41858 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound41858 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41859 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2144,40,3092,33,3,3076,2081,1024,32,2080,0,16,2,41,65,2049,3077,2144,2048,1056,33,116,32,3173,545]

theorem envBound41859 : H12AffineFastState.Bounded env41859 := by
  intro p hp
  have h : env41859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41858_41859 : H12AffineEnvironment.transform 11 2144 env41858 = env41859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env41858 == env41859) = true)

theorem identity41859 : scanCanonicalize (H12AffineFastState.compose env41859 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 94) := by decide +kernel

theorem selectedBound41859 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env41860 : List Nat := [2,4,8,16,32,64,9,116,512,94,2048,2144,40,2122,33,3,2138,2081,94,32,2080,0,16,2,41,65,2049,2139,2144,2048,126,33,116,32,2107,545]

theorem envBound41860 : H12AffineFastState.Bounded env41860 := by
  intro p hp
  have h : env41860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41859_41860 : H12AffineEnvironment.transform 9 94 env41859 = env41860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 94 env41859 == env41860) = true)

theorem identity41860 : scanCanonicalize (H12AffineFastState.compose env41860 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41860 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41861 : List Nat := [2,4,8,16,32,17,9,37,512,15,2048,2097,40,2075,33,3,2059,2081,15,32,2080,0,16,2,41,16,2049,2058,2097,2048,47,33,37,32,2107,545]

theorem envBound41861 : H12AffineFastState.Bounded env41861 := by
  intro p hp
  have h : env41861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41860_41861 : H12AffineEnvironment.transform 5 17 env41860 = env41861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41860 == env41861) = true)

theorem identity41861 : scanCanonicalize (H12AffineFastState.compose env41861 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound41861 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41862 : List Nat := [2,4,8,16,32,17,9,37,512,15,49,0,40,42,33,3,58,16,15,32,17,0,16,2,41,16,48,59,0,49,47,33,37,32,10,545]

theorem envBound41862 : H12AffineFastState.Bounded env41862 := by
  intro p hp
  have h : env41862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41861_41862 : H12AffineEnvironment.transform 10 49 env41861 = env41862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env41861 == env41862) = true)

def env41863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,17,98780,8328,65,4270243,5393,17664,108927,1501,4256860,256,21793,46212,74250]

theorem envBound41863 : H12AffineFastState.Bounded env41863 := by
  intro p hp
  have h : env41863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41843_41863 : H12AffineEnvironment.transform 20 4161 env41843 = env41863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41843 == env41863) = true)

theorem identity41863 : scanCanonicalize (H12AffineFastState.compose env41863 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213487) := by decide +kernel

theorem selectedBound41863 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,213487,17,98780,8328,65,158028,5393,17664,108927,1501,243123,256,21793,46212,74250]

theorem envBound41864 : H12AffineFastState.Bounded env41864 := by
  intro p hp
  have h : env41864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41863_41864 : H12AffineEnvironment.transform 21 213487 env41863 = env41864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213487 env41863 == env41864) = true)

theorem identity41864 : scanCanonicalize (H12AffineFastState.compose env41864 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41864 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env41865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4161,156132,17,41431,8328,65,158028,5393,17664,35188,1501,169400,256,21793,46212,513]

theorem envBound41865 : H12AffineFastState.Bounded env41865 := by
  intro p hp
  have h : env41865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41864_41865 : H12AffineEnvironment.transform 15 8203 env41864 = env41865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41864 == env41865) = true)

theorem identity41865 : scanCanonicalize (H12AffineFastState.compose env41865 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound41865 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,2420,1024,32769,4161,8693,17,41431,8328,65,10589,5393,17664,35188,1501,54697,256,21793,46212,513]

theorem envBound41866 : H12AffineFastState.Bounded env41866 := by
  intro p hp
  have h : env41866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41865_41866 : H12AffineEnvironment.transform 16 16401 env41865 = env41866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41865 == env41866) = true)

theorem identity41866 : scanCanonicalize (H12AffineFastState.compose env41866 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound41866 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env41867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16401,2420,1024,29709,4161,8693,17,21979,8328,65,10589,5393,17664,32120,1501,8613,256,21793,16520,513]

theorem envBound41867 : H12AffineFastState.Bounded env41867 := by
  intro p hp
  have h : env41867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41866_41867 : H12AffineEnvironment.transform 14 29708 env41866 = env41867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env41866 == env41867) = true)

theorem identity41867 : scanCanonicalize (H12AffineFastState.compose env41867 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41867 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env41868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21841,342,16401,2420,1024,21840,4161,168,17,21979,469,65,2048,5393,17664,23589,1501,248,256,21793,16520,513]

theorem envBound41868 : H12AffineFastState.Bounded env41868 := by
  intro p hp
  have h : env41868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41867_41868 : H12AffineEnvironment.transform 12 349 env41867 = env41868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41867 == env41868) = true)

theorem identity41868 : scanCanonicalize (H12AffineFastState.compose env41868 (packedSelected [1,2,5,7,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound41868 : packedSelected [1,2,5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,2184,7641,342,2201,2420,1024,7640,4161,168,17,7507,469,65,2048,5393,3464,5293,1501,248,256,7593,2048,513]

theorem envBound41869 : H12AffineFastState.Bounded env41869 := by
  intro p hp
  have h : env41869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41868_41869 : H12AffineEnvironment.transform 13 2184 env41868 = env41869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env41868 == env41869) = true)

theorem identity41869 : scanCanonicalize (H12AffineFastState.compose env41869 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41869 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env41870 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,120,2184,7420,115,2201,2129,1024,7421,4161,168,17,7286,240,65,2048,5172,3245,5293,1272,248,37,7308,2048,513]

theorem envBound41870 : H12AffineFastState.Bounded env41870 := by
  intro p hp
  have h : env41870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41869_41870 : H12AffineEnvironment.transform 7 37 env41869 = env41870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41869 == env41870) = true)

theorem identity41870 : scanCanonicalize (H12AffineFastState.compose env41870 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound41870 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env41871 : List Nat := [2,4,8,16,32,64,128,37,512,189,2048,4096,120,2184,6209,115,2201,2129,189,6208,4161,168,17,6347,240,65,2048,4233,2064,4112,69,248,37,6193,2048,513]

theorem envBound41871 : H12AffineFastState.Bounded env41871 := by
  intro p hp
  have h : env41871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41870_41871 : H12AffineEnvironment.transform 9 189 env41870 = env41871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env41870 == env41871) = true)

theorem identity41871 : scanCanonicalize (H12AffineFastState.compose env41871 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound41871 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41872 : List Nat := [2,4,8,16,32,64,128,37,512,189,2048,2113,120,2184,0,115,2201,2129,189,1,2048,168,17,138,240,65,2048,2248,2064,2129,69,248,37,112,2048,513]

theorem envBound41872 : H12AffineFastState.Bounded env41872 := by
  intro p hp
  have h : env41872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41871_41872 : H12AffineEnvironment.transform 11 2113 env41871 = env41872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env41871 == env41872) = true)

def env41873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270242,5393,17665,2210111,1500,4256860,256,2114913,2139332,74251]

theorem envBound41873 : H12AffineFastState.Bounded env41873 := by
  intro p hp
  have h : env41873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41842_41873 : H12AffineEnvironment.transform 22 2101329 env41842 = env41873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env41842 == env41873) = true)

def env41874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,17,98781,8328,65,4270242,5393,17665,108927,1500,4256860,256,21793,46212,74251]

theorem envBound41874 : H12AffineFastState.Bounded env41874 := by
  intro p hp
  have h : env41874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41873_41874 : H12AffineEnvironment.transform 20 4160 env41873 = env41874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41873 == env41874) = true)

theorem identity41874 : scanCanonicalize (H12AffineFastState.compose env41874 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243002) := by decide +kernel

theorem selectedBound41874 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243002,17,98781,8328,65,171416,5393,17665,108927,1500,213350,256,21793,46212,74251]

theorem envBound41875 : H12AffineFastState.Bounded env41875 := by
  intro p hp
  have h : env41875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41874_41875 : H12AffineEnvironment.transform 21 243002 env41874 = env41875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243002 env41874 == env41875) = true)

def env41876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243002,17,98645,8192,65,171280,5393,17665,108927,1364,213350,256,21793,46092,74251]

theorem envBound41876 : H12AffineFastState.Bounded env41876 := by
  intro p hp
  have h : env41876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41875_41876 : H12AffineEnvironment.transform 6 8 env41875 = env41876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41875 == env41876) = true)

theorem identity41876 : scanCanonicalize (H12AffineFastState.compose env41876 (packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41876 : packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env41877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,131072,223598,1024,21761,4160,221242,17,87125,8192,65,149520,5393,17665,97407,1364,213350,256,21793,24844,74251]

theorem envBound41877 : H12AffineFastState.Bounded env41877 := by
  intro p hp
  have h : env41877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41876_41877 : H12AffineEnvironment.transform 14 21760 env41876 = env41877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41876 == env41877) = true)

theorem identity41877 : scanCanonicalize (H12AffineFastState.compose env41877 (packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound41877 : packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,79130,23668,1024,21761,4160,21792,17,87125,8192,65,97546,5393,17665,97407,1364,29820,256,21793,24844,74251]

theorem envBound41878 : H12AffineFastState.Bounded env41878 := by
  intro p hp
  have h : env41878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41877_41878 : H12AffineEnvironment.transform 16 79130 env41877 = env41878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env41877 == env41878) = true)

theorem identity41878 : scanCanonicalize (H12AffineFastState.compose env41878 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41878 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env41879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,70726,23668,1024,21761,4160,21792,17,87125,348,65,89174,5393,17665,89379,1364,21792,256,21793,16464,66391]

theorem envBound41879 : H12AffineFastState.Bounded env41879 := by
  intro p hp
  have h : env41879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41878_41879 : H12AffineEnvironment.transform 12 348 env41878 = env41879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41878 == env41879) = true)

theorem identity41879 : scanCanonicalize (H12AffineFastState.compose env41879 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound41879 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env41880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,262,5440,23668,1024,21761,4160,21792,17,21843,348,65,23888,5393,17665,23589,1364,21792,256,21793,16464,593]

theorem envBound41880 : H12AffineFastState.Bounded env41880 := by
  intro p hp
  have h : env41880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41879_41880 : H12AffineEnvironment.transform 15 262 env41879 = env41880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env41879 == env41880) = true)

theorem identity41880 : scanCanonicalize (H12AffineFastState.compose env41880 (packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound41880 : packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env41881 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,348,16384,20544,262,4096,22836,320,20545,4160,20576,17,20499,348,65,22544,4177,16449,22885,20,20576,256,20577,16464,593]

theorem envBound41881 : H12AffineFastState.Bounded env41881 := by
  intro p hp
  have h : env41881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41880_41881 : H12AffineEnvironment.transform 9 320 env41880 = env41881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41880 == env41881) = true)

theorem identity41881 : scanCanonicalize (H12AffineFastState.compose env41881 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound41881 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41882 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,348,4113,81,262,4096,2341,320,80,4160,113,17,2,348,65,2049,4177,4176,2420,20,113,256,112,4161,593]

theorem envBound41882 : H12AffineFastState.Bounded env41882 := by
  intro p hp
  have h : env41882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41881_41882 : H12AffineEnvironment.transform 13 4113 env41881 = env41882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env41881 == env41882) = true)

theorem identity41882 : scanCanonicalize (H12AffineFastState.compose env41882 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 798) := by decide +kernel

theorem selectedBound41882 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41883 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,798,348,783,81,262,798,2341,320,80,862,113,17,2,348,65,2049,847,846,2420,20,113,256,112,863,593]

theorem envBound41883 : H12AffineFastState.Bounded env41883 := by
  intro p hp
  have h : env41883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41882_41883 : H12AffineEnvironment.transform 11 798 env41882 = env41883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 798 env41882 == env41883) = true)

theorem identity41883 : scanCanonicalize (H12AffineFastState.compose env41883 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound41883 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env41884 : List Nat := [2,4,8,16,32,64,8,256,512,320,814,798,348,783,81,262,798,523,320,80,862,113,17,2,348,65,815,847,846,602,20,113,256,112,863,593]

theorem envBound41884 : H12AffineFastState.Bounded env41884 := by
  intro p hp
  have h : env41884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41883_41884 : H12AffineEnvironment.transform 10 814 env41883 = env41884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env41883 == env41884) = true)

theorem identity41884 : scanCanonicalize (H12AffineFastState.compose env41884 (packedSelected [0,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound41884 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env41885 : List Nat := [2,4,8,16,32,64,8,256,271,320,33,17,348,0,81,262,17,260,320,80,81,113,17,2,348,65,32,64,65,341,20,113,256,112,80,350]

theorem envBound41885 : H12AffineFastState.Bounded env41885 := by
  intro p hp
  have h : env41885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41884_41885 : H12AffineEnvironment.transform 8 271 env41884 = env41885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env41884 == env41885) = true)

theorem identity41885 : scanCanonicalize (H12AffineFastState.compose env41885 (packedSelected [0,1,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound41885 : packedSelected [0,1,5,6,9] rootPS < 2^1333 := by decide +kernel

def env41886 : List Nat := [2,4,8,16,32,64,8,85,90,21,33,17,9,0,81,83,17,81,21,80,81,113,17,2,9,65,32,64,65,0,20,113,85,112,80,11]

theorem envBound41886 : H12AffineFastState.Bounded env41886 := by
  intro p hp
  have h : env41886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41885_41886 : H12AffineEnvironment.transform 7 85 env41885 = env41886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env41885 == env41886) = true)

theorem identity41886 : scanCanonicalize (H12AffineFastState.compose env41886 (packedSelected [3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound41886 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env41887 : List Nat := [2,4,8,16,32,49,8,36,43,21,33,17,9,0,32,34,17,32,21,33,32,0,17,2,9,48,32,49,48,0,20,0,36,1,33,11]

theorem envBound41887 : H12AffineFastState.Bounded env41887 := by
  intro p hp
  have h : env41887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41886_41887 : H12AffineEnvironment.transform 5 49 env41886 = env41887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env41886 == env41887) = true)

theorem identity41887 : scanCanonicalize (H12AffineFastState.compose env41887 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound41887 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41888 : List Nat := [2,4,8,5,32,36,8,36,43,0,33,4,9,0,32,34,4,32,0,33,32,0,4,2,9,37,32,36,37,0,1,0,36,1,33,11]

theorem envBound41888 : H12AffineFastState.Bounded env41888 := by
  intro p hp
  have h : env41888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41887_41888 : H12AffineEnvironment.transform 3 5 env41887 = env41888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env41887 == env41888) = true)

theorem identity41888 : scanCanonicalize (H12AffineFastState.compose env41888 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound41888 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env41889 : List Nat := [2,4,8,5,6,2,8,2,13,0,7,4,9,0,6,4,4,6,0,7,6,0,4,2,9,3,6,2,3,0,1,0,2,1,7,11]

theorem envBound41889 : H12AffineFastState.Bounded env41889 := by
  intro p hp
  have h : env41889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41888_41889 : H12AffineEnvironment.transform 4 6 env41888 = env41889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env41888 == env41889) = true)

theorem identity41889 : scanCanonicalize (H12AffineFastState.compose env41889 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41889 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env41890 : List Nat := [2,3,8,2,1,2,8,2,10,0,0,3,9,0,1,3,3,1,0,0,1,0,3,2,9,3,1,2,3,0,1,0,2,1,0,11]

theorem envBound41890 : H12AffineFastState.Bounded env41890 := by
  intro p hp
  have h : env41890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41889_41890 : H12AffineEnvironment.transform 1 3 env41889 = env41890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41889 == env41890) = true)

def env41891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243002,17,98644,8193,65,171281,5393,17665,108927,1365,213350,256,21793,46093,74251]

theorem envBound41891 : H12AffineFastState.Bounded env41891 := by
  intro p hp
  have h : env41891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41875_41891 : H12AffineEnvironment.transform 6 9 env41875 = env41891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41875 == env41891) = true)

theorem identity41891 : scanCanonicalize (H12AffineFastState.compose env41891 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223598,1024,8540,4160,201831,17,73737,8193,65,146508,5393,17665,67618,1365,213350,256,21793,5456,74251]

theorem envBound41892 : H12AffineFastState.Bounded env41892 := by
  intro p hp
  have h : env41892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41891_41892 : H12AffineEnvironment.transform 14 8541 env41891 = env41892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41891 == env41892) = true)

theorem identity41892 : scanCanonicalize (H12AffineFastState.compose env41892 (packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound41892 : packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS < 2^1333 := by decide +kernel

def env41893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,34,131072,158028,1024,8540,4160,136261,17,8235,8193,65,146508,5393,17665,2048,1365,147780,256,21793,5456,8745]

theorem envBound41893 : H12AffineFastState.Bounded env41893 := by
  intro p hp
  have h : env41893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41892_41893 : H12AffineEnvironment.transform 15 34 env41892 = env41893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env41892 == env41893) = true)

def env41894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,16,98780,8328,65,4270242,5393,17665,108926,1500,4256860,256,21792,46213,74251]

theorem envBound41894 : H12AffineFastState.Bounded env41894 := by
  intro p hp
  have h : env41894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41873_41894 : H12AffineEnvironment.transform 20 4161 env41873 = env41894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41873 == env41894) = true)

theorem identity41894 : scanCanonicalize (H12AffineFastState.compose env41894 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41894 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4161,4194304,16,41430,8328,65,4196520,5393,17665,35188,1500,4256860,256,21792,46213,513]

theorem envBound41895 : H12AffineFastState.Bounded env41895 := by
  intro p hp
  have h : env41895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41894_41895 : H12AffineEnvironment.transform 15 8202 env41894 = env41895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41894 == env41895) = true)

theorem identity41895 : scanCanonicalize (H12AffineFastState.compose env41895 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8693) := by decide +kernel

theorem selectedBound41895 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4161,8693,16,41430,8328,65,10589,5393,17665,35188,1500,54697,256,21792,46213,513]

theorem envBound41896 : H12AffineFastState.Bounded env41896 := by
  intro p hp
  have h : env41896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41895_41896 : H12AffineEnvironment.transform 21 8693 env41895 = env41896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8693 env41895 == env41896) = true)

theorem identity41896 : scanCanonicalize (H12AffineFastState.compose env41896 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41896 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env41897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4161,8573,16,41310,8192,65,10589,5393,17665,35188,1364,54561,256,21792,46093,513]

theorem envBound41897 : H12AffineFastState.Bounded env41897 := by
  intro p hp
  have h : env41897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41896_41897 : H12AffineEnvironment.transform 6 8 env41896 = env41897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41896 == env41897) = true)

theorem identity41897 : scanCanonicalize (H12AffineFastState.compose env41897 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound41897 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24908,10280,1024,32769,4161,8573,16,41310,8192,65,10589,5393,17665,35188,1364,54561,256,21792,46093,513]

theorem envBound41898 : H12AffineFastState.Bounded env41898 := by
  intro p hp
  have h : env41898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41897_41898 : H12AffineEnvironment.transform 16 24908 env41897 = env41898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env41897 == env41898) = true)

theorem identity41898 : scanCanonicalize (H12AffineFastState.compose env41898 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41898 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env41899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,24908,10280,1024,8540,4161,8573,16,3,8192,65,10589,5393,17665,10281,1364,29820,256,21792,5456,513]

theorem envBound41899 : H12AffineFastState.Bounded env41899 := by
  intro p hp
  have h : env41899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41898_41899 : H12AffineEnvironment.transform 14 8541 env41898 = env41899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41898 == env41899) = true)

theorem identity41899 : scanCanonicalize (H12AffineFastState.compose env41899 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound41899 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8202,5393,10280,1024,8540,4161,8573,16,3,8192,65,10589,5393,12636,10281,1364,33,256,8573,5456,513]

theorem envBound41900 : H12AffineFastState.Bounded env41900 := by
  intro p hp
  have h : env41900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41899_41900 : H12AffineEnvironment.transform 13 13405 env41899 = env41900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env41899 == env41900) = true)

theorem identity41900 : scanCanonicalize (H12AffineFastState.compose env41900 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41900 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41901 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,8460,8202,5393,10280,1024,8461,4112,8492,16,3,8192,16,10508,5393,12557,10281,1285,33,256,8492,5377,513]

theorem envBound41901 : H12AffineFastState.Bounded env41901 := by
  intro p hp
  have h : env41901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41900_41901 : H12AffineEnvironment.transform 5 17 env41900 = env41901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41900 == env41901) = true)

theorem identity41901 : scanCanonicalize (H12AffineFastState.compose env41901 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41901 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41902 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1024,0,4112,33,16,3,269,16,2049,5393,4096,2340,1285,33,256,33,5377,513]

theorem envBound41902 : H12AffineFastState.Bounded env41902 := by
  intro p hp
  have h : env41902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41901_41902 : H12AffineEnvironment.transform 12 269 env41901 = env41902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41901 == env41902) = true)

theorem identity41902 : scanCanonicalize (H12AffineFastState.compose env41902 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound41902 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41903 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1312,269,33,1,263,49,2341,1024,0,1328,33,16,3,269,16,2049,49,1312,2340,1285,33,256,33,33,513]

theorem envBound41903 : H12AffineFastState.Bounded env41903 := by
  intro p hp
  have h : env41903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41902_41903 : H12AffineEnvironment.transform 11 1312 env41902 = env41903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env41902 == env41903) = true)

theorem identity41903 : scanCanonicalize (H12AffineFastState.compose env41903 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41903 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41904 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,1029,40,33,1,34,49,2048,1024,0,1045,33,16,3,40,16,2049,49,1029,2049,1056,33,37,33,33,513]

theorem envBound41904 : H12AffineFastState.Bounded env41904 := by
  intro p hp
  have h : env41904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41903_41904 : H12AffineEnvironment.transform 7 37 env41903 = env41904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41903 == env41904) = true)

theorem identity41904 : scanCanonicalize (H12AffineFastState.compose env41904 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound41904 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41905 : List Nat := [2,4,8,16,32,17,8,37,512,532,2048,529,40,33,1,34,49,2048,532,0,513,33,16,3,40,16,2049,49,529,2049,564,33,37,33,33,513]

theorem envBound41905 : H12AffineFastState.Bounded env41905 := by
  intro p hp
  have h : env41905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41904_41905 : H12AffineEnvironment.transform 9 532 env41904 = env41905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env41904 == env41905) = true)

theorem identity41905 : scanCanonicalize (H12AffineFastState.compose env41905 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound41905 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41906 : List Nat := [2,4,8,16,32,17,8,37,512,532,513,529,40,33,1,34,49,513,532,0,513,33,16,3,40,16,512,49,529,512,564,33,37,33,33,513]

theorem envBound41906 : H12AffineFastState.Bounded env41906 := by
  intro p hp
  have h : env41906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41905_41906 : H12AffineEnvironment.transform 10 513 env41905 = env41906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env41905 == env41906) = true)

theorem identity41906 : scanCanonicalize (H12AffineFastState.compose env41906 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41906 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41907 : List Nat := [2,4,8,16,17,17,8,20,512,532,513,529,25,16,1,19,0,513,532,0,513,16,16,3,25,16,512,0,529,512,517,16,20,16,16,513]

theorem envBound41907 : H12AffineFastState.Bounded env41907 := by
  intro p hp
  have h : env41907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41906_41907 : H12AffineEnvironment.transform 4 17 env41906 = env41907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41906 == env41907) = true)

theorem identity41907 : scanCanonicalize (H12AffineFastState.compose env41907 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound41907 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env41908 : List Nat := [2,4,8,16,17,17,8,20,17,5,16,0,25,16,1,19,0,16,5,0,16,16,16,3,25,16,17,0,0,17,20,16,20,16,16,16]

theorem envBound41908 : H12AffineFastState.Bounded env41908 := by
  intro p hp
  have h : env41908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41907_41908 : H12AffineEnvironment.transform 8 17 env41907 = env41908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41907 == env41908) = true)

def env41909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound41909 : H12AffineFastState.Bounded env41909 := by
  intro p hp
  have h : env41909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41742_41909 : H12AffineEnvironment.transform 18 1025 env41742 = env41909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env41742 == env41909) = true)

theorem identity41909 : scanCanonicalize (H12AffineFastState.compose env41909 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8686063) := by decide +kernel

theorem selectedBound41909 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8686063,8328,65,4409838,10816866,10507600,8830977,331263,15068206,257,2444611,2469095,272937]

theorem envBound41910 : H12AffineFastState.Bounded env41910 := by
  intro p hp
  have h : env41910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41909_41910 : H12AffineEnvironment.transform 23 8686063 env41909 = env41910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8686063 env41909 == env41910) = true)

def env41911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4409702,10816866,10507600,8830977,331127,15068206,257,2444611,2468975,272937]

theorem envBound41911 : H12AffineFastState.Bounded env41911 := by
  intro p hp
  have h : env41911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41910_41911 : H12AffineEnvironment.transform 6 8 env41910 = env41911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41910 == env41911) = true)

theorem identity41911 : scanCanonicalize (H12AffineFastState.compose env41911 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 371055) := by decide +kernel

theorem selectedBound41911 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env41912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,371055,73736,8192,65,4409702,2139149,2489407,223598,331127,6309185,257,2444611,2468975,272937]

theorem envBound41912 : H12AffineFastState.Bounded env41912 := by
  intro p hp
  have h : env41912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41911_41912 : H12AffineEnvironment.transform 22 371055 env41911 = env41912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 371055 env41911 == env41912) = true)

theorem identity41912 : scanCanonicalize (H12AffineFastState.compose env41912 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41912 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env41913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,2097152,4194304,297317,2,8192,65,4352364,2139149,2415669,149860,273789,6309185,257,2387273,2395237,272937]

theorem envBound41913 : H12AffineFastState.Bounded env41913 := by
  intro p hp
  have h : env41913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41912_41913 : H12AffineEnvironment.transform 15 8202 env41912 = env41913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41912 == env41913) = true)

theorem identity41913 : scanCanonicalize (H12AffineFastState.compose env41913 (packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound41913 : packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,157752,1025,32769,2097152,4194304,188765,2,8192,65,4352364,2139149,2274317,149860,148805,6309185,257,2229617,2286685,147985]

theorem envBound41914 : H12AffineFastState.Bounded env41914 := by
  intro p hp
  have h : env41914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41913_41914 : H12AffineEnvironment.transform 17 157752 env41913 = env41914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env41913 == env41914) = true)

theorem identity41914 : scanCanonicalize (H12AffineFastState.compose env41914 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound41914 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env41915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,2097152,4194304,41293,2,8192,65,4204924,2139149,2159645,2420,1365,6309185,257,2114913,2139213,513]

theorem envBound41915 : H12AffineFastState.Bounded env41915 := by
  intro p hp
  have h : env41915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41914_41915 : H12AffineEnvironment.transform 16 16400 env41914 = env41915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41914 == env41915) = true)

theorem identity41915 : scanCanonicalize (H12AffineFastState.compose env41915 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41915 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env41916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,2097152,4194304,17,2,8192,65,4204924,2098513,2118977,2420,1365,6309185,257,2114913,2098449,513]

theorem envBound41916 : H12AffineFastState.Bounded env41916 := by
  intro p hp
  have h : env41916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41915_41916 : H12AffineEnvironment.transform 14 8540 env41915 = env41916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41915 == env41916) = true)

theorem identity41916 : scanCanonicalize (H12AffineFastState.compose env41916 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 16497) := by decide +kernel

theorem selectedBound41916 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,2097152,16497,17,2,8192,65,26893,2098513,2118977,2420,1365,2098480,257,2114913,2098449,513]

theorem envBound41917 : H12AffineFastState.Bounded env41917 := by
  intro p hp
  have h : env41917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41916_41917 : H12AffineEnvironment.transform 21 16497 env41916 = env41917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16497 env41916 == env41917) = true)

theorem identity41917 : scanCanonicalize (H12AffineFastState.compose env41917 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound41917 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env41918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,12572,16497,17,2,8192,65,26893,13389,25693,2420,1365,13356,257,29821,13325,513]

theorem envBound41918 : H12AffineFastState.Bounded env41918 := by
  intro p hp
  have h : env41918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41917_41918 : H12AffineEnvironment.transform 20 12572 env41917 = env41918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env41917 == env41918) = true)

theorem identity41918 : scanCanonicalize (H12AffineFastState.compose env41918 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound41918 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1297,1095,16400,3173,1025,1296,5457,16497,17,2,1101,65,19776,4096,16400,2420,1365,4193,257,20528,4160,513]

theorem envBound41919 : H12AffineFastState.Bounded env41919 := by
  intro p hp
  have h : env41919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41918_41919 : H12AffineEnvironment.transform 12 1101 env41918 = env41919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env41918 == env41919) = true)

theorem identity41919 : scanCanonicalize (H12AffineFastState.compose env41919 (packedSelected [4,9,23] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound41919 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env41920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,81,1297,1095,65,3173,1025,1296,5457,32,17,2,1101,65,3345,4096,65,2420,1365,4193,257,4193,4160,513]

theorem envBound41920 : H12AffineFastState.Bounded env41920 := by
  intro p hp
  have h : env41920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41919_41920 : H12AffineEnvironment.transform 13 81 env41919 = env41920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env41919 == env41920) = true)

theorem identity41920 : scanCanonicalize (H12AffineFastState.compose env41920 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1101,81,1297,1095,65,3173,1025,1296,1345,32,17,2,1101,65,3345,16,65,2420,1365,113,257,113,80,513]

theorem envBound41921 : H12AffineFastState.Bounded env41921 := by
  intro p hp
  have h : env41921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41920_41921 : H12AffineEnvironment.transform 11 16 env41920 = env41921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41920 == env41921) = true)

theorem identity41921 : scanCanonicalize (H12AffineFastState.compose env41921 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound41921 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,16,1101,81,1297,1095,65,80,1025,1296,1345,32,17,2,1101,65,292,16,65,1345,1365,113,257,113,80,513]

theorem envBound41922 : H12AffineFastState.Bounded env41922 := by
  intro p hp
  have h : env41922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41921_41922 : H12AffineEnvironment.transform 10 1077 env41921 = env41922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env41921 == env41922) = true)

theorem identity41922 : scanCanonicalize (H12AffineFastState.compose env41922 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41922 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env41923 : List Nat := [2,4,8,16,32,64,8,256,512,273,292,16,348,81,0,342,65,80,272,1,80,32,17,2,348,65,292,16,65,80,68,113,257,113,80,513]

theorem envBound41923 : H12AffineFastState.Bounded env41923 := by
  intro p hp
  have h : env41923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41922_41923 : H12AffineEnvironment.transform 9 273 env41922 = env41923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41922 == env41923) = true)

theorem identity41923 : scanCanonicalize (H12AffineFastState.compose env41923 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41924 : List Nat := [2,4,8,16,32,17,8,256,512,273,292,16,269,0,0,263,16,1,272,1,1,32,17,2,269,16,292,16,16,1,21,32,257,32,1,513]

theorem envBound41924 : H12AffineFastState.Bounded env41924 := by
  intro p hp
  have h : env41924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41923_41924 : H12AffineEnvironment.transform 5 17 env41923 = env41924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41923 == env41924) = true)

def env41925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4409703,10816866,10507600,8830977,331126,15068206,257,2444611,2468974,272937]

theorem envBound41925 : H12AffineFastState.Bounded env41925 := by
  intro p hp
  have h : env41925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41910_41925 : H12AffineEnvironment.transform 6 9 env41910 = env41925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41910 == env41925) = true)

def env41926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4262263,10816866,10507600,8683537,331126,15068206,257,2444611,2468974,272937]

theorem envBound41926 : H12AffineFastState.Bounded env41926 := by
  intro p hp
  have h : env41926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41925_41926 : H12AffineEnvironment.transform 16 16400 env41925 = env41926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41925 == env41926) = true)

theorem identity41926 : scanCanonicalize (H12AffineFastState.compose env41926 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41926 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env41927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429902,8193,65,4262263,10560842,10507600,8431673,75102,14795782,257,2188651,2196550,513]

theorem envBound41927 : H12AffineFastState.Bounded env41927 := by
  intro p hp
  have h : env41927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41926_41927 : H12AffineEnvironment.transform 17 10280 env41926 = env41927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41926 == env41927) = true)

def env41928 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429854,8193,17,4262183,10560794,10507520,8431673,75022,14795782,257,2188603,2196502,513]

theorem envBound41928 : H12AffineFastState.Bounded env41928 := by
  intro p hp
  have h : env41928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41927_41928 : H12AffineEnvironment.transform 5 16 env41927 = env41928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41927 == env41928) = true)

theorem identity41928 : scanCanonicalize (H12AffineFastState.compose env41928 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4268090) := by decide +kernel

theorem selectedBound41928 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41929 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4268090,4292900,8193,17,4262183,6292768,6387002,4294659,75022,2155580,257,2188603,2196502,513]

theorem envBound41929 : H12AffineFastState.Bounded env41929 := by
  intro p hp
  have h : env41929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41928_41929 : H12AffineEnvironment.transform 22 4268090 env41928 = env41929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268090 env41928 == env41929) = true)

theorem identity41929 : scanCanonicalize (H12AffineFastState.compose env41929 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(20+1) ^^^ 91418) := by decide +kernel

theorem selectedBound41929 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env41930 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,91418,4194304,4268090,4292900,8193,17,4262183,4284474,4198432,4294659,75022,98598,257,33,57612,513]

theorem envBound41930 : H12AffineFastState.Bounded env41930 := by
  intro p hp
  have h : env41930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41929_41930 : H12AffineEnvironment.transform 20 91418 env41929 = env41930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91418 env41929 == env41930) = true)

theorem identity41930 : scanCanonicalize (H12AffineFastState.compose env41930 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound41930 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env41931 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,16400,10280,1025,32769,25628,4194304,4202812,4227106,8193,17,4196385,4219196,4198432,4229381,9224,32800,257,33,57612,513]

theorem envBound41931 : H12AffineFastState.Bounded env41931 := by
  intro p hp
  have h : env41931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41930_41931 : H12AffineEnvironment.transform 15 262 env41930 = env41931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env41930 == env41931) = true)

theorem identity41931 : scanCanonicalize (H12AffineFastState.compose env41931 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound41931 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41932 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,16400,10280,1025,32769,25628,41261,32785,8463,8193,17,43276,49169,45325,10280,9224,32800,257,33,57612,513]

theorem envBound41932 : H12AffineFastState.Bounded env41932 := by
  intro p hp
  have h : env41932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41931_41932 : H12AffineEnvironment.transform 21 41261 env41931 = env41932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env41931 == env41932) = true)

theorem identity41932 : scanCanonicalize (H12AffineFastState.compose env41932 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41932 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41933 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16400,2340,1025,32769,17680,32801,32785,3,269,17,34816,49169,36865,2340,1284,32800,257,33,49152,513]

theorem envBound41933 : H12AffineFastState.Bounded env41933 := by
  intro p hp
  have h : env41933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41932_41933 : H12AffineEnvironment.transform 12 268 env41932 = env41933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41932 == env41933) = true)

theorem identity41933 : scanCanonicalize (H12AffineFastState.compose env41933 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41933 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41934 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16400,2340,1025,1,17680,33,17,3,269,17,2048,16401,4097,2340,1284,32,257,33,16384,513]

theorem envBound41934 : H12AffineFastState.Bounded env41934 := by
  intro p hp
  have h : env41934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41933_41934 : H12AffineEnvironment.transform 14 0 env41933 = env41934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41933 == env41934) = true)

theorem identity41934 : scanCanonicalize (H12AffineFastState.compose env41934 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41935 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5156,0,262,5172,2340,1025,1,4404,33,17,3,269,17,2048,5173,4097,2340,1284,32,257,33,5156,513]

theorem envBound41935 : H12AffineFastState.Bounded env41935 := by
  intro p hp
  have h : env41935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41934_41935 : H12AffineEnvironment.transform 13 5156 env41934 = env41935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env41934 == env41935) = true)

def env41936 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,268,2836,0,262,2820,2340,1025,1,3588,33,17,3,269,17,2048,2821,3889,2340,1284,32,257,33,2836,513]

theorem envBound41936 : H12AffineFastState.Bounded env41936 := by
  intro p hp
  have h : env41936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41935_41936 : H12AffineEnvironment.transform 11 3888 env41935 = env41936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env41935 == env41936) = true)

def env41937 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,268,1044,0,262,1028,1572,1025,1,260,33,17,3,269,17,1792,1029,49,1572,1284,32,257,33,1044,513]

theorem envBound41937 : H12AffineFastState.Bounded env41937 := by
  intro p hp
  have h : env41937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41936_41937 : H12AffineEnvironment.transform 10 1792 env41936 = env41937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41936 == env41937) = true)

theorem identity41937 : scanCanonicalize (H12AffineFastState.compose env41937 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41937 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41938 : List Nat := [2,4,8,16,32,16,9,256,512,20,788,48,268,0,0,262,16,560,21,1,260,33,17,3,269,17,788,17,49,560,272,32,257,33,0,513]

theorem envBound41938 : H12AffineFastState.Bounded env41938 := by
  intro p hp
  have h : env41938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41937_41938 : H12AffineEnvironment.transform 9 20 env41937 = env41938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41937 == env41938) = true)

def env41939 : List Nat := [2,4,8,16,0,16,9,256,512,20,788,16,268,0,0,262,16,528,21,1,260,1,17,3,269,17,788,17,17,528,272,0,257,1,0,513]

theorem envBound41939 : H12AffineFastState.Bounded env41939 := by
  intro p hp
  have h : env41939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41938_41939 : H12AffineEnvironment.transform 4 0 env41938 = env41939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41938 == env41939) = true)

theorem identity41939 : scanCanonicalize (H12AffineFastState.compose env41939 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound41939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41940 : List Nat := [2,4,8,16,0,16,9,256,277,20,1,16,268,0,0,262,16,261,21,1,260,1,17,3,269,17,1,17,17,261,272,0,257,1,0,276]

theorem envBound41940 : H12AffineFastState.Bounded env41940 := by
  intro p hp
  have h : env41940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41939_41940 : H12AffineEnvironment.transform 8 277 env41939 = env41940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env41939 == env41940) = true)

def leafEnv41940 : List Nat := [2,4,8,16,0,16,9,256,277,20,1,16,268,0,0,262,16,261,21,1,260,1,17,3,273,269,1,17,1,17,17,261,272,0,257,1,5,263,0,276,1,260,0]

def active41940 : List Nat := [0,1,2,3,7]

def tree41940 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41940 : H12WitnessSearch.Good tree41940 := H12GlobalWitnessIndex.good

theorem leafIdentity41940 : H12AffineFastState.composeSystem env41940 rootObs = leafEnv41940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41940 rootObs == leafEnv41940) = true)

theorem terminalChecked41940 : H12PackedTerminal.terminalCheckFast leafEnv41940 active41940 tree41940 = true := by decide +kernel

def env41941 : List Nat := [2,4,8,16,1,16,9,256,512,20,788,17,268,0,0,262,16,529,21,1,260,0,17,3,269,17,788,17,16,529,272,1,257,0,0,513]

theorem envBound41941 : H12AffineFastState.Bounded env41941 := by
  intro p hp
  have h : env41941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41938_41941 : H12AffineEnvironment.transform 4 1 env41938 = env41941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41938 == env41941) = true)

theorem identity41941 : scanCanonicalize (H12AffineFastState.compose env41941 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41941 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41942 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,11,268,0,0,262,10,523,15,1,260,0,11,3,269,11,782,11,10,523,266,1,257,0,0,513]

theorem envBound41942 : H12AffineFastState.Bounded env41942 := by
  intro p hp
  have h : env41942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41941_41942 : H12AffineEnvironment.transform 3 10 env41941 = env41942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41941 == env41942) = true)

def leafEnv41942 : List Nat := [2,4,8,10,1,10,9,256,512,14,782,11,268,0,0,262,10,523,15,1,260,0,11,3,267,269,1,11,782,11,10,523,266,1,257,0,5,263,0,513,1,260,0]

def active41942 : List Nat := [0,1,2,7,8]

def tree41942 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41942 : H12WitnessSearch.Good tree41942 := H12GlobalWitnessIndex.good

theorem leafIdentity41942 : H12AffineFastState.composeSystem env41942 rootObs = leafEnv41942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41942 rootObs == leafEnv41942) = true)

theorem terminalChecked41942 : H12PackedTerminal.terminalCheckFast leafEnv41942 active41942 tree41942 = true := by decide +kernel

def env41943 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,268,1045,0,262,1029,1573,1025,1,261,33,17,3,269,17,1793,1028,48,1573,1284,32,257,33,1045,513]

theorem envBound41943 : H12AffineFastState.Bounded env41943 := by
  intro p hp
  have h : env41943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41936_41943 : H12AffineEnvironment.transform 10 1793 env41936 = env41943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41936 == env41943) = true)

theorem identity41943 : scanCanonicalize (H12AffineFastState.compose env41943 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41943 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41944 : List Nat := [2,4,8,16,32,16,9,5,512,1024,1540,49,9,1045,0,3,1029,1573,1025,1,0,33,17,3,8,17,1540,1028,48,1573,1025,32,4,33,1045,513]

theorem envBound41944 : H12AffineFastState.Bounded env41944 := by
  intro p hp
  have h : env41944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41943_41944 : H12AffineEnvironment.transform 7 5 env41943 = env41944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41943 == env41944) = true)

def env41945 : List Nat := [2,4,8,16,32,16,9,5,512,52,560,49,9,33,0,3,49,529,53,1,0,33,17,3,8,17,560,48,48,529,53,32,4,33,33,513]

theorem envBound41945 : H12AffineFastState.Bounded env41945 := by
  intro p hp
  have h : env41945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41944_41945 : H12AffineEnvironment.transform 9 52 env41944 = env41945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41944 == env41945) = true)

theorem identity41945 : scanCanonicalize (H12AffineFastState.compose env41945 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound41945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41946 : List Nat := [2,4,8,16,32,16,9,5,16,52,32,49,9,33,0,3,49,1,53,1,0,33,17,3,8,17,32,48,48,1,53,32,4,33,33,17]

theorem envBound41946 : H12AffineFastState.Bounded env41946 := by
  intro p hp
  have h : env41946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41945_41946 : H12AffineEnvironment.transform 8 16 env41945 = env41946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41945 == env41946) = true)

def leafEnv41946 : List Nat := [2,4,8,16,32,16,9,5,16,52,32,49,9,33,0,3,49,1,53,1,0,33,17,3,52,8,1,17,32,48,48,1,53,32,4,33,5,2,33,17,1,0,0]

def active41946 : List Nat := [0,1,2,3,4]

def tree41946 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41946 : H12WitnessSearch.Good tree41946 := H12GlobalWitnessIndex.good

theorem leafIdentity41946 : H12AffineFastState.composeSystem env41946 rootObs = leafEnv41946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41946 rootObs == leafEnv41946) = true)

theorem terminalChecked41946 : H12PackedTerminal.terminalCheckFast leafEnv41946 active41946 tree41946 = true := by decide +kernel

def env41947 : List Nat := [2,4,8,16,32,16,9,5,512,53,561,49,9,32,0,3,48,528,52,1,0,33,17,3,8,17,561,49,48,528,52,32,4,33,32,513]

theorem envBound41947 : H12AffineFastState.Bounded env41947 := by
  intro p hp
  have h : env41947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41944_41947 : H12AffineEnvironment.transform 9 53 env41944 = env41947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41944 == env41947) = true)

theorem identity41947 : scanCanonicalize (H12AffineFastState.compose env41947 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41947 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41948 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,42,9,32,0,3,43,523,47,1,0,33,10,3,8,10,554,42,43,523,47,32,4,33,32,513]

theorem envBound41948 : H12AffineFastState.Bounded env41948 := by
  intro p hp
  have h : env41948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41947_41948 : H12AffineEnvironment.transform 3 11 env41947 = env41948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41947 == env41948) = true)

def leafEnv41948 : List Nat := [2,4,8,11,32,11,9,5,512,46,554,42,9,32,0,3,43,523,47,1,0,33,10,3,46,8,1,10,554,42,43,523,47,32,4,33,5,2,32,513,1,0,0]

def active41948 : List Nat := [0,1,2,4,8]

def tree41948 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41948 : H12WitnessSearch.Good tree41948 := H12GlobalWitnessIndex.good

theorem leafIdentity41948 : H12AffineFastState.composeSystem env41948 rootObs = leafEnv41948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41948 rootObs == leafEnv41948) = true)

theorem terminalChecked41948 : H12PackedTerminal.terminalCheckFast leafEnv41948 active41948 tree41948 = true := by decide +kernel

def env41949 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,268,2837,0,262,2821,2340,1025,1,3589,33,17,3,269,17,2048,2820,3888,2340,1284,32,257,33,2837,513]

theorem envBound41949 : H12AffineFastState.Bounded env41949 := by
  intro p hp
  have h : env41949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41935_41949 : H12AffineEnvironment.transform 11 3889 env41935 = env41949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env41935 == env41949) = true)

def env41950 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,268,1045,0,262,1029,1572,1025,1,261,33,17,3,269,17,1792,1028,48,1572,1284,32,257,33,1045,513]

theorem envBound41950 : H12AffineFastState.Bounded env41950 := by
  intro p hp
  have h : env41950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41949_41950 : H12AffineEnvironment.transform 10 1792 env41949 = env41950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41949 == env41950) = true)

theorem identity41950 : scanCanonicalize (H12AffineFastState.compose env41950 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41951 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1792,17,268,1045,0,262,1029,1540,1025,1,261,1,17,3,269,17,1792,1028,16,1540,1284,0,257,1,1045,513]

theorem envBound41951 : H12AffineFastState.Bounded env41951 := by
  intro p hp
  have h : env41951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41950_41951 : H12AffineEnvironment.transform 4 0 env41950 = env41951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41950 == env41951) = true)

def env41952 : List Nat := [2,4,8,16,0,16,9,256,512,20,788,17,268,1,0,262,17,528,21,1,261,1,17,3,269,17,788,16,16,528,272,0,257,1,1,513]

theorem envBound41952 : H12AffineFastState.Bounded env41952 := by
  intro p hp
  have h : env41952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41951_41952 : H12AffineEnvironment.transform 9 20 env41951 = env41952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41951 == env41952) = true)

theorem identity41952 : scanCanonicalize (H12AffineFastState.compose env41952 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound41952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41953 : List Nat := [2,4,8,16,0,16,9,256,276,20,0,17,268,1,0,262,17,260,21,1,261,1,17,3,269,17,0,16,16,260,272,0,257,1,1,277]

theorem envBound41953 : H12AffineFastState.Bounded env41953 := by
  intro p hp
  have h : env41953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41952_41953 : H12AffineEnvironment.transform 8 276 env41952 = env41953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env41952 == env41953) = true)

def leafEnv41953 : List Nat := [2,4,8,16,0,16,9,256,276,20,0,17,268,1,0,262,17,260,21,1,261,1,17,3,273,269,1,17,0,16,16,260,272,0,257,1,5,263,1,277,1,261,0]

def active41953 : List Nat := [0,1,2,3,7]

def tree41953 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41953 : H12WitnessSearch.Good tree41953 := H12GlobalWitnessIndex.good

theorem leafIdentity41953 : H12AffineFastState.composeSystem env41953 rootObs = leafEnv41953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41953 rootObs == leafEnv41953) = true)

theorem terminalChecked41953 : H12PackedTerminal.terminalCheckFast leafEnv41953 active41953 tree41953 = true := by decide +kernel

def env41954 : List Nat := [2,4,8,16,0,16,9,256,512,21,789,17,268,0,0,262,16,529,20,1,261,1,17,3,269,17,789,17,16,529,273,0,257,1,0,513]

theorem envBound41954 : H12AffineFastState.Bounded env41954 := by
  intro p hp
  have h : env41954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41951_41954 : H12AffineEnvironment.transform 9 21 env41951 = env41954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41951 == env41954) = true)

theorem identity41954 : scanCanonicalize (H12AffineFastState.compose env41954 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41954 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41955 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,11,268,0,0,262,10,523,14,1,261,1,11,3,269,11,783,11,10,523,267,0,257,1,0,513]

theorem envBound41955 : H12AffineFastState.Bounded env41955 := by
  intro p hp
  have h : env41955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41954_41955 : H12AffineEnvironment.transform 3 10 env41954 = env41955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41954 == env41955) = true)

def leafEnv41955 : List Nat := [2,4,8,10,0,10,9,256,512,15,783,11,268,0,0,262,10,523,14,1,261,1,11,3,266,269,1,11,783,11,10,523,267,0,257,1,5,263,0,513,1,261,0]

def active41955 : List Nat := [0,1,2,7,8]

def tree41955 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41955 : H12WitnessSearch.Good tree41955 := H12GlobalWitnessIndex.good

theorem leafIdentity41955 : H12AffineFastState.composeSystem env41955 rootObs = leafEnv41955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41955 rootObs == leafEnv41955) = true)

theorem terminalChecked41955 : H12PackedTerminal.terminalCheckFast leafEnv41955 active41955 tree41955 = true := by decide +kernel

def env41956 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,268,1044,0,262,1028,1573,1025,1,260,33,17,3,269,17,1793,1029,49,1573,1284,32,257,33,1044,513]

theorem envBound41956 : H12AffineFastState.Bounded env41956 := by
  intro p hp
  have h : env41956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41949_41956 : H12AffineEnvironment.transform 10 1793 env41949 = env41956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41949 == env41956) = true)

theorem identity41956 : scanCanonicalize (H12AffineFastState.compose env41956 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound41956 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41957 : List Nat := [2,4,8,16,32,16,9,256,512,305,560,48,268,293,0,262,309,788,304,1,260,33,17,3,269,17,560,308,49,788,53,32,257,33,293,513]

theorem envBound41957 : H12AffineFastState.Bounded env41957 := by
  intro p hp
  have h : env41957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41956_41957 : H12AffineEnvironment.transform 9 305 env41956 = env41957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env41956 == env41957) = true)

def env41958 : List Nat := [2,4,8,16,32,16,9,4,512,53,560,48,8,33,0,2,49,528,52,1,0,33,17,3,9,17,560,48,49,528,53,32,5,33,33,513]

theorem envBound41958 : H12AffineFastState.Bounded env41958 := by
  intro p hp
  have h : env41958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41957_41958 : H12AffineEnvironment.transform 7 4 env41957 = env41958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41957 == env41958) = true)

theorem identity41958 : scanCanonicalize (H12AffineFastState.compose env41958 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41959 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,43,8,33,0,2,42,523,47,1,0,33,10,3,9,10,555,43,42,523,46,32,5,33,33,513]

theorem envBound41959 : H12AffineFastState.Bounded env41959 := by
  intro p hp
  have h : env41959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41958_41959 : H12AffineEnvironment.transform 3 11 env41958 = env41959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41958 == env41959) = true)

def leafEnv41959 : List Nat := [2,4,8,11,32,11,9,4,512,46,555,43,8,33,0,2,42,523,47,1,0,33,10,3,47,9,1,10,555,43,42,523,46,32,5,33,5,3,33,513,1,0,0]

def active41959 : List Nat := [0,1,2,4,8]

def tree41959 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41959 : H12WitnessSearch.Good tree41959 := H12GlobalWitnessIndex.good

theorem leafIdentity41959 : H12AffineFastState.composeSystem env41959 rootObs = leafEnv41959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41959 rootObs == leafEnv41959) = true)

theorem terminalChecked41959 : H12PackedTerminal.terminalCheckFast leafEnv41959 active41959 tree41959 = true := by decide +kernel

def env41960 : List Nat := [2,4,8,16,32,16,9,5,512,52,560,48,9,32,0,3,48,529,53,1,1,33,17,3,8,17,560,49,49,529,53,32,4,33,32,513]

theorem envBound41960 : H12AffineFastState.Bounded env41960 := by
  intro p hp
  have h : env41960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41957_41960 : H12AffineEnvironment.transform 7 5 env41957 = env41960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41957 == env41960) = true)

theorem identity41960 : scanCanonicalize (H12AffineFastState.compose env41960 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound41960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41961 : List Nat := [2,4,8,16,32,16,9,5,17,52,33,48,9,32,0,3,48,0,53,1,1,33,17,3,8,17,33,49,49,0,53,32,4,33,32,16]

theorem envBound41961 : H12AffineFastState.Bounded env41961 := by
  intro p hp
  have h : env41961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41960_41961 : H12AffineEnvironment.transform 8 17 env41960 = env41961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41960 == env41961) = true)

def leafEnv41961 : List Nat := [2,4,8,16,32,16,9,5,17,52,33,48,9,32,0,3,48,0,53,1,1,33,17,3,52,8,1,17,33,49,49,0,53,32,4,33,5,2,32,16,1,1,0]

def active41961 : List Nat := [0,1,2,3,4]

def tree41961 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41961 : H12WitnessSearch.Good tree41961 := H12GlobalWitnessIndex.good

theorem leafIdentity41961 : H12AffineFastState.composeSystem env41961 rootObs = leafEnv41961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41961 rootObs == leafEnv41961) = true)

theorem terminalChecked41961 : H12PackedTerminal.terminalCheckFast leafEnv41961 active41961 tree41961 = true := by decide +kernel

def env41962 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429855,8193,16,4262182,10560795,10507521,8431673,75023,14795782,257,2188602,2196503,513]

theorem envBound41962 : H12AffineFastState.Bounded env41962 := by
  intro p hp
  have h : env41962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41927_41962 : H12AffineEnvironment.transform 5 17 env41927 = env41962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41927 == env41962) = true)

theorem identity41962 : scanCanonicalize (H12AffineFastState.compose env41962 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound41962 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41963 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4194353,4235566,8193,16,4262182,6366506,6313264,4237320,75023,2212919,257,2188602,2196503,513]

theorem envBound41963 : H12AffineFastState.Bounded env41963 := by
  intro p hp
  have h : env41963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41962_41963 : H12AffineEnvironment.transform 22 4194353 env41962 = env41963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env41962 == env41963) = true)

theorem identity41963 : scanCanonicalize (H12AffineFastState.compose env41963 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 2122812) := by decide +kernel

theorem selectedBound41963 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env41964 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,2122812,2122765,2147602,8193,16,2190618,82198,12556,2149428,75023,2212919,257,2188602,2196503,513]

theorem envBound41964 : H12AffineFastState.Bounded env41964 := by
  intro p hp
  have h : env41964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41963_41964 : H12AffineEnvironment.transform 21 2122812 env41963 = env41964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122812 env41963 == env41964) = true)

theorem identity41964 : scanCanonicalize (H12AffineFastState.compose env41964 (packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41964 : packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env41965 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16400,2340,1025,32769,2097152,2114864,2114817,2147602,269,16,2182166,82198,4096,2149428,66563,2212919,257,2180150,2196503,513]

theorem envBound41965 : H12AffineFastState.Bounded env41965 := by
  intro p hp
  have h : env41965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41964_41965 : H12AffineEnvironment.transform 12 268 env41964 = env41965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41964 == env41965) = true)

theorem identity41965 : scanCanonicalize (H12AffineFastState.compose env41965 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41965 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41966 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,65536,16400,2340,1025,1,2097152,2114864,2114817,2114834,269,16,2182166,82198,4096,2116660,66563,2180151,257,2180150,2163735,513]

theorem envBound41966 : H12AffineFastState.Bounded env41966 := by
  intro p hp
  have h : env41966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41965_41966 : H12AffineEnvironment.transform 14 0 env41965 = env41966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41965 == env41966) = true)

theorem identity41966 : scanCanonicalize (H12AffineFastState.compose env41966 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound41966 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41967 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,16400,2340,1025,1,2097152,2114864,2114817,2114834,269,16,2116880,16400,4096,2116660,1285,2114865,257,2114864,2098449,513]

theorem envBound41967 : H12AffineFastState.Bounded env41967 := by
  intro p hp
  have h : env41967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41966_41967 : H12AffineEnvironment.transform 15 262 env41966 = env41967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env41966 == env41967) = true)

theorem identity41967 : scanCanonicalize (H12AffineFastState.compose env41967 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound41967 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41968 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1572,4096,268,16384,0,262,16400,1792,1025,1,2097152,2114864,2114817,2114834,269,16,2114356,16400,4096,2114064,1285,2114865,257,2114864,2098449,513]

theorem envBound41968 : H12AffineFastState.Bounded env41968 := by
  intro p hp
  have h : env41968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41967_41968 : H12AffineEnvironment.transform 10 1572 env41967 = env41968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env41967 == env41968) = true)

theorem identity41968 : scanCanonicalize (H12AffineFastState.compose env41968 (packedSelected [4,7] rootPS)) = affineNative (2^(20+1) ^^^ 21009) := by decide +kernel

theorem selectedBound41968 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env41969 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1572,4096,268,16384,0,262,16400,1792,1025,1,21009,5921,5904,5891,269,16,4389,16400,4096,4097,1285,5920,257,5921,22272,513]

theorem envBound41969 : H12AffineFastState.Bounded env41969 := by
  intro p hp
  have h : env41969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41968_41969 : H12AffineEnvironment.transform 20 21009 env41968 = env41969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 21009 env41968 == env41969) = true)

theorem identity41969 : scanCanonicalize (H12AffineFastState.compose env41969 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41969 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env41970 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1572,4096,268,5156,0,262,5172,1792,1025,1,1589,5921,5904,5891,269,16,4389,5172,4096,4097,1285,5920,257,5921,804,513]

theorem envBound41970 : H12AffineFastState.Bounded env41970 := by
  intro p hp
  have h : env41970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41969_41970 : H12AffineEnvironment.transform 13 5156 env41969 = env41970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env41969 == env41970) = true)

theorem identity41970 : scanCanonicalize (H12AffineFastState.compose env41970 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41970 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41971 : List Nat := [2,4,8,16,32,17,9,256,512,272,820,4096,268,4404,0,262,4388,528,273,1,805,4657,4608,4627,269,16,4389,4388,4096,4097,21,4656,257,4657,804,513]

theorem envBound41971 : H12AffineFastState.Bounded env41971 := by
  intro p hp
  have h : env41971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41970_41971 : H12AffineEnvironment.transform 9 272 env41970 = env41971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41970 == env41971) = true)

theorem identity41971 : scanCanonicalize (H12AffineFastState.compose env41971 (packedSelected [1,3,10] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound41971 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env41972 : List Nat := [2,4,8,16,32,17,9,256,512,272,820,529,268,805,0,262,821,528,273,1,805,32,17,2,269,16,820,821,529,528,21,33,257,32,804,513]

theorem envBound41972 : H12AffineFastState.Bounded env41972 := by
  intro p hp
  have h : env41972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41971_41972 : H12AffineEnvironment.transform 11 529 env41971 = env41972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env41971 == env41972) = true)

theorem identity41972 : scanCanonicalize (H12AffineFastState.compose env41972 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41973 : List Nat := [2,4,8,16,32,17,9,5,512,21,561,529,9,544,0,3,560,528,20,1,544,32,17,2,8,16,561,560,529,528,21,33,4,32,545,513]

theorem envBound41973 : H12AffineFastState.Bounded env41973 := by
  intro p hp
  have h : env41973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41972_41973 : H12AffineEnvironment.transform 7 5 env41972 = env41973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41972 == env41973) = true)

theorem identity41973 : scanCanonicalize (H12AffineFastState.compose env41973 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41973 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41974 : List Nat := [2,4,8,16,0,17,9,5,512,21,529,529,9,512,0,3,528,528,20,1,512,0,17,2,8,16,529,528,529,528,21,1,4,0,513,513]

theorem envBound41974 : H12AffineFastState.Bounded env41974 := by
  intro p hp
  have h : env41974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41973_41974 : H12AffineEnvironment.transform 4 0 env41973 = env41974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41973 == env41974) = true)

theorem identity41974 : scanCanonicalize (H12AffineFastState.compose env41974 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41975 : List Nat := [2,4,8,16,0,17,9,5,0,21,17,17,9,0,0,3,16,16,20,1,0,0,17,2,8,16,17,16,17,16,21,1,4,0,1,1]

theorem envBound41975 : H12AffineFastState.Bounded env41975 := by
  intro p hp
  have h : env41975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41974_41975 : H12AffineEnvironment.transform 8 0 env41974 = env41975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41974 == env41975) = true)

theorem identity41975 : scanCanonicalize (H12AffineFastState.compose env41975 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41976 : List Nat := [2,4,8,11,0,10,9,5,0,14,10,10,9,0,0,3,11,11,15,1,0,0,10,2,8,11,10,11,10,11,14,1,4,0,1,1]

theorem envBound41976 : H12AffineFastState.Bounded env41976 := by
  intro p hp
  have h : env41976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41975_41976 : H12AffineEnvironment.transform 3 11 env41975 = env41976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41975 == env41976) = true)

def env41977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4262262,10816866,10507600,8683536,331126,15068206,257,2444611,2468974,272937]

theorem envBound41977 : H12AffineFastState.Bounded env41977 := by
  intro p hp
  have h : env41977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41925_41977 : H12AffineEnvironment.transform 16 16401 env41925 = env41977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41925 == env41977) = true)

def env41978 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685878,8193,17,4262182,10816818,10507520,8683536,331046,15068206,257,2444563,2468926,272937]

theorem envBound41978 : H12AffineFastState.Bounded env41978 := by
  intro p hp
  have h : env41978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41977_41978 : H12AffineEnvironment.transform 5 16 env41977 = env41978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41977 == env41978) = true)

def env41979 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685878,8193,17,4262182,10815490,10506288,8683536,329750,15067422,257,2443299,2468110,272937]

theorem envBound41979 : H12AffineFastState.Bounded env41979 := by
  intro p hp
  have h : env41979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41978_41979 : H12AffineEnvironment.transform 9 304 env41978 = env41979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env41978 == env41979) = true)

theorem identity41979 : scanCanonicalize (H12AffineFastState.compose env41979 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235580) := by decide +kernel

theorem selectedBound41979 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41980 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4235580,4466698,8193,17,4262182,6662462,6353164,4464940,329750,2443298,257,2443299,2468110,272937]

theorem envBound41980 : H12AffineFastState.Bounded env41980 := by
  intro p hp
  have h : env41980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41979_41980 : H12AffineEnvironment.transform 22 4235580 env41979 = env41980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235580 env41979 == env41980) = true)

def env41981 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,4194304,4235580,4194338,8193,17,4262182,6390038,6353164,4196612,73790,2187274,257,2187275,2195750,513]

theorem envBound41981 : H12AffineFastState.Bounded env41981 := by
  intro p hp
  have h : env41981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41980_41981 : H12AffineEnvironment.transform 17 10280 env41980 = env41981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41980 == env41981) = true)

theorem identity41981 : scanCanonicalize (H12AffineFastState.compose env41981 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound41981 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env41982 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,33030,16401,10280,305,32769,2097152,4194304,4235580,4194338,8193,17,4229152,6291472,6353164,4196612,41272,2154764,257,2154765,2097184,513]

theorem envBound41982 : H12AffineFastState.Bounded env41982 := by
  intro p hp
  have h : env41982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41981_41982 : H12AffineEnvironment.transform 15 33030 env41981 = env41982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env41981 == env41982) = true)

theorem identity41982 : scanCanonicalize (H12AffineFastState.compose env41982 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound41982 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41983 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,33030,16401,10280,305,32769,2097152,32,41244,2,8193,17,34816,2097200,2158892,2340,41272,2154764,257,2154765,2097184,513]

theorem envBound41983 : H12AffineFastState.Bounded env41983 := by
  intro p hp
  have h : env41983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41982_41983 : H12AffineEnvironment.transform 21 32 env41982 = env41983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env41982 == env41983) = true)

theorem identity41983 : scanCanonicalize (H12AffineFastState.compose env41983 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41983 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41984 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,269,16384,32768,33030,16401,2341,305,32769,2097152,32,32785,2,268,17,34816,2097200,2150433,2340,32821,2146305,257,2146304,2097184,513]

theorem envBound41984 : H12AffineFastState.Bounded env41984 := by
  intro p hp
  have h : env41984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41983_41984 : H12AffineEnvironment.transform 12 269 env41983 = env41984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41983 == env41984) = true)

theorem identity41984 : scanCanonicalize (H12AffineFastState.compose env41984 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41984 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env41985 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,269,16384,0,262,16401,2341,305,1,2097152,32,17,2,268,17,2048,2097200,2117665,2340,53,2113537,257,2113536,2097184,513]

theorem envBound41985 : H12AffineFastState.Bounded env41985 := by
  intro p hp
  have h : env41985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41984_41985 : H12AffineEnvironment.transform 14 0 env41984 = env41985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41984 == env41985) = true)

theorem identity41985 : scanCanonicalize (H12AffineFastState.compose env41985 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6933) := by decide +kernel

theorem selectedBound41985 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41986 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,269,6933,0,262,6916,2341,305,1,2097152,32,17,2,268,17,2048,2097200,2100020,2340,53,2104084,257,2104085,2097184,513]

theorem envBound41986 : H12AffineFastState.Bounded env41986 := by
  intro p hp
  have h : env41986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41985_41986 : H12AffineEnvironment.transform 13 6933 env41985 = env41986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6933 env41985 == env41986) = true)

def env41987 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,2097152,4194304,4235580,4194339,8193,17,4262182,6390039,6353164,4196613,73791,2187275,257,2187274,2195751,512]

theorem envBound41987 : H12AffineFastState.Bounded env41987 := by
  intro p hp
  have h : env41987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41980_41987 : H12AffineEnvironment.transform 17 10281 env41980 = env41987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41980 == env41987) = true)

theorem identity41987 : scanCanonicalize (H12AffineFastState.compose env41987 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 100386) := by decide +kernel

theorem selectedBound41987 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env41988 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,100386,4194304,4235580,4194339,8193,17,4262182,4196661,4290862,4196613,73791,59433,257,59432,2309,512]

theorem envBound41988 : H12AffineFastState.Bounded env41988 := by
  intro p hp
  have h : env41988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41987_41988 : H12AffineEnvironment.transform 20 100386 env41987 = env41988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 100386 env41987 == env41988) = true)

theorem identity41988 : scanCanonicalize (H12AffineFastState.compose env41988 (packedSelected [1,3,4,5,8,9,11,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 80191) := by decide +kernel

theorem selectedBound41988 : packedSelected [1,3,4,5,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env41989 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10281,305,32769,100386,80191,104451,80156,8193,17,12313,77834,16401,77882,73791,59433,257,59432,2309,512]

theorem envBound41989 : H12AffineFastState.Bounded env41989 := by
  intro p hp
  have h : env41989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41988_41989 : H12AffineEnvironment.transform 21 80191 env41988 = env41989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80191 env41988 == env41989) = true)

theorem identity41989 : scanCanonicalize (H12AffineFastState.compose env41989 (packedSelected [1,3,4,5,8,9,11,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 38930) := by decide +kernel

theorem selectedBound41989 : packedSelected [1,3,4,5,8,9,11,15,21] rootPS < 2^1333 := by decide +kernel

def env41990 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,38930,16401,10281,305,32769,4144,41261,17,41230,8193,17,12313,43032,16401,43048,47149,59433,257,59432,2309,512]

theorem envBound41990 : H12AffineFastState.Bounded env41990 := by
  intro p hp
  have h : env41990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41989_41990 : H12AffineEnvironment.transform 15 38930 env41989 = env41990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38930 env41989 == env41990) = true)

theorem identity41990 : scanCanonicalize (H12AffineFastState.compose env41990 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound41990 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env41991 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,2080,32768,38930,2097,10281,305,32769,4144,41261,17,41230,8193,17,12313,43032,2097,43048,47149,40969,257,40968,2309,512]

theorem envBound41991 : H12AffineFastState.Bounded env41991 := by
  intro p hp
  have h : env41991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41990_41991 : H12AffineEnvironment.transform 13 2080 env41990 = env41991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env41990 == env41991) = true)

theorem identity41991 : scanCanonicalize (H12AffineFastState.compose env41991 (packedSelected [0,2,3,5,6,7,10,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound41991 : packedSelected [0,2,3,5,6,7,10,14,18] rootPS < 2^1333 := by decide +kernel

def env41992 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,2080,293,6455,2097,10281,305,292,4144,8200,17,8235,8193,17,12313,10557,2097,10509,14600,8492,257,8493,2309,512]

theorem envBound41992 : H12AffineFastState.Bounded env41992 := by
  intro p hp
  have h : env41992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41991_41992 : H12AffineEnvironment.transform 14 293 env41991 = env41992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env41991 == env41992) = true)

theorem identity41992 : scanCanonicalize (H12AffineFastState.compose env41992 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound41992 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41993 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,6429,2080,293,6455,2097,4404,305,292,4144,6421,17,6454,6428,17,2308,4128,2097,4112,21,6193,257,6192,2309,512]

theorem envBound41993 : H12AffineFastState.Bounded env41993 := by
  intro p hp
  have h : env41993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41992_41993 : H12AffineEnvironment.transform 12 6429 env41992 = env41993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env41992 == env41993) = true)

theorem identity41993 : scanCanonicalize (H12AffineFastState.compose env41993 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41993 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env41994 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,4096,6169,2080,33,6195,2097,4144,53,32,4144,6161,17,6194,6168,17,2048,4128,2097,4112,21,6193,5,6192,2049,512]

theorem envBound41994 : H12AffineFastState.Bounded env41994 := by
  intro p hp
  have h : env41994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41993_41994 : H12AffineEnvironment.transform 7 4 env41993 = env41994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41993 == env41994) = true)

def env41995 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685878,8193,17,4262182,10815491,10506289,8683536,329751,15067423,257,2443298,2468111,272937]

theorem envBound41995 : H12AffineFastState.Bounded env41995 := by
  intro p hp
  have h : env41995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41978_41995 : H12AffineEnvironment.transform 9 305 env41978 = env41995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env41978 == env41995) = true)

theorem identity41995 : scanCanonicalize (H12AffineFastState.compose env41995 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4491540) := by decide +kernel

theorem selectedBound41995 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41996 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4491540,4194338,8193,17,4262182,6390039,6609189,4196612,329751,2187275,257,2443298,2468111,272937]

theorem envBound41996 : H12AffineFastState.Bounded env41996 := by
  intro p hp
  have h : env41996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41995_41996 : H12AffineEnvironment.transform 22 4491540 env41995 = env41996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4491540 env41995 == env41996) = true)

theorem identity41996 : scanCanonicalize (H12AffineFastState.compose env41996 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41996 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env41997 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4235580,4194338,8193,17,4262182,6390039,6353165,4196612,73791,2187275,257,2187274,2195751,513]

theorem envBound41997 : H12AffineFastState.Bounded env41997 := by
  intro p hp
  have h : env41997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41996_41997 : H12AffineEnvironment.transform 17 10280 env41996 = env41997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41996 == env41997) = true)

theorem identity41997 : scanCanonicalize (H12AffineFastState.compose env41997 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound41997 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env41998 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,33030,16401,10280,304,32769,2097152,4194304,4235580,4194338,8193,17,4229152,6291473,6353165,4196612,41273,2154765,257,2154764,2097185,513]

theorem envBound41998 : H12AffineFastState.Bounded env41998 := by
  intro p hp
  have h : env41998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41997_41998 : H12AffineEnvironment.transform 15 33030 env41997 = env41998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env41997 == env41998) = true)

theorem identity41998 : scanCanonicalize (H12AffineFastState.compose env41998 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound41998 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41999 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,33030,16401,10280,304,32769,2097152,32,41244,2,8193,17,34816,2097201,2158893,2340,41273,2154765,257,2154764,2097185,513]

theorem envBound41999 : H12AffineFastState.Bounded env41999 := by
  intro p hp
  have h : env41999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41998_41999 : H12AffineEnvironment.transform 21 32 env41998 = env41999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env41998 == env41999) = true)

theorem identity41999 : scanCanonicalize (H12AffineFastState.compose env41999 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41999 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42000 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,32768,33030,16401,2341,304,32769,2097152,32,32785,2,268,17,34816,2097201,2150432,2340,32820,2146304,257,2146305,2097185,513]

theorem envBound42000 : H12AffineFastState.Bounded env42000 := by
  intro p hp
  have h : env42000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41999_42000 : H12AffineEnvironment.transform 12 269 env41999 = env42000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41999 == env42000) = true)

theorem identity42000 : scanCanonicalize (H12AffineFastState.compose env42000 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42000 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42001 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,16384,0,262,16401,2341,304,1,2097152,32,17,2,268,17,2048,2097201,2117664,2340,52,2113536,257,2113537,2097185,513]

theorem envBound42001 : H12AffineFastState.Bounded env42001 := by
  intro p hp
  have h : env42001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42000_42001 : H12AffineEnvironment.transform 14 0 env42000 = env42001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42000 == env42001) = true)

theorem identity42001 : scanCanonicalize (H12AffineFastState.compose env42001 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6932) := by decide +kernel

theorem selectedBound42001 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42002 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,6932,0,262,6917,2341,304,1,2097152,32,17,2,268,17,2048,2097201,2100020,2340,52,2104084,257,2104085,2097185,513]

theorem envBound42002 : H12AffineFastState.Bounded env42002 := by
  intro p hp
  have h : env42002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42001_42002 : H12AffineEnvironment.transform 13 6932 env42001 = env42002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6932 env42001 == env42002) = true)

def env42003 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685879,8193,16,4262183,10816819,10507521,8683536,331047,15068206,257,2444562,2468927,272937]

theorem envBound42003 : H12AffineFastState.Bounded env42003 := by
  intro p hp
  have h : env42003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41977_42003 : H12AffineEnvironment.transform 5 17 env41977 = env42003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41977 == env42003) = true)

def env42004 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685879,8193,16,4262183,10815491,10506289,8683536,329751,15067422,257,2443298,2468111,272937]

theorem envBound42004 : H12AffineFastState.Bounded env42004 := by
  intro p hp
  have h : env42004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42003_42004 : H12AffineEnvironment.transform 9 304 env42003 = env42004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env42003 == env42004) = true)

theorem identity42004 : scanCanonicalize (H12AffineFastState.compose env42004 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4292918) := by decide +kernel

theorem selectedBound42004 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42005 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4292918,4524033,8193,16,4262183,6588725,6410503,4522278,329751,2385960,257,2443298,2468111,272937]

theorem envBound42005 : H12AffineFastState.Bounded env42005 := by
  intro p hp
  have h : env42005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42004_42005 : H12AffineEnvironment.transform 22 4292918 env42004 = env42005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292918 env42004 == env42005) = true)

theorem identity42005 : scanCanonicalize (H12AffineFastState.compose env42005 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42005 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42006 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,4194304,4292918,4268073,8193,16,4262183,6332701,6410503,4270350,73791,2113536,257,2187274,2195751,513]

theorem envBound42006 : H12AffineFastState.Bounded env42006 := by
  intro p hp
  have h : env42006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42005_42006 : H12AffineEnvironment.transform 17 10280 env42005 = env42006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42005 == env42006) = true)

theorem identity42006 : scanCanonicalize (H12AffineFastState.compose env42006 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound42006 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env42007 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,10280,305,32769,2097152,41260,73754,98565,8193,16,108555,2097201,2191403,100386,73791,2113536,257,2187274,2195751,513]

theorem envBound42007 : H12AffineFastState.Bounded env42007 := by
  intro p hp
  have h : env42007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42006_42007 : H12AffineEnvironment.transform 21 41260 env42006 = env42007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env42006 == env42007) = true)

theorem identity42007 : scanCanonicalize (H12AffineFastState.compose env42007 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42007 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42008 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,8203,16401,10280,305,32769,2097152,41260,17,41230,8193,16,34816,2097201,2117664,43049,52,2113536,257,2113537,2138412,513]

theorem envBound42008 : H12AffineFastState.Bounded env42008 := by
  intro p hp
  have h : env42008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42007_42008 : H12AffineEnvironment.transform 15 8203 env42007 = env42008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42007 == env42008) = true)

theorem identity42008 : scanCanonicalize (H12AffineFastState.compose env42008 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42008 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42009 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,0,8203,16401,10280,305,1,2097152,8492,17,8462,8193,16,2048,2097201,2117664,10281,52,2113536,257,2113537,2105644,513]

theorem envBound42009 : H12AffineFastState.Bounded env42009 := by
  intro p hp
  have h : env42009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42008_42009 : H12AffineEnvironment.transform 14 0 env42008 = env42009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42008 == env42009) = true)

theorem identity42009 : scanCanonicalize (H12AffineFastState.compose env42009 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42009 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42010 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,268,16384,0,263,16401,2340,305,1,2097152,32,17,2,269,16,2048,2097201,2117664,2341,52,2113536,257,2113537,2097184,513]

theorem envBound42010 : H12AffineFastState.Bounded env42010 := by
  intro p hp
  have h : env42010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42009_42010 : H12AffineEnvironment.transform 12 268 env42009 = env42010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42009 == env42010) = true)

theorem identity42010 : scanCanonicalize (H12AffineFastState.compose env42010 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6705) := by decide +kernel

theorem selectedBound42010 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42011 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,268,6705,0,263,6688,2340,305,1,2097152,32,17,2,269,16,2048,2097201,2099729,2341,52,2103857,257,2103856,2097184,513]

theorem envBound42011 : H12AffineFastState.Bounded env42011 := by
  intro p hp
  have h : env42011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42010_42011 : H12AffineEnvironment.transform 13 6705 env42010 = env42011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6705 env42010 == env42011) = true)

def env42012 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,8388608,8685879,8193,16,4262183,10815490,10506288,8683536,329750,15067423,257,2443299,2468110,272937]

theorem envBound42012 : H12AffineFastState.Bounded env42012 := by
  intro p hp
  have h : env42012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42003_42012 : H12AffineEnvironment.transform 9 305 env42003 = env42012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env42003 == env42012) = true)

theorem identity42012 : scanCanonicalize (H12AffineFastState.compose env42012 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4565278) := by decide +kernel

theorem selectedBound42012 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42013 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,262144,304,32769,2097152,4194304,4565278,4268073,8193,16,4262183,6332700,6682926,4270350,329750,2113537,257,2443299,2468110,272937]

theorem envBound42013 : H12AffineFastState.Bounded env42013 := by
  intro p hp
  have h : env42013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42012_42013 : H12AffineEnvironment.transform 22 4565278 env42012 = env42013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4565278 env42012 == env42013) = true)

def env42014 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,4194304,4292918,4268073,8193,16,4262183,6332700,6410502,4270350,73790,2113537,257,2187275,2195750,513]

theorem envBound42014 : H12AffineFastState.Bounded env42014 := by
  intro p hp
  have h : env42014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42013_42014 : H12AffineEnvironment.transform 17 10280 env42013 = env42014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42013 == env42014) = true)

theorem identity42014 : scanCanonicalize (H12AffineFastState.compose env42014 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound42014 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env42015 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10280,304,32769,2097152,41260,73754,98565,8193,16,108555,2097200,2191402,100386,73790,2113537,257,2187275,2195750,513]

theorem envBound42015 : H12AffineFastState.Bounded env42015 := by
  intro p hp
  have h : env42015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42014_42015 : H12AffineEnvironment.transform 21 41260 env42014 = env42015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env42014 == env42015) = true)

theorem identity42015 : scanCanonicalize (H12AffineFastState.compose env42015 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42015 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42016 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,8203,16401,10280,304,32769,2097152,41260,17,41230,8193,16,34816,2097200,2117665,43049,53,2113537,257,2113536,2138413,513]

theorem envBound42016 : H12AffineFastState.Bounded env42016 := by
  intro p hp
  have h : env42016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42015_42016 : H12AffineEnvironment.transform 15 8203 env42015 = env42016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42015 == env42016) = true)

theorem identity42016 : scanCanonicalize (H12AffineFastState.compose env42016 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42016 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42017 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,0,8203,16401,10280,304,1,2097152,8492,17,8462,8193,16,2048,2097200,2117665,10281,53,2113537,257,2113536,2105645,513]

theorem envBound42017 : H12AffineFastState.Bounded env42017 := by
  intro p hp
  have h : env42017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42016_42017 : H12AffineEnvironment.transform 14 0 env42016 = env42017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42016 == env42017) = true)

theorem identity42017 : scanCanonicalize (H12AffineFastState.compose env42017 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42017 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42018 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,0,263,16401,2340,304,1,2097152,32,17,2,269,16,2048,2097200,2117665,2341,53,2113537,257,2113536,2097185,513]

theorem envBound42018 : H12AffineFastState.Bounded env42018 := by
  intro p hp
  have h : env42018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42017_42018 : H12AffineEnvironment.transform 12 268 env42017 = env42018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42017 == env42018) = true)

theorem identity42018 : scanCanonicalize (H12AffineFastState.compose env42018 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6704) := by decide +kernel

theorem selectedBound42018 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42019 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,6704,0,263,6689,2340,304,1,2097152,32,17,2,269,16,2048,2097200,2099729,2341,53,2103857,257,2103856,2097185,513]

theorem envBound42019 : H12AffineFastState.Bounded env42019 := by
  intro p hp
  have h : env42019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42018_42019 : H12AffineEnvironment.transform 13 6704 env42018 = env42019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6704 env42018 == env42019) = true)

def env42020 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10281,304,32769,2097152,4194304,4292919,4268073,8193,16,4262183,6332700,6410503,4270350,73791,2113537,257,2187274,2195751,512]

theorem envBound42020 : H12AffineFastState.Bounded env42020 := by
  intro p hp
  have h : env42020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42013_42020 : H12AffineEnvironment.transform 17 10281 env42013 = env42020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42013 == env42020) = true)

theorem identity42020 : scanCanonicalize (H12AffineFastState.compose env42020 (packedSelected [0,7,16] rootPS)) = affineNative (2^(20+1) ^^^ 110618) := by decide +kernel

theorem selectedBound42020 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env42021 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,16401,10281,304,32769,110618,4194304,4292919,4268073,8193,16,4262183,4264198,4219165,4270350,73791,127003,257,53264,12605,512]

theorem envBound42021 : H12AffineFastState.Bounded env42021 := by
  intro p hp
  have h : env42021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42020_42021 : H12AffineEnvironment.transform 20 110618 env42020 = env42021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110618 env42020 == env42021) = true)

theorem identity42021 : scanCanonicalize (H12AffineFastState.compose env42021 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(14+1) ^^^ 14621) := by decide +kernel

theorem selectedBound42021 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env42022 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,14621,65536,16401,10281,304,14620,67847,4194304,4274218,4268073,8193,16,4262183,4264198,4219165,4270350,73791,84230,257,26893,12605,512]

theorem envBound42022 : H12AffineFastState.Bounded env42022 := by
  intro p hp
  have h : env42022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42021_42022 : H12AffineEnvironment.transform 14 14621 env42021 = env42022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14621 env42021 == env42022) = true)

theorem identity42022 : scanCanonicalize (H12AffineFastState.compose env42022 (packedSelected [1,3,5,8,11,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound42022 : packedSelected [1,3,5,8,11,14,15,20] rootPS < 2^1333 := by decide +kernel

def env42023 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,2341,14621,65536,2356,10281,304,14620,67847,4194304,4274218,4268073,8193,16,4262183,4264198,4204600,4270350,73791,65571,257,8232,12605,512]

theorem envBound42023 : H12AffineFastState.Bounded env42023 := by
  intro p hp
  have h : env42023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42022_42023 : H12AffineEnvironment.transform 13 2341 env42022 = env42023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env42022 == env42023) = true)

theorem identity42023 : scanCanonicalize (H12AffineFastState.compose env42023 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 79931) := by decide +kernel

theorem selectedBound42023 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42024 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,2341,14621,65536,2356,10281,304,14620,67847,79931,17,6162,8193,16,12572,10557,69635,4405,73791,65571,257,8232,12605,512]

theorem envBound42024 : H12AffineFastState.Bounded env42024 := by
  intro p hp
  have h : env42024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42023_42024 : H12AffineEnvironment.transform 21 79931 env42023 = env42024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 79931 env42023 == env42024) = true)

theorem identity42024 : scanCanonicalize (H12AffineFastState.compose env42024 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 6461) := by decide +kernel

theorem selectedBound42024 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42025 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,6461,2341,32,65536,2356,4372,304,33,67847,65798,17,6162,6460,16,2081,4096,69635,4405,71938,65571,257,6421,2048,512]

theorem envBound42025 : H12AffineFastState.Bounded env42025 := by
  intro p hp
  have h : env42025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42024_42025 : H12AffineEnvironment.transform 12 6461 env42024 = env42025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6461 env42024 == env42025) = true)

theorem identity42025 : scanCanonicalize (H12AffineFastState.compose env42025 (packedSelected [12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound42025 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env42026 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,6461,2341,32,35,2356,4372,304,33,2340,293,17,6162,6460,16,2081,4096,4128,4405,6433,0,257,6421,2048,512]

theorem envBound42026 : H12AffineFastState.Bounded env42026 := by
  intro p hp
  have h : env42026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42025_42026 : H12AffineEnvironment.transform 15 35 env42025 = env42026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env42025 == env42026) = true)

theorem identity42026 : scanCanonicalize (H12AffineFastState.compose env42026 (packedSelected [4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42026 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env42027 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,6200,2080,32,35,2097,4113,53,33,2081,32,17,6162,6201,16,2081,4096,4128,4144,6180,0,4,6160,2048,512]

theorem envBound42027 : H12AffineFastState.Bounded env42027 := by
  intro p hp
  have h : env42027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42026_42027 : H12AffineEnvironment.transform 7 5 env42026 = env42027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42026 == env42027) = true)

theorem identity42027 : scanCanonicalize (H12AffineFastState.compose env42027 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound42027 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42028 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2065,41,2080,32,35,2097,2048,53,33,2081,32,17,3,40,16,2081,2065,2097,2081,53,0,4,1,2048,512]

theorem envBound42028 : H12AffineFastState.Bounded env42028 := by
  intro p hp
  have h : env42028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42027_42028 : H12AffineEnvironment.transform 11 2065 env42027 = env42028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env42027 == env42028) = true)

theorem identity42028 : scanCanonicalize (H12AffineFastState.compose env42028 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42028 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42029 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2065,8,2049,1,2,2064,2048,20,0,2048,1,17,3,9,16,2048,2065,2064,2048,20,0,4,1,2048,512]

theorem envBound42029 : H12AffineFastState.Bounded env42029 := by
  intro p hp
  have h : env42029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42028_42029 : H12AffineEnvironment.transform 4 1 env42028 = env42029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42028 == env42029) = true)

theorem identity42029 : scanCanonicalize (H12AffineFastState.compose env42029 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42030 : List Nat := [2,4,8,16,1,17,9,5,0,21,2048,2065,8,2049,1,2,2064,2048,20,0,2048,1,17,3,9,16,2048,2065,2064,2048,20,0,4,1,2048,0]

theorem envBound42030 : H12AffineFastState.Bounded env42030 := by
  intro p hp
  have h : env42030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42029_42030 : H12AffineEnvironment.transform 8 0 env42029 = env42030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42029 == env42030) = true)

theorem identity42030 : scanCanonicalize (H12AffineFastState.compose env42030 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound42030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42031 : List Nat := [2,4,8,16,1,17,9,5,0,21,31,14,8,30,1,2,15,31,20,0,31,1,17,3,9,16,31,14,15,31,20,0,4,1,31,0]

theorem envBound42031 : H12AffineFastState.Bounded env42031 := by
  intro p hp
  have h : env42031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42030_42031 : H12AffineEnvironment.transform 10 31 env42030 = env42031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env42030 == env42031) = true)

def leafEnv42031 : List Nat := [2,4,8,16,1,17,9,5,0,21,31,14,8,30,1,2,15,31,20,0,31,1,17,3,21,9,1,16,31,14,15,31,20,0,4,1,5,3,31,0,1,30,0]

def active42031 : List Nat := [0,1,2,3]

def tree42031 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42031 : H12WitnessSearch.Good tree42031 := H12GlobalWitnessIndex.good

theorem leafIdentity42031 : H12AffineFastState.composeSystem env42031 rootObs = leafEnv42031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42031 rootObs == leafEnv42031) = true)

theorem terminalChecked42031 : H12PackedTerminal.terminalCheckFast leafEnv42031 active42031 tree42031 = true := by decide +kernel

def env42032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound42032 : H12AffineFastState.Bounded env42032 := by
  intro p hp
  have h : env42032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41741_42032 : H12AffineEnvironment.transform 26 30393345 env41741 = env42032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env41741 == env42032) = true)

def env42033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound42033 : H12AffineFastState.Bounded env42033 := by
  intro p hp
  have h : env42033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42032_42033 : H12AffineEnvironment.transform 18 1024 env42032 = env42033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env42032 == env42033) = true)

theorem identity42033 : scanCanonicalize (H12AffineFastState.compose env42033 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493615) := by decide +kernel

theorem selectedBound42033 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493615,8328,65,14797998,493603,10507600,8830977,10979519,4680047,256,8898563,8858023,10923880]

theorem envBound42034 : H12AffineFastState.Bounded env42034 := by
  intro p hp
  have h : env42034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42033_42034 : H12AffineEnvironment.transform 23 2493615 env42033 = env42034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493615 env42033 == env42034) = true)

def env42035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797998,115151,10507600,8423917,10600787,4268163,256,8487407,8478795,10544772]

theorem envBound42035 : H12AffineFastState.Bounded env42035 := by
  intro p hp
  have h : env42035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42034_42035 : H12AffineEnvironment.transform 17 149996 env42034 = env42035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env42034 == env42035) = true)

def env42036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,8388608,21763,8328,65,12705006,115151,8406288,8423917,8507667,4268163,256,8487407,8478795,8451780]

theorem envBound42036 : H12AffineFastState.Bounded env42036 := by
  intro p hp
  have h : env42036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42035_42036 : H12AffineEnvironment.transform 20 4160 env42035 = env42036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42035 == env42036) = true)

def env42037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,16,21763,8328,65,4316414,115151,17664,35325,119043,4268163,256,98815,90203,63188]

theorem envBound42037 : H12AffineFastState.Bounded env42037 := by
  intro p hp
  have h : env42037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42036_42037 : H12AffineEnvironment.transform 22 16 env42036 = env42037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42036 == env42037) = true)

theorem identity42037 : scanCanonicalize (H12AffineFastState.compose env42037 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound42037 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149996,1024,32769,4160,4194304,16,21763,8328,65,4196384,5393,17664,35325,1501,4256861,256,21793,46213,63188]

theorem envBound42038 : H12AffineFastState.Bounded env42038 := by
  intro p hp
  have h : env42038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42037_42038 : H12AffineEnvironment.transform 15 54494 env42037 = env42038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env42037 == env42038) = true)

def env42039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149860,1024,32769,4160,4194304,16,21763,8192,65,4196384,5393,17664,35189,1365,4256861,256,21793,46093,63068]

theorem envBound42039 : H12AffineFastState.Bounded env42039 := by
  intro p hp
  have h : env42039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42038_42039 : H12AffineEnvironment.transform 6 8 env42038 = env42039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42038 == env42039) = true)

theorem identity42039 : scanCanonicalize (H12AffineFastState.compose env42039 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound42039 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,35188,1024,32769,4160,4194304,16,21763,8192,65,4196384,5393,17664,35189,1365,4256861,256,21793,46093,63068]

theorem envBound42040 : H12AffineFastState.Bounded env42040 := by
  intro p hp
  have h : env42040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42039_42040 : H12AffineEnvironment.transform 16 49168 env42039 = env42040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env42039 == env42040) = true)

theorem identity42040 : scanCanonicalize (H12AffineFastState.compose env42040 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42040 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,54358,49168,35188,1024,32769,4160,4194304,16,21763,268,65,4196384,5393,17664,35189,1365,4248913,256,21793,38145,55120]

theorem envBound42041 : H12AffineFastState.Bounded env42041 := by
  intro p hp
  have h : env42041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42040_42041 : H12AffineEnvironment.transform 12 268 env42040 = env42041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42040 == env42041) = true)

theorem identity42041 : scanCanonicalize (H12AffineFastState.compose env42041 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound42041 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,54358,49168,35188,1024,32769,4160,33,16,21763,268,65,2049,5393,17664,35189,1365,54640,256,21793,38145,55120]

theorem envBound42042 : H12AffineFastState.Bounded env42042 := by
  intro p hp
  have h : env42042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42041_42042 : H12AffineEnvironment.transform 21 33 env42041 = env42042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42041 == env42042) = true)

theorem identity42042 : scanCanonicalize (H12AffineFastState.compose env42042 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound42042 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env42043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,32768,32882,37940,35188,1024,32769,4160,33,16,295,268,65,2049,5393,4388,35189,1365,33108,256,261,38145,33652]

theorem envBound42043 : H12AffineFastState.Bounded env42043 := by
  intro p hp
  have h : env42043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42042_42043 : H12AffineEnvironment.transform 13 5156 env42042 = env42043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env42042 == env42043) = true)

theorem identity42043 : scanCanonicalize (H12AffineFastState.compose env42043 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42043 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env42044 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5156,32768,32882,37940,34816,1024,32769,4160,33,16,83,120,65,2049,5221,4176,34817,1057,32800,116,113,38005,33280]

theorem envBound42044 : H12AffineFastState.Bounded env42044 := by
  intro p hp
  have h : env42044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42043_42044 : H12AffineEnvironment.transform 7 116 env42043 = env42044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42043 == env42044) = true)

theorem identity42044 : scanCanonicalize (H12AffineFastState.compose env42044 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42044 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env42045 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5156,0,114,5172,2048,1024,1,4160,33,16,83,120,65,2049,5221,4176,2049,1057,32,116,113,5237,512]

theorem envBound42045 : H12AffineFastState.Bounded env42045 := by
  intro p hp
  have h : env42045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42044_42045 : H12AffineEnvironment.transform 14 0 env42044 = env42045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42044 == env42045) = true)

theorem identity42045 : scanCanonicalize (H12AffineFastState.compose env42045 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound42045 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42046 : List Nat := [2,4,8,16,32,64,8,116,512,1024,554,4096,120,5156,0,114,5172,554,1024,1,4160,33,16,83,120,65,555,5221,4176,555,1057,32,116,113,5237,512]

theorem envBound42046 : H12AffineFastState.Bounded env42046 := by
  intro p hp
  have h : env42046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42045_42046 : H12AffineEnvironment.transform 10 554 env42045 = env42046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env42045 == env42046) = true)

theorem identity42046 : scanCanonicalize (H12AffineFastState.compose env42046 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound42046 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42047 : List Nat := [2,4,8,16,32,49,8,5,512,1024,554,4096,9,5156,0,3,5172,554,1024,1,4145,33,16,34,9,48,555,5140,4129,555,1057,32,5,0,5124,512]

theorem envBound42047 : H12AffineFastState.Bounded env42047 := by
  intro p hp
  have h : env42047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42046_42047 : H12AffineEnvironment.transform 5 49 env42046 = env42047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env42046 == env42047) = true)

theorem identity42047 : scanCanonicalize (H12AffineFastState.compose env42047 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42047 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42048 : List Nat := [2,4,8,16,1,16,8,5,512,1024,523,4096,9,5125,0,3,5141,523,1024,1,4112,0,16,3,9,17,522,5140,4096,522,1024,1,5,0,5124,512]

theorem envBound42048 : H12AffineFastState.Bounded env42048 := by
  intro p hp
  have h : env42048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42047_42048 : H12AffineEnvironment.transform 4 1 env42047 = env42048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42047 == env42048) = true)

theorem identity42048 : scanCanonicalize (H12AffineFastState.compose env42048 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42048 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42049 : List Nat := [2,4,8,16,1,16,8,5,1,1024,10,4096,9,5125,0,3,5141,10,1024,1,4112,0,16,3,9,17,11,5140,4096,11,1024,1,5,0,5124,1]

theorem envBound42049 : H12AffineFastState.Bounded env42049 := by
  intro p hp
  have h : env42049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42048_42049 : H12AffineEnvironment.transform 8 1 env42048 = env42049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42048 == env42049) = true)

theorem identity42049 : scanCanonicalize (H12AffineFastState.compose env42049 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound42049 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42050 : List Nat := [2,4,8,16,1,16,8,5,1,1024,10,1044,9,17,0,3,1,10,1024,1,1028,0,16,3,9,17,11,0,1044,11,1024,1,5,0,16,1]

theorem envBound42050 : H12AffineFastState.Bounded env42050 := by
  intro p hp
  have h : env42050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42049_42050 : H12AffineEnvironment.transform 11 1044 env42049 = env42050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env42049 == env42050) = true)

def env42051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149861,1024,32769,4160,4194304,16,21763,8193,65,4196384,5393,17664,35188,1364,4256861,256,21793,46092,63069]

theorem envBound42051 : H12AffineFastState.Bounded env42051 := by
  intro p hp
  have h : env42051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42038_42051 : H12AffineEnvironment.transform 6 9 env42038 = env42051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42038 == env42051) = true)

theorem identity42051 : scanCanonicalize (H12AffineFastState.compose env42051 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound42051 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,10280,1024,32769,4160,4194304,16,21763,8193,65,4196384,5393,17664,35188,1364,4256861,256,21793,46092,63069]

theorem envBound42052 : H12AffineFastState.Bounded env42052 := by
  intro p hp
  have h : env42052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42051_42052 : H12AffineEnvironment.transform 16 24909 env42051 = env42052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env42051 == env42052) = true)

theorem identity42052 : scanCanonicalize (H12AffineFastState.compose env42052 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound42052 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24909,10280,1024,29789,4160,4194304,16,21763,8193,65,4196384,5393,17664,32040,1364,4194305,256,21793,16464,513]

theorem envBound42053 : H12AffineFastState.Bounded env42053 := by
  intro p hp
  have h : env42053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42052_42053 : H12AffineEnvironment.transform 14 29788 env42052 = env42053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env42052 == env42053) = true)

theorem identity42053 : scanCanonicalize (H12AffineFastState.compose env42053 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound42053 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24909,10280,1024,29789,4160,33,16,21763,8193,65,2049,5393,17664,32040,1364,32,256,21793,16464,513]

theorem envBound42054 : H12AffineFastState.Bounded env42054 := by
  intro p hp
  have h : env42054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42053_42054 : H12AffineEnvironment.transform 21 33 env42053 = env42054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42053 == env42054) = true)

theorem identity42054 : scanCanonicalize (H12AffineFastState.compose env42054 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42054 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,262,16448,2341,1024,21840,4160,33,16,21763,268,65,2049,5393,17664,23589,1364,32,256,21793,16464,513]

theorem envBound42055 : H12AffineFastState.Bounded env42055 := by
  intro p hp
  have h : env42055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42054_42055 : H12AffineEnvironment.transform 12 269 env42054 = env42055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42054 == env42055) = true)

theorem identity42055 : scanCanonicalize (H12AffineFastState.compose env42055 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42055 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env42056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,262,5441,2341,1024,81,4160,33,16,2,268,65,2049,5393,4097,2340,1364,32,256,32,5457,513]

theorem envBound42056 : H12AffineFastState.Bounded env42056 := by
  intro p hp
  have h : env42056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42055_42056 : H12AffineEnvironment.transform 13 5377 env42055 = env42056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42055 == env42056) = true)

theorem identity42056 : scanCanonicalize (H12AffineFastState.compose env42056 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound42056 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2560,269,3841,80,262,3905,2341,1024,81,2624,33,16,2,268,65,2049,3857,2561,2340,1364,32,256,32,3921,513]

theorem envBound42057 : H12AffineFastState.Bounded env42057 := by
  intro p hp
  have h : env42057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42056_42057 : H12AffineEnvironment.transform 11 2560 env42056 = env42057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env42056 == env42057) = true)

theorem identity42057 : scanCanonicalize (H12AffineFastState.compose env42057 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42057 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42058 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2560,269,3841,1,262,3856,2341,1024,0,2577,33,16,2,268,16,2049,3857,2561,2340,1285,32,256,32,3840,513]

theorem envBound42058 : H12AffineFastState.Bounded env42058 := by
  intro p hp
  have h : env42058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42057_42058 : H12AffineEnvironment.transform 5 17 env42057 = env42058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42057 == env42058) = true)

theorem identity42058 : scanCanonicalize (H12AffineFastState.compose env42058 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound42058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42059 : List Nat := [2,4,8,16,32,17,9,256,512,1024,561,49,269,1328,1,262,1313,788,1024,0,32,33,16,2,268,16,560,1312,48,789,1285,32,256,32,1329,513]

theorem envBound42059 : H12AffineFastState.Bounded env42059 := by
  intro p hp
  have h : env42059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42058_42059 : H12AffineEnvironment.transform 10 561 env42058 = env42059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env42058 == env42059) = true)

def env42060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,17,21763,8328,65,4316415,115151,17665,35324,119042,4268163,256,98814,90202,63189]

theorem envBound42060 : H12AffineFastState.Bounded env42060 := by
  intro p hp
  have h : env42060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42036_42060 : H12AffineEnvironment.transform 22 17 env42036 = env42060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42036 == env42060) = true)

theorem identity42060 : scanCanonicalize (H12AffineFastState.compose env42060 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213350) := by decide +kernel

theorem selectedBound42060 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,213350,17,21763,8328,65,171417,115151,17665,35324,119042,156133,256,98814,90202,63189]

theorem envBound42061 : H12AffineFastState.Bounded env42061 := by
  intro p hp
  have h : env42061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42060_42061 : H12AffineEnvironment.transform 21 213350 env42060 = env42061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213350 env42060 == env42061) = true)

def env42062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,213350,17,21763,8192,65,171281,115015,17665,35188,119042,156013,256,98678,90202,63069]

theorem envBound42062 : H12AffineFastState.Bounded env42062 := by
  intro p hp
  have h : env42062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42061_42062 : H12AffineEnvironment.transform 6 8 env42061 = env42062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42061 == env42062) = true)

theorem identity42062 : scanCanonicalize (H12AffineFastState.compose env42062 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42062 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4160,213350,17,21763,8192,65,146508,90138,17665,10281,94303,156013,256,73771,90202,22272]

theorem envBound42063 : H12AffineFastState.Bounded env42063 := by
  intro p hp
  have h : env42063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42062_42063 : H12AffineEnvironment.transform 14 8541 env42062 = env42063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42062 == env42063) = true)

theorem identity42063 : scanCanonicalize (H12AffineFastState.compose env42063 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42063 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,76159,1024,8540,4160,8573,17,21763,8192,65,89175,90138,17665,10281,94303,65910,256,73771,90202,22272]

theorem envBound42064 : H12AffineFastState.Bounded env42064 := by
  intro p hp
  have h : env42064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42063_42064 : H12AffineEnvironment.transform 16 90139 env42063 = env42064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42063 == env42064) = true)

theorem identity42064 : scanCanonicalize (H12AffineFastState.compose env42064 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound42064 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,24909,10281,1024,8540,4160,8573,17,21763,8192,65,23809,24908,17665,10281,28937,32,256,8573,24844,22272]

theorem envBound42065 : H12AffineFastState.Bounded env42065 := by
  intro p hp
  have h : env42065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42064_42065 : H12AffineEnvironment.transform 15 342 env42064 = env42065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env42064 == env42065) = true)

theorem identity42065 : scanCanonicalize (H12AffineFastState.compose env42065 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound42065 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,342,17665,3173,1024,1296,4160,1329,17,21763,1100,65,23809,17664,17665,3173,21829,32,256,1329,17728,22272]

theorem envBound42066 : H12AffineFastState.Bounded env42066 := by
  intro p hp
  have h : env42066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42065_42066 : H12AffineEnvironment.transform 12 1100 env42065 = env42066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env42065 == env42066) = true)

theorem identity42066 : scanCanonicalize (H12AffineFastState.compose env42066 (packedSelected [1,8,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42066 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env42067 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,16384,1,342,16401,2421,272,0,4160,33,17,20499,348,65,22545,16400,16401,2421,20565,32,256,33,16464,21008]

theorem envBound42067 : H12AffineFastState.Bounded env42067 := by
  intro p hp
  have h : env42067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42066_42067 : H12AffineEnvironment.transform 9 272 env42066 = env42067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42066 == env42067) = true)

theorem identity42067 : scanCanonicalize (H12AffineFastState.compose env42067 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound42067 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42068 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4405,1,342,4388,2421,272,0,4160,33,17,294,348,65,2340,4389,4388,2421,352,32,256,33,4453,805]

theorem envBound42068 : H12AffineFastState.Bounded env42068 := by
  intro p hp
  have h : env42068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42067_42068 : H12AffineEnvironment.transform 13 4405 env42067 = env42068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env42067 == env42068) = true)

theorem identity42068 : scanCanonicalize (H12AffineFastState.compose env42068 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound42068 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42069 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,348,2048,1,342,2065,2421,272,0,2421,33,17,294,348,65,2340,2064,2065,2421,352,32,256,33,2128,805]

theorem envBound42069 : H12AffineFastState.Bounded env42069 := by
  intro p hp
  have h : env42069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42068_42069 : H12AffineEnvironment.transform 11 2357 env42068 = env42069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env42068 == env42069) = true)

theorem identity42069 : scanCanonicalize (H12AffineFastState.compose env42069 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42069 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0