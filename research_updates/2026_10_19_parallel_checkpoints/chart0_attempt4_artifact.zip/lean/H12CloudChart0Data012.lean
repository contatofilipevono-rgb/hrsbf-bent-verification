import H12CloudChart0Data011

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans2937_2938 : H12AffineEnvironment.transform 16 28586 env2937 = env2938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 28586 env2937 == env2938) = true)

theorem identity2938 : scanCanonicalize (H12AffineFastState.compose env2938 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 16243) := by decide +kernel

theorem selectedBound2938 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env2939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16243,11853,12179,4313,12750,6531,11853,12523,33,4739,139,8329,4819,12474,15009,14968,2420,1365,341,7299,341,1992,513]

theorem envBound2939 : H12AffineFastState.Bounded env2939 := by
  intro p hp
  have h : env2939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2938_2939 : H12AffineEnvironment.transform 13 16243 env2938 = env2939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16243 env2938 == env2939) = true)

theorem identity2939 : scanCanonicalize (H12AffineFastState.compose env2939 (packedSelected [1,5,6,10] rootPS)) = affineNative (2^(11+1) ^^^ 3970) := by decide +kernel

theorem selectedBound2939 : packedSelected [1,5,6,10] rootPS < 2^1333 := by decide +kernel

def env2940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3970,8192,8433,11853,12179,3931,11852,1537,11853,12137,33,3329,139,8329,3409,12088,9507,9722,2420,1365,341,769,341,1992,513]

theorem envBound2940 : H12AffineFastState.Bounded env2940 := by
  intro p hp
  have h : env2940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2939_2940 : H12AffineEnvironment.transform 11 3970 env2939 = env2940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3970 env2939 == env2940) = true)

theorem identity2940 : scanCanonicalize (H12AffineFastState.compose env2940 (packedSelected [1,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1944) := by decide +kernel

theorem selectedBound2940 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env2941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1944,26,8192,8433,8661,8203,195,8660,1537,8661,8433,33,665,139,8329,713,8352,9507,9722,1772,1365,341,769,341,1992,513]

theorem envBound2941 : H12AffineFastState.Bounded env2941 := by
  intro p hp
  have h : env2941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2940_2941 : H12AffineEnvironment.transform 10 1944 env2940 = env2941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1944 env2940 == env2941) = true)

theorem identity2941 : scanCanonicalize (H12AffineFastState.compose env2941 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1896) := by decide +kernel

theorem selectedBound2941 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env2942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1944,26,1896,1945,1725,1891,195,1724,1537,1725,1945,33,665,139,2017,713,1992,587,658,1772,1365,341,769,341,1992,513]

theorem envBound2942 : H12AffineFastState.Bounded env2942 := by
  intro p hp
  have h : env2942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2941_2942 : H12AffineEnvironment.transform 12 1896 env2941 = env2942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1896 env2941 == env2942) = true)

theorem identity2942 : scanCanonicalize (H12AffineFastState.compose env2942 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound2942 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2943 : List Nat := [2,4,8,16,32,64,128,256,512,62,934,26,854,935,643,861,195,642,575,643,935,33,665,139,991,713,1014,587,658,722,363,341,769,341,1014,513]

theorem envBound2943 : H12AffineFastState.Bounded env2943 := by
  intro p hp
  have h : env2943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2942_2943 : H12AffineEnvironment.transform 9 62 env2942 = env2943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env2942 == env2943) = true)

theorem identity2943 : scanCanonicalize (H12AffineFastState.compose env2943 (packedSelected [1,3,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2943 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env2944 : List Nat := [2,4,8,16,32,17,128,256,512,62,934,26,775,935,643,780,146,642,575,643,935,33,665,139,910,664,935,538,658,643,314,260,769,260,935,513]

theorem envBound2944 : H12AffineFastState.Bounded env2944 := by
  intro p hp
  have h : env2944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2943_2944 : H12AffineEnvironment.transform 5 17 env2943 = env2944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2943 == env2944) = true)

theorem identity2944 : scanCanonicalize (H12AffineFastState.compose env2944 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound2944 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env2945 : List Nat := [2,4,8,16,32,17,128,256,131,62,293,26,388,292,0,399,146,1,188,0,292,33,26,139,269,27,292,153,17,0,314,260,386,260,292,130]

theorem envBound2945 : H12AffineFastState.Bounded env2945 := by
  intro p hp
  have h : env2945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2944_2945 : H12AffineEnvironment.transform 8 131 env2944 = env2945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env2944 == env2945) = true)

theorem identity2945 : scanCanonicalize (H12AffineFastState.compose env2945 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound2945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env2946 : List Nat := [2,4,8,16,32,17,128,172,131,62,137,26,40,136,0,35,146,1,188,0,136,33,26,139,161,27,136,153,17,0,150,168,46,168,136,130]

theorem envBound2946 : H12AffineFastState.Bounded env2946 := by
  intro p hp
  have h : env2946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2945_2946 : H12AffineEnvironment.transform 7 172 env2945 = env2946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env2945 == env2946) = true)

theorem identity2946 : scanCanonicalize (H12AffineFastState.compose env2946 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound2946 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2947 : List Nat := [2,4,8,10,32,11,128,172,131,36,137,0,40,136,0,35,136,1,166,0,136,33,0,139,161,1,136,131,11,0,140,168,46,168,136,130]

theorem envBound2947 : H12AffineFastState.Bounded env2947 := by
  intro p hp
  have h : env2947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2946_2947 : H12AffineEnvironment.transform 3 10 env2946 = env2947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env2946 == env2947) = true)

theorem identity2947 : scanCanonicalize (H12AffineFastState.compose env2947 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound2947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2948 : List Nat := [2,4,8,10,32,11,8,36,11,36,1,0,40,0,0,35,0,1,46,0,0,33,0,3,41,1,0,11,11,0,4,32,46,32,0,10]

theorem envBound2948 : H12AffineFastState.Bounded env2948 := by
  intro p hp
  have h : env2948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2947_2948 : H12AffineEnvironment.transform 6 8 env2947 = env2948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env2947 == env2948) = true)

theorem identity2948 : scanCanonicalize (H12AffineFastState.compose env2948 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound2948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2949 : List Nat := [2,4,8,10,10,11,8,14,11,14,1,0,2,0,0,9,0,1,4,0,0,11,0,3,3,1,0,11,11,0,4,10,4,10,0,10]

theorem envBound2949 : H12AffineFastState.Bounded env2949 := by
  intro p hp
  have h : env2949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2948_2949 : H12AffineEnvironment.transform 4 10 env2948 = env2949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env2948 == env2949) = true)

theorem identity2949 : scanCanonicalize (H12AffineFastState.compose env2949 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound2949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2950 : List Nat := [2,1,8,10,10,11,8,11,11,11,1,0,2,0,0,9,0,1,1,0,0,11,0,3,3,1,0,11,11,0,1,10,1,10,0,10]

theorem envBound2950 : H12AffineFastState.Bounded env2950 := by
  intro p hp
  have h : env2950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2949_2950 : H12AffineEnvironment.transform 1 1 env2949 = env2950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env2949 == env2950) = true)

def env2951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,268570625,151259274,92374097,164406726,525568,151257259,34359738368,25733063]

theorem envBound2951 : H12AffineFastState.Bounded env2951 := by
  intro p hp
  have h : env2951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2924_2951 : H12AffineEnvironment.transform 28 268570625 env2924 = env2951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env2924 == env2951) = true)

theorem identity2951 : scanCanonicalize (H12AffineFastState.compose env2951 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(23+1) ^^^ 176599) := by decide +kernel

theorem selectedBound2951 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env2952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,176599,8329,67108864,134217728,268435456,268570625,134658397,75707782,147723281,525568,134656380,34359738368,9049616]

theorem envBound2952 : H12AffineFastState.Bounded env2952 := by
  intro p hp
  have h : env2952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2951_2952 : H12AffineEnvironment.transform 23 176599 env2951 = env2952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 176599 env2951 == env2952) = true)

def env2953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,134217728,268435456,268435965,134523041,75572346,147588589,525568,134520960,34359738368,8914924]

theorem envBound2953 : H12AffineFastState.Bounded env2953 := by
  intro p hp
  have h : env2953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2952_2953 : H12AffineEnvironment.transform 16 4604 env2952 = env2953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4604 env2952 == env2953) = true)

theorem identity2953 : scanCanonicalize (H12AffineFastState.compose env2953 (packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 203784471) := by decide +kernel

theorem selectedBound2953 : packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env2954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,134217728,268435456,268435965,134523041,75572346,147588589,525568,134520960,203784471,8914924]

theorem envBound2954 : H12AffineFastState.Bounded env2954 := by
  intro p hp
  have h : env2954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2953_2954 : H12AffineEnvironment.transform 34 203784471 env2953 = env2954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 203784471 env2953 == env2954) = true)

def env2955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,11015248,134217728,268435456,268435965,134523041,2699306,147588589,525568,134520960,143496519,8914924]

theorem envBound2955 : H12AffineFastState.Bounded env2955 := by
  intro p hp
  have h : env2955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2954_2955 : H12AffineEnvironment.transform 25 11015248 env2954 = env2955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 11015248 env2954 == env2955) = true)

def env2956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,11015248,849104,268435456,268435965,547953,2699306,12644669,525568,545872,8479127,8914924]

theorem envBound2956 : H12AffineFastState.Bounded env2956 := by
  intro p hp
  have h : env2956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2955_2956 : H12AffineEnvironment.transform 26 849104 env2955 = env2956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849104 env2955 == env2956) = true)

def env2957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849104,268435456,268435965,547953,598058,12644669,525568,545872,8479127,8914924]

theorem envBound2957 : H12AffineFastState.Bounded env2957 := by
  intro p hp
  have h : env2957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2956_2957 : H12AffineEnvironment.transform 20 4096 env2956 = env2957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env2956 == env2957) = true)

def env2958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849104,16384,16893,547953,598058,12644669,525568,545872,8479127,8914924]

theorem envBound2958 : H12AffineFastState.Bounded env2958 := by
  intro p hp
  have h : env2958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2957_2958 : H12AffineEnvironment.transform 27 16384 env2957 = env2958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env2957 == env2958) = true)

def env2959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323792,16384,16893,22641,74794,12644669,256,20560,8479127,8389612]

theorem envBound2959 : H12AffineFastState.Bounded env2959 := by
  intro p hp
  have h : env2959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2958_2959 : H12AffineEnvironment.transform 18 1024 env2958 = env2959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2958 == env2959) = true)

theorem identity2959 : scanCanonicalize (H12AffineFastState.compose env2959 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5456) := by decide +kernel

theorem selectedBound2959 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,5456,41003,8329,5376,323792,16384,16893,22641,74794,4252781,256,20560,95431,5820]

theorem envBound2960 : H12AffineFastState.Bounded env2960 := by
  intro p hp
  have h : env2960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2959_2960 : H12AffineEnvironment.transform 22 5456 env2959 = env2960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5456 env2959 == env2960) = true)

def env2961 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,5376,41003,8329,5376,323712,16384,16813,22561,74794,4252733,256,20480,95383,5820]

theorem envBound2961 : H12AffineFastState.Bounded env2961 := by
  intro p hp
  have h : env2961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2960_2961 : H12AffineEnvironment.transform 5 16 env2960 = env2961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2960 == env2961) = true)

theorem identity2961 : scanCanonicalize (H12AffineFastState.compose env2961 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound2961 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2962 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,4194304,444,41003,8329,444,320572,16384,16813,19613,74794,4252733,256,17596,90155,512]

theorem envBound2962 : H12AffineFastState.Bounded env2962 := by
  intro p hp
  have h : env2962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2961_2962 : H12AffineEnvironment.transform 11 1212 env2961 = env2962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env2961 == env2962) = true)

theorem identity2962 : scanCanonicalize (H12AffineFastState.compose env2962 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound2962 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2963 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,41349,444,41003,8329,444,320572,16384,16813,19613,74794,17848,256,17596,90155,512]

theorem envBound2963 : H12AffineFastState.Bounded env2963 := by
  intro p hp
  have h : env2963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2962_2963 : H12AffineEnvironment.transform 21 41349 env2962 = env2963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env2962 == env2963) = true)

theorem identity2963 : scanCanonicalize (H12AffineFastState.compose env2963 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound2963 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env2964 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33543,1296,262144,1024,32768,1212,41349,444,41003,8329,444,320572,16384,16813,19613,42797,17848,256,17596,58156,512]

theorem envBound2964 : H12AffineFastState.Bounded env2964 := by
  intro p hp
  have h : env2964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2963_2964 : H12AffineEnvironment.transform 15 33543 env2963 = env2964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env2963 == env2964) = true)

theorem identity2964 : scanCanonicalize (H12AffineFastState.compose env2964 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound2964 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env2965 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,262144,1024,26425,1212,18108,444,18194,8329,444,262917,16384,16813,19613,16404,17848,256,17596,1045,512]

theorem envBound2965 : H12AffineFastState.Bounded env2965 := by
  intro p hp
  have h : env2965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2964_2965 : H12AffineEnvironment.transform 14 26425 env2964 = env2965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env2964 == env2965) = true)

theorem identity2965 : scanCanonicalize (H12AffineFastState.compose env2965 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound2965 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env2966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,20157,1024,26425,1212,18108,444,18194,8329,444,19896,16384,16813,19613,16404,17848,256,17596,1045,512]

theorem envBound2966 : H12AffineFastState.Bounded env2966 := by
  intro p hp
  have h : env2966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2965_2966 : H12AffineEnvironment.transform 17 20157 env2965 = env2966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env2965 == env2966) = true)

def env2967 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,5377,41003,8329,5376,323713,16384,16812,22560,74794,4252732,256,20481,95382,5820]

theorem envBound2967 : H12AffineFastState.Bounded env2967 := by
  intro p hp
  have h : env2967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2960_2967 : H12AffineEnvironment.transform 5 17 env2960 = env2967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2960 == env2967) = true)

def env2968 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41260,5377,41003,8329,5376,323713,16384,16812,22560,74794,17680,256,20481,95382,5820]

theorem envBound2968 : H12AffineFastState.Bounded env2968 := by
  intro p hp
  have h : env2968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2967_2968 : H12AffineEnvironment.transform 21 41260 env2967 = env2968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env2967 == env2968) = true)

theorem identity2968 : scanCanonicalize (H12AffineFastState.compose env2968 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2968 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2969 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,41260,5377,41003,8225,5376,323625,16384,16644,22560,74794,17680,256,20481,95294,5652]

theorem envBound2969 : H12AffineFastState.Bounded env2969 := by
  intro p hp
  have h : env2969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2968_2969 : H12AffineEnvironment.transform 6 40 env2968 = env2969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2968 == env2969) = true)

def env2970 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1296,8192,16384,32768,65536,1045,262144,1024,32768,1296,41260,17,41003,8225,16,320825,16384,16644,19760,74794,17680,256,17681,90414,772]

theorem envBound2970 : H12AffineFastState.Bounded env2970 := by
  intro p hp
  have h : env2970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2969_2970 : H12AffineEnvironment.transform 11 1296 env2969 = env2970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env2969 == env2970) = true)

def env2971 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,32768,65536,1044,262144,1024,32768,1297,41260,16,41003,8225,17,320824,16384,16644,19761,74794,17680,256,17680,90415,773]

theorem envBound2971 : H12AffineFastState.Bounded env2971 := by
  intro p hp
  have h : env2971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2969_2971 : H12AffineEnvironment.transform 11 1297 env2969 = env2971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env2969 == env2971) = true)

theorem identity2971 : scanCanonicalize (H12AffineFastState.compose env2971 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2971 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2972 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,16384,32768,65536,1044,262144,1024,32768,1045,41000,16,41003,8225,17,320572,16384,16384,19509,74794,17428,4,17428,90155,513]

theorem envBound2972 : H12AffineFastState.Bounded env2972 := by
  intro p hp
  have h : env2972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2971_2972 : H12AffineEnvironment.transform 7 4 env2971 = env2972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2971 == env2972) = true)

theorem identity2972 : scanCanonicalize (H12AffineFastState.compose env2972 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 26142) := by decide +kernel

theorem selectedBound2972 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env2973 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,16384,32768,26142,1044,262144,1024,32768,1045,41000,16,41003,8225,17,320572,16384,16384,19509,16948,17428,4,17428,1589,513]

theorem envBound2973 : H12AffineFastState.Bounded env2973 := by
  intro p hp
  have h : env2973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2972_2973 : H12AffineEnvironment.transform 15 26142 env2972 = env2973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26142 env2972 == env2973) = true)

theorem identity2973 : scanCanonicalize (H12AffineFastState.compose env2973 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2973 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env2974 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,16384,32768,26127,1029,262144,1024,32768,1028,41000,1,41003,8225,0,320557,16384,16384,19492,16933,17413,4,17413,1572,513]

theorem envBound2974 : H12AffineFastState.Bounded env2974 := by
  intro p hp
  have h : env2974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2973_2974 : H12AffineEnvironment.transform 3 1 env2973 = env2974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2973 == env2974) = true)

theorem identity2974 : scanCanonicalize (H12AffineFastState.compose env2974 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8744) := by decide +kernel

theorem selectedBound2974 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2975 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,16384,8744,26127,1029,262144,1024,8744,1028,512,1,515,8225,0,280069,16384,16384,19492,16933,17413,4,17413,1572,513]

theorem envBound2975 : H12AffineFastState.Bounded env2975 := by
  intro p hp
  have h : env2975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2974_2975 : H12AffineEnvironment.transform 14 8744 env2974 = env2975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8744 env2974 == env2975) = true)

theorem identity2975 : scanCanonicalize (H12AffineFastState.compose env2975 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1547) := by decide +kernel

theorem selectedBound2975 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env2976 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,1547,8744,8196,1029,262144,1024,8744,1028,512,1,515,8225,0,262158,1547,1547,2607,1070,526,4,526,1572,513]

theorem envBound2976 : H12AffineFastState.Bounded env2976 := by
  intro p hp
  have h : env2976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2975_2976 : H12AffineEnvironment.transform 13 1547 env2975 = env2976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1547 env2975 == env2976) = true)

theorem identity2976 : scanCanonicalize (H12AffineFastState.compose env2976 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2607) := by decide +kernel

theorem selectedBound2976 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env2977 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,1547,8744,8196,1029,2607,1024,8744,1028,512,1,515,8225,0,2593,1547,1547,2607,1070,526,4,526,1572,513]

theorem envBound2977 : H12AffineFastState.Bounded env2977 := by
  intro p hp
  have h : env2977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2976_2977 : H12AffineEnvironment.transform 17 2607 env2976 = env2977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2607 env2976 == env2977) = true)

theorem identity2977 : scanCanonicalize (H12AffineFastState.compose env2977 (packedSelected [0,1,2,3,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 3593) := by decide +kernel

theorem selectedBound2977 : packedSelected [0,1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env2978 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,3593,1547,3105,3597,1029,2607,1024,3105,1028,512,1,515,3624,0,2593,1547,1547,2607,1070,526,4,526,1572,513]

theorem envBound2978 : H12AffineFastState.Bounded env2978 := by
  intro p hp
  have h : env2978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2977_2978 : H12AffineEnvironment.transform 12 3593 env2977 = env2978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3593 env2977 == env2978) = true)

theorem identity2978 : scanCanonicalize (H12AffineFastState.compose env2978 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound2978 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2979 : List Nat := [2,4,8,1,32,0,40,4,512,1024,42,1028,1571,1547,1035,1575,1029,517,1024,1035,1028,512,1,515,1538,0,523,1547,1547,517,1070,526,4,526,1572,513]

theorem envBound2979 : H12AffineFastState.Bounded env2979 := by
  intro p hp
  have h : env2979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2978_2979 : H12AffineEnvironment.transform 10 42 env2978 = env2979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env2978 == env2979) = true)

theorem identity2979 : scanCanonicalize (H12AffineFastState.compose env2979 (packedSelected [0,1,2,6,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound2979 : packedSelected [0,1,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env2980 : List Nat := [2,4,3,1,32,0,35,4,512,1024,33,1028,1571,1536,1024,1575,1029,517,1024,1024,1028,512,1,515,1538,0,512,1536,1536,517,1061,517,4,517,1572,513]

theorem envBound2980 : H12AffineFastState.Bounded env2980 := by
  intro p hp
  have h : env2980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2979_2980 : H12AffineEnvironment.transform 2 3 env2979 = env2980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env2979 == env2980) = true)

theorem identity2980 : scanCanonicalize (H12AffineFastState.compose env2980 (packedSelected [1,6] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound2980 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env2981 : List Nat := [2,4,3,1,5,0,6,4,512,1024,4,1028,1542,1536,1024,1538,1029,517,1024,1024,1028,512,1,515,1538,0,512,1536,1536,517,1024,517,4,517,1537,513]

theorem envBound2981 : H12AffineFastState.Bounded env2981 := by
  intro p hp
  have h : env2981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2980_2981 : H12AffineEnvironment.transform 4 5 env2980 = env2981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env2980 == env2981) = true)

theorem identity2981 : scanCanonicalize (H12AffineFastState.compose env2981 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound2981 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2982 : List Nat := [2,4,3,1,5,0,6,4,5,1024,4,1028,1027,1029,1024,1031,1029,0,1024,1024,1028,5,1,6,1031,0,5,1029,1029,0,1024,0,4,0,1028,4]

theorem envBound2982 : H12AffineFastState.Bounded env2982 := by
  intro p hp
  have h : env2982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2981_2982 : H12AffineEnvironment.transform 8 5 env2981 = env2982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env2981 == env2982) = true)

def env2983 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41261,5377,41003,8329,5376,323713,16384,16812,22560,74794,17681,256,20481,95382,5820]

theorem envBound2983 : H12AffineFastState.Bounded env2983 := by
  intro p hp
  have h : env2983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2967_2983 : H12AffineEnvironment.transform 21 41261 env2967 = env2983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env2967 == env2983) = true)

theorem identity2983 : scanCanonicalize (H12AffineFastState.compose env2983 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound2983 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2984 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1024,32768,4096,41261,5377,41003,8329,5376,323713,16384,16812,22560,16824,17681,256,20481,4356,5820]

theorem envBound2984 : H12AffineFastState.Bounded env2984 := by
  intro p hp
  have h : env2984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2983_2984 : H12AffineEnvironment.transform 15 26002 env2983 = env2984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env2983 == env2984) = true)

def env2985 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,16384,32768,26002,1213,262144,1024,32768,1296,41261,17,41003,8329,16,320913,16384,16812,19760,16824,17681,256,17681,1044,940]

theorem envBound2985 : H12AffineFastState.Bounded env2985 := by
  intro p hp
  have h : env2985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2984_2985 : H12AffineEnvironment.transform 11 1296 env2984 = env2985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env2984 == env2985) = true)

theorem identity2985 : scanCanonicalize (H12AffineFastState.compose env2985 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2985 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2986 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,16384,32768,25750,1213,262144,1024,32768,1044,41001,17,41003,8329,16,320661,16384,16552,19508,16572,17429,4,17429,1044,680]

theorem envBound2986 : H12AffineFastState.Bounded env2986 := by
  intro p hp
  have h : env2986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2985_2986 : H12AffineEnvironment.transform 7 4 env2985 = env2986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2985 == env2986) = true)

theorem identity2986 : scanCanonicalize (H12AffineFastState.compose env2986 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound2986 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env2987 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1692,32768,8714,1213,262144,1024,32768,1044,41001,17,41003,8329,16,303625,1692,1588,2728,1568,649,4,649,1044,680]

theorem envBound2987 : H12AffineFastState.Bounded env2987 := by
  intro p hp
  have h : env2987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2986_2987 : H12AffineEnvironment.transform 13 1692 env2986 = env2987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env2986 == env2987) = true)

theorem identity2987 : scanCanonicalize (H12AffineFastState.compose env2987 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound2987 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env2988 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1692,8201,8714,1213,262144,1024,8201,1044,32,17,34,8329,16,262656,1692,1588,2728,1568,649,4,649,1044,680]

theorem envBound2988 : H12AffineFastState.Bounded env2988 := by
  intro p hp
  have h : env2988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2987_2988 : H12AffineEnvironment.transform 14 8201 env2987 = env2988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env2987 == env2988) = true)

theorem identity2988 : scanCanonicalize (H12AffineFastState.compose env2988 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2729) := by decide +kernel

theorem selectedBound2988 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2989 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1692,8201,8714,1213,2729,1024,8201,1044,32,17,34,8329,16,2217,1692,1588,2728,1568,649,4,649,1044,680]

theorem envBound2989 : H12AffineFastState.Bounded env2989 := by
  intro p hp
  have h : env2989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2988_2989 : H12AffineEnvironment.transform 17 2729 env2988 = env2989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2729 env2988 == env2989) = true)

theorem identity2989 : scanCanonicalize (H12AffineFastState.compose env2989 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2989 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2990 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,8192,1588,8201,8714,1045,2561,1024,8201,1044,32,17,34,8225,16,2049,1588,1588,2560,1568,545,4,545,1044,512]

theorem envBound2990 : H12AffineFastState.Bounded env2990 := by
  intro p hp
  have h : env2990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2989_2990 : H12AffineEnvironment.transform 6 40 env2989 = env2990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2989 == env2990) = true)

theorem identity2990 : scanCanonicalize (H12AffineFastState.compose env2990 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound2990 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2991 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,1085,1588,1076,1591,1045,2561,1024,1076,1044,32,17,34,1052,16,2049,1588,1588,2560,1568,545,4,545,1044,512]

theorem envBound2991 : H12AffineFastState.Bounded env2991 := by
  intro p hp
  have h : env2991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2990_2991 : H12AffineEnvironment.transform 12 1085 env2990 = env2991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env2990 == env2991) = true)

theorem identity2991 : scanCanonicalize (H12AffineFastState.compose env2991 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound2991 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env2992 : List Nat := [2,4,8,16,27,17,19,4,512,1024,2048,1044,1030,1551,1039,1548,1045,2561,1024,1039,1044,27,17,25,1052,16,2049,1551,1551,2560,1563,538,4,538,1044,512]

theorem envBound2992 : H12AffineFastState.Bounded env2992 := by
  intro p hp
  have h : env2992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2991_2992 : H12AffineEnvironment.transform 4 27 env2991 = env2992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env2991 == env2992) = true)

theorem identity2992 : scanCanonicalize (H12AffineFastState.compose env2992 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound2992 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2993 : List Nat := [2,4,8,16,27,17,19,4,512,1024,1044,1044,1030,1551,1039,1548,1045,1557,1024,1039,1044,27,17,25,1052,16,1045,1551,1551,1556,1563,538,4,538,1044,512]

theorem envBound2993 : H12AffineFastState.Bounded env2993 := by
  intro p hp
  have h : env2993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2992_2993 : H12AffineEnvironment.transform 10 1044 env2992 = env2993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env2992 == env2993) = true)

theorem identity2993 : scanCanonicalize (H12AffineFastState.compose env2993 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound2993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2994 : List Nat := [2,4,8,16,27,17,19,4,1,1024,1044,1044,1030,1038,1039,1037,1045,1044,1024,1039,1044,27,17,25,1052,16,1045,1038,1038,1045,1050,27,4,27,1044,1]

theorem envBound2994 : H12AffineFastState.Bounded env2994 := by
  intro p hp
  have h : env2994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2993_2994 : H12AffineEnvironment.transform 8 1 env2993 = env2994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env2993 == env2994) = true)

theorem identity2994 : scanCanonicalize (H12AffineFastState.compose env2994 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound2994 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2995 : List Nat := [2,4,8,16,27,17,19,4,1,20,0,0,18,26,27,25,1,0,20,27,0,27,17,25,8,16,1,26,26,1,14,27,4,27,0,1]

theorem envBound2995 : H12AffineFastState.Bounded env2995 := by
  intro p hp
  have h : env2995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2994_2995 : H12AffineEnvironment.transform 9 20 env2994 = env2995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env2994 == env2995) = true)

theorem identity2995 : scanCanonicalize (H12AffineFastState.compose env2995 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound2995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2996 : List Nat := [2,4,8,10,1,11,9,4,1,14,0,0,8,0,1,3,1,0,14,1,0,1,11,3,8,10,1,0,0,1,14,1,4,1,0,1]

theorem envBound2996 : H12AffineFastState.Bounded env2996 := by
  intro p hp
  have h : env2996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2995_2996 : H12AffineEnvironment.transform 3 10 env2995 = env2996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env2995 == env2996) = true)

def env2997 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,16384,32768,26002,1212,262144,1024,32768,1297,41261,16,41003,8329,17,320912,16384,16812,19761,16824,17681,256,17680,1045,941]

theorem envBound2997 : H12AffineFastState.Bounded env2997 := by
  intro p hp
  have h : env2997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2984_2997 : H12AffineEnvironment.transform 11 1297 env2984 = env2997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env2984 == env2997) = true)

theorem identity2997 : scanCanonicalize (H12AffineFastState.compose env2997 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2997 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2998 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,32768,25914,1044,262144,1024,32768,1297,41261,16,41003,8225,17,320824,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound2998 : H12AffineFastState.Bounded env2998 := by
  intro p hp
  have h : env2998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2997_2998 : H12AffineEnvironment.transform 6 40 env2997 = env2998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2997 == env2998) = true)

theorem identity2998 : scanCanonicalize (H12AffineFastState.compose env2998 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1039) := by decide +kernel

theorem selectedBound2998 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2999 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,32768,25914,1044,1039,1024,32768,1297,41261,16,41003,8225,17,57655,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound2999 : H12AffineFastState.Bounded env2999 := by
  intro p hp
  have h : env2999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2998_2999 : H12AffineEnvironment.transform 17 1039 env2998 = env2999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1039 env2998 == env2999) = true)

theorem identity2999 : scanCanonicalize (H12AffineFastState.compose env2999 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 1291) := by decide +kernel

theorem selectedBound2999 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env3000 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,1291,25914,1044,1039,1024,1291,1297,9254,16,9504,8225,17,25660,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound3000 : H12AffineFastState.Bounded env3000 := by
  intro p hp
  have h : env3000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2999_3000 : H12AffineEnvironment.transform 14 1291 env2999 = env3000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1291 env2999 == env3000) = true)

theorem identity3000 : scanCanonicalize (H12AffineFastState.compose env3000 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3000 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3001 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,16384,1039,25662,1044,1039,1024,1039,1045,9254,16,9252,8225,17,25660,16384,16384,19509,16404,17429,4,17428,1045,513]

theorem envBound3001 : H12AffineFastState.Bounded env3001 := by
  intro p hp
  have h : env3001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3000_3001 : H12AffineEnvironment.transform 7 4 env3000 = env3001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3000 == env3001) = true)

theorem identity3001 : scanCanonicalize (H12AffineFastState.compose env3001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8195) := by decide +kernel

theorem selectedBound3001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3002 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,8195,1039,1085,1044,1039,1024,1039,1045,9254,16,9252,8225,17,1087,8195,8195,11318,8215,9238,4,9239,1045,513]

theorem envBound3002 : H12AffineFastState.Bounded env3002 := by
  intro p hp
  have h : env3002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3001_3002 : H12AffineEnvironment.transform 13 8195 env3001 = env3002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8195 env3001 == env3002) = true)

theorem identity3002 : scanCanonicalize (H12AffineFastState.compose env3002 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound3002 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env3003 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1071,1045,8192,8195,1039,1085,1044,1039,1024,1039,1045,9254,16,9252,8225,17,1087,8195,8195,8217,8215,9238,4,9239,1045,513]

theorem envBound3003 : H12AffineFastState.Bounded env3003 := by
  intro p hp
  have h : env3003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3002_3003 : H12AffineEnvironment.transform 10 1071 env3002 = env3003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env3002 == env3003) = true)

theorem identity3003 : scanCanonicalize (H12AffineFastState.compose env3003 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound3003 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env3004 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1071,1045,8192,8195,1039,1085,1044,1039,1024,1039,1045,9254,16,9252,8225,17,1087,8195,8195,8217,8215,9238,4,9239,1045,32]

theorem envBound3004 : H12AffineFastState.Bounded env3004 := by
  intro p hp
  have h : env3004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3003_3004 : H12AffineEnvironment.transform 8 33 env3003 = env3004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3003 == env3004) = true)

theorem identity3004 : scanCanonicalize (H12AffineFastState.compose env3004 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound3004 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env3005 : List Nat := [2,4,8,16,32,17,40,4,33,53,26,32,8192,8195,58,8,33,58,53,58,32,8211,16,8209,8225,17,10,8195,8195,8217,8215,8227,4,8226,32,32]

theorem envBound3005 : H12AffineFastState.Bounded env3005 := by
  intro p hp
  have h : env3005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3004_3005 : H12AffineEnvironment.transform 9 53 env3004 = env3005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env3004 == env3005) = true)

theorem identity3005 : scanCanonicalize (H12AffineFastState.compose env3005 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound3005 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env3006 : List Nat := [2,4,8,14,32,15,40,4,33,43,4,32,8192,8195,36,8,33,36,43,36,32,8205,14,8207,8225,15,10,8195,8195,8199,8201,8227,4,8226,32,32]

theorem envBound3006 : H12AffineFastState.Bounded env3006 := by
  intro p hp
  have h : env3006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3005_3006 : H12AffineEnvironment.transform 3 14 env3005 = env3006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env3005 == env3006) = true)

theorem identity3006 : scanCanonicalize (H12AffineFastState.compose env3006 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound3006 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env3007 : List Nat := [2,4,8,14,32,15,40,4,33,43,4,32,41,42,36,8,33,36,43,36,32,36,14,38,8,15,10,42,42,46,32,10,4,11,32,32]

theorem envBound3007 : H12AffineFastState.Bounded env3007 := by
  intro p hp
  have h : env3007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3006_3007 : H12AffineEnvironment.transform 12 41 env3006 = env3007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env3006 == env3007) = true)

theorem identity3007 : scanCanonicalize (H12AffineFastState.compose env3007 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3008 : List Nat := [2,4,8,14,10,15,2,4,11,1,4,10,3,0,14,8,11,14,1,14,10,14,14,12,8,15,10,0,0,4,10,10,4,11,10,10]

theorem envBound3008 : H12AffineFastState.Bounded env3008 := by
  intro p hp
  have h : env3008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3007_3008 : H12AffineEnvironment.transform 4 10 env3007 = env3008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3007 == env3008) = true)

theorem identity3008 : scanCanonicalize (H12AffineFastState.compose env3008 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3008 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env3009 : List Nat := [2,0,8,10,10,11,2,0,11,1,0,10,3,0,10,8,11,10,1,10,10,10,10,8,8,11,10,0,0,0,10,10,0,11,10,10]

theorem envBound3009 : H12AffineFastState.Bounded env3009 := by
  intro p hp
  have h : env3009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3008_3009 : H12AffineEnvironment.transform 1 0 env3008 = env3009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3008 == env3009) = true)

theorem identity3009 : scanCanonicalize (H12AffineFastState.compose env3009 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3009 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3010 : List Nat := [2,0,2,0,0,1,2,0,1,1,0,0,3,0,0,2,1,0,1,0,0,0,0,2,2,1,0,0,0,0,0,0,0,1,0,0]

theorem envBound3010 : H12AffineFastState.Bounded env3010 := by
  intro p hp
  have h : env3010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3009_3010 : H12AffineEnvironment.transform 2 2 env3009 = env3010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3009 == env3010) = true)

def env3011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323793,16384,16893,22640,74795,12644669,257,20561,8479127,8389613]

theorem envBound3011 : H12AffineFastState.Bounded env3011 := by
  intro p hp
  have h : env3011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2958_3011 : H12AffineEnvironment.transform 18 1025 env2958 = env3011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2958 == env3011) = true)

theorem identity3011 : scanCanonicalize (H12AffineFastState.compose env3011 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound3011 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,303233,4176,4525,2080,74795,12624237,257,1,8466887,8389613]

theorem envBound3012 : H12AffineFastState.Bounded env3012 := by
  intro p hp
  have h : env3012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3011_3012 : H12AffineEnvironment.transform 13 4176 env3011 = env3012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env3011 == env3012) = true)

def env3013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4096,4194304,8388608,41003,8329,8388609,303233,4096,4525,2080,74795,12624189,257,1,8466839,8389565]

theorem envBound3013 : H12AffineFastState.Bounded env3013 := by
  intro p hp
  have h : env3013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3012_3013 : H12AffineEnvironment.transform 5 16 env3012 = env3013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3012 == env3013) = true)

def env3014 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,2080,1025,32768,4096,4194304,8388608,41003,8329,8388609,43169,4096,4525,2080,74795,12624189,257,1,8466839,8389565]

theorem envBound3014 : H12AffineFastState.Bounded env3014 := by
  intro p hp
  have h : env3014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3013_3014 : H12AffineEnvironment.transform 17 2080 env3013 = env3014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env3013 == env3014) = true)

theorem identity3014 : scanCanonicalize (H12AffineFastState.compose env3014 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound3014 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env3015 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4524,2080,1025,32768,4096,4194304,8388608,41003,8329,8388609,43169,4096,4525,2080,1192,12624189,257,1,8392980,8389565]

theorem envBound3015 : H12AffineFastState.Bounded env3015 := by
  intro p hp
  have h : env3015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3014_3015 : H12AffineEnvironment.transform 15 8323 env3014 = env3015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env3014 == env3015) = true)

theorem identity3015 : scanCanonicalize (H12AffineFastState.compose env3015 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound3015 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env3016 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4524,2080,1025,32768,4096,41088,8388608,41003,8329,8388609,43169,4096,4525,2080,1192,8389053,257,1,8392980,8389565]

theorem envBound3016 : H12AffineFastState.Bounded env3016 := by
  intro p hp
  have h : env3016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3015_3016 : H12AffineEnvironment.transform 21 41088 env3015 = env3016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3015 == env3016) = true)

theorem identity3016 : scanCanonicalize (H12AffineFastState.compose env3016 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 185) := by decide +kernel

theorem selectedBound3016 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3017 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4524,2080,1025,32768,4096,41088,185,41003,8329,184,43169,4096,4525,2080,1192,260,257,1,4525,772]

theorem envBound3017 : H12AffineFastState.Bounded env3017 := by
  intro p hp
  have h : env3017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3016_3017 : H12AffineEnvironment.transform 22 185 env3016 = env3017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env3016 == env3017) = true)

theorem identity3017 : scanCanonicalize (H12AffineFastState.compose env3017 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 14224) := by decide +kernel

theorem selectedBound3017 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3018 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,14224,8323,4524,2080,1025,14224,4096,5904,185,6075,8329,184,7985,4096,4525,2080,1192,260,257,1,4525,772]

theorem envBound3018 : H12AffineFastState.Bounded env3018 := by
  intro p hp
  have h : env3018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3017_3018 : H12AffineEnvironment.transform 14 14224 env3017 = env3018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14224 env3017 == env3018) = true)

theorem identity3018 : scanCanonicalize (H12AffineFastState.compose env3018 (packedSelected [0,1,4,5,7,8,9,24] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound3018 : packedSelected [0,1,4,5,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env3019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1841,8353,8323,1693,2080,1025,8353,1841,33,185,138,8329,184,2048,1841,1692,2080,1192,260,257,1,1692,772]

theorem envBound3019 : H12AffineFastState.Bounded env3019 := by
  intro p hp
  have h : env3019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3018_3019 : H12AffineEnvironment.transform 11 1841 env3018 = env3019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env3018 == env3019) = true)

theorem identity3019 : scanCanonicalize (H12AffineFastState.compose env3019 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound3019 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3020 : List Nat := [2,4,8,16,32,16,19,256,512,1024,2048,1841,8192,1841,8242,8208,1550,2080,1025,8242,1841,33,42,25,8218,43,2048,1841,1551,2080,1083,260,257,1,1551,772]

theorem envBound3020 : H12AffineFastState.Bounded env3020 := by
  intro p hp
  have h : env3020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3019_3020 : H12AffineEnvironment.transform 6 19 env3019 = env3020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env3019 == env3020) = true)

theorem identity3020 : scanCanonicalize (H12AffineFastState.compose env3020 (packedSelected [3,4,5,7,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3020 : packedSelected [3,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env3021 : List Nat := [2,4,8,16,32,16,19,256,512,1024,1550,1841,8192,1841,8242,8208,1550,1582,1025,8242,1841,33,42,25,8218,43,1550,1841,1551,1582,1083,260,257,1,1551,772]

theorem envBound3021 : H12AffineFastState.Bounded env3021 := by
  intro p hp
  have h : env3021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3020_3021 : H12AffineEnvironment.transform 10 1550 env3020 = env3021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3020 == env3021) = true)

theorem identity3021 : scanCanonicalize (H12AffineFastState.compose env3021 (packedSelected [1,4,8,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound3021 : packedSelected [1,4,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3022 : List Nat := [2,4,8,16,32,16,19,37,512,1024,1550,1556,8192,1556,8242,8208,1550,1582,1025,8242,1556,33,42,25,8218,43,1550,1556,1551,1582,1083,33,36,1,1551,545]

theorem envBound3022 : H12AffineFastState.Bounded env3022 := by
  intro p hp
  have h : env3022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3021_3022 : H12AffineEnvironment.transform 7 37 env3021 = env3022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env3021 == env3022) = true)

theorem identity3022 : scanCanonicalize (H12AffineFastState.compose env3022 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3022 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3023 : List Nat := [2,4,8,16,27,16,19,30,512,1024,1550,1556,8192,1556,8201,8208,1550,1557,1025,8201,1556,26,17,25,8218,16,1550,1556,1551,1557,1024,26,31,1,1551,538]

theorem envBound3023 : H12AffineFastState.Bounded env3023 := by
  intro p hp
  have h : env3023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3022_3023 : H12AffineEnvironment.transform 4 27 env3022 = env3023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3022 == env3023) = true)

theorem identity3023 : scanCanonicalize (H12AffineFastState.compose env3023 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound3023 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3024 : List Nat := [2,4,8,16,27,16,19,30,512,1024,1550,1556,1053,1556,1044,1037,1550,1557,1025,1044,1556,26,17,25,1031,16,1550,1556,1551,1557,1024,26,31,1,1551,538]

theorem envBound3024 : H12AffineFastState.Bounded env3024 := by
  intro p hp
  have h : env3024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3023_3024 : H12AffineEnvironment.transform 12 1053 env3023 = env3024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env3023 == env3024) = true)

theorem identity3024 : scanCanonicalize (H12AffineFastState.compose env3024 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3024 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3025 : List Nat := [2,4,8,10,1,10,9,4,512,1024,1550,1550,1031,1550,1038,1037,1550,1551,1025,1038,1550,0,11,3,1031,10,1550,1550,1551,1551,1024,0,5,1,1551,512]

theorem envBound3025 : H12AffineFastState.Bounded env3025 := by
  intro p hp
  have h : env3025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3024_3025 : H12AffineEnvironment.transform 3 10 env3024 = env3025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3024 == env3025) = true)

theorem identity3025 : scanCanonicalize (H12AffineFastState.compose env3025 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3026 : List Nat := [2,4,8,10,1,10,9,4,512,14,512,512,9,512,0,3,512,513,15,0,512,0,11,3,9,10,512,512,513,513,14,0,5,1,513,512]

theorem envBound3026 : H12AffineFastState.Bounded env3026 := by
  intro p hp
  have h : env3026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3025_3026 : H12AffineEnvironment.transform 9 14 env3025 = env3026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3025 == env3026) = true)

theorem identity3026 : scanCanonicalize (H12AffineFastState.compose env3026 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3027 : List Nat := [2,4,8,10,1,10,9,4,1,14,1,1,9,1,0,3,1,0,15,0,1,0,11,3,9,10,1,1,0,0,14,0,5,1,0,1]

theorem envBound3027 : H12AffineFastState.Bounded env3027 := by
  intro p hp
  have h : env3027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3026_3027 : H12AffineEnvironment.transform 8 1 env3026 = env3027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3026 == env3027) = true)

def env3028 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,2081,1025,32768,4096,4194304,8388608,41003,8329,8388609,43168,4096,4525,2080,74795,12624189,257,1,8466839,8389565]

theorem envBound3028 : H12AffineFastState.Bounded env3028 := by
  intro p hp
  have h : env3028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3013_3028 : H12AffineEnvironment.transform 17 2081 env3013 = env3028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env3013 == env3028) = true)

theorem identity3028 : scanCanonicalize (H12AffineFastState.compose env3028 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(22+1) ^^^ 4292886) := by decide +kernel

theorem selectedBound3028 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env3029 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,2081,1025,32768,4096,4194304,4292886,41003,8329,4292887,43168,4096,4525,2080,74795,73771,257,1,4239489,4293291]

theorem envBound3029 : H12AffineFastState.Bounded env3029 := by
  intro p hp
  have h : env3029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3028_3029 : H12AffineEnvironment.transform 22 4292886 env3028 = env3029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292886 env3028 == env3029) = true)

theorem identity3029 : scanCanonicalize (H12AffineFastState.compose env3029 (packedSelected [2,3,4,5,8,9,11,13,17,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound3029 : packedSelected [2,3,4,5,8,9,11,13,17,20,23,28] rootPS < 2^1333 := by decide +kernel

def env3030 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8582,4524,2081,1025,32768,4096,4194304,4235408,41003,8329,4235409,43168,4096,4525,2080,1453,429,257,1,4239489,4236077]

theorem envBound3030 : H12AffineFastState.Bounded env3030 := by
  intro p hp
  have h : env3030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3029_3030 : H12AffineEnvironment.transform 15 8582 env3029 = env3030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env3029 == env3030) = true)

theorem identity3030 : scanCanonicalize (H12AffineFastState.compose env3030 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11782) := by decide +kernel

theorem selectedBound3030 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env3031 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,11782,8582,4524,2081,1025,11782,4096,4194304,4198038,3629,8329,4198039,1702,4096,4525,2080,1453,429,257,1,4202119,4197675]

theorem envBound3031 : H12AffineFastState.Bounded env3031 := by
  intro p hp
  have h : env3031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3030_3031 : H12AffineEnvironment.transform 14 11782 env3030 = env3031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11782 env3030 == env3031) = true)

theorem identity3031 : scanCanonicalize (H12AffineFastState.compose env3031 (packedSelected [0,4,6,7,9,11,17,21,32] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound3031 : packedSelected [0,4,6,7,9,11,17,21,32] rootPS < 2^1333 := by decide +kernel

def env3032 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1703,4096,8192,4096,8353,8582,4524,1670,1025,8353,4096,4194304,4194353,138,8329,4194352,1702,4096,4525,1671,1453,429,257,1,4198432,4195212]

theorem envBound3032 : H12AffineFastState.Bounded env3032 := by
  intro p hp
  have h : env3032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3031_3032 : H12AffineEnvironment.transform 10 1703 env3031 = env3032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env3031 == env3032) = true)

theorem identity3032 : scanCanonicalize (H12AffineFastState.compose env3032 (packedSelected [0,1,2,6,7,8,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3032 : packedSelected [0,1,2,6,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env3033 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1703,4096,8192,4096,8353,8234,4096,1670,1025,8353,4096,4194304,4194353,138,8329,4194352,1702,4096,4097,1671,1025,1,173,1,4198432,4194848]

theorem envBound3033 : H12AffineFastState.Bounded env3033 := by
  intro p hp
  have h : env3033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3032_3033 : H12AffineEnvironment.transform 7 172 env3032 = env3033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3032 == env3033) = true)

theorem identity3033 : scanCanonicalize (H12AffineFastState.compose env3033 (packedSelected [1,4,5,7,20] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3033 : packedSelected [1,4,5,7,20] rootPS < 2^1333 := by decide +kernel

def env3034 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,4096,8192,4096,8200,8234,4096,1583,1025,8200,4096,4194304,4194353,35,8224,4194352,1551,4096,4097,1582,1025,1,4,1,4198432,4194848]

theorem envBound3034 : H12AffineFastState.Bounded env3034 := by
  intro p hp
  have h : env3034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3033_3034 : H12AffineEnvironment.transform 6 41 env3033 = env3034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3033 == env3034) = true)

theorem identity3034 : scanCanonicalize (H12AffineFastState.compose env3034 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3034 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3035 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,1589,8192,1589,8200,8234,1589,1583,1025,8200,1589,4194304,4194353,35,8224,4194352,1551,1589,1588,1582,1025,1,4,1,4195861,4194848]

theorem envBound3035 : H12AffineFastState.Bounded env3035 := by
  intro p hp
  have h : env3035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3034_3035 : H12AffineEnvironment.transform 11 1589 env3034 = env3035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3034 == env3035) = true)

theorem identity3035 : scanCanonicalize (H12AffineFastState.compose env3035 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound3035 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env3036 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,1589,1031,1589,1039,1069,1589,1583,1025,1039,1589,4194304,4194353,35,1063,4194352,1551,1589,1588,1582,1025,1,4,1,4195861,4194848]

theorem envBound3036 : H12AffineFastState.Bounded env3036 := by
  intro p hp
  have h : env3036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3035_3036 : H12AffineEnvironment.transform 12 1031 env3035 = env3036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env3035 == env3036) = true)

theorem identity3036 : scanCanonicalize (H12AffineFastState.compose env3036 (packedSelected [11] rootPS)) = affineNative (2^(21+1) ^^^ 545) := by decide +kernel

theorem selectedBound3036 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3037 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,1589,1031,1589,1039,1069,1589,1583,1025,1039,1589,545,528,35,1063,529,1551,1589,1588,1582,1025,1,4,1,1076,1]

theorem envBound3037 : H12AffineFastState.Bounded env3037 := by
  intro p hp
  have h : env3037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3036_3037 : H12AffineEnvironment.transform 21 545 env3036 = env3037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 545 env3036 == env3037) = true)

theorem identity3037 : scanCanonicalize (H12AffineFastState.compose env3037 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound3037 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3038 : List Nat := [2,4,8,16,32,16,41,5,512,52,570,513,51,513,59,25,513,539,53,59,513,545,528,35,19,529,571,513,512,538,53,1,4,1,0,1]

theorem envBound3038 : H12AffineFastState.Bounded env3038 := by
  intro p hp
  have h : env3038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3037_3038 : H12AffineEnvironment.transform 9 52 env3037 = env3038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env3037 == env3038) = true)

def env3039 : List Nat := [2,4,8,16,32,16,41,5,0,52,58,1,51,1,59,25,1,27,53,59,1,33,16,35,19,17,59,1,0,26,53,1,4,1,0,1]

theorem envBound3039 : H12AffineFastState.Bounded env3039 := by
  intro p hp
  have h : env3039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3038_3039 : H12AffineEnvironment.transform 8 0 env3038 = env3039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3038 == env3039) = true)

theorem identity3039 : scanCanonicalize (H12AffineFastState.compose env3039 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound3039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3040 : List Nat := [2,4,8,4,32,4,41,5,0,32,46,1,39,1,47,13,1,15,33,47,1,33,4,35,7,5,47,1,0,14,33,1,4,1,0,1]

theorem envBound3040 : H12AffineFastState.Bounded env3040 := by
  intro p hp
  have h : env3040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3039_3040 : H12AffineEnvironment.transform 3 4 env3039 = env3040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env3039 == env3040) = true)

theorem identity3040 : scanCanonicalize (H12AffineFastState.compose env3040 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound3040 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3041 : List Nat := [2,4,8,4,15,4,6,5,0,15,1,1,8,1,0,13,1,15,14,0,1,14,4,12,7,5,0,1,0,14,14,1,4,1,0,1]

theorem envBound3041 : H12AffineFastState.Bounded env3041 := by
  intro p hp
  have h : env3041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3040_3041 : H12AffineEnvironment.transform 4 15 env3040 = env3041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env3040 == env3041) = true)

theorem identity3041 : scanCanonicalize (H12AffineFastState.compose env3041 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3041 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3042 : List Nat := [2,0,8,0,11,0,2,1,0,11,1,1,8,1,0,9,1,11,10,0,1,10,0,8,3,1,0,1,0,10,10,1,0,1,0,1]

theorem envBound3042 : H12AffineFastState.Bounded env3042 := by
  intro p hp
  have h : env3042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3041_3042 : H12AffineEnvironment.transform 1 0 env3041 = env3042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3041 == env3042) = true)

def leafEnv3042 : List Nat := [2,0,8,0,11,0,2,1,0,11,1,1,8,1,0,9,1,11,10,0,1,10,0,8,11,3,1,1,0,1,0,10,10,1,0,1,1,2,0,1,1,0,0]

def active3042 : List Nat := [0,2]

def tree3042 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3042 : H12WitnessSearch.Good tree3042 := H12GlobalWitnessIndex.good

theorem leafIdentity3042 : H12AffineFastState.composeSystem env3042 rootObs = leafEnv3042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3042 rootObs == leafEnv3042) = true)

theorem terminalChecked3042 : H12PackedTerminal.terminalCheckFast leafEnv3042 active3042 tree3042 = true := by decide +kernel

def env3043 : List Nat := [2,4,8,16,32,16,41,5,1,52,59,0,51,0,59,25,0,26,53,59,0,32,17,35,19,16,58,0,1,27,53,1,4,1,0,1]

theorem envBound3043 : H12AffineFastState.Bounded env3043 := by
  intro p hp
  have h : env3043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3038_3043 : H12AffineEnvironment.transform 8 1 env3038 = env3043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3038 == env3043) = true)

def env3044 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4096,4194304,8388608,41003,8329,8388608,303233,4097,4525,2080,74795,12624188,257,1,8466838,8389564]

theorem envBound3044 : H12AffineFastState.Bounded env3044 := by
  intro p hp
  have h : env3044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3012_3044 : H12AffineEnvironment.transform 5 17 env3012 = env3044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3012 == env3044) = true)

theorem identity3044 : scanCanonicalize (H12AffineFastState.compose env3044 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3044 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3045 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4096,4194304,444,41003,8329,444,303233,4097,4525,2080,74795,4235392,257,1,77866,512]

theorem envBound3045 : H12AffineFastState.Bounded env3045 := by
  intro p hp
  have h : env3045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3044_3045 : H12AffineEnvironment.transform 22 444 env3044 = env3045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3044 == env3045) = true)

theorem identity3045 : scanCanonicalize (H12AffineFastState.compose env3045 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3045 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3046 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4096,41348,444,41003,8329,444,303233,4097,4525,2080,74795,260,257,1,77866,512]

theorem envBound3046 : H12AffineFastState.Bounded env3046 := by
  intro p hp
  have h : env3046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3045_3046 : H12AffineEnvironment.transform 21 41348 env3045 = env3046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3045 == env3046) = true)

theorem identity3046 : scanCanonicalize (H12AffineFastState.compose env3046 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3046 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3047 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,38843,4525,262144,1025,32768,4096,41348,444,41003,8329,444,303233,4097,4525,2080,45968,260,257,1,42897,512]

theorem envBound3047 : H12AffineFastState.Bounded env3047 := by
  intro p hp
  have h : env3047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3046_3047 : H12AffineEnvironment.transform 15 38843 env3046 = env3047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3046 == env3047) = true)

theorem identity3047 : scanCanonicalize (H12AffineFastState.compose env3047 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14136) := by decide +kernel

theorem selectedBound3047 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3048 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,14136,8323,4525,262144,1025,14136,4096,5820,444,5907,8329,444,268217,4097,4525,2080,1192,260,257,1,4265,512]

theorem envBound3048 : H12AffineFastState.Bounded env3048 := by
  intro p hp
  have h : env3048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3047_3048 : H12AffineEnvironment.transform 14 14136 env3047 = env3048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14136 env3047 == env3048) = true)

theorem identity3048 : scanCanonicalize (H12AffineFastState.compose env3048 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound3048 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3049 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,14136,8323,4525,2341,1025,14136,4096,5820,444,5907,8329,444,7836,4097,4525,2080,1192,260,257,1,4265,512]

theorem envBound3049 : H12AffineFastState.Bounded env3049 := by
  intro p hp
  have h : env3049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3048_3049 : H12AffineEnvironment.transform 17 2341 env3048 = env3049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env3048 == env3049) = true)

theorem identity3049 : scanCanonicalize (H12AffineFastState.compose env3049 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3049 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env3050 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,4097,13885,8323,4264,2080,1025,13885,4096,5820,185,5654,8329,185,7836,4097,4264,2080,1192,1,4,1,4265,512]

theorem envBound3050 : H12AffineFastState.Bounded env3050 := by
  intro p hp
  have h : env3050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3049_3050 : H12AffineEnvironment.transform 7 5 env3049 = env3050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3049 == env3050) = true)

theorem identity3050 : scanCanonicalize (H12AffineFastState.compose env3050 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3050 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3051 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1589,8192,1588,8200,8323,1693,2080,1025,8200,1589,137,185,35,8329,185,2217,1588,1693,2080,1192,1,4,1,1692,512]

theorem envBound3051 : H12AffineFastState.Bounded env3051 := by
  intro p hp
  have h : env3051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3050_3051 : H12AffineEnvironment.transform 11 1589 env3050 = env3051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3050 == env3051) = true)

theorem identity3051 : scanCanonicalize (H12AffineFastState.compose env3051 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3051 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3052 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1589,8192,1588,8200,8235,1589,2080,1025,8200,1589,33,17,35,8225,17,2049,1588,1589,2080,1024,1,4,1,1588,512]

theorem envBound3052 : H12AffineFastState.Bounded env3052 := by
  intro p hp
  have h : env3052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3051_3052 : H12AffineEnvironment.transform 6 40 env3051 = env3052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3051 == env3052) = true)

theorem identity3052 : scanCanonicalize (H12AffineFastState.compose env3052 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2616) := by decide +kernel

theorem selectedBound3052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3053 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1589,2616,1588,2608,2579,1589,2080,1025,2608,1589,33,17,35,2585,17,2049,1588,1589,2080,1024,1,4,1,1588,512]

theorem envBound3053 : H12AffineFastState.Bounded env3053 := by
  intro p hp
  have h : env3053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3052_3053 : H12AffineEnvironment.transform 12 2616 env3052 = env3053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2616 env3052 == env3053) = true)

theorem identity3053 : scanCanonicalize (H12AffineFastState.compose env3053 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3053 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3054 : List Nat := [2,4,8,1,32,0,40,5,512,1024,2048,1572,2601,1573,2593,2562,1572,2080,1025,2593,1572,33,0,35,2568,0,2049,1573,1572,2080,1024,1,4,1,1573,512]

theorem envBound3054 : H12AffineFastState.Bounded env3054 := by
  intro p hp
  have h : env3054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3053_3054 : H12AffineEnvironment.transform 3 1 env3053 = env3054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3053 == env3054) = true)

def env3055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849104,16385,16892,547953,598058,12644669,525568,545872,8479127,8914924]

theorem envBound3055 : H12AffineFastState.Bounded env3055 := by
  intro p hp
  have h : env3055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2957_3055 : H12AffineEnvironment.transform 27 16385 env2957 = env3055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env2957 == env3055) = true)

def env3056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323792,16385,16892,22641,74794,12644669,256,20560,8479127,8389612]

theorem envBound3056 : H12AffineFastState.Bounded env3056 := by
  intro p hp
  have h : env3056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3055_3056 : H12AffineEnvironment.transform 18 1024 env3055 = env3056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3055 == env3056) = true)

theorem identity3056 : scanCanonicalize (H12AffineFastState.compose env3056 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46528) := by decide +kernel

theorem selectedBound3056 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,46528,8388608,41003,8329,8388688,323792,16385,16892,22641,74794,8406269,256,20560,8479127,8389612]

theorem envBound3057 : H12AffineFastState.Bounded env3057 := by
  intro p hp
  have h : env3057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3056_3057 : H12AffineEnvironment.transform 21 46528 env3056 = env3057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46528 env3056 == env3057) = true)

def env3058 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,46480,8388608,41003,8329,8388608,323712,16385,16812,22561,74794,8406189,256,20480,8479127,8389564]

theorem envBound3058 : H12AffineFastState.Bounded env3058 := by
  intro p hp
  have h : env3058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3057_3058 : H12AffineEnvironment.transform 5 16 env3057 = env3058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3057 == env3058) = true)

def env3059 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4096,46124,8388608,41003,8329,8388608,323712,16385,16400,22561,74794,8406189,188,20480,8478763,8389120]

theorem envBound3059 : H12AffineFastState.Bounded env3059 := by
  intro p hp
  have h : env3059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3058_3059 : H12AffineEnvironment.transform 7 188 env3058 = env3059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3058 == env3059) = true)

theorem identity3059 : scanCanonicalize (H12AffineFastState.compose env3059 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 46109) := by decide +kernel

theorem selectedBound3059 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3060 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4096,46124,46109,41003,8329,46109,323712,16385,16400,22561,74794,61616,188,20480,119862,46621]

theorem envBound3060 : H12AffineFastState.Bounded env3060 := by
  intro p hp
  have h : env3060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3059_3060 : H12AffineEnvironment.transform 22 46109 env3059 = env3060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46109 env3059 == env3060) = true)

def env3061 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,4096,46124,46093,41003,8329,46093,323712,16385,16384,22561,74794,61600,172,20480,119846,46605]

theorem envBound3061 : H12AffineFastState.Bounded env3061 := by
  intro p hp
  have h : env3061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3060_3061 : H12AffineEnvironment.transform 3 0 env3060 = env3061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3060 == env3061) = true)

theorem identity3061 : scanCanonicalize (H12AffineFastState.compose env3061 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound3061 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3062 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,28802,4096,262144,1024,32768,4096,46124,46093,41003,8329,46093,323712,16385,16384,22561,21672,61600,172,20480,42148,46605]

theorem envBound3062 : H12AffineFastState.Bounded env3062 := by
  intro p hp
  have h : env3062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3061_3062 : H12AffineEnvironment.transform 15 28802 env3061 = env3062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env3061 == env3062) = true)

theorem identity3062 : scanCanonicalize (H12AffineFastState.compose env3062 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound3062 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3063 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,16384,32768,25735,1029,262144,1024,32768,1029,41001,40968,41003,8329,40968,320645,16385,16384,19492,16557,58533,172,17413,42148,41480]

theorem envBound3063 : H12AffineFastState.Bounded env3063 := by
  intro p hp
  have h : env3063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3062_3063 : H12AffineEnvironment.transform 11 1029 env3062 = env3063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env3062 == env3063) = true)

theorem identity3063 : scanCanonicalize (H12AffineFastState.compose env3063 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8833) := by decide +kernel

theorem selectedBound3063 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3064 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,16384,8833,25735,1029,262144,1024,8833,1029,680,649,682,8329,649,280068,16385,16384,19492,16557,17956,172,17413,1573,137]

theorem envBound3064 : H12AffineFastState.Bounded env3064 := by
  intro p hp
  have h : env3064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3063_3064 : H12AffineEnvironment.transform 14 8833 env3063 = env3064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8833 env3063 == env3064) = true)

theorem identity3064 : scanCanonicalize (H12AffineFastState.compose env3064 (packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 2560) := by decide +kernel

theorem selectedBound3064 : packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3065 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,16384,8833,25735,1029,2560,1024,8833,1029,680,649,682,8329,649,19460,16385,16384,19492,16557,17956,172,17413,1573,137]

theorem envBound3065 : H12AffineFastState.Bounded env3065 := by
  intro p hp
  have h : env3065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3064_3065 : H12AffineEnvironment.transform 17 2560 env3064 = env3065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2560 env3064 == env3065) = true)

theorem identity3065 : scanCanonicalize (H12AffineFastState.compose env3065 (packedSelected [1,5,6,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 8363) := by decide +kernel

theorem selectedBound3065 : packedSelected [1,5,6,11,12,15] rootPS < 2^1333 := by decide +kernel

def env3066 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,8363,8833,1068,1029,2560,1024,8833,1029,680,649,682,8329,649,11439,8362,8363,11407,8198,9871,172,9390,1573,137]

theorem envBound3066 : H12AffineFastState.Bounded env3066 := by
  intro p hp
  have h : env3066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3065_3066 : H12AffineEnvironment.transform 13 8363 env3065 = env3066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8363 env3065 == env3066) = true)

theorem identity3066 : scanCanonicalize (H12AffineFastState.compose env3066 (packedSelected [0,2,3,4,5,6,7,9,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound3066 : packedSelected [0,2,3,4,5,6,7,9,18] rootPS < 2^1333 := by decide +kernel

def env3067 : List Nat := [2,4,8,0,32,0,128,172,136,1024,2048,1029,8192,8363,8201,1068,1029,2184,1024,8201,1029,32,1,34,8329,1,11439,8362,8363,11407,8198,9223,172,9390,1197,137]

theorem envBound3067 : H12AffineFastState.Bounded env3067 := by
  intro p hp
  have h : env3067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3066_3067 : H12AffineEnvironment.transform 8 136 env3066 = env3067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env3066 == env3067) = true)

theorem identity3067 : scanCanonicalize (H12AffineFastState.compose env3067 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound3067 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3068 : List Nat := [2,4,8,0,32,0,128,172,136,1024,2048,1029,2089,2178,2080,1068,1029,2184,1024,2080,1029,32,1,34,2208,1,1158,2179,2178,1190,2095,3118,172,3207,1197,137]

theorem envBound3068 : H12AffineFastState.Bounded env3068 := by
  intro p hp
  have h : env3068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3067_3068 : H12AffineEnvironment.transform 12 2089 env3067 = env3068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env3067 == env3068) = true)

theorem identity3068 : scanCanonicalize (H12AffineFastState.compose env3068 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3068 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3069 : List Nat := [2,4,8,0,32,0,34,14,42,1024,2048,1029,2089,2080,2080,1068,1029,2090,1024,2080,1029,32,1,34,2050,1,1060,2081,2080,1028,2095,3118,14,3109,1039,43]

theorem envBound3069 : H12AffineFastState.Bounded env3069 := by
  intro p hp
  have h : env3069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3068_3069 : H12AffineEnvironment.transform 6 34 env3068 = env3069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3068 == env3069) = true)

theorem identity3069 : scanCanonicalize (H12AffineFastState.compose env3069 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1067) := by decide +kernel

theorem selectedBound3069 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env3070 : List Nat := [2,4,8,0,32,0,34,14,42,1024,1067,1029,1026,1035,1035,1068,1029,1025,1024,1035,1029,32,1,34,1065,1,1060,1034,1035,1028,1028,5,14,14,1039,43]

theorem envBound3070 : H12AffineFastState.Bounded env3070 := by
  intro p hp
  have h : env3070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3069_3070 : H12AffineEnvironment.transform 10 1067 env3069 = env3070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1067 env3069 == env3070) = true)

theorem identity3070 : scanCanonicalize (H12AffineFastState.compose env3070 (packedSelected [2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound3070 : packedSelected [2,3,7] rootPS < 2^1333 := by decide +kernel

def env3071 : List Nat := [2,4,8,0,14,0,12,14,4,1024,1029,1029,1026,1035,1035,1026,1029,1025,1024,1035,1029,14,1,12,1031,1,1034,1034,1035,1028,1028,5,14,14,1039,5]

theorem envBound3071 : H12AffineFastState.Bounded env3071 := by
  intro p hp
  have h : env3071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3070_3071 : H12AffineEnvironment.transform 4 14 env3070 = env3071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env3070 == env3071) = true)

theorem identity3071 : scanCanonicalize (H12AffineFastState.compose env3071 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3071 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3072 : List Nat := [2,4,8,0,14,0,12,14,4,15,10,10,13,4,4,13,10,14,15,4,10,14,1,12,8,1,5,5,4,11,11,5,14,14,0,5]

theorem envBound3072 : H12AffineFastState.Bounded env3072 := by
  intro p hp
  have h : env3072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3071_3072 : H12AffineEnvironment.transform 9 15 env3071 = env3072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3071 == env3072) = true)

theorem identity3072 : scanCanonicalize (H12AffineFastState.compose env3072 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3072 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env3073 : List Nat := [2,4,3,0,5,0,7,5,4,4,1,1,6,4,4,6,1,5,4,4,1,5,1,7,3,1,5,5,4,0,0,5,5,5,0,5]

theorem envBound3073 : H12AffineFastState.Bounded env3073 := by
  intro p hp
  have h : env3073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3072_3073 : H12AffineEnvironment.transform 2 3 env3072 = env3073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3072 == env3073) = true)

def leafEnv3073 : List Nat := [2,4,3,0,5,0,7,5,4,4,1,1,6,4,4,6,1,5,4,4,1,5,1,7,1,3,1,1,5,5,4,0,0,5,5,5,5,2,0,5,1,4,0]

def active3073 : List Nat := [0,1]

def tree3073 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3073 : H12WitnessSearch.Good tree3073 := H12GlobalWitnessIndex.good

theorem leafIdentity3073 : H12AffineFastState.composeSystem env3073 rootObs = leafEnv3073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3073 rootObs == leafEnv3073) = true)

theorem terminalChecked3073 : H12PackedTerminal.terminalCheckFast leafEnv3073 active3073 tree3073 = true := by decide +kernel

def env3074 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4096,46124,46092,41003,8329,46092,323712,16385,16385,22561,74794,61601,173,20480,119847,46604]

theorem envBound3074 : H12AffineFastState.Bounded env3074 := by
  intro p hp
  have h : env3074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3060_3074 : H12AffineEnvironment.transform 3 1 env3060 = env3074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3060 == env3074) = true)

theorem identity3074 : scanCanonicalize (H12AffineFastState.compose env3074 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3074 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3075 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4096,46124,46092,41003,8224,46092,323625,16385,16385,22561,74794,61448,4,20480,119847,46604]

theorem envBound3075 : H12AffineFastState.Bounded env3075 := by
  intro p hp
  have h : env3075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3074_3075 : H12AffineEnvironment.transform 6 41 env3074 = env3075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3074 == env3075) = true)

theorem identity3075 : scanCanonicalize (H12AffineFastState.compose env3075 (packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound3075 : packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env3076 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53283,4097,262144,1024,32768,4096,46124,46092,41003,8224,46092,323625,16385,16385,22561,62473,61448,4,20480,1028,46604]

theorem envBound3076 : H12AffineFastState.Bounded env3076 := by
  intro p hp
  have h : env3076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3075_3076 : H12AffineEnvironment.transform 15 53283 env3075 = env3076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env3075 == env3076) = true)

theorem identity3076 : scanCanonicalize (H12AffineFastState.compose env3076 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 22529) := by decide +kernel

theorem selectedBound3076 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env3077 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53283,4097,22529,1024,32768,4096,46124,46092,41003,8224,46092,43048,16385,16385,22561,62473,61448,4,20480,1028,46604]

theorem envBound3077 : H12AffineFastState.Bounded env3077 := by
  intro p hp
  have h : env3077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3076_3077 : H12AffineEnvironment.transform 17 22529 env3076 = env3077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22529 env3076 == env3077) = true)

theorem identity3077 : scanCanonicalize (H12AffineFastState.compose env3077 (packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3077 : packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3078 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1551,4096,8192,16384,32768,53283,4097,22030,1024,32768,4096,46124,46092,41003,8224,46092,42535,16385,16385,22062,62473,61448,4,20480,1028,46604]

theorem envBound3078 : H12AffineFastState.Bounded env3078 := by
  intro p hp
  have h : env3078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3077_3078 : H12AffineEnvironment.transform 10 1551 env3077 = env3078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env3077 == env3078) = true)

theorem identity3078 : scanCanonicalize (H12AffineFastState.compose env3078 (packedSelected [0,3,4,5,6,7,9,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3078 : packedSelected [0,3,4,5,6,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env3079 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1551,4096,8192,16384,1582,22029,4097,22030,1024,1582,4096,12802,12834,9733,8224,12834,8201,16385,16385,22062,29223,30246,4,20480,1028,12322]

theorem envBound3079 : H12AffineFastState.Bounded env3079 := by
  intro p hp
  have h : env3079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3078_3079 : H12AffineEnvironment.transform 14 1582 env3078 = env3079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1582 env3078 == env3079) = true)

theorem identity3079 : scanCanonicalize (H12AffineFastState.compose env3079 (packedSelected [2,3,4,8,9,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 8706) := by decide +kernel

theorem selectedBound3079 : packedSelected [2,3,4,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env3080 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1551,4096,8192,8706,1582,13327,4097,13324,1024,1582,4096,12802,12834,9733,8224,12834,8201,8707,8707,13356,4133,5156,4,12802,1028,12322]

theorem envBound3080 : H12AffineFastState.Bounded env3080 := by
  intro p hp
  have h : env3080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3079_3080 : H12AffineEnvironment.transform 13 8706 env3079 = env3080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8706 env3079 == env3080) = true)

theorem identity3080 : scanCanonicalize (H12AffineFastState.compose env3080 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(12+1) ^^^ 1574) := by decide +kernel

theorem selectedBound3080 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env3081 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1551,4096,1574,1060,1582,4649,4097,4650,1024,1582,4096,5156,5124,35,1542,5124,1583,1061,1061,4618,4133,5156,4,5156,1028,5636]

theorem envBound3081 : H12AffineFastState.Bounded env3081 := by
  intro p hp
  have h : env3081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3080_3081 : H12AffineEnvironment.transform 12 1574 env3080 = env3081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1574 env3080 == env3081) = true)

theorem identity3081 : scanCanonicalize (H12AffineFastState.compose env3081 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3081 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3082 : List Nat := [2,4,8,1,32,1,41,4,512,4,523,4096,546,32,554,4649,4097,4650,4,554,4096,4128,4096,35,514,4096,555,33,33,4618,4133,4128,4,4128,0,4608]

theorem envBound3082 : H12AffineFastState.Bounded env3082 := by
  intro p hp
  have h : env3082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3081_3082 : H12AffineEnvironment.transform 9 4 env3081 = env3082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3081 == env3082) = true)

theorem identity3082 : scanCanonicalize (H12AffineFastState.compose env3082 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3082 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env3083 : List Nat := [2,4,8,1,1,1,8,4,512,4,523,4096,515,1,523,4616,4097,4619,4,523,4096,4097,4096,2,514,4096,522,0,0,4618,4100,4097,4,4097,0,4608]

theorem envBound3083 : H12AffineFastState.Bounded env3083 := by
  intro p hp
  have h : env3083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3082_3083 : H12AffineEnvironment.transform 4 1 env3082 = env3083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3082 == env3083) = true)

theorem identity3083 : scanCanonicalize (H12AffineFastState.compose env3083 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound3083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3084 : List Nat := [2,4,8,1,1,1,8,4,10,4,1,4096,9,1,1,4098,4097,4097,4,1,4096,4097,4096,2,8,4096,0,0,0,4096,4100,4097,4,4097,0,4106]

theorem envBound3084 : H12AffineFastState.Bounded env3084 := by
  intro p hp
  have h : env3084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3083_3084 : H12AffineEnvironment.transform 8 10 env3083 = env3084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env3083 == env3084) = true)

theorem identity3084 : scanCanonicalize (H12AffineFastState.compose env3084 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound3084 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3085 : List Nat := [2,4,8,1,1,1,8,4,10,4,1,11,9,1,1,9,10,10,4,1,11,10,11,2,8,11,0,0,0,11,15,10,4,10,0,1]

theorem envBound3085 : H12AffineFastState.Bounded env3085 := by
  intro p hp
  have h : env3085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3084_3085 : H12AffineEnvironment.transform 11 11 env3084 = env3085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env3084 == env3085) = true)

def env3086 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1024,32768,4096,46125,8388608,41003,8329,8388608,323712,16385,16401,22561,74794,8406189,189,20480,8478762,8389121]

theorem envBound3086 : H12AffineFastState.Bounded env3086 := by
  intro p hp
  have h : env3086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3058_3086 : H12AffineEnvironment.transform 7 189 env3058 = env3086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3058 == env3086) = true)

theorem identity3086 : scanCanonicalize (H12AffineFastState.compose env3086 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound3086 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3087 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,53402,4113,262144,1024,32768,4096,46125,8388608,41003,8329,8388608,323712,16385,16401,22561,62640,8406189,189,20480,8433840,8389121]

theorem envBound3087 : H12AffineFastState.Bounded env3087 := by
  intro p hp
  have h : env3087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3086_3087 : H12AffineEnvironment.transform 15 53402 env3086 = env3087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env3086 == env3087) = true)

def env3088 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1024,32768,4096,46125,8388608,41003,8329,8388608,323712,16385,16385,22561,62624,8406189,173,20480,8433824,8389121]

theorem envBound3088 : H12AffineFastState.Bounded env3088 := by
  intro p hp
  have h : env3088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3087_3088 : H12AffineEnvironment.transform 3 0 env3087 = env3088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3087 == env3088) = true)

def env3089 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8352,28714,4097,262144,1024,8352,4096,5261,8388608,139,8329,8388608,282656,16385,16385,22561,21504,8406189,173,20480,8392704,8389121]

theorem envBound3089 : H12AffineFastState.Bounded env3089 := by
  intro p hp
  have h : env3089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3088_3089 : H12AffineEnvironment.transform 14 8352 env3088 = env3089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3088 == env3089) = true)

theorem identity3089 : scanCanonicalize (H12AffineFastState.compose env3089 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound3089 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3090 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8352,28714,4097,2081,1024,8352,4096,5261,8388608,139,8329,8388608,22529,16385,16385,22561,21504,8406189,173,20480,8392704,8389121]

theorem envBound3090 : H12AffineFastState.Bounded env3090 := by
  intro p hp
  have h : env3090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3089_3090 : H12AffineEnvironment.transform 17 2081 env3089 = env3090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env3089 == env3090) = true)

theorem identity3090 : scanCanonicalize (H12AffineFastState.compose env3090 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(22+1) ^^^ 9767) := by decide +kernel

theorem selectedBound3090 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env3091 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8352,28714,4097,2081,1024,8352,4096,5261,9767,139,8329,9767,22529,16385,16385,22561,21504,25226,173,20480,13863,9254]

theorem envBound3091 : H12AffineFastState.Bounded env3091 := by
  intro p hp
  have h : env3091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3090_3091 : H12AffineEnvironment.transform 22 9767 env3090 = env3091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9767 env3090 == env3091) = true)

theorem identity3091 : scanCanonicalize (H12AffineFastState.compose env3091 (packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 7814) := by decide +kernel

theorem selectedBound3091 : packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env3092 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,7814,8352,11948,4097,2081,1024,8352,4096,5261,9767,139,8329,9767,1671,7815,7815,1703,2694,15372,173,3718,13863,9254]

theorem envBound3092 : H12AffineFastState.Bounded env3092 := by
  intro p hp
  have h : env3092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3091_3092 : H12AffineEnvironment.transform 13 7814 env3091 = env3092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7814 env3091 == env3092) = true)

theorem identity3092 : scanCanonicalize (H12AffineFastState.compose env3092 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4642) := by decide +kernel

theorem selectedBound3092 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env3093 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,4642,7814,4738,7310,4097,2081,1024,4738,4096,5261,5125,139,4779,5125,1671,7815,7815,1703,2694,3630,173,3718,1029,5636]

theorem envBound3093 : H12AffineFastState.Bounded env3093 := by
  intro p hp
  have h : env3093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3092_3093 : H12AffineEnvironment.transform 12 4642 env3092 = env3093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4642 env3092 == env3093) = true)

theorem identity3093 : scanCanonicalize (H12AffineFastState.compose env3093 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound3093 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env3094 : List Nat := [2,4,8,0,32,0,128,173,131,1024,2048,4096,4257,7173,4097,7310,4097,2081,1024,4097,4096,5261,5125,139,4136,5125,1028,7172,7172,1060,2053,3245,173,3077,1029,5255]

theorem envBound3094 : H12AffineFastState.Bounded env3094 := by
  intro p hp
  have h : env3094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3093_3094 : H12AffineEnvironment.transform 8 131 env3093 = env3094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env3093 == env3094) = true)

def env3095 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8353,28715,4097,262144,1024,8353,4096,5260,8388608,138,8329,8388608,282657,16385,16385,22561,21505,8406189,173,20480,8392705,8389121]

theorem envBound3095 : H12AffineFastState.Bounded env3095 := by
  intro p hp
  have h : env3095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3088_3095 : H12AffineEnvironment.transform 14 8353 env3088 = env3095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3088 == env3095) = true)

theorem identity3095 : scanCanonicalize (H12AffineFastState.compose env3095 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound3095 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3096 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8353,28715,4097,19493,1024,8353,4096,5260,8388608,138,8329,8388608,7172,16385,16385,22561,21505,8406189,173,20480,8392705,8389121]

theorem envBound3096 : H12AffineFastState.Bounded env3096 := by
  intro p hp
  have h : env3096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3095_3096 : H12AffineEnvironment.transform 17 19493 env3095 = env3096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env3095 == env3096) = true)

theorem identity3096 : scanCanonicalize (H12AffineFastState.compose env3096 (packedSelected [2,3,5,6,10,13,17,21] rootPS)) = affineNative (2^(12+1) ^^^ 2219) := by decide +kernel

theorem selectedBound3096 : packedSelected [2,3,5,6,10,13,17,21] rootPS < 2^1333 := by decide +kernel

def env3097 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,2219,16384,2058,22656,4097,19493,1024,2058,4096,5260,8388608,138,2082,8388608,7172,16385,16385,22561,21505,8406189,173,20480,8392705,8389121]

theorem envBound3097 : H12AffineFastState.Bounded env3097 := by
  intro p hp
  have h : env3097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3096_3097 : H12AffineEnvironment.transform 12 2219 env3096 = env3097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2219 env3096 == env3097) = true)

theorem identity3097 : scanCanonicalize (H12AffineFastState.compose env3097 (packedSelected [2,4,9,11,20,23] rootPS)) = affineNative (2^(22+1) ^^^ 5293) := by decide +kernel

theorem selectedBound3097 : packedSelected [2,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env3098 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,2219,16384,2058,22656,4097,19493,1024,2058,4096,5260,5293,138,2082,5293,7172,16385,16385,22561,21505,20480,173,20480,1196,5804]

theorem envBound3098 : H12AffineFastState.Bounded env3098 := by
  intro p hp
  have h : env3098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3097_3098 : H12AffineEnvironment.transform 22 5293 env3097 = env3098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5293 env3097 == env3098) = true)

theorem identity3098 : scanCanonicalize (H12AffineFastState.compose env3098 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 2722) := by decide +kernel

theorem selectedBound3098 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3099 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,2219,2722,2058,4642,4097,1671,1024,2058,4096,5260,5293,138,2082,5293,7172,2723,2723,4739,7843,6818,173,6818,1196,5804]

theorem envBound3099 : H12AffineFastState.Bounded env3099 := by
  intro p hp
  have h : env3099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3098_3099 : H12AffineEnvironment.transform 13 2722 env3098 = env3099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2722 env3098 == env3099) = true)

theorem identity3099 : scanCanonicalize (H12AffineFastState.compose env3099 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound3099 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env3100 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,649,2219,2722,2058,171,648,1671,1024,2058,649,1541,1572,138,2082,1572,3725,2723,2723,10,3114,2091,173,2091,1196,1061]

theorem envBound3100 : H12AffineFastState.Bounded env3100 := by
  intro p hp
  have h : env3100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3099_3100 : H12AffineEnvironment.transform 11 649 env3099 = env3100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env3099 == env3100) = true)

theorem identity3100 : scanCanonicalize (H12AffineFastState.compose env3100 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3100 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env3101 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,545,2051,2570,2058,3,544,1583,1024,2058,545,1541,1572,34,2082,1572,3621,2571,2571,10,3114,2091,5,2091,1028,1061]

theorem envBound3101 : H12AffineFastState.Bounded env3101 := by
  intro p hp
  have h : env3101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3100_3101 : H12AffineEnvironment.transform 6 40 env3100 = env3101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3100 == env3101) = true)

theorem identity3101 : scanCanonicalize (H12AffineFastState.compose env3101 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound3101 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3102 : List Nat := [2,4,8,0,32,0,40,5,512,1024,43,545,40,545,33,3,544,1583,1024,33,545,1541,1572,34,9,1572,1550,544,544,10,1025,0,5,0,1028,1061]

theorem envBound3102 : H12AffineFastState.Bounded env3102 := by
  intro p hp
  have h : env3102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3101_3102 : H12AffineEnvironment.transform 10 43 env3101 = env3102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env3101 == env3102) = true)

theorem identity3102 : scanCanonicalize (H12AffineFastState.compose env3102 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3102 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3103 : List Nat := [2,4,8,0,32,0,40,5,512,5,43,545,40,545,33,3,544,554,5,33,545,512,545,34,9,545,523,544,544,10,4,0,5,0,1,32]

theorem envBound3103 : H12AffineFastState.Bounded env3103 := by
  intro p hp
  have h : env3103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3102_3103 : H12AffineEnvironment.transform 9 5 env3102 = env3103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3102 == env3103) = true)

theorem identity3103 : scanCanonicalize (H12AffineFastState.compose env3103 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound3103 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3104 : List Nat := [2,4,8,0,32,0,40,5,32,5,43,1,40,1,33,3,0,10,5,33,1,32,1,34,9,1,43,0,0,10,4,0,5,0,1,32]

theorem envBound3104 : H12AffineFastState.Bounded env3104 := by
  intro p hp
  have h : env3104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3103_3104 : H12AffineEnvironment.transform 8 32 env3103 = env3104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3103 == env3104) = true)

theorem identity3104 : scanCanonicalize (H12AffineFastState.compose env3104 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3105 : List Nat := [2,4,3,0,32,0,35,5,32,5,32,1,35,1,33,3,0,1,5,33,1,32,1,34,2,1,32,0,0,1,4,0,5,0,1,32]

theorem envBound3105 : H12AffineFastState.Bounded env3105 := by
  intro p hp
  have h : env3105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3104_3105 : H12AffineEnvironment.transform 2 3 env3104 = env3105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3104 == env3105) = true)

theorem identity3105 : scanCanonicalize (H12AffineFastState.compose env3105 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3105 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3106 : List Nat := [2,4,3,0,1,0,2,5,1,5,1,1,2,1,0,3,0,1,5,0,1,1,1,3,2,1,1,0,0,1,4,0,5,0,1,1]

theorem envBound3106 : H12AffineFastState.Bounded env3106 := by
  intro p hp
  have h : env3106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3105_3106 : H12AffineEnvironment.transform 4 1 env3105 = env3106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3105 == env3106) = true)

def env3107 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1024,32768,4096,46125,8388608,41003,8329,8388608,323712,16385,16384,22561,62625,8406189,172,20480,8433825,8389121]

theorem envBound3107 : H12AffineFastState.Bounded env3107 := by
  intro p hp
  have h : env3107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3087_3107 : H12AffineEnvironment.transform 3 1 env3087 = env3107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3087 == env3107) = true)

theorem identity3107 : scanCanonicalize (H12AffineFastState.compose env3107 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5293) := by decide +kernel

theorem selectedBound3107 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3108 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1024,32768,4096,46125,5293,41003,8329,5293,323712,16385,16384,22561,62625,20480,172,20480,41996,5804]

theorem envBound3108 : H12AffineFastState.Bounded env3108 := by
  intro p hp
  have h : env3108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3107_3108 : H12AffineEnvironment.transform 22 5293 env3107 = env3108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5293 env3107 == env3108) = true)

theorem identity3108 : scanCanonicalize (H12AffineFastState.compose env3108 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3108 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3109 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53282,4096,262144,1024,32768,4096,46125,5124,41003,8224,5124,323625,16385,16384,22561,62472,20480,5,20480,41996,5637]

theorem envBound3109 : H12AffineFastState.Bounded env3109 := by
  intro p hp
  have h : env3109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3108_3109 : H12AffineEnvironment.transform 6 41 env3108 = env3109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3108 == env3109) = true)

theorem identity3109 : scanCanonicalize (H12AffineFastState.compose env3109 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound3109 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3110 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53282,4096,43049,1024,32768,4096,46125,5124,41003,8224,5124,22528,16385,16384,22561,62472,20480,5,20480,41996,5637]

theorem envBound3110 : H12AffineFastState.Bounded env3110 := by
  intro p hp
  have h : env3110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3109_3110 : H12AffineEnvironment.transform 17 43049 env3109 = env3110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env3109 == env3110) = true)

theorem identity3110 : scanCanonicalize (H12AffineFastState.compose env3110 (packedSelected [1,2,3,4,5,6,7,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 13356) := by decide +kernel

theorem selectedBound3110 : packedSelected [1,2,3,4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3111 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,16384,13356,25614,4096,7173,1024,13356,4096,1,5124,5127,8224,5124,22528,16385,16384,22561,16420,20480,5,20480,4128,5637]

theorem envBound3111 : H12AffineFastState.Bounded env3111 := by
  intro p hp
  have h : env3111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3110_3111 : H12AffineEnvironment.transform 14 13356 env3110 = env3111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13356 env3110 == env3111) = true)

theorem identity3111 : scanCanonicalize (H12AffineFastState.compose env3111 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4619) := by decide +kernel

theorem selectedBound3111 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env3112 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,4619,13356,13829,4096,7173,1024,13356,4096,1,5124,5127,8224,5124,2571,4618,4619,2602,4655,523,5,523,4128,5637]

theorem envBound3112 : H12AffineFastState.Bounded env3112 := by
  intro p hp
  have h : env3112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3111_3112 : H12AffineEnvironment.transform 13 4619 env3111 = env3112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4619 env3111 == env3112) = true)

theorem identity3112 : scanCanonicalize (H12AffineFastState.compose env3112 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2571) := by decide +kernel

theorem selectedBound3112 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env3113 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,2571,8192,2048,11815,11278,2571,1550,1024,11815,2571,1,3599,3596,8224,3599,2571,2049,2048,2602,2084,523,5,523,2603,3086]

theorem envBound3113 : H12AffineFastState.Bounded env3113 := by
  intro p hp
  have h : env3113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3112_3113 : H12AffineEnvironment.transform 11 2571 env3112 = env3113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2571 env3112 == env3113) = true)

theorem identity3113 : scanCanonicalize (H12AffineFastState.compose env3113 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound3113 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env3114 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,2571,1069,2048,2570,2083,2571,1550,1024,2570,2571,1,3599,3596,1037,3599,2571,2049,2048,2602,2084,523,5,523,2603,3086]

theorem envBound3114 : H12AffineFastState.Bounded env3114 := by
  intro p hp
  have h : env3114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3113_3114 : H12AffineEnvironment.transform 12 1069 env3113 = env3114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env3113 == env3114) = true)

theorem identity3114 : scanCanonicalize (H12AffineFastState.compose env3114 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3114 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3115 : List Nat := [2,4,8,1,32,1,41,5,512,14,2048,2571,35,2048,2570,2083,2571,512,14,2570,2571,1,2561,2562,3,2561,2571,2049,2048,2602,2084,523,5,523,2603,2048]

theorem envBound3115 : H12AffineFastState.Bounded env3115 := by
  intro p hp
  have h : env3115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3114_3115 : H12AffineEnvironment.transform 9 14 env3114 = env3115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3114 == env3115) = true)

theorem identity3115 : scanCanonicalize (H12AffineFastState.compose env3115 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3115 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env3116 : List Nat := [2,4,8,1,1,1,8,5,512,14,2048,2571,2,2048,2570,2050,2571,512,14,2570,2571,1,2561,2562,3,2561,2571,2049,2048,2571,2053,523,5,523,2570,2048]

theorem envBound3116 : H12AffineFastState.Bounded env3116 := by
  intro p hp
  have h : env3116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3115_3116 : H12AffineEnvironment.transform 4 1 env3115 = env3116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3115 == env3116) = true)

def env3117 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46481,8388608,41003,8329,8388609,323713,16385,16813,22560,74794,8406188,256,20481,8479127,8389565]

theorem envBound3117 : H12AffineFastState.Bounded env3117 := by
  intro p hp
  have h : env3117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3057_3117 : H12AffineEnvironment.transform 5 17 env3057 = env3117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3057 == env3117) = true)

theorem identity3117 : scanCanonicalize (H12AffineFastState.compose env3117 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3117 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3118 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46481,445,41003,8329,444,323713,16385,16813,22560,74794,17681,256,20481,90154,512]

theorem envBound3118 : H12AffineFastState.Bounded env3118 := by
  intro p hp
  have h : env3118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3117_3118 : H12AffineEnvironment.transform 22 445 env3117 = env3118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3117 == env3118) = true)

theorem identity3118 : scanCanonicalize (H12AffineFastState.compose env3118 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound3118 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3119 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1024,32768,1045,41348,445,41003,8329,444,320660,16385,16813,19509,74794,17681,256,17428,90154,512]

theorem envBound3119 : H12AffineFastState.Bounded env3119 := by
  intro p hp
  have h : env3119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3118_3119 : H12AffineEnvironment.transform 11 1045 env3118 = env3119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env3118 == env3119) = true)

theorem identity3119 : scanCanonicalize (H12AffineFastState.compose env3119 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33710) := by decide +kernel

theorem selectedBound3119 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3120 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,33710,1464,262144,1024,32768,1045,41348,445,41003,8329,444,320660,16385,16813,19509,42884,17681,256,17428,58244,512]

theorem envBound3120 : H12AffineFastState.Bounded env3120 := by
  intro p hp
  have h : env3120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3119_3120 : H12AffineEnvironment.transform 15 33710 env3119 = env3120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33710 env3119 == env3120) = true)

theorem identity3120 : scanCanonicalize (H12AffineFastState.compose env3120 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3120 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25750,1464,262144,1024,26424,1045,18108,445,18195,8329,444,263084,16385,16813,19509,16572,17681,256,17428,1212,512]

theorem envBound3121 : H12AffineFastState.Bounded env3121 := by
  intro p hp
  have h : env3121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3120_3121 : H12AffineEnvironment.transform 14 26424 env3120 = env3121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3120 == env3121) = true)

theorem identity3121 : scanCanonicalize (H12AffineFastState.compose env3121 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound3121 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25750,1464,20156,1024,26424,1045,18108,445,18195,8329,444,19728,16385,16813,19509,16572,17681,256,17428,1212,512]

theorem envBound3122 : H12AffineFastState.Bounded env3122 := by
  intro p hp
  have h : env3122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3121_3122 : H12AffineEnvironment.transform 17 20156 env3121 = env3122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env3121 == env3122) = true)

theorem identity3122 : scanCanonicalize (H12AffineFastState.compose env3122 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound3122 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env3123 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,1840,8200,9126,1464,2444,1024,8200,1045,396,445,35,8329,444,2592,1841,1693,2821,1932,545,256,804,1212,512]

theorem envBound3123 : H12AffineFastState.Bounded env3123 := by
  intro p hp
  have h : env3123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3122_3123 : H12AffineEnvironment.transform 13 1840 env3122 = env3123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env3122 == env3123) = true)

theorem identity3123 : scanCanonicalize (H12AffineFastState.compose env3123 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3123 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env3124 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1045,8192,1692,8200,8714,1044,2080,1024,8200,1045,32,17,35,8329,16,2592,1693,1693,2729,1568,545,172,648,1212,512]

theorem envBound3124 : H12AffineFastState.Bounded env3124 := by
  intro p hp
  have h : env3124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3123_3124 : H12AffineEnvironment.transform 7 172 env3123 = env3124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3123 == env3124) = true)

theorem identity3124 : scanCanonicalize (H12AffineFastState.compose env3124 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3124 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3125 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1551,1045,8192,1692,8200,8714,1044,1583,1024,8200,1045,32,17,35,8329,16,1071,1693,1693,1190,1568,545,172,648,1212,512]

theorem envBound3125 : H12AffineFastState.Bounded env3125 := by
  intro p hp
  have h : env3125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3124_3125 : H12AffineEnvironment.transform 10 1551 env3124 = env3125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env3124 == env3125) = true)

theorem identity3125 : scanCanonicalize (H12AffineFastState.compose env3125 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1199) := by decide +kernel

theorem selectedBound3125 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env3126 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1551,1045,1199,1692,1191,1701,1044,1583,1024,1191,1045,32,17,35,1062,16,1071,1693,1693,1190,1568,545,172,648,1212,512]

theorem envBound3126 : H12AffineFastState.Bounded env3126 := by
  intro p hp
  have h : env3126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3125_3126 : H12AffineEnvironment.transform 12 1199 env3125 = env3126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1199 env3125 == env3126) = true)

theorem identity3126 : scanCanonicalize (H12AffineFastState.compose env3126 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound3126 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env3127 : List Nat := [2,4,8,16,32,17,128,172,512,135,648,146,40,539,32,546,147,680,135,32,146,32,17,35,161,16,168,538,538,33,679,545,172,648,59,512]

theorem envBound3127 : H12AffineFastState.Bounded env3127 := by
  intro p hp
  have h : env3127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3126_3127 : H12AffineEnvironment.transform 9 135 env3126 = env3127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env3126 == env3127) = true)

theorem identity3127 : scanCanonicalize (H12AffineFastState.compose env3127 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3127 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env3128 : List Nat := [2,4,8,10,32,11,128,172,512,135,648,136,40,513,32,546,137,680,135,32,136,32,11,35,161,10,168,512,512,33,679,545,172,648,33,512]

theorem envBound3128 : H12AffineFastState.Bounded env3128 := by
  intro p hp
  have h : env3128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3127_3128 : H12AffineEnvironment.transform 3 10 env3127 = env3128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3127 == env3128) = true)

def env3129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323793,16385,16892,22640,74795,12644669,257,20561,8479127,8389613]

theorem envBound3129 : H12AffineFastState.Bounded env3129 := by
  intro p hp
  have h : env3129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3055_3129 : H12AffineEnvironment.transform 18 1025 env3055 = env3129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3055 == env3129) = true)

theorem identity3129 : scanCanonicalize (H12AffineFastState.compose env3129 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255937) := by decide +kernel

theorem selectedBound3129 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,4255937,41003,8329,4255888,323793,16385,16892,22640,74795,508,257,20561,4297046,4256556]

theorem envBound3130 : H12AffineFastState.Bounded env3130 := by
  intro p hp
  have h : env3130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3129_3130 : H12AffineEnvironment.transform 22 4255937 env3129 = env3130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255937 env3129 == env3130) = true)

def env3131 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,4255889,41003,8329,4255888,323713,16385,16812,22560,74795,428,257,20481,4296966,4256556]

theorem envBound3131 : H12AffineFastState.Bounded env3131 := by
  intro p hp
  have h : env3131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3130_3131 : H12AffineEnvironment.transform 5 16 env3130 = env3131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3130 == env3131) = true)

theorem identity3131 : scanCanonicalize (H12AffineFastState.compose env3131 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61740) := by decide +kernel

theorem selectedBound3131 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3132 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,61740,445,41003,8329,444,323713,16385,16812,22560,74795,428,257,20481,90154,512]

theorem envBound3132 : H12AffineFastState.Bounded env3132 := by
  intro p hp
  have h : env3132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3131_3132 : H12AffineEnvironment.transform 21 61740 env3131 = env3132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61740 env3131 == env3132) = true)

theorem identity3132 : scanCanonicalize (H12AffineFastState.compose env3132 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound3132 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3133 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1025,32768,4096,41349,445,41003,8329,444,303144,4264,4357,2185,74795,428,257,168,77955,512]

theorem envBound3133 : H12AffineFastState.Bounded env3133 := by
  intro p hp
  have h : env3133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3132_3133 : H12AffineEnvironment.transform 13 4265 env3132 = env3133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3132 == env3133) = true)

theorem identity3133 : scanCanonicalize (H12AffineFastState.compose env3133 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3133 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3134 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,38843,4524,262144,1025,32768,4096,41349,445,41003,8329,444,303144,4264,4357,2185,45968,428,257,168,42808,512]

theorem envBound3134 : H12AffineFastState.Bounded env3134 := by
  intro p hp
  have h : env3134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3133_3134 : H12AffineEnvironment.transform 15 38843 env3133 = env3134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3133 == env3134) = true)

theorem identity3134 : scanCanonicalize (H12AffineFastState.compose env3134 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14225) := by decide +kernel

theorem selectedBound3134 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3135 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8234,4524,262144,1025,14225,4096,5652,445,6074,8329,444,268217,4264,4357,2185,1025,428,257,168,4265,512]

theorem envBound3135 : H12AffineFastState.Bounded env3135 := by
  intro p hp
  have h : env3135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3134_3135 : H12AffineEnvironment.transform 14 14225 env3134 = env3135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14225 env3134 == env3135) = true)

theorem identity3135 : scanCanonicalize (H12AffineFastState.compose env3135 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound3135 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3136 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8234,4524,2445,1025,14225,4096,5652,445,6074,8329,444,7732,4264,4357,2185,1025,428,257,168,4265,512]

theorem envBound3136 : H12AffineFastState.Bounded env3136 := by
  intro p hp
  have h : env3136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3135_3136 : H12AffineEnvironment.transform 17 2445 env3135 = env3136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env3135 == env3136) = true)

theorem identity3136 : scanCanonicalize (H12AffineFastState.compose env3136 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3136 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env3137 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4265,13885,8234,4096,2081,1025,13885,4096,5652,17,5654,8329,16,7732,4264,4265,2185,1025,0,173,168,4265,512]

theorem envBound3137 : H12AffineFastState.Bounded env3137 := by
  intro p hp
  have h : env3137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3136_3137 : H12AffineEnvironment.transform 7 172 env3136 = env3137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3136 == env3137) = true)

theorem identity3137 : scanCanonicalize (H12AffineFastState.compose env3137 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound3137 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3138 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,4096,8192,4265,13885,8234,4096,642,1025,13885,4096,5652,17,5654,8329,16,5271,4264,4265,554,1025,0,173,168,4265,512]

theorem envBound3138 : H12AffineFastState.Bounded env3138 := by
  intro p hp
  have h : env3138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3137_3138 : H12AffineEnvironment.transform 10 675 env3137 = env3138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env3137 == env3138) = true)

theorem identity3138 : scanCanonicalize (H12AffineFastState.compose env3138 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3138 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3139 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,1693,8192,1588,8352,8234,1693,642,1025,8352,1693,137,17,139,8329,16,522,1589,1588,554,1025,0,173,168,1588,512]

theorem envBound3139 : H12AffineFastState.Bounded env3139 := by
  intro p hp
  have h : env3139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3138_3139 : H12AffineEnvironment.transform 11 1693 env3138 = env3139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3138 == env3139) = true)

theorem identity3139 : scanCanonicalize (H12AffineFastState.compose env3139 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound3139 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3140 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,1693,19,1588,179,57,1693,642,1025,179,1693,137,17,139,154,16,522,1589,1588,554,1025,0,173,168,1588,512]

theorem envBound3140 : H12AffineFastState.Bounded env3140 := by
  intro p hp
  have h : env3140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3139_3140 : H12AffineEnvironment.transform 12 19 env3139 = env3140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env3139 == env3140) = true)

theorem identity3140 : scanCanonicalize (H12AffineFastState.compose env3140 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3140 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3141 : List Nat := [2,4,8,16,32,16,41,5,512,1024,522,1588,19,1588,26,57,1588,555,1025,26,1588,32,17,34,51,16,522,1589,1588,554,1025,0,4,1,1588,512]

theorem envBound3141 : H12AffineFastState.Bounded env3141 := by
  intro p hp
  have h : env3141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3140_3141 : H12AffineEnvironment.transform 6 41 env3140 = env3141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3140 == env3141) = true)

theorem identity3141 : scanCanonicalize (H12AffineFastState.compose env3141 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound3141 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3142 : List Nat := [2,4,8,16,17,16,24,5,512,1024,522,1541,19,1541,26,8,1541,538,1025,26,1541,17,17,19,2,16,522,1540,1541,539,1025,0,4,1,1541,512]

theorem envBound3142 : H12AffineFastState.Bounded env3142 := by
  intro p hp
  have h : env3142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3141_3142 : H12AffineEnvironment.transform 4 17 env3141 = env3142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env3141 == env3142) = true)

theorem identity3142 : scanCanonicalize (H12AffineFastState.compose env3142 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3142 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env3143 : List Nat := [2,4,2,16,17,16,18,5,512,1024,512,1541,19,1541,16,2,1541,528,1025,16,1541,17,17,19,2,16,512,1540,1541,529,1025,0,4,1,1541,512]

theorem envBound3143 : H12AffineFastState.Bounded env3143 := by
  intro p hp
  have h : env3143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3142_3143 : H12AffineEnvironment.transform 2 2 env3142 = env3143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3142 == env3143) = true)

theorem identity3143 : scanCanonicalize (H12AffineFastState.compose env3143 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3143 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3144 : List Nat := [2,4,2,0,1,0,2,5,512,1024,512,1541,3,1541,0,2,1541,512,1025,0,1541,1,1,3,2,0,512,1540,1541,513,1025,0,4,1,1541,512]

theorem envBound3144 : H12AffineFastState.Bounded env3144 := by
  intro p hp
  have h : env3144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3143_3144 : H12AffineEnvironment.transform 3 0 env3143 = env3144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3143 == env3144) = true)

theorem identity3144 : scanCanonicalize (H12AffineFastState.compose env3144 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3145 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1028,3,1028,0,2,1028,1,1025,0,1028,1,1,3,2,0,1,1029,1028,0,1025,0,4,1,1028,1]

theorem envBound3145 : H12AffineFastState.Bounded env3145 := by
  intro p hp
  have h : env3145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3144_3145 : H12AffineEnvironment.transform 8 1 env3144 = env3145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3144 == env3145) = true)

def leafEnv3145 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1028,3,1028,0,2,1028,1,1025,0,1028,1,1,3,1024,2,1,0,1,1029,1028,0,1025,0,4,1,5,2,1028,1,1,1029,0]

def active3145 : List Nat := [0,1,9]

def tree3145 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3145 : H12WitnessSearch.Good tree3145 := H12GlobalWitnessIndex.good

theorem leafIdentity3145 : H12AffineFastState.composeSystem env3145 rootObs = leafEnv3145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3145 rootObs == leafEnv3145) = true)

theorem terminalChecked3145 : H12PackedTerminal.terminalCheckFast leafEnv3145 active3145 tree3145 = true := by decide +kernel

def env3146 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,4255888,41003,8329,4255888,323712,16385,16813,22561,74795,429,257,20480,4296967,4256556]

theorem envBound3146 : H12AffineFastState.Bounded env3146 := by
  intro p hp
  have h : env3146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3130_3146 : H12AffineEnvironment.transform 5 17 env3130 = env3146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3130 == env3146) = true)

def env3147 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4096,4194304,4255888,41003,8329,4255888,323712,16385,16401,22561,74795,17,189,20480,4296891,4256400]

theorem envBound3147 : H12AffineFastState.Bounded env3147 := by
  intro p hp
  have h : env3147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3146_3147 : H12AffineEnvironment.transform 7 188 env3146 = env3147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3146 == env3147) = true)

theorem identity3147 : scanCanonicalize (H12AffineFastState.compose env3147 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 28833) := by decide +kernel

theorem selectedBound3147 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3148 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28833,65536,4113,262144,1025,28833,4096,4194304,4194353,20618,8329,4194353,262177,16385,16401,22561,74795,17,189,20480,4284442,4194865]

theorem envBound3148 : H12AffineFastState.Bounded env3148 := by
  intro p hp
  have h : env3148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3147_3148 : H12AffineEnvironment.transform 14 28833 env3147 = env3148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28833 env3147 == env3148) = true)

def env3149 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28833,65536,4113,262144,1025,28833,4096,20512,20497,20618,8329,20497,262177,16385,16401,22561,74795,17,189,20480,77882,21009]

theorem envBound3149 : H12AffineFastState.Bounded env3149 := by
  intro p hp
  have h : env3149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3148_3149 : H12AffineEnvironment.transform 21 20512 env3148 = env3149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20512 env3148 == env3149) = true)

theorem identity3149 : scanCanonicalize (H12AffineFastState.compose env3149 (packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound3149 : packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3150 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,1676,13869,65536,4113,262144,1025,13869,4096,5804,5789,5638,8329,5789,262177,1677,1693,7853,74795,17,189,5772,77882,5277]

theorem envBound3150 : H12AffineFastState.Bounded env3150 := by
  intro p hp
  have h : env3150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3149_3150 : H12AffineEnvironment.transform 13 1676 env3149 = env3150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env3149 == env3150) = true)

theorem identity3150 : scanCanonicalize (H12AffineFastState.compose env3150 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound3150 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3151 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,8192,1588,13869,65536,4113,262144,1025,13869,4096,5652,5669,5638,8241,5669,262177,1589,1573,7701,74795,17,5,5684,77882,5157]

theorem envBound3151 : H12AffineFastState.Bounded env3151 := by
  intro p hp
  have h : env3151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3150_3151 : H12AffineEnvironment.transform 6 56 env3150 = env3151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3150 == env3151) = true)

theorem identity3151 : scanCanonicalize (H12AffineFastState.compose env3151 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13839) := by decide +kernel

theorem selectedBound3151 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3152 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,8192,1588,13869,13839,4113,262144,1025,13869,4096,5652,5669,5638,8241,5669,262177,1589,1573,7701,4644,17,5,5684,1589,5157]

theorem envBound3152 : H12AffineFastState.Bounded env3152 := by
  intro p hp
  have h : env3152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3151_3152 : H12AffineEnvironment.transform 15 13839 env3151 = env3152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13839 env3151 == env3152) = true)

theorem identity3152 : scanCanonicalize (H12AffineFastState.compose env3152 (packedSelected [1,2,5,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 15398) := by decide +kernel

theorem selectedBound3152 : packedSelected [1,2,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3153 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,8192,1588,13869,13839,4113,15398,1025,13869,4096,5652,5669,5638,8241,5669,15367,1589,1573,7701,4644,17,5,5684,1589,5157]

theorem envBound3153 : H12AffineFastState.Bounded env3153 := by
  intro p hp
  have h : env3153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3152_3153 : H12AffineEnvironment.transform 17 15398 env3152 = env3153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 15398 env3152 == env3153) = true)

theorem identity3153 : scanCanonicalize (H12AffineFastState.compose env3153 (packedSelected [1,2,5,6,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 562) := by decide +kernel

theorem selectedBound3153 : packedSelected [1,2,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env3154 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,562,1588,5151,5181,4113,7700,1025,5151,4096,5652,5669,5638,515,5669,7733,1589,1573,7701,4644,17,5,5684,1589,5157]

theorem envBound3154 : H12AffineFastState.Bounded env3154 := by
  intro p hp
  have h : env3154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3153_3154 : H12AffineEnvironment.transform 12 562 env3153 = env3154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 562 env3153 == env3154) = true)

def env3155 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28833,65536,4113,262144,1025,28833,4096,20513,20496,20618,8329,20496,262177,16385,16401,22561,74795,17,189,20480,77883,21008]

theorem envBound3155 : H12AffineFastState.Bounded env3155 := by
  intro p hp
  have h : env3155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3148_3155 : H12AffineEnvironment.transform 21 20513 env3148 = env3155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20513 env3148 == env3155) = true)

theorem identity3155 : scanCanonicalize (H12AffineFastState.compose env3155 (packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 26143) := by decide +kernel

theorem selectedBound3155 : packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3156 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28833,26143,4113,262144,1025,28833,4096,20513,20496,20618,8329,20496,262177,16385,16401,22561,16948,17,189,20480,22052,21008]

theorem envBound3156 : H12AffineFastState.Bounded env3156 := by
  intro p hp
  have h : env3156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3155_3156 : H12AffineEnvironment.transform 15 26143 env3155 = env3156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26143 env3155 == env3156) = true)

theorem identity3156 : scanCanonicalize (H12AffineFastState.compose env3156 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound3156 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3157 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4265,8200,14006,4113,262144,1025,8200,4096,136,185,35,8329,185,262177,4264,4280,2184,4765,17,189,169,1677,697]

theorem envBound3157 : H12AffineFastState.Bounded env3157 := by
  intro p hp
  have h : env3157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3156_3157 : H12AffineEnvironment.transform 13 4265 env3156 = env3157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3156 == env3157) = true)

theorem identity3157 : scanCanonicalize (H12AffineFastState.compose env3157 (packedSelected [0,2,3,5,7,10,11,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound3157 : packedSelected [0,2,3,5,7,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env3158 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4265,8200,14006,4113,7700,1025,8200,4096,136,185,35,8329,185,7733,4264,4280,2184,4765,17,189,169,1677,697]

theorem envBound3158 : H12AffineFastState.Bounded env3158 := by
  intro p hp
  have h : env3158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3157_3158 : H12AffineEnvironment.transform 17 7700 env3157 = env3158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env3157 == env3158) = true)

theorem identity3158 : scanCanonicalize (H12AffineFastState.compose env3158 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3158 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env3159 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1573,8192,1676,8200,8339,1588,2097,1025,8200,1573,136,185,35,8329,185,2064,1677,1693,2184,1208,17,189,169,1677,697]

theorem envBound3159 : H12AffineFastState.Bounded env3159 := by
  intro p hp
  have h : env3159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3158_3159 : H12AffineEnvironment.transform 11 1573 env3158 = env3159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env3158 == env3159) = true)

theorem identity3159 : scanCanonicalize (H12AffineFastState.compose env3159 (packedSelected [6,13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3159 : packedSelected [6,13] rootPS < 2^1333 := by decide +kernel

def env3160 : List Nat := [2,4,8,16,32,17,34,30,512,1024,2048,1573,8192,1582,8200,8241,1588,2097,1025,8200,1573,42,27,35,8235,27,2064,1583,1599,2090,1050,17,31,11,1583,539]

theorem envBound3160 : H12AffineFastState.Bounded env3160 := by
  intro p hp
  have h : env3160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3159_3160 : H12AffineEnvironment.transform 6 34 env3159 = env3160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3159 == env3160) = true)

theorem identity3160 : scanCanonicalize (H12AffineFastState.compose env3160 (packedSelected [8,10,28] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3160 : packedSelected [8,10,28] rootPS < 2^1333 := by decide +kernel

def env3161 : List Nat := [2,4,8,1,32,0,34,15,512,1024,2048,1573,8192,1582,8200,8224,1573,2080,1025,8200,1573,42,10,35,8235,10,2049,1583,1582,2090,1035,0,14,11,1583,522]

theorem envBound3161 : H12AffineFastState.Bounded env3161 := by
  intro p hp
  have h : env3161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3160_3161 : H12AffineEnvironment.transform 3 1 env3160 = env3161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3160 == env3161) = true)

theorem identity3161 : scanCanonicalize (H12AffineFastState.compose env3161 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2594) := by decide +kernel

theorem selectedBound3161 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env3162 : List Nat := [2,4,8,1,32,0,34,15,512,1024,2048,1573,2594,1582,2602,2562,1573,2080,1025,2602,1573,42,10,35,2569,10,2049,1583,1582,2090,1035,0,14,11,1583,522]

theorem envBound3162 : H12AffineFastState.Bounded env3162 := by
  intro p hp
  have h : env3162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3161_3162 : H12AffineEnvironment.transform 12 2594 env3161 = env3162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2594 env3161 == env3162) = true)

def env3163 : List Nat := [2,4,8,1,32,0,34,15,512,1024,1540,1573,1062,1582,1070,1030,1573,1572,1025,1070,1573,42,10,35,1037,10,1541,1583,1582,1582,1035,0,14,11,1583,522]

theorem envBound3163 : H12AffineFastState.Bounded env3163 := by
  intro p hp
  have h : env3163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3162_3163 : H12AffineEnvironment.transform 10 1540 env3162 = env3163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env3162 == env3163) = true)

theorem identity3163 : scanCanonicalize (H12AffineFastState.compose env3163 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3164 : List Nat := [2,4,2,1,32,0,34,5,512,1024,1540,1573,1062,1572,1060,1030,1573,1572,1025,1060,1573,32,0,35,1031,0,1541,1573,1572,1572,1025,0,4,1,1573,512]

theorem envBound3164 : H12AffineFastState.Bounded env3164 := by
  intro p hp
  have h : env3164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3163_3164 : H12AffineEnvironment.transform 2 2 env3163 = env3164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3163 == env3164) = true)

theorem identity3164 : scanCanonicalize (H12AffineFastState.compose env3164 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3164 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3165 : List Nat := [2,4,2,1,1,0,3,5,512,1024,1540,1540,1031,1541,1029,1030,1540,1541,1025,1029,1540,1,0,2,1031,0,1541,1540,1541,1541,1025,0,4,1,1540,512]

theorem envBound3165 : H12AffineFastState.Bounded env3165 := by
  intro p hp
  have h : env3165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3164_3165 : H12AffineEnvironment.transform 4 1 env3164 = env3165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3164 == env3165) = true)

theorem identity3165 : scanCanonicalize (H12AffineFastState.compose env3165 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3166 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1029,1029,1031,1028,1029,1030,1029,1028,1025,1029,1029,1,0,2,1031,0,1028,1029,1028,1028,1025,0,4,1,1029,1]

theorem envBound3166 : H12AffineFastState.Bounded env3166 := by
  intro p hp
  have h : env3166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3165_3166 : H12AffineEnvironment.transform 8 1 env3165 = env3166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3165 == env3166) = true)

theorem identity3166 : scanCanonicalize (H12AffineFastState.compose env3166 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3166 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3167 : List Nat := [2,4,2,1,1,0,3,5,1,5,0,0,2,1,0,3,0,1,4,0,0,1,0,2,2,0,1,0,1,1,4,0,4,1,0,1]

theorem envBound3167 : H12AffineFastState.Bounded env3167 := by
  intro p hp
  have h : env3167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3166_3167 : H12AffineEnvironment.transform 9 5 env3166 = env3167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3166 == env3167) = true)

def leafEnv3167 : List Nat := [2,4,2,1,1,0,3,5,1,5,0,0,2,1,0,3,0,1,4,0,0,1,0,2,5,2,1,0,1,0,1,1,4,0,4,1,5,2,0,1,1,0,0]

def active3167 : List Nat := [0,1]

def tree3167 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3167 : H12WitnessSearch.Good tree3167 := H12GlobalWitnessIndex.good

theorem leafIdentity3167 : H12AffineFastState.composeSystem env3167 rootObs = leafEnv3167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3167 rootObs == leafEnv3167) = true)

theorem terminalChecked3167 : H12PackedTerminal.terminalCheckFast leafEnv3167 active3167 tree3167 = true := by decide +kernel

def env3168 : List Nat := [2,4,8,1,32,0,34,15,512,1024,1541,1573,1063,1582,1071,1031,1573,1573,1025,1071,1573,42,10,35,1036,10,1540,1583,1582,1583,1035,0,14,11,1583,522]

theorem envBound3168 : H12AffineFastState.Bounded env3168 := by
  intro p hp
  have h : env3168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3162_3168 : H12AffineEnvironment.transform 10 1541 env3162 = env3168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env3162 == env3168) = true)

def env3169 : List Nat := [2,4,8,1,32,0,34,15,32,1024,1061,1029,1063,1038,1071,1031,1029,1029,1025,1071,1029,42,10,35,1036,10,1060,1039,1038,1039,1035,0,14,11,1039,42]

theorem envBound3169 : H12AffineFastState.Bounded env3169 := by
  intro p hp
  have h : env3169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3168_3169 : H12AffineEnvironment.transform 8 32 env3168 = env3169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3168 == env3169) = true)

theorem identity3169 : scanCanonicalize (H12AffineFastState.compose env3169 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3169 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3170 : List Nat := [2,4,8,1,32,0,34,15,32,4,33,1,35,10,43,3,1,1,5,43,1,42,10,35,8,10,32,11,10,11,15,0,14,11,11,42]

theorem envBound3170 : H12AffineFastState.Bounded env3170 := by
  intro p hp
  have h : env3170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3169_3170 : H12AffineEnvironment.transform 9 4 env3169 = env3170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3169 == env3170) = true)

theorem identity3170 : scanCanonicalize (H12AffineFastState.compose env3170 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3170 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3171 : List Nat := [2,4,8,1,1,0,3,15,1,4,0,1,2,10,10,3,1,1,5,10,1,11,10,2,8,10,1,11,10,11,15,0,14,11,11,11]

theorem envBound3171 : H12AffineFastState.Bounded env3171 := by
  intro p hp
  have h : env3171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3170_3171 : H12AffineEnvironment.transform 4 1 env3170 = env3171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3170 == env3171) = true)

def env3172 : List Nat := [2,0,8,1,1,0,3,11,1,0,0,1,2,10,10,3,1,1,1,10,1,11,10,2,8,10,1,11,10,11,11,0,10,11,11,11]

theorem envBound3172 : H12AffineFastState.Bounded env3172 := by
  intro p hp
  have h : env3172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3171_3172 : H12AffineEnvironment.transform 1 0 env3171 = env3172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3171 == env3172) = true)

theorem identity3172 : scanCanonicalize (H12AffineFastState.compose env3172 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3173 : List Nat := [2,0,2,1,1,0,3,1,1,0,0,1,2,0,0,3,1,1,1,0,1,1,0,2,2,0,1,1,0,1,1,0,0,1,1,1]

theorem envBound3173 : H12AffineFastState.Bounded env3173 := by
  intro p hp
  have h : env3173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3172_3173 : H12AffineEnvironment.transform 2 2 env3172 = env3173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3172 == env3173) = true)

def leafEnv3173 : List Nat := [2,0,2,1,1,0,3,1,1,0,0,1,2,0,0,3,1,1,1,0,1,1,0,2,0,2,1,0,1,1,0,1,1,0,0,1,1,2,1,1,1,1,0]

def active3173 : List Nat := [0]

def tree3173 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3173 : H12WitnessSearch.Good tree3173 := H12GlobalWitnessIndex.good

theorem leafIdentity3173 : H12AffineFastState.composeSystem env3173 rootObs = leafEnv3173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3173 rootObs == leafEnv3173) = true)

theorem terminalChecked3173 : H12PackedTerminal.terminalCheckFast leafEnv3173 active3173 tree3173 = true := by decide +kernel

def env3174 : List Nat := [2,1,8,1,1,0,3,10,1,1,0,1,2,10,10,3,1,1,0,10,1,11,10,2,8,10,1,11,10,11,10,0,11,11,11,11]

theorem envBound3174 : H12AffineFastState.Bounded env3174 := by
  intro p hp
  have h : env3174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3171_3174 : H12AffineEnvironment.transform 1 1 env3171 = env3174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3171 == env3174) = true)

def leafEnv3174 : List Nat := [2,1,8,1,1,0,3,10,1,1,0,1,2,10,10,3,1,1,0,10,1,11,10,2,11,8,1,10,1,11,10,11,10,0,11,11,0,2,11,11,1,11,0]

def active3174 : List Nat := [0,2]

def tree3174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3174 : H12WitnessSearch.Good tree3174 := H12GlobalWitnessIndex.good

theorem leafIdentity3174 : H12AffineFastState.composeSystem env3174 rootObs = leafEnv3174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3174 rootObs == leafEnv3174) = true)

theorem terminalChecked3174 : H12PackedTerminal.terminalCheckFast leafEnv3174 active3174 tree3174 = true := by decide +kernel

def env3175 : List Nat := [2,4,8,1,32,0,34,15,33,1024,1060,1028,1063,1039,1071,1031,1028,1028,1025,1071,1028,42,10,35,1036,10,1061,1038,1039,1038,1035,0,14,11,1038,43]

theorem envBound3175 : H12AffineFastState.Bounded env3175 := by
  intro p hp
  have h : env3175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3168_3175 : H12AffineEnvironment.transform 8 33 env3168 = env3175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3168 == env3175) = true)

theorem identity3175 : scanCanonicalize (H12AffineFastState.compose env3175 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound3175 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3176 : List Nat := [2,4,8,1,32,0,34,15,33,46,10,42,9,33,1,41,42,42,47,1,42,42,10,35,34,10,11,32,33,32,37,0,14,11,32,43]

theorem envBound3176 : H12AffineFastState.Bounded env3176 := by
  intro p hp
  have h : env3176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3175_3176 : H12AffineEnvironment.transform 9 46 env3175 = env3176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env3175 == env3176) = true)

theorem identity3176 : scanCanonicalize (H12AffineFastState.compose env3176 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3177 : List Nat := [2,4,3,1,32,0,34,4,33,37,1,33,2,33,1,34,33,33,36,1,33,33,1,35,34,1,0,32,33,32,37,0,5,0,32,32]

theorem envBound3177 : H12AffineFastState.Bounded env3177 := by
  intro p hp
  have h : env3177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3176_3177 : H12AffineEnvironment.transform 2 3 env3176 = env3177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3176 == env3177) = true)

theorem identity3177 : scanCanonicalize (H12AffineFastState.compose env3177 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3178 : List Nat := [2,1,3,1,32,0,34,1,33,32,1,33,2,33,1,34,33,33,33,1,33,33,1,35,34,1,0,32,33,32,32,0,0,0,32,32]

theorem envBound3178 : H12AffineFastState.Bounded env3178 := by
  intro p hp
  have h : env3178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3177_3178 : H12AffineEnvironment.transform 1 1 env3177 = env3178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3177 == env3178) = true)

theorem identity3178 : scanCanonicalize (H12AffineFastState.compose env3178 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3178 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3179 : List Nat := [2,1,3,1,0,0,2,1,1,0,1,1,2,1,1,2,1,1,1,1,1,1,1,3,2,1,0,0,1,0,0,0,0,0,0,0]

theorem envBound3179 : H12AffineFastState.Bounded env3179 := by
  intro p hp
  have h : env3179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3178_3179 : H12AffineEnvironment.transform 4 0 env3178 = env3179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3178 == env3179) = true)

def leafEnv3179 : List Nat := [2,1,3,1,0,0,2,1,1,0,1,1,2,1,1,2,1,1,1,1,1,1,1,3,1,2,1,1,0,0,1,0,0,0,0,0,0,2,0,0,1,0,0]

def active3179 : List Nat := [0]

def tree3179 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3179 : H12WitnessSearch.Good tree3179 := H12GlobalWitnessIndex.good

theorem leafIdentity3179 : H12AffineFastState.composeSystem env3179 rootObs = leafEnv3179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3179 rootObs == leafEnv3179) = true)

theorem terminalChecked3179 : H12PackedTerminal.terminalCheckFast leafEnv3179 active3179 tree3179 = true := by decide +kernel

def env3180 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4096,4194304,4255888,41003,8329,4255888,323712,16385,16400,22561,74795,16,188,20480,4296890,4256401]

theorem envBound3180 : H12AffineFastState.Bounded env3180 := by
  intro p hp
  have h : env3180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3146_3180 : H12AffineEnvironment.transform 7 189 env3146 = env3180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3146 == env3180) = true)

theorem identity3180 : scanCanonicalize (H12AffineFastState.compose env3180 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound3180 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3181 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53402,4112,262144,1025,32768,4096,4194304,4255888,41003,8329,4255888,323712,16385,16400,22561,62641,16,188,20480,4210720,4256401]

theorem envBound3181 : H12AffineFastState.Bounded env3181 := by
  intro p hp
  have h : env3181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3180_3181 : H12AffineEnvironment.transform 15 53402 env3180 = env3181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env3180 == env3181) = true)

def env3182 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,32768,32922,4112,262144,1025,32768,4096,4194304,4235408,41003,8329,4235408,303232,4097,4112,2081,42161,16,188,0,4198432,4235921]

theorem envBound3182 : H12AffineFastState.Bounded env3182 := by
  intro p hp
  have h : env3182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3181_3182 : H12AffineEnvironment.transform 13 4096 env3181 = env3182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3181 == env3182) = true)

theorem identity3182 : scanCanonicalize (H12AffineFastState.compose env3182 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8368) := by decide +kernel

theorem selectedBound3182 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3183 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,8368,8234,4112,262144,1025,8368,4096,4194304,4194336,155,8329,4194336,262192,4097,4112,2081,1025,16,188,0,4198432,4194849]

theorem envBound3183 : H12AffineFastState.Bounded env3183 := by
  intro p hp
  have h : env3183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3182_3183 : H12AffineEnvironment.transform 14 8368 env3182 = env3183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8368 env3182 == env3183) = true)

theorem identity3183 : scanCanonicalize (H12AffineFastState.compose env3183 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2096) := by decide +kernel

theorem selectedBound3183 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env3184 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,8368,8234,4112,2096,1025,8368,4096,4194304,4194336,155,8329,4194336,2048,4097,4112,2081,1025,16,188,0,4198432,4194849]

theorem envBound3184 : H12AffineFastState.Bounded env3184 := by
  intro p hp
  have h : env3184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3183_3184 : H12AffineEnvironment.transform 17 2096 env3183 = env3184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2096 env3183 == env3184) = true)

theorem identity3184 : scanCanonicalize (H12AffineFastState.compose env3184 (packedSelected [1,3,4,5,7,8,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2579) := by decide +kernel

theorem selectedBound3184 : packedSelected [1,3,4,5,7,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env3185 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,2579,4096,2723,2617,4112,2096,1025,2723,4096,4194304,4194336,155,2714,4194336,2048,4097,4112,2081,1025,16,188,0,4198432,4194849]

theorem envBound3185 : H12AffineFastState.Bounded env3185 := by
  intro p hp
  have h : env3185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3184_3185 : H12AffineEnvironment.transform 12 2579 env3184 = env3185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2579 env3184 == env3185) = true)

theorem identity3185 : scanCanonicalize (H12AffineFastState.compose env3185 (packedSelected [4,9,20] rootPS)) = affineNative (2^(21+1) ^^^ 153) := by decide +kernel

theorem selectedBound3185 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3186 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,2579,4096,2723,2617,4112,2096,1025,2723,4096,153,185,155,2714,185,2048,4097,4112,2081,1025,16,188,0,4281,696]

theorem envBound3186 : H12AffineFastState.Bounded env3186 := by
  intro p hp
  have h : env3186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3185_3186 : H12AffineEnvironment.transform 21 153 env3185 = env3186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 153 env3185 == env3186) = true)

theorem identity3186 : scanCanonicalize (H12AffineFastState.compose env3186 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3186 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3187 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1589,2579,1589,2723,2617,1573,2096,1025,2723,1589,153,185,155,2714,185,2048,1588,1573,2081,1025,16,188,0,1676,696]

theorem envBound3187 : H12AffineFastState.Bounded env3187 := by
  intro p hp
  have h : env3187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3186_3187 : H12AffineEnvironment.transform 11 1589 env3186 = env3187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3186 == env3187) = true)

theorem identity3187 : scanCanonicalize (H12AffineFastState.compose env3187 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound3187 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env3188 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1589,2579,1589,2587,2617,1573,2096,1025,2587,1589,33,1,35,2594,1,2048,1588,1573,2081,1025,16,4,0,1588,512]

theorem envBound3188 : H12AffineFastState.Bounded env3188 := by
  intro p hp
  have h : env3188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3187_3188 : H12AffineEnvironment.transform 6 56 env3187 = env3188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3187 == env3188) = true)

theorem identity3188 : scanCanonicalize (H12AffineFastState.compose env3188 (packedSelected [1,2,3,4,6,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3188 : packedSelected [1,2,3,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env3189 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1573,2563,1573,2571,2601,1573,2080,1025,2571,1573,33,1,35,2594,1,2048,1572,1573,2081,1025,0,4,0,1572,512]

end H12CloudChart0