import H12CloudChart0Data133

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound34005 : H12AffineFastState.Bounded env34005 := by
  intro p hp
  have h : env34005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34004_34005 : H12AffineEnvironment.transform 7 116 env34004 = env34005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34004 == env34005) = true)

def env34006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97547,115151,17664,2363593,119043,329730,257,2199998,2191387,63188]

theorem envBound34006 : H12AffineFastState.Bounded env34006 := by
  intro p hp
  have h : env34006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33997_34006 : H12AffineEnvironment.transform 21 272513 env33997 = env34006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33997 == env34006) = true)

theorem identity34006 : scanCanonicalize (H12AffineFastState.compose env34006 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound34006 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77898,272513,73754,95496,8328,64,97547,115151,17664,336003,119043,329730,257,41460,16465,63188]

theorem envBound34007 : H12AffineFastState.Bounded env34007 := by
  intro p hp
  have h : env34007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34006_34007 : H12AffineEnvironment.transform 20 77898 env34006 = env34007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env34006 == env34007) = true)

def env34008 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77850,272513,73754,95496,8328,16,97547,115103,17664,336003,119043,329730,257,41380,16385,63108]

theorem envBound34008 : H12AffineFastState.Bounded env34008 := by
  intro p hp
  have h : env34008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34007_34008 : H12AffineEnvironment.transform 5 16 env34007 = env34008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34007 == env34008) = true)

theorem identity34008 : scanCanonicalize (H12AffineFastState.compose env34008 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound34008 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env34009 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,100386,1025,32769,77850,106659,73754,95496,8328,16,97547,115103,17664,43169,119043,32800,257,41380,16385,63108]

theorem envBound34009 : H12AffineFastState.Bounded env34009 := by
  intro p hp
  have h : env34009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34008_34009 : H12AffineEnvironment.transform 17 100386 env34008 = env34009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env34008 == env34009) = true)

theorem identity34009 : scanCanonicalize (H12AffineFastState.compose env34009 (packedSelected [0,1,4,7,10,11,16,20,22,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound34009 : packedSelected [0,1,4,7,10,11,16,20,22,26,28,32] rootPS < 2^1333 := by decide +kernel

def env34010 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40970,49304,10280,1025,32769,36880,169,32784,54530,8328,16,56577,24981,17664,43169,28937,32800,257,41380,16385,63108]

theorem envBound34010 : H12AffineFastState.Bounded env34010 := by
  intro p hp
  have h : env34010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34009_34010 : H12AffineEnvironment.transform 15 40970 env34009 = env34010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env34009 == env34010) = true)

theorem identity34010 : scanCanonicalize (H12AffineFastState.compose env34010 (packedSelected [0,1,4,7,8,16,18,19,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 12692) := by decide +kernel

theorem selectedBound34010 : packedSelected [0,1,4,7,8,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env34011 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,12692,32768,40970,45324,10280,1025,32769,36880,169,32784,42134,8328,16,44181,4097,13460,43169,157,32800,257,41380,12693,34576]

theorem envBound34011 : H12AffineFastState.Bounded env34011 := by
  intro p hp
  have h : env34011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34010_34011 : H12AffineEnvironment.transform 13 12692 env34010 = env34011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12692 env34010 == env34011) = true)

theorem identity34011 : scanCanonicalize (H12AffineFastState.compose env34011 (packedSelected [2,3,4,5,6,10,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound34011 : packedSelected [2,3,4,5,6,10,17,20,22] rootPS < 2^1333 := by decide +kernel

def env34012 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4113,32768,33167,37001,2477,1025,32769,36880,169,32784,34067,269,16,36112,4097,5393,35108,157,32800,257,32801,4112,34576]

theorem envBound34012 : H12AffineFastState.Bounded env34012 := by
  intro p hp
  have h : env34012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34011_34012 : H12AffineEnvironment.transform 12 389 env34011 = env34012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env34011 == env34012) = true)

theorem identity34012 : scanCanonicalize (H12AffineFastState.compose env34012 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34012 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env34013 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4113,0,399,4233,2477,1025,1,4112,169,16,1299,269,16,3344,4097,5393,2340,157,32,257,33,4112,1808]

theorem envBound34013 : H12AffineFastState.Bounded env34013 := by
  intro p hp
  have h : env34013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34012_34013 : H12AffineEnvironment.transform 14 0 env34012 = env34013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34012 == env34013) = true)

theorem identity34013 : scanCanonicalize (H12AffineFastState.compose env34013 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34013 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env34014 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,389,4113,0,399,4233,2477,52,1,4112,169,16,294,269,16,2341,4097,4388,2340,157,32,257,33,4112,805]

theorem envBound34014 : H12AffineFastState.Bounded env34014 := by
  intro p hp
  have h : env34014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34013_34014 : H12AffineEnvironment.transform 9 53 env34013 = env34014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34013 == env34014) = true)

theorem identity34014 : scanCanonicalize (H12AffineFastState.compose env34014 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound34014 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env34015 : List Nat := [2,4,8,16,32,16,128,172,512,53,2048,4096,41,4113,0,35,4233,2049,52,1,4112,169,16,138,161,16,2185,4097,4232,2184,157,32,173,33,4112,649]

theorem envBound34015 : H12AffineFastState.Bounded env34015 := by
  intro p hp
  have h : env34015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34014_34015 : H12AffineEnvironment.transform 7 172 env34014 = env34015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env34014 == env34015) = true)

theorem identity34015 : scanCanonicalize (H12AffineFastState.compose env34015 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34015 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34016 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,0,35,4096,2049,52,1,4112,32,16,3,40,16,2048,4097,4097,2049,20,32,36,33,4112,512]

theorem envBound34016 : H12AffineFastState.Bounded env34016 := by
  intro p hp
  have h : env34016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34015_34016 : H12AffineEnvironment.transform 6 9 env34015 = env34016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34015 == env34016) = true)

def env34017 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77851,272513,73754,95496,8328,17,97547,115102,17664,336003,119043,329730,257,41381,16384,63109]

theorem envBound34017 : H12AffineFastState.Bounded env34017 := by
  intro p hp
  have h : env34017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34007_34017 : H12AffineEnvironment.transform 5 17 env34007 = env34017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34007 == env34017) = true)

theorem identity34017 : scanCanonicalize (H12AffineFastState.compose env34017 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound34017 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env34018 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21897,65536,5393,262144,1025,21896,77851,272513,73754,95496,8328,17,97547,70679,17664,336003,66698,329730,257,29740,16384,8972]

theorem envBound34018 : H12AffineFastState.Bounded env34018 := by
  intro p hp
  have h : env34018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34017_34018 : H12AffineEnvironment.transform 14 21897 env34017 = env34018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env34017 == env34018) = true)

theorem identity34018 : scanCanonicalize (H12AffineFastState.compose env34018 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound34018 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34019 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21897,65536,5393,97327,1025,21896,77851,87214,73754,95496,8328,17,97547,70679,17664,23724,66698,29741,257,29740,16384,8972]

theorem envBound34019 : H12AffineFastState.Bounded env34019 := by
  intro p hp
  have h : env34019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34018_34019 : H12AffineEnvironment.transform 17 97327 env34018 = env34019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env34018 == env34019) = true)

theorem identity34019 : scanCanonicalize (H12AffineFastState.compose env34019 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34019 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34020 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,65536,5393,97327,1025,21761,77851,87079,73754,95496,8193,17,97547,70679,17664,23589,66563,29741,257,29740,16384,8972]

theorem envBound34020 : H12AffineFastState.Bounded env34020 := by
  intro p hp
  have h : env34020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34019_34020 : H12AffineEnvironment.transform 6 9 env34019 = env34020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34019 == env34020) = true)

theorem identity34020 : scanCanonicalize (H12AffineFastState.compose env34020 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34020 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env34021 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,65536,5393,89378,1025,21761,69910,87079,65815,87045,268,17,89094,70679,17664,23589,66563,21792,257,21793,16384,513]

theorem envBound34021 : H12AffineFastState.Bounded env34021 := by
  intro p hp
  have h : env34021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34020_34021 : H12AffineEnvironment.transform 12 269 env34020 = env34021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34020 == env34021) = true)

theorem identity34021 : scanCanonicalize (H12AffineFastState.compose env34021 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34021 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34022 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,65536,5393,67619,1025,0,69910,65830,65815,65796,268,17,67847,70679,4097,2340,66563,33,257,32,5377,513]

theorem envBound34022 : H12AffineFastState.Bounded env34022 := by
  intro p hp
  have h : env34022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34021_34022 : H12AffineEnvironment.transform 13 5377 env34021 = env34022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34021 == env34022) = true)

theorem identity34022 : scanCanonicalize (H12AffineFastState.compose env34022 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound34022 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34023 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1025,0,4113,33,16,3,268,17,2048,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound34023 : H12AffineFastState.Bounded env34023 := by
  intro p hp
  have h : env34023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34022_34023 : H12AffineEnvironment.transform 15 263 env34022 = env34023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env34022 == env34023) = true)

theorem identity34023 : scanCanonicalize (H12AffineFastState.compose env34023 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34024 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1025,0,4113,33,16,3,40,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound34024 : H12AffineFastState.Bounded env34024 := by
  intro p hp
  have h : env34024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34023_34024 : H12AffineEnvironment.transform 7 36 env34023 = env34024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34023 == env34024) = true)

def env34025 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,1,35,1029,2048,1025,0,33,33,16,3,40,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound34025 : H12AffineFastState.Bounded env34025 := by
  intro p hp
  have h : env34025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34024_34025 : H12AffineEnvironment.transform 11 48 env34024 = env34025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34024 == env34025) = true)

theorem identity34025 : scanCanonicalize (H12AffineFastState.compose env34025 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound34025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34026 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,48,41,1045,1,35,1029,528,1025,0,33,33,16,3,40,17,528,1028,49,528,1056,33,37,32,1045,513]

theorem envBound34026 : H12AffineFastState.Bounded env34026 := by
  intro p hp
  have h : env34026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34025_34026 : H12AffineEnvironment.transform 10 528 env34025 = env34026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env34025 == env34026) = true)

def env34027 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,41,33,1,35,49,528,53,0,33,33,16,3,40,17,528,48,49,528,20,33,37,32,33,513]

theorem envBound34027 : H12AffineFastState.Bounded env34027 := by
  intro p hp
  have h : env34027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34026_34027 : H12AffineEnvironment.transform 9 52 env34026 = env34027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34026 == env34027) = true)

def env34028 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,41,32,1,35,48,528,52,0,33,33,16,3,40,17,528,49,49,528,21,33,37,32,32,513]

theorem envBound34028 : H12AffineFastState.Bounded env34028 := by
  intro p hp
  have h : env34028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34026_34028 : H12AffineEnvironment.transform 9 53 env34026 = env34028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34026 == env34028) = true)

theorem identity34028 : scanCanonicalize (H12AffineFastState.compose env34028 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34029 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,48,41,32,1,35,48,59,52,0,33,33,16,3,40,17,59,49,49,59,21,33,37,32,32,42]

theorem envBound34029 : H12AffineFastState.Bounded env34029 := by
  intro p hp
  have h : env34029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34028_34029 : H12AffineEnvironment.transform 8 43 env34028 = env34029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34028 == env34029) = true)

def leafEnv34029 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,48,41,32,1,35,48,59,52,0,33,33,16,3,20,40,1,17,59,49,49,59,21,33,37,32,5,34,32,42,1,33,0]

def active34029 : List Nat := [0,1,2,3,4]

def tree34029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34029 : H12WitnessSearch.Good tree34029 := H12GlobalWitnessIndex.good

theorem leafIdentity34029 : H12AffineFastState.composeSystem env34029 rootObs = leafEnv34029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34029 rootObs == leafEnv34029) = true)

theorem terminalChecked34029 : H12PackedTerminal.terminalCheckFast leafEnv34029 active34029 tree34029 = true := by decide +kernel

def env34030 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,1,35,1028,2048,1025,0,32,33,16,3,40,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound34030 : H12AffineFastState.Bounded env34030 := by
  intro p hp
  have h : env34030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34024_34030 : H12AffineEnvironment.transform 11 49 env34024 = env34030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34024 == env34030) = true)

theorem identity34030 : scanCanonicalize (H12AffineFastState.compose env34030 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound34030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34031 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,49,41,1044,1,35,1028,1573,1025,0,32,33,16,3,40,17,1573,1029,48,1573,1056,33,37,32,1044,513]

theorem envBound34031 : H12AffineFastState.Bounded env34031 := by
  intro p hp
  have h : env34031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34030_34031 : H12AffineEnvironment.transform 10 1573 env34030 = env34031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env34030 == env34031) = true)

def env34032 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,41,32,1,35,48,529,53,0,32,33,16,3,40,17,529,49,48,529,20,33,37,32,32,513]

theorem envBound34032 : H12AffineFastState.Bounded env34032 := by
  intro p hp
  have h : env34032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34031_34032 : H12AffineEnvironment.transform 9 52 env34031 = env34032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34031 == env34032) = true)

def env34033 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,41,33,1,35,49,528,52,0,32,33,16,3,40,17,528,48,48,528,21,33,37,32,33,513]

theorem envBound34033 : H12AffineFastState.Bounded env34033 := by
  intro p hp
  have h : env34033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34031_34033 : H12AffineEnvironment.transform 9 53 env34031 = env34033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34031 == env34033) = true)

theorem identity34033 : scanCanonicalize (H12AffineFastState.compose env34033 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34034 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,49,41,33,1,35,49,58,52,0,32,33,16,3,40,17,58,48,48,58,21,33,37,32,33,43]

theorem envBound34034 : H12AffineFastState.Bounded env34034 := by
  intro p hp
  have h : env34034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34033_34034 : H12AffineEnvironment.transform 8 42 env34033 = env34034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34033 == env34034) = true)

def leafEnv34034 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,49,41,33,1,35,49,58,52,0,32,33,16,3,20,40,1,17,58,48,48,58,21,33,37,32,5,34,33,43,1,32,0]

def active34034 : List Nat := [0,1,2,3,4]

def tree34034 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34034 : H12WitnessSearch.Good tree34034 := H12GlobalWitnessIndex.good

theorem leafIdentity34034 : H12AffineFastState.composeSystem env34034 rootObs = leafEnv34034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34034 rootObs == leafEnv34034) = true)

theorem terminalChecked34034 : H12PackedTerminal.terminalCheckFast leafEnv34034 active34034 tree34034 = true := by decide +kernel

def env34035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543883,115151,17665,2363592,119042,4268163,257,2199999,2191386,63189]

theorem envBound34035 : H12AffineFastState.Bounded env34035 := by
  intro p hp
  have h : env34035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33996_34035 : H12AffineEnvironment.transform 22 2101329 env33996 = env34035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env33996 == env34035) = true)

def env34036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97547,115151,17665,2363592,119042,329731,257,2199999,2191386,63189]

theorem envBound34036 : H12AffineFastState.Bounded env34036 := by
  intro p hp
  have h : env34036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34035_34036 : H12AffineEnvironment.transform 21 272512 env34035 = env34036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34035 == env34036) = true)

theorem identity34036 : scanCanonicalize (H12AffineFastState.compose env34036 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound34036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49304,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,43476,5392,17665,2363592,1501,318684,257,2114912,2139333,63189]

theorem envBound34037 : H12AffineFastState.Bounded env34037 := by
  intro p hp
  have h : env34037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34036_34037 : H12AffineEnvironment.transform 15 54495 env34036 = env34037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env34036 == env34037) = true)

theorem identity34037 : scanCanonicalize (H12AffineFastState.compose env34037 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound34037 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,13388,262144,1025,29909,2097152,272512,2101329,2114882,8328,64,23808,5392,17665,2363592,1501,272392,257,2114912,2117649,513]

theorem envBound34038 : H12AffineFastState.Bounded env34038 := by
  intro p hp
  have h : env34038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34037_34038 : H12AffineEnvironment.transform 14 29908 env34037 = env34038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env34037 == env34038) = true)

theorem identity34038 : scanCanonicalize (H12AffineFastState.compose env34038 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34038 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env34039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,13388,262144,1025,137,2097152,272512,2101329,2109726,8328,64,10588,5392,12637,2363592,1501,272392,257,2109756,2106445,513]

theorem envBound34039 : H12AffineFastState.Bounded env34039 := by
  intro p hp
  have h : env34039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34038_34039 : H12AffineEnvironment.transform 13 13404 env34038 = env34039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34038 == env34039) = true)

theorem identity34039 : scanCanonicalize (H12AffineFastState.compose env34039 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound34039 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,13388,262144,1025,137,4160,272512,17,8542,8328,64,10588,5392,12637,262280,1501,272392,257,8572,13325,513]

theorem envBound34040 : H12AffineFastState.Bounded env34040 := by
  intro p hp
  have h : env34040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34039_34040 : H12AffineEnvironment.transform 20 4160 env34039 = env34040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34039 == env34040) = true)

theorem identity34040 : scanCanonicalize (H12AffineFastState.compose env34040 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34040 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,13388,10281,1025,137,4160,169,17,8542,8328,64,10588,5392,12637,10401,1501,33,257,8572,13325,513]

theorem envBound34041 : H12AffineFastState.Bounded env34041 := by
  intro p hp
  have h : env34041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34040_34041 : H12AffineEnvironment.transform 17 10281 env34040 = env34041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34040 == env34041) = true)

theorem identity34041 : scanCanonicalize (H12AffineFastState.compose env34041 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34041 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,342,5393,2420,1025,137,4160,169,17,3,469,64,2049,5392,4096,2556,1501,33,257,33,5456,513]

theorem envBound34042 : H12AffineFastState.Bounded env34042 := by
  intro p hp
  have h : env34042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34041_34042 : H12AffineEnvironment.transform 12 349 env34041 = env34042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34041 == env34042) = true)

theorem identity34042 : scanCanonicalize (H12AffineFastState.compose env34042 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34042 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34043 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5237,136,34,5221,2048,1025,137,4160,169,17,3,161,64,2049,5220,4096,2184,1193,33,117,33,5156,513]

theorem envBound34043 : H12AffineFastState.Bounded env34043 := by
  intro p hp
  have h : env34043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34042_34043 : H12AffineEnvironment.transform 7 116 env34042 = env34043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34042 == env34043) = true)

theorem identity34043 : scanCanonicalize (H12AffineFastState.compose env34043 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34043 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34044 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,1,34,5221,2048,1025,0,4160,32,17,3,40,64,2049,5220,4096,2049,1056,33,117,33,5156,513]

theorem envBound34044 : H12AffineFastState.Bounded env34044 := by
  intro p hp
  have h : env34044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34043_34044 : H12AffineEnvironment.transform 6 9 env34043 = env34044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34043 == env34044) = true)

theorem identity34044 : scanCanonicalize (H12AffineFastState.compose env34044 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound34044 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34045 : List Nat := [2,4,8,16,32,64,9,116,512,1024,91,4096,41,5237,1,34,5221,91,1025,0,4160,32,17,3,40,64,90,5220,4096,90,1056,33,117,33,5156,513]

theorem envBound34045 : H12AffineFastState.Bounded env34045 := by
  intro p hp
  have h : env34045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34044_34045 : H12AffineEnvironment.transform 10 91 env34044 = env34045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env34044 == env34045) = true)

theorem identity34045 : scanCanonicalize (H12AffineFastState.compose env34045 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound34045 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34046 : List Nat := [2,4,8,16,32,64,9,116,512,1024,91,1,41,1140,1,34,1124,91,1025,0,65,32,17,3,40,64,90,1125,1,90,1056,33,117,33,1061,513]

theorem envBound34046 : H12AffineFastState.Bounded env34046 := by
  intro p hp
  have h : env34046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34045_34046 : H12AffineEnvironment.transform 11 1 env34045 = env34046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env34045 == env34046) = true)

theorem identity34046 : scanCanonicalize (H12AffineFastState.compose env34046 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound34046 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34047 : List Nat := [2,4,8,16,32,64,9,116,512,62,91,1,41,74,1,34,90,91,63,0,65,32,17,3,40,64,90,91,1,90,30,33,117,33,27,513]

theorem envBound34047 : H12AffineFastState.Bounded env34047 := by
  intro p hp
  have h : env34047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34046_34047 : H12AffineEnvironment.transform 9 62 env34046 = env34047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env34046 == env34047) = true)

theorem identity34047 : scanCanonicalize (H12AffineFastState.compose env34047 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34047 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env34048 : List Nat := [2,4,8,16,0,64,9,84,512,30,91,1,9,74,1,2,90,91,31,0,65,0,17,3,8,64,90,91,1,90,30,1,85,1,27,513]

theorem envBound34048 : H12AffineFastState.Bounded env34048 := by
  intro p hp
  have h : env34048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34047_34048 : H12AffineEnvironment.transform 4 0 env34047 = env34048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34047 == env34048) = true)

def env34049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97546,115151,17665,2363592,119042,329730,257,2199999,2191386,63189]

theorem envBound34049 : H12AffineFastState.Bounded env34049 := by
  intro p hp
  have h : env34049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34035_34049 : H12AffineEnvironment.transform 21 272513 env34035 = env34049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34035 == env34049) = true)

theorem identity34049 : scanCanonicalize (H12AffineFastState.compose env34049 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound34049 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,115871,272513,120014,98781,8328,64,97546,115151,17665,382039,119042,329730,257,21792,46213,63189]

theorem envBound34050 : H12AffineFastState.Bounded env34050 := by
  intro p hp
  have h : env34050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34049_34050 : H12AffineEnvironment.transform 20 115871 env34049 = env34050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env34049 == env34050) = true)

def env34051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10400,1025,32769,115871,33,120014,98781,8328,64,97546,115151,17665,130295,119042,73890,257,21792,46213,63189]

theorem envBound34051 : H12AffineFastState.Bounded env34051 := by
  intro p hp
  have h : env34051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34050_34051 : H12AffineEnvironment.transform 17 10400 env34050 = env34051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env34050 == env34051) = true)

theorem identity34051 : scanCanonicalize (H12AffineFastState.compose env34051 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound34051 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,263,49304,10400,1025,32769,50584,33,54729,32986,8328,64,31757,49352,17665,65008,53253,8613,257,21792,46213,63189]

theorem envBound34052 : H12AffineFastState.Bounded env34052 := by
  intro p hp
  have h : env34052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34051_34052 : H12AffineEnvironment.transform 15 263 env34051 = env34052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env34051 == env34052) = true)

theorem identity34052 : scanCanonicalize (H12AffineFastState.compose env34052 (packedSelected [1,10,16,20,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34052 : packedSelected [1,10,16,20,26,28] rootPS < 2^1333 := by decide +kernel

def env34053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,263,49304,2477,1025,32769,50584,33,54729,32986,389,64,23808,49352,17665,56573,53253,168,257,21792,38280,55256]

theorem envBound34053 : H12AffineFastState.Bounded env34053 := by
  intro p hp
  have h : env34053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34052_34053 : H12AffineEnvironment.transform 12 269 env34052 = env34053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34052 == env34053) = true)

theorem identity34053 : scanCanonicalize (H12AffineFastState.compose env34053 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34053 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env34054 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,263,49216,2421,1025,32769,50496,33,54545,32770,349,64,23808,49168,17665,56357,53253,112,257,21792,38224,55040]

theorem envBound34054 : H12AffineFastState.Bounded env34054 := by
  intro p hp
  have h : env34054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34053_34054 : H12AffineEnvironment.transform 6 88 env34053 = env34054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34053 == env34054) = true)

theorem identity34054 : scanCanonicalize (H12AffineFastState.compose env34054 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound34054 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env34055 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,80,263,16400,2421,1025,81,17680,33,21825,82,349,64,23808,16448,17665,23669,20565,112,257,21792,5376,22352]

theorem envBound34055 : H12AffineFastState.Bounded env34055 := by
  intro p hp
  have h : env34055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34054_34055 : H12AffineEnvironment.transform 14 80 env34054 = env34055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env34054 == env34055) = true)

theorem identity34055 : scanCanonicalize (H12AffineFastState.compose env34055 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34055 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env34056 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,121,16384,80,115,16400,2049,1025,81,17508,33,21557,82,41,64,23668,16448,17525,23669,20565,112,117,21588,5236,22052]

theorem envBound34056 : H12AffineFastState.Bounded env34056 := by
  intro p hp
  have h : env34056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34055_34056 : H12AffineEnvironment.transform 7 116 env34055 = env34056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34055 == env34056) = true)

theorem identity34056 : scanCanonicalize (H12AffineFastState.compose env34056 (packedSelected [2,6,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound34056 : packedSelected [2,6,14] rootPS < 2^1333 := by decide +kernel

def env34057 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,121,5157,80,115,5173,2049,1025,81,4161,33,16,82,41,64,2129,5221,4176,2128,1136,112,117,113,5236,513]

theorem envBound34057 : H12AffineFastState.Bounded env34057 := by
  intro p hp
  have h : env34057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34056_34057 : H12AffineEnvironment.transform 13 5157 env34056 = env34057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env34056 == env34057) = true)

def env34058 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4113,33,16,2,41,16,2049,5173,4096,2048,1056,32,37,33,5156,513]

theorem envBound34058 : H12AffineFastState.Bounded env34058 := by
  intro p hp
  have h : env34058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34057_34058 : H12AffineEnvironment.transform 5 16 env34057 = env34058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34057 == env34058) = true)

theorem identity34058 : scanCanonicalize (H12AffineFastState.compose env34058 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34059 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,0,35,4097,2049,53,1,4113,33,16,2,41,16,2049,4097,4096,2048,20,32,37,33,4112,513]

theorem envBound34059 : H12AffineFastState.Bounded env34059 := by
  intro p hp
  have h : env34059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34058_34059 : H12AffineEnvironment.transform 9 52 env34058 = env34059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34058 == env34059) = true)

theorem identity34059 : scanCanonicalize (H12AffineFastState.compose env34059 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound34059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34060 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,4096,41,4113,0,35,4097,49,53,1,4113,33,16,2,41,16,49,4097,4096,48,20,32,37,33,4112,513]

theorem envBound34060 : H12AffineFastState.Bounded env34060 := by
  intro p hp
  have h : env34060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34059_34060 : H12AffineEnvironment.transform 10 48 env34059 = env34060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env34059 == env34060) = true)

theorem identity34060 : scanCanonicalize (H12AffineFastState.compose env34060 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound34060 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34061 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,41,48,0,35,32,49,53,1,48,33,16,2,41,16,49,32,33,48,20,32,37,33,49,513]

theorem envBound34061 : H12AffineFastState.Bounded env34061 := by
  intro p hp
  have h : env34061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34060_34061 : H12AffineEnvironment.transform 11 33 env34060 = env34061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env34060 == env34061) = true)

def leafEnv34061 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,41,48,0,35,32,49,53,1,48,33,16,2,21,41,1,16,49,32,33,48,20,32,37,33,5,35,49,513,1,49,0]

def active34061 : List Nat := [0,1,2,3,4,8]

def tree34061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34061 : H12WitnessSearch.Good tree34061 := H12GlobalWitnessIndex.good

theorem leafIdentity34061 : H12AffineFastState.composeSystem env34061 rootObs = leafEnv34061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34061 rootObs == leafEnv34061) = true)

theorem terminalChecked34061 : H12PackedTerminal.terminalCheckFast leafEnv34061 active34061 tree34061 = true := by decide +kernel

def env34062 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,1,34,5173,2049,1025,0,4112,33,16,3,41,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound34062 : H12AffineFastState.Bounded env34062 := by
  intro p hp
  have h : env34062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34057_34062 : H12AffineEnvironment.transform 5 17 env34057 = env34062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34057 == env34062) = true)

def env34063 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1045,1,34,1029,2049,1025,0,32,33,16,3,41,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound34063 : H12AffineFastState.Bounded env34063 := by
  intro p hp
  have h : env34063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34062_34063 : H12AffineEnvironment.transform 11 48 env34062 = env34063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34062 == env34063) = true)

theorem identity34063 : scanCanonicalize (H12AffineFastState.compose env34063 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34064 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,32,1,34,48,2049,52,0,32,33,16,3,41,17,2048,49,49,2049,20,33,36,32,32,513]

theorem envBound34064 : H12AffineFastState.Bounded env34064 := by
  intro p hp
  have h : env34064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34063_34064 : H12AffineEnvironment.transform 9 53 env34063 = env34064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34063 == env34064) = true)

theorem identity34064 : scanCanonicalize (H12AffineFastState.compose env34064 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34065 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,48,40,32,1,34,48,2049,52,0,32,33,16,3,41,17,2048,49,49,2049,20,33,36,32,32,43]

theorem envBound34065 : H12AffineFastState.Bounded env34065 := by
  intro p hp
  have h : env34065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34064_34065 : H12AffineEnvironment.transform 8 42 env34064 = env34065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34064 == env34065) = true)

def leafEnv34065 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,48,40,32,1,34,48,2049,52,0,32,33,16,3,21,41,1,17,2048,49,49,2049,20,33,36,32,5,35,32,43,1,32,0]

def active34065 : List Nat := [0,1,2,3,4,10]

def tree34065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34065 : H12WitnessSearch.Good tree34065 := H12GlobalWitnessIndex.good

theorem leafIdentity34065 : H12AffineFastState.composeSystem env34065 rootObs = leafEnv34065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34065 rootObs == leafEnv34065) = true)

theorem terminalChecked34065 : H12PackedTerminal.terminalCheckFast leafEnv34065 active34065 tree34065 = true := by decide +kernel

def env34066 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1044,1,34,1028,2049,1025,0,33,33,16,3,41,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound34066 : H12AffineFastState.Bounded env34066 := by
  intro p hp
  have h : env34066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34062_34066 : H12AffineEnvironment.transform 11 49 env34062 = env34066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34062 == env34066) = true)

def env34067 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,32,1,34,48,2049,53,0,33,33,16,3,41,17,2048,49,48,2049,21,33,36,32,32,513]

theorem envBound34067 : H12AffineFastState.Bounded env34067 := by
  intro p hp
  have h : env34067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34066_34067 : H12AffineEnvironment.transform 9 52 env34066 = env34067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34066 == env34067) = true)

def env34068 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,40,33,1,34,49,2049,52,0,33,33,16,3,41,17,2048,48,48,2049,20,33,36,32,33,513]

theorem envBound34068 : H12AffineFastState.Bounded env34068 := by
  intro p hp
  have h : env34068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34066_34068 : H12AffineEnvironment.transform 9 53 env34066 = env34068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34066 == env34068) = true)

theorem identity34068 : scanCanonicalize (H12AffineFastState.compose env34068 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34069 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,49,40,33,1,34,49,2049,52,0,33,33,16,3,41,17,2048,48,48,2049,20,33,36,32,33,42]

theorem envBound34069 : H12AffineFastState.Bounded env34069 := by
  intro p hp
  have h : env34069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34068_34069 : H12AffineEnvironment.transform 8 43 env34068 = env34069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34068 == env34069) = true)

def leafEnv34069 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,49,40,33,1,34,49,2049,52,0,33,33,16,3,21,41,1,17,2048,48,48,2049,20,33,36,32,5,35,33,42,1,33,0]

def active34069 : List Nat := [0,1,2,3,4,10]

def tree34069 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34069 : H12WitnessSearch.Good tree34069 := H12GlobalWitnessIndex.good

theorem leafIdentity34069 : H12AffineFastState.composeSystem env34069 rootObs = leafEnv34069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34069 rootObs == leafEnv34069) = true)

theorem terminalChecked34069 : H12PackedTerminal.terminalCheckFast leafEnv34069 active34069 tree34069 = true := by decide +kernel

def env34070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10401,1025,32769,115871,32,120014,98781,8328,64,97546,115151,17665,130294,119042,73891,257,21792,46213,63189]

theorem envBound34070 : H12AffineFastState.Bounded env34070 := by
  intro p hp
  have h : env34070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34050_34070 : H12AffineEnvironment.transform 17 10401 env34050 = env34070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env34050 == env34070) = true)

theorem identity34070 : scanCanonicalize (H12AffineFastState.compose env34070 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 29942) := by decide +kernel

theorem selectedBound34070 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29942,49304,10401,1025,32769,45161,32,41016,62763,8328,64,2556,46393,17665,34816,42484,21589,257,21792,46213,63189]

theorem envBound34071 : H12AffineFastState.Bounded env34071 := by
  intro p hp
  have h : env34071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34070_34071 : H12AffineEnvironment.transform 15 29942 env34070 = env34071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29942 env34070 == env34071) = true)

theorem identity34071 : scanCanonicalize (H12AffineFastState.compose env34071 (packedSelected [3,5,7,11,12,14,15,16,17,18,23,27,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound34071 : packedSelected [3,5,7,11,12,14,15,16,17,18,23,27,31,32] rootPS < 2^1333 := by decide +kernel

def env34072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,29942,24752,10401,1025,8233,4161,32,16,21763,8328,64,2556,5393,17665,10280,1500,21589,257,21792,5293,22269]

theorem envBound34072 : H12AffineFastState.Bounded env34072 := by
  intro p hp
  have h : env34072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34071_34072 : H12AffineEnvironment.transform 14 8232 env34071 = env34072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env34071 == env34072) = true)

theorem identity34072 : scanCanonicalize (H12AffineFastState.compose env34072 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound34072 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env34073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13688,8232,398,5576,10401,1025,8233,4161,32,16,8315,8328,64,2556,5393,12409,10280,1500,8493,257,8280,5293,9093]

theorem envBound34073 : H12AffineFastState.Bounded env34073 := by
  intro p hp
  have h : env34073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34072_34073 : H12AffineEnvironment.transform 13 13688 env34072 = env34073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env34072 == env34073) = true)

theorem identity34073 : scanCanonicalize (H12AffineFastState.compose env34073 (packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34073 : packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env34074 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,13324,8232,250,5308,10401,1025,8233,4161,32,16,8315,8328,64,2184,5221,12409,10280,1192,8281,117,8280,5293,8945]

theorem envBound34074 : H12AffineFastState.Bounded env34074 := by
  intro p hp
  have h : env34074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34073_34074 : H12AffineEnvironment.transform 7 116 env34073 = env34074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34073 == env34074) = true)

theorem identity34074 : scanCanonicalize (H12AffineFastState.compose env34074 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound34074 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env34075 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,241,5373,217,250,5308,2128,1025,216,4161,32,16,138,121,64,2184,5221,4232,2265,1192,168,117,169,5293,512]

theorem envBound34075 : H12AffineFastState.Bounded env34075 := by
  intro p hp
  have h : env34075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34074_34075 : H12AffineEnvironment.transform 12 241 env34074 = env34075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env34074 == env34075) = true)

theorem identity34075 : scanCanonicalize (H12AffineFastState.compose env34075 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34075 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34076 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,41,5157,1,34,5220,2128,1025,0,4161,32,16,82,121,64,2128,5221,4176,2049,1136,112,117,113,5237,512]

theorem envBound34076 : H12AffineFastState.Bounded env34076 := by
  intro p hp
  have h : env34076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34075_34076 : H12AffineEnvironment.transform 6 88 env34075 = env34076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34075 == env34076) = true)

theorem identity34076 : scanCanonicalize (H12AffineFastState.compose env34076 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34077 : List Nat := [2,4,8,16,32,49,41,5,512,1024,2048,4096,41,5157,1,34,5141,2081,1025,0,4144,32,16,35,8,49,2081,5140,4129,2049,1025,1,4,0,5124,512]

theorem envBound34077 : H12AffineFastState.Bounded env34077 := by
  intro p hp
  have h : env34077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34076_34077 : H12AffineEnvironment.transform 5 49 env34076 = env34077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34076 == env34077) = true)

theorem identity34077 : scanCanonicalize (H12AffineFastState.compose env34077 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34077 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34078 : List Nat := [2,4,8,16,32,49,41,5,512,52,2048,4096,41,4113,1,34,4129,2081,53,0,4144,32,16,35,8,49,2081,4128,4129,2049,53,1,4,0,4144,512]

theorem envBound34078 : H12AffineFastState.Bounded env34078 := by
  intro p hp
  have h : env34078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34077_34078 : H12AffineEnvironment.transform 9 52 env34077 = env34078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34077 == env34078) = true)

theorem identity34078 : scanCanonicalize (H12AffineFastState.compose env34078 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound34078 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34079 : List Nat := [2,4,8,16,32,49,41,5,512,52,2048,2097,41,2080,1,34,2064,2081,53,0,2049,32,16,35,8,49,2081,2065,2064,2049,53,1,4,0,2049,512]

theorem envBound34079 : H12AffineFastState.Bounded env34079 := by
  intro p hp
  have h : env34079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34078_34079 : H12AffineEnvironment.transform 11 2097 env34078 = env34079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env34078 == env34079) = true)

theorem identity34079 : scanCanonicalize (H12AffineFastState.compose env34079 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound34079 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34080 : List Nat := [2,4,8,16,32,49,41,5,512,52,561,512,41,529,1,34,545,528,53,0,560,32,16,35,8,49,528,544,545,560,53,1,4,0,560,512]

theorem envBound34080 : H12AffineFastState.Bounded env34080 := by
  intro p hp
  have h : env34080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34079_34080 : H12AffineEnvironment.transform 10 561 env34079 = env34080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env34079 == env34080) = true)

theorem identity34080 : scanCanonicalize (H12AffineFastState.compose env34080 (packedSelected [0,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34080 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env34081 : List Nat := [2,4,8,16,0,17,9,5,512,20,529,512,9,529,1,2,513,528,21,0,528,0,16,3,8,17,528,512,513,528,21,1,4,0,528,512]

theorem envBound34081 : H12AffineFastState.Bounded env34081 := by
  intro p hp
  have h : env34081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34080_34081 : H12AffineEnvironment.transform 4 0 env34080 = env34081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34080 == env34081) = true)

theorem identity34081 : scanCanonicalize (H12AffineFastState.compose env34081 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34082 : List Nat := [2,4,8,1,0,0,9,5,512,5,512,512,9,512,1,2,513,513,4,0,513,0,1,3,8,0,513,512,513,513,4,1,4,0,513,512]

theorem envBound34082 : H12AffineFastState.Bounded env34082 := by
  intro p hp
  have h : env34082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34081_34082 : H12AffineEnvironment.transform 3 1 env34081 = env34082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34081 == env34082) = true)

theorem identity34082 : scanCanonicalize (H12AffineFastState.compose env34082 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34083 : List Nat := [2,1,8,1,0,0,9,0,512,0,512,512,9,512,1,2,513,513,1,0,513,0,1,3,8,0,513,512,513,513,1,1,1,0,513,512]

theorem envBound34083 : H12AffineFastState.Bounded env34083 := by
  intro p hp
  have h : env34083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34082_34083 : H12AffineEnvironment.transform 1 1 env34082 = env34083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34082 == env34083) = true)

def env34084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025626,115150,10507600,8650904,10600786,4268162,257,8487407,8478794,10544773]

theorem envBound34084 : H12AffineFastState.Bounded env34084 := by
  intro p hp
  have h : env34084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33995_34084 : H12AffineEnvironment.transform 16 49305 env33995 = env34084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env33995 == env34084) = true)

def env34085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543882,115150,17664,2363592,119042,4268162,257,2199999,2191386,63189]

theorem envBound34085 : H12AffineFastState.Bounded env34085 := by
  intro p hp
  have h : env34085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34084_34085 : H12AffineEnvironment.transform 22 2101328 env34084 = env34085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env34084 == env34085) = true)

def env34086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97546,115150,17664,2363592,119042,329730,257,2199999,2191386,63189]

theorem envBound34086 : H12AffineFastState.Bounded env34086 := by
  intro p hp
  have h : env34086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34085_34086 : H12AffineEnvironment.transform 21 272512 env34085 = env34086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34085 == env34086) = true)

theorem identity34086 : scanCanonicalize (H12AffineFastState.compose env34086 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound34086 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58517,272512,62661,41430,8328,64,97546,115150,17664,324701,119042,329730,257,95530,103567,63189]

theorem envBound34087 : H12AffineFastState.Bounded env34087 := by
  intro p hp
  have h : env34087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34086_34087 : H12AffineEnvironment.transform 20 58517 env34086 = env34087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env34086 == env34087) = true)

def env34088 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58517,272512,62613,41350,8328,16,97546,115102,17664,324621,119042,329730,257,95530,103567,63109]

theorem envBound34088 : H12AffineFastState.Bounded env34088 := by
  intro p hp
  have h : env34088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34087_34088 : H12AffineEnvironment.transform 5 16 env34087 = env34088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34087 == env34088) = true)

theorem identity34088 : scanCanonicalize (H12AffineFastState.compose env34088 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34088 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env34089 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,65536,49305,262144,1025,32769,50585,264588,54681,32906,388,16,89094,115102,17664,316673,119042,329730,257,87078,103567,55177]

theorem envBound34089 : H12AffineFastState.Bounded env34089 := by
  intro p hp
  have h : env34089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34088_34089 : H12AffineEnvironment.transform 12 268 env34088 = env34089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34088 == env34089) = true)

theorem identity34089 : scanCanonicalize (H12AffineFastState.compose env34089 (packedSelected [4,7,9,10,16,17,19,20,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 122282) := by decide +kernel

theorem selectedBound34089 : packedSelected [4,7,9,10,16,17,19,20,26,27,31] rootPS < 2^1333 := by decide +kernel

def env34090 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,65536,49305,122282,1025,32769,50585,119846,54681,32906,388,16,89094,115102,17664,67755,119042,54696,257,87078,103567,55177]

theorem envBound34090 : H12AffineFastState.Bounded env34090 := by
  intro p hp
  have h : env34090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34089_34090 : H12AffineEnvironment.transform 17 122282 env34089 = env34090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122282 env34089 == env34090) = true)

theorem identity34090 : scanCanonicalize (H12AffineFastState.compose env34090 (packedSelected [0,4,7,16,17,19,20,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound34090 : packedSelected [0,4,7,16,17,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env34091 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,21647,49305,35109,1025,32769,50585,32937,54681,32906,388,16,2185,38161,17664,23588,34189,54696,257,169,49152,55177]

theorem envBound34091 : H12AffineFastState.Bounded env34091 := by
  intro p hp
  have h : env34091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34090_34091 : H12AffineEnvironment.transform 15 21647 env34090 = env34091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env34090 == env34091) = true)

theorem identity34091 : scanCanonicalize (H12AffineFastState.compose env34091 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound34091 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env34092 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21896,21647,5393,23725,1025,21897,4113,21793,17,21762,388,16,2185,16537,17664,23588,20485,32,257,169,5512,513]

theorem envBound34092 : H12AffineFastState.Bounded env34092 := by
  intro p hp
  have h : env34092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34091_34092 : H12AffineEnvironment.transform 14 21896 env34091 = env34092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env34091 == env34092) = true)

def env34093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58517,272512,62612,41351,8328,17,97546,115103,17664,324620,119042,329730,257,95530,103567,63108]

theorem envBound34093 : H12AffineFastState.Bounded env34093 := by
  intro p hp
  have h : env34093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34087_34093 : H12AffineEnvironment.transform 5 17 env34087 = env34093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34087 == env34093) = true)

theorem identity34093 : scanCanonicalize (H12AffineFastState.compose env34093 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound34093 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env34094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,65536,46108,262144,1025,32769,36880,272512,32785,41351,8328,17,67983,111898,12677,295049,107911,329730,257,65967,103567,33281]

theorem envBound34094 : H12AffineFastState.Bounded env34094 := by
  intro p hp
  have h : env34094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34093_34094 : H12AffineEnvironment.transform 13 13445 env34093 = env34094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env34093 == env34094) = true)

theorem identity34094 : scanCanonicalize (H12AffineFastState.compose env34094 (packedSelected [0,3,4,7,16,17,20,22,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound34094 : packedSelected [0,3,4,7,16,17,20,22,24,26,31] rootPS < 2^1333 := by decide +kernel

def env34095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8581,65536,5529,262144,1025,8580,12693,272512,8596,2,8328,17,67983,70815,12677,270604,66562,329730,257,65967,79114,9092]

theorem envBound34095 : H12AffineFastState.Bounded env34095 := by
  intro p hp
  have h : env34095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34094_34095 : H12AffineEnvironment.transform 14 8581 env34094 = env34095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env34094 == env34095) = true)

theorem identity34095 : scanCanonicalize (H12AffineFastState.compose env34095 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound34095 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env34096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8581,65536,5529,67754,1025,8580,12693,73770,8596,2,8328,17,67983,70815,12677,76198,66562,168,257,65967,79114,9092]

theorem envBound34096 : H12AffineFastState.Bounded env34096 := by
  intro p hp
  have h : env34096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34095_34096 : H12AffineEnvironment.transform 17 67754 env34095 = env34096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env34095 == env34096) = true)

theorem identity34096 : scanCanonicalize (H12AffineFastState.compose env34096 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34096 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env34097 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8460,65536,5392,67619,1025,8461,12572,73770,8477,2,8193,17,67846,70678,12556,76079,66562,33,257,65830,79114,8973]

theorem envBound34097 : H12AffineFastState.Bounded env34097 := by
  intro p hp
  have h : env34097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34096_34097 : H12AffineEnvironment.transform 6 9 env34096 = env34097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34096 == env34097) = true)

theorem identity34097 : scanCanonicalize (H12AffineFastState.compose env34097 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound34097 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34098 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8460,262,5392,2341,1025,8461,12572,8492,8477,2,8193,17,2048,5392,12556,10281,1284,33,257,32,13324,8973]

theorem envBound34098 : H12AffineFastState.Bounded env34098 := by
  intro p hp
  have h : env34098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34097_34098 : H12AffineEnvironment.transform 15 262 env34097 = env34098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env34097 == env34098) = true)

theorem identity34098 : scanCanonicalize (H12AffineFastState.compose env34098 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34098 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34099 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,8192,13324,8460,262,5392,2308,1025,8461,12572,8461,8477,2,8193,17,2048,5392,12556,10248,1284,0,257,1,13324,8973]

theorem envBound34099 : H12AffineFastState.Bounded env34099 := by
  intro p hp
  have h : env34099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34098_34099 : H12AffineEnvironment.transform 4 1 env34098 = env34099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34098 == env34099) = true)

def env34100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97547,115150,17664,2363592,119042,329731,257,2199999,2191386,63189]

theorem envBound34100 : H12AffineFastState.Bounded env34100 := by
  intro p hp
  have h : env34100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34085_34100 : H12AffineEnvironment.transform 21 272513 env34085 = env34100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34085 == env34100) = true)

theorem identity34100 : scanCanonicalize (H12AffineFastState.compose env34100 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound34100 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,262144,1025,29909,2097152,272513,2101328,2114883,8328,64,97547,79130,17664,2363592,75222,329731,257,2188651,2191386,513]

theorem envBound34101 : H12AffineFastState.Bounded env34101 := by
  intro p hp
  have h : env34101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34100_34101 : H12AffineEnvironment.transform 14 29908 env34100 = env34101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env34100 == env34101) = true)

def env34102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,32240,1025,29909,2097152,21873,2101328,2114883,8328,64,97547,79130,17664,2125112,75222,95731,257,2188651,2191386,513]

theorem envBound34102 : H12AffineFastState.Bounded env34102 := by
  intro p hp
  have h : env34102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34101_34102 : H12AffineEnvironment.transform 17 32240 env34101 = env34102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env34101 == env34102) = true)

theorem identity34102 : scanCanonicalize (H12AffineFastState.compose env34102 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34102 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env34103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32121,1025,29788,2097152,21873,2101328,2114883,8193,64,97547,79130,17664,2125112,75103,95610,257,2188651,2191386,513]

theorem envBound34103 : H12AffineFastState.Bounded env34103 := by
  intro p hp
  have h : env34103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34102_34103 : H12AffineEnvironment.transform 6 9 env34102 = env34103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34102 == env34103) = true)

theorem identity34103 : scanCanonicalize (H12AffineFastState.compose env34103 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 12573) := by decide +kernel

theorem selectedBound34103 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env34104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32121,1025,29788,12573,21873,8525,29790,8193,64,97547,79130,17664,23589,75103,95610,257,87158,82183,513]

theorem envBound34104 : H12AffineFastState.Bounded env34104 := by
  intro p hp
  have h : env34104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34103_34104 : H12AffineEnvironment.transform 20 12573 env34103 = env34104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12573 env34103 == env34104) = true)

theorem identity34104 : scanCanonicalize (H12AffineFastState.compose env34104 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound34104 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8283,13389,32121,1025,29788,12573,21873,8525,29790,8193,64,23888,5441,17664,23589,1284,21793,257,29741,24924,513]

theorem envBound34105 : H12AffineFastState.Bounded env34105 := by
  intro p hp
  have h : env34105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34104_34105 : H12AffineEnvironment.transform 15 8283 env34104 = env34105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env34104 == env34105) = true)

theorem identity34105 : scanCanonicalize (H12AffineFastState.compose env34105 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34105 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8283,13389,2421,1025,80,12573,8573,8525,82,8193,64,10588,5441,12556,10281,1284,8493,257,33,5456,513]

theorem envBound34106 : H12AffineFastState.Bounded env34106 := by
  intro p hp
  have h : env34106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34105_34106 : H12AffineEnvironment.transform 13 13324 env34105 = env34106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34105 == env34106) = true)

theorem identity34106 : scanCanonicalize (H12AffineFastState.compose env34106 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34106 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env34107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,81,263,5393,2421,1025,80,4161,33,17,82,349,64,2048,5441,4176,2421,1284,113,257,33,5456,513]

theorem envBound34107 : H12AffineFastState.Bounded env34107 := by
  intro p hp
  have h : env34107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34106_34107 : H12AffineEnvironment.transform 12 348 env34106 = env34107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34106 == env34107) = true)

theorem identity34107 : scanCanonicalize (H12AffineFastState.compose env34107 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34107 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34108 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1025,1,4112,33,17,3,268,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound34108 : H12AffineFastState.Bounded env34108 := by
  intro p hp
  have h : env34108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34107_34108 : H12AffineEnvironment.transform 5 17 env34107 = env34108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34107 == env34108) = true)

theorem identity34108 : scanCanonicalize (H12AffineFastState.compose env34108 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound34108 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34109 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1077,269,308,0,263,292,2340,1025,1,1061,33,17,3,268,17,2048,293,1076,2340,1284,32,257,33,308,513]

theorem envBound34109 : H12AffineFastState.Bounded env34109 := by
  intro p hp
  have h : env34109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34108_34109 : H12AffineEnvironment.transform 11 1077 env34108 = env34109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env34108 == env34109) = true)

theorem identity34109 : scanCanonicalize (H12AffineFastState.compose env34109 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34109 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34110 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1077,269,308,0,263,292,2340,1025,1,1061,33,17,3,268,17,2048,293,1076,2340,1284,32,257,33,308,1]

theorem envBound34110 : H12AffineFastState.Bounded env34110 := by
  intro p hp
  have h : env34110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34109_34110 : H12AffineEnvironment.transform 8 0 env34109 = env34110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34109 == env34110) = true)

theorem identity34110 : scanCanonicalize (H12AffineFastState.compose env34110 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34110 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34111 : List Nat := [2,4,8,16,32,17,9,37,0,1024,2048,1077,40,17,0,34,1,2049,1025,1,1061,33,17,3,41,17,2048,0,1076,2049,1057,32,36,33,17,1]

theorem envBound34111 : H12AffineFastState.Bounded env34111 := by
  intro p hp
  have h : env34111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34110_34111 : H12AffineEnvironment.transform 7 37 env34110 = env34111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34110 == env34111) = true)

def env34112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,32241,1025,29909,2097152,21872,2101328,2114883,8328,64,97547,79130,17664,2125113,75222,95730,257,2188651,2191386,513]

theorem envBound34112 : H12AffineFastState.Bounded env34112 := by
  intro p hp
  have h : env34112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34101_34112 : H12AffineEnvironment.transform 17 32241 env34101 = env34112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env34101 == env34112) = true)

def env34113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32121,1025,29789,2097152,21872,2101328,2114883,8192,64,97547,79130,17664,2125113,75102,95610,257,2188651,2191386,513]

theorem envBound34113 : H12AffineFastState.Bounded env34113 := by
  intro p hp
  have h : env34113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34112_34113 : H12AffineEnvironment.transform 6 8 env34112 = env34113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34112 == env34113) = true)

theorem identity34113 : scanCanonicalize (H12AffineFastState.compose env34113 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound34113 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env34114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32121,1025,29789,12392,21872,8248,29995,8192,64,97547,79130,17664,23889,75102,95610,257,87299,82034,513]

theorem envBound34114 : H12AffineFastState.Bounded env34114 := by
  intro p hp
  have h : env34114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34113_34114 : H12AffineEnvironment.transform 20 12392 env34113 = env34114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env34113 == env34114) = true)

theorem identity34114 : scanCanonicalize (H12AffineFastState.compose env34114 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound34114 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env34115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,20759,13389,32121,1025,29789,12392,21872,8248,29995,8192,64,11292,25613,17664,23889,29769,9325,257,1044,4453,513]

theorem envBound34115 : H12AffineFastState.Bounded env34115 := by
  intro p hp
  have h : env34115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34114_34115 : H12AffineEnvironment.transform 15 20759 env34114 = env34115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env34114 == env34115) = true)

theorem identity34115 : scanCanonicalize (H12AffineFastState.compose env34115 (packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound34115 : packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS < 2^1333 := by decide +kernel

def env34116 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,16384,28956,20759,12557,30777,321,28957,12392,20528,8248,28779,8192,64,10588,24909,16448,22545,28937,8493,257,340,4453,513]

theorem envBound34116 : H12AffineFastState.Bounded env34116 := by
  intro p hp
  have h : env34116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34115_34116 : H12AffineEnvironment.transform 9 320 env34115 = env34116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env34115 == env34116) = true)

theorem identity34116 : scanCanonicalize (H12AffineFastState.compose env34116 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound34116 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env34117 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,4160,8540,343,12557,10361,321,8541,12392,112,8248,8235,8192,64,10588,12557,4096,2129,8521,8493,257,340,4453,513]

theorem envBound34117 : H12AffineFastState.Bounded env34117 := by
  intro p hp
  have h : env34117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34116_34117 : H12AffineEnvironment.transform 13 4160 env34116 = env34117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env34116 == env34117) = true)

def env34118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32120,1025,29788,2097152,21872,2101328,2114883,8193,64,97547,79130,17664,2125113,75103,95611,257,2188651,2191386,513]

theorem envBound34118 : H12AffineFastState.Bounded env34118 := by
  intro p hp
  have h : env34118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34112_34118 : H12AffineEnvironment.transform 6 9 env34112 = env34118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34112 == env34118) = true)

theorem identity34118 : scanCanonicalize (H12AffineFastState.compose env34118 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound34118 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env34119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32120,1025,29788,77851,21872,73803,95576,8193,64,97547,79130,17664,89378,75103,95611,257,21872,16385,513]

theorem envBound34119 : H12AffineFastState.Bounded env34119 := by
  intro p hp
  have h : env34119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34118_34119 : H12AffineEnvironment.transform 20 77851 env34118 = env34119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env34118 == env34119) = true)

theorem identity34119 : scanCanonicalize (H12AffineFastState.compose env34119 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound34119 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env34120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,13389,32120,1025,29788,12620,21872,8476,29711,8193,64,31836,13389,17664,23669,9224,29740,257,21872,16385,513]

theorem envBound34120 : H12AffineFastState.Bounded env34120 := by
  intro p hp
  have h : env34120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34119_34120 : H12AffineEnvironment.transform 15 343 env34119 = env34120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env34119 == env34120) = true)

theorem identity34120 : scanCanonicalize (H12AffineFastState.compose env34120 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34120 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,5392,23589,1025,21761,4113,21872,65,21842,348,64,23809,5392,17664,23669,1365,21873,257,21872,16385,513]

theorem envBound34121 : H12AffineFastState.Bounded env34121 := by
  intro p hp
  have h : env34121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34120_34121 : H12AffineEnvironment.transform 12 349 env34120 = env34121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34120 == env34121) = true)

theorem identity34121 : scanCanonicalize (H12AffineFastState.compose env34121 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound34121 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,81,343,5392,2420,1025,80,4113,33,65,3,348,64,2128,5392,4177,2340,1365,32,257,33,5456,513]

theorem envBound34122 : H12AffineFastState.Bounded env34122 := by
  intro p hp
  have h : env34122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34121_34122 : H12AffineEnvironment.transform 13 5457 env34121 = env34122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env34121 == env34122) = true)

theorem identity34122 : scanCanonicalize (H12AffineFastState.compose env34122 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34122 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34123 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5236,81,114,5173,2129,1025,80,4113,33,65,3,121,64,2128,5173,4177,2049,1136,32,36,33,5237,513]

theorem envBound34123 : H12AffineFastState.Bounded env34123 := by
  intro p hp
  have h : env34123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34122_34123 : H12AffineEnvironment.transform 7 37 env34122 = env34123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34122 == env34123) = true)

def env34124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543883,115150,17665,2363593,119043,4268162,257,2199998,2191387,63188]

theorem envBound34124 : H12AffineFastState.Bounded env34124 := by
  intro p hp
  have h : env34124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34084_34124 : H12AffineEnvironment.transform 22 2101329 env34084 = env34124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env34084 == env34124) = true)

def env34125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97547,115150,17665,2363593,119043,329730,257,2199998,2191387,63188]

theorem envBound34125 : H12AffineFastState.Bounded env34125 := by
  intro p hp
  have h : env34125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34124_34125 : H12AffineEnvironment.transform 21 272512 env34124 = env34125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34124 == env34125) = true)

theorem identity34125 : scanCanonicalize (H12AffineFastState.compose env34125 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound34125 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4160,272512,17,21763,8328,64,97547,115150,17665,262281,119043,329730,257,98814,90203,63188]

theorem envBound34126 : H12AffineFastState.Bounded env34126 := by
  intro p hp
  have h : env34126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34125_34126 : H12AffineEnvironment.transform 20 4160 env34125 = env34126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34125 == env34126) = true)

def env34127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21763,8192,64,97547,115014,17665,262145,119043,329730,257,98678,90203,63068]

theorem envBound34127 : H12AffineFastState.Bounded env34127 := by
  intro p hp
  have h : env34127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34126_34127 : H12AffineEnvironment.transform 6 8 env34126 = env34127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34126 == env34127) = true)

theorem identity34127 : scanCanonicalize (H12AffineFastState.compose env34127 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound34127 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,4160,41341,17,21763,8192,64,97547,115014,17665,35188,119043,98679,257,98678,90203,63068]

theorem envBound34128 : H12AffineFastState.Bounded env34128 := by
  intro p hp
  have h : env34128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34127_34128 : H12AffineEnvironment.transform 17 35189 env34127 = env34128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env34127 == env34128) = true)

theorem identity34128 : scanCanonicalize (H12AffineFastState.compose env34128 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound34128 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env34129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8494,49169,35189,1025,32769,4160,41341,17,21763,8192,64,23589,57448,17665,35188,61485,41049,257,41048,16757,63068]

theorem envBound34129 : H12AffineFastState.Bounded env34129 := by
  intro p hp
  have h : env34129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34128_34129 : H12AffineEnvironment.transform 15 8494 env34128 = env34129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env34128 == env34129) = true)

theorem identity34129 : scanCanonicalize (H12AffineFastState.compose env34129 (packedSelected [0,1,2,5,6,7,10,11,12,15,16,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34129 : packedSelected [0,1,2,5,6,7,10,11,12,15,16,23,24,28] rootPS < 2^1333 := by decide +kernel

def env34130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8494,46156,35189,1025,32769,4160,41341,17,8542,8192,64,10360,37941,12636,35188,33904,41049,257,41048,13608,33281]

theorem envBound34130 : H12AffineFastState.Bounded env34130 := by
  intro p hp
  have h : env34130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34129_34130 : H12AffineEnvironment.transform 13 13405 env34129 = env34130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34129 == env34130) = true)

theorem identity34130 : scanCanonicalize (H12AffineFastState.compose env34130 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound34130 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5156,32768,343,37941,35189,1025,32769,4160,33028,17,295,121,64,2049,37941,4389,35188,33904,32800,257,32801,5457,33281]

theorem envBound34131 : H12AffineFastState.Bounded env34131 := by
  intro p hp
  have h : env34131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34130_34131 : H12AffineEnvironment.transform 12 121 env34130 = env34131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env34130 == env34131) = true)

def env34132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21763,8193,64,97547,115015,17665,262144,119043,329730,257,98679,90203,63069]

theorem envBound34132 : H12AffineFastState.Bounded env34132 := by
  intro p hp
  have h : env34132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34126_34132 : H12AffineEnvironment.transform 6 9 env34126 = env34132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34126 == env34132) = true)

theorem identity34132 : scanCanonicalize (H12AffineFastState.compose env34132 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34132 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,32,17,21763,8193,64,97547,115015,17665,10281,119043,73771,257,98679,90203,63069]

theorem envBound34133 : H12AffineFastState.Bounded env34133 := by
  intro p hp
  have h : env34133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34132_34133 : H12AffineEnvironment.transform 17 10281 env34132 = env34133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34132 == env34133) = true)

theorem identity34133 : scanCanonicalize (H12AffineFastState.compose env34133 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound34133 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env34134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10281,1025,32769,4160,32,17,3,8193,64,75787,103495,4097,10281,99331,73771,257,98679,79195,41821]

theorem envBound34134 : H12AffineFastState.Bounded env34134 := by
  intro p hp
  have h : env34134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34133_34134 : H12AffineEnvironment.transform 13 5376 env34133 = env34134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34133 == env34134) = true)

theorem identity34134 : scanCanonicalize (H12AffineFastState.compose env34134 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34134 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env34135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,38160,2421,1025,32769,4160,32,17,3,349,64,67927,103495,4097,2421,99331,65911,257,98679,70663,33281]

theorem envBound34135 : H12AffineFastState.Bounded env34135 := by
  intro p hp
  have h : env34135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34134_34135 : H12AffineEnvironment.transform 12 348 env34134 = env34135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34134 == env34135) = true)

theorem identity34135 : scanCanonicalize (H12AffineFastState.compose env34135 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound34135 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,342,38160,2421,1025,32769,4160,32,17,3,349,64,2049,38161,4097,2421,34133,33,257,32801,5457,33281]

theorem envBound34136 : H12AffineFastState.Bounded env34136 := by
  intro p hp
  have h : env34136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34135_34136 : H12AffineEnvironment.transform 15 342 env34135 = env34136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env34135 == env34136) = true)

theorem identity34136 : scanCanonicalize (H12AffineFastState.compose env34136 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 2389) := by decide +kernel

theorem selectedBound34136 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env34137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2389,348,3157,32768,342,35909,2421,1025,32769,2325,32,17,3,349,64,2049,35908,2388,2421,34133,33,257,32801,3076,33281]

theorem envBound34137 : H12AffineFastState.Bounded env34137 := by
  intro p hp
  have h : env34137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34136_34137 : H12AffineEnvironment.transform 11 2389 env34136 = env34137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2389 env34136 == env34137) = true)

theorem identity34137 : scanCanonicalize (H12AffineFastState.compose env34137 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound34137 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env34138 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,2048,9,3157,32768,3,35909,2080,1025,32769,2112,32,17,3,8,64,2049,35908,2049,2080,33792,33,84,32801,3076,33281]

theorem envBound34138 : H12AffineFastState.Bounded env34138 := by
  intro p hp
  have h : env34138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34137_34138 : H12AffineEnvironment.transform 7 85 env34137 = env34138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env34137 == env34138) = true)

theorem identity34138 : scanCanonicalize (H12AffineFastState.compose env34138 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34138 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34139 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,2048,9,3157,0,3,3141,2080,1025,1,2112,32,17,3,8,64,2049,3140,2049,2080,1024,33,84,33,3076,513]

theorem envBound34139 : H12AffineFastState.Bounded env34139 := by
  intro p hp
  have h : env34139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34138_34139 : H12AffineEnvironment.transform 14 0 env34138 = env34139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34138 == env34139) = true)

theorem identity34139 : scanCanonicalize (H12AffineFastState.compose env34139 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound34139 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34140 : List Nat := [2,4,8,16,32,64,9,85,512,1024,577,577,9,1556,0,3,1540,609,1025,1,513,32,17,3,8,64,576,1541,576,609,1024,33,84,33,1605,513]

theorem envBound34140 : H12AffineFastState.Bounded env34140 := by
  intro p hp
  have h : env34140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34139_34140 : H12AffineEnvironment.transform 10 577 env34139 = env34140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env34139 == env34140) = true)

theorem identity34140 : scanCanonicalize (H12AffineFastState.compose env34140 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34140 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34141 : List Nat := [2,4,8,16,32,17,9,4,512,1024,528,528,9,1556,0,3,1540,560,1025,1,513,32,17,3,8,17,529,1541,529,560,1024,33,5,33,1556,513]

theorem envBound34141 : H12AffineFastState.Bounded env34141 := by
  intro p hp
  have h : env34141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34140_34141 : H12AffineEnvironment.transform 5 17 env34140 = env34141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34140 == env34141) = true)

theorem identity34141 : scanCanonicalize (H12AffineFastState.compose env34141 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound34141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34142 : List Nat := [2,4,8,16,32,17,9,4,512,549,528,528,9,49,0,3,33,560,548,1,513,32,17,3,8,17,529,32,529,560,549,33,5,33,49,513]

theorem envBound34142 : H12AffineFastState.Bounded env34142 := by
  intro p hp
  have h : env34142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34141_34142 : H12AffineEnvironment.transform 9 549 env34141 = env34142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env34141 == env34142) = true)

theorem identity34142 : scanCanonicalize (H12AffineFastState.compose env34142 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound34142 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34143 : List Nat := [2,4,8,16,32,17,9,4,1,36,17,17,9,49,0,3,33,49,37,1,0,32,17,3,8,17,16,32,16,49,36,33,5,33,49,0]

theorem envBound34143 : H12AffineFastState.Bounded env34143 := by
  intro p hp
  have h : env34143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34142_34143 : H12AffineEnvironment.transform 8 1 env34142 = env34143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env34142 == env34143) = true)

theorem identity34143 : scanCanonicalize (H12AffineFastState.compose env34143 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34143 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34144 : List Nat := [2,4,8,0,32,1,9,4,1,36,1,1,9,33,0,3,33,33,37,1,0,32,1,3,8,1,0,32,0,33,36,33,5,33,33,0]

theorem envBound34144 : H12AffineFastState.Bounded env34144 := by
  intro p hp
  have h : env34144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34143_34144 : H12AffineEnvironment.transform 3 0 env34143 = env34144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34143 == env34144) = true)

theorem identity34144 : scanCanonicalize (H12AffineFastState.compose env34144 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34145 : List Nat := [2,4,8,0,1,1,9,4,1,5,1,1,9,0,0,3,0,0,4,1,0,1,1,3,8,1,0,1,0,0,5,0,5,0,0,0]

theorem envBound34145 : H12AffineFastState.Bounded env34145 := by
  intro p hp
  have h : env34145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34144_34145 : H12AffineEnvironment.transform 4 1 env34144 = env34145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34144 == env34145) = true)

theorem identity34145 : scanCanonicalize (H12AffineFastState.compose env34145 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34146 : List Nat := [2,4,2,0,1,1,3,4,1,5,1,1,3,0,0,3,0,0,4,1,0,1,1,3,2,1,0,1,0,0,5,0,5,0,0,0]

theorem envBound34146 : H12AffineFastState.Bounded env34146 := by
  intro p hp
  have h : env34146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34145_34146 : H12AffineEnvironment.transform 2 2 env34145 = env34146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34145 == env34146) = true)

def env34147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97546,115150,17665,2363593,119043,329731,257,2199998,2191387,63188]

theorem envBound34147 : H12AffineFastState.Bounded env34147 := by
  intro p hp
  have h : env34147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34124_34147 : H12AffineEnvironment.transform 21 272513 env34124 = env34147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34124 == env34147) = true)

def env34148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101329,2114883,8192,64,97546,115014,17665,2363457,119043,329731,257,2199862,2191387,63068]

theorem envBound34148 : H12AffineFastState.Bounded env34148 := by
  intro p hp
  have h : env34148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34147_34148 : H12AffineEnvironment.transform 6 8 env34147 = env34148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34147 == env34148) = true)

def env34149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21763,8192,64,97546,115014,17665,262145,119043,329731,257,98678,90203,63068]

theorem envBound34149 : H12AffineFastState.Bounded env34149 := by
  intro p hp
  have h : env34149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34148_34149 : H12AffineEnvironment.transform 20 4160 env34148 = env34149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34148 == env34149) = true)

theorem identity34149 : scanCanonicalize (H12AffineFastState.compose env34149 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound34149 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,4160,41340,17,21763,8192,64,97546,115014,17665,35188,119043,98678,257,98678,90203,63068]

theorem envBound34150 : H12AffineFastState.Bounded env34150 := by
  intro p hp
  have h : env34150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34149_34150 : H12AffineEnvironment.transform 17 35189 env34149 = env34150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env34149 == env34150) = true)

theorem identity34150 : scanCanonicalize (H12AffineFastState.compose env34150 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound34150 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env34151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21794,49169,35189,1025,32769,4160,41340,17,21763,8192,64,10280,37988,17665,35188,33825,54356,257,54356,13689,63068]

theorem envBound34151 : H12AffineFastState.Bounded env34151 := by
  intro p hp
  have h : env34151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34150_34151 : H12AffineEnvironment.transform 15 21794 env34150 = env34151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env34150 == env34151) = true)

theorem identity34151 : scanCanonicalize (H12AffineFastState.compose env34151 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound34151 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env34152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21794,5392,23668,1025,21760,4160,29821,17,21763,8192,64,10280,16741,17665,23669,20768,341,257,341,13689,9053]

theorem envBound34152 : H12AffineFastState.Bounded env34152 := by
  intro p hp
  have h : env34152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34151_34152 : H12AffineEnvironment.transform 14 21761 env34151 = env34152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env34151 == env34152) = true)

theorem identity34152 : scanCanonicalize (H12AffineFastState.compose env34152 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34152 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env34153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,21761,21794,5392,23668,1025,21760,4160,21588,17,21763,41,64,2049,16741,17665,23669,20768,341,257,341,5456,884]

theorem envBound34153 : H12AffineFastState.Bounded env34153 := by
  intro p hp
  have h : env34153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34152_34153 : H12AffineEnvironment.transform 12 41 env34152 = env34153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34152 == env34153) = true)

theorem identity34153 : scanCanonicalize (H12AffineFastState.compose env34153 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound34153 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env34154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,372,343,5392,2049,1025,373,4160,33,17,374,41,64,2049,5392,4468,2048,1365,341,257,341,5456,884]

theorem envBound34154 : H12AffineFastState.Bounded env34154 := by
  intro p hp
  have h : env34154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34153_34154 : H12AffineEnvironment.transform 13 5237 env34153 = env34154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env34153 == env34154) = true)

theorem identity34154 : scanCanonicalize (H12AffineFastState.compose env34154 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound34154 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1296,41,357,372,343,0,2049,1025,373,1360,33,17,374,41,64,2049,0,1124,2048,1365,341,257,341,64,884]

theorem envBound34155 : H12AffineFastState.Bounded env34155 := by
  intro p hp
  have h : env34155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34154_34155 : H12AffineEnvironment.transform 11 1296 env34154 = env34155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env34154 == env34155) = true)

theorem identity34155 : scanCanonicalize (H12AffineFastState.compose env34155 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34155 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env34156 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,1296,8,324,341,343,0,2049,1025,340,1360,0,17,343,8,64,2049,0,1093,2048,1365,341,257,341,64,853]

theorem envBound34156 : H12AffineFastState.Bounded env34156 := by
  intro p hp
  have h : env34156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34155_34156 : H12AffineEnvironment.transform 4 1 env34155 = env34156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34155 == env34156) = true)

theorem identity34156 : scanCanonicalize (H12AffineFastState.compose env34156 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34156 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34157 : List Nat := [2,4,8,16,1,64,8,256,512,272,2048,0,8,324,341,343,0,2049,273,340,64,0,17,343,8,64,2049,0,341,2048,69,341,257,341,64,853]

theorem envBound34157 : H12AffineFastState.Bounded env34157 := by
  intro p hp
  have h : env34157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34156_34157 : H12AffineEnvironment.transform 9 272 env34156 = env34157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34156 == env34157) = true)

theorem identity34157 : scanCanonicalize (H12AffineFastState.compose env34157 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound34157 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env34158 : List Nat := [2,4,8,16,1,64,8,256,512,272,81,0,8,324,341,343,0,80,273,340,64,0,17,343,8,64,80,0,341,81,69,341,257,341,64,853]

theorem envBound34158 : H12AffineFastState.Bounded env34158 := by
  intro p hp
  have h : env34158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34157_34158 : H12AffineEnvironment.transform 10 81 env34157 = env34158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env34157 == env34158) = true)

def env34159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,16,21762,8192,64,97546,115014,17665,262144,119043,329731,257,98679,90202,63068]

theorem envBound34159 : H12AffineFastState.Bounded env34159 := by
  intro p hp
  have h : env34159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34148_34159 : H12AffineEnvironment.transform 20 4161 env34148 = env34159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34148 == env34159) = true)

theorem identity34159 : scanCanonicalize (H12AffineFastState.compose env34159 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34159 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1025,8540,4161,272393,16,21762,8192,64,97546,90139,17665,262144,94302,329731,257,73770,90202,22273]

theorem envBound34160 : H12AffineFastState.Bounded env34160 := by
  intro p hp
  have h : env34160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34159_34160 : H12AffineEnvironment.transform 14 8541 env34159 = env34160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34159 == env34160) = true)

theorem identity34160 : scanCanonicalize (H12AffineFastState.compose env34160 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound34160 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,2421,1025,8540,4161,8572,16,21762,8192,64,97546,90139,17665,2421,94302,65910,257,73770,90202,22273]

theorem envBound34161 : H12AffineFastState.Bounded env34161 := by
  intro p hp
  have h : env34161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34160_34161 : H12AffineEnvironment.transform 17 2421 env34160 = env34161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env34160 == env34161) = true)

theorem identity34161 : scanCanonicalize (H12AffineFastState.compose env34161 (packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound34161 : packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS < 2^1333 := by decide +kernel

def env34162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,30043,24908,2421,1025,8540,4161,8572,16,21762,8192,64,2129,5440,17665,2421,1285,29741,257,21873,5377,22273]

theorem envBound34162 : H12AffineFastState.Bounded env34162 := by
  intro p hp
  have h : env34162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34161_34162 : H12AffineEnvironment.transform 15 30043 env34161 = env34162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env34161 == env34162) = true)

theorem identity34162 : scanCanonicalize (H12AffineFastState.compose env34162 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound34162 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env34163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8541,8495,13624,2421,1025,8540,4161,8572,16,374,8192,64,2129,5440,4469,2421,1285,8281,257,261,5377,885]

theorem envBound34163 : H12AffineFastState.Bounded env34163 := by
  intro p hp
  have h : env34163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34162_34163 : H12AffineEnvironment.transform 13 5236 env34162 = env34163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env34162 == env34163) = true)

theorem identity34163 : scanCanonicalize (H12AffineFastState.compose env34163 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34163 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env34164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5236,80,34,5173,2421,1025,81,4161,113,16,374,269,64,2129,5440,4469,2421,1285,340,257,261,5377,885]

theorem envBound34164 : H12AffineFastState.Bounded env34164 := by
  intro p hp
  have h : env34164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34163_34164 : H12AffineEnvironment.transform 12 269 env34163 = env34164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34163 == env34164) = true)

theorem identity34164 : scanCanonicalize (H12AffineFastState.compose env34164 (packedSelected [0,4,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34164 : packedSelected [0,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env34165 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5236,80,34,5173,2049,1025,81,4161,113,16,2,121,64,2129,5172,4097,2049,1137,32,117,113,5237,513]

theorem envBound34165 : H12AffineFastState.Bounded env34165 := by
  intro p hp
  have h : env34165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34164_34165 : H12AffineEnvironment.transform 7 116 env34164 = env34165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34164 == env34165) = true)

theorem identity34165 : scanCanonicalize (H12AffineFastState.compose env34165 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34165 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34166 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5173,2049,1025,1,4113,33,16,2,41,16,2049,5172,4097,2049,1057,32,37,33,5157,513]

theorem envBound34166 : H12AffineFastState.Bounded env34166 := by
  intro p hp
  have h : env34166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34165_34166 : H12AffineEnvironment.transform 5 16 env34165 = env34166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34165 == env34166) = true)

theorem identity34166 : scanCanonicalize (H12AffineFastState.compose env34166 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34166 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34167 : List Nat := [2,4,8,16,17,16,8,21,512,1024,2048,4096,24,5141,0,19,5124,2049,1025,1,4113,16,16,2,24,16,2049,5125,4097,2049,1040,17,20,16,5140,513]

theorem envBound34167 : H12AffineFastState.Bounded env34167 := by
  intro p hp
  have h : env34167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34166_34167 : H12AffineEnvironment.transform 4 17 env34166 = env34167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34166 == env34167) = true)

theorem identity34167 : scanCanonicalize (H12AffineFastState.compose env34167 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound34167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34168 : List Nat := [2,4,8,16,17,16,8,21,512,1024,2048,529,24,1540,0,19,1557,2049,1025,1,512,16,16,2,24,16,2049,1556,528,2049,1040,17,20,16,1541,513]

theorem envBound34168 : H12AffineFastState.Bounded env34168 := by
  intro p hp
  have h : env34168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34167_34168 : H12AffineEnvironment.transform 11 529 env34167 = env34168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env34167 == env34168) = true)

theorem identity34168 : scanCanonicalize (H12AffineFastState.compose env34168 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound34168 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34169 : List Nat := [2,4,8,16,17,16,8,21,512,5,2048,529,24,513,0,19,528,2049,4,1,512,16,16,2,24,16,2049,529,528,2049,21,17,20,16,512,513]

theorem envBound34169 : H12AffineFastState.Bounded env34169 := by
  intro p hp
  have h : env34169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34168_34169 : H12AffineEnvironment.transform 9 5 env34168 = env34169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env34168 == env34169) = true)

theorem identity34169 : scanCanonicalize (H12AffineFastState.compose env34169 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34169 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34170 : List Nat := [2,4,8,0,1,0,8,5,512,5,2048,513,8,513,0,3,512,2049,4,1,512,0,0,2,8,0,2049,513,512,2049,5,1,4,0,512,513]

theorem envBound34170 : H12AffineFastState.Bounded env34170 := by
  intro p hp
  have h : env34170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34169_34170 : H12AffineEnvironment.transform 3 0 env34169 = env34170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34169 == env34170) = true)

theorem identity34170 : scanCanonicalize (H12AffineFastState.compose env34170 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound34170 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env34171 : List Nat := [2,4,8,0,1,0,8,5,512,5,513,513,8,513,0,3,512,512,4,1,512,0,0,2,8,0,512,513,512,512,5,1,4,0,512,513]

theorem envBound34171 : H12AffineFastState.Bounded env34171 := by
  intro p hp
  have h : env34171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34170_34171 : H12AffineEnvironment.transform 10 513 env34170 = env34171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env34170 == env34171) = true)

def env34172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101329,2114883,8193,64,97546,115015,17665,2363456,119043,329731,257,2199863,2191387,63069]

theorem envBound34172 : H12AffineFastState.Bounded env34172 := by
  intro p hp
  have h : env34172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34147_34172 : H12AffineEnvironment.transform 6 9 env34147 = env34172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34147 == env34172) = true)

def env34173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,21763,8193,64,97546,115015,17665,262144,119043,329731,257,98679,90203,63069]

theorem envBound34173 : H12AffineFastState.Bounded env34173 := by
  intro p hp
  have h : env34173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34172_34173 : H12AffineEnvironment.transform 20 4160 env34172 = env34173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34172 == env34173) = true)

theorem identity34173 : scanCanonicalize (H12AffineFastState.compose env34173 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34173 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,33,17,21763,8193,64,97546,115015,17665,10281,119043,73770,257,98679,90203,63069]

theorem envBound34174 : H12AffineFastState.Bounded env34174 := by
  intro p hp
  have h : env34174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34173_34174 : H12AffineEnvironment.transform 17 10281 env34173 = env34174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34173 == env34174) = true)

theorem identity34174 : scanCanonicalize (H12AffineFastState.compose env34174 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound34174 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env34175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,49168,10281,1025,32769,4160,33,17,21763,8193,64,10589,38160,17665,10281,34132,29821,257,54560,13324,63069]

theorem envBound34175 : H12AffineFastState.Bounded env34175 := by
  intro p hp
  have h : env34175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34174_34175 : H12AffineEnvironment.transform 15 21591 env34174 = env34175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env34174 == env34175) = true)

theorem identity34175 : scanCanonicalize (H12AffineFastState.compose env34175 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound34175 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env34176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21591,5393,10281,1025,21760,4160,33,17,21763,8193,64,10589,16401,17665,10281,20565,29821,257,33,13324,9052]

theorem envBound34176 : H12AffineFastState.Bounded env34176 := by
  intro p hp
  have h : env34176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34175_34176 : H12AffineEnvironment.transform 14 21761 env34175 = env34176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env34175 == env34176) = true)

theorem identity34176 : scanCanonicalize (H12AffineFastState.compose env34176 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34176 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8202,5393,10281,1025,8541,4160,33,17,8542,8193,64,10589,13388,12636,10281,9224,32,257,33,13324,9052]

theorem envBound34177 : H12AffineFastState.Bounded env34177 := by
  intro p hp
  have h : env34177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34176_34177 : H12AffineEnvironment.transform 13 13405 env34176 = env34177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34176 == env34177) = true)

theorem identity34177 : scanCanonicalize (H12AffineFastState.compose env34177 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34177 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,81,263,5393,2340,1025,80,4160,33,17,83,268,64,2128,5441,4177,2340,1285,32,257,33,5377,593]

theorem envBound34178 : H12AffineFastState.Bounded env34178 := by
  intro p hp
  have h : env34178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34177_34178 : H12AffineEnvironment.transform 12 269 env34177 = env34178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34177 == env34178) = true)

theorem identity34178 : scanCanonicalize (H12AffineFastState.compose env34178 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound34178 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env34179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,522,4096,269,5456,81,263,5393,814,1025,80,4160,33,17,83,268,64,602,5441,4177,814,1285,32,257,33,5377,593]

theorem envBound34179 : H12AffineFastState.Bounded env34179 := by
  intro p hp
  have h : env34179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34178_34179 : H12AffineEnvironment.transform 10 522 env34178 = env34179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env34178 == env34179) = true)

theorem identity34179 : scanCanonicalize (H12AffineFastState.compose env34179 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound34179 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env34180 : List Nat := [2,4,8,16,32,64,9,84,512,1024,522,4096,89,5124,81,83,5189,634,1025,80,4160,33,17,83,88,64,602,5141,4177,634,1105,32,85,33,5205,593]

theorem envBound34180 : H12AffineFastState.Bounded env34180 := by
  intro p hp
  have h : env34180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34179_34180 : H12AffineEnvironment.transform 7 84 env34179 = env34180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env34179 == env34180) = true)

theorem identity34180 : scanCanonicalize (H12AffineFastState.compose env34180 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34180 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34181 : List Nat := [2,4,8,16,1,64,9,84,512,1024,522,4096,89,5124,81,83,5189,603,1025,80,4160,0,17,83,88,64,602,5141,4177,603,1105,1,85,0,5205,593]

theorem envBound34181 : H12AffineFastState.Bounded env34181 := by
  intro p hp
  have h : env34181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34180_34181 : H12AffineEnvironment.transform 4 1 env34180 = env34181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34180 == env34181) = true)

theorem identity34181 : scanCanonicalize (H12AffineFastState.compose env34181 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34181 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34182 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,4096,9,5124,1,3,5141,523,1025,0,4112,0,17,3,8,16,522,5141,4097,523,1025,1,5,0,5125,513]

theorem envBound34182 : H12AffineFastState.Bounded env34182 := by
  intro p hp
  have h : env34182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34181_34182 : H12AffineEnvironment.transform 5 16 env34181 = env34182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34181 == env34182) = true)

def env34183 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,16,9,1044,1,3,1029,523,1025,0,0,0,17,3,8,16,522,1029,17,523,1025,1,5,0,1045,513]

theorem envBound34183 : H12AffineFastState.Bounded env34183 := by
  intro p hp
  have h : env34183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34182_34183 : H12AffineEnvironment.transform 11 16 env34182 = env34183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34182 == env34183) = true)

theorem identity34183 : scanCanonicalize (H12AffineFastState.compose env34183 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound34183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34184 : List Nat := [2,4,8,5,1,5,9,4,512,1024,522,5,9,1025,1,3,1029,523,1025,0,0,0,4,3,8,5,522,1029,4,523,1025,1,5,0,1024,513]

theorem envBound34184 : H12AffineFastState.Bounded env34184 := by
  intro p hp
  have h : env34184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34183_34184 : H12AffineEnvironment.transform 3 5 env34183 = env34184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34183 == env34184) = true)

def env34185 : List Nat := [2,4,8,5,1,5,9,4,512,0,522,5,9,1,1,3,5,523,1,0,0,0,4,3,8,5,522,5,4,523,1,1,5,0,0,513]

theorem envBound34185 : H12AffineFastState.Bounded env34185 := by
  intro p hp
  have h : env34185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34184_34185 : H12AffineEnvironment.transform 9 0 env34184 = env34185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env34184 == env34185) = true)

theorem identity34185 : scanCanonicalize (H12AffineFastState.compose env34185 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34186 : List Nat := [1,4,8,5,1,5,9,4,512,0,521,5,9,1,1,0,5,520,1,0,0,0,4,0,8,5,521,5,4,520,1,1,5,0,0,513]

theorem envBound34186 : H12AffineFastState.Bounded env34186 := by
  intro p hp
  have h : env34186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34185_34186 : H12AffineEnvironment.transform 0 1 env34185 = env34186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34185 == env34186) = true)

def leafEnv34186 : List Nat := [1,4,8,5,1,5,9,4,512,0,521,5,9,1,1,0,5,520,1,0,0,0,4,0,1,8,1,5,521,5,4,520,1,1,5,0,4,1,0,513,1,1,0]

def active34186 : List Nat := [1,2,8]

def tree34186 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34186 : H12WitnessSearch.Good tree34186 := H12GlobalWitnessIndex.good

theorem leafIdentity34186 : H12AffineFastState.composeSystem env34186 rootObs = leafEnv34186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34186 rootObs == leafEnv34186) = true)

theorem terminalChecked34186 : H12PackedTerminal.terminalCheckFast leafEnv34186 active34186 tree34186 = true := by decide +kernel

def env34187 : List Nat := [2,4,8,5,1,5,9,4,512,1,522,5,9,0,1,3,4,523,0,0,0,0,4,3,8,5,522,4,4,523,0,1,5,0,1,513]

theorem envBound34187 : H12AffineFastState.Bounded env34187 := by
  intro p hp
  have h : env34187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34184_34187 : H12AffineEnvironment.transform 9 1 env34184 = env34187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env34184 == env34187) = true)

theorem identity34187 : scanCanonicalize (H12AffineFastState.compose env34187 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound34187 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34188 : List Nat := [2,4,8,5,1,5,9,4,8,1,2,5,9,0,1,3,4,3,0,0,0,0,4,3,8,5,2,4,4,3,0,1,5,0,1,9]

theorem envBound34188 : H12AffineFastState.Bounded env34188 := by
  intro p hp
  have h : env34188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34187_34188 : H12AffineEnvironment.transform 8 8 env34187 = env34188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env34187 == env34188) = true)

def leafEnv34188 : List Nat := [2,4,8,5,1,5,9,4,8,1,2,5,9,0,1,3,4,3,0,0,0,0,4,3,0,8,1,5,2,4,4,3,0,1,5,0,4,2,1,9,1,1,0]

def active34188 : List Nat := [0,1,2]

def tree34188 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34188 : H12WitnessSearch.Good tree34188 := H12GlobalWitnessIndex.good

theorem leafIdentity34188 : H12AffineFastState.composeSystem env34188 rootObs = leafEnv34188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34188 rootObs == leafEnv34188) = true)

theorem terminalChecked34188 : H12PackedTerminal.terminalCheckFast leafEnv34188 active34188 tree34188 = true := by decide +kernel

def env34189 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,17,9,1045,1,3,1028,523,1025,0,1,0,17,3,8,16,522,1028,16,523,1025,1,5,0,1044,513]

theorem envBound34189 : H12AffineFastState.Bounded env34189 := by
  intro p hp
  have h : env34189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34182_34189 : H12AffineEnvironment.transform 11 17 env34182 = env34189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34182 == env34189) = true)

theorem identity34189 : scanCanonicalize (H12AffineFastState.compose env34189 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound34189 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34190 : List Nat := [2,4,8,16,1,16,9,4,512,1,522,17,9,20,1,3,5,523,0,0,1,0,17,3,8,16,522,5,16,523,0,1,5,0,21,513]

theorem envBound34190 : H12AffineFastState.Bounded env34190 := by
  intro p hp
  have h : env34190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34189_34190 : H12AffineEnvironment.transform 9 1 env34189 = env34190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env34189 == env34190) = true)

def env34191 : List Nat := [2,4,8,4,1,4,9,4,512,1,522,5,9,0,1,3,5,523,0,0,1,0,5,3,8,4,522,5,4,523,0,1,5,0,1,513]

theorem envBound34191 : H12AffineFastState.Bounded env34191 := by
  intro p hp
  have h : env34191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34190_34191 : H12AffineEnvironment.transform 3 4 env34190 = env34191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env34190 == env34191) = true)

theorem identity34191 : scanCanonicalize (H12AffineFastState.compose env34191 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34191 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34192 : List Nat := [0,4,8,4,1,4,9,4,512,1,520,5,9,0,1,1,5,521,0,0,1,0,5,1,8,4,520,5,4,521,0,1,5,0,1,513]

theorem envBound34192 : H12AffineFastState.Bounded env34192 := by
  intro p hp
  have h : env34192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34191_34192 : H12AffineEnvironment.transform 0 0 env34191 = env34192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34191 == env34192) = true)

def leafEnv34192 : List Nat := [0,4,8,4,1,4,9,4,512,1,520,5,9,0,1,1,5,521,0,0,1,0,5,1,0,8,1,4,520,5,4,521,0,1,5,0,4,0,1,513,1,0,0]

def active34192 : List Nat := [1,2,8]

def tree34192 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34192 : H12WitnessSearch.Good tree34192 := H12GlobalWitnessIndex.good

theorem leafIdentity34192 : H12AffineFastState.composeSystem env34192 rootObs = leafEnv34192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34192 rootObs == leafEnv34192) = true)

theorem terminalChecked34192 : H12PackedTerminal.terminalCheckFast leafEnv34192 active34192 tree34192 = true := by decide +kernel

def env34193 : List Nat := [2,4,8,5,1,5,9,4,512,1,522,4,9,1,1,3,5,523,0,0,1,0,4,3,8,5,522,5,5,523,0,1,5,0,0,513]

theorem envBound34193 : H12AffineFastState.Bounded env34193 := by
  intro p hp
  have h : env34193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34190_34193 : H12AffineEnvironment.transform 3 5 env34190 = env34193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34190 == env34193) = true)

theorem identity34193 : scanCanonicalize (H12AffineFastState.compose env34193 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound34193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34194 : List Nat := [2,4,8,5,1,5,9,4,9,1,3,4,9,1,1,3,5,2,0,0,1,0,4,3,8,5,3,5,5,2,0,1,5,0,0,8]

theorem envBound34194 : H12AffineFastState.Bounded env34194 := by
  intro p hp
  have h : env34194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34193_34194 : H12AffineEnvironment.transform 8 9 env34193 = env34194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env34193 == env34194) = true)

def leafEnv34194 : List Nat := [2,4,8,5,1,5,9,4,9,1,3,4,9,1,1,3,5,2,0,0,1,0,4,3,0,8,1,5,3,5,5,2,0,1,5,0,4,2,0,8,1,0,0]

def active34194 : List Nat := [0,1,2]

def tree34194 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34194 : H12WitnessSearch.Good tree34194 := H12GlobalWitnessIndex.good

theorem leafIdentity34194 : H12AffineFastState.composeSystem env34194 rootObs = leafEnv34194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34194 rootObs == leafEnv34194) = true)

theorem terminalChecked34194 : H12PackedTerminal.terminalCheckFast leafEnv34194 active34194 tree34194 = true := by decide +kernel

def env34195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,16,21762,8193,64,97546,115015,17665,262145,119043,329731,257,98678,90202,63069]

theorem envBound34195 : H12AffineFastState.Bounded env34195 := by
  intro p hp
  have h : env34195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34172_34195 : H12AffineEnvironment.transform 20 4161 env34172 = env34195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34172 == env34195) = true)

theorem identity34195 : scanCanonicalize (H12AffineFastState.compose env34195 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound34195 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env34196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,89459,1025,32769,4161,95611,16,21762,8193,64,97546,115015,17665,89458,119043,21872,257,98678,90202,63069]

theorem envBound34196 : H12AffineFastState.Bounded env34196 := by
  intro p hp
  have h : env34196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34195_34196 : H12AffineEnvironment.transform 17 89459 env34195 = env34196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env34195 == env34196) = true)

theorem identity34196 : scanCanonicalize (H12AffineFastState.compose env34196 (packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound34196 : packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env34197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,65536,13340,89459,1025,29709,4161,95611,16,21762,8193,64,97546,79179,17665,89458,75023,21872,257,95610,90202,593]

theorem envBound34197 : H12AffineFastState.Bounded env34197 := by
  intro p hp
  have h : env34197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34196_34197 : H12AffineEnvironment.transform 14 29708 env34196 = env34197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env34196 == env34197) = true)

theorem identity34197 : scanCanonicalize (H12AffineFastState.compose env34197 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound34197 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,65536,13340,67618,1025,8540,4161,73770,16,83,8193,64,75867,79179,4176,67619,75023,33,257,73771,79115,593]

theorem envBound34198 : H12AffineFastState.Bounded env34198 := by
  intro p hp
  have h : env34198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34197_34198 : H12AffineEnvironment.transform 13 5457 env34197 = env34198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env34197 == env34198) = true)

theorem identity34198 : scanCanonicalize (H12AffineFastState.compose env34198 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34198 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env34199 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,65536,13340,67618,1025,8460,4113,73770,16,3,8193,16,75787,79131,4096,67619,75023,33,257,73771,79115,513]

theorem envBound34199 : H12AffineFastState.Bounded env34199 := by
  intro p hp
  have h : env34199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34198_34199 : H12AffineEnvironment.transform 5 16 env34198 = env34199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34198 == env34199) = true)

theorem identity34199 : scanCanonicalize (H12AffineFastState.compose env34199 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound34199 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34200 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,1330,13340,3344,1025,8460,4113,9496,16,3,8193,16,11577,12329,4096,3345,8253,33,257,9497,12345,513]

theorem envBound34200 : H12AffineFastState.Bounded env34200 := by
  intro p hp
  have h : env34200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34199_34200 : H12AffineEnvironment.transform 15 1330 env34199 = env34200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env34199 == env34200) = true)

theorem identity34200 : scanCanonicalize (H12AffineFastState.compose env34200 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34200 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env34201 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,1330,5393,3344,1025,1,4113,1045,16,3,268,16,3124,4388,4096,3345,304,33,257,1044,4404,513]

theorem envBound34201 : H12AffineFastState.Bounded env34201 := by
  intro p hp
  have h : env34201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34200_34201 : H12AffineEnvironment.transform 12 269 env34200 = env34201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34200 == env34201) = true)

theorem identity34201 : scanCanonicalize (H12AffineFastState.compose env34201 (packedSelected [0,1,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound34201 : packedSelected [0,1,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env34202 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1297,4096,269,5377,0,1330,5393,1,1025,1,4113,1045,16,3,268,16,293,4388,4096,0,304,33,257,1044,4404,513]

theorem envBound34202 : H12AffineFastState.Bounded env34202 := by
  intro p hp
  have h : env34202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34201_34202 : H12AffineEnvironment.transform 10 1297 env34201 = env34202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env34201 == env34202) = true)

def env34203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound34203 : H12AffineFastState.Bounded env34203 := by
  intro p hp
  have h : env34203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33452_34203 : H12AffineEnvironment.transform 25 65 env33452 = env34203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env33452 == env34203) = true)

def env34204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound34204 : H12AffineFastState.Bounded env34204 := by
  intro p hp
  have h : env34204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34203_34204 : H12AffineEnvironment.transform 26 30393344 env34203 = env34204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env34203 == env34204) = true)

def env34205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound34205 : H12AffineFastState.Bounded env34205 := by
  intro p hp
  have h : env34205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34204_34205 : H12AffineEnvironment.transform 18 1024 env34204 = env34205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env34204 == env34205) = true)

theorem identity34205 : scanCanonicalize (H12AffineFastState.compose env34205 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound34205 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362363,18973836,10507601,8456378,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound34206 : H12AffineFastState.Bounded env34206 := by
  intro p hp
  have h : env34206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34205_34206 : H12AffineEnvironment.transform 17 247995 env34205 = env34206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env34205 == env34206) = true)

def env34207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784807,5392,10507601,8456378,10491276,4256860,256,8410416,8434837,10564187]

theorem envBound34207 : H12AffineFastState.Bounded env34207 := by
  intro p hp
  have h : env34207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34206_34207 : H12AffineEnvironment.transform 23 2199964 env34206 = env34207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env34206 == env34207) = true)

def env34208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,8388608,98780,8328,65,12683623,5392,8406289,8456378,8390092,4256860,256,8410416,8434837,8462875]

theorem envBound34208 : H12AffineFastState.Bounded env34208 := by
  intro p hp
  have h : env34208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34207_34208 : H12AffineEnvironment.transform 20 4160 env34207 = env34208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34207 == env34208) = true)

def env34209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374560,98780,8328,65,215367,5392,4359473,4442266,4376044,4256860,256,4363536,4355253,4448827]

theorem envBound34209 : H12AffineFastState.Bounded env34209 := by
  intro p hp
  have h : env34209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34208_34209 : H12AffineEnvironment.transform 22 4374560 env34208 = env34209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env34208 == env34209) = true)

theorem identity34209 : scanCanonicalize (H12AffineFastState.compose env34209 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound34209 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138341,1024,32769,4160,4194304,4374560,21762,8328,65,171417,5392,4359473,4332612,4376044,4256860,256,4363536,4355253,4339429]

theorem envBound34210 : H12AffineFastState.Bounded env34210 := by
  intro p hp
  have h : env34210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34209_34210 : H12AffineEnvironment.transform 15 54494 env34209 = env34210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env34209 == env34210) = true)

def env34211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138341,1024,32769,4160,180408,152,21762,8328,65,171417,5392,17801,56572,1364,144612,256,21928,46093,63069]

theorem envBound34211 : H12AffineFastState.Bounded env34211 := by
  intro p hp
  have h : env34211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34210_34211 : H12AffineEnvironment.transform 21 180408 env34210 = env34211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env34210 == env34211) = true)

theorem identity34211 : scanCanonicalize (H12AffineFastState.compose env34211 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34211 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env34212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,138341,1024,32769,4160,169401,152,3,8328,65,171417,5392,4232,35325,1364,144612,256,169,46093,41820]

theorem envBound34212 : H12AffineFastState.Bounded env34212 := by
  intro p hp
  have h : env34212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34211_34212 : H12AffineEnvironment.transform 13 5377 env34211 = env34212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34211 == env34212) = true)

theorem identity34212 : scanCanonicalize (H12AffineFastState.compose env34212 (packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound34212 : packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env34213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,13341,10360,1024,32769,4160,41380,152,3,8328,65,43396,5392,4232,35325,1364,249,256,169,46093,41820]

theorem envBound34213 : H12AffineFastState.Bounded env34213 := by
  intro p hp
  have h : env34213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34212_34213 : H12AffineEnvironment.transform 16 13341 env34212 = env34213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env34212 == env34213) = true)

theorem identity34213 : scanCanonicalize (H12AffineFastState.compose env34213 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34213 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env34214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,32768,33247,5440,2341,1024,32769,4160,33017,152,3,469,65,35033,5392,4232,35325,1364,249,256,169,38224,33281]

theorem envBound34214 : H12AffineFastState.Bounded env34214 := by
  intro p hp
  have h : env34214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34213_34214 : H12AffineEnvironment.transform 12 349 env34213 = env34214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34213 == env34214) = true)

theorem identity34214 : scanCanonicalize (H12AffineFastState.compose env34214 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound34214 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env34215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,217,262,5440,2341,1024,216,4160,32,152,3,469,65,2048,5392,4232,2340,1364,249,256,169,5513,728]

theorem envBound34215 : H12AffineFastState.Bounded env34215 := by
  intro p hp
  have h : env34215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34214_34215 : H12AffineEnvironment.transform 14 217 env34214 = env34215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env34214 == env34215) = true)

theorem identity34215 : scanCanonicalize (H12AffineFastState.compose env34215 (packedSelected [4,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound34215 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env34216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1196,349,429,217,262,492,2341,1024,216,1260,32,152,3,469,65,2048,444,1060,2340,1364,249,256,169,293,728]

theorem envBound34216 : H12AffineFastState.Bounded env34216 := by
  intro p hp
  have h : env34216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34215_34216 : H12AffineEnvironment.transform 11 1196 env34215 = env34216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env34215 == env34216) = true)

theorem identity34216 : scanCanonicalize (H12AffineFastState.compose env34216 (packedSelected [1,8,10,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound34216 : packedSelected [1,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env34217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1125,1196,349,429,217,262,492,1344,1024,216,1260,32,152,3,469,65,1125,444,1060,1345,1364,249,256,169,293,728]

theorem envBound34217 : H12AffineFastState.Bounded env34217 := by
  intro p hp
  have h : env34217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34216_34217 : H12AffineEnvironment.transform 10 1125 env34216 = env34217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env34216 == env34217) = true)

theorem identity34217 : scanCanonicalize (H12AffineFastState.compose env34217 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34217 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env34218 : List Nat := [2,4,8,16,32,64,128,37,512,1024,1125,1196,120,136,217,35,201,1125,1024,216,1260,32,152,3,240,65,1125,153,1060,1124,1137,249,37,169,0,728]

theorem envBound34218 : H12AffineFastState.Bounded env34218 := by
  intro p hp
  have h : env34218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34217_34218 : H12AffineEnvironment.transform 7 37 env34217 = env34218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34217 == env34218) = true)

theorem identity34218 : scanCanonicalize (H12AffineFastState.compose env34218 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound34218 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34219 : List Nat := [2,4,8,16,32,64,128,37,512,236,137,64,120,136,217,35,201,137,236,216,0,32,152,3,240,65,137,153,200,136,157,249,37,169,0,728]

theorem envBound34219 : H12AffineFastState.Bounded env34219 := by
  intro p hp
  have h : env34219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34218_34219 : H12AffineEnvironment.transform 9 236 env34218 = env34219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env34218 == env34219) = true)

theorem identity34219 : scanCanonicalize (H12AffineFastState.compose env34219 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34219 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34220 : List Nat := [2,4,8,16,32,64,8,37,512,100,1,64,120,0,81,35,65,1,100,80,0,32,16,3,120,65,1,17,64,0,21,113,37,33,0,592]

theorem envBound34220 : H12AffineFastState.Bounded env34220 := by
  intro p hp
  have h : env34220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34219_34220 : H12AffineEnvironment.transform 6 8 env34219 = env34220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34219 == env34220) = true)

theorem identity34220 : scanCanonicalize (H12AffineFastState.compose env34220 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34220 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34221 : List Nat := [2,4,8,16,1,64,8,4,512,69,1,64,89,0,81,2,65,1,69,80,0,1,16,3,89,65,1,17,64,0,21,80,4,0,0,592]

theorem envBound34221 : H12AffineFastState.Bounded env34221 := by
  intro p hp
  have h : env34221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34220_34221 : H12AffineEnvironment.transform 4 1 env34220 = env34221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34220 == env34221) = true)

def env34222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138341,1024,32769,4160,180409,153,21762,8328,65,171417,5392,17800,56573,1365,144613,256,21929,46092,63068]

theorem envBound34222 : H12AffineFastState.Bounded env34222 := by
  intro p hp
  have h : env34222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34210_34222 : H12AffineEnvironment.transform 21 180409 env34210 = env34222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env34210 == env34222) = true)

theorem identity34222 : scanCanonicalize (H12AffineFastState.compose env34222 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34222 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env34223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,54494,131072,138341,1024,32769,4160,180409,153,21762,389,65,171417,5392,17800,56573,1365,136680,256,21929,38145,55121]

theorem envBound34223 : H12AffineFastState.Bounded env34223 := by
  intro p hp
  have h : env34223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34222_34223 : H12AffineEnvironment.transform 12 269 env34222 = env34223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34222 == env34223) = true)

theorem identity34223 : scanCanonicalize (H12AffineFastState.compose env34223 (packedSelected [0,1,4,7,10,11,22,26,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34223 : packedSelected [0,1,4,7,10,11,22,26,28,32] rootPS < 2^1333 := by decide +kernel

def env34224 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,54279,131072,138341,1024,32769,4160,180320,64,21762,348,65,171328,5392,17745,56356,1365,136497,256,21872,38145,55121]

theorem envBound34224 : H12AffineFastState.Bounded env34224 := by
  intro p hp
  have h : env34224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34223_34224 : H12AffineEnvironment.transform 6 89 env34223 = env34224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34223 == env34224) = true)

theorem identity34224 : scanCanonicalize (H12AffineFastState.compose env34224 (packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound34224 : packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env34225 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,54279,49169,56436,1024,32769,4160,113,64,21762,348,65,23889,5392,17745,56356,1365,54560,256,21872,38145,55121]

theorem envBound34225 : H12AffineFastState.Bounded env34225 := by
  intro p hp
  have h : env34225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34224_34225 : H12AffineEnvironment.transform 16 49169 env34224 = env34225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env34224 == env34225) = true)

theorem identity34225 : scanCanonicalize (H12AffineFastState.compose env34225 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound34225 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env34226 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21760,263,5393,2420,1024,21761,4160,113,64,21762,348,65,23889,5392,17745,2340,1365,32,256,21872,16385,593]

theorem envBound34226 : H12AffineFastState.Bounded env34226 := by
  intro p hp
  have h : env34226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34225_34226 : H12AffineEnvironment.transform 14 21760 env34225 = env34226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env34225 == env34226) = true)

theorem identity34226 : scanCanonicalize (H12AffineFastState.compose env34226 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34226 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34227 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,263,5393,2340,1024,21761,4112,33,16,21762,268,17,23809,5392,17665,2340,1285,32,256,21792,16385,513]

theorem envBound34227 : H12AffineFastState.Bounded env34227 := by
  intro p hp
  have h : env34227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34226_34227 : H12AffineEnvironment.transform 5 16 env34226 = env34227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34226 == env34227) = true)

theorem identity34227 : scanCanonicalize (H12AffineFastState.compose env34227 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34227 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env34228 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1024,0,4112,33,16,3,268,17,2048,5392,4096,2340,1285,32,256,33,5376,513]

theorem envBound34228 : H12AffineFastState.Bounded env34228 := by
  intro p hp
  have h : env34228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34227_34228 : H12AffineEnvironment.transform 13 5377 env34227 = env34228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34227 == env34228) = true)

theorem identity34228 : scanCanonicalize (H12AffineFastState.compose env34228 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34229 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1024,0,4112,33,16,3,40,17,2048,5172,4096,2048,1057,32,36,33,5156,513]

theorem envBound34229 : H12AffineFastState.Bounded env34229 := by
  intro p hp
  have h : env34229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34228_34229 : H12AffineEnvironment.transform 7 36 env34228 = env34229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34228 == env34229) = true)

theorem identity34229 : scanCanonicalize (H12AffineFastState.compose env34229 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34229 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34230 : List Nat := [2,4,8,16,32,16,9,36,512,1024,523,4096,41,5157,1,35,5173,523,1024,0,4112,33,16,3,40,17,523,5172,4096,523,1057,32,36,33,5156,513]

theorem envBound34230 : H12AffineFastState.Bounded env34230 := by
  intro p hp
  have h : env34230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34229_34230 : H12AffineEnvironment.transform 10 523 env34229 = env34230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34229 == env34230) = true)

theorem identity34230 : scanCanonicalize (H12AffineFastState.compose env34230 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34230 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34231 : List Nat := [2,4,8,16,1,16,9,5,512,1024,523,4096,8,5124,1,2,5140,523,1024,0,4112,0,16,3,9,17,523,5141,4096,523,1024,1,5,0,5125,513]

theorem envBound34231 : H12AffineFastState.Bounded env34231 := by
  intro p hp
  have h : env34231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34230_34231 : H12AffineEnvironment.transform 4 1 env34230 = env34231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34230 == env34231) = true)

def env34232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374561,98780,8328,65,215366,5392,4359472,4442267,4376045,4256860,256,4363537,4355252,4448826]

theorem envBound34232 : H12AffineFastState.Bounded env34232 := by
  intro p hp
  have h : env34232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34208_34232 : H12AffineEnvironment.transform 22 4374561 env34208 = env34232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env34208 == env34232) = true)

theorem identity34232 : scanCanonicalize (H12AffineFastState.compose env34232 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound34232 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,201967,120014,98780,8328,65,215366,5392,102879,56436,119042,254131,256,98814,90203,63189]

theorem envBound34233 : H12AffineFastState.Bounded env34233 := by
  intro p hp
  have h : env34233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34232_34233 : H12AffineEnvironment.transform 21 201967 env34232 = env34233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env34232 == env34233) = true)

def env34234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130175,1024,32769,4160,73771,120014,98780,8328,65,97666,5392,102879,56436,119042,119927,256,98814,90203,63189]

theorem envBound34234 : H12AffineFastState.Bounded env34234 := by
  intro p hp
  have h : env34234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34233_34234 : H12AffineEnvironment.transform 16 13508 env34233 = env34234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env34233 == env34234) = true)

theorem identity34234 : scanCanonicalize (H12AffineFastState.compose env34234 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34234 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env34235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4160,73771,119879,98645,8193,65,97547,5392,102742,56436,119042,119927,256,98679,90203,63068]

theorem envBound34235 : H12AffineFastState.Bounded env34235 := by
  intro p hp
  have h : env34235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34234_34235 : H12AffineEnvironment.transform 6 9 env34234 = env34235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34234 == env34235) = true)

theorem identity34235 : scanCanonicalize (H12AffineFastState.compose env34235 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound34235 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,10281,1024,32769,4160,62589,17,21763,8193,65,43357,5392,17664,56436,1364,33,256,21793,46093,63068]

theorem envBound34236 : H12AffineFastState.Bounded env34236 := by
  intro p hp
  have h : env34236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34235_34236 : H12AffineEnvironment.transform 15 54358 env34235 = env34236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env34235 == env34236) = true)

theorem identity34236 : scanCanonicalize (H12AffineFastState.compose env34236 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound34236 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,13389,10281,1024,29788,4160,32,17,21763,8193,65,23808,5392,17664,10281,1364,33,256,21793,16464,513]

theorem envBound34237 : H12AffineFastState.Bounded env34237 := by
  intro p hp
  have h : env34237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34236_34237 : H12AffineEnvironment.transform 14 29789 env34236 = env34237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env34236 == env34237) = true)

theorem identity34237 : scanCanonicalize (H12AffineFastState.compose env34237 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound34237 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,8203,13389,10281,1024,81,4160,32,17,8462,8193,65,10509,5392,12557,10281,1364,33,256,8492,13405,513]

theorem envBound34238 : H12AffineFastState.Bounded env34238 := by
  intro p hp
  have h : env34238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34237_34238 : H12AffineEnvironment.transform 13 13325 env34237 = env34238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env34237 == env34238) = true)

theorem identity34238 : scanCanonicalize (H12AffineFastState.compose env34238 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34238 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34239 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,8203,13340,10281,1024,0,4113,32,17,8462,8193,16,10509,5392,12557,10281,1285,33,256,8492,13324,513]

theorem envBound34239 : H12AffineFastState.Bounded env34239 := by
  intro p hp
  have h : env34239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34238_34239 : H12AffineEnvironment.transform 5 17 env34238 = env34239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34238 == env34239) = true)

theorem identity34239 : scanCanonicalize (H12AffineFastState.compose env34239 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound34239 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34240 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1312,8192,8493,1,8203,8508,10281,1024,0,1329,32,17,8462,8193,16,10509,48,9261,10281,1285,33,256,8492,8492,513]

theorem envBound34240 : H12AffineFastState.Bounded env34240 := by
  intro p hp
  have h : env34240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34239_34240 : H12AffineEnvironment.transform 11 1312 env34239 = env34240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env34239 == env34240) = true)

theorem identity34240 : scanCanonicalize (H12AffineFastState.compose env34240 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34241 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1312,269,32,1,262,49,2340,1024,0,1329,32,17,3,268,16,2048,48,1312,2340,1285,33,256,33,33,513]

theorem envBound34241 : H12AffineFastState.Bounded env34241 := by
  intro p hp
  have h : env34241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34240_34241 : H12AffineEnvironment.transform 12 269 env34240 = env34241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34240 == env34241) = true)

theorem identity34241 : scanCanonicalize (H12AffineFastState.compose env34241 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound34241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34242 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,17,269,32,1,262,49,2340,305,0,0,32,17,3,268,16,2048,48,17,2340,52,33,256,33,33,513]

theorem envBound34242 : H12AffineFastState.Bounded env34242 := by
  intro p hp
  have h : env34242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34241_34242 : H12AffineEnvironment.transform 9 305 env34241 = env34242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env34241 == env34242) = true)

theorem identity34242 : scanCanonicalize (H12AffineFastState.compose env34242 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound34242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34243 : List Nat := [2,4,8,16,32,17,9,256,512,305,554,17,269,32,1,262,49,782,305,0,0,32,17,3,268,16,554,48,17,782,52,33,256,33,33,513]

theorem envBound34243 : H12AffineFastState.Bounded env34243 := by
  intro p hp
  have h : env34243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34242_34243 : H12AffineEnvironment.transform 10 554 env34242 = env34243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env34242 == env34243) = true)

theorem identity34243 : scanCanonicalize (H12AffineFastState.compose env34243 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34243 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34244 : List Nat := [2,4,8,16,32,17,9,256,42,305,0,17,269,32,1,262,49,292,305,0,0,32,17,3,268,16,0,48,17,292,52,33,256,33,33,43]

theorem envBound34244 : H12AffineFastState.Bounded env34244 := by
  intro p hp
  have h : env34244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34243_34244 : H12AffineEnvironment.transform 8 42 env34243 = env34244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34243 == env34244) = true)

theorem identity34244 : scanCanonicalize (H12AffineFastState.compose env34244 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34244 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34245 : List Nat := [2,4,8,16,32,17,9,36,42,21,0,17,41,32,1,34,49,0,21,0,0,32,17,3,40,16,0,48,17,0,52,33,36,33,33,43]

theorem envBound34245 : H12AffineFastState.Bounded env34245 := by
  intro p hp
  have h : env34245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34244_34245 : H12AffineEnvironment.transform 7 36 env34244 = env34245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34244 == env34245) = true)

theorem identity34245 : scanCanonicalize (H12AffineFastState.compose env34245 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound34245 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34246 : List Nat := [2,4,8,15,32,14,9,36,42,10,0,14,41,32,1,34,46,0,10,0,0,32,14,3,40,15,0,47,14,0,43,33,36,33,33,43]

theorem envBound34246 : H12AffineFastState.Bounded env34246 := by
  intro p hp
  have h : env34246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34245_34246 : H12AffineEnvironment.transform 3 15 env34245 = env34246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env34245 == env34246) = true)

theorem identity34246 : scanCanonicalize (H12AffineFastState.compose env34246 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34247 : List Nat := [0,4,8,13,32,12,9,36,40,8,0,12,41,32,1,32,44,0,8,0,0,32,12,1,40,13,0,45,12,0,41,33,36,33,33,41]

theorem envBound34247 : H12AffineFastState.Bounded env34247 := by
  intro p hp
  have h : env34247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34246_34247 : H12AffineEnvironment.transform 0 0 env34246 = env34247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34246 == env34247) = true)

def env34248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130174,1024,32769,4160,73770,120014,98780,8328,65,97667,5392,102879,56436,119042,119926,256,98814,90203,63189]

theorem envBound34248 : H12AffineFastState.Bounded env34248 := by
  intro p hp
  have h : env34248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34233_34248 : H12AffineEnvironment.transform 16 13509 env34233 = env34248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env34233 == env34248) = true)

theorem identity34248 : scanCanonicalize (H12AffineFastState.compose env34248 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34248 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env34249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,13509,100386,1024,32769,4160,73770,106642,98780,8328,65,68063,5392,102879,43048,107870,106538,256,98814,70663,33417]

theorem envBound34249 : H12AffineFastState.Bounded env34249 := by
  intro p hp
  have h : env34249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34248_34249 : H12AffineEnvironment.transform 13 13404 env34248 = env34249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34248 == env34249) = true)

theorem identity34249 : scanCanonicalize (H12AffineFastState.compose env34249 (packedSelected [4,5,7,8,9,10,14,15,17,18,19,23,24,27,28,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound34249 : packedSelected [4,5,7,8,9,10,14,15,17,18,19,23,24,27,28,35,38] rootPS < 2^1333 := by decide +kernel

def env34250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,262,13509,35108,1024,32769,4160,8492,41364,32986,8328,65,2265,5392,37081,43048,42072,41260,256,33016,5377,33417]

theorem envBound34250 : H12AffineFastState.Bounded env34250 := by
  intro p hp
  have h : env34250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34249_34250 : H12AffineEnvironment.transform 15 262 env34249 = env34250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env34249 == env34250) = true)

theorem identity34250 : scanCanonicalize (H12AffineFastState.compose env34250 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34250 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env34251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,32768,262,5577,35108,1024,32769,4160,32,32920,32986,388,65,2265,5392,37081,35108,34132,32800,256,33016,5377,33417]

theorem envBound34251 : H12AffineFastState.Bounded env34251 := by
  intro p hp
  have h : env34251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34250_34251 : H12AffineEnvironment.transform 12 268 env34250 = env34251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34250 == env34251) = true)

theorem identity34251 : scanCanonicalize (H12AffineFastState.compose env34251 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound34251 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env34252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,137,262,5577,2477,1024,136,4160,32,17,83,388,65,2265,5392,4176,2477,1501,169,256,113,5377,512]

theorem envBound34252 : H12AffineFastState.Bounded env34252 := by
  intro p hp
  have h : env34252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34251_34252 : H12AffineEnvironment.transform 14 137 env34251 = env34252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env34251 == env34252) = true)

theorem identity34252 : scanCanonicalize (H12AffineFastState.compose env34252 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34252 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34253 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,268,5456,137,262,5577,2445,1024,136,4160,0,17,83,388,65,2265,5392,4176,2445,1501,137,256,81,5377,512]

theorem envBound34253 : H12AffineFastState.Bounded env34253 := by
  intro p hp
  have h : env34253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34252_34253 : H12AffineEnvironment.transform 4 0 env34252 = env34253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34252 == env34253) = true)

theorem identity34253 : scanCanonicalize (H12AffineFastState.compose env34253 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound34253 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34254 : List Nat := [2,4,8,16,0,64,128,85,512,1024,2048,4096,89,5125,137,83,5276,2264,1024,136,4160,0,17,83,209,65,2265,5189,4176,2264,1160,137,85,81,5204,512]

theorem envBound34254 : H12AffineFastState.Bounded env34254 := by
  intro p hp
  have h : env34254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34253_34254 : H12AffineEnvironment.transform 7 85 env34253 = env34254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env34253 == env34254) = true)

theorem identity34254 : scanCanonicalize (H12AffineFastState.compose env34254 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound34254 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env34255 : List Nat := [2,4,8,16,0,64,128,85,512,20,2048,4096,89,4113,137,83,4232,2264,20,136,4160,0,17,83,209,65,2265,4177,4176,2264,156,137,85,81,4160,512]

theorem envBound34255 : H12AffineFastState.Bounded env34255 := by
  intro p hp
  have h : env34255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34254_34255 : H12AffineEnvironment.transform 9 20 env34254 = env34255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34254 == env34255) = true)

theorem identity34255 : scanCanonicalize (H12AffineFastState.compose env34255 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound34255 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env34256 : List Nat := [2,4,8,16,0,64,128,85,512,20,2048,2113,89,2128,137,83,2249,2264,20,136,2049,0,17,83,209,65,2265,2064,2065,2264,156,137,85,81,2049,512]

theorem envBound34256 : H12AffineFastState.Bounded env34256 := by
  intro p hp
  have h : env34256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34255_34256 : H12AffineEnvironment.transform 11 2113 env34255 = env34256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env34255 == env34256) = true)

theorem identity34256 : scanCanonicalize (H12AffineFastState.compose env34256 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34256 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env34257 : List Nat := [2,4,8,16,0,64,89,85,512,20,2048,2113,89,2128,80,83,2064,2049,20,81,2049,0,17,83,8,65,2048,2064,2065,2049,69,80,85,81,2049,512]

theorem envBound34257 : H12AffineFastState.Bounded env34257 := by
  intro p hp
  have h : env34257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34256_34257 : H12AffineEnvironment.transform 6 89 env34256 = env34257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34256 == env34257) = true)

end H12CloudChart0