import H12CloudChart0Data122

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound31204 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env31205 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5457,1,342,5392,2341,1024,0,4161,112,64,2,348,65,2049,5441,4096,2340,1285,33,256,112,5456,592]

theorem envBound31205 : H12AffineFastState.Bounded env31205 := by
  intro p hp
  have h : env31205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31204_31205 : H12AffineEnvironment.transform 13 5457 env31204 = env31205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31204 == env31205) = true)

theorem identity31205 : scanCanonicalize (H12AffineFastState.compose env31205 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31205 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31206 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4113,32,16,2,268,17,2049,5393,4096,2340,1285,33,256,32,5376,512]

theorem envBound31206 : H12AffineFastState.Bounded env31206 := by
  intro p hp
  have h : env31206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31205_31206 : H12AffineEnvironment.transform 5 16 env31205 = env31206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31205 == env31206) = true)

theorem identity31206 : scanCanonicalize (H12AffineFastState.compose env31206 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31206 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31207 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,268,5377,1,262,5392,2308,1024,0,4113,1,16,2,268,17,2049,5393,4096,2309,1285,0,256,1,5376,512]

theorem envBound31207 : H12AffineFastState.Bounded env31207 := by
  intro p hp
  have h : env31207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31206_31207 : H12AffineEnvironment.transform 4 1 env31206 = env31207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31206 == env31207) = true)

theorem identity31207 : scanCanonicalize (H12AffineFastState.compose env31207 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound31207 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31208 : List Nat := [2,4,8,16,1,16,8,256,512,1024,522,4096,268,5377,1,262,5392,782,1024,0,4113,1,16,2,268,17,523,5393,4096,783,1285,0,256,1,5376,512]

theorem envBound31208 : H12AffineFastState.Bounded env31208 := by
  intro p hp
  have h : env31208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31207_31208 : H12AffineEnvironment.transform 10 522 env31207 = env31208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env31207 == env31208) = true)

def env31209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493492,499128,8328,65,2396605,2496821,416100,2149429,2102684,2373704,256,21793,46213,2175563]

theorem envBound31209 : H12AffineFastState.Bounded env31209 := by
  intro p hp
  have h : env31209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31156_31209 : H12AffineEnvironment.transform 21 180273 env31156 = env31209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env31156 == env31209) = true)

def env31210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400500,499128,8328,65,295421,395637,416100,56437,1500,272392,256,21793,46213,74251]

theorem envBound31210 : H12AffineFastState.Bounded env31210 := by
  intro p hp
  have h : env31210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31209_31210 : H12AffineEnvironment.transform 20 4160 env31209 = env31210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31209 == env31210) = true)

theorem identity31210 : scanCanonicalize (H12AffineFastState.compose env31210 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound31210 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,144612,400500,485741,8328,65,292136,395637,416100,10400,1500,272392,256,21793,16464,74251]

theorem envBound31211 : H12AffineFastState.Bounded env31211 := by
  intro p hp
  have h : env31211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31210_31211 : H12AffineEnvironment.transform 14 29909 env31210 = env31211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env31210 == env31211) = true)

def env31212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144492,400500,485741,8192,65,292136,395637,416100,10280,1364,272392,256,21793,16464,74251]

theorem envBound31212 : H12AffineFastState.Bounded env31212 := by
  intro p hp
  have h : env31212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31211_31212 : H12AffineEnvironment.transform 6 8 env31211 = env31212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31211 == env31212) = true)

theorem identity31212 : scanCanonicalize (H12AffineFastState.compose env31212 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound31212 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,215091,1024,29788,4160,144492,87111,8542,8192,65,212251,82246,69975,10280,1364,221243,256,21793,16464,74251]

theorem envBound31213 : H12AffineFastState.Bounded env31213 := by
  intro p hp
  have h : env31213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31212_31213 : H12AffineEnvironment.transform 17 215091 env31212 = env31213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env31212 == env31213) = true)

theorem identity31213 : scanCanonicalize (H12AffineFastState.compose env31213 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound31213 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1024,29788,4160,87159,87111,8542,8192,65,23808,82246,69975,10280,1364,32,256,21793,16464,74251]

theorem envBound31214 : H12AffineFastState.Bounded env31214 := by
  intro p hp
  have h : env31214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31213_31214 : H12AffineEnvironment.transform 16 90139 env31213 = env31214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env31213 == env31214) = true)

theorem identity31214 : scanCanonicalize (H12AffineFastState.compose env31214 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound31214 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5393,10280,1024,29788,4160,8573,8525,8542,8192,65,23808,13388,25693,10280,1364,32,256,21793,16464,22273]

theorem envBound31215 : H12AffineFastState.Bounded env31215 := by
  intro p hp
  have h : env31215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31214_31215 : H12AffineEnvironment.transform 15 29962 env31214 = env31215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env31214 == env31215) = true)

theorem identity31215 : scanCanonicalize (H12AffineFastState.compose env31215 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound31215 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,9292,9499,5393,10280,1024,9293,4160,8573,8525,8542,8192,65,3345,13388,13388,10280,1364,32,256,1328,4161,1808]

theorem envBound31216 : H12AffineFastState.Bounded env31216 := by
  intro p hp
  have h : env31216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31215_31216 : H12AffineEnvironment.transform 13 4113 env31215 = env31216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env31215 == env31216) = true)

theorem identity31216 : scanCanonicalize (H12AffineFastState.compose env31216 (packedSelected [0,1,3,5,7,8,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound31216 : packedSelected [0,1,3,5,7,8,11,15,16] rootPS < 2^1333 := by decide +kernel

def env31217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4113,80,263,5393,3124,1024,81,4160,1377,1361,1346,1052,65,3345,4176,4176,3124,1364,32,256,1328,4161,1808]

theorem envBound31217 : H12AffineFastState.Bounded env31217 := by
  intro p hp
  have h : env31217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31216_31217 : H12AffineEnvironment.transform 12 1052 env31216 = env31217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env31216 == env31217) = true)

def env31218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144493,400500,485741,8193,65,292136,395637,416100,10281,1365,272392,256,21793,16464,74251]

theorem envBound31218 : H12AffineFastState.Bounded env31218 := by
  intro p hp
  have h : env31218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31211_31218 : H12AffineEnvironment.transform 6 9 env31211 = env31218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31211 == env31218) = true)

theorem identity31218 : scanCanonicalize (H12AffineFastState.compose env31218 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound31218 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,5440,262144,1024,29789,4160,8493,264500,359469,8193,65,292136,269365,281636,10281,1365,272392,256,21793,16464,74251]

theorem envBound31219 : H12AffineFastState.Bounded env31219 := by
  intro p hp
  have h : env31219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31218_31219 : H12AffineEnvironment.transform 16 5440 env31218 = env31219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env31218 == env31219) = true)

theorem identity31219 : scanCanonicalize (H12AffineFastState.compose env31219 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound31219 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,5440,262144,1024,29789,4160,8493,264500,272507,8193,65,292136,269365,281636,10281,1365,272392,256,21793,16464,30301]

theorem envBound31220 : H12AffineFastState.Bounded env31220 := by
  intro p hp
  have h : env31220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31219_31220 : H12AffineEnvironment.transform 15 21590 env31219 = env31220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env31219 == env31220) = true)

theorem identity31220 : scanCanonicalize (H12AffineFastState.compose env31220 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound31220 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env31221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,5440,10360,1024,29789,4160,8493,8524,3,8193,65,23888,13389,25692,10281,1365,112,256,21793,16464,30301]

theorem envBound31221 : H12AffineFastState.Bounded env31221 := by
  intro p hp
  have h : env31221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31220_31221 : H12AffineEnvironment.transform 17 10360 env31220 = env31221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env31220 == env31221) = true)

theorem identity31221 : scanCanonicalize (H12AffineFastState.compose env31221 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound31221 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8282,5440,10360,1024,81,4160,8493,8524,3,8193,65,10588,13389,4176,10281,1365,112,256,8493,13404,593]

theorem envBound31222 : H12AffineFastState.Bounded env31222 := by
  intro p hp
  have h : env31222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31221_31222 : H12AffineEnvironment.transform 13 13324 env31221 = env31222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env31221 == env31222) = true)

theorem identity31222 : scanCanonicalize (H12AffineFastState.compose env31222 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound31222 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env31223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6429,3345,80,6471,5440,4453,1024,81,4160,6192,6225,3,6428,65,4161,3408,4176,4404,1365,112,256,6192,3393,593]

theorem envBound31223 : H12AffineFastState.Bounded env31223 := by
  intro p hp
  have h : env31223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31222_31223 : H12AffineEnvironment.transform 12 6429 env31222 = env31223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env31222 == env31223) = true)

theorem identity31223 : scanCanonicalize (H12AffineFastState.compose env31223 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound31223 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,5133,1,80,5207,5440,4453,1024,81,4160,5408,5441,3,5132,65,4161,64,4176,4404,1365,112,256,5408,81,593]

theorem envBound31224 : H12AffineFastState.Bounded env31224 := by
  intro p hp
  have h : env31224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31223_31224 : H12AffineEnvironment.transform 10 1296 env31223 = env31224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env31223 == env31224) = true)

theorem identity31224 : scanCanonicalize (H12AffineFastState.compose env31224 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31224 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env31225 : List Nat := [2,4,8,16,32,64,9,256,512,273,1,4096,4380,1,80,4422,4177,4453,273,81,4160,4145,4176,3,4381,65,4161,64,4176,4404,68,112,256,4145,81,593]

theorem envBound31225 : H12AffineFastState.Bounded env31225 := by
  intro p hp
  have h : env31225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31224_31225 : H12AffineEnvironment.transform 9 273 env31224 = env31225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31224 == env31225) = true)

def env31226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400501,499128,8328,65,295420,395636,416100,56436,1501,272393,256,21793,46213,74250]

theorem envBound31226 : H12AffineFastState.Bounded env31226 := by
  intro p hp
  have h : env31226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31209_31226 : H12AffineEnvironment.transform 20 4161 env31209 = env31226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31209 == env31226) = true)

theorem identity31226 : scanCanonicalize (H12AffineFastState.compose env31226 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound31226 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180273,16,98781,8328,65,171417,5393,17665,56436,1501,144492,256,21793,46213,74250]

theorem envBound31227 : H12AffineFastState.Bounded env31227 := by
  intro p hp
  have h : env31227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31226_31227 : H12AffineEnvironment.transform 17 138341 env31226 = env31227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env31226 == env31227) = true)

def env31228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180273,16,98645,8192,65,171281,5393,17665,56436,1365,144492,256,21793,46093,74250]

theorem envBound31228 : H12AffineFastState.Bounded env31228 := by
  intro p hp
  have h : env31228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31227_31228 : H12AffineEnvironment.transform 6 8 env31227 = env31228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31227 == env31228) = true)

theorem identity31228 : scanCanonicalize (H12AffineFastState.compose env31228 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound31228 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,108926,1024,32769,4161,95530,16,98645,8192,65,75786,5393,17665,56436,1365,98679,256,21793,46093,74250]

theorem envBound31229 : H12AffineFastState.Bounded env31229 := by
  intro p hp
  have h : env31229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31228_31229 : H12AffineEnvironment.transform 16 111899 env31228 = env31229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env31228 == env31229) = true)

theorem identity31229 : scanCanonicalize (H12AffineFastState.compose env31229 (packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound31229 : packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env31230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90139,97406,1024,21761,4161,95530,16,87125,8192,65,75786,5393,17665,2420,1365,87159,256,21793,24845,74250]

theorem envBound31230 : H12AffineFastState.Bounded env31230 := by
  intro p hp
  have h : env31230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31229_31230 : H12AffineEnvironment.transform 14 21760 env31229 = env31230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env31229 == env31230) = true)

theorem identity31230 : scanCanonicalize (H12AffineFastState.compose env31230 (packedSelected [0,4,7,11,16,20,22,32] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound31230 : packedSelected [0,4,7,11,16,20,22,32] rootPS < 2^1333 := by decide +kernel

def env31231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,30042,5441,2340,1024,21761,4161,112,16,8463,8192,65,23888,5393,17665,2420,1365,8493,256,21793,24845,22352]

theorem envBound31231 : H12AffineFastState.Bounded env31231 := by
  intro p hp
  have h : env31231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31230_31231 : H12AffineEnvironment.transform 15 30042 env31230 = env31231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env31230 == env31231) = true)

theorem identity31231 : scanCanonicalize (H12AffineFastState.compose env31231 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31231 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21760,21794,5441,2340,1024,21761,4161,112,16,375,120,65,23888,5393,17665,2420,1365,341,256,21793,16757,22352]

theorem envBound31232 : H12AffineFastState.Bounded env31232 := by
  intro p hp
  have h : env31232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31231_31232 : H12AffineEnvironment.transform 12 120 env31231 = env31232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31231 == env31232) = true)

theorem identity31232 : scanCanonicalize (H12AffineFastState.compose env31232 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound31232 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env31233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5236,372,342,5441,2340,1024,373,4161,112,16,375,120,65,2340,5393,4469,2420,1365,341,256,341,5377,804]

theorem envBound31233 : H12AffineFastState.Bounded env31233 := by
  intro p hp
  have h : env31233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31232_31233 : H12AffineEnvironment.transform 13 5236 env31232 = env31233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env31232 == env31233) = true)

theorem identity31233 : scanCanonicalize (H12AffineFastState.compose env31233 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound31233 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env31234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,120,5236,372,342,5441,1345,1024,373,4161,112,16,375,120,65,1345,5393,4469,1297,1365,341,256,341,5377,804]

theorem envBound31234 : H12AffineFastState.Bounded env31234 := by
  intro p hp
  have h : env31234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31233_31234 : H12AffineEnvironment.transform 10 1125 env31233 = env31234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env31233 == env31234) = true)

theorem identity31234 : scanCanonicalize (H12AffineFastState.compose env31234 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound31234 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env31235 : List Nat := [2,4,8,16,32,64,8,256,512,116,17,4096,120,4096,372,342,4405,309,116,373,4161,112,16,375,120,65,309,4453,4469,357,289,341,256,341,4469,804]

theorem envBound31235 : H12AffineFastState.Bounded env31235 := by
  intro p hp
  have h : env31235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31234_31235 : H12AffineEnvironment.transform 9 116 env31234 = env31235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env31234 == env31235) = true)

theorem identity31235 : scanCanonicalize (H12AffineFastState.compose env31235 (packedSelected [0,1,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound31235 : packedSelected [0,1,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31236 : List Nat := [2,4,8,16,32,64,8,256,308,116,17,4096,120,4096,372,342,4405,309,116,373,4161,112,16,375,120,65,309,4453,4469,357,289,341,256,341,4469,16]

theorem envBound31236 : H12AffineFastState.Bounded env31236 := by
  intro p hp
  have h : env31236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31235_31236 : H12AffineEnvironment.transform 8 308 env31235 = env31236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env31235 == env31236) = true)

theorem identity31236 : scanCanonicalize (H12AffineFastState.compose env31236 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound31236 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env31237 : List Nat := [2,4,8,16,32,64,8,256,308,116,17,65,120,65,372,342,372,309,116,373,0,112,16,375,120,65,309,292,308,357,289,341,256,341,308,16]

theorem envBound31237 : H12AffineFastState.Bounded env31237 := by
  intro p hp
  have h : env31237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31236_31237 : H12AffineEnvironment.transform 11 65 env31236 = env31237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env31236 == env31237) = true)

theorem identity31237 : scanCanonicalize (H12AffineFastState.compose env31237 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound31237 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env31238 : List Nat := [2,4,8,16,32,64,8,85,97,116,17,65,120,65,33,3,33,96,116,32,0,112,16,34,120,65,96,113,97,48,116,0,85,0,97,16]

theorem envBound31238 : H12AffineFastState.Bounded env31238 := by
  intro p hp
  have h : env31238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31237_31238 : H12AffineEnvironment.transform 7 85 env31237 = env31238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env31237 == env31238) = true)

theorem identity31238 : scanCanonicalize (H12AffineFastState.compose env31238 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31238 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31239 : List Nat := [2,4,8,16,32,16,8,5,49,36,17,17,40,17,33,3,33,48,36,32,0,32,16,34,40,17,48,33,49,48,36,0,5,0,49,16]

theorem envBound31239 : H12AffineFastState.Bounded env31239 := by
  intro p hp
  have h : env31239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31238_31239 : H12AffineEnvironment.transform 5 16 env31238 = env31239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31238 == env31239) = true)

theorem identity31239 : scanCanonicalize (H12AffineFastState.compose env31239 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31240 : List Nat := [2,4,8,0,32,0,8,5,33,36,1,1,40,1,33,3,33,32,36,32,0,32,0,34,40,1,32,33,33,32,36,0,5,0,33,0]

theorem envBound31240 : H12AffineFastState.Bounded env31240 := by
  intro p hp
  have h : env31240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31239_31240 : H12AffineEnvironment.transform 3 0 env31239 = env31240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31239 == env31240) = true)

def env31241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180273,16,98644,8193,65,171280,5393,17665,56436,1364,144492,256,21793,46092,74250]

theorem envBound31241 : H12AffineFastState.Bounded env31241 := by
  intro p hp
  have h : env31241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31227_31241 : H12AffineEnvironment.transform 6 9 env31227 = env31241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31227 == env31241) = true)

theorem identity31241 : scanCanonicalize (H12AffineFastState.compose env31241 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound31241 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,67618,1024,32769,4161,119926,16,98644,8193,65,100695,5393,17665,56436,1364,73771,256,21793,46092,74250]

theorem envBound31242 : H12AffineFastState.Bounded env31242 := by
  intro p hp
  have h : env31242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31241_31242 : H12AffineEnvironment.transform 16 70727 env31241 = env31242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env31241 == env31242) = true)

theorem identity31242 : scanCanonicalize (H12AffineFastState.compose env31242 (packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31242 : packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,70727,67618,1024,32769,4161,106538,16,98644,8193,65,100695,5393,12637,43048,1364,73771,256,8573,46092,74250]

theorem envBound31243 : H12AffineFastState.Bounded env31243 := by
  intro p hp
  have h : env31243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31242_31243 : H12AffineEnvironment.transform 13 13404 env31242 = env31243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31242 == env31243) = true)

theorem identity31243 : scanCanonicalize (H12AffineFastState.compose env31243 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31243 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env31244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,70727,67618,1024,32769,4161,98678,16,98644,349,65,100695,5393,4097,35188,1364,65911,256,33,38224,66390]

theorem envBound31244 : H12AffineFastState.Bounded env31244 := by
  intro p hp
  have h : env31244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31243_31244 : H12AffineEnvironment.transform 12 348 env31243 = env31244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31243 == env31244) = true)

theorem identity31244 : scanCanonicalize (H12AffineFastState.compose env31244 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31244 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env31245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,70727,67618,1024,1,4161,65910,16,65876,349,65,67927,5393,4097,2420,1364,65911,256,33,5456,66390]

theorem envBound31245 : H12AffineFastState.Bounded env31245 := by
  intro p hp
  have h : env31245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31244_31245 : H12AffineEnvironment.transform 14 0 env31244 = env31245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31244 == env31245) = true)

theorem identity31245 : scanCanonicalize (H12AffineFastState.compose env31245 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound31245 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,375,5424,2389,1024,1,4161,1,16,35,349,65,2080,5393,4097,2420,1364,0,256,33,5456,545]

theorem envBound31246 : H12AffineFastState.Bounded env31246 := by
  intro p hp
  have h : env31246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31245_31246 : H12AffineEnvironment.transform 15 375 env31245 = env31246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env31245 == env31246) = true)

theorem identity31246 : scanCanonicalize (H12AffineFastState.compose env31246 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound31246 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1093,4096,348,5376,0,375,5424,1296,1024,1,4161,1,16,35,349,65,1125,5393,4097,1329,1364,0,256,33,5456,545]

theorem envBound31247 : H12AffineFastState.Bounded env31247 := by
  intro p hp
  have h : env31247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31246_31247 : H12AffineEnvironment.transform 10 1093 env31246 = env31247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env31246 == env31247) = true)

def env31248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493492,499129,8328,65,6705549,2496820,416100,2149429,2102685,6748280,256,21792,46212,2175562]

theorem envBound31248 : H12AffineFastState.Bounded env31248 := by
  intro p hp
  have h : env31248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31155_31248 : H12AffineEnvironment.transform 23 499129 env31155 = env31248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env31155 == env31248) = true)

def env31249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493492,499129,8328,65,2396605,2496820,416100,2149429,2102685,2373704,256,21792,46212,2175562]

theorem envBound31249 : H12AffineFastState.Bounded env31249 := by
  intro p hp
  have h : env31249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31248_31249 : H12AffineEnvironment.transform 21 180272 env31248 = env31249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env31248 == env31249) = true)

def env31250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400500,499129,8328,65,295421,395636,416100,56437,1501,272392,256,21792,46212,74250]

theorem envBound31250 : H12AffineFastState.Bounded env31250 := by
  intro p hp
  have h : env31250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31249_31250 : H12AffineEnvironment.transform 20 4160 env31249 = env31250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31249 == env31250) = true)

theorem identity31250 : scanCanonicalize (H12AffineFastState.compose env31250 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31250 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,180272,400500,441778,8328,65,295421,395636,416100,56437,1501,272392,256,21792,46212,513]

theorem envBound31251 : H12AffineFastState.Bounded env31251 := by
  intro p hp
  have h : env31251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31250_31251 : H12AffineEnvironment.transform 15 8203 env31250 = env31251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31250 == env31251) = true)

def env31252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4160,32800,285796,327074,8328,65,295421,280932,268660,56437,1501,272392,256,21792,46212,513]

theorem envBound31252 : H12AffineFastState.Bounded env31252 := by
  intro p hp
  have h : env31252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31251_31252 : H12AffineEnvironment.transform 16 16400 env31251 = env31252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31251 == env31252) = true)

def env31253 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4112,32800,285748,327074,8328,17,295341,280884,268580,56357,1421,272392,256,21792,46212,513]

theorem envBound31253 : H12AffineFastState.Bounded env31253 := by
  intro p hp
  have h : env31253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31252_31253 : H12AffineEnvironment.transform 5 16 env31252 = env31253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31252 == env31253) = true)

theorem identity31253 : scanCanonicalize (H12AffineFastState.compose env31253 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound31253 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env31254 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,4112,32800,29844,54530,8328,17,43277,24980,12676,56357,1421,168,256,21792,46212,513]

theorem envBound31254 : H12AffineFastState.Bounded env31254 := by
  intro p hp
  have h : env31254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31253_31254 : H12AffineEnvironment.transform 17 10400 env31253 = env31254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31253 == env31254) = true)

theorem identity31254 : scanCanonicalize (H12AffineFastState.compose env31254 (packedSelected [1,3,4,5,8,9,12,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound31254 : packedSelected [1,3,4,5,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env31255 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8203,16400,10400,1024,29828,4112,29861,29844,8583,8328,17,23944,24980,12676,10400,1421,168,256,21792,16385,513]

theorem envBound31255 : H12AffineFastState.Bounded env31255 := by
  intro p hp
  have h : env31255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31254_31255 : H12AffineEnvironment.transform 14 29829 env31254 = env31255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env31254 == env31255) = true)

theorem identity31255 : scanCanonicalize (H12AffineFastState.compose env31255 (packedSelected [3,7,8,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound31255 : packedSelected [3,7,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env31256 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2576,8192,16384,28309,8203,16400,10400,1024,28308,2560,28341,28292,8583,8328,17,18328,24980,11156,10400,1421,168,256,20272,16385,513]

theorem envBound31256 : H12AffineFastState.Bounded env31256 := by
  intro p hp
  have h : env31256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31255_31256 : H12AffineEnvironment.transform 11 2576 env31255 = env31256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env31255 == env31256) = true)

theorem identity31256 : scanCanonicalize (H12AffineFastState.compose env31256 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 3992) := by decide +kernel

theorem selectedBound31256 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31257 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2576,8192,3992,8461,8203,3976,10400,1024,8460,2560,8493,8476,8583,8328,17,2048,11788,11156,10400,1421,168,256,168,3993,513]

theorem envBound31257 : H12AffineFastState.Bounded env31257 := by
  intro p hp
  have h : env31257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31256_31257 : H12AffineEnvironment.transform 13 3992 env31256 = env31257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3992 env31256 == env31257) = true)

theorem identity31257 : scanCanonicalize (H12AffineFastState.compose env31257 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31257 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31258 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2576,268,3992,1,263,3976,2476,1024,0,2560,33,16,139,388,17,2048,3840,2712,2476,1421,168,256,168,3993,513]

theorem envBound31258 : H12AffineFastState.Bounded env31258 := by
  intro p hp
  have h : env31258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31257_31258 : H12AffineEnvironment.transform 12 268 env31257 = env31258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31257 == env31258) = true)

theorem identity31258 : scanCanonicalize (H12AffineFastState.compose env31258 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound31258 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31259 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1076,1572,268,940,1,263,956,1432,1024,0,1588,33,16,139,388,17,1076,820,1708,1432,1421,168,256,168,941,513]

theorem envBound31259 : H12AffineFastState.Bounded env31259 := by
  intro p hp
  have h : env31259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31258_31259 : H12AffineEnvironment.transform 10 1076 env31258 = env31259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env31258 == env31259) = true)

theorem identity31259 : scanCanonicalize (H12AffineFastState.compose env31259 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound31259 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31260 : List Nat := [2,4,8,16,32,16,128,256,512,768,820,292,268,940,1,263,956,664,768,0,308,33,16,139,388,17,820,820,428,664,653,168,256,168,941,513]

theorem envBound31260 : H12AffineFastState.Bounded env31260 := by
  intro p hp
  have h : env31260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31259_31260 : H12AffineEnvironment.transform 9 768 env31259 = env31260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env31259 == env31260) = true)

theorem identity31260 : scanCanonicalize (H12AffineFastState.compose env31260 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31260 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31261 : List Nat := [2,4,8,16,32,16,128,37,512,549,529,1,41,649,1,34,665,664,549,0,17,33,16,139,161,17,529,529,137,664,653,168,37,168,648,513]

theorem envBound31261 : H12AffineFastState.Bounded env31261 := by
  intro p hp
  have h : env31261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31260_31261 : H12AffineEnvironment.transform 7 37 env31260 = env31261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31260 == env31261) = true)

theorem identity31261 : scanCanonicalize (H12AffineFastState.compose env31261 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound31261 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31262 : List Nat := [2,4,8,16,32,16,128,37,32,5,49,1,41,169,1,34,185,184,5,0,17,33,16,139,161,17,49,49,137,184,173,168,37,168,168,33]

theorem envBound31262 : H12AffineFastState.Bounded env31262 := by
  intro p hp
  have h : env31262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31261_31262 : H12AffineEnvironment.transform 8 32 env31261 = env31262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env31261 == env31262) = true)

theorem identity31262 : scanCanonicalize (H12AffineFastState.compose env31262 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31262 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env31263 : List Nat := [2,4,8,16,1,16,128,4,1,5,16,1,8,136,1,3,152,153,5,0,17,0,16,139,128,17,16,16,137,153,140,137,4,137,137,0]

theorem envBound31263 : H12AffineFastState.Bounded env31263 := by
  intro p hp
  have h : env31263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31262_31263 : H12AffineEnvironment.transform 4 1 env31262 = env31263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31262 == env31263) = true)

theorem identity31263 : scanCanonicalize (H12AffineFastState.compose env31263 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound31263 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31264 : List Nat := [2,4,8,16,1,16,24,4,1,5,16,1,8,16,1,3,0,1,5,0,17,0,16,19,24,17,16,16,17,1,20,17,4,17,17,0]

theorem envBound31264 : H12AffineFastState.Bounded env31264 := by
  intro p hp
  have h : env31264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31263_31264 : H12AffineEnvironment.transform 6 24 env31263 = env31264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env31263 == env31264) = true)

theorem identity31264 : scanCanonicalize (H12AffineFastState.compose env31264 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31265 : List Nat := [2,4,3,16,1,16,19,4,1,5,16,1,3,16,1,3,0,1,5,0,17,0,16,19,19,17,16,16,17,1,20,17,4,17,17,0]

theorem envBound31265 : H12AffineFastState.Bounded env31265 := by
  intro p hp
  have h : env31265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31264_31265 : H12AffineEnvironment.transform 2 3 env31264 = env31265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31264 == env31265) = true)

theorem identity31265 : scanCanonicalize (H12AffineFastState.compose env31265 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31265 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env31266 : List Nat := [2,4,3,1,1,1,2,4,1,5,1,1,3,1,1,3,0,1,5,0,0,0,1,2,2,0,1,1,0,1,5,0,4,0,0,0]

theorem envBound31266 : H12AffineFastState.Bounded env31266 := by
  intro p hp
  have h : env31266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31265_31266 : H12AffineEnvironment.transform 3 1 env31265 = env31266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31265 == env31266) = true)

def env31267 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4113,32800,285749,327074,8328,16,295340,280885,268581,56356,1420,272392,256,21792,46212,513]

theorem envBound31267 : H12AffineFastState.Bounded env31267 := by
  intro p hp
  have h : env31267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31252_31267 : H12AffineEnvironment.transform 5 17 env31252 = env31267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31252 == env31267) = true)

theorem identity31267 : scanCanonicalize (H12AffineFastState.compose env31267 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound31267 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env31268 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8203,16400,262144,1024,8580,4113,8613,285749,285735,8328,16,270377,280885,268581,32161,1420,272392,256,21792,5377,513]

theorem envBound31268 : H12AffineFastState.Bounded env31268 := by
  intro p hp
  have h : env31268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31267_31268 : H12AffineEnvironment.transform 14 8581 env31267 = env31268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env31267 == env31268) = true)

theorem identity31268 : scanCanonicalize (H12AffineFastState.compose env31268 (packedSelected [1,4,5,8,9,14,17,20,24] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound31268 : packedSelected [1,4,5,8,9,14,17,20,24] rootPS < 2^1333 := by decide +kernel

def env31269 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8203,16400,10280,1024,8580,4113,8613,29725,29711,8328,16,2049,24861,12557,32161,1420,32,256,21792,5377,513]

theorem envBound31269 : H12AffineFastState.Bounded env31269 := by
  intro p hp
  have h : env31269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31268_31269 : H12AffineEnvironment.transform 17 10280 env31268 = env31269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env31268 == env31269) = true)

theorem identity31269 : scanCanonicalize (H12AffineFastState.compose env31269 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound31269 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env31270 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13608,8581,8203,13624,10280,1024,8580,4113,8613,309,295,8328,16,2049,5173,12557,2185,1420,32,256,8200,5377,513]

theorem envBound31270 : H12AffineFastState.Bounded env31270 := by
  intro p hp
  have h : env31270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31269_31270 : H12AffineEnvironment.transform 13 13608 env31269 = env31270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env31269 == env31270) = true)

theorem identity31270 : scanCanonicalize (H12AffineFastState.compose env31270 (packedSelected [2,6,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound31270 : packedSelected [2,6,12,15,17] rootPS < 2^1333 := by decide +kernel

def env31271 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1337,4113,1212,1330,4097,3345,1024,1213,4113,1180,309,295,1457,16,2049,5173,5172,2185,1420,32,256,1329,5377,513]

theorem envBound31271 : H12AffineFastState.Bounded env31271 := by
  intro p hp
  have h : env31271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31270_31271 : H12AffineEnvironment.transform 12 1337 env31270 = env31271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env31270 == env31271) = true)

theorem identity31271 : scanCanonicalize (H12AffineFastState.compose env31271 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31271 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31272 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,1053,4113,1212,1046,4097,3125,1024,1213,4113,1180,17,3,1173,16,2049,5173,5172,2185,1192,32,36,1045,5157,513]

theorem envBound31272 : H12AffineFastState.Bounded env31272 := by
  intro p hp
  have h : env31272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31271_31272 : H12AffineEnvironment.transform 7 36 env31271 = env31272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31271 == env31272) = true)

theorem identity31272 : scanCanonicalize (H12AffineFastState.compose env31272 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1724) := by decide +kernel

theorem selectedBound31272 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31273 : List Nat := [2,4,8,16,32,17,128,36,512,1024,1724,4096,1053,4113,1212,1046,4097,649,1024,1213,4113,1180,17,3,1173,16,1725,5173,5172,1589,1192,32,36,1045,5157,513]

theorem envBound31273 : H12AffineFastState.Bounded env31273 := by
  intro p hp
  have h : env31273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31272_31273 : H12AffineEnvironment.transform 10 1724 env31272 = env31273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1724 env31272 == env31273) = true)

theorem identity31273 : scanCanonicalize (H12AffineFastState.compose env31273 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound31273 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31274 : List Nat := [2,4,8,16,32,17,128,36,512,173,529,4096,176,4113,17,187,4097,649,173,16,4113,49,17,3,56,16,528,4248,4249,664,5,32,36,184,4232,513]

theorem envBound31274 : H12AffineFastState.Bounded env31274 := by
  intro p hp
  have h : env31274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31273_31274 : H12AffineEnvironment.transform 9 173 env31273 = env31274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env31273 == env31274) = true)

theorem identity31274 : scanCanonicalize (H12AffineFastState.compose env31274 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31274 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31275 : List Nat := [2,4,8,16,32,17,9,36,512,36,529,4096,57,4113,17,50,4097,512,36,16,4113,49,17,3,56,16,528,4113,4112,529,5,32,36,49,4097,513]

theorem envBound31275 : H12AffineFastState.Bounded env31275 := by
  intro p hp
  have h : env31275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31274_31275 : H12AffineEnvironment.transform 6 9 env31274 = env31275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31274 == env31275) = true)

theorem identity31275 : scanCanonicalize (H12AffineFastState.compose env31275 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31275 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env31276 : List Nat := [2,4,8,0,32,1,9,36,512,36,513,4096,41,4097,1,34,4097,512,36,0,4097,33,1,3,40,0,512,4097,4096,513,5,32,36,33,4097,513]

theorem envBound31276 : H12AffineFastState.Bounded env31276 := by
  intro p hp
  have h : env31276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31275_31276 : H12AffineEnvironment.transform 3 0 env31275 = env31276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31275 == env31276) = true)

theorem identity31276 : scanCanonicalize (H12AffineFastState.compose env31276 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound31276 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31277 : List Nat := [2,4,8,0,32,1,9,36,512,36,513,33,41,32,1,34,32,512,36,0,32,33,1,3,40,0,512,32,33,513,5,32,36,33,32,513]

theorem envBound31277 : H12AffineFastState.Bounded env31277 := by
  intro p hp
  have h : env31277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31276_31277 : H12AffineEnvironment.transform 11 33 env31276 = env31277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env31276 == env31277) = true)

theorem identity31277 : scanCanonicalize (H12AffineFastState.compose env31277 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31277 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31278 : List Nat := [2,4,8,0,32,1,9,36,1,36,0,33,41,32,1,34,32,1,36,0,32,33,1,3,40,0,1,32,33,0,5,32,36,33,32,0]

theorem envBound31278 : H12AffineFastState.Bounded env31278 := by
  intro p hp
  have h : env31278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31277_31278 : H12AffineEnvironment.transform 8 1 env31277 = env31278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31277 == env31278) = true)

theorem identity31278 : scanCanonicalize (H12AffineFastState.compose env31278 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31278 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31279 : List Nat := [2,4,8,0,0,1,9,4,1,4,0,1,9,0,1,2,0,1,4,0,0,1,1,3,8,0,1,0,1,0,5,0,4,1,0,0]

theorem envBound31279 : H12AffineFastState.Bounded env31279 := by
  intro p hp
  have h : env31279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31278_31279 : H12AffineEnvironment.transform 4 0 env31278 = env31279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31278 == env31279) = true)

def env31280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4160,32801,285797,327075,8328,65,295421,280933,268661,56437,1501,272392,256,21792,46212,513]

theorem envBound31280 : H12AffineFastState.Bounded env31280 := by
  intro p hp
  have h : env31280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31251_31280 : H12AffineEnvironment.transform 16 16401 env31251 = env31280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31251 == env31280) = true)

theorem identity31280 : scanCanonicalize (H12AffineFastState.compose env31280 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound31280 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,23669,1024,32769,4160,32801,16,41430,8328,65,56712,5392,17664,56437,1501,29821,256,21792,46212,513]

theorem envBound31281 : H12AffineFastState.Bounded env31281 := by
  intro p hp
  have h : env31281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31280_31281 : H12AffineEnvironment.transform 17 23669 env31280 = env31281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env31280 == env31281) = true)

theorem identity31281 : scanCanonicalize (H12AffineFastState.compose env31281 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound31281 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,8203,16401,23669,1024,137,4160,169,16,8542,8328,65,23808,5392,17664,23805,1501,29821,256,21792,13324,513]

theorem envBound31282 : H12AffineFastState.Bounded env31282 := by
  intro p hp
  have h : env31282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31281_31282 : H12AffineEnvironment.transform 14 136 env31281 = env31282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env31281 == env31282) = true)

theorem identity31282 : scanCanonicalize (H12AffineFastState.compose env31282 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound31282 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env31283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,479,16401,23669,1024,137,4160,169,16,138,348,65,23808,5392,17664,23805,1501,21929,256,21792,5592,513]

theorem envBound31283 : H12AffineFastState.Bounded env31283 := by
  intro p hp
  have h : env31283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31282_31283 : H12AffineEnvironment.transform 12 468 env31282 = env31283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env31282 == env31283) = true)

theorem identity31283 : scanCanonicalize (H12AffineFastState.compose env31283 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound31283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,479,5529,2557,1024,137,4160,169,16,138,348,65,2184,5392,4232,2421,1501,33,256,168,5592,513]

theorem envBound31284 : H12AffineFastState.Bounded env31284 := by
  intro p hp
  have h : env31284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31283_31284 : H12AffineEnvironment.transform 13 5512 env31283 = env31284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env31283 == env31284) = true)

theorem identity31284 : scanCanonicalize (H12AffineFastState.compose env31284 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound31284 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1125,468,493,136,479,508,2557,1024,137,1061,169,16,138,348,65,2184,373,1261,2421,1501,33,256,168,445,513]

theorem envBound31285 : H12AffineFastState.Bounded env31285 := by
  intro p hp
  have h : env31285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31284_31285 : H12AffineEnvironment.transform 11 1125 env31284 = env31285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env31284 == env31285) = true)

theorem identity31285 : scanCanonicalize (H12AffineFastState.compose env31285 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound31285 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env31286 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1125,41,16,136,34,1,2048,1024,137,1061,169,16,138,161,65,2184,136,1261,2184,1056,33,253,168,64,513]

theorem envBound31286 : H12AffineFastState.Bounded env31286 := by
  intro p hp
  have h : env31286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31285_31286 : H12AffineEnvironment.transform 7 253 env31285 = env31286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env31285 == env31286) = true)

theorem identity31286 : scanCanonicalize (H12AffineFastState.compose env31286 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31286 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31287 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1125,41,16,0,34,1,2048,1024,1,1061,33,16,2,41,65,2048,0,1125,2048,1056,33,117,32,64,513]

theorem envBound31287 : H12AffineFastState.Bounded env31287 := by
  intro p hp
  have h : env31287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31286_31287 : H12AffineEnvironment.transform 6 8 env31286 = env31287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31286 == env31287) = true)

theorem identity31287 : scanCanonicalize (H12AffineFastState.compose env31287 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound31287 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31288 : List Nat := [2,4,8,16,32,64,8,117,512,1024,10,1125,41,16,0,34,1,10,1024,1,1061,33,16,2,41,65,10,0,1125,10,1056,33,117,32,64,513]

theorem envBound31288 : H12AffineFastState.Bounded env31288 := by
  intro p hp
  have h : env31288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31287_31288 : H12AffineEnvironment.transform 10 10 env31287 = env31288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env31287 == env31288) = true)

theorem identity31288 : scanCanonicalize (H12AffineFastState.compose env31288 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31288 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31289 : List Nat := [2,4,2,16,32,64,2,117,512,1024,0,1125,35,16,0,34,1,0,1024,1,1061,33,16,2,35,65,0,0,1125,0,1056,33,117,32,64,513]

theorem envBound31289 : H12AffineFastState.Bounded env31289 := by
  intro p hp
  have h : env31289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31288_31289 : H12AffineEnvironment.transform 2 2 env31288 = env31289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31288 == env31289) = true)

theorem identity31289 : scanCanonicalize (H12AffineFastState.compose env31289 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31289 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31290 : List Nat := [2,4,2,16,32,49,2,4,512,1024,0,1044,35,16,0,34,1,0,1024,1,1061,33,16,2,35,48,0,0,1044,0,1056,33,4,32,49,513]

theorem envBound31290 : H12AffineFastState.Bounded env31290 := by
  intro p hp
  have h : env31290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31289_31290 : H12AffineEnvironment.transform 5 49 env31289 = env31290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31289 == env31290) = true)

theorem identity31290 : scanCanonicalize (H12AffineFastState.compose env31290 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31290 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env31291 : List Nat := [2,4,2,16,16,1,2,4,512,1024,0,1044,19,16,0,18,1,0,1024,1,1045,17,16,2,19,0,0,0,1044,0,1040,17,4,16,1,513]

theorem envBound31291 : H12AffineFastState.Bounded env31291 := by
  intro p hp
  have h : env31291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31290_31291 : H12AffineEnvironment.transform 4 16 env31290 = env31291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31290 == env31291) = true)

theorem identity31291 : scanCanonicalize (H12AffineFastState.compose env31291 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound31291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31292 : List Nat := [2,1,2,16,16,1,2,1,512,1024,0,1041,19,16,0,18,1,0,1024,1,1040,17,16,2,19,0,0,0,1041,0,1040,17,1,16,1,513]

theorem envBound31292 : H12AffineFastState.Bounded env31292 := by
  intro p hp
  have h : env31292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31291_31292 : H12AffineEnvironment.transform 1 1 env31291 = env31292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env31291 == env31292) = true)

theorem identity31292 : scanCanonicalize (H12AffineFastState.compose env31292 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound31292 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31293 : List Nat := [2,1,2,16,16,1,2,1,512,17,0,0,19,16,0,18,1,0,17,1,1,17,16,2,19,0,0,0,0,0,1,17,1,16,1,513]

theorem envBound31293 : H12AffineFastState.Bounded env31293 := by
  intro p hp
  have h : env31293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31292_31293 : H12AffineEnvironment.transform 9 17 env31292 = env31293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env31292 == env31293) = true)

theorem identity31293 : scanCanonicalize (H12AffineFastState.compose env31293 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound31293 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31294 : List Nat := [2,1,2,16,16,1,2,1,3,17,0,0,19,16,0,18,1,0,17,1,1,17,16,2,19,0,0,0,0,0,1,17,1,16,1,2]

theorem envBound31294 : H12AffineFastState.Bounded env31294 := by
  intro p hp
  have h : env31294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31293_31294 : H12AffineEnvironment.transform 8 3 env31293 = env31294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env31293 == env31294) = true)

def env31295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400501,499129,8328,65,295420,395637,416100,56436,1500,272393,256,21792,46212,74251]

theorem envBound31295 : H12AffineFastState.Bounded env31295 := by
  intro p hp
  have h : env31295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31249_31295 : H12AffineEnvironment.transform 20 4161 env31249 = env31295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31249 == env31295) = true)

theorem identity31295 : scanCanonicalize (H12AffineFastState.compose env31295 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound31295 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,180272,120014,21762,8328,65,215367,115150,102879,56436,1500,254130,256,21792,46212,74251]

theorem envBound31296 : H12AffineFastState.Bounded env31296 := by
  intro p hp
  have h : env31296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31295_31296 : H12AffineEnvironment.transform 17 247995 env31295 = env31296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env31295 == env31296) = true)

def env31297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130175,1024,32769,4161,62708,120014,21762,8328,65,97667,115150,102879,56436,1500,119926,256,21792,46212,74251]

theorem envBound31297 : H12AffineFastState.Bounded env31297 := by
  intro p hp
  have h : env31297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31296_31297 : H12AffineEnvironment.transform 16 13508 env31296 = env31297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env31296 == env31297) = true)

def env31298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130175,1024,32769,4161,62588,119878,21762,8192,65,97547,115014,102743,56436,1364,119926,256,21792,46092,74251]

theorem envBound31298 : H12AffineFastState.Bounded env31298 := by
  intro p hp
  have h : env31298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31297_31298 : H12AffineEnvironment.transform 6 8 env31297 = env31298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31297 == env31298) = true)

theorem identity31298 : scanCanonicalize (H12AffineFastState.compose env31298 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31298 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13388,108927,1024,32769,4161,41340,98630,2,8192,65,75787,103494,102743,35188,1364,98678,256,32,46092,74251]

theorem envBound31299 : H12AffineFastState.Bounded env31299 := by
  intro p hp
  have h : env31299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31298_31299 : H12AffineEnvironment.transform 13 5376 env31298 = env31299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31298 == env31299) = true)

theorem identity31299 : scanCanonicalize (H12AffineFastState.compose env31299 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound31299 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env31300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,41050,13388,2341,1024,32769,4161,41340,8476,2,8192,65,34897,13340,12557,35188,1364,8492,256,32,46092,33361]

theorem envBound31300 : H12AffineFastState.Bounded env31300 := by
  intro p hp
  have h : env31300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31299_31300 : H12AffineEnvironment.transform 15 41050 env31299 = env31300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env31299 == env31300) = true)

theorem identity31300 : scanCanonicalize (H12AffineFastState.compose env31300 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31300 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env31301 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,32768,41050,13388,2129,1024,32769,4161,40968,8296,2,8192,65,34897,13340,12409,34816,1056,8280,116,32,46092,33361]

theorem envBound31301 : H12AffineFastState.Bounded env31301 := by
  intro p hp
  have h : env31301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31300_31301 : H12AffineEnvironment.transform 7 116 env31300 = env31301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31300 == env31301) = true)

theorem identity31301 : scanCanonicalize (H12AffineFastState.compose env31301 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound31301 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31302 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8313,35,13388,2129,1024,8312,4161,113,8296,2,8192,65,10280,13340,12409,10361,1056,8280,116,32,5237,8744]

theorem envBound31302 : H12AffineFastState.Bounded env31302 := by
  intro p hp
  have h : env31302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31301_31302 : H12AffineEnvironment.transform 14 8313 env31301 = env31302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env31301 == env31302) = true)

theorem identity31302 : scanCanonicalize (H12AffineFastState.compose env31302 (packedSelected [2,3,4,5,6,7,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound31302 : packedSelected [2,3,4,5,6,7,10,14] rootPS < 2^1333 := by decide +kernel

def env31303 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,6200,5236,6209,35,3188,2129,1024,6208,4161,113,6224,2,6200,65,4112,3108,2113,4161,1056,6240,116,32,5237,6672]

theorem envBound31303 : H12AffineFastState.Bounded env31303 := by
  intro p hp
  have h : env31303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31302_31303 : H12AffineEnvironment.transform 12 6200 env31302 = env31303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env31302 == env31303) = true)

theorem identity31303 : scanCanonicalize (H12AffineFastState.compose env31303 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31303 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env31304 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,6200,5156,6161,35,3108,2049,1024,6160,4113,33,6144,2,6200,17,4112,3108,2065,4113,1056,6192,36,32,5157,6672]

theorem envBound31304 : H12AffineFastState.Bounded env31304 := by
  intro p hp
  have h : env31304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31303_31304 : H12AffineEnvironment.transform 5 16 env31303 = env31304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31303 == env31304) = true)

theorem identity31304 : scanCanonicalize (H12AffineFastState.compose env31304 (packedSelected [4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound31304 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env31305 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2065,41,3125,0,35,3108,2049,1024,1,2048,33,17,2,41,17,2049,3108,2065,2048,1056,33,36,32,3124,513]

theorem envBound31305 : H12AffineFastState.Bounded env31305 := by
  intro p hp
  have h : env31305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31304_31305 : H12AffineEnvironment.transform 11 2065 env31304 = env31305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env31304 == env31305) = true)

theorem identity31305 : scanCanonicalize (H12AffineFastState.compose env31305 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31305 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31306 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,41,2048,0,35,2065,2049,53,1,2048,33,17,2,41,17,2049,2065,2065,2048,21,33,36,32,2049,513]

theorem envBound31306 : H12AffineFastState.Bounded env31306 := by
  intro p hp
  have h : env31306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31305_31306 : H12AffineEnvironment.transform 9 53 env31305 = env31306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31305 == env31306) = true)

theorem identity31306 : scanCanonicalize (H12AffineFastState.compose env31306 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound31306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31307 : List Nat := [2,4,8,16,32,16,8,36,26,53,2048,2065,41,2048,0,35,2065,2049,53,1,2048,33,17,2,41,17,2049,2065,2065,2048,21,33,36,32,2049,27]

theorem envBound31307 : H12AffineFastState.Bounded env31307 := by
  intro p hp
  have h : env31307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31306_31307 : H12AffineEnvironment.transform 8 26 env31306 = env31307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env31306 == env31307) = true)

def env31308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4161,62589,119879,21762,8193,65,97546,115015,102742,56436,1365,119926,256,21792,46093,74251]

theorem envBound31308 : H12AffineFastState.Bounded env31308 := by
  intro p hp
  have h : env31308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31297_31308 : H12AffineEnvironment.transform 6 9 env31297 = env31308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31297 == env31308) = true)

theorem identity31308 : scanCanonicalize (H12AffineFastState.compose env31308 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound31308 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,67619,1024,29789,4161,33,73755,21762,8193,65,97546,79131,91402,10280,1365,73770,256,21792,16465,74251]

theorem envBound31309 : H12AffineFastState.Bounded env31309 := by
  intro p hp
  have h : env31309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31308_31309 : H12AffineEnvironment.transform 14 29788 env31308 = env31309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env31308 == env31309) = true)

theorem identity31309 : scanCanonicalize (H12AffineFastState.compose env31309 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound31309 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env31310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,13389,32040,1024,29789,4161,33,21776,21762,8193,65,2049,16400,4097,10280,1365,21793,256,21792,16465,22272]

theorem envBound31310 : H12AffineFastState.Bounded env31310 := by
  intro p hp
  have h : env31310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31309_31310 : H12AffineEnvironment.transform 15 29963 env31309 = env31310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env31309 == env31310) = true)

def env31311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130174,1024,32769,4161,62709,120014,21762,8328,65,97666,115150,102879,56436,1500,119927,256,21792,46212,74251]

theorem envBound31311 : H12AffineFastState.Bounded env31311 := by
  intro p hp
  have h : env31311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31296_31311 : H12AffineEnvironment.transform 16 13509 env31296 = env31311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env31296 == env31311) = true)

def env31312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4161,62589,119878,21762,8192,65,97546,115014,102743,56436,1364,119927,256,21792,46092,74251]

theorem envBound31312 : H12AffineFastState.Bounded env31312 := by
  intro p hp
  have h : env31312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31311_31312 : H12AffineEnvironment.transform 6 8 env31311 = env31312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31311 == env31312) = true)

theorem identity31312 : scanCanonicalize (H12AffineFastState.compose env31312 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound31312 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,13389,32041,1024,32769,4161,62589,21777,21762,8192,65,64605,16401,4096,56436,1364,21792,256,21792,46092,41820]

theorem envBound31313 : H12AffineFastState.Bounded env31313 := by
  intro p hp
  have h : env31313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31312_31313 : H12AffineEnvironment.transform 15 33111 env31312 = env31313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env31312 == env31313) = true)

theorem identity31313 : scanCanonicalize (H12AffineFastState.compose env31313 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound31313 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env31314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,33111,13389,2048,1024,32769,4161,33108,8248,8235,8192,65,35188,13624,4096,43357,1364,8201,256,8201,46092,41820]

theorem envBound31314 : H12AffineFastState.Bounded env31314 := by
  intro p hp
  have h : env31314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31313_31314 : H12AffineEnvironment.transform 13 13609 env31313 = env31314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env31313 == env31314) = true)

theorem identity31314 : scanCanonicalize (H12AffineFastState.compose env31314 (packedSelected [0,3,4,5,6,7,9,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound31314 : packedSelected [0,3,4,5,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,2048,2391,13389,2048,1024,2049,4161,2388,8248,8235,8192,65,372,13624,4096,8541,1364,8201,256,8201,15372,11100]

theorem envBound31315 : H12AffineFastState.Bounded env31315 := by
  intro p hp
  have h : env31315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31314_31315 : H12AffineEnvironment.transform 14 2048 env31314 = env31315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env31314 == env31315) = true)

theorem identity31315 : scanCanonicalize (H12AffineFastState.compose env31315 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound31315 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env31316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2088,7425,2048,2391,7269,2048,1024,2049,4161,2388,2064,2051,2088,65,372,7440,4096,2421,1364,2081,256,2081,5156,884]

theorem envBound31316 : H12AffineFastState.Bounded env31316 := by
  intro p hp
  have h : env31316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31315_31316 : H12AffineEnvironment.transform 12 2088 env31315 = env31316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env31315 == env31316) = true)

def env31317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130174,1024,32769,4161,62588,119879,21762,8193,65,97547,115015,102742,56436,1365,119927,256,21792,46093,74251]

theorem envBound31317 : H12AffineFastState.Bounded env31317 := by
  intro p hp
  have h : env31317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31311_31317 : H12AffineEnvironment.transform 6 9 env31311 = env31317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31311 == env31317) = true)

theorem identity31317 : scanCanonicalize (H12AffineFastState.compose env31317 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31317 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31318 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,56436,1024,32769,4161,62588,62541,21762,8193,65,23809,57677,45404,56436,1365,62589,256,21792,46093,513]

theorem envBound31318 : H12AffineFastState.Bounded env31318 := by
  intro p hp
  have h : env31318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31317_31318 : H12AffineEnvironment.transform 15 8202 env31317 = env31318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31317 == env31318) = true)

theorem identity31318 : scanCanonicalize (H12AffineFastState.compose env31318 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound31318 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env31319 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,8202,13388,2341,1024,21840,4161,8493,8476,21762,8193,65,23809,13340,25613,2341,1365,8492,256,21792,24924,513]

theorem envBound31319 : H12AffineFastState.Bounded env31319 := by
  intro p hp
  have h : env31319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31318_31319 : H12AffineEnvironment.transform 14 21841 env31318 = env31319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env31318 == env31319) = true)

theorem identity31319 : scanCanonicalize (H12AffineFastState.compose env31319 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31319 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env31320 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,8202,13340,2341,1024,21760,4113,8493,8476,21762,8193,17,23809,13340,25613,2341,1285,8492,256,21792,24844,513]

theorem envBound31320 : H12AffineFastState.Bounded env31320 := by
  intro p hp
  have h : env31320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31319_31320 : H12AffineEnvironment.transform 5 16 env31319 = env31320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31319 == env31320) = true)

theorem identity31320 : scanCanonicalize (H12AffineFastState.compose env31320 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31320 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31321 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,8202,13340,2341,1024,0,4113,8493,8476,2,8193,17,2049,13340,12557,2341,1285,8492,256,32,13324,513]

theorem envBound31321 : H12AffineFastState.Bounded env31321 := by
  intro p hp
  have h : env31321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31320_31321 : H12AffineEnvironment.transform 13 5376 env31320 = env31321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31320 == env31321) = true)

theorem identity31321 : scanCanonicalize (H12AffineFastState.compose env31321 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31321 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31322 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,4112,1,8202,12556,2341,272,0,4113,8493,8476,2,8193,17,2049,12556,12557,2341,21,8492,256,32,12572,513]

theorem envBound31322 : H12AffineFastState.Bounded env31322 := by
  intro p hp
  have h : env31322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31321_31322 : H12AffineEnvironment.transform 9 272 env31321 = env31322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31321 == env31322) = true)

theorem identity31322 : scanCanonicalize (H12AffineFastState.compose env31322 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31322 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31323 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,4096,8192,4112,1,8202,12556,293,272,0,4113,8493,8476,2,8193,17,1,12556,12557,293,21,8492,256,32,12572,513]

theorem envBound31323 : H12AffineFastState.Bounded env31323 := by
  intro p hp
  have h : env31323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31322_31323 : H12AffineEnvironment.transform 10 0 env31322 = env31323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31322 == env31323) = true)

theorem identity31323 : scanCanonicalize (H12AffineFastState.compose env31323 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31323 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env31324 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,17,8192,1,1,8202,8477,293,272,0,0,8493,8476,2,8193,17,1,8477,8476,293,21,8492,256,32,8461,513]

theorem envBound31324 : H12AffineFastState.Bounded env31324 := by
  intro p hp
  have h : env31324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31323_31324 : H12AffineEnvironment.transform 11 17 env31323 = env31324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31323 == env31324) = true)

theorem identity31324 : scanCanonicalize (H12AffineFastState.compose env31324 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound31324 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env31325 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,17,40,1,1,34,309,293,272,0,0,261,308,2,41,17,1,309,308,293,21,260,256,32,293,513]

theorem envBound31325 : H12AffineFastState.Bounded env31325 := by
  intro p hp
  have h : env31325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31324_31325 : H12AffineEnvironment.transform 12 40 env31324 = env31325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env31324 == env31325) = true)

def env31326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493492,499129,8328,65,2396604,2496820,416100,2149429,2102685,2373705,256,21792,46212,2175562]

theorem envBound31326 : H12AffineFastState.Bounded env31326 := by
  intro p hp
  have h : env31326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31248_31326 : H12AffineEnvironment.transform 21 180273 env31248 = env31326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env31248 == env31326) = true)

def env31327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400500,499129,8328,65,295420,395636,416100,56437,1501,272393,256,21792,46212,74250]

theorem envBound31327 : H12AffineFastState.Bounded env31327 := by
  intro p hp
  have h : env31327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31326_31327 : H12AffineEnvironment.transform 20 4160 env31326 = env31327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31326 == env31327) = true)

theorem identity31327 : scanCanonicalize (H12AffineFastState.compose env31327 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound31327 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4160,180273,73755,41430,8328,65,245139,79131,91403,56437,1501,201830,256,21792,46212,74250]

theorem envBound31328 : H12AffineFastState.Bounded env31328 := by
  intro p hp
  have h : env31328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31327_31328 : H12AffineEnvironment.transform 17 212079 env31327 = env31328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env31327 == env31328) = true)

def env31329 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212031,1024,32769,4112,180273,73755,41350,8328,17,245139,79131,91403,56357,1421,201782,256,21792,46212,74250]

theorem envBound31329 : H12AffineFastState.Bounded env31329 := by
  intro p hp
  have h : env31329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31328_31329 : H12AffineEnvironment.transform 5 16 env31328 = env31329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31328 == env31329) = true)

theorem identity31329 : scanCanonicalize (H12AffineFastState.compose env31329 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound31329 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env31330 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,108966,1024,32769,4112,21928,73755,41350,8328,17,75786,79131,91403,56357,1421,98735,256,21792,46212,74250]

theorem envBound31330 : H12AffineFastState.Bounded env31330 := by
  intro p hp
  have h : env31330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31329_31330 : H12AffineEnvironment.transform 16 38297 env31329 = env31330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env31329 == env31330) = true)

theorem identity31330 : scanCanonicalize (H12AffineFastState.compose env31330 (packedSelected [10,17,18,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound31330 : packedSelected [10,17,18,23,31] rootPS < 2^1333 := by decide +kernel

def env31331 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40971,38297,2477,1024,32769,4112,21928,32784,41350,8328,17,34817,38160,50432,56357,1421,8612,256,21792,46212,33281]

theorem envBound31331 : H12AffineFastState.Bounded env31331 := by
  intro p hp
  have h : env31331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31330_31331 : H12AffineEnvironment.transform 15 40971 env31330 = env31331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env31330 == env31331) = true)

theorem identity31331 : scanCanonicalize (H12AffineFastState.compose env31331 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound31331 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env31332 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,30083,16401,2477,1024,21897,4112,21928,21912,29710,8328,17,23945,16536,4232,2477,1421,8612,256,21792,24844,22409]

theorem envBound31332 : H12AffineFastState.Bounded env31332 := by
  intro p hp
  have h : env31332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31331_31332 : H12AffineEnvironment.transform 14 21896 env31331 = env31332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env31331 == env31332) = true)

theorem identity31332 : scanCanonicalize (H12AffineFastState.compose env31332 (packedSelected [0,2,4,5,6,7,8,9,11,14,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 11690) := by decide +kernel

theorem selectedBound31332 : packedSelected [0,2,4,5,6,7,8,9,11,14,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31333 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,11690,14370,6185,11707,2477,1024,14371,4112,14338,14386,6564,8328,17,12323,11570,4232,2477,1421,8612,256,14474,3238,14883]

theorem envBound31333 : H12AffineFastState.Bounded env31333 := by
  intro p hp
  have h : env31333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31332_31333 : H12AffineEnvironment.transform 13 11690 env31332 = env31333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11690 env31332 == env31333) = true)

theorem identity31333 : scanCanonicalize (H12AffineFastState.compose env31333 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound31333 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31334 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,3118,6566,6185,3135,2477,1024,6567,4112,6534,6582,6564,268,17,4519,3254,4232,2477,1421,32,256,6414,3238,7079]

theorem envBound31334 : H12AffineFastState.Bounded env31334 := by
  intro p hp
  have h : env31334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31333_31334 : H12AffineEnvironment.transform 12 388 env31333 = env31334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env31333 == env31334) = true)

theorem identity31334 : scanCanonicalize (H12AffineFastState.compose env31334 (packedSelected [4,5,8,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31334 : packedSelected [4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env31335 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,3118,6447,6185,3135,2340,1024,6446,4112,6415,6463,6445,268,17,4398,3135,4097,2340,1284,32,256,6414,3119,6958]

theorem envBound31335 : H12AffineFastState.Bounded env31335 := by
  intro p hp
  have h : env31335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31334_31335 : H12AffineEnvironment.transform 6 9 env31334 = env31335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31334 == env31335) = true)

theorem identity31335 : scanCanonicalize (H12AffineFastState.compose env31335 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound31335 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env31336 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,269,3118,1290,1036,3135,2340,1024,1291,3125,1322,1306,1288,268,17,3339,3135,3108,2340,1284,32,256,1323,3119,1803]

theorem envBound31336 : H12AffineFastState.Bounded env31336 := by
  intro p hp
  have h : env31336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31335_31336 : H12AffineEnvironment.transform 11 3109 env31335 = env31336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env31335 == env31336) = true)

theorem identity31336 : scanCanonicalize (H12AffineFastState.compose env31336 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 314) := by decide +kernel

theorem selectedBound31336 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31337 : List Nat := [2,4,8,16,32,16,9,256,512,314,2048,2335,269,2324,48,310,2309,2340,314,49,2319,16,32,50,268,17,2097,2309,2334,2340,62,32,256,17,2325,561]

theorem envBound31337 : H12AffineFastState.Bounded env31337 := by
  intro p hp
  have h : env31337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31336_31337 : H12AffineEnvironment.transform 9 314 env31336 = env31337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 314 env31336 == env31337) = true)

theorem identity31337 : scanCanonicalize (H12AffineFastState.compose env31337 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31337 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31338 : List Nat := [2,4,8,16,16,16,9,256,512,266,2048,2335,269,2324,0,262,2309,2324,266,1,2319,16,16,2,268,17,2049,2309,2334,2324,14,16,256,17,2325,513]

theorem envBound31338 : H12AffineFastState.Bounded env31338 := by
  intro p hp
  have h : env31338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31337_31338 : H12AffineEnvironment.transform 4 16 env31337 = env31338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31337 == env31338) = true)

theorem identity31338 : scanCanonicalize (H12AffineFastState.compose env31338 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound31338 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31339 : List Nat := [2,4,8,16,16,16,9,30,512,20,2048,2049,19,2058,0,24,2075,2058,20,1,2065,16,16,2,18,17,2049,2075,2048,2058,14,16,30,17,2059,513]

theorem envBound31339 : H12AffineFastState.Bounded env31339 := by
  intro p hp
  have h : env31339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31338_31339 : H12AffineEnvironment.transform 7 30 env31338 = env31339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env31338 == env31339) = true)

def env31340 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212030,1024,32769,4113,180273,73755,41351,8328,16,245139,79131,91403,56356,1420,201783,256,21792,46212,74250]

theorem envBound31340 : H12AffineFastState.Bounded env31340 := by
  intro p hp
  have h : env31340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31328_31340 : H12AffineEnvironment.transform 5 17 env31328 = env31340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31328 == env31340) = true)

theorem identity31340 : scanCanonicalize (H12AffineFastState.compose env31340 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound31340 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env31341 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13341,67619,1024,32769,4113,62508,73755,41351,8328,16,100750,79131,91403,56356,1420,73770,256,21792,46212,74250]

theorem envBound31341 : H12AffineFastState.Bounded env31341 := by
  intro p hp
  have h : env31341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31340_31341 : H12AffineEnvironment.transform 16 13341 env31340 = env31341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env31340 == env31341) = true)

theorem identity31341 : scanCanonicalize (H12AffineFastState.compose env31341 (packedSelected [0,1,2,3,4,6,7,9,10,11,14,17,18,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 41382) := by decide +kernel

theorem selectedBound31341 : packedSelected [0,1,2,3,4,6,7,9,10,11,14,17,18,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31342 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,41382,13341,43397,1024,32769,4113,62508,33213,41351,8328,16,10280,38077,50349,56356,1420,33164,256,21792,46212,33708]

theorem envBound31342 : H12AffineFastState.Bounded env31342 := by
  intro p hp
  have h : env31342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31341_31342 : H12AffineEnvironment.transform 15 41382 env31341 = env31342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41382 env31341 == env31342) = true)

theorem identity31342 : scanCanonicalize (H12AffineFastState.compose env31342 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31342 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env31343 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,8192,16384,32768,41091,13341,43168,1024,32769,4113,62508,32920,41122,8328,16,10280,38077,50349,56356,1193,32937,37,21509,46212,33417]

theorem envBound31343 : H12AffineFastState.Bounded env31343 := by
  intro p hp
  have h : env31343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31342_31343 : H12AffineEnvironment.transform 7 37 env31342 = env31343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31342 == env31343) = true)

theorem identity31343 : scanCanonicalize (H12AffineFastState.compose env31343 (packedSelected [0,1,4,7,8,12,15,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound31343 : packedSelected [0,1,4,7,8,12,15,19,22] rootPS < 2^1333 := by decide +kernel

def env31344 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,8192,16384,137,8202,13341,10281,1024,136,4113,29861,17,8235,8328,16,10280,5172,17444,23725,1193,32,37,21509,13325,512]

theorem envBound31344 : H12AffineFastState.Bounded env31344 := by
  intro p hp
  have h : env31344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31343_31344 : H12AffineEnvironment.transform 14 137 env31343 = env31344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env31343 == env31344) = true)

theorem identity31344 : scanCanonicalize (H12AffineFastState.compose env31344 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound31344 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31345 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,161,16384,137,171,5308,2184,1024,136,4113,21508,17,138,41,16,2185,5172,17444,23725,1193,32,37,21509,5292,512]

theorem envBound31345 : H12AffineFastState.Bounded env31345 := by
  intro p hp
  have h : env31345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31344_31345 : H12AffineEnvironment.transform 12 161 env31344 = env31345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env31344 == env31345) = true)

theorem identity31345 : scanCanonicalize (H12AffineFastState.compose env31345 (packedSelected [0,3,5,6,7,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound31345 : packedSelected [0,3,5,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env31346 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,161,5157,137,171,5308,2184,1024,136,4113,33,17,138,41,16,2185,5172,4097,2184,1193,32,37,32,5292,512]

theorem envBound31346 : H12AffineFastState.Bounded env31346 := by
  intro p hp
  have h : env31346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31345_31346 : H12AffineEnvironment.transform 13 5157 env31345 = env31346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env31345 == env31346) = true)

theorem identity31346 : scanCanonicalize (H12AffineFastState.compose env31346 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31346 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31347 : List Nat := [2,4,8,16,1,17,128,4,512,1024,2048,4096,128,5124,137,138,5277,2184,1024,136,4113,0,17,138,8,16,2185,5141,4097,2184,1160,1,4,1,5261,512]

theorem envBound31347 : H12AffineFastState.Bounded env31347 := by
  intro p hp
  have h : env31347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31346_31347 : H12AffineEnvironment.transform 4 1 env31346 = env31347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31346 == env31347) = true)

theorem identity31347 : scanCanonicalize (H12AffineFastState.compose env31347 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound31347 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env31348 : List Nat := [2,4,8,16,1,17,128,4,512,1024,2048,1029,128,1,137,138,152,2184,1024,136,1044,0,17,138,8,16,2185,16,1028,2184,1160,1,4,1,136,512]

theorem envBound31348 : H12AffineFastState.Bounded env31348 := by
  intro p hp
  have h : env31348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31347_31348 : H12AffineEnvironment.transform 11 1029 env31347 = env31348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env31347 == env31348) = true)

def env31349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400501,499129,8328,65,295421,395637,416100,56436,1500,272392,256,21792,46212,74251]

theorem envBound31349 : H12AffineFastState.Bounded env31349 := by
  intro p hp
  have h : env31349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31326_31349 : H12AffineEnvironment.transform 20 4161 env31326 = env31349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31326 == env31349) = true)

theorem identity31349 : scanCanonicalize (H12AffineFastState.compose env31349 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound31349 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,180273,400501,412007,8328,65,295421,395637,416100,56436,1500,272392,256,21792,46212,63189]

theorem envBound31350 : H12AffineFastState.Bounded env31350 := by
  intro p hp
  have h : env31350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31349_31350 : H12AffineEnvironment.transform 15 54494 env31349 = env31350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env31349 == env31350) = true)

def env31351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180273,400501,412007,8192,65,295285,395637,416100,56436,1364,272392,256,21792,46092,63069]

theorem envBound31351 : H12AffineFastState.Bounded env31351 := by
  intro p hp
  have h : env31351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31350_31351 : H12AffineEnvironment.transform 6 8 env31350 = env31351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31350 == env31351) = true)

theorem identity31351 : scanCanonicalize (H12AffineFastState.compose env31351 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 2128) := by decide +kernel

theorem selectedBound31351 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env31352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,2128,1024,32769,4161,180273,136229,147767,8192,65,35109,131365,151860,56436,1364,8280,256,21792,46092,63069]

theorem envBound31352 : H12AffineFastState.Bounded env31352 := by
  intro p hp
  have h : env31352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31351_31352 : H12AffineEnvironment.transform 17 2128 env31351 = env31352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2128 env31351 == env31352) = true)

theorem identity31352 : scanCanonicalize (H12AffineFastState.compose env31352 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound31352 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21540,114,131072,2128,1024,21541,4161,136213,136229,147767,8192,65,23809,131365,151860,2128,1364,8280,256,21792,24616,8825]

theorem envBound31353 : H12AffineFastState.Bounded env31353 := by
  intro p hp
  have h : env31353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31352_31353 : H12AffineEnvironment.transform 14 21540 env31352 = env31353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env31352 == env31353) = true)

theorem identity31353 : scanCanonicalize (H12AffineFastState.compose env31353 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13672) := by decide +kernel

theorem selectedBound31353 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env31354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21540,114,13672,2128,1024,21541,4161,8573,8525,29791,8192,65,23809,13389,25692,2128,1364,8280,256,21792,24616,8825]

theorem envBound31354 : H12AffineFastState.Bounded env31354 := by
  intro p hp
  have h : env31354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31353_31354 : H12AffineEnvironment.transform 16 13672 env31353 = env31354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13672 env31353 == env31354) = true)

theorem identity31354 : scanCanonicalize (H12AffineFastState.compose env31354 (packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound31354 : packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31355 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21540,114,5440,2128,1024,21541,4161,341,357,21623,40,65,23809,5221,17524,2128,1364,112,256,21792,16384,593]

theorem envBound31355 : H12AffineFastState.Bounded env31355 := by
  intro p hp
  have h : env31355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31354_31355 : H12AffineEnvironment.transform 12 40 env31354 = env31355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env31354 == env31355) = true)

theorem identity31355 : scanCanonicalize (H12AffineFastState.compose env31355 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31355 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31356 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,16384,21540,35,5393,2049,1024,21541,4112,260,308,21542,40,16,23809,5172,17445,2049,1285,33,256,21792,16384,512]

theorem envBound31356 : H12AffineFastState.Bounded env31356 := by
  intro p hp
  have h : env31356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31355_31356 : H12AffineEnvironment.transform 5 17 env31355 = env31356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31355 == env31356) = true)

theorem identity31356 : scanCanonicalize (H12AffineFastState.compose env31356 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31356 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31357 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,40,16384,21540,35,5140,2049,1024,21541,4112,1,49,21542,40,16,23556,5172,17445,2049,1024,33,5,21541,16384,512]

theorem envBound31357 : H12AffineFastState.Bounded env31357 := by
  intro p hp
  have h : env31357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31356_31357 : H12AffineEnvironment.transform 7 5 env31356 = env31357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31356 == env31357) = true)

theorem identity31357 : scanCanonicalize (H12AffineFastState.compose env31357 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound31357 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31358 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,40,5125,33,35,5140,2049,1024,32,4112,1,49,35,40,16,2049,5172,4128,2049,1024,33,5,32,5125,512]

theorem envBound31358 : H12AffineFastState.Bounded env31358 := by
  intro p hp
  have h : env31358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31357_31358 : H12AffineEnvironment.transform 13 5125 env31357 = env31358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env31357 == env31358) = true)

theorem identity31358 : scanCanonicalize (H12AffineFastState.compose env31358 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound31358 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env31359 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,1557,40,528,33,35,513,2049,1024,32,1541,1,49,35,40,16,2049,545,1589,2049,1024,33,5,32,528,512]

theorem envBound31359 : H12AffineFastState.Bounded env31359 := by
  intro p hp
  have h : env31359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31358_31359 : H12AffineEnvironment.transform 11 1557 env31358 = env31359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env31358 == env31359) = true)

theorem identity31359 : scanCanonicalize (H12AffineFastState.compose env31359 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31359 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31360 : List Nat := [2,4,8,16,32,17,8,5,512,1024,49,1557,40,528,33,35,513,48,1024,32,1541,1,49,35,40,16,48,545,1589,48,1024,33,5,32,528,512]

theorem envBound31360 : H12AffineFastState.Bounded env31360 := by
  intro p hp
  have h : env31360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31359_31360 : H12AffineEnvironment.transform 10 49 env31359 = env31360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31359 == env31360) = true)

theorem identity31360 : scanCanonicalize (H12AffineFastState.compose env31360 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound31360 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env31361 : List Nat := [2,4,8,16,32,17,8,5,512,564,49,33,40,528,33,35,513,48,564,32,49,1,49,35,40,16,48,545,1,48,564,33,5,32,528,512]

theorem envBound31361 : H12AffineFastState.Bounded env31361 := by
  intro p hp
  have h : env31361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31360_31361 : H12AffineEnvironment.transform 9 564 env31360 = env31361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env31360 == env31361) = true)

theorem identity31361 : scanCanonicalize (H12AffineFastState.compose env31361 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31361 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31362 : List Nat := [2,4,8,16,17,17,8,5,512,517,0,16,25,528,16,18,513,1,517,17,0,1,0,18,25,16,1,528,1,1,517,16,5,17,528,512]

theorem envBound31362 : H12AffineFastState.Bounded env31362 := by
  intro p hp
  have h : env31362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31361_31362 : H12AffineEnvironment.transform 4 17 env31361 = env31362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31361 == env31362) = true)

theorem identity31362 : scanCanonicalize (H12AffineFastState.compose env31362 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31362 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31363 : List Nat := [2,4,8,16,17,17,8,5,0,5,0,16,25,16,16,18,1,1,5,17,0,1,0,18,25,16,1,16,1,1,5,16,5,17,16,0]

theorem envBound31363 : H12AffineFastState.Bounded env31363 := by
  intro p hp
  have h : env31363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31362_31363 : H12AffineEnvironment.transform 8 0 env31362 = env31363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31362 == env31363) = true)

theorem identity31363 : scanCanonicalize (H12AffineFastState.compose env31363 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound31363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31364 : List Nat := [2,4,8,14,15,15,8,5,0,5,0,14,7,14,14,12,1,1,5,15,0,1,0,12,7,14,1,14,1,1,5,14,5,15,14,0]

theorem envBound31364 : H12AffineFastState.Bounded env31364 := by
  intro p hp
  have h : env31364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31363_31364 : H12AffineEnvironment.transform 3 14 env31363 = env31364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env31363 == env31364) = true)

theorem identity31364 : scanCanonicalize (H12AffineFastState.compose env31364 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound31364 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31365 : List Nat := [2,4,7,1,0,0,7,5,0,5,0,1,7,1,1,3,1,1,5,0,0,1,0,3,7,1,1,1,1,1,5,1,5,0,1,0]

theorem envBound31365 : H12AffineFastState.Bounded env31365 := by
  intro p hp
  have h : env31365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31364_31365 : H12AffineEnvironment.transform 2 7 env31364 = env31365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env31364 == env31365) = true)

def env31366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180273,400501,412007,8193,65,295284,395637,416100,56436,1365,272392,256,21792,46093,63068]

theorem envBound31366 : H12AffineFastState.Bounded env31366 := by
  intro p hp
  have h : env31366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31350_31366 : H12AffineEnvironment.transform 6 9 env31350 = env31366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31350 == env31366) = true)

theorem identity31366 : scanCanonicalize (H12AffineFastState.compose env31366 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound31366 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env31367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,23588,1024,32769,4161,180273,147537,136515,8193,65,56656,152913,132416,56436,1365,29740,256,21792,46093,63068]

theorem envBound31367 : H12AffineFastState.Bounded env31367 := by
  intro p hp
  have h : env31367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31366_31367 : H12AffineEnvironment.transform 17 23588 env31366 = env31367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env31366 == env31367) = true)

theorem identity31367 : scanCanonicalize (H12AffineFastState.compose env31367 (packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound31367 : packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env31368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,57677,23588,1024,32769,4161,8572,41244,62478,8193,65,56656,46108,58381,56436,1365,29740,256,21792,46093,63068]

theorem envBound31368 : H12AffineFastState.Bounded env31368 := by
  intro p hp
  have h : env31368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31367_31368 : H12AffineEnvironment.transform 16 57677 env31367 = env31368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env31367 == env31368) = true)

theorem identity31368 : scanCanonicalize (H12AffineFastState.compose env31368 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31368 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env31369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40971,38161,10360,1024,32769,4161,8572,41244,32850,8193,65,43276,46108,36945,43048,1365,112,256,8572,46093,33280]

theorem envBound31369 : H12AffineFastState.Bounded env31369 := by
  intro p hp
  have h : env31369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31368_31369 : H12AffineEnvironment.transform 13 13404 env31368 = env31369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31368 == env31369) = true)

theorem identity31369 : scanCanonicalize (H12AffineFastState.compose env31369 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31369 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,5393,10360,1024,1,4161,8572,8476,82,8193,65,10508,13340,4177,10280,1365,112,256,8572,13325,512]

theorem envBound31370 : H12AffineFastState.Bounded env31370 := by
  intro p hp
  have h : env31370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31369_31370 : H12AffineEnvironment.transform 14 0 env31369 = env31370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31369 == env31370) = true)

theorem identity31370 : scanCanonicalize (H12AffineFastState.compose env31370 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31370 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31371 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,13357,0,8203,5393,10249,1024,1,4144,8461,8476,35,8193,48,10508,13340,4128,10280,1316,1,256,8461,13325,512]

theorem envBound31371 : H12AffineFastState.Bounded env31371 := by
  intro p hp
  have h : env31371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31370_31371 : H12AffineEnvironment.transform 5 49 env31370 = env31371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31370 == env31371) = true)

theorem identity31371 : scanCanonicalize (H12AffineFastState.compose env31371 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound31371 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31372 : List Nat := [2,4,8,16,32,49,9,256,512,20,2048,4096,8192,12345,0,8203,4357,10249,20,1,4144,8461,8476,35,8193,48,10508,12296,4128,10280,304,1,256,8461,12313,512]

theorem envBound31372 : H12AffineFastState.Bounded env31372 := by
  intro p hp
  have h : env31372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31371_31372 : H12AffineEnvironment.transform 9 20 env31371 = env31372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31371 == env31372) = true)

theorem identity31372 : scanCanonicalize (H12AffineFastState.compose env31372 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31372 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31373 : List Nat := [2,4,8,16,1,16,9,256,512,20,2048,4096,8192,12312,0,8203,4357,10249,20,1,4113,8461,8476,2,8193,17,10508,12296,4097,10249,273,1,256,8461,12313,512]

theorem envBound31373 : H12AffineFastState.Bounded env31373 := by
  intro p hp
  have h : env31373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31372_31373 : H12AffineEnvironment.transform 4 1 env31372 = env31373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31372 == env31373) = true)

theorem identity31373 : scanCanonicalize (H12AffineFastState.compose env31373 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound31373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31374 : List Nat := [2,4,8,16,1,16,9,256,512,20,2048,16,8192,8200,0,8203,277,10249,20,1,1,8461,8476,2,8193,17,10508,8216,17,10249,273,1,256,8461,8201,512]

theorem envBound31374 : H12AffineFastState.Bounded env31374 := by
  intro p hp
  have h : env31374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31373_31374 : H12AffineEnvironment.transform 11 16 env31373 = env31374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31373 == env31374) = true)

theorem identity31374 : scanCanonicalize (H12AffineFastState.compose env31374 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound31374 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31375 : List Nat := [2,4,8,16,1,16,9,256,512,20,261,16,8192,8200,0,8203,277,8460,20,1,1,8461,8476,2,8193,17,8201,8216,17,8460,273,1,256,8461,8201,512]

theorem envBound31375 : H12AffineFastState.Bounded env31375 := by
  intro p hp
  have h : env31375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31374_31375 : H12AffineEnvironment.transform 10 261 env31374 = env31375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env31374 == env31375) = true)

def env31376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound31376 : H12AffineFastState.Bounded env31376 := by
  intro p hp
  have h : env31376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31153_31376 : H12AffineEnvironment.transform 18 1025 env31153 = env31376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31153 == env31376) = true)

theorem identity31376 : scanCanonicalize (H12AffineFastState.compose env31376 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485428) := by decide +kernel

theorem selectedBound31376 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485428,8328,65,14822581,288824,10507600,8830976,10774692,4491637,257,8661016,8702397,10833778]

theorem envBound31377 : H12AffineFastState.Bounded env31377 := by
  intro p hp
  have h : env31377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31376_31377 : H12AffineEnvironment.transform 23 2485428 env31376 = env31377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485428 env31376 == env31377) = true)

def env31378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294200,2485428,8328,65,6705549,288824,2369640,179512,2102684,4491637,257,21792,46213,2175562]

theorem envBound31378 : H12AffineFastState.Bounded env31378 := by
  intro p hp
  have h : env31378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31377_31378 : H12AffineEnvironment.transform 22 294200 env31377 = env31378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294200 env31377 == env31378) = true)

def env31379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294200,98780,8328,65,4340965,288824,17664,179512,293108,4491637,257,21792,46213,352034]

theorem envBound31379 : H12AffineFastState.Bounded env31379 := by
  intro p hp
  have h : env31379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31378_31379 : H12AffineEnvironment.transform 20 290152 env31378 = env31379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env31378 == env31379) = true)

def env31380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294200,98780,8328,65,398437,288824,17664,179512,293108,41461,257,21792,46213,352034]

theorem envBound31380 : H12AffineFastState.Bounded env31380 := by
  intro p hp
  have h : env31380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31379_31380 : H12AffineEnvironment.transform 21 272512 env31379 = env31380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31379 == env31380) = true)

theorem identity31380 : scanCanonicalize (H12AffineFastState.compose env31380 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound31380 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35325,1025,32769,58517,41341,62661,98780,8328,65,171416,57797,17664,179512,61705,41461,257,21792,46213,120543]

theorem envBound31381 : H12AffineFastState.Bounded env31381 := by
  intro p hp
  have h : env31381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31380_31381 : H12AffineEnvironment.transform 17 35325 env31380 = env31381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env31380 == env31381) = true)

def env31382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35325,1025,32769,45461,41341,41413,98780,8328,65,171416,46277,4096,179512,41993,41461,257,32,46213,99295]

theorem envBound31382 : H12AffineFastState.Bounded env31382 := by
  intro p hp
  have h : env31382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31381_31382 : H12AffineEnvironment.transform 13 5376 env31381 = env31382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31381 == env31382) = true)

theorem identity31382 : scanCanonicalize (H12AffineFastState.compose env31382 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound31382 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,131072,35325,1025,32769,45461,41341,41413,41310,8328,65,171416,46277,4096,179512,41993,41461,257,32,46213,41821]

theorem envBound31383 : H12AffineFastState.Bounded env31383 := by
  intro p hp
  have h : env31383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31382_31383 : H12AffineEnvironment.transform 15 8322 env31382 = env31383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env31382 == env31383) = true)

theorem identity31383 : scanCanonicalize (H12AffineFastState.compose env31383 (packedSelected [0,1,8,10,12,18,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound31383 : packedSelected [0,1,8,10,12,18,20,27] rootPS < 2^1333 := by decide +kernel

def env31384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8322,131072,10281,1025,8661,4161,169,17,138,8328,65,146508,5393,4096,138476,1501,33,257,32,5457,649]

theorem envBound31384 : H12AffineFastState.Bounded env31384 := by
  intro p hp
  have h : env31384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31383_31384 : H12AffineEnvironment.transform 14 8660 env31383 = env31384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env31383 == env31384) = true)

theorem identity31384 : scanCanonicalize (H12AffineFastState.compose env31384 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound31384 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,381,5376,169,511,131072,2388,1025,168,4161,169,17,138,501,65,138545,5393,4096,138476,1501,33,257,32,5457,649]

theorem envBound31385 : H12AffineFastState.Bounded env31385 := by
  intro p hp
  have h : env31385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31384_31385 : H12AffineEnvironment.transform 12 381 env31384 = env31385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env31384 == env31385) = true)

def env31386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35325,1025,32769,45460,41341,41412,98780,8328,65,171416,46276,4097,179512,41992,41461,257,33,46213,99294]

theorem envBound31386 : H12AffineFastState.Bounded env31386 := by
  intro p hp
  have h : env31386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31381_31386 : H12AffineEnvironment.transform 13 5377 env31381 = env31386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31381 == env31386) = true)

theorem identity31386 : scanCanonicalize (H12AffineFastState.compose env31386 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound31386 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,35325,1025,32769,45460,41341,41412,3,8328,65,171416,46276,4097,179512,41992,41461,257,33,46213,513]

theorem envBound31387 : H12AffineFastState.Bounded env31387 := by
  intro p hp
  have h : env31387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31386_31387 : H12AffineEnvironment.transform 15 33247 env31386 = env31387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env31386 == env31387) = true)

theorem identity31387 : scanCanonicalize (H12AffineFastState.compose env31387 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound31387 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env31388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,46277,35325,1025,32769,45460,41341,41412,3,8328,65,10589,46276,4097,2557,41992,41461,257,33,46213,513]

theorem envBound31388 : H12AffineFastState.Bounded env31388 := by
  intro p hp
  have h : env31388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31387_31388 : H12AffineEnvironment.transform 16 46277 env31387 = env31388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env31387 == env31388) = true)

theorem identity31388 : scanCanonicalize (H12AffineFastState.compose env31388 (packedSelected [1,2,3,6,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31388 : packedSelected [1,2,3,6,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env31389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,32768,33247,38345,35325,1025,32769,37016,32881,32968,3,388,65,2129,38344,4097,2557,34052,33017,257,33,38281,513]

theorem envBound31389 : H12AffineFastState.Bounded env31389 := by
  intro p hp
  have h : env31389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31388_31389 : H12AffineEnvironment.transform 12 268 env31388 = env31389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31388 == env31389) = true)

theorem identity31389 : scanCanonicalize (H12AffineFastState.compose env31389 (packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31389 : packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,33110,38208,35188,1025,32769,36881,32881,32833,3,269,65,2129,38209,4097,2420,34052,32880,257,33,38144,513]

theorem envBound31390 : H12AffineFastState.Bounded env31390 := by
  intro p hp
  have h : env31390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31389_31390 : H12AffineEnvironment.transform 6 9 env31389 = env31390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31389 == env31390) = true)

theorem identity31390 : scanCanonicalize (H12AffineFastState.compose env31390 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound31390 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,262,5392,2340,1025,81,4161,33,17,3,269,65,2129,5393,4097,2420,1364,32,257,33,5456,513]

theorem envBound31391 : H12AffineFastState.Bounded env31391 := by
  intro p hp
  have h : env31391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31390_31391 : H12AffineEnvironment.transform 14 80 env31390 = env31391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env31390 == env31391) = true)

theorem identity31391 : scanCanonicalize (H12AffineFastState.compose env31391 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1605) := by decide +kernel

theorem selectedBound31391 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1605,268,836,80,262,853,2340,1025,81,1540,33,17,3,269,65,2129,852,1604,2420,1364,32,257,33,789,513]

theorem envBound31392 : H12AffineFastState.Bounded env31392 := by
  intro p hp
  have h : env31392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31391_31392 : H12AffineEnvironment.transform 11 1605 env31391 = env31392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1605 env31391 == env31392) = true)

theorem identity31392 : scanCanonicalize (H12AffineFastState.compose env31392 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound31392 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env31393 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,1605,89,529,80,83,512,2161,1025,81,1540,33,17,3,88,65,2129,513,1604,2081,1025,32,84,33,576,513]

theorem envBound31393 : H12AffineFastState.Bounded env31393 := by
  intro p hp
  have h : env31393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31392_31393 : H12AffineEnvironment.transform 7 85 env31392 = env31393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env31392 == env31393) = true)

theorem identity31393 : scanCanonicalize (H12AffineFastState.compose env31393 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31393 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31394 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,1557,9,529,0,3,512,2081,1025,1,1540,33,17,3,8,17,2049,513,1556,2081,1025,32,4,33,528,513]

theorem envBound31394 : H12AffineFastState.Bounded env31394 := by
  intro p hp
  have h : env31394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31393_31394 : H12AffineEnvironment.transform 5 16 env31393 = env31394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31393 == env31394) = true)

theorem identity31394 : scanCanonicalize (H12AffineFastState.compose env31394 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound31394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31395 : List Nat := [2,4,8,16,32,16,9,5,512,37,2048,560,9,529,0,3,512,2081,36,1,545,33,17,3,8,17,2049,513,561,2081,36,32,4,33,528,513]

theorem envBound31395 : H12AffineFastState.Bounded env31395 := by
  intro p hp
  have h : env31395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31394_31395 : H12AffineEnvironment.transform 9 37 env31394 = env31395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env31394 == env31395) = true)

theorem identity31395 : scanCanonicalize (H12AffineFastState.compose env31395 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound31395 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31396 : List Nat := [2,4,8,16,32,16,9,5,512,37,513,560,9,529,0,3,512,544,36,1,545,33,17,3,8,17,512,513,561,544,36,32,4,33,528,513]

theorem envBound31396 : H12AffineFastState.Bounded env31396 := by
  intro p hp
  have h : env31396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31395_31396 : H12AffineEnvironment.transform 10 513 env31395 = env31396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env31395 == env31396) = true)

theorem identity31396 : scanCanonicalize (H12AffineFastState.compose env31396 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31396 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env31397 : List Nat := [2,4,8,16,16,16,9,5,512,21,513,512,9,529,0,3,512,528,20,1,529,17,17,3,8,17,512,513,513,528,20,16,4,17,528,513]

theorem envBound31397 : H12AffineFastState.Bounded env31397 := by
  intro p hp
  have h : env31397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31396_31397 : H12AffineEnvironment.transform 4 16 env31396 = env31397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31396 == env31397) = true)

theorem identity31397 : scanCanonicalize (H12AffineFastState.compose env31397 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31397 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31398 : List Nat := [2,4,8,16,16,16,9,5,1,21,0,1,9,16,0,3,1,17,20,1,16,17,17,3,8,17,1,0,0,17,20,16,4,17,17,0]

theorem envBound31398 : H12AffineFastState.Bounded env31398 := by
  intro p hp
  have h : env31398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31397_31398 : H12AffineEnvironment.transform 8 1 env31397 = env31398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31397 == env31398) = true)

def env31399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294200,98780,8328,65,398436,288824,17664,179512,293108,41460,257,21792,46213,352034]

theorem envBound31399 : H12AffineFastState.Bounded env31399 := by
  intro p hp
  have h : env31399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31379_31399 : H12AffineEnvironment.transform 21 272513 env31379 = env31399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31379 == env31399) = true)

theorem identity31399 : scanCanonicalize (H12AffineFastState.compose env31399 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound31399 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,290152,272513,294200,95496,8328,65,398436,288824,17664,149996,293108,21792,257,21792,16465,352034]

theorem envBound31400 : H12AffineFastState.Bounded env31400 := by
  intro p hp
  have h : env31400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31399_31400 : H12AffineEnvironment.transform 14 29908 env31399 = env31400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env31399 == env31400) = true)

theorem identity31400 : scanCanonicalize (H12AffineFastState.compose env31400 (packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound31400 : packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS < 2^1333 := by decide +kernel

def env31401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30083,131072,262144,1025,29909,290152,272513,294200,139,8328,65,398436,288824,17664,149996,293108,21792,257,21792,16465,273057]

theorem envBound31401 : H12AffineFastState.Bounded env31401 := by
  intro p hp
  have h : env31401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31400_31401 : H12AffineEnvironment.transform 15 30083 env31400 = env31401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env31400 == env31401) = true)

theorem identity31401 : scanCanonicalize (H12AffineFastState.compose env31401 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound31401 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30083,131072,2476,1025,29909,25796,8493,29844,139,8328,65,138696,24980,17664,149996,29016,21792,257,21792,16465,8973]

theorem envBound31402 : H12AffineFastState.Bounded env31402 := by
  intro p hp
  have h : env31402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31401_31402 : H12AffineEnvironment.transform 17 2476 env31401 = env31402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env31401 == env31402) = true)

theorem identity31402 : scanCanonicalize (H12AffineFastState.compose env31402 (packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound31402 : packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env31403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,16384,20925,20714,131072,2476,1025,20924,16813,1092,20989,139,1505,65,138696,17661,17664,149996,21553,21792,257,21792,16465,1636]

theorem envBound31403 : H12AffineFastState.Bounded env31403 := by
  intro p hp
  have h : env31403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31402_31403 : H12AffineEnvironment.transform 12 1385 env31402 = env31403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env31402 == env31403) = true)

theorem identity31403 : scanCanonicalize (H12AffineFastState.compose env31403 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 16585) := by decide +kernel

theorem selectedBound31403 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env31404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,16384,20925,20714,16585,2476,1025,20924,16813,1092,20989,139,1505,65,23809,17661,17664,2341,21553,21792,257,21792,16465,1636]

theorem envBound31404 : H12AffineFastState.Bounded env31404 := by
  intro p hp
  have h : env31404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31403_31404 : H12AffineEnvironment.transform 16 16585 env31403 = env31404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16585 env31403 == env31404) = true)

theorem identity31404 : scanCanonicalize (H12AffineFastState.compose env31404 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound31404 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env31405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,2184,6453,6242,2113,2476,1025,6452,2341,1092,6517,139,1505,65,5513,3189,3464,2341,7353,7592,257,7592,2265,1636]

theorem envBound31405 : H12AffineFastState.Bounded env31405 := by
  intro p hp
  have h : env31405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31404_31405 : H12AffineEnvironment.transform 13 2184 env31404 = env31405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env31404 == env31405) = true)

theorem identity31405 : scanCanonicalize (H12AffineFastState.compose env31405 (packedSelected [10,12,19] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound31405 : packedSelected [10,12,19] rootPS < 2^1333 := by decide +kernel

def env31406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,153,1385,2184,2476,2299,2113,2476,1025,2477,2341,1092,2540,139,1505,65,1296,3189,3464,2341,3104,3377,257,3377,2265,1636]

theorem envBound31406 : H12AffineFastState.Bounded env31406 := by
  intro p hp
  have h : env31406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31405_31406 : H12AffineEnvironment.transform 11 153 env31405 = env31406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env31405 == env31406) = true)

theorem identity31406 : scanCanonicalize (H12AffineFastState.compose env31406 (packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound31406 : packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env31407 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,153,1220,2184,2049,2299,2113,2049,1025,2048,2184,1092,2113,139,1100,65,1213,3189,3109,2184,3104,3228,172,3228,2265,1636]

theorem envBound31407 : H12AffineFastState.Bounded env31407 := by
  intro p hp
  have h : env31407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31406_31407 : H12AffineEnvironment.transform 7 173 env31406 = env31407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env31406 == env31407) = true)

theorem identity31407 : scanCanonicalize (H12AffineFastState.compose env31407 (packedSelected [0,1,3,5,7,8,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound31407 : packedSelected [0,1,3,5,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env31408 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,65,1052,2128,2049,2083,2113,2049,1025,2048,2128,1092,2113,83,1100,65,1125,3189,3109,2128,3104,3140,116,3140,2049,1636]

theorem envBound31408 : H12AffineFastState.Bounded env31408 := by
  intro p hp
  have h : env31408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31407_31408 : H12AffineEnvironment.transform 6 88 env31407 = env31408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env31407 == env31408) = true)

theorem identity31408 : scanCanonicalize (H12AffineFastState.compose env31408 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound31408 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31409 : List Nat := [2,4,8,16,32,64,88,117,512,1024,1141,65,1052,1061,1140,1110,1076,1140,1025,1141,1061,1092,1076,83,1100,65,1125,0,80,1061,85,49,116,49,1140,1636]

theorem envBound31409 : H12AffineFastState.Bounded env31409 := by
  intro p hp
  have h : env31409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31408_31409 : H12AffineEnvironment.transform 10 1141 env31408 = env31409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env31408 == env31409) = true)

theorem identity31409 : scanCanonicalize (H12AffineFastState.compose env31409 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound31409 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31410 : List Nat := [2,4,8,16,32,64,88,117,512,117,0,65,105,80,1,35,65,1,116,0,80,49,65,83,57,65,16,0,80,80,85,49,116,49,1,529]

theorem envBound31410 : H12AffineFastState.Bounded env31410 := by
  intro p hp
  have h : env31410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31409_31410 : H12AffineEnvironment.transform 9 117 env31409 = env31410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env31409 == env31410) = true)

theorem identity31410 : scanCanonicalize (H12AffineFastState.compose env31410 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31410 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env31411 : List Nat := [2,4,8,0,32,64,72,101,512,101,0,65,105,64,1,35,65,1,100,0,64,33,65,67,41,65,0,0,64,64,69,33,100,33,1,513]

theorem envBound31411 : H12AffineFastState.Bounded env31411 := by
  intro p hp
  have h : env31411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31410_31411 : H12AffineEnvironment.transform 3 0 env31410 = env31411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31410 == env31411) = true)

theorem identity31411 : scanCanonicalize (H12AffineFastState.compose env31411 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31411 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31412 : List Nat := [2,4,8,0,32,0,8,37,512,37,0,1,41,0,1,35,1,1,36,0,0,33,1,3,41,1,0,0,0,0,5,33,36,33,1,513]

theorem envBound31412 : H12AffineFastState.Bounded env31412 := by
  intro p hp
  have h : env31412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31411_31412 : H12AffineEnvironment.transform 5 0 env31411 = env31412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31411 == env31412) = true)

theorem identity31412 : scanCanonicalize (H12AffineFastState.compose env31412 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound31412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31413 : List Nat := [2,4,8,0,32,0,8,37,33,37,0,1,41,0,1,35,1,1,36,0,0,33,1,3,41,1,0,0,0,0,5,33,36,33,1,32]

theorem envBound31413 : H12AffineFastState.Bounded env31413 := by
  intro p hp
  have h : env31413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31412_31413 : H12AffineEnvironment.transform 8 33 env31412 = env31413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env31412 == env31413) = true)

theorem identity31413 : scanCanonicalize (H12AffineFastState.compose env31413 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31414 : List Nat := [2,4,8,0,0,0,8,5,1,5,0,1,9,0,1,3,1,1,4,0,0,1,1,3,9,1,0,0,0,0,5,1,4,1,1,0]

theorem envBound31414 : H12AffineFastState.Bounded env31414 := by
  intro p hp
  have h : env31414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31413_31414 : H12AffineEnvironment.transform 4 0 env31413 = env31414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31413 == env31414) = true)

def env31415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294200,98781,8328,65,4340964,288824,17665,179512,293109,4491637,257,21792,46213,352035]

theorem envBound31415 : H12AffineFastState.Bounded env31415 := by
  intro p hp
  have h : env31415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31378_31415 : H12AffineEnvironment.transform 20 290153 env31378 = env31415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env31378 == env31415) = true)

def env31416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294200,98781,8328,65,398436,288824,17665,179512,293109,41461,257,21792,46213,352035]

theorem envBound31416 : H12AffineFastState.Bounded env31416 := by
  intro p hp
  have h : env31416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31415_31416 : H12AffineEnvironment.transform 21 272512 env31415 = env31416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31415 == env31416) = true)

theorem identity31416 : scanCanonicalize (H12AffineFastState.compose env31416 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound31416 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21929,17,98781,8328,65,158029,5393,17665,179512,1500,41461,257,21792,46213,74250]

theorem envBound31417 : H12AffineFastState.Bounded env31417 := by
  intro p hp
  have h : env31417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31416_31417 : H12AffineEnvironment.transform 17 32041 env31416 = env31417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env31416 == env31417) = true)

theorem identity31417 : scanCanonicalize (H12AffineFastState.compose env31417 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31417 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4160,21929,17,41430,8328,65,158029,5393,17665,179512,1500,41461,257,21792,46213,513]

theorem envBound31418 : H12AffineFastState.Bounded env31418 := by
  intro p hp
  have h : env31418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31417_31418 : H12AffineEnvironment.transform 15 8203 env31417 = env31418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31417 == env31418) = true)

theorem identity31418 : scanCanonicalize (H12AffineFastState.compose env31418 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound31418 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,131072,32041,1025,29708,4160,21929,17,21979,8328,65,158029,5393,17665,149813,1500,22008,257,21792,16520,513]

theorem envBound31419 : H12AffineFastState.Bounded env31419 := by
  intro p hp
  have h : env31419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31418_31419 : H12AffineEnvironment.transform 14 29709 env31418 = env31419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env31418 == env31419) = true)

def env31420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8541,8203,131072,10361,1025,8540,4160,249,17,139,8328,65,146461,5393,4177,138341,1500,168,257,112,5592,513]

theorem envBound31420 : H12AffineFastState.Bounded env31420 := by
  intro p hp
  have h : env31420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31419_31420 : H12AffineEnvironment.transform 13 5456 env31419 = env31420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env31419 == env31420) = true)

theorem identity31420 : scanCanonicalize (H12AffineFastState.compose env31420 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31420 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,8203,131072,10361,1025,8540,4160,113,17,3,8192,65,146461,5393,4177,138341,1364,32,257,112,5456,513]

theorem envBound31421 : H12AffineFastState.Bounded env31421 := by
  intro p hp
  have h : env31421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31420_31421 : H12AffineEnvironment.transform 6 8 env31420 = env31421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31420 == env31421) = true)

theorem identity31421 : scanCanonicalize (H12AffineFastState.compose env31421 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound31421 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,8203,5173,10361,1025,8540,4160,113,17,3,8192,65,10280,5393,4177,2128,1364,32,257,112,5456,513]

theorem envBound31422 : H12AffineFastState.Bounded env31422 := by
  intro p hp
  have h : env31422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31421_31422 : H12AffineEnvironment.transform 16 5173 env31421 = env31422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env31421 == env31422) = true)

theorem identity31422 : scanCanonicalize (H12AffineFastState.compose env31422 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31422 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env31423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,81,263,5173,2421,1025,80,4160,113,17,3,268,65,2340,5393,4177,2128,1364,32,257,112,5456,513]

theorem envBound31423 : H12AffineFastState.Bounded env31423 := by
  intro p hp
  have h : env31423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31422_31423 : H12AffineEnvironment.transform 12 268 env31422 = env31423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31422 == env31423) = true)

theorem identity31423 : scanCanonicalize (H12AffineFastState.compose env31423 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound31423 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env31424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,4096,268,5456,81,263,5173,1,1025,80,4160,113,17,3,268,65,80,5393,4177,292,1364,32,257,112,5456,513]

theorem envBound31424 : H12AffineFastState.Bounded env31424 := by
  intro p hp
  have h : env31424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31423_31424 : H12AffineEnvironment.transform 10 372 env31423 = env31424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env31423 == env31424) = true)

theorem identity31424 : scanCanonicalize (H12AffineFastState.compose env31424 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31424 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env31425 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,4096,120,5156,81,115,5173,1,1025,80,4160,113,17,3,120,65,80,5221,4177,80,1056,32,117,112,5156,513]

theorem envBound31425 : H12AffineFastState.Bounded env31425 := by
  intro p hp
  have h : env31425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31424_31425 : H12AffineEnvironment.transform 7 116 env31424 = env31425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31424 == env31425) = true)

theorem identity31425 : scanCanonicalize (H12AffineFastState.compose env31425 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound31425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31426 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,80,120,1140,81,115,1125,1,1025,80,16,113,17,3,120,65,80,1077,1,80,1056,32,117,112,1140,513]

theorem envBound31426 : H12AffineFastState.Bounded env31426 := by
  intro p hp
  have h : env31426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31425_31426 : H12AffineEnvironment.transform 11 80 env31425 = env31426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env31425 == env31426) = true)

theorem identity31426 : scanCanonicalize (H12AffineFastState.compose env31426 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound31426 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31427 : List Nat := [2,4,8,16,32,64,8,116,512,84,0,80,120,32,81,115,49,1,85,80,16,113,17,3,120,65,80,97,1,80,116,32,117,112,32,513]

theorem envBound31427 : H12AffineFastState.Bounded env31427 := by
  intro p hp
  have h : env31427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31426_31427 : H12AffineEnvironment.transform 9 84 env31426 = env31427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env31426 == env31427) = true)

theorem identity31427 : scanCanonicalize (H12AffineFastState.compose env31427 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31427 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31428 : List Nat := [2,4,8,16,32,16,8,36,512,4,0,0,40,32,1,35,49,1,5,0,16,33,17,3,40,17,0,49,1,0,36,32,37,32,32,513]

theorem envBound31428 : H12AffineFastState.Bounded env31428 := by
  intro p hp
  have h : env31428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31427_31428 : H12AffineEnvironment.transform 5 16 env31427 = env31428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31427 == env31428) = true)

theorem identity31428 : scanCanonicalize (H12AffineFastState.compose env31428 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound31428 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31429 : List Nat := [2,4,8,16,32,16,8,36,37,4,0,0,40,32,1,35,49,1,5,0,16,33,17,3,40,17,0,49,1,0,36,32,37,32,32,36]

theorem envBound31429 : H12AffineFastState.Bounded env31429 := by
  intro p hp
  have h : env31429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31428_31429 : H12AffineEnvironment.transform 8 37 env31428 = env31429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env31428 == env31429) = true)

theorem identity31429 : scanCanonicalize (H12AffineFastState.compose env31429 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31429 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31430 : List Nat := [2,4,8,16,10,16,8,14,15,4,0,0,2,10,1,9,27,1,5,0,16,11,17,3,2,17,0,27,1,0,14,10,15,10,10,14]

theorem envBound31430 : H12AffineFastState.Bounded env31430 := by
  intro p hp
  have h : env31430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31429_31430 : H12AffineEnvironment.transform 4 10 env31429 = env31430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31429 == env31430) = true)

theorem identity31430 : scanCanonicalize (H12AffineFastState.compose env31430 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31430 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31431 : List Nat := [2,4,2,16,0,16,2,4,5,4,0,0,2,0,1,3,17,1,5,0,16,1,17,3,2,17,0,17,1,0,4,0,5,0,0,4]

theorem envBound31431 : H12AffineFastState.Bounded env31431 := by
  intro p hp
  have h : env31431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31430_31431 : H12AffineEnvironment.transform 2 2 env31430 = env31431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31430 == env31431) = true)

theorem identity31431 : scanCanonicalize (H12AffineFastState.compose env31431 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31431 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env31432 : List Nat := [2,4,2,1,0,1,2,4,5,4,0,0,2,0,1,3,0,1,5,0,1,1,0,3,2,0,0,0,1,0,4,0,5,0,0,4]

theorem envBound31432 : H12AffineFastState.Bounded env31432 := by
  intro p hp
  have h : env31432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31431_31432 : H12AffineEnvironment.transform 3 1 env31431 = env31432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31431 == env31432) = true)

theorem identity31432 : scanCanonicalize (H12AffineFastState.compose env31432 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31433 : List Nat := [1,4,1,1,0,1,1,4,5,4,0,0,1,0,1,0,0,1,5,0,1,1,0,0,1,0,0,0,1,0,4,0,5,0,0,4]

theorem envBound31433 : H12AffineFastState.Bounded env31433 := by
  intro p hp
  have h : env31433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31432_31433 : H12AffineEnvironment.transform 0 1 env31432 = env31433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31432 == env31433) = true)

def env31434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8540,8203,131072,10360,1025,8541,4160,248,17,138,8328,65,146460,5393,4176,138340,1500,169,257,113,5593,513]

theorem envBound31434 : H12AffineFastState.Bounded env31434 := by
  intro p hp
  have h : env31434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31419_31434 : H12AffineEnvironment.transform 13 5457 env31419 = env31434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31419 == env31434) = true)

theorem identity31434 : scanCanonicalize (H12AffineFastState.compose env31434 (packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound31434 : packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS < 2^1333 := by decide +kernel

def env31435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8540,8203,13388,10360,1025,8541,4160,248,17,138,8328,65,2128,5393,4176,10280,1500,169,257,113,5593,513]

theorem envBound31435 : H12AffineFastState.Bounded env31435 := by
  intro p hp
  have h : env31435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31434_31435 : H12AffineEnvironment.transform 16 13388 env31434 = env31435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env31434 == env31435) = true)

theorem identity31435 : scanCanonicalize (H12AffineFastState.compose env31435 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31435 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env31436 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,5236,8313,8203,13388,10360,1025,8312,4160,248,17,138,8328,65,2128,5172,4176,10280,1273,169,36,113,5372,513]

theorem envBound31436 : H12AffineFastState.Bounded env31436 := by
  intro p hp
  have h : env31436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31435_31436 : H12AffineEnvironment.transform 7 37 env31435 = env31436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31435 == env31436) = true)

theorem identity31436 : scanCanonicalize (H12AffineFastState.compose env31436 (packedSelected [0,1,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound31436 : packedSelected [0,1,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env31437 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,1220,5236,1213,1231,4232,3260,1025,1212,4160,248,17,138,1100,65,2128,5172,4176,3308,1273,169,36,113,5372,513]

theorem envBound31437 : H12AffineFastState.Bounded env31437 := by
  intro p hp
  have h : env31437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31436_31437 : H12AffineEnvironment.transform 12 1220 env31436 = env31437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env31436 == env31437) = true)

theorem identity31437 : scanCanonicalize (H12AffineFastState.compose env31437 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound31437 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env31438 : List Nat := [2,4,8,16,32,64,128,37,512,100,2048,4096,160,4112,217,171,4232,2264,101,216,4160,248,17,138,40,65,2128,4176,4176,2184,157,169,36,113,4248,513]

theorem envBound31438 : H12AffineFastState.Bounded env31438 := by
  intro p hp
  have h : env31438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31437_31438 : H12AffineEnvironment.transform 9 100 env31437 = env31438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env31437 == env31438) = true)

theorem identity31438 : scanCanonicalize (H12AffineFastState.compose env31438 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound31438 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31439 : List Nat := [2,4,8,16,32,64,88,37,512,100,2048,4096,120,4112,1,115,4176,2048,101,0,4160,32,17,82,40,65,2128,4176,4176,2128,69,113,36,113,4160,513]

theorem envBound31439 : H12AffineFastState.Bounded env31439 := by
  intro p hp
  have h : env31439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31438_31439 : H12AffineEnvironment.transform 6 88 env31438 = env31439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env31438 == env31439) = true)

theorem identity31439 : scanCanonicalize (H12AffineFastState.compose env31439 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31439 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env31440 : List Nat := [2,4,8,16,32,64,88,37,512,100,0,4096,120,4112,1,115,4176,0,101,0,4160,32,17,82,40,65,80,4176,4176,80,69,113,36,113,4160,513]

theorem envBound31440 : H12AffineFastState.Bounded env31440 := by
  intro p hp
  have h : env31440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31439_31440 : H12AffineEnvironment.transform 10 0 env31439 = env31440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31439 == env31440) = true)

theorem identity31440 : scanCanonicalize (H12AffineFastState.compose env31440 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound31440 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env31441 : List Nat := [2,4,8,16,32,64,88,37,512,100,0,16,120,0,1,115,64,0,101,0,80,32,17,82,40,65,80,64,64,80,69,113,36,113,80,513]

theorem envBound31441 : H12AffineFastState.Bounded env31441 := by
  intro p hp
  have h : env31441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31440_31441 : H12AffineEnvironment.transform 11 16 env31440 = env31441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31440 == env31441) = true)

theorem identity31441 : scanCanonicalize (H12AffineFastState.compose env31441 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31441 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env31442 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,40,0,1,35,16,0,53,0,0,32,17,2,40,17,0,16,16,0,21,33,36,33,0,513]

theorem envBound31442 : H12AffineFastState.Bounded env31442 := by
  intro p hp
  have h : env31442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31441_31442 : H12AffineEnvironment.transform 5 16 env31441 = env31442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31441 == env31442) = true)

theorem identity31442 : scanCanonicalize (H12AffineFastState.compose env31442 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31442 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31443 : List Nat := [2,4,8,16,0,16,8,5,512,20,0,16,8,0,1,3,16,0,21,0,0,0,17,2,8,17,0,16,16,0,21,1,4,1,0,513]

theorem envBound31443 : H12AffineFastState.Bounded env31443 := by
  intro p hp
  have h : env31443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31442_31443 : H12AffineEnvironment.transform 4 0 env31442 = env31443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31442 == env31443) = true)

theorem identity31443 : scanCanonicalize (H12AffineFastState.compose env31443 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31443 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31444 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,16,8,0,1,3,16,0,21,0,0,0,17,2,8,17,0,16,16,0,21,1,4,1,0,1]

theorem envBound31444 : H12AffineFastState.Bounded env31444 := by
  intro p hp
  have h : env31444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31443_31444 : H12AffineEnvironment.transform 8 0 env31443 = env31444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31443 == env31444) = true)

def env31445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294200,98781,8328,65,398437,288824,17665,179512,293109,41460,257,21792,46213,352035]

theorem envBound31445 : H12AffineFastState.Bounded env31445 := by
  intro p hp
  have h : env31445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31415_31445 : H12AffineEnvironment.transform 21 272513 env31415 = env31445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31415 == env31445) = true)

def env31446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294200,98645,8192,65,398437,288824,17665,179512,292989,41340,257,21792,46093,352035]

theorem envBound31446 : H12AffineFastState.Bounded env31446 := by
  intro p hp
  have h : env31446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31445_31446 : H12AffineEnvironment.transform 6 8 env31445 = env31446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31445 == env31446) = true)

def env31447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,276585,272393,272440,98645,8192,65,398437,277816,4097,179512,273789,41340,257,32,46093,330275]

theorem envBound31447 : H12AffineFastState.Bounded env31447 := by
  intro p hp
  have h : env31447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31446_31447 : H12AffineEnvironment.transform 13 5376 env31446 = env31447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31446 == env31447) = true)

theorem identity31447 : scanCanonicalize (H12AffineFastState.compose env31447 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31447 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1025,32769,276585,272393,272440,41310,8192,65,398437,277816,4097,179512,273789,41340,257,32,46093,272936]

theorem envBound31448 : H12AffineFastState.Bounded env31448 := by
  intro p hp
  have h : env31448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31447_31448 : H12AffineEnvironment.transform 15 8203 env31447 = env31448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31447 == env31448) = true)

theorem identity31448 : scanCanonicalize (H12AffineFastState.compose env31448 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31448 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env31449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,262,131072,262144,1025,32769,268644,264452,264501,32851,269,65,398437,269365,4097,171061,265328,32881,257,32,38144,264997]

theorem envBound31449 : H12AffineFastState.Bounded env31449 := by
  intro p hp
  have h : env31449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31448_31449 : H12AffineEnvironment.transform 12 269 env31448 = env31449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31448 == env31449) = true)

theorem identity31449 : scanCanonicalize (H12AffineFastState.compose env31449 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 38208) := by decide +kernel

theorem selectedBound31449 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env31450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,262,38208,262144,1025,32769,268644,264452,264501,32851,269,65,295205,269365,4097,2421,265328,32881,257,32,38144,264997]

theorem envBound31450 : H12AffineFastState.Bounded env31450 := by
  intro p hp
  have h : env31450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31449_31450 : H12AffineEnvironment.transform 16 38208 env31449 = env31450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38208 env31449 == env31450) = true)

theorem identity31450 : scanCanonicalize (H12AffineFastState.compose env31450 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound31450 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,262,5393,262144,1025,80,268644,264452,264501,2,269,65,262516,269365,4097,2421,265328,32,257,32,5457,264997]

theorem envBound31451 : H12AffineFastState.Bounded env31451 := by
  intro p hp
  have h : env31451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31450_31451 : H12AffineEnvironment.transform 14 81 env31450 = env31451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env31450 == env31451) = true)

theorem identity31451 : scanCanonicalize (H12AffineFastState.compose env31451 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31451 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,262,5393,4112,1025,80,2420,6420,6437,2,269,65,4452,3109,4097,2421,7264,32,257,32,5457,6965]

theorem envBound31452 : H12AffineFastState.Bounded env31452 := by
  intro p hp
  have h : env31452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31451_31452 : H12AffineEnvironment.transform 17 4112 env31451 = env31452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env31451 == env31452) = true)

theorem identity31452 : scanCanonicalize (H12AffineFastState.compose env31452 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2672) := by decide +kernel

theorem selectedBound31452 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env31453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2672,269,3952,81,262,3937,2656,1025,80,2420,868,853,2,269,65,2836,3109,2673,2421,1552,32,257,32,3873,325]

theorem envBound31453 : H12AffineFastState.Bounded env31453 := by
  intro p hp
  have h : env31453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31452_31453 : H12AffineEnvironment.transform 11 2672 env31452 = env31453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2672 env31452 == env31453) = true)

theorem identity31453 : scanCanonicalize (H12AffineFastState.compose env31453 (packedSelected [0,2,3,5,6,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound31453 : packedSelected [0,2,3,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env31454 : List Nat := [2,4,8,16,32,64,8,256,64,1024,2048,2096,269,3376,81,262,3361,2080,1025,80,2420,292,277,2,269,65,2388,3109,2097,2421,1104,32,257,32,3425,325]

theorem envBound31454 : H12AffineFastState.Bounded env31454 := by
  intro p hp
  have h : env31454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31453_31454 : H12AffineEnvironment.transform 8 64 env31453 = env31454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env31453 == env31454) = true)

theorem identity31454 : scanCanonicalize (H12AffineFastState.compose env31454 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound31454 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env31455 : List Nat := [2,4,8,16,32,64,8,85,64,1024,2048,2096,88,3173,81,83,3188,2080,1025,80,2081,113,64,2,88,65,2049,3109,2097,2080,1104,32,84,32,3124,16]

theorem envBound31455 : H12AffineFastState.Bounded env31455 := by
  intro p hp
  have h : env31455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31454_31455 : H12AffineEnvironment.transform 7 85 env31454 = env31455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env31454 == env31455) = true)

theorem identity31455 : scanCanonicalize (H12AffineFastState.compose env31455 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1109) := by decide +kernel

theorem selectedBound31455 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env31456 : List Nat := [2,4,8,16,32,64,8,85,64,1024,1109,1125,88,48,81,83,33,1141,1025,80,1140,113,64,2,88,65,1108,112,1124,1141,1104,32,84,32,97,16]

theorem envBound31456 : H12AffineFastState.Bounded env31456 := by
  intro p hp
  have h : env31456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31455_31456 : H12AffineEnvironment.transform 10 1109 env31455 = env31456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1109 env31455 == env31456) = true)

theorem identity31456 : scanCanonicalize (H12AffineFastState.compose env31456 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound31456 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env31457 : List Nat := [2,4,8,16,32,64,8,85,64,117,32,16,88,48,81,83,33,0,116,80,1,113,64,2,88,65,33,112,17,0,37,32,84,32,97,16]

theorem envBound31457 : H12AffineFastState.Bounded env31457 := by
  intro p hp
  have h : env31457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31456_31457 : H12AffineEnvironment.transform 9 117 env31456 = env31457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env31456 == env31457) = true)

theorem identity31457 : scanCanonicalize (H12AffineFastState.compose env31457 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound31457 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env31458 : List Nat := [2,4,8,16,32,1,8,20,1,52,32,16,25,48,16,18,33,0,53,17,1,48,1,2,25,0,33,49,17,0,37,32,21,32,32,16]

theorem envBound31458 : H12AffineFastState.Bounded env31458 := by
  intro p hp
  have h : env31458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31457_31458 : H12AffineEnvironment.transform 5 1 env31457 = env31458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31457 == env31458) = true)

theorem identity31458 : scanCanonicalize (H12AffineFastState.compose env31458 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31459 : List Nat := [2,4,8,1,32,1,8,5,1,37,32,1,8,33,1,3,33,0,36,0,1,33,1,2,8,0,33,32,0,0,37,32,4,32,32,1]

theorem envBound31459 : H12AffineFastState.Bounded env31459 := by
  intro p hp
  have h : env31459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31458_31459 : H12AffineEnvironment.transform 3 1 env31458 = env31459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31458 == env31459) = true)

theorem identity31459 : scanCanonicalize (H12AffineFastState.compose env31459 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31460 : List Nat := [2,4,8,1,0,1,8,5,1,5,0,1,8,1,1,3,1,0,4,0,1,1,1,2,8,0,1,0,0,0,5,0,4,0,0,1]

theorem envBound31460 : H12AffineFastState.Bounded env31460 := by
  intro p hp
  have h : env31460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31459_31460 : H12AffineEnvironment.transform 4 0 env31459 = env31460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31459 == env31460) = true)

theorem identity31460 : scanCanonicalize (H12AffineFastState.compose env31460 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound31460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31461 : List Nat := [2,4,7,1,0,1,7,5,1,5,0,1,7,1,1,3,1,0,4,0,1,1,1,2,7,0,1,0,0,0,5,0,4,0,0,1]

theorem envBound31461 : H12AffineFastState.Bounded env31461 := by
  intro p hp
  have h : env31461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31460_31461 : H12AffineEnvironment.transform 2 7 env31460 = env31461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env31460 == env31461) = true)

end H12CloudChart0