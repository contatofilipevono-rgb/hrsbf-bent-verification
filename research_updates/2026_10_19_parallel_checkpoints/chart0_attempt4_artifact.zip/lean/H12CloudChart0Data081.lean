import H12CloudChart0Data080

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env20444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8581,8202,131072,138340,1024,8580,4160,144612,16,83,8328,65,146460,5392,4177,10400,1500,144492,256,113,5376,513]

theorem envBound20444 : H12AffineFastState.Bounded env20444 := by
  intro p hp
  have h : env20444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20443_20444 : H12AffineEnvironment.transform 13 5457 env20443 = env20444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env20443 == env20444) = true)

theorem identity20444 : scanCanonicalize (H12AffineFastState.compose env20444 (packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20444 : packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env20445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5457,217,342,131072,138340,1024,216,4160,136632,16,83,468,65,138560,5392,4177,2556,1500,136496,256,113,5376,513]

theorem envBound20445 : H12AffineFastState.Bounded env20445 := by
  intro p hp
  have h : env20445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20444_20445 : H12AffineEnvironment.transform 12 348 env20444 = env20445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20444 == env20445) = true)

theorem identity20445 : scanCanonicalize (H12AffineFastState.compose env20445 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20445 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5457,217,342,5392,2420,1024,216,4160,168,16,83,468,65,2128,5392,4177,2556,1500,32,256,113,5376,513]

theorem envBound20446 : H12AffineFastState.Bounded env20446 := by
  intro p hp
  have h : env20446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20445_20446 : H12AffineEnvironment.transform 16 5392 env20445 = env20446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20445 == env20446) = true)

theorem identity20446 : scanCanonicalize (H12AffineFastState.compose env20446 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20446 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env20447 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,348,4160,217,342,4097,2420,273,216,4160,168,16,83,468,65,2128,4097,4177,2556,205,32,256,113,4113,513]

theorem envBound20447 : H12AffineFastState.Bounded env20447 := by
  intro p hp
  have h : env20447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20446_20447 : H12AffineEnvironment.transform 9 273 env20446 = env20447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20446 == env20447) = true)

theorem identity20447 : scanCanonicalize (H12AffineFastState.compose env20447 (packedSelected [2,3,4,5,7,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 852) := by decide +kernel

theorem selectedBound20447 : packedSelected [2,3,4,5,7,11,15] rootPS < 2^1333 := by decide +kernel

def env20448 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,852,348,788,217,342,853,2420,273,216,788,168,16,83,468,65,2128,853,773,2556,205,32,256,113,837,513]

theorem envBound20448 : H12AffineFastState.Bounded env20448 := by
  intro p hp
  have h : env20448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20447_20448 : H12AffineEnvironment.transform 11 852 env20447 = env20448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env20447 == env20448) = true)

theorem identity20448 : scanCanonicalize (H12AffineFastState.compose env20448 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20448 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env20449 : List Nat := [2,4,8,16,32,64,128,37,512,52,2048,625,121,561,217,115,624,2129,52,216,561,168,16,83,241,65,2128,624,544,2265,205,32,37,113,608,513]

theorem envBound20449 : H12AffineFastState.Bounded env20449 := by
  intro p hp
  have h : env20449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20448_20449 : H12AffineEnvironment.transform 7 37 env20448 = env20449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20448 == env20449) = true)

theorem identity20449 : scanCanonicalize (H12AffineFastState.compose env20449 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20449 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20450 : List Nat := [2,4,8,16,32,64,40,37,512,52,2048,625,121,561,113,115,624,2129,52,112,561,0,16,83,89,65,2128,624,544,2161,101,32,37,113,608,513]

theorem envBound20450 : H12AffineFastState.Bounded env20450 := by
  intro p hp
  have h : env20450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20449_20450 : H12AffineEnvironment.transform 6 40 env20449 = env20450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20449 == env20450) = true)

theorem identity20450 : scanCanonicalize (H12AffineFastState.compose env20450 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound20450 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env20451 : List Nat := [2,4,8,16,32,64,40,37,512,52,64,625,121,561,113,115,624,17,52,112,561,0,16,83,89,65,16,624,544,49,101,32,37,113,608,513]

theorem envBound20451 : H12AffineFastState.Bounded env20451 := by
  intro p hp
  have h : env20451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20450_20451 : H12AffineEnvironment.transform 10 64 env20450 = env20451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env20450 == env20451) = true)

theorem identity20451 : scanCanonicalize (H12AffineFastState.compose env20451 (packedSelected [4,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20451 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env20452 : List Nat := [2,4,8,16,32,48,40,37,512,52,48,513,9,561,1,3,512,17,52,0,561,0,16,35,41,49,16,512,544,49,21,32,37,1,528,513]

theorem envBound20452 : H12AffineFastState.Bounded env20452 := by
  intro p hp
  have h : env20452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20451_20452 : H12AffineEnvironment.transform 5 48 env20451 = env20452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20451 == env20452) = true)

theorem identity20452 : scanCanonicalize (H12AffineFastState.compose env20452 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20452 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20453 : List Nat := [2,4,8,16,0,16,8,5,512,20,16,513,9,529,1,3,512,17,20,0,529,0,16,3,9,17,16,512,512,17,21,0,5,1,528,513]

theorem envBound20453 : H12AffineFastState.Bounded env20453 := by
  intro p hp
  have h : env20453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20452_20453 : H12AffineEnvironment.transform 4 0 env20452 = env20453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20452 == env20453) = true)

theorem identity20453 : scanCanonicalize (H12AffineFastState.compose env20453 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20454 : List Nat := [2,0,8,16,0,16,8,1,512,16,16,513,9,529,1,3,512,17,16,0,529,0,16,3,9,17,16,512,512,17,17,0,1,1,528,513]

theorem envBound20454 : H12AffineFastState.Bounded env20454 := by
  intro p hp
  have h : env20454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20453_20454 : H12AffineEnvironment.transform 1 0 env20453 = env20454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20453 == env20454) = true)

theorem identity20454 : scanCanonicalize (H12AffineFastState.compose env20454 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20455 : List Nat := [1,0,8,16,0,16,8,1,512,16,16,513,9,529,1,0,512,17,16,0,529,0,16,0,9,17,16,512,512,17,17,0,1,1,528,513]

theorem envBound20455 : H12AffineFastState.Bounded env20455 := by
  intro p hp
  have h : env20455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20454_20455 : H12AffineEnvironment.transform 0 1 env20454 = env20455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20454 == env20455) = true)

theorem identity20455 : scanCanonicalize (H12AffineFastState.compose env20455 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound20455 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20456 : List Nat := [1,0,8,16,0,16,8,1,24,16,16,25,9,9,1,0,24,17,16,0,9,0,16,0,9,17,16,24,24,17,17,0,1,1,8,25]

theorem envBound20456 : H12AffineFastState.Bounded env20456 := by
  intro p hp
  have h : env20456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20455_20456 : H12AffineEnvironment.transform 8 24 env20455 = env20456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env20455 == env20456) = true)

theorem identity20456 : scanCanonicalize (H12AffineFastState.compose env20456 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound20456 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20457 : List Nat := [1,0,8,9,0,9,8,1,1,9,9,0,9,9,1,0,1,8,9,0,9,0,9,0,9,8,9,1,1,8,8,0,1,1,8,0]

theorem envBound20457 : H12AffineFastState.Bounded env20457 := by
  intro p hp
  have h : env20457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20456_20457 : H12AffineEnvironment.transform 3 9 env20456 = env20457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env20456 == env20457) = true)

def env20458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212078,1024,29909,4160,144613,17,95496,8328,65,215367,5392,17665,67755,1501,144493,256,21793,16464,74250]

theorem envBound20458 : H12AffineFastState.Bounded env20458 := by
  intro p hp
  have h : env20458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20441_20458 : H12AffineEnvironment.transform 21 144613 env20441 = env20458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env20441 == env20458) = true)

def env20459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212078,1024,8661,4160,144613,17,73736,8328,65,203847,5392,4097,67755,1501,144493,256,33,5456,74250]

theorem envBound20459 : H12AffineFastState.Bounded env20459 := by
  intro p hp
  have h : env20459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20458_20459 : H12AffineEnvironment.transform 13 5376 env20458 = env20459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20458 == env20459) = true)

theorem identity20459 : scanCanonicalize (H12AffineFastState.compose env20459 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20459 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8322,131072,138476,1024,8661,4160,144613,17,138,8328,65,146629,5392,4097,10281,1501,144493,256,33,5456,648]

theorem envBound20460 : H12AffineFastState.Bounded env20460 := by
  intro p hp
  have h : env20460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20459_20460 : H12AffineEnvironment.transform 15 8322 env20459 = env20460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20459 == env20460) = true)

theorem identity20460 : scanCanonicalize (H12AffineFastState.compose env20460 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20460 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env20461 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,5292,8312,8322,131072,138476,1024,8313,4160,144613,17,138,8328,65,146629,5308,4097,10281,1137,144493,172,33,5372,648]

theorem envBound20461 : H12AffineFastState.Bounded env20461 := by
  intro p hp
  have h : env20461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20460_20461 : H12AffineEnvironment.transform 7 172 env20460 = env20461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20460 == env20461) = true)

theorem identity20461 : scanCanonicalize (H12AffineFastState.compose env20461 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound20461 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env20462 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,5292,8312,8322,13461,10361,1024,8313,4160,112,17,138,8328,65,2128,5308,4097,10281,1137,248,172,33,5372,648]

theorem envBound20462 : H12AffineFastState.Bounded env20462 := by
  intro p hp
  have h : env20462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20461_20462 : H12AffineEnvironment.transform 16 13461 env20461 = env20462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env20461 == env20462) = true)

theorem identity20462 : scanCanonicalize (H12AffineFastState.compose env20462 (packedSelected [0,4,6,7,9,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20462 : packedSelected [0,4,6,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env20463 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,8192,5236,8312,8282,13389,10361,1024,8313,4160,112,17,82,8272,65,2128,5220,4097,10281,1137,32,116,33,5156,592]

theorem envBound20463 : H12AffineFastState.Bounded env20463 := by
  intro p hp
  have h : env20463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20462_20463 : H12AffineEnvironment.transform 6 88 env20462 = env20463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20462 == env20463) = true)

theorem identity20463 : scanCanonicalize (H12AffineFastState.compose env20463 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound20463 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env20464 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,1053,5236,1125,1095,4176,3172,1024,1124,4160,112,17,82,1101,65,2128,5220,4097,3124,1137,32,116,33,5156,592]

theorem envBound20464 : H12AffineFastState.Bounded env20464 := by
  intro p hp
  have h : env20464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20463_20464 : H12AffineEnvironment.transform 12 1053 env20463 = env20464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env20463 == env20464) = true)

theorem identity20464 : scanCanonicalize (H12AffineFastState.compose env20464 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20464 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20465 : List Nat := [2,4,8,16,32,64,88,116,512,52,2048,4096,41,4160,81,115,4176,2128,52,80,4160,112,17,82,121,65,2128,4176,4097,2048,69,32,116,33,4112,592]

theorem envBound20465 : H12AffineFastState.Bounded env20465 := by
  intro p hp
  have h : env20465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20464_20465 : H12AffineEnvironment.transform 9 52 env20464 = env20465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20464 == env20465) = true)

theorem identity20465 : scanCanonicalize (H12AffineFastState.compose env20465 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound20465 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20466 : List Nat := [2,4,8,16,32,64,88,116,512,52,2048,2096,41,2160,81,115,2144,2128,52,80,2160,112,17,82,121,65,2128,2144,2097,2048,69,32,116,33,2080,592]

theorem envBound20466 : H12AffineFastState.Bounded env20466 := by
  intro p hp
  have h : env20466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20465_20466 : H12AffineEnvironment.transform 11 2096 env20465 = env20466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env20465 == env20466) = true)

theorem identity20466 : scanCanonicalize (H12AffineFastState.compose env20466 (packedSelected [1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 79) := by decide +kernel

theorem selectedBound20466 : packedSelected [1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env20467 : List Nat := [2,4,8,16,32,64,88,116,512,52,79,127,41,63,81,115,47,31,52,80,63,112,17,82,121,65,31,47,126,79,69,32,116,33,111,592]

theorem envBound20467 : H12AffineFastState.Bounded env20467 := by
  intro p hp
  have h : env20467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20466_20467 : H12AffineEnvironment.transform 10 79 env20466 = env20467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 79 env20466 == env20467) = true)

theorem identity20467 : scanCanonicalize (H12AffineFastState.compose env20467 (packedSelected [3,4] rootPS)) = affineNative (2^(5+1) ^^^ 56) := by decide +kernel

theorem selectedBound20467 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env20468 : List Nat := [2,4,8,16,32,56,32,12,512,52,55,7,41,63,41,11,47,31,52,40,63,8,17,42,1,57,31,47,6,55,61,32,12,33,23,552]

theorem envBound20468 : H12AffineFastState.Bounded env20468 := by
  intro p hp
  have h : env20468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20467_20468 : H12AffineEnvironment.transform 5 56 env20467 = env20468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 56 env20467 == env20468) = true)

def env20469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212078,1024,8660,4160,144613,17,73737,8328,65,203846,5392,4096,67755,1501,144493,256,32,5457,74250]

theorem envBound20469 : H12AffineFastState.Bounded env20469 := by
  intro p hp
  have h : env20469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20458_20469 : H12AffineEnvironment.transform 13 5377 env20458 = env20469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20458 == env20469) = true)

theorem identity20469 : scanCanonicalize (H12AffineFastState.compose env20469 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20469 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,131072,138341,1024,8660,4160,144613,17,2,8328,65,146509,5392,4096,10400,1501,144493,256,32,5457,513]

theorem envBound20470 : H12AffineFastState.Bounded env20470 := by
  intro p hp
  have h : env20470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20469_20470 : H12AffineEnvironment.transform 15 8203 env20469 = env20470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20469 == env20470) = true)

theorem identity20470 : scanCanonicalize (H12AffineFastState.compose env20470 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound20470 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13461,10480,1024,8660,4160,112,17,2,8328,65,2264,5392,4096,10400,1501,248,256,32,5457,513]

theorem envBound20471 : H12AffineFastState.Bounded env20471 := by
  intro p hp
  have h : env20471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20470_20471 : H12AffineEnvironment.transform 16 13461 env20470 = env20471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env20470 == env20471) = true)

theorem identity20471 : scanCanonicalize (H12AffineFastState.compose env20471 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound20471 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5377,80,398,5392,2421,1024,81,4160,112,17,2,269,65,2264,5392,4096,2341,1501,248,256,32,5457,513]

theorem envBound20472 : H12AffineFastState.Bounded env20472 := by
  intro p hp
  have h : env20472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20471_20472 : H12AffineEnvironment.transform 12 389 env20471 = env20472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env20471 == env20472) = true)

theorem identity20472 : scanCanonicalize (H12AffineFastState.compose env20472 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound20472 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env20473 : List Nat := [2,4,8,16,32,64,128,256,512,116,2048,4096,389,4469,80,398,4452,2421,116,81,4160,112,17,2,269,65,2264,4452,4096,2341,425,248,256,32,4389,513]

theorem envBound20473 : H12AffineFastState.Bounded env20473 := by
  intro p hp
  have h : env20473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20472_20473 : H12AffineEnvironment.transform 9 116 env20472 = env20473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env20472 == env20473) = true)

theorem identity20473 : scanCanonicalize (H12AffineFastState.compose env20473 (packedSelected [0,3,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound20473 : packedSelected [0,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env20474 : List Nat := [2,4,8,16,32,64,128,256,512,116,665,4096,389,4469,80,398,4452,1004,116,81,4160,112,17,2,269,65,577,4452,4096,956,425,248,256,32,4389,513]

theorem envBound20474 : H12AffineFastState.Bounded env20474 := by
  intro p hp
  have h : env20474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20473_20474 : H12AffineEnvironment.transform 10 665 env20473 = env20474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env20473 == env20474) = true)

theorem identity20474 : scanCanonicalize (H12AffineFastState.compose env20474 (packedSelected [1,2,3,4,7,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20474 : packedSelected [1,2,3,4,7,11,15] rootPS < 2^1333 := by decide +kernel

def env20475 : List Nat := [2,4,8,16,32,64,128,116,512,116,665,4096,241,4097,80,250,4112,664,116,81,4160,112,17,2,121,65,577,4112,4096,712,221,248,116,32,4177,513]

theorem envBound20475 : H12AffineFastState.Bounded env20475 := by
  intro p hp
  have h : env20475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20474_20475 : H12AffineEnvironment.transform 7 116 env20474 = env20475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20474 == env20475) = true)

theorem identity20475 : scanCanonicalize (H12AffineFastState.compose env20475 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound20475 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20476 : List Nat := [2,4,8,16,32,64,24,116,512,116,513,4096,105,4097,80,98,4112,512,116,81,4160,112,17,2,121,65,577,4112,4096,592,69,96,116,32,4177,513]

theorem envBound20476 : H12AffineFastState.Bounded env20476 := by
  intro p hp
  have h : env20476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20475_20476 : H12AffineEnvironment.transform 6 24 env20475 = env20476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env20475 == env20476) = true)

theorem identity20476 : scanCanonicalize (H12AffineFastState.compose env20476 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound20476 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env20477 : List Nat := [2,4,8,16,32,0,24,52,512,52,513,4096,41,4097,16,34,4112,512,52,17,4096,48,17,2,57,1,513,4112,4096,528,5,32,52,32,4113,513]

theorem envBound20477 : H12AffineFastState.Bounded env20477 := by
  intro p hp
  have h : env20477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20476_20477 : H12AffineEnvironment.transform 5 0 env20476 = env20477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env20476 == env20477) = true)

theorem identity20477 : scanCanonicalize (H12AffineFastState.compose env20477 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20478 : List Nat := [2,4,8,0,32,0,8,36,512,36,513,4096,41,4097,0,34,4096,512,36,1,4096,32,1,2,41,1,513,4096,4096,512,5,32,36,32,4097,513]

theorem envBound20478 : H12AffineFastState.Bounded env20478 := by
  intro p hp
  have h : env20478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20477_20478 : H12AffineEnvironment.transform 3 0 env20477 = env20478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20477 == env20478) = true)

theorem identity20478 : scanCanonicalize (H12AffineFastState.compose env20478 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20478 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20479 : List Nat := [2,4,8,0,32,0,8,36,0,36,1,4096,41,4097,0,34,4096,0,36,1,4096,32,1,2,41,1,1,4096,4096,0,5,32,36,32,4097,1]

theorem envBound20479 : H12AffineFastState.Bounded env20479 := by
  intro p hp
  have h : env20479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20478_20479 : H12AffineEnvironment.transform 8 0 env20478 = env20479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20478 == env20479) = true)

theorem identity20479 : scanCanonicalize (H12AffineFastState.compose env20479 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20480 : List Nat := [2,4,8,0,10,0,8,14,0,14,1,4096,3,4097,0,8,4096,0,14,1,4096,10,1,2,3,1,1,4096,4096,0,5,10,14,10,4097,1]

theorem envBound20480 : H12AffineFastState.Bounded env20480 := by
  intro p hp
  have h : env20480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20479_20480 : H12AffineEnvironment.transform 4 10 env20479 = env20480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20479 == env20480) = true)

def env20481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374561,98780,8328,65,215366,5392,4359473,4442267,4376045,4256860,256,4363537,4355252,4448826]

theorem envBound20481 : H12AffineFastState.Bounded env20481 := by
  intro p hp
  have h : env20481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20439_20481 : H12AffineEnvironment.transform 22 4374561 env20439 = env20481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env20439 == env20481) = true)

theorem identity20481 : scanCanonicalize (H12AffineFastState.compose env20481 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound20481 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,144613,62660,98780,8328,65,215366,5392,45524,130174,61704,180409,256,41460,16465,120543]

theorem envBound20482 : H12AffineFastState.Bounded env20482 := by
  intro p hp
  have h : env20482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20481_20482 : H12AffineEnvironment.transform 21 144613 env20481 = env20482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env20481 == env20482) = true)

def env20483 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4112,144565,62612,98700,8328,17,215318,5392,45444,130094,61704,180409,256,41380,16385,120463]

theorem envBound20483 : H12AffineFastState.Bounded env20483 := by
  intro p hp
  have h : env20483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20482_20483 : H12AffineEnvironment.transform 5 16 env20482 = env20483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20482 == env20483) = true)

theorem identity20483 : scanCanonicalize (H12AffineFastState.compose env20483 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20483 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env20484 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,43168,1024,32769,4112,87215,62612,98700,8328,17,10508,5392,45444,130094,61704,106659,256,41380,16385,120463]

theorem envBound20484 : H12AffineFastState.Bounded env20484 := by
  intro p hp
  have h : env20484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20483_20484 : H12AffineEnvironment.transform 16 90138 env20483 = env20484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20483 == env20484) = true)

theorem identity20484 : scanCanonicalize (H12AffineFastState.compose env20484 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound20484 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env20485 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,46228,43168,1024,32769,4112,32801,62612,21762,8328,17,10508,5392,45444,10400,61704,29741,256,41380,16385,513]

theorem envBound20485 : H12AffineFastState.Bounded env20485 := by
  intro p hp
  have h : env20485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20484_20485 : H12AffineEnvironment.transform 15 54414 env20484 = env20485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env20484 == env20485) = true)

theorem identity20485 : scanCanonicalize (H12AffineFastState.compose env20485 (packedSelected [1,2,4,5,6,7,8,9,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20485 : packedSelected [1,2,4,5,6,7,8,9,24,27] rootPS < 2^1333 := by decide +kernel

def env20486 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33166,46228,43168,1024,32769,4112,32801,41364,2,8328,17,10508,5392,45444,10400,41992,8493,256,41380,5377,513]

theorem envBound20486 : H12AffineFastState.Bounded env20486 := by
  intro p hp
  have h : env20486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20485_20486 : H12AffineEnvironment.transform 13 5376 env20485 = env20486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20485 == env20486) = true)

theorem identity20486 : scanCanonicalize (H12AffineFastState.compose env20486 (packedSelected [17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20486 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env20487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8461,8323,5529,2477,1024,8460,4112,8492,153,2,8328,17,10508,5392,4233,10400,1285,8493,256,169,5377,513]

theorem envBound20487 : H12AffineFastState.Bounded env20487 := by
  intro p hp
  have h : env20487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20486_20487 : H12AffineEnvironment.transform 14 8461 env20486 = env20487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env20486 == env20487) = true)

theorem identity20487 : scanCanonicalize (H12AffineFastState.compose env20487 (packedSelected [0,1,2,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 957) := by decide +kernel

theorem selectedBound20487 : packedSelected [0,1,2,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,957,8192,1725,8461,8323,1572,2477,1024,8460,941,8492,153,2,8328,17,10508,1709,820,10400,1285,8493,256,169,1724,513]

theorem envBound20488 : H12AffineFastState.Bounded env20488 := by
  intro p hp
  have h : env20488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20487_20488 : H12AffineEnvironment.transform 11 957 env20487 = env20488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 957 env20487 == env20488) = true)

theorem identity20488 : scanCanonicalize (H12AffineFastState.compose env20488 (packedSelected [5,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2964) := by decide +kernel

theorem selectedBound20488 : packedSelected [5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env20489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,957,2964,1725,2713,2839,1572,2477,1024,2712,941,2744,153,2,2844,17,664,1709,820,820,1285,2745,256,169,1724,513]

theorem envBound20489 : H12AffineFastState.Bounded env20489 := by
  intro p hp
  have h : env20489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20488_20489 : H12AffineEnvironment.transform 12 2964 env20488 = env20489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2964 env20488 == env20489) = true)

theorem identity20489 : scanCanonicalize (H12AffineFastState.compose env20489 (packedSelected [2,6,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20489 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env20490 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,821,2844,1589,2577,2839,1572,2341,1024,2576,805,2608,17,2,2844,17,528,1573,820,820,1285,2609,256,33,1588,513]

theorem envBound20490 : H12AffineFastState.Bounded env20490 := by
  intro p hp
  have h : env20490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20489_20490 : H12AffineEnvironment.transform 6 8 env20489 = env20490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20489 == env20490) = true)

theorem identity20490 : scanCanonicalize (H12AffineFastState.compose env20490 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1841) := by decide +kernel

theorem selectedBound20490 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20491 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1841,821,1069,1589,1312,1062,1572,1556,1024,1313,805,1281,17,2,1069,17,528,1573,820,820,1285,1280,256,33,1588,513]

theorem envBound20491 : H12AffineFastState.Bounded env20491 := by
  intro p hp
  have h : env20491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20490_20491 : H12AffineEnvironment.transform 10 1841 env20490 = env20491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1841 env20490 == env20491) = true)

theorem identity20491 : scanCanonicalize (H12AffineFastState.compose env20491 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20491 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20492 : List Nat := [2,4,8,0,32,0,8,256,512,1024,1825,805,1069,1573,1312,1062,1572,1540,1024,1313,805,1281,1,2,1069,1,512,1573,804,804,1285,1280,256,33,1572,513]

theorem envBound20492 : H12AffineFastState.Bounded env20492 := by
  intro p hp
  have h : env20492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20491_20492 : H12AffineEnvironment.transform 3 0 env20491 = env20492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20491 == env20492) = true)

theorem identity20492 : scanCanonicalize (H12AffineFastState.compose env20492 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound20492 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20493 : List Nat := [2,4,8,0,32,0,8,256,512,36,773,805,9,513,260,2,512,544,36,261,805,293,1,2,9,1,512,513,804,804,289,292,256,33,512,513]

theorem envBound20493 : H12AffineFastState.Bounded env20493 := by
  intro p hp
  have h : env20493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20492_20493 : H12AffineEnvironment.transform 9 36 env20492 = env20493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env20492 == env20493) = true)

theorem identity20493 : scanCanonicalize (H12AffineFastState.compose env20493 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20493 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env20494 : List Nat := [2,4,8,0,32,0,8,4,512,36,513,545,9,513,0,2,512,544,36,1,545,33,1,2,9,1,512,513,544,544,37,32,4,33,512,513]

theorem envBound20494 : H12AffineFastState.Bounded env20494 := by
  intro p hp
  have h : env20494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20493_20494 : H12AffineEnvironment.transform 7 4 env20493 = env20494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20493 == env20494) = true)

theorem identity20494 : scanCanonicalize (H12AffineFastState.compose env20494 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20494 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env20495 : List Nat := [2,4,8,0,1,0,8,4,512,5,513,512,9,513,0,2,512,513,5,1,512,0,1,2,9,1,512,513,513,513,4,1,4,0,512,513]

theorem envBound20495 : H12AffineFastState.Bounded env20495 := by
  intro p hp
  have h : env20495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20494_20495 : H12AffineEnvironment.transform 4 1 env20494 = env20495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20494 == env20495) = true)

theorem identity20495 : scanCanonicalize (H12AffineFastState.compose env20495 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20496 : List Nat := [2,4,8,0,1,0,8,4,0,5,1,0,9,1,0,2,0,1,5,1,0,0,1,2,9,1,0,1,1,1,4,1,4,0,0,1]

theorem envBound20496 : H12AffineFastState.Bounded env20496 := by
  intro p hp
  have h : env20496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20495_20496 : H12AffineEnvironment.transform 8 0 env20495 = env20496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20495 == env20496) = true)

theorem identity20496 : scanCanonicalize (H12AffineFastState.compose env20496 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20497 : List Nat := [2,4,2,0,1,0,2,4,0,5,1,0,3,1,0,2,0,1,5,1,0,0,1,2,3,1,0,1,1,1,4,1,4,0,0,1]

theorem envBound20497 : H12AffineFastState.Bounded env20497 := by
  intro p hp
  have h : env20497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20496_20497 : H12AffineEnvironment.transform 2 2 env20496 = env20497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20496 == env20497) = true)

def env20498 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4113,144564,62613,98701,8328,16,215319,5392,45445,130095,61704,180409,256,41381,16384,120462]

theorem envBound20498 : H12AffineFastState.Bounded env20498 := by
  intro p hp
  have h : env20498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20482_20498 : H12AffineEnvironment.transform 5 17 env20482 = env20498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20482 == env20498) = true)

theorem identity20498 : scanCanonicalize (H12AffineFastState.compose env20498 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound20498 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env20499 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,21647,131072,171061,1024,32769,4113,144564,62613,54530,8328,16,138648,5392,45445,43168,61704,180409,256,41381,16384,33281]

theorem envBound20499 : H12AffineFastState.Bounded env20499 := by
  intro p hp
  have h : env20499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20498_20499 : H12AffineEnvironment.transform 15 21647 env20498 = env20499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env20498 == env20499) = true)

theorem identity20499 : scanCanonicalize (H12AffineFastState.compose env20499 (packedSelected [0,1,4,7,18,19,22,23,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20499 : packedSelected [0,1,4,7,18,19,22,23,28,31] rootPS < 2^1333 := by decide +kernel

def env20500 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,398,131072,171061,1024,32769,4113,144564,41364,32771,8328,16,138648,5392,45445,43168,41993,169400,256,41381,5377,33281]

theorem envBound20500 : H12AffineFastState.Bounded env20500 := by
  intro p hp
  have h : env20500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20499_20500 : H12AffineEnvironment.transform 13 5377 env20499 = env20500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20499 == env20500) = true)

theorem identity20500 : scanCanonicalize (H12AffineFastState.compose env20500 (packedSelected [3,10,17,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20500 : packedSelected [3,10,17,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env20501 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,137,398,131072,138428,1024,136,4113,144564,8477,138,8328,16,138648,5392,12556,10281,9344,136497,256,8492,5377,648]

theorem envBound20501 : H12AffineFastState.Bounded env20501 := by
  intro p hp
  have h : env20501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20500_20501 : H12AffineEnvironment.transform 14 137 env20500 = env20501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20500 == env20501) = true)

theorem identity20501 : scanCanonicalize (H12AffineFastState.compose env20501 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20501 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20502 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,0,263,131072,138293,1024,1,4113,144445,8477,3,8193,16,138513,5392,12556,10281,9225,136497,256,8492,5377,513]

theorem envBound20502 : H12AffineFastState.Bounded env20502 := by
  intro p hp
  have h : env20502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20501_20502 : H12AffineEnvironment.transform 6 9 env20501 = env20502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20501 == env20502) = true)

theorem identity20502 : scanCanonicalize (H12AffineFastState.compose env20502 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound20502 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20503 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,0,263,13340,10281,1024,1,4113,33,8477,3,8193,16,10509,5392,12556,10281,9225,8493,256,8492,5377,513]

theorem envBound20503 : H12AffineFastState.Bounded env20503 := by
  intro p hp
  have h : env20503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20502_20503 : H12AffineEnvironment.transform 16 13340 env20502 = env20503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env20502 == env20503) = true)

theorem identity20503 : scanCanonicalize (H12AffineFastState.compose env20503 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20503 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20504 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1024,1,4113,33,16,3,268,16,2048,5392,4097,2340,1284,32,256,33,5377,513]

theorem envBound20504 : H12AffineFastState.Bounded env20504 := by
  intro p hp
  have h : env20504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20503_20504 : H12AffineEnvironment.transform 12 269 env20503 = env20504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20503 == env20504) = true)

theorem identity20504 : scanCanonicalize (H12AffineFastState.compose env20504 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound20504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20505 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,293,269,1060,0,263,1076,2340,1024,1,308,33,16,3,268,16,2048,1077,292,2340,1284,32,256,33,1060,513]

theorem envBound20505 : H12AffineFastState.Bounded env20505 := by
  intro p hp
  have h : env20505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20504_20505 : H12AffineEnvironment.transform 11 293 env20504 = env20505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env20504 == env20505) = true)

theorem identity20505 : scanCanonicalize (H12AffineFastState.compose env20505 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20505 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20506 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,293,269,1060,0,263,1076,2340,1024,1,308,33,16,3,268,16,2048,1077,292,2340,1284,32,256,33,1060,0]

theorem envBound20506 : H12AffineFastState.Bounded env20506 := by
  intro p hp
  have h : env20506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20505_20506 : H12AffineEnvironment.transform 8 1 env20505 = env20506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20505 == env20506) = true)

theorem identity20506 : scanCanonicalize (H12AffineFastState.compose env20506 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20506 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20507 : List Nat := [2,4,8,16,32,17,9,256,1,52,2048,293,269,16,0,263,0,2340,52,1,308,33,16,3,268,16,2048,1,292,2340,304,32,256,33,16,0]

theorem envBound20507 : H12AffineFastState.Bounded env20507 := by
  intro p hp
  have h : env20507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20506_20507 : H12AffineEnvironment.transform 9 52 env20506 = env20507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20506 == env20507) = true)

def env20508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,8388608,98781,8328,65,12683622,5392,8406289,8456378,8390093,4256860,256,8410416,8434837,8462874]

theorem envBound20508 : H12AffineFastState.Bounded env20508 := by
  intro p hp
  have h : env20508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20438_20508 : H12AffineEnvironment.transform 20 4161 env20438 = env20508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20438 == env20508) = true)

def env20509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374560,98781,8328,65,215366,5392,4359473,4442266,4376045,4256860,256,4363536,4355253,4448826]

theorem envBound20509 : H12AffineFastState.Bounded env20509 := by
  intro p hp
  have h : env20509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20508_20509 : H12AffineEnvironment.transform 22 4374560 env20508 = env20509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env20508 == env20509) = true)

def env20510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100522,1024,32769,4161,4194304,4227120,98781,8328,65,67926,5392,4244769,4294794,4228605,4256860,256,4248832,4207781,4301354]

theorem envBound20510 : H12AffineFastState.Bounded env20510 := by
  intro p hp
  have h : env20510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20509_20510 : H12AffineEnvironment.transform 16 16400 env20509 = env20510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20509 == env20510) = true)

theorem identity20510 : scanCanonicalize (H12AffineFastState.compose env20510 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound20510 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env20511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100522,1024,32769,4161,32937,153,98781,8328,65,67926,5392,17800,67619,1364,29941,256,21929,46092,74371]

theorem envBound20511 : H12AffineFastState.Bounded env20511 := by
  intro p hp
  have h : env20511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20510_20511 : H12AffineEnvironment.transform 21 32937 env20510 = env20511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env20510 == env20511) = true)

theorem identity20511 : scanCanonicalize (H12AffineFastState.compose env20511 (packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20511 : packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43168,1024,32769,4161,32937,153,41431,8328,65,10588,5392,17800,10281,1364,29941,256,21929,46092,649]

theorem envBound20512 : H12AffineFastState.Bounded env20512 := by
  intro p hp
  have h : env20512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20511_20512 : H12AffineEnvironment.transform 15 8202 env20511 = env20512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20511 == env20512) = true)

theorem identity20512 : scanCanonicalize (H12AffineFastState.compose env20512 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20512 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16400,2557,1024,8540,4161,8692,153,138,8328,65,10588,5392,17800,10281,1364,29941,256,21929,5457,649]

theorem envBound20513 : H12AffineFastState.Bounded env20513 := by
  intro p hp
  have h : env20513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20512_20513 : H12AffineEnvironment.transform 14 8541 env20512 = env20513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20512 == env20513) = true)

theorem identity20513 : scanCanonicalize (H12AffineFastState.compose env20513 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20513 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,2421,1024,8540,4161,8572,17,2,8192,65,10588,5392,17664,10281,1364,29821,256,21793,5457,513]

theorem envBound20514 : H12AffineFastState.Bounded env20514 := by
  intro p hp
  have h : env20514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20513_20514 : H12AffineEnvironment.transform 6 8 env20513 = env20514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20513 == env20514) = true)

theorem identity20514 : scanCanonicalize (H12AffineFastState.compose env20514 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound20514 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5156,8541,8202,5172,2421,1024,8540,4161,8572,17,2,8192,65,10588,5392,4388,10281,1364,8281,256,261,5457,513]

theorem envBound20515 : H12AffineFastState.Bounded env20515 := by
  intro p hp
  have h : env20515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20514_20515 : H12AffineEnvironment.transform 13 5156 env20514 = env20515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env20514 == env20515) = true)

theorem identity20515 : scanCanonicalize (H12AffineFastState.compose env20515 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20515 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env20516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5156,373,34,5172,2421,1024,372,4161,340,17,2,40,65,2420,5392,4388,2049,1364,113,256,261,5457,513]

theorem envBound20516 : H12AffineFastState.Bounded env20516 := by
  intro p hp
  have h : env20516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20515_20516 : H12AffineEnvironment.transform 12 40 env20515 = env20516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20515 == env20516) = true)

theorem identity20516 : scanCanonicalize (H12AffineFastState.compose env20516 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound20516 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,40,2048,373,34,2064,2421,1024,372,3173,340,17,2,40,65,2420,2356,3328,2049,1364,113,256,261,2421,513]

theorem envBound20517 : H12AffineFastState.Bounded env20517 := by
  intro p hp
  have h : env20517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20516_20517 : H12AffineEnvironment.transform 11 3108 env20516 = env20517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env20516 == env20517) = true)

theorem identity20517 : scanCanonicalize (H12AffineFastState.compose env20517 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound20517 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,40,292,373,34,308,81,1024,372,1345,340,17,2,40,65,80,16,1060,293,1364,113,256,261,81,513]

theorem envBound20518 : H12AffineFastState.Bounded env20518 := by
  intro p hp
  have h : env20518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20517_20518 : H12AffineEnvironment.transform 10 292 env20517 = env20518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env20517 == env20518) = true)

theorem identity20518 : scanCanonicalize (H12AffineFastState.compose env20518 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20518 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env20519 : List Nat := [2,4,8,16,32,64,8,256,512,53,292,309,40,292,373,34,308,81,53,372,372,340,17,2,40,65,80,16,17,293,353,113,256,261,81,513]

theorem envBound20519 : H12AffineFastState.Bounded env20519 := by
  intro p hp
  have h : env20519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20518_20519 : H12AffineEnvironment.transform 9 53 env20518 = env20519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20518 == env20519) = true)

theorem identity20519 : scanCanonicalize (H12AffineFastState.compose env20519 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20520 : List Nat := [2,4,8,16,32,64,8,117,512,53,81,64,40,81,0,34,65,81,53,1,1,33,17,2,40,65,80,16,17,80,20,113,117,112,81,513]

theorem envBound20520 : H12AffineFastState.Bounded env20520 := by
  intro p hp
  have h : env20520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20519_20520 : H12AffineEnvironment.transform 7 117 env20519 = env20520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20519 == env20520) = true)

def env20521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,100523,1024,32769,4161,4194304,4227121,98781,8328,65,67927,5392,4244768,4294795,4228604,4256860,256,4248833,4207780,4301355]

theorem envBound20521 : H12AffineFastState.Bounded env20521 := by
  intro p hp
  have h : env20521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20509_20521 : H12AffineEnvironment.transform 16 16401 env20509 = env20521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20509 == env20521) = true)

theorem identity20521 : scanCanonicalize (H12AffineFastState.compose env20521 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound20521 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env20522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,16401,10281,1024,32769,4161,4194304,4227121,8543,8328,65,43477,5392,4244768,4204553,4228604,4256860,256,4248833,4207780,4194985]

theorem envBound20522 : H12AffineFastState.Bounded env20522 := by
  intro p hp
  have h : env20522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20521_20522 : H12AffineEnvironment.transform 15 41090 env20521 = env20522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env20521 == env20522) = true)

theorem identity20522 : scanCanonicalize (H12AffineFastState.compose env20522 (packedSelected [1,3,5,8,12,16,17,20,26,31,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20522 : packedSelected [1,3,5,8,12,16,17,20,26,31,41] rootPS < 2^1333 := by decide +kernel

def env20523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1024,32769,4161,4194304,4227121,8543,8193,65,43356,5392,4244768,4204553,4228469,4256860,256,4248833,4207661,4194848]

theorem envBound20523 : H12AffineFastState.Bounded env20523 := by
  intro p hp
  have h : env20523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20522_20523 : H12AffineEnvironment.transform 6 9 env20522 = env20523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20522 == env20523) = true)

theorem identity20523 : scanCanonicalize (H12AffineFastState.compose env20523 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound20523 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1024,32769,4161,33,32784,8543,8193,65,43356,5392,50433,10280,34132,62589,256,54560,13324,513]

theorem envBound20524 : H12AffineFastState.Bounded env20524 := by
  intro p hp
  have h : env20524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20523_20524 : H12AffineEnvironment.transform 21 33 env20523 = env20524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env20523 == env20524) = true)

theorem identity20524 : scanCanonicalize (H12AffineFastState.compose env20524 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20524 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,13388,10281,1024,32769,4161,33,32784,8543,8193,65,43356,5392,45404,10280,34132,32800,256,41341,13324,513]

theorem envBound20525 : H12AffineFastState.Bounded env20525 := by
  intro p hp
  have h : env20525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20524_20525 : H12AffineEnvironment.transform 13 13405 env20524 = env20525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20524 == env20525) = true)

theorem identity20525 : scanCanonicalize (H12AffineFastState.compose env20525 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20525 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,13388,10281,1024,1,4161,33,16,8543,8193,65,10588,5392,12636,10280,1364,32,256,8573,13324,513]

theorem envBound20526 : H12AffineFastState.Bounded env20526 := by
  intro p hp
  have h : env20526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20525_20526 : H12AffineEnvironment.transform 14 0 env20525 = env20526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20525 == env20526) = true)

theorem identity20526 : scanCanonicalize (H12AffineFastState.compose env20526 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20526 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5392,2421,1024,1,4161,33,16,3,349,65,2048,5392,4096,2420,1364,32,256,33,5456,513]

theorem envBound20527 : H12AffineFastState.Bounded env20527 := by
  intro p hp
  have h : env20527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20526_20527 : H12AffineEnvironment.transform 12 348 env20526 = env20527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20526 == env20527) = true)

theorem identity20527 : scanCanonicalize (H12AffineFastState.compose env20527 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound20527 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,0,343,1141,2421,1024,1,292,33,16,3,349,65,2048,1141,357,2420,1364,32,256,33,1077,513]

theorem envBound20528 : H12AffineFastState.Bounded env20528 := by
  intro p hp
  have h : env20528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20527_20528 : H12AffineEnvironment.transform 11 357 env20527 = env20528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env20527 == env20528) = true)

theorem identity20528 : scanCanonicalize (H12AffineFastState.compose env20528 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound20528 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,357,348,1124,0,343,1141,1297,1024,1,292,33,16,3,349,65,1124,1141,357,1296,1364,32,256,33,1077,513]

theorem envBound20529 : H12AffineFastState.Bounded env20529 := by
  intro p hp
  have h : env20529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20528_20529 : H12AffineEnvironment.transform 10 1124 env20528 = env20529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env20528 == env20529) = true)

theorem identity20529 : scanCanonicalize (H12AffineFastState.compose env20529 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound20529 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20530 : List Nat := [2,4,8,16,32,64,9,256,308,1024,1124,357,348,1124,0,343,1141,1297,1024,1,292,33,16,3,349,65,1124,1141,357,1296,1364,32,256,33,1077,309]

theorem envBound20530 : H12AffineFastState.Bounded env20530 := by
  intro p hp
  have h : env20530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20529_20530 : H12AffineEnvironment.transform 8 308 env20529 = env20530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env20529 == env20530) = true)

theorem identity20530 : scanCanonicalize (H12AffineFastState.compose env20530 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound20530 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env20531 : List Nat := [2,4,8,16,32,33,9,256,308,1024,1029,260,317,1029,0,310,1044,1297,1024,1,292,33,16,3,316,32,1029,1044,260,1296,1333,32,256,33,1077,309]

theorem envBound20531 : H12AffineFastState.Bounded env20531 := by
  intro p hp
  have h : env20531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20530_20531 : H12AffineEnvironment.transform 5 33 env20530 = env20531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env20530 == env20531) = true)

theorem identity20531 : scanCanonicalize (H12AffineFastState.compose env20531 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20531 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20532 : List Nat := [2,4,8,16,0,1,9,256,276,1024,1029,260,285,1029,0,278,1044,1297,1024,1,260,1,16,3,284,0,1029,1044,260,1296,1301,0,256,1,1045,277]

theorem envBound20532 : H12AffineFastState.Bounded env20532 := by
  intro p hp
  have h : env20532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20531_20532 : H12AffineEnvironment.transform 4 0 env20531 = env20532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20531 == env20532) = true)

theorem identity20532 : scanCanonicalize (H12AffineFastState.compose env20532 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20532 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env20533 : List Nat := [2,4,8,0,0,1,9,256,260,1024,1029,260,269,1029,0,262,1028,1281,1024,1,260,1,0,3,268,0,1029,1028,260,1280,1285,0,256,1,1029,261]

theorem envBound20533 : H12AffineFastState.Bounded env20533 := by
  intro p hp
  have h : env20533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20532_20533 : H12AffineEnvironment.transform 3 0 env20532 = env20533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20532 == env20533) = true)

theorem identity20533 : scanCanonicalize (H12AffineFastState.compose env20533 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound20533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20534 : List Nat := [2,4,8,0,0,1,9,256,260,256,261,260,269,261,0,262,260,1,256,1,260,1,0,3,268,0,261,260,260,0,5,0,256,1,261,261]

theorem envBound20534 : H12AffineFastState.Bounded env20534 := by
  intro p hp
  have h : env20534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20533_20534 : H12AffineEnvironment.transform 9 256 env20533 = env20534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env20533 == env20534) = true)

theorem identity20534 : scanCanonicalize (H12AffineFastState.compose env20534 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20535 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,1,8,0,0,3,1,1,5,1,1,1,0,3,9,0,0,1,1,0,5,0,5,1,0,0]

theorem envBound20535 : H12AffineFastState.Bounded env20535 := by
  intro p hp
  have h : env20535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20534_20535 : H12AffineEnvironment.transform 7 5 env20534 = env20535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20534 == env20535) = true)

def env20536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374561,98781,8328,65,215367,5392,4359472,4442267,4376044,4256860,256,4363537,4355252,4448827]

theorem envBound20536 : H12AffineFastState.Bounded env20536 := by
  intro p hp
  have h : env20536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20508_20536 : H12AffineEnvironment.transform 22 4374561 env20508 = env20536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env20508 == env20536) = true)

theorem identity20536 : scanCanonicalize (H12AffineFastState.compose env20536 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound20536 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,180273,16,98781,8328,65,215367,5392,17665,67754,1501,144493,256,21792,46213,74250]

theorem envBound20537 : H12AffineFastState.Bounded env20537 := by
  intro p hp
  have h : env20537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20536_20537 : H12AffineEnvironment.transform 21 180273 env20536 = env20537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env20536 == env20537) = true)

def env20538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180273,16,98645,8192,65,215367,5392,17665,67618,1365,144493,256,21792,46093,74250]

theorem envBound20538 : H12AffineFastState.Bounded env20538 := by
  intro p hp
  have h : env20538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20537_20538 : H12AffineEnvironment.transform 6 8 env20537 = env20538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20537 == env20538) = true)

theorem identity20538 : scanCanonicalize (H12AffineFastState.compose env20538 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound20538 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,108926,1024,32769,4161,41341,16,98645,8192,65,75787,5392,17665,67618,1365,21793,256,21792,46093,74250]

theorem envBound20539 : H12AffineFastState.Bounded env20539 := by
  intro p hp
  have h : env20539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20538_20539 : H12AffineEnvironment.transform 16 24908 env20538 = env20539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env20538 == env20539) = true)

theorem identity20539 : scanCanonicalize (H12AffineFastState.compose env20539 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound20539 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,32768,65536,13624,108926,1024,32769,4161,41341,16,98645,8192,65,75787,5392,4469,67618,1365,341,256,340,46093,74250]

theorem envBound20540 : H12AffineFastState.Bounded env20540 := by
  intro p hp
  have h : env20540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20539_20540 : H12AffineEnvironment.transform 13 5236 env20539 = env20540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env20539 == env20540) = true)

theorem identity20540 : scanCanonicalize (H12AffineFastState.compose env20540 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound20540 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env20541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,32768,342,13624,43048,1024,32769,4161,41341,16,32771,8192,65,10589,5392,4469,2420,1365,341,256,340,46093,9052]

theorem envBound20541 : H12AffineFastState.Bounded env20541 := by
  intro p hp
  have h : env20541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20540_20541 : H12AffineEnvironment.transform 15 342 env20540 = env20541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env20540 == env20541) = true)

theorem identity20541 : scanCanonicalize (H12AffineFastState.compose env20541 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound20541 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env20542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,292,342,13624,10508,1024,293,4161,8281,16,295,8192,65,10589,5392,4469,2420,1365,341,256,340,13609,9052]

theorem envBound20542 : H12AffineFastState.Bounded env20542 := by
  intro p hp
  have h : env20542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20541_20542 : H12AffineEnvironment.transform 14 292 env20541 = env20542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env20541 == env20542) = true)

def env20543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180273,16,98644,8193,65,215367,5392,17665,67619,1364,144493,256,21792,46092,74250]

theorem envBound20543 : H12AffineFastState.Bounded env20543 := by
  intro p hp
  have h : env20543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20537_20543 : H12AffineEnvironment.transform 6 9 env20537 = env20543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20537 == env20543) = true)

theorem identity20543 : scanCanonicalize (H12AffineFastState.compose env20543 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound20543 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,67618,1024,32769,4161,32,16,98644,8193,65,100694,5392,17665,67619,1364,62588,256,21792,46092,74250]

theorem envBound20544 : H12AffineFastState.Bounded env20544 := by
  intro p hp
  have h : env20544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20543_20544 : H12AffineEnvironment.transform 16 49169 env20543 = env20544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env20543 == env20544) = true)

theorem identity20544 : scanCanonicalize (H12AffineFastState.compose env20544 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20544 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env20545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,16401,67618,1024,1,4161,32,16,65876,8193,65,67926,5392,17665,67619,1364,29820,256,21792,13324,74250]

theorem envBound20545 : H12AffineFastState.Bounded env20545 := by
  intro p hp
  have h : env20545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20544_20545 : H12AffineEnvironment.transform 14 0 env20544 = env20545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20544 == env20545) = true)

theorem identity20545 : scanCanonicalize (H12AffineFastState.compose env20545 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20545 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8202,16401,10280,1024,1,4161,32,16,8542,8193,65,10588,5392,17665,10281,1364,29820,256,21792,13324,512]

theorem envBound20546 : H12AffineFastState.Bounded env20546 := by
  intro p hp
  have h : env20546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20545_20546 : H12AffineEnvironment.transform 15 8202 env20545 = env20546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20545 == env20546) = true)

theorem identity20546 : scanCanonicalize (H12AffineFastState.compose env20546 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound20546 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1085,16384,0,1079,16401,3093,1024,1,4161,32,16,1379,1084,65,3425,5392,17665,3092,1364,20545,256,21792,4145,512]

theorem envBound20547 : H12AffineFastState.Bounded env20547 := by
  intro p hp
  have h : env20547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20546_20547 : H12AffineEnvironment.transform 12 1085 env20546 = env20547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env20546 == env20547) = true)

theorem identity20547 : scanCanonicalize (H12AffineFastState.compose env20547 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound20547 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20548 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,4096,120,16384,0,114,16401,2128,69,1,4161,32,16,294,121,65,2340,4437,16708,2129,273,20545,256,20837,4145,512]

theorem envBound20548 : H12AffineFastState.Bounded env20548 := by
  intro p hp
  have h : env20548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20547_20548 : H12AffineEnvironment.transform 9 69 env20547 = env20548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env20547 == env20548) = true)

theorem identity20548 : scanCanonicalize (H12AffineFastState.compose env20548 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 2389) := by decide +kernel

theorem selectedBound20548 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20549 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,4096,120,2389,0,114,2372,2128,69,1,4161,32,16,294,121,65,2340,4437,2065,2129,273,6420,256,6192,4145,512]

theorem envBound20549 : H12AffineFastState.Bounded env20549 := by
  intro p hp
  have h : env20549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20548_20549 : H12AffineEnvironment.transform 13 2389 env20548 = env20549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2389 env20548 == env20549) = true)

theorem identity20549 : scanCanonicalize (H12AffineFastState.compose env20549 (packedSelected [0,1,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound20549 : packedSelected [0,1,4,6,8] rootPS < 2^1333 := by decide +kernel

def env20550 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,113,120,2389,0,114,2372,2128,69,1,48,32,16,294,121,65,2340,292,2065,2129,273,2405,256,2113,64,512]

theorem envBound20550 : H12AffineFastState.Bounded env20550 := by
  intro p hp
  have h : env20550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20549_20550 : H12AffineEnvironment.transform 11 113 env20549 = env20550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env20549 == env20550) = true)

theorem identity20550 : scanCanonicalize (H12AffineFastState.compose env20550 (packedSelected [0,2,6,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound20550 : packedSelected [0,2,6,7,12] rootPS < 2^1333 := by decide +kernel

def env20551 : List Nat := [2,4,8,16,32,64,9,256,512,69,276,113,120,65,0,114,80,324,69,1,48,32,16,294,121,65,48,292,261,325,273,113,256,341,64,512]

theorem envBound20551 : H12AffineFastState.Bounded env20551 := by
  intro p hp
  have h : env20551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20550_20551 : H12AffineEnvironment.transform 10 276 env20550 = env20551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env20550 == env20551) = true)

theorem identity20551 : scanCanonicalize (H12AffineFastState.compose env20551 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20551 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20552 : List Nat := [2,4,8,1,32,64,9,256,512,69,261,96,105,65,0,99,65,324,69,1,33,32,1,294,104,65,33,292,261,325,256,96,256,324,64,512]

theorem envBound20552 : H12AffineFastState.Bounded env20552 := by
  intro p hp
  have h : env20552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20551_20552 : H12AffineEnvironment.transform 3 1 env20551 = env20552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20551 == env20552) = true)

theorem identity20552 : scanCanonicalize (H12AffineFastState.compose env20552 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound20552 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env20553 : List Nat := [2,4,8,1,32,64,9,256,96,69,261,96,105,65,0,99,65,324,69,1,33,32,1,294,104,65,33,292,261,325,256,96,256,324,64,96]

theorem envBound20553 : H12AffineFastState.Bounded env20553 := by
  intro p hp
  have h : env20553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20552_20553 : H12AffineEnvironment.transform 8 96 env20552 = env20553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env20552 == env20553) = true)

theorem identity20553 : scanCanonicalize (H12AffineFastState.compose env20553 (packedSelected [1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20553 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env20554 : List Nat := [2,4,8,1,32,64,9,36,96,69,33,96,105,65,0,99,65,96,69,1,33,32,1,2,104,65,33,0,33,97,36,96,36,96,64,96]

theorem envBound20554 : H12AffineFastState.Bounded env20554 := by
  intro p hp
  have h : env20554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20553_20554 : H12AffineEnvironment.transform 7 36 env20553 = env20554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20553 == env20554) = true)

theorem identity20554 : scanCanonicalize (H12AffineFastState.compose env20554 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound20554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20555 : List Nat := [2,4,8,1,32,32,9,36,0,37,33,0,9,33,0,3,33,0,37,1,33,32,1,2,8,33,33,0,33,1,36,0,36,0,32,0]

theorem envBound20555 : H12AffineFastState.Bounded env20555 := by
  intro p hp
  have h : env20555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20554_20555 : H12AffineEnvironment.transform 5 32 env20554 = env20555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env20554 == env20555) = true)

def env20556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784806,5393,10507600,8456378,10491277,4256861,256,8410417,8434836,10564186]

theorem envBound20556 : H12AffineFastState.Bounded env20556 := by
  intro p hp
  have h : env20556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20437_20556 : H12AffineEnvironment.transform 23 2199965 env20437 = env20556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env20437 == env20556) = true)

def env20557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,8388608,98781,8328,65,12683622,5393,8406288,8456378,8390093,4256861,256,8410417,8434836,8462874]

theorem envBound20557 : H12AffineFastState.Bounded env20557 := by
  intro p hp
  have h : env20557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20556_20557 : H12AffineEnvironment.transform 20 4160 env20556 = env20557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20556 == env20557) = true)

def env20558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374560,98781,8328,65,215366,5393,4359472,4442266,4376045,4256861,256,4363537,4355252,4448826]

theorem envBound20558 : H12AffineFastState.Bounded env20558 := by
  intro p hp
  have h : env20558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20557_20558 : H12AffineEnvironment.transform 22 4374560 env20557 = env20558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env20557 == env20558) = true)

theorem identity20558 : scanCanonicalize (H12AffineFastState.compose env20558 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254011) := by decide +kernel

theorem selectedBound20558 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,254011,73755,98781,8328,65,215366,5393,91403,10401,75222,201830,256,95530,103567,513]

theorem envBound20559 : H12AffineFastState.Bounded env20559 := by
  intro p hp
  have h : env20559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20558_20559 : H12AffineEnvironment.transform 21 254011 env20558 = env20559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254011 env20558 == env20559) = true)

def env20560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,254011,73755,98645,8192,65,215366,5393,91403,10281,75102,201830,256,95530,103431,513]

theorem envBound20560 : H12AffineFastState.Bounded env20560 := by
  intro p hp
  have h : env20560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20559_20560 : H12AffineEnvironment.transform 6 8 env20559 = env20560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20559 == env20560) = true)

theorem identity20560 : scanCanonicalize (H12AffineFastState.compose env20560 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20560 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,43048,1024,32769,4160,32801,73755,98645,8192,65,10588,5393,91403,10281,75102,29820,256,95530,103431,513]

theorem envBound20561 : H12AffineFastState.Bounded env20561 := by
  intro p hp
  have h : env20561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20560_20561 : H12AffineEnvironment.transform 16 90138 env20560 = env20561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20560 == env20561) = true)

theorem identity20561 : scanCanonicalize (H12AffineFastState.compose env20561 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound20561 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,90138,23588,1024,29709,4160,29741,73755,95577,8192,65,10588,5393,91403,10281,75102,29820,256,95530,90123,513]

theorem envBound20562 : H12AffineFastState.Bounded env20562 := by
  intro p hp
  have h : env20562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20561_20562 : H12AffineEnvironment.transform 14 29708 env20561 = env20562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env20561 == env20562) = true)

theorem identity20562 : scanCanonicalize (H12AffineFastState.compose env20562 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound20562 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20563 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,9278,17444,23588,1024,29709,4160,29741,1061,20839,8192,65,10588,5393,16693,10281,352,29820,256,20756,17461,513]

theorem envBound20563 : H12AffineFastState.Bounded env20563 := by
  intro p hp
  have h : env20563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20562_20563 : H12AffineEnvironment.transform 15 9278 env20562 = env20563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env20562 == env20563) = true)

theorem identity20563 : scanCanonicalize (H12AffineFastState.compose env20563 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20563 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env20564 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,16384,28728,8202,16400,22544,52,28729,4160,28697,17,20839,8192,65,10588,4389,16693,10281,352,28744,256,20756,16385,513]

theorem envBound20564 : H12AffineFastState.Bounded env20564 := by
  intro p hp
  have h : env20564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20563_20564 : H12AffineEnvironment.transform 9 52 env20563 = env20564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20563 == env20564) = true)

theorem identity20564 : scanCanonicalize (H12AffineFastState.compose env20564 (packedSelected [2,3,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound20564 : packedSelected [2,3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env20565 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,12392,80,8202,12408,10360,52,81,4160,113,17,8463,8192,65,10588,4389,12637,10281,352,32,256,8572,12393,513]

theorem envBound20565 : H12AffineFastState.Bounded env20565 := by
  intro p hp
  have h : env20565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20564_20565 : H12AffineEnvironment.transform 13 12392 env20564 = env20565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env20564 == env20565) = true)

theorem identity20565 : scanCanonicalize (H12AffineFastState.compose env20565 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20565 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20566 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,8192,12345,1,8202,12329,10281,52,0,4113,32,17,8463,8192,16,10509,4389,12556,10281,305,32,256,8493,12344,513]

theorem envBound20566 : H12AffineFastState.Bounded env20566 := by
  intro p hp
  have h : env20566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20565_20566 : H12AffineEnvironment.transform 5 17 env20565 = env20566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20565 == env20566) = true)

theorem identity20566 : scanCanonicalize (H12AffineFastState.compose env20566 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20566 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20567 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,17,8192,8232,1,8202,8248,10281,52,0,0,32,17,8463,8192,16,10509,308,8477,10281,305,32,256,8493,8233,513]

theorem envBound20567 : H12AffineFastState.Bounded env20567 := by
  intro p hp
  have h : env20567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20566_20567 : H12AffineEnvironment.transform 11 17 env20566 = env20567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20566 == env20567) = true)

theorem identity20567 : scanCanonicalize (H12AffineFastState.compose env20567 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound20567 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20568 : List Nat := [2,4,8,16,32,17,8,256,512,52,292,17,8192,8232,1,8202,8248,8461,52,0,0,32,17,8463,8192,16,8233,308,8477,8461,305,32,256,8493,8233,513]

theorem envBound20568 : H12AffineFastState.Bounded env20568 := by
  intro p hp
  have h : env20568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20567_20568 : H12AffineEnvironment.transform 10 292 env20567 = env20568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env20567 == env20568) = true)

def env20569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,254011,73755,98644,8193,65,215366,5393,91403,10280,75103,201830,256,95530,103430,513]

theorem envBound20569 : H12AffineFastState.Bounded env20569 := by
  intro p hp
  have h : env20569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20559_20569 : H12AffineEnvironment.transform 6 9 env20559 = env20569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20559 == env20569) = true)

theorem identity20569 : scanCanonicalize (H12AffineFastState.compose env20569 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound20569 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4160,33,73755,98644,8193,65,43356,5393,91403,10280,75103,62588,256,95530,103430,513]

theorem envBound20570 : H12AffineFastState.Bounded env20570 := by
  intro p hp
  have h : env20570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20569_20570 : H12AffineEnvironment.transform 16 122906 env20569 = env20570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env20569 == env20570) = true)

theorem identity20570 : scanCanonicalize (H12AffineFastState.compose env20570 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20570 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env20571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1024,32769,4160,33,16,41311,8193,65,43356,5393,17664,10280,1364,62588,256,21793,46093,513]

theorem envBound20571 : H12AffineFastState.Bounded env20571 := by
  intro p hp
  have h : env20571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20570_20571 : H12AffineEnvironment.transform 15 8203 env20570 = env20571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20570 == env20571) = true)

theorem identity20571 : scanCanonicalize (H12AffineFastState.compose env20571 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20571 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49169,2340,1024,32769,4160,33,16,32850,268,65,34897,5393,17664,2341,1364,54641,256,21793,38144,513]

theorem envBound20572 : H12AffineFastState.Bounded env20572 := by
  intro p hp
  have h : env20572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20571_20572 : H12AffineEnvironment.transform 12 269 env20571 = env20572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20571 == env20572) = true)

theorem identity20572 : scanCanonicalize (H12AffineFastState.compose env20572 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound20572 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,32768,262,38208,2340,1024,32769,4160,33,16,32850,268,65,34897,5393,4177,2341,1364,32800,256,112,38144,513]

theorem envBound20573 : H12AffineFastState.Bounded env20573 := by
  intro p hp
  have h : env20573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20572_20573 : H12AffineEnvironment.transform 13 5457 env20572 = env20573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env20572 == env20573) = true)

theorem identity20573 : scanCanonicalize (H12AffineFastState.compose env20573 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound20573 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,81,262,5393,2340,1024,80,4160,33,16,3,268,65,2048,5393,4177,2341,1364,113,256,112,5457,513]

theorem envBound20574 : H12AffineFastState.Bounded env20574 := by
  intro p hp
  have h : env20574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20573_20574 : H12AffineEnvironment.transform 14 81 env20573 = env20574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env20573 == env20574) = true)

theorem identity20574 : scanCanonicalize (H12AffineFastState.compose env20574 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound20574 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env20575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2096,269,3425,81,262,3361,2340,1024,80,2160,33,16,3,268,65,2048,3361,2145,2341,1364,113,256,112,3425,513]

theorem envBound20575 : H12AffineFastState.Bounded env20575 := by
  intro p hp
  have h : env20575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20574_20575 : H12AffineEnvironment.transform 11 2096 env20574 = env20575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env20574 == env20575) = true)

theorem identity20575 : scanCanonicalize (H12AffineFastState.compose env20575 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound20575 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20576 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,2096,269,2128,81,262,2064,2340,305,80,2160,33,16,3,268,65,2048,2064,2145,2341,101,113,256,112,2128,513]

theorem envBound20576 : H12AffineFastState.Bounded env20576 := by
  intro p hp
  have h : env20576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20575_20576 : H12AffineEnvironment.transform 9 305 env20575 = env20576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env20575 == env20576) = true)

theorem identity20576 : scanCanonicalize (H12AffineFastState.compose env20576 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20576 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20577 : List Nat := [2,4,8,16,32,48,9,256,512,305,2048,2096,269,2080,33,262,2064,2340,305,32,2048,33,16,3,268,49,2048,2064,2065,2341,21,1,256,0,2080,513]

theorem envBound20577 : H12AffineFastState.Bounded env20577 := by
  intro p hp
  have h : env20577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20576_20577 : H12AffineEnvironment.transform 5 48 env20576 = env20577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20576 == env20577) = true)

theorem identity20577 : scanCanonicalize (H12AffineFastState.compose env20577 (packedSelected [3,5,19] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20577 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env20578 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,2065,269,2049,0,262,2064,2309,272,1,2048,0,16,3,268,16,2048,2064,2065,2308,21,1,256,0,2049,513]

theorem envBound20578 : H12AffineFastState.Bounded env20578 := by
  intro p hp
  have h : env20578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20577_20578 : H12AffineEnvironment.transform 4 1 env20577 = env20578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20577 == env20578) = true)

theorem identity20578 : scanCanonicalize (H12AffineFastState.compose env20578 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound20578 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20579 : List Nat := [2,4,8,16,1,17,9,256,512,272,260,277,269,261,0,262,276,1,272,1,260,0,16,3,268,16,260,276,277,0,21,1,256,0,261,513]

theorem envBound20579 : H12AffineFastState.Bounded env20579 := by
  intro p hp
  have h : env20579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20578_20579 : H12AffineEnvironment.transform 10 260 env20578 = env20579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env20578 == env20579) = true)

def env20580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374561,98781,8328,65,215367,5393,4359473,4442267,4376044,4256861,256,4363536,4355253,4448827]

theorem envBound20580 : H12AffineFastState.Bounded env20580 := by
  intro p hp
  have h : env20580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20557_20580 : H12AffineEnvironment.transform 22 4374561 env20557 = env20580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env20557 == env20580) = true)

theorem identity20580 : scanCanonicalize (H12AffineFastState.compose env20580 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20580 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4160,4194304,4374561,41430,8328,65,158028,5393,4359473,4384912,4376044,4256861,256,4363536,4355253,4375088]

theorem envBound20581 : H12AffineFastState.Bounded env20581 := by
  intro p hp
  have h : env20581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20580_20581 : H12AffineEnvironment.transform 15 8203 env20580 = env20581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20580 == env20581) = true)

theorem identity20581 : scanCanonicalize (H12AffineFastState.compose env20581 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound20581 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4160,180273,16,41430,8328,65,158028,5393,17664,10401,1501,144492,256,21793,46212,513]

theorem envBound20582 : H12AffineFastState.Bounded env20582 := by
  intro p hp
  have h : env20582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20581_20582 : H12AffineEnvironment.transform 21 180273 env20581 = env20582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env20581 == env20582) = true)

theorem identity20582 : scanCanonicalize (H12AffineFastState.compose env20582 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound20582 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43169,1024,32769,4160,32801,16,41430,8328,65,10588,5393,17664,10401,1501,29820,256,21793,46212,513]

theorem envBound20583 : H12AffineFastState.Bounded env20583 := by
  intro p hp
  have h : env20583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20582_20583 : H12AffineEnvironment.transform 16 16400 env20582 = env20583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20582 == env20583) = true)

theorem identity20583 : scanCanonicalize (H12AffineFastState.compose env20583 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20583 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13389,43169,1024,32769,4160,32801,16,41430,8328,65,10588,5393,12637,10401,1501,33,256,8572,46212,513]

theorem envBound20584 : H12AffineFastState.Bounded env20584 := by
  intro p hp
  have h : env20584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20583_20584 : H12AffineEnvironment.transform 13 13405 env20583 = env20584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20583 == env20584) = true)

theorem identity20584 : scanCanonicalize (H12AffineFastState.compose env20584 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20584 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8203,13389,2556,1024,8540,4160,8572,16,139,8328,65,10588,5393,12637,10401,1501,33,256,8572,5593,513]

theorem envBound20585 : H12AffineFastState.Bounded env20585 := by
  intro p hp
  have h : env20585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20584_20585 : H12AffineEnvironment.transform 14 8541 env20584 = env20585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20584 == env20585) = true)

theorem identity20585 : scanCanonicalize (H12AffineFastState.compose env20585 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20585 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,343,5393,2556,1024,0,4160,32,16,139,468,65,2048,5393,4097,2557,1501,33,256,32,5593,513]

theorem envBound20586 : H12AffineFastState.Bounded env20586 := by
  intro p hp
  have h : env20586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20585_20586 : H12AffineEnvironment.transform 12 348 env20585 = env20586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20585 == env20586) = true)

theorem identity20586 : scanCanonicalize (H12AffineFastState.compose env20586 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound20586 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2420,348,3189,1,343,3173,2556,1024,0,2356,32,16,139,468,65,2048,3173,2421,2557,1501,33,256,32,3245,513]

theorem envBound20587 : H12AffineFastState.Bounded env20587 := by
  intro p hp
  have h : env20587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20586_20587 : H12AffineEnvironment.transform 11 2420 env20586 = env20587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env20586 == env20587) = true)

theorem identity20587 : scanCanonicalize (H12AffineFastState.compose env20587 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound20587 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env20588 : List Nat := [2,4,8,16,32,64,128,231,512,1024,2048,2195,187,3189,1,176,3173,2075,1024,0,2259,32,16,139,51,65,2048,3173,2194,2074,1082,33,231,32,3245,513]

theorem envBound20588 : H12AffineFastState.Bounded env20588 := by
  intro p hp
  have h : env20588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20587_20588 : H12AffineEnvironment.transform 7 231 env20587 = env20588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env20587 == env20588) = true)

theorem identity20588 : scanCanonicalize (H12AffineFastState.compose env20588 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20588 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env20589 : List Nat := [2,4,8,16,32,64,8,111,512,1024,2048,2075,51,3189,1,56,3173,2075,1024,0,2139,32,16,3,51,65,2048,3173,2074,2074,1082,33,111,32,3109,513]

theorem envBound20589 : H12AffineFastState.Bounded env20589 := by
  intro p hp
  have h : env20589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20588_20589 : H12AffineEnvironment.transform 6 8 env20588 = env20589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20588 == env20589) = true)

theorem identity20589 : scanCanonicalize (H12AffineFastState.compose env20589 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound20589 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20590 : List Nat := [2,4,8,16,32,64,8,111,512,126,2048,2075,51,2059,1,56,2075,2075,126,0,2139,32,16,3,51,65,2048,2075,2074,2074,68,33,111,32,2139,513]

theorem envBound20590 : H12AffineFastState.Bounded env20590 := by
  intro p hp
  have h : env20590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20589_20590 : H12AffineEnvironment.transform 9 126 env20589 = env20590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env20589 == env20590) = true)

theorem identity20590 : scanCanonicalize (H12AffineFastState.compose env20590 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound20590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20591 : List Nat := [2,4,8,16,32,1,8,46,512,63,2048,2075,51,2059,1,56,2075,2075,63,0,2074,32,16,3,51,0,2048,2075,2074,2074,5,33,46,32,2074,513]

theorem envBound20591 : H12AffineFastState.Bounded env20591 := by
  intro p hp
  have h : env20591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20590_20591 : H12AffineEnvironment.transform 5 1 env20590 = env20591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env20590 == env20591) = true)

theorem identity20591 : scanCanonicalize (H12AffineFastState.compose env20591 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 530) := by decide +kernel

theorem selectedBound20591 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env20592 : List Nat := [2,4,8,16,32,1,8,46,512,63,530,521,51,537,1,56,521,521,63,0,520,32,16,3,51,0,530,521,520,520,5,33,46,32,520,513]

theorem envBound20592 : H12AffineFastState.Bounded env20592 := by
  intro p hp
  have h : env20592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20591_20592 : H12AffineEnvironment.transform 10 530 env20591 = env20592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 530 env20591 == env20592) = true)

theorem identity20592 : scanCanonicalize (H12AffineFastState.compose env20592 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound20592 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env20593 : List Nat := [2,4,8,11,32,1,8,46,512,36,521,521,40,514,1,35,521,521,36,0,520,32,11,3,40,0,521,521,520,520,5,33,46,32,520,513]

theorem envBound20593 : H12AffineFastState.Bounded env20593 := by
  intro p hp
  have h : env20593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20592_20593 : H12AffineEnvironment.transform 3 11 env20592 = env20593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env20592 == env20593) = true)

theorem identity20593 : scanCanonicalize (H12AffineFastState.compose env20593 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound20593 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20594 : List Nat := [2,4,8,11,32,1,8,46,13,36,4,4,40,15,1,35,4,4,36,0,5,32,11,3,40,0,4,4,5,5,5,33,46,32,5,12]

theorem envBound20594 : H12AffineFastState.Bounded env20594 := by
  intro p hp
  have h : env20594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20593_20594 : H12AffineEnvironment.transform 8 13 env20593 = env20594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env20593 == env20594) = true)

theorem identity20594 : scanCanonicalize (H12AffineFastState.compose env20594 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound20594 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20595 : List Nat := [2,4,3,0,32,1,3,37,6,36,4,4,35,4,1,35,4,4,36,0,5,32,0,3,35,0,4,4,5,5,5,33,37,32,5,7]

theorem envBound20595 : H12AffineFastState.Bounded env20595 := by
  intro p hp
  have h : env20595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20594_20595 : H12AffineEnvironment.transform 2 3 env20594 = env20595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env20594 == env20595) = true)

theorem identity20595 : scanCanonicalize (H12AffineFastState.compose env20595 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound20595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20596 : List Nat := [2,4,3,0,5,1,3,0,6,1,4,4,6,4,1,6,4,4,1,0,5,5,0,3,6,0,4,4,5,5,5,4,0,5,5,7]

theorem envBound20596 : H12AffineFastState.Bounded env20596 := by
  intro p hp
  have h : env20596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20595_20596 : H12AffineEnvironment.transform 4 5 env20595 = env20596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env20595 == env20596) = true)

def env20597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,8388608,98780,8328,65,12683623,5393,8406289,8456378,8390092,4256861,256,8410417,8434836,8462875]

theorem envBound20597 : H12AffineFastState.Bounded env20597 := by
  intro p hp
  have h : env20597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20556_20597 : H12AffineEnvironment.transform 20 4161 env20556 = env20597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20556 == env20597) = true)

def env20598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374560,98780,8328,65,215367,5393,4359473,4442266,4376044,4256861,256,4363537,4355252,4448827]

theorem envBound20598 : H12AffineFastState.Bounded env20598 := by
  intro p hp
  have h : env20598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20597_20598 : H12AffineEnvironment.transform 22 4374560 env20597 = env20598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env20597 == env20598) = true)

theorem identity20598 : scanCanonicalize (H12AffineFastState.compose env20598 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound20598 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,201967,120015,98780,8328,65,215367,5393,102878,56437,119043,254130,256,98814,90203,63188]

theorem envBound20599 : H12AffineFastState.Bounded env20599 := by
  intro p hp
  have h : env20599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20598_20599 : H12AffineEnvironment.transform 21 201967 env20598 = env20599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env20598 == env20599) = true)

def env20600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130174,1024,32769,4161,73771,120015,98780,8328,65,97667,5393,102878,56437,119043,119926,256,98814,90203,63188]

theorem envBound20600 : H12AffineFastState.Bounded env20600 := by
  intro p hp
  have h : env20600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20599_20600 : H12AffineEnvironment.transform 16 13508 env20599 = env20600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env20599 == env20600) = true)

theorem identity20600 : scanCanonicalize (H12AffineFastState.compose env20600 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20600 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env20601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,13508,67619,1024,29788,4161,73771,73874,95617,8328,65,97667,5393,91523,10280,75102,73771,256,95651,90203,649]

theorem envBound20601 : H12AffineFastState.Bounded env20601 := by
  intro p hp
  have h : env20601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20600_20601 : H12AffineEnvironment.transform 14 29789 env20600 = env20601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20600 == env20601) = true)

theorem identity20601 : scanCanonicalize (H12AffineFastState.compose env20601 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20601 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env20602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21760,65536,5529,67619,1024,21761,4161,65910,65999,87260,469,65,89310,5393,83166,2421,66563,65910,256,87294,82182,649]

theorem envBound20602 : H12AffineFastState.Bounded env20602 := by
  intro p hp
  have h : env20602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20601_20602 : H12AffineEnvironment.transform 12 349 env20601 = env20602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20601 == env20602) = true)

theorem identity20602 : scanCanonicalize (H12AffineFastState.compose env20602 (packedSelected [0,1,2,5,6,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20602 : packedSelected [0,1,2,5,6,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20603 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,16384,20496,65536,4233,67619,272,20497,4161,65910,65999,86476,469,65,88526,4097,82382,2421,65811,65910,256,86510,82182,649]

theorem envBound20603 : H12AffineFastState.Bounded env20603 := by
  intro p hp
  have h : env20603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20602_20603 : H12AffineEnvironment.transform 9 272 env20602 = env20603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20602 == env20603) = true)

theorem identity20603 : scanCanonicalize (H12AffineFastState.compose env20603 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20603 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env20604 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4113,1,65536,4233,67619,272,0,4161,65910,65999,66013,469,65,68063,4097,70111,2421,65811,65910,256,66047,69911,649]

theorem envBound20604 : H12AffineFastState.Bounded env20604 := by
  intro p hp
  have h : env20604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20603_20604 : H12AffineEnvironment.transform 13 4113 env20603 = env20604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20603 == env20604) = true)

theorem identity20604 : scanCanonicalize (H12AffineFastState.compose env20604 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound20604 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20605 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4113,1,479,4233,2556,272,0,4161,169,16,2,469,65,2048,4097,4096,2421,204,169,256,32,4296,649]

theorem envBound20605 : H12AffineFastState.Bounded env20605 := by
  intro p hp
  have h : env20605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20604_20605 : H12AffineEnvironment.transform 15 479 env20604 = env20605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env20604 == env20605) = true)

theorem identity20605 : scanCanonicalize (H12AffineFastState.compose env20605 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20605 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20606 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,1,343,4097,2420,272,0,4161,33,16,2,349,65,2048,4097,4096,2421,68,33,256,32,4160,513]

theorem envBound20606 : H12AffineFastState.Bounded env20606 := by
  intro p hp
  have h : env20606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20605_20606 : H12AffineEnvironment.transform 6 8 env20605 = env20606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20605 == env20606) = true)

theorem identity20606 : scanCanonicalize (H12AffineFastState.compose env20606 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 340) := by decide +kernel

theorem selectedBound20606 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20607 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,340,349,325,1,343,341,2420,272,0,277,33,16,2,349,65,2048,341,340,2421,68,33,256,32,276,513]

theorem envBound20607 : H12AffineFastState.Bounded env20607 := by
  intro p hp
  have h : env20607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20606_20607 : H12AffineEnvironment.transform 11 340 env20606 = env20607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 340 env20606 == env20607) = true)

theorem identity20607 : scanCanonicalize (H12AffineFastState.compose env20607 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound20607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20608 : List Nat := [2,4,8,16,32,64,8,256,48,272,2048,340,349,325,1,343,341,2420,272,0,277,33,16,2,349,65,2048,341,340,2421,68,33,256,32,276,49]

theorem envBound20608 : H12AffineFastState.Bounded env20608 := by
  intro p hp
  have h : env20608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20607_20608 : H12AffineEnvironment.transform 8 48 env20607 = env20608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env20607 == env20608) = true)

theorem identity20608 : scanCanonicalize (H12AffineFastState.compose env20608 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20608 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20609 : List Nat := [2,4,8,16,32,16,8,256,48,272,2048,260,269,277,1,263,261,2340,272,0,277,33,16,2,269,17,2048,261,260,2341,20,33,256,32,276,49]

theorem envBound20609 : H12AffineFastState.Bounded env20609 := by
  intro p hp
  have h : env20609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20608_20609 : H12AffineEnvironment.transform 5 16 env20608 = env20609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20608 == env20609) = true)

theorem identity20609 : scanCanonicalize (H12AffineFastState.compose env20609 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound20609 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20610 : List Nat := [2,4,8,16,32,16,8,256,48,272,293,260,269,277,1,263,261,1,272,0,277,33,16,2,269,17,293,261,260,0,20,33,256,32,276,49]

theorem envBound20610 : H12AffineFastState.Bounded env20610 := by
  intro p hp
  have h : env20610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20609_20610 : H12AffineEnvironment.transform 10 293 env20609 = env20610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env20609 == env20610) = true)

theorem identity20610 : scanCanonicalize (H12AffineFastState.compose env20610 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20610 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20611 : List Nat := [2,4,8,16,1,16,8,256,17,272,260,260,269,277,1,263,261,1,272,0,277,0,16,2,269,17,260,261,260,0,20,0,256,1,276,16]

theorem envBound20611 : H12AffineFastState.Bounded env20611 := by
  intro p hp
  have h : env20611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20610_20611 : H12AffineEnvironment.transform 4 1 env20610 = env20611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20610 == env20611) = true)

theorem identity20611 : scanCanonicalize (H12AffineFastState.compose env20611 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound20611 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20612 : List Nat := [2,4,8,16,1,16,8,30,17,14,26,26,19,11,1,25,27,1,14,0,11,0,16,2,19,17,26,27,26,0,20,0,30,1,10,16]

theorem envBound20612 : H12AffineFastState.Bounded env20612 := by
  intro p hp
  have h : env20612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20611_20612 : H12AffineEnvironment.transform 7 30 env20611 = env20612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env20611 == env20612) = true)

theorem identity20612 : scanCanonicalize (H12AffineFastState.compose env20612 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound20612 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20613 : List Nat := [2,4,8,11,1,11,8,5,10,14,1,1,8,11,1,2,0,1,14,0,11,0,11,2,8,10,1,0,1,0,15,0,5,1,10,11]

theorem envBound20613 : H12AffineFastState.Bounded env20613 := by
  intro p hp
  have h : env20613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20612_20613 : H12AffineEnvironment.transform 3 11 env20612 = env20613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env20612 == env20613) = true)

theorem identity20613 : scanCanonicalize (H12AffineFastState.compose env20613 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound20613 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env20614 : List Nat := [2,4,3,0,1,0,3,5,1,5,1,1,3,0,1,2,0,1,5,0,0,0,0,2,3,1,1,0,1,0,4,0,5,1,1,0]

theorem envBound20614 : H12AffineFastState.Bounded env20614 := by
  intro p hp
  have h : env20614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20613_20614 : H12AffineEnvironment.transform 2 3 env20613 = env20614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env20613 == env20614) = true)

def env20615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130175,1024,32769,4161,73770,120015,98780,8328,65,97666,5393,102878,56437,119043,119927,256,98814,90203,63188]

theorem envBound20615 : H12AffineFastState.Bounded env20615 := by
  intro p hp
  have h : env20615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20599_20615 : H12AffineEnvironment.transform 16 13509 env20599 = env20615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env20599 == env20615) = true)

theorem identity20615 : scanCanonicalize (H12AffineFastState.compose env20615 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20615 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env20616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,13509,97526,1024,136,4161,73770,87110,65877,8328,65,97666,5393,69975,23804,86410,87294,256,65911,90203,30301]

theorem envBound20616 : H12AffineFastState.Bounded env20616 := by
  intro p hp
  have h : env20616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20615_20616 : H12AffineEnvironment.transform 14 137 env20615 = env20616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20615 == env20616) = true)

theorem identity20616 : scanCanonicalize (H12AffineFastState.compose env20616 (packedSelected [3,4,5,7,8,9,14,15,17,18,19,23,26,27,28,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound20616 : packedSelected [3,4,5,7,8,9,14,15,17,18,19,23,26,27,28,35,38] rootPS < 2^1333 := by decide +kernel

def env20617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,137,65536,13509,76079,1024,136,4161,73770,65951,65877,8328,65,75867,5393,69975,2341,66643,65831,256,65911,79234,9092]

theorem envBound20617 : H12AffineFastState.Bounded env20617 := by
  intro p hp
  have h : env20617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20616_20617 : H12AffineEnvironment.transform 13 5593 env20616 = env20617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env20616 == env20617) = true)

theorem identity20617 : scanCanonicalize (H12AffineFastState.compose env20617 (packedSelected [0,9,16,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound20617 : packedSelected [0,9,16,20,22,27] rootPS < 2^1333 := by decide +kernel

def env20618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,137,399,13509,10400,1024,136,4161,8613,16,218,8328,65,10708,5393,4312,2341,1500,168,256,248,13325,9092]

theorem envBound20618 : H12AffineFastState.Bounded env20618 := by
  intro p hp
  have h : env20618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20617_20618 : H12AffineEnvironment.transform 15 399 env20617 = env20618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env20617 == env20618) = true)

theorem identity20618 : scanCanonicalize (H12AffineFastState.compose env20618 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20618 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env20619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,137,399,13461,10400,1024,136,4113,8613,16,138,8328,17,10628,5393,4232,2341,1420,168,256,168,13325,9092]

theorem envBound20619 : H12AffineFastState.Bounded env20619 := by
  intro p hp
  have h : env20619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20618_20619 : H12AffineEnvironment.transform 5 16 env20618 = env20619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20618 == env20619) = true)

theorem identity20619 : scanCanonicalize (H12AffineFastState.compose env20619 (packedSelected [1,3,5,7,8,9,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6924) := by decide +kernel

theorem selectedBound20619 : packedSelected [1,3,5,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env20620 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,6924,5513,137,399,3993,5036,1024,136,4113,6825,16,138,7044,17,4744,5393,4232,2341,1420,168,256,168,3841,6280]

theorem envBound20620 : H12AffineFastState.Bounded env20620 := by
  intro p hp
  have h : env20620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20619_20620 : H12AffineEnvironment.transform 12 6924 env20619 = env20620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6924 env20619 == env20620) = true)

theorem identity20620 : scanCanonicalize (H12AffineFastState.compose env20620 (packedSelected [0,1,4,8,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound20620 : packedSelected [0,1,4,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env20621 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2200,916,3345,137,399,3993,2868,1024,136,2185,561,16,138,796,17,2576,3465,2064,2341,1420,168,256,168,3841,16]

theorem envBound20621 : H12AffineFastState.Bounded env20621 := by
  intro p hp
  have h : env20621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20620_20621 : H12AffineEnvironment.transform 11 2200 env20620 = env20621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env20620 == env20621) = true)

theorem identity20621 : scanCanonicalize (H12AffineFastState.compose env20621 (packedSelected [0,4,6,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound20621 : packedSelected [0,4,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env20622 : List Nat := [2,4,8,16,32,16,128,256,512,1024,168,48,916,1465,137,399,1841,924,1024,136,33,561,16,138,796,17,696,1313,184,397,1420,168,256,168,1961,16]

theorem envBound20622 : H12AffineFastState.Bounded env20622 := by
  intro p hp
  have h : env20622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20621_20622 : H12AffineEnvironment.transform 10 168 env20621 = env20622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env20621 == env20622) = true)

theorem identity20622 : scanCanonicalize (H12AffineFastState.compose env20622 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound20622 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20623 : List Nat := [2,4,8,16,32,16,128,256,169,1024,168,48,317,1465,137,399,1432,309,1024,136,33,152,16,138,437,17,17,1313,184,397,1420,168,256,168,1280,16]

theorem envBound20623 : H12AffineFastState.Bounded env20623 := by
  intro p hp
  have h : env20623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20622_20623 : H12AffineEnvironment.transform 8 169 env20622 = env20623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env20622 == env20623) = true)

theorem identity20623 : scanCanonicalize (H12AffineFastState.compose env20623 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 392) := by decide +kernel

theorem selectedBound20623 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env20624 : List Nat := [2,4,8,16,32,16,128,256,169,392,168,48,317,49,137,399,16,309,392,136,33,152,16,138,437,17,17,169,184,397,4,168,256,168,136,16]

theorem envBound20624 : H12AffineFastState.Bounded env20624 := by
  intro p hp
  have h : env20624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20623_20624 : H12AffineEnvironment.transform 9 392 env20623 = env20624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env20623 == env20624) = true)

theorem identity20624 : scanCanonicalize (H12AffineFastState.compose env20624 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound20624 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env20625 : List Nat := [2,4,8,16,32,16,128,141,169,5,168,48,176,49,137,2,16,184,5,136,33,152,16,138,56,17,17,169,184,0,4,168,141,168,136,16]

theorem envBound20625 : H12AffineFastState.Bounded env20625 := by
  intro p hp
  have h : env20625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20624_20625 : H12AffineEnvironment.transform 7 141 env20624 = env20625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env20624 == env20625) = true)

theorem identity20625 : scanCanonicalize (H12AffineFastState.compose env20625 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound20625 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20626 : List Nat := [2,4,8,16,32,16,57,52,16,5,17,48,9,49,48,2,16,1,5,49,33,33,16,51,56,17,17,16,1,0,4,17,52,17,49,16]

theorem envBound20626 : H12AffineFastState.Bounded env20626 := by
  intro p hp
  have h : env20626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20625_20626 : H12AffineEnvironment.transform 6 57 env20625 = env20626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env20625 == env20626) = true)

theorem identity20626 : scanCanonicalize (H12AffineFastState.compose env20626 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20626 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env20627 : List Nat := [2,4,8,16,0,16,25,20,16,5,17,16,9,17,16,2,16,1,5,17,1,1,16,19,24,17,17,16,1,0,4,17,20,17,17,16]

theorem envBound20627 : H12AffineFastState.Bounded env20627 := by
  intro p hp
  have h : env20627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20626_20627 : H12AffineEnvironment.transform 4 0 env20626 = env20627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20626 == env20627) = true)

theorem identity20627 : scanCanonicalize (H12AffineFastState.compose env20627 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20628 : List Nat := [2,4,8,0,0,0,9,4,0,5,1,0,9,1,0,2,0,1,5,1,1,1,0,3,8,1,1,0,1,0,4,1,4,1,1,0]

theorem envBound20628 : H12AffineFastState.Bounded env20628 := by
  intro p hp
  have h : env20628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20627_20628 : H12AffineEnvironment.transform 3 0 env20627 = env20628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20627 == env20628) = true)

theorem identity20628 : scanCanonicalize (H12AffineFastState.compose env20628 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20629 : List Nat := [2,1,8,0,0,0,9,1,0,0,1,0,9,1,0,2,0,1,0,1,1,1,0,3,8,1,1,0,1,0,1,1,1,1,1,0]

theorem envBound20629 : H12AffineFastState.Bounded env20629 := by
  intro p hp
  have h : env20629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20628_20629 : H12AffineEnvironment.transform 1 1 env20628 = env20629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20628 == env20629) = true)

theorem identity20629 : scanCanonicalize (H12AffineFastState.compose env20629 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20630 : List Nat := [2,1,1,0,0,0,0,1,0,0,1,0,0,1,0,2,0,1,0,1,1,1,0,3,1,1,1,0,1,0,1,1,1,1,1,0]

theorem envBound20630 : H12AffineFastState.Bounded env20630 := by
  intro p hp
  have h : env20630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20629_20630 : H12AffineEnvironment.transform 2 1 env20629 = env20630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20629 == env20630) = true)

theorem identity20630 : scanCanonicalize (H12AffineFastState.compose env20630 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20630 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20631 : List Nat := [1,1,1,0,0,0,0,1,0,0,1,0,0,1,0,1,0,1,0,1,1,1,0,0,1,1,1,0,1,0,1,1,1,1,1,0]

theorem envBound20631 : H12AffineFastState.Bounded env20631 := by
  intro p hp
  have h : env20631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20630_20631 : H12AffineEnvironment.transform 0 1 env20630 = env20631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20630 == env20631) = true)

def env20632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374561,98780,8328,65,215366,5393,4359472,4442267,4376045,4256861,256,4363536,4355253,4448826]

theorem envBound20632 : H12AffineFastState.Bounded env20632 := by
  intro p hp
  have h : env20632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20597_20632 : H12AffineEnvironment.transform 22 4374561 env20597 = env20632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env20597 == env20632) = true)

theorem identity20632 : scanCanonicalize (H12AffineFastState.compose env20632 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound20632 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138341,1024,32769,4161,4194304,4374561,21763,8328,65,171417,5393,4359472,4332612,4376045,4256861,256,4363536,4355253,4339429]

theorem envBound20633 : H12AffineFastState.Bounded env20633 := by
  intro p hp
  have h : env20633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20632_20633 : H12AffineEnvironment.transform 15 54495 env20632 = env20633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env20632 == env20633) = true)

def env20634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138341,1024,32769,4161,180408,153,21763,8328,65,171417,5393,17800,56572,1365,144613,256,21928,46093,63069]

theorem envBound20634 : H12AffineFastState.Bounded env20634 := by
  intro p hp
  have h : env20634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20633_20634 : H12AffineEnvironment.transform 21 180408 env20633 = env20634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env20633 == env20634) = true)

theorem identity20634 : scanCanonicalize (H12AffineFastState.compose env20634 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound20634 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env20635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21841,398,131072,138341,1024,21840,4161,136681,153,21763,8328,65,149704,5393,17800,2477,1365,144613,256,21928,24924,8972]

theorem envBound20635 : H12AffineFastState.Bounded env20635 := by
  intro p hp
  have h : env20635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20634_20635 : H12AffineEnvironment.transform 14 21841 env20634 = env20635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env20634 == env20635) = true)

theorem identity20635 : scanCanonicalize (H12AffineFastState.compose env20635 (packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound20635 : packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env20636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21841,398,24908,32041,1024,21840,4161,29861,153,21763,8328,65,10628,5393,17800,2477,1365,21929,256,21928,24924,8972]

theorem envBound20636 : H12AffineFastState.Bounded env20636 := by
  intro p hp
  have h : env20636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20635_20636 : H12AffineEnvironment.transform 16 24908 env20635 = env20636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env20635 == env20636) = true)

theorem identity20636 : scanCanonicalize (H12AffineFastState.compose env20636 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20636 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,80,398,13389,10280,1024,81,4161,8612,153,2,8328,65,10628,5393,4233,2477,1365,168,256,169,13405,8972]

theorem envBound20637 : H12AffineFastState.Bounded env20637 := by
  intro p hp
  have h : env20637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20636_20637 : H12AffineEnvironment.transform 13 5377 env20636 = env20637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20636 == env20637) = true)

theorem identity20637 : scanCanonicalize (H12AffineFastState.compose env20637 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound20637 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20638 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4249,80,398,12757,10280,408,81,4161,8612,153,2,8328,65,10628,4233,4233,2477,205,168,256,169,12741,8972]

theorem envBound20638 : H12AffineFastState.Bounded env20638 := by
  intro p hp
  have h : env20638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20637_20638 : H12AffineEnvironment.transform 9 408 env20637 = env20638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env20637 == env20638) = true)

theorem identity20638 : scanCanonicalize (H12AffineFastState.compose env20638 (packedSelected [2,4,6,9,11,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound20638 : packedSelected [2,4,6,9,11,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env20639 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,469,4249,80,398,4096,2557,408,81,4161,113,153,2,349,65,2129,4233,4233,2477,205,168,256,169,4112,729]

theorem envBound20639 : H12AffineFastState.Bounded env20639 := by
  intro p hp
  have h : env20639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20638_20639 : H12AffineEnvironment.transform 12 469 env20638 = env20639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env20638 == env20639) = true)

theorem identity20639 : scanCanonicalize (H12AffineFastState.compose env20639 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20639 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env20640 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,389,4249,0,398,4096,2477,408,1,4113,33,153,2,269,17,2049,4233,4233,2477,157,168,256,169,4112,649]

theorem envBound20640 : H12AffineFastState.Bounded env20640 := by
  intro p hp
  have h : env20640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20639_20640 : H12AffineEnvironment.transform 5 16 env20639 = env20640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20639 == env20640) = true)

theorem identity20640 : scanCanonicalize (H12AffineFastState.compose env20640 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20640 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20641 : List Nat := [2,4,8,16,32,16,128,4,512,156,2048,4096,129,4249,0,138,4096,2217,156,1,4113,33,153,2,9,17,2049,4233,4233,2217,157,168,4,169,4112,649]

theorem envBound20641 : H12AffineFastState.Bounded env20641 := by
  intro p hp
  have h : env20641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20640_20641 : H12AffineEnvironment.transform 7 4 env20640 = env20641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20640 == env20641) = true)

theorem identity20641 : scanCanonicalize (H12AffineFastState.compose env20641 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound20641 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env20642 : List Nat := [2,4,8,16,32,16,128,4,512,156,2048,2097,129,2216,0,138,2097,2217,156,1,2080,33,153,2,9,17,2049,2232,2232,2217,157,168,4,169,2081,649]

theorem envBound20642 : H12AffineFastState.Bounded env20642 := by
  intro p hp
  have h : env20642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20641_20642 : H12AffineEnvironment.transform 11 2097 env20641 = env20642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env20641 == env20642) = true)

theorem identity20642 : scanCanonicalize (H12AffineFastState.compose env20642 (packedSelected [0,1,2,3,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20642 : packedSelected [0,1,2,3,6,9] rootPS < 2^1333 := by decide +kernel

def env20643 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,2097,9,2080,0,2,2097,2081,20,1,2080,33,17,2,9,17,2049,2096,2096,2081,21,32,4,33,2081,513]

theorem envBound20643 : H12AffineFastState.Bounded env20643 := by
  intro p hp
  have h : env20643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20642_20643 : H12AffineEnvironment.transform 6 8 env20642 = env20643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20642 == env20643) = true)

theorem identity20643 : scanCanonicalize (H12AffineFastState.compose env20643 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20644 : List Nat := [2,4,8,16,17,16,8,4,512,20,2048,2048,9,2065,0,2,2048,2064,20,1,2065,16,17,2,9,17,2049,2049,2049,2064,21,17,4,16,2064,513]

theorem envBound20644 : H12AffineFastState.Bounded env20644 := by
  intro p hp
  have h : env20644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20643_20644 : H12AffineEnvironment.transform 4 17 env20643 = env20644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20643 == env20644) = true)

theorem identity20644 : scanCanonicalize (H12AffineFastState.compose env20644 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound20644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20645 : List Nat := [2,4,8,10,11,10,8,4,512,14,2048,2048,9,2059,0,2,2048,2058,14,1,2059,10,11,2,9,11,2049,2049,2049,2058,15,11,4,10,2058,513]

theorem envBound20645 : H12AffineFastState.Bounded env20645 := by
  intro p hp
  have h : env20645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20644_20645 : H12AffineEnvironment.transform 3 10 env20644 = env20645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env20644 == env20645) = true)

theorem identity20645 : scanCanonicalize (H12AffineFastState.compose env20645 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound20645 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20646 : List Nat := [2,4,8,10,11,10,8,4,512,14,512,512,9,523,0,2,512,522,14,1,523,10,11,2,9,11,513,513,513,522,15,11,4,10,522,513]

theorem envBound20646 : H12AffineFastState.Bounded env20646 := by
  intro p hp
  have h : env20646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20645_20646 : H12AffineEnvironment.transform 10 512 env20645 = env20646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env20645 == env20646) = true)

theorem identity20646 : scanCanonicalize (H12AffineFastState.compose env20646 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound20646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20647 : List Nat := [2,4,8,10,11,10,8,4,10,14,10,10,9,1,0,2,10,0,14,1,1,10,11,2,9,11,11,11,11,0,15,11,4,10,0,11]

theorem envBound20647 : H12AffineFastState.Bounded env20647 := by
  intro p hp
  have h : env20647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20646_20647 : H12AffineEnvironment.transform 8 10 env20646 = env20647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env20646 == env20647) = true)

theorem identity20647 : scanCanonicalize (H12AffineFastState.compose env20647 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound20647 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20648 : List Nat := [2,4,3,1,0,1,3,4,1,5,1,1,2,1,0,2,1,0,5,1,1,1,0,2,2,0,0,0,0,0,4,0,4,1,0,0]

theorem envBound20648 : H12AffineFastState.Bounded env20648 := by
  intro p hp
  have h : env20648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20647_20648 : H12AffineEnvironment.transform 2 3 env20647 = env20648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env20647 == env20648) = true)

def env20649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138341,1024,32769,4161,180409,152,21763,8328,65,171417,5393,17801,56573,1364,144612,256,21929,46092,63068]

theorem envBound20649 : H12AffineFastState.Bounded env20649 := by
  intro p hp
  have h : env20649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20633_20649 : H12AffineEnvironment.transform 21 180409 env20633 = env20649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env20633 == env20649) = true)

theorem identity20649 : scanCanonicalize (H12AffineFastState.compose env20649 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20649 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env20650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,30082,131072,138341,1024,8540,4161,156132,152,21763,8328,65,146628,5393,17801,32160,1364,144612,256,21929,5457,22273]

theorem envBound20650 : H12AffineFastState.Bounded env20650 := by
  intro p hp
  have h : env20650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20649_20650 : H12AffineEnvironment.transform 14 8541 env20649 = env20650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20649 == env20650) = true)

theorem identity20650 : scanCanonicalize (H12AffineFastState.compose env20650 (packedSelected [1,17,18,19,23,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound20650 : packedSelected [1,17,18,19,23,28,31] rootPS < 2^1333 := by decide +kernel

def env20651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,21590,131072,138341,1024,136,4161,147504,152,21763,348,65,138512,5393,17801,23668,1364,136496,256,21929,5457,22273]

theorem envBound20651 : H12AffineFastState.Bounded env20651 := by
  intro p hp
  have h : env20651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20650_20651 : H12AffineEnvironment.transform 12 468 env20650 = env20651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env20650 == env20651) = true)

theorem identity20651 : scanCanonicalize (H12AffineFastState.compose env20651 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound20651 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env20652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,479,131072,138341,1024,136,4161,136633,152,138,348,65,138512,5393,4096,2557,1364,136496,256,32,5457,648]

theorem envBound20652 : H12AffineFastState.Bounded env20652 := by
  intro p hp
  have h : env20652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20651_20652 : H12AffineEnvironment.transform 13 5513 env20651 = env20652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env20651 == env20652) = true)

theorem identity20652 : scanCanonicalize (H12AffineFastState.compose env20652 (packedSelected [6,14] rootPS)) = affineNative (2^(16+1) ^^^ 5560) := by decide +kernel

theorem selectedBound20652 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env20653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,479,5560,2525,1024,136,4161,1,152,138,348,65,2216,5393,4096,2557,1364,136,256,32,5457,648]

theorem envBound20653 : H12AffineFastState.Bounded env20653 := by
  intro p hp
  have h : env20653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20652_20653 : H12AffineEnvironment.transform 16 5560 env20652 = env20653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5560 env20652 == env20653) = true)

def env20654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound20654 : H12AffineFastState.Bounded env20654 := by
  intro p hp
  have h : env20654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20435_20654 : H12AffineEnvironment.transform 18 1025 env20435 = env20654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20435 == env20654) = true)

theorem identity20654 : scanCanonicalize (H12AffineFastState.compose env20654 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661050) := by decide +kernel

theorem selectedBound20654 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8328,65,4450362,10857655,10507600,8830977,371754,15027706,257,2485399,2428211,297980]

theorem envBound20655 : H12AffineFastState.Bounded env20655 := by
  intro p hp
  have h : env20655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20654_20655 : H12AffineEnvironment.transform 23 8661050 env20654 = env20655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661050 env20654 == env20655) = true)

def env20656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450362,10857535,10507600,8830977,371754,15027570,257,2485279,2428211,297844]

theorem envBound20656 : H12AffineFastState.Bounded env20656 := by
  intro p hp
  have h : env20656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20655_20656 : H12AffineEnvironment.transform 6 8 env20655 = env20656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20655 == env20656) = true)

theorem identity20656 : scanCanonicalize (H12AffineFastState.compose env20656 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound20656 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env20657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,8429903,8192,65,4450362,10560842,10507600,8538484,75103,14795783,257,2188650,2196550,513]

theorem envBound20657 : H12AffineFastState.Bounded env20657 := by
  intro p hp
  have h : env20657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20656_20657 : H12AffineEnvironment.transform 17 35189 env20656 = env20657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env20656 == env20657) = true)

def env20658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,16,41311,8192,65,4450362,2172250,2118976,149860,75103,6407191,257,2188650,2196550,513]

theorem envBound20658 : H12AffineFastState.Bounded env20658 := by
  intro p hp
  have h : env20658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20657_20658 : H12AffineEnvironment.transform 22 16 env20657 = env20658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env20657 == env20658) = true)

theorem identity20658 : scanCanonicalize (H12AffineFastState.compose env20658 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20658 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229152,2172250,2118976,76158,75103,6407191,257,2188650,2196550,513]

theorem envBound20659 : H12AffineFastState.Bounded env20659 := by
  intro p hp
  have h : env20659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20658_20659 : H12AffineEnvironment.transform 16 90138 env20658 = env20659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20658 == env20659) = true)

theorem identity20659 : scanCanonicalize (H12AffineFastState.compose env20659 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound20659 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229152,2139148,2118976,43048,41993,6309185,257,2155580,2098448,513]

theorem envBound20660 : H12AffineFastState.Bounded env20660 := by
  intro p hp
  have h : env20660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20659_20660 : H12AffineEnvironment.transform 15 33110 env20659 = env20660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env20659 == env20660) = true)

theorem identity20660 : scanCanonicalize (H12AffineFastState.compose env20660 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20660 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1025,8541,2097152,4194304,16,3,8192,65,4204924,2098512,2118976,2420,1365,6309185,257,2114912,2098448,513]

theorem envBound20661 : H12AffineFastState.Bounded env20661 := by
  intro p hp
  have h : env20661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20660_20661 : H12AffineEnvironment.transform 14 8540 env20660 = env20661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20660 == env20661) = true)

theorem identity20661 : scanCanonicalize (H12AffineFastState.compose env20661 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound20661 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1025,8541,2097152,2114912,16,3,8192,65,2124828,2098512,2118976,2420,1365,33,257,2114912,2098448,513]

theorem envBound20662 : H12AffineFastState.Bounded env20662 := by
  intro p hp
  have h : env20662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20661_20662 : H12AffineEnvironment.transform 21 2114912 env20661 = env20662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env20661 == env20662) = true)

theorem identity20662 : scanCanonicalize (H12AffineFastState.compose env20662 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound20662 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1025,8541,25677,8493,16,3,8192,65,2129,24861,12557,2420,1365,33,257,8493,24925,513]

theorem envBound20663 : H12AffineFastState.Bounded env20663 := by
  intro p hp
  have h : env20663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20662_20663 : H12AffineEnvironment.transform 20 25677 env20662 = env20663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env20662 == env20663) = true)

theorem identity20663 : scanCanonicalize (H12AffineFastState.compose env20663 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20663 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,262,16400,2341,1025,81,17729,33,16,3,268,65,2129,16401,4097,2420,1365,33,257,33,16465,513]

theorem envBound20664 : H12AffineFastState.Bounded env20664 := by
  intro p hp
  have h : env20664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20663_20664 : H12AffineEnvironment.transform 12 268 env20663 = env20664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20663 == env20664) = true)

theorem identity20664 : scanCanonicalize (H12AffineFastState.compose env20664 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1393) := by decide +kernel

theorem selectedBound20664 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1393,268,16384,80,262,16400,2341,1025,81,17729,33,16,3,268,65,2129,16401,1392,2420,1365,33,257,33,16465,513]

theorem envBound20665 : H12AffineFastState.Bounded env20665 := by
  intro p hp
  have h : env20665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20664_20665 : H12AffineEnvironment.transform 11 1393 env20664 = env20665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1393 env20664 == env20665) = true)

theorem identity20665 : scanCanonicalize (H12AffineFastState.compose env20665 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2625) := by decide +kernel

theorem selectedBound20665 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1393,268,2625,80,262,2641,2341,1025,81,3840,33,16,3,268,65,2129,2640,1392,2420,1365,33,257,33,2576,513]

theorem envBound20666 : H12AffineFastState.Bounded env20666 := by
  intro p hp
  have h : env20666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20665_20666 : H12AffineEnvironment.transform 13 2625 env20665 = env20666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2625 env20665 == env20666) = true)

theorem identity20666 : scanCanonicalize (H12AffineFastState.compose env20666 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound20666 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env20667 : List Nat := [2,4,8,16,32,64,8,256,276,1024,2048,1393,268,2389,80,262,2373,2341,1025,81,3092,33,16,3,268,65,2129,2372,1392,2420,1365,33,257,33,2308,277]

theorem envBound20667 : H12AffineFastState.Bounded env20667 := by
  intro p hp
  have h : env20667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20666_20667 : H12AffineEnvironment.transform 8 276 env20666 = env20667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env20666 == env20667) = true)

theorem identity20667 : scanCanonicalize (H12AffineFastState.compose env20667 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound20667 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20668 : List Nat := [2,4,8,16,32,64,8,85,65,1024,2048,1060,89,2048,80,83,2064,2160,1025,81,3092,33,16,3,89,65,2129,2065,1061,2081,1024,33,84,33,2129,64]

theorem envBound20668 : H12AffineFastState.Bounded env20668 := by
  intro p hp
  have h : env20668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20667_20668 : H12AffineEnvironment.transform 7 85 env20667 = env20668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env20667 == env20668) = true)

def env20669 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,17,41310,8192,65,4450362,2172251,2118977,149861,75103,6407190,257,2188650,2196550,513]

theorem envBound20669 : H12AffineFastState.Bounded env20669 := by
  intro p hp
  have h : env20669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20657_20669 : H12AffineEnvironment.transform 22 17 env20657 = env20669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env20657 == env20669) = true)

theorem identity20669 : scanCanonicalize (H12AffineFastState.compose env20669 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound20669 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env20670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,115734,4194304,17,41310,8192,65,4450362,57677,102743,149861,75103,4194304,257,41340,16464,513]

theorem envBound20670 : H12AffineFastState.Bounded env20670 := by
  intro p hp
  have h : env20670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20669_20670 : H12AffineEnvironment.transform 20 115734 env20669 = env20670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env20669 == env20670) = true)

def env20671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9293,1025,11577,92462,4194304,17,3174,8192,65,4408578,19573,81007,149861,75103,4194304,257,3140,16464,513]

theorem envBound20671 : H12AffineFastState.Bounded env20671 := by
  intro p hp
  have h : env20671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20670_20671 : H12AffineEnvironment.transform 14 11576 env20670 = env20671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env20670 == env20671) = true)

theorem identity20671 : scanCanonicalize (H12AffineFastState.compose env20671 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85283) := by decide +kernel

theorem selectedBound20671 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env20672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,85283,9293,1025,11577,92462,4194304,17,3174,8192,65,4196385,19573,81007,66630,75103,4194304,257,3140,16464,513]

theorem envBound20672 : H12AffineFastState.Bounded env20672 := by
  intro p hp
  have h : env20672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20671_20672 : H12AffineEnvironment.transform 16 85283 env20671 = env20672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85283 env20671 == env20672) = true)

theorem identity20672 : scanCanonicalize (H12AffineFastState.compose env20672 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound20672 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env20673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8540,65536,82247,9293,1025,8541,91466,4194304,17,2,8192,65,4195397,16401,77835,66630,75103,4194304,257,32,16464,513]

theorem envBound20673 : H12AffineFastState.Bounded env20673 := by
  intro p hp
  have h : env20673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20672_20673 : H12AffineEnvironment.transform 10 1124 env20672 = env20673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env20672 == env20673) = true)

def env20674 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,8192,16384,8460,65536,82199,9245,1025,8461,91418,4194304,17,2,8192,17,4195349,16401,77835,66582,75023,4194304,257,32,16384,513]

theorem envBound20674 : H12AffineFastState.Bounded env20674 := by
  intro p hp
  have h : env20674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20673_20674 : H12AffineEnvironment.transform 5 16 env20673 = env20674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20673 == env20674) = true)

theorem identity20674 : scanCanonicalize (H12AffineFastState.compose env20674 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20674 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20675 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,16384,0,65536,82199,1297,1025,1,82966,4194304,17,2,268,17,4195349,16401,69895,66582,66563,4194304,257,32,16384,513]

theorem envBound20675 : H12AffineFastState.Bounded env20675 := by
  intro p hp
  have h : env20675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20674_20675 : H12AffineEnvironment.transform 12 268 env20674 = env20675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20674 == env20675) = true)

theorem identity20675 : scanCanonicalize (H12AffineFastState.compose env20675 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound20675 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20676 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,16384,0,65536,82199,1297,1025,1,82966,32,17,2,268,17,1077,16401,69895,66582,66563,32,257,32,16384,513]

theorem envBound20676 : H12AffineFastState.Bounded env20676 := by
  intro p hp
  have h : env20676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20675_20676 : H12AffineEnvironment.transform 21 32 env20675 = env20676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env20675 == env20676) = true)

theorem identity20676 : scanCanonicalize (H12AffineFastState.compose env20676 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20676 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20677 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,16384,0,262,16401,1297,1025,1,17680,32,17,2,268,17,1077,16401,4097,1296,1285,32,257,32,16384,513]

theorem envBound20677 : H12AffineFastState.Bounded env20677 := by
  intro p hp
  have h : env20677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20676_20677 : H12AffineEnvironment.transform 15 262 env20676 = env20677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20676 == env20677) = true)

theorem identity20677 : scanCanonicalize (H12AffineFastState.compose env20677 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound20677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20678 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,1296,0,262,1281,1297,1025,1,0,32,17,2,268,17,1077,1281,4097,1296,1285,32,257,32,1296,513]

theorem envBound20678 : H12AffineFastState.Bounded env20678 := by
  intro p hp
  have h : env20678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20677_20678 : H12AffineEnvironment.transform 13 1296 env20677 = env20678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env20677 == env20678) = true)

theorem identity20678 : scanCanonicalize (H12AffineFastState.compose env20678 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound20678 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20679 : List Nat := [2,4,8,16,32,16,8,256,512,795,815,4096,268,523,0,262,538,522,794,1,0,32,17,2,268,17,814,538,4097,523,542,32,257,32,523,513]

theorem envBound20679 : H12AffineFastState.Bounded env20679 := by
  intro p hp
  have h : env20679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20678_20679 : H12AffineEnvironment.transform 9 795 env20678 = env20679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env20678 == env20679) = true)

theorem identity20679 : scanCanonicalize (H12AffineFastState.compose env20679 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20679 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20680 : List Nat := [2,4,8,16,32,16,8,5,512,542,554,4096,9,523,0,3,538,522,543,1,0,32,17,2,9,17,555,538,4097,523,542,32,4,32,523,513]

theorem envBound20680 : H12AffineFastState.Bounded env20680 := by
  intro p hp
  have h : env20680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20679_20680 : H12AffineEnvironment.transform 7 5 env20679 = env20680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20679 == env20680) = true)

theorem identity20680 : scanCanonicalize (H12AffineFastState.compose env20680 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20680 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20681 : List Nat := [2,4,8,16,32,16,8,5,512,542,554,17,9,523,0,3,538,522,543,1,0,32,17,2,9,17,555,538,16,523,542,32,4,32,523,513]

theorem envBound20681 : H12AffineFastState.Bounded env20681 := by
  intro p hp
  have h : env20681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20680_20681 : H12AffineEnvironment.transform 11 17 env20680 = env20681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20680 == env20681) = true)

theorem identity20681 : scanCanonicalize (H12AffineFastState.compose env20681 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound20681 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20682 : List Nat := [2,4,8,16,32,16,8,5,11,21,33,17,9,0,0,3,17,1,20,1,0,32,17,2,9,17,32,17,16,0,21,32,4,32,0,10]

theorem envBound20682 : H12AffineFastState.Bounded env20682 := by
  intro p hp
  have h : env20682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20681_20682 : H12AffineEnvironment.transform 8 11 env20681 = env20682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env20681 == env20682) = true)

theorem identity20682 : scanCanonicalize (H12AffineFastState.compose env20682 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20682 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20683 : List Nat := [2,4,8,16,0,16,8,5,11,21,1,17,9,0,0,3,17,1,20,1,0,0,17,2,9,17,0,17,16,0,21,0,4,0,0,10]

theorem envBound20683 : H12AffineFastState.Bounded env20683 := by
  intro p hp
  have h : env20683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20682_20683 : H12AffineEnvironment.transform 4 0 env20682 = env20683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20682 == env20683) = true)

theorem identity20683 : scanCanonicalize (H12AffineFastState.compose env20683 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound20683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20684 : List Nat := [2,4,8,14,0,14,8,5,11,11,1,15,9,0,0,3,15,1,10,1,0,0,15,2,9,15,0,15,14,0,11,0,4,0,0,10]

theorem envBound20684 : H12AffineFastState.Bounded env20684 := by
  intro p hp
  have h : env20684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20683_20684 : H12AffineEnvironment.transform 3 14 env20683 = env20684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env20683 == env20684) = true)

theorem identity20684 : scanCanonicalize (H12AffineFastState.compose env20684 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20684 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20685 : List Nat := [2,4,1,7,0,7,1,5,2,2,1,6,0,0,0,3,6,1,3,1,0,0,6,2,0,6,0,6,7,0,2,0,4,0,0,3]

theorem envBound20685 : H12AffineFastState.Bounded env20685 := by
  intro p hp
  have h : env20685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20684_20685 : H12AffineEnvironment.transform 2 1 env20684 = env20685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20684 == env20685) = true)

def env20686 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8461,65536,82198,9244,1025,8460,91419,4194304,17,2,8192,16,4195348,16401,77835,66583,75022,4194304,257,32,16385,513]

theorem envBound20686 : H12AffineFastState.Bounded env20686 := by
  intro p hp
  have h : env20686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20673_20686 : H12AffineEnvironment.transform 5 17 env20673 = env20686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20673 == env20686) = true)

theorem identity20686 : scanCanonicalize (H12AffineFastState.compose env20686 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound20686 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20687 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8461,263,16401,9244,1025,8460,25628,4194304,17,2,8192,16,4195348,16401,12556,1296,9225,4194304,257,32,16385,513]

theorem envBound20687 : H12AffineFastState.Bounded env20687 := by
  intro p hp
  have h : env20687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20686_20687 : H12AffineEnvironment.transform 15 263 env20686 = env20687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env20686 == env20687) = true)

theorem identity20687 : scanCanonicalize (H12AffineFastState.compose env20687 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound20687 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20688 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8461,263,16401,9244,1025,8460,25628,32,17,2,8192,16,1076,16401,12556,1296,9225,32,257,32,16385,513]

theorem envBound20688 : H12AffineFastState.Bounded env20688 := by
  intro p hp
  have h : env20688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20687_20688 : H12AffineEnvironment.transform 21 32 env20687 = env20688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env20687 == env20688) = true)

theorem identity20688 : scanCanonicalize (H12AffineFastState.compose env20688 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound20688 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20689 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,1076,8461,263,1061,9244,1025,8460,8232,32,17,2,8192,16,1076,1061,12556,1296,9225,32,257,32,1077,513]

theorem envBound20689 : H12AffineFastState.Bounded env20689 := by
  intro p hp
  have h : env20689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20688_20689 : H12AffineEnvironment.transform 13 1076 env20688 = env20689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env20688 == env20689) = true)

theorem identity20689 : scanCanonicalize (H12AffineFastState.compose env20689 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20689 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20690 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,269,1076,0,263,1061,1297,1025,1,293,32,17,2,269,16,1076,1061,4097,1296,1284,32,257,32,1077,513]

theorem envBound20690 : H12AffineFastState.Bounded env20690 := by
  intro p hp
  have h : env20690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20689_20690 : H12AffineEnvironment.transform 12 269 env20689 = env20690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20689 == env20690) = true)

theorem identity20690 : scanCanonicalize (H12AffineFastState.compose env20690 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20691 : List Nat := [2,4,8,16,32,17,8,256,512,53,0,4096,269,1,0,263,16,292,52,1,293,32,17,2,269,16,1,16,4097,293,305,32,257,32,0,513]

theorem envBound20691 : H12AffineFastState.Bounded env20691 := by
  intro p hp
  have h : env20691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20690_20691 : H12AffineEnvironment.transform 9 53 env20690 = env20691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20690 == env20691) = true)

theorem identity20691 : scanCanonicalize (H12AffineFastState.compose env20691 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound20691 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20692 : List Nat := [2,4,8,16,32,17,8,256,303,53,0,4096,269,1,0,263,16,292,52,1,293,32,17,2,269,16,1,16,4097,293,305,32,257,32,0,302]

theorem envBound20692 : H12AffineFastState.Bounded env20692 := by
  intro p hp
  have h : env20692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20691_20692 : H12AffineEnvironment.transform 8 303 env20691 = env20692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env20691 == env20692) = true)

theorem identity20692 : scanCanonicalize (H12AffineFastState.compose env20692 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound20692 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20693 : List Nat := [2,4,8,16,32,17,8,256,303,53,0,276,269,1,0,263,16,292,52,1,293,32,17,2,269,16,1,16,277,293,305,32,257,32,0,302]

theorem envBound20693 : H12AffineFastState.Bounded env20693 := by
  intro p hp
  have h : env20693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20692_20693 : H12AffineEnvironment.transform 11 276 env20692 = env20693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env20692 == env20693) = true)

def env20694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9292,1025,11576,92463,4194304,17,3175,8192,65,4408579,19572,81006,149861,75103,4194304,257,3141,16464,513]

theorem envBound20694 : H12AffineFastState.Bounded env20694 := by
  intro p hp
  have h : env20694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20670_20694 : H12AffineEnvironment.transform 14 11577 env20670 = env20694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env20670 == env20694) = true)

theorem identity20694 : scanCanonicalize (H12AffineFastState.compose env20694 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound20694 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env20695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,82247,9292,1025,11576,92463,4194304,17,3175,8192,65,4195396,19572,81006,67618,75103,4194304,257,3141,16464,513]

theorem envBound20695 : H12AffineFastState.Bounded env20695 := by
  intro p hp
  have h : env20695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20694_20695 : H12AffineEnvironment.transform 16 82247 env20694 = env20695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env20694 == env20695) = true)

def env20696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8541,65536,82247,9292,1025,8540,91467,4194304,17,3,8192,65,4195396,16400,77834,66630,75103,4194304,257,33,16464,513]

theorem envBound20696 : H12AffineFastState.Bounded env20696 := by
  intro p hp
  have h : env20696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20695_20696 : H12AffineEnvironment.transform 10 1124 env20695 = env20696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env20695 == env20696) = true)

theorem identity20696 : scanCanonicalize (H12AffineFastState.compose env20696 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound20696 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8541,28698,12637,9292,1025,8540,5457,4194304,17,3,8192,65,4195396,16400,16400,29788,21829,4194304,257,33,16464,513]

theorem envBound20697 : H12AffineFastState.Bounded env20697 := by
  intro p hp
  have h : env20697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20696_20697 : H12AffineEnvironment.transform 15 28698 env20696 = env20697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env20696 == env20697) = true)

theorem identity20697 : scanCanonicalize (H12AffineFastState.compose env20697 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20697 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0