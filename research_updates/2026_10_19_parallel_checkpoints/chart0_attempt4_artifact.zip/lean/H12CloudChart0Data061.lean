import H12CloudChart0Data060

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env15336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,372,1094,5173,2049,1024,373,4160,32,17,1127,1100,64,2128,5393,4097,2129,1365,1093,256,32,4405,513]

theorem envBound15336 : H12AffineFastState.Bounded env15336 := by
  intro p hp
  have h : env15336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15335_15336 : H12AffineEnvironment.transform 12 1100 env15335 = env15336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env15335 == env15336) = true)

theorem identity15336 : scanCanonicalize (H12AffineFastState.compose env15336 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15336 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env15337 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,40,4453,372,34,4177,2049,100,373,4160,32,17,3,40,64,2128,4469,4097,2129,305,33,256,32,4405,513]

theorem envBound15337 : H12AffineFastState.Bounded env15337 := by
  intro p hp
  have h : env15337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15336_15337 : H12AffineEnvironment.transform 9 100 env15336 = env15337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15336 == env15337) = true)

theorem identity15337 : scanCanonicalize (H12AffineFastState.compose env15337 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15337 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15338 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,4112,1,34,4177,2049,100,0,4160,32,17,3,40,64,2128,4096,4097,2129,68,33,117,32,4160,513]

theorem envBound15338 : H12AffineFastState.Bounded env15338 := by
  intro p hp
  have h : env15338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15337_15338 : H12AffineEnvironment.transform 7 117 env15337 = env15338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15337 == env15338) = true)

theorem identity15338 : scanCanonicalize (H12AffineFastState.compose env15338 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15338 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15339 : List Nat := [2,4,8,16,32,49,8,4,512,21,2048,4096,40,4112,1,34,4128,2049,21,0,4145,32,17,3,40,49,2081,4096,4097,2080,53,33,4,32,4145,513]

theorem envBound15339 : H12AffineFastState.Bounded env15339 := by
  intro p hp
  have h : env15339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15338_15339 : H12AffineEnvironment.transform 5 49 env15338 = env15339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15338 == env15339) = true)

theorem identity15339 : scanCanonicalize (H12AffineFastState.compose env15339 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound15339 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15340 : List Nat := [2,4,8,16,32,49,8,4,512,21,2048,2097,40,2081,1,34,2065,2049,21,0,2048,32,17,3,40,49,2081,2097,2096,2080,53,33,4,32,2048,513]

theorem envBound15340 : H12AffineFastState.Bounded env15340 := by
  intro p hp
  have h : env15340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15339_15340 : H12AffineEnvironment.transform 11 2097 env15339 = env15340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env15339 == env15340) = true)

theorem identity15340 : scanCanonicalize (H12AffineFastState.compose env15340 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound15340 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env15341 : List Nat := [2,4,8,16,32,49,8,4,512,21,560,513,40,529,1,34,545,561,21,0,560,32,17,3,40,49,529,513,512,528,53,33,4,32,560,513]

theorem envBound15341 : H12AffineFastState.Bounded env15341 := by
  intro p hp
  have h : env15341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15340_15341 : H12AffineEnvironment.transform 10 560 env15340 = env15341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env15340 == env15341) = true)

def env15342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,8388608,98645,8193,64,8787061,79131,8466459,8819968,8389956,98679,256,8462395,8492055,8462875]

theorem envBound15342 : H12AffineFastState.Bounded env15342 := by
  intro p hp
  have h : env15342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15320_15342 : H12AffineEnvironment.transform 6 9 env15320 = env15342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15320 == env15342) = true)

def env15343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,16,98645,8193,64,398437,79131,77835,431376,1364,98679,256,73771,103431,74251]

theorem envBound15343 : H12AffineFastState.Bounded env15343 := by
  intro p hp
  have h : env15343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15342_15343 : H12AffineEnvironment.transform 22 16 env15342 = env15343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15342 == env15343) = true)

theorem identity15343 : scanCanonicalize (H12AffineFastState.compose env15343 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15343 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41311,8193,64,398437,5393,4097,431376,1364,41341,256,33,46093,513]

theorem envBound15344 : H12AffineFastState.Bounded env15344 := by
  intro p hp
  have h : env15344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15343_15344 : H12AffineEnvironment.transform 15 8202 env15343 = env15344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15343 == env15344) = true)

theorem identity15344 : scanCanonicalize (H12AffineFastState.compose env15344 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15344 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,3,8193,64,398437,5393,4097,406604,1364,33,256,33,5457,513]

theorem envBound15345 : H12AffineFastState.Bounded env15345 := by
  intro p hp
  have h : env15345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15344_15345 : H12AffineEnvironment.transform 14 8540 env15344 = env15345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15344 == env15345) = true)

theorem identity15345 : scanCanonicalize (H12AffineFastState.compose env15345 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound15345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5441,262144,1024,8541,4161,32,16,3,8193,64,262436,5393,4097,270605,1364,33,256,33,5457,513]

theorem envBound15346 : H12AffineFastState.Bounded env15346 := by
  intro p hp
  have h : env15346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15345_15346 : H12AffineEnvironment.transform 16 5441 env15345 = env15346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env15345 == env15346) = true)

theorem identity15346 : scanCanonicalize (H12AffineFastState.compose env15346 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound15346 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5441,10361,1024,8541,4161,32,16,3,8193,64,10589,5393,4097,2420,1364,33,256,33,5457,513]

theorem envBound15347 : H12AffineFastState.Bounded env15347 := by
  intro p hp
  have h : env15347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15346_15347 : H12AffineEnvironment.transform 17 10361 env15346 = env15347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env15346 == env15347) = true)

theorem identity15347 : scanCanonicalize (H12AffineFastState.compose env15347 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15347 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,5393,10281,1024,8461,4113,32,16,3,8193,16,10509,5393,4097,2340,1284,33,256,33,5377,513]

theorem envBound15348 : H12AffineFastState.Bounded env15348 := by
  intro p hp
  have h : env15348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15347_15348 : H12AffineEnvironment.transform 5 16 env15347 = env15348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15347 == env15348) = true)

theorem identity15348 : scanCanonicalize (H12AffineFastState.compose env15348 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound15348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15349 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,8192,308,8460,8202,292,10281,1024,8461,1060,32,16,3,8193,16,10509,292,1076,2340,1284,33,256,33,308,513]

theorem envBound15349 : H12AffineFastState.Bounded env15349 := by
  intro p hp
  have h : env15349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15348_15349 : H12AffineEnvironment.transform 11 1077 env15348 = env15349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env15348 == env15349) = true)

theorem identity15349 : scanCanonicalize (H12AffineFastState.compose env15349 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound15349 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15350 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,2083,308,2351,2089,292,10,1024,2350,1060,32,16,3,2082,16,302,292,1076,2340,1284,33,256,33,308,513]

theorem envBound15350 : H12AffineFastState.Bounded env15350 := by
  intro p hp
  have h : env15350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15349_15350 : H12AffineEnvironment.transform 12 2083 env15349 = env15350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env15349 == env15350) = true)

theorem identity15350 : scanCanonicalize (H12AffineFastState.compose env15350 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound15350 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15351 : List Nat := [2,4,8,16,32,16,9,256,512,1024,302,1077,269,308,1,263,292,10,1024,0,1060,32,16,3,268,16,302,292,1076,10,1284,33,256,33,308,513]

theorem envBound15351 : H12AffineFastState.Bounded env15351 := by
  intro p hp
  have h : env15351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15350_15351 : H12AffineEnvironment.transform 10 302 env15350 = env15351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env15350 == env15351) = true)

theorem identity15351 : scanCanonicalize (H12AffineFastState.compose env15351 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound15351 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15352 : List Nat := [2,4,8,16,32,16,9,256,512,289,302,276,269,308,1,263,292,10,289,0,261,32,16,3,268,16,302,292,277,10,37,33,256,33,308,513]

theorem envBound15352 : H12AffineFastState.Bounded env15352 := by
  intro p hp
  have h : env15352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15351_15352 : H12AffineEnvironment.transform 9 289 env15351 = env15352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env15351 == env15352) = true)

theorem identity15352 : scanCanonicalize (H12AffineFastState.compose env15352 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound15352 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15353 : List Nat := [2,4,8,16,32,16,9,63,512,30,17,43,50,11,1,56,27,10,30,0,58,32,16,3,51,16,17,27,42,10,37,33,63,33,11,513]

theorem envBound15353 : H12AffineFastState.Bounded env15353 := by
  intro p hp
  have h : env15353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15352_15353 : H12AffineEnvironment.transform 7 63 env15352 = env15353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env15352 == env15353) = true)

theorem identity15353 : scanCanonicalize (H12AffineFastState.compose env15353 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15353 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env15354 : List Nat := [2,4,8,16,16,16,9,15,512,30,17,27,2,11,1,8,27,10,30,0,10,16,16,3,3,16,17,27,26,10,21,17,15,17,11,513]

theorem envBound15354 : H12AffineFastState.Bounded env15354 := by
  intro p hp
  have h : env15354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15353_15354 : H12AffineEnvironment.transform 4 16 env15353 = env15354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15353 == env15354) = true)

theorem identity15354 : scanCanonicalize (H12AffineFastState.compose env15354 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15354 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15355 : List Nat := [2,4,8,0,0,0,9,15,512,14,1,11,2,11,1,8,11,10,14,0,10,0,0,3,3,0,1,11,10,10,5,1,15,1,11,513]

theorem envBound15355 : H12AffineFastState.Bounded env15355 := by
  intro p hp
  have h : env15355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15354_15355 : H12AffineEnvironment.transform 3 0 env15354 = env15355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15354 == env15355) = true)

theorem identity15355 : scanCanonicalize (H12AffineFastState.compose env15355 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound15355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15356 : List Nat := [2,4,8,0,0,0,9,15,9,14,1,11,2,11,1,8,11,10,14,0,10,0,0,3,3,0,1,11,10,10,5,1,15,1,11,8]

theorem envBound15356 : H12AffineFastState.Bounded env15356 := by
  intro p hp
  have h : env15356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15355_15356 : H12AffineEnvironment.transform 8 9 env15355 = env15356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env15355 == env15356) = true)

theorem identity15356 : scanCanonicalize (H12AffineFastState.compose env15356 (packedSelected [12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15356 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env15357 : List Nat := [2,4,3,0,0,0,2,4,2,5,1,0,2,0,1,3,0,1,5,0,1,0,0,3,3,0,1,0,1,1,5,1,4,1,0,3]

theorem envBound15357 : H12AffineFastState.Bounded env15357 := by
  intro p hp
  have h : env15357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15356_15357 : H12AffineEnvironment.transform 2 3 env15356 = env15357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15356 == env15357) = true)

theorem identity15357 : scanCanonicalize (H12AffineFastState.compose env15357 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound15357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15358 : List Nat := [2,2,3,0,0,0,2,2,2,3,1,0,2,0,1,3,0,1,3,0,1,0,0,3,3,0,1,0,1,1,3,1,2,1,0,3]

theorem envBound15358 : H12AffineFastState.Bounded env15358 := by
  intro p hp
  have h : env15358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15357_15358 : H12AffineEnvironment.transform 1 2 env15357 = env15358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env15357 == env15358) = true)

def env15359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,17,98645,8193,64,398436,79131,77834,431377,1365,98679,256,73770,103430,74250]

theorem envBound15359 : H12AffineFastState.Bounded env15359 := by
  intro p hp
  have h : env15359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15342_15359 : H12AffineEnvironment.transform 22 17 env15342 = env15359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env15342 == env15359) = true)

theorem identity15359 : scanCanonicalize (H12AffineFastState.compose env15359 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound15359 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,77899,32,17,98645,8193,64,203847,79131,77834,236850,1365,98679,256,73770,103430,74250]

theorem envBound15360 : H12AffineFastState.Bounded env15360 := by
  intro p hp
  have h : env15360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15359_15360 : H12AffineEnvironment.transform 17 67619 env15359 = env15360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env15359 == env15360) = true)

theorem identity15360 : scanCanonicalize (H12AffineFastState.compose env15360 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound15360 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env15361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103495,67619,1024,32769,77899,32,17,98645,8193,64,34816,79131,77834,2421,1365,98679,256,73770,103430,74250]

theorem envBound15361 : H12AffineFastState.Bounded env15361 := by
  intro p hp
  have h : env15361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15360_15361 : H12AffineEnvironment.transform 16 103495 env15360 = env15361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env15360 == env15361) = true)

theorem identity15361 : scanCanonicalize (H12AffineFastState.compose env15361 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15361 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5393,35189,1024,32769,45341,32,17,3,8193,64,34816,46157,45404,2421,1365,33,256,41340,5456,41820]

theorem envBound15362 : H12AffineFastState.Bounded env15362 := by
  intro p hp
  have h : env15362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15361_15362 : H12AffineEnvironment.transform 15 33110 env15361 = env15362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15361 == env15362) = true)

theorem identity15362 : scanCanonicalize (H12AffineFastState.compose env15362 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound15362 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,32768,33110,5393,35189,1024,32769,37221,32,17,3,121,64,34816,37941,37156,2421,1365,33,256,33028,5456,33572]

theorem envBound15363 : H12AffineFastState.Bounded env15363 := by
  intro p hp
  have h : env15363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15362_15363 : H12AffineEnvironment.transform 12 120 env15362 = env15363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env15362 == env15363) = true)

theorem identity15363 : scanCanonicalize (H12AffineFastState.compose env15363 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15363 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,1,343,5393,2420,1024,0,4452,32,17,3,121,64,2049,5172,4389,2421,1365,33,256,261,5456,805]

theorem envBound15364 : H12AffineFastState.Bounded env15364 := by
  intro p hp
  have h : env15364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15363_15364 : H12AffineEnvironment.transform 14 1 env15363 = env15364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15363 == env15364) = true)

theorem identity15364 : scanCanonicalize (H12AffineFastState.compose env15364 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15364 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env15365 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,1,34,5220,2049,1024,0,4113,32,17,3,121,64,2049,5172,4176,2048,1056,33,117,112,5157,592]

theorem envBound15365 : H12AffineFastState.Bounded env15365 := by
  intro p hp
  have h : env15365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15364_15365 : H12AffineEnvironment.transform 7 117 env15364 = env15365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15364 == env15365) = true)

theorem identity15365 : scanCanonicalize (H12AffineFastState.compose env15365 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15365 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env15366 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,4096,120,5236,1,34,5220,1,1024,0,4113,32,17,3,121,64,1,5172,4176,0,1056,33,117,112,5157,592]

theorem envBound15366 : H12AffineFastState.Bounded env15366 := by
  intro p hp
  have h : env15366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15365_15366 : H12AffineEnvironment.transform 10 0 env15365 = env15366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15365 == env15366) = true)

theorem identity15366 : scanCanonicalize (H12AffineFastState.compose env15366 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound15366 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env15367 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,64,120,1076,1,34,1060,1,1024,0,81,32,17,3,121,64,1,1140,16,0,1056,33,117,112,1125,592]

theorem envBound15367 : H12AffineFastState.Bounded env15367 := by
  intro p hp
  have h : env15367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15366_15367 : H12AffineEnvironment.transform 11 64 env15366 = env15367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env15366 == env15367) = true)

def env15368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787060,79131,8466578,8819968,8389956,98678,256,8462395,8492190,8462994]

theorem envBound15368 : H12AffineFastState.Bounded env15368 := by
  intro p hp
  have h : env15368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15319_15368 : H12AffineEnvironment.transform 21 33 env15319 = env15368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15319 == env15368) = true)

theorem identity15368 : scanCanonicalize (H12AffineFastState.compose env15368 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound15368 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,16,98645,8328,64,398436,79131,77954,431376,1364,98678,256,73771,103566,74370]

theorem envBound15369 : H12AffineFastState.Bounded env15369 := by
  intro p hp
  have h : env15369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15368_15369 : H12AffineEnvironment.transform 22 16 env15368 = env15369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15368 == env15369) = true)

def env15370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,16,98645,8192,64,398436,79131,77834,431376,1364,98678,256,73771,103430,74250]

theorem envBound15370 : H12AffineFastState.Bounded env15370 := by
  intro p hp
  have h : env15370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15369_15370 : H12AffineEnvironment.transform 6 8 env15369 = env15370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15369 == env15370) = true)

theorem identity15370 : scanCanonicalize (H12AffineFastState.compose env15370 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound15370 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15371 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,45341,33,16,2,8192,64,398436,46156,45405,431376,1364,33,256,41340,5457,41821]

theorem envBound15371 : H12AffineFastState.Bounded env15371 := by
  intro p hp
  have h : env15371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15370_15371 : H12AffineEnvironment.transform 15 33111 env15370 = env15371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env15370 == env15371) = true)

theorem identity15371 : scanCanonicalize (H12AffineFastState.compose env15371 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound15371 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env15372 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,46157,262144,1024,32769,45341,33,16,2,8192,64,303145,46156,45405,270685,1364,33,256,41340,5457,41821]

theorem envBound15372 : H12AffineFastState.Bounded env15372 := by
  intro p hp
  have h : env15372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15371_15372 : H12AffineEnvironment.transform 16 46157 env15371 = env15372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env15371 == env15372) = true)

theorem identity15372 : scanCanonicalize (H12AffineFastState.compose env15372 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15372 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15373 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,262144,1024,8541,4161,33,16,2,8192,64,262517,5392,4097,270685,1364,33,256,32,5457,513]

theorem envBound15373 : H12AffineFastState.Bounded env15373 := by
  intro p hp
  have h : env15373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15372_15373 : H12AffineEnvironment.transform 14 8540 env15372 = env15373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15372 == env15373) = true)

theorem identity15373 : scanCanonicalize (H12AffineFastState.compose env15373 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound15373 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,10281,1024,8541,4161,33,16,2,8192,64,10588,5392,4097,2420,1364,33,256,32,5457,513]

theorem envBound15374 : H12AffineFastState.Bounded env15374 := by
  intro p hp
  have h : env15374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15373_15374 : H12AffineEnvironment.transform 17 10281 env15373 = env15374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15373 == env15374) = true)

theorem identity15374 : scanCanonicalize (H12AffineFastState.compose env15374 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound15374 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5377,341,2,5393,2080,1024,340,4161,33,16,2,9,64,2389,5392,4097,2420,1364,33,256,32,5457,513]

theorem envBound15375 : H12AffineFastState.Bounded env15375 := by
  intro p hp
  have h : env15375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15374_15375 : H12AffineEnvironment.transform 12 9 env15374 = env15375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env15374 == env15375) = true)

theorem identity15375 : scanCanonicalize (H12AffineFastState.compose env15375 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15375 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15376 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,9,4112,341,2,4096,2080,273,340,4161,33,16,2,9,64,2389,4097,4097,2420,69,33,256,32,4160,513]

theorem envBound15376 : H12AffineFastState.Bounded env15376 := by
  intro p hp
  have h : env15376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15375_15376 : H12AffineEnvironment.transform 9 273 env15375 = env15376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15375 == env15376) = true)

theorem identity15376 : scanCanonicalize (H12AffineFastState.compose env15376 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound15376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15377 : List Nat := [2,4,8,16,32,64,8,100,512,117,2048,4096,9,4112,49,2,4096,2080,117,48,4161,33,16,2,9,64,2097,4097,4097,2064,69,33,100,32,4160,513]

theorem envBound15377 : H12AffineFastState.Bounded env15377 := by
  intro p hp
  have h : env15377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15376_15377 : H12AffineEnvironment.transform 7 100 env15376 = env15377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env15376 == env15377) = true)

theorem identity15377 : scanCanonicalize (H12AffineFastState.compose env15377 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound15377 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15378 : List Nat := [2,4,8,16,32,64,8,100,512,117,2048,529,9,513,49,2,529,2080,117,48,592,33,16,2,9,64,2097,528,528,2064,69,33,100,32,593,513]

theorem envBound15378 : H12AffineFastState.Bounded env15378 := by
  intro p hp
  have h : env15378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15377_15378 : H12AffineEnvironment.transform 11 529 env15377 = env15378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env15377 == env15378) = true)

theorem identity15378 : scanCanonicalize (H12AffineFastState.compose env15378 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound15378 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env15379 : List Nat := [2,4,8,16,32,64,8,100,512,117,608,529,9,513,49,2,529,576,117,48,592,33,16,2,9,64,593,528,528,624,69,33,100,32,593,513]

theorem envBound15379 : H12AffineFastState.Bounded env15379 := by
  intro p hp
  have h : env15379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15378_15379 : H12AffineEnvironment.transform 10 608 env15378 = env15379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env15378 == env15379) = true)

theorem identity15379 : scanCanonicalize (H12AffineFastState.compose env15379 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15379 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env15380 : List Nat := [2,4,8,16,32,17,8,53,512,36,561,529,9,513,49,2,529,529,36,48,513,33,16,2,9,17,512,528,528,545,20,33,53,32,512,513]

theorem envBound15380 : H12AffineFastState.Bounded env15380 := by
  intro p hp
  have h : env15380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15379_15380 : H12AffineEnvironment.transform 5 17 env15379 = env15380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15379 == env15380) = true)

theorem identity15380 : scanCanonicalize (H12AffineFastState.compose env15380 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound15380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15381 : List Nat := [2,4,8,16,32,17,8,53,17,36,32,0,9,16,49,2,0,0,36,48,16,33,16,2,9,17,17,1,1,48,20,33,53,32,17,16]

theorem envBound15381 : H12AffineFastState.Bounded env15381 := by
  intro p hp
  have h : env15381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15380_15381 : H12AffineEnvironment.transform 8 17 env15380 = env15381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env15380 == env15381) = true)

theorem identity15381 : scanCanonicalize (H12AffineFastState.compose env15381 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15381 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15382 : List Nat := [2,4,8,16,0,17,8,21,17,4,0,0,9,16,17,2,0,0,4,16,16,1,16,2,9,17,17,1,1,16,20,1,21,0,17,16]

theorem envBound15382 : H12AffineFastState.Bounded env15382 := by
  intro p hp
  have h : env15382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15381_15382 : H12AffineEnvironment.transform 4 0 env15381 = env15382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15381 == env15382) = true)

theorem identity15382 : scanCanonicalize (H12AffineFastState.compose env15382 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15383 : List Nat := [2,4,8,0,0,1,8,5,1,4,0,0,9,0,1,2,0,0,4,0,0,1,0,2,9,1,1,1,1,0,4,1,5,0,1,0]

theorem envBound15383 : H12AffineFastState.Bounded env15383 := by
  intro p hp
  have h : env15383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15382_15383 : H12AffineEnvironment.transform 3 0 env15382 = env15383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15382 == env15383) = true)

def env15384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,33,16,98645,8193,64,398436,79131,77835,431376,1364,98678,256,73771,103431,74251]

theorem envBound15384 : H12AffineFastState.Bounded env15384 := by
  intro p hp
  have h : env15384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15369_15384 : H12AffineEnvironment.transform 6 9 env15369 = env15384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15369 == env15384) = true)

theorem identity15384 : scanCanonicalize (H12AffineFastState.compose env15384 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41311,8193,64,398436,5393,4097,431376,1364,41340,256,33,46093,513]

theorem envBound15385 : H12AffineFastState.Bounded env15385 := by
  intro p hp
  have h : env15385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15384_15385 : H12AffineEnvironment.transform 15 8202 env15384 = env15385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15384 == env15385) = true)

theorem identity15385 : scanCanonicalize (H12AffineFastState.compose env15385 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15385 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,3,8193,64,398436,5393,4097,406604,1364,32,256,33,5457,513]

theorem envBound15386 : H12AffineFastState.Bounded env15386 := by
  intro p hp
  have h : env15386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15385_15386 : H12AffineEnvironment.transform 14 8540 env15385 = env15386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15385 == env15386) = true)

theorem identity15386 : scanCanonicalize (H12AffineFastState.compose env15386 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound15386 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5441,262144,1024,8541,4161,33,16,3,8193,64,262437,5393,4097,270605,1364,32,256,33,5457,513]

theorem envBound15387 : H12AffineFastState.Bounded env15387 := by
  intro p hp
  have h : env15387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15386_15387 : H12AffineEnvironment.transform 16 5441 env15386 = env15387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env15386 == env15387) = true)

theorem identity15387 : scanCanonicalize (H12AffineFastState.compose env15387 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound15387 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5441,2421,1024,8541,4161,33,16,3,8193,64,2128,5393,4097,10360,1364,32,256,33,5457,513]

theorem envBound15388 : H12AffineFastState.Bounded env15388 := by
  intro p hp
  have h : env15388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15387_15388 : H12AffineEnvironment.transform 17 2421 env15387 = env15388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env15387 == env15388) = true)

theorem identity15388 : scanCanonicalize (H12AffineFastState.compose env15388 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15388 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5441,2421,1024,0,4161,33,16,3,348,64,2128,5393,4097,2341,1364,32,256,33,5457,513]

theorem envBound15389 : H12AffineFastState.Bounded env15389 := by
  intro p hp
  have h : env15389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15388_15389 : H12AffineEnvironment.transform 12 349 env15388 = env15389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15388 == env15389) = true)

theorem identity15389 : scanCanonicalize (H12AffineFastState.compose env15389 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15389 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15390 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1024,0,4112,33,16,3,269,17,2049,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound15390 : H12AffineFastState.Bounded env15390 := by
  intro p hp
  have h : env15390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15389_15390 : H12AffineEnvironment.transform 5 17 env15389 = env15390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15389 == env15390) = true)

theorem identity15390 : scanCanonicalize (H12AffineFastState.compose env15390 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15390 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15391 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2048,1024,0,4112,33,16,3,41,17,2049,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound15391 : H12AffineFastState.Bounded env15391 := by
  intro p hp
  have h : env15391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15390_15391 : H12AffineEnvironment.transform 7 36 env15390 = env15391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15390 == env15391) = true)

theorem identity15391 : scanCanonicalize (H12AffineFastState.compose env15391 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15391 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15392 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4113,1,34,4096,2048,52,0,4112,33,16,3,41,17,2049,4097,4097,2049,21,32,36,33,4112,513]

theorem envBound15392 : H12AffineFastState.Bounded env15392 := by
  intro p hp
  have h : env15392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15391_15392 : H12AffineEnvironment.transform 9 52 env15391 = env15392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15391 == env15392) = true)

theorem identity15392 : scanCanonicalize (H12AffineFastState.compose env15392 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound15392 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15393 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,33,40,48,1,34,33,2048,52,0,49,33,16,3,41,17,2049,32,32,2049,21,32,36,33,49,513]

theorem envBound15393 : H12AffineFastState.Bounded env15393 := by
  intro p hp
  have h : env15393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15392_15393 : H12AffineEnvironment.transform 11 33 env15392 = env15393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env15392 == env15393) = true)

theorem identity15393 : scanCanonicalize (H12AffineFastState.compose env15393 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound15393 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15394 : List Nat := [2,4,8,16,32,17,9,36,512,52,32,33,40,48,1,34,33,32,52,0,49,33,16,3,41,17,33,32,32,33,21,32,36,33,49,513]

theorem envBound15394 : H12AffineFastState.Bounded env15394 := by
  intro p hp
  have h : env15394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15393_15394 : H12AffineEnvironment.transform 10 32 env15393 = env15394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env15393 == env15394) = true)

theorem identity15394 : scanCanonicalize (H12AffineFastState.compose env15394 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15394 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15395 : List Nat := [2,4,8,1,32,0,9,36,512,37,32,33,40,33,1,34,33,32,37,0,32,33,1,3,41,0,33,32,32,33,4,32,36,33,32,513]

theorem envBound15395 : H12AffineFastState.Bounded env15395 := by
  intro p hp
  have h : env15395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15394_15395 : H12AffineEnvironment.transform 3 1 env15394 = env15395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15394 == env15395) = true)

def env15396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119893,8328,64,12981332,79130,8466578,8830977,8409156,4314199,256,8484155,8492191,8484754]

theorem envBound15396 : H12AffineFastState.Bounded env15396 := by
  intro p hp
  have h : env15396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15280_15396 : H12AffineEnvironment.transform 23 119893 env15280 = env15396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119893 env15280 == env15396) = true)

def env15397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981332,79130,8466578,8819969,8389956,4292951,256,8462395,8492191,8462994]

theorem envBound15397 : H12AffineFastState.Bounded env15397 := by
  intro p hp
  have h : env15397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15396_15397 : H12AffineEnvironment.transform 13 5376 env15396 = env15397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15396 == env15397) = true)

def env15398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787060,79130,8466578,8819969,8389956,98679,256,8462395,8492191,8462994]

theorem envBound15398 : H12AffineFastState.Bounded env15398 := by
  intro p hp
  have h : env15398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15397_15398 : H12AffineEnvironment.transform 21 32 env15397 = env15398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15397 == env15398) = true)

theorem identity15398 : scanCanonicalize (H12AffineFastState.compose env15398 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound15398 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,73875,98645,8328,64,472295,79130,4097,505234,75223,98679,256,168,46092,513]

theorem envBound15399 : H12AffineFastState.Bounded env15399 := by
  intro p hp
  have h : env15399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15398_15399 : H12AffineEnvironment.transform 22 73875 env15398 = env15399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env15398 == env15399) = true)

def env15400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,73755,98645,8192,64,472175,79130,4097,505114,75103,98679,256,32,46092,513]

theorem envBound15400 : H12AffineFastState.Bounded env15400 := by
  intro p hp
  have h : env15400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15399_15400 : H12AffineEnvironment.transform 6 8 env15399 = env15400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15399 == env15400) = true)

theorem identity15400 : scanCanonicalize (H12AffineFastState.compose env15400 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound15400 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79131,262144,1024,32769,77899,32,73755,98645,8192,64,262516,79130,4097,294913,75103,98679,256,32,46092,513]

theorem envBound15401 : H12AffineFastState.Bounded env15401 := by
  intro p hp
  have h : env15401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15400_15401 : H12AffineEnvironment.transform 16 79131 env15400 = env15401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env15400 == env15401) = true)

theorem identity15401 : scanCanonicalize (H12AffineFastState.compose env15401 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound15401 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,9292,65536,79131,262144,1024,9293,77899,32,73755,75033,8192,64,262516,79130,4097,271437,75103,75067,256,32,4160,513]

theorem envBound15402 : H12AffineFastState.Bounded env15402 := by
  intro p hp
  have h : env15402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15401_15402 : H12AffineEnvironment.transform 14 9292 env15401 = env15402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env15401 == env15402) = true)

theorem identity15402 : scanCanonicalize (H12AffineFastState.compose env15402 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound15402 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env15403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,372,65536,69667,262144,1024,373,71027,32,66851,65569,1336,64,262516,69666,4097,262517,65639,65539,256,32,4160,513]

theorem envBound15403 : H12AffineFastState.Bounded env15403 := by
  intro p hp
  have h : env15403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15402_15403 : H12AffineEnvironment.transform 12 1336 env15402 = env15403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env15402 == env15403) = true)

theorem identity15403 : scanCanonicalize (H12AffineFastState.compose env15403 (packedSelected [3,5,10,18,21,32] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound15403 : packedSelected [3,5,10,18,21,32] rootPS < 2^1333 := by decide +kernel

def env15404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,372,65536,69667,3124,1024,373,71027,32,66851,65569,1336,64,3392,69666,4097,3393,65639,65539,256,32,4160,513]

theorem envBound15404 : H12AffineFastState.Bounded env15404 := by
  intro p hp
  have h : env15404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15403_15404 : H12AffineEnvironment.transform 17 3124 env15403 = env15404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env15403 == env15404) = true)

theorem identity15404 : scanCanonicalize (H12AffineFastState.compose env15404 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound15404 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env15405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,372,263,4388,3124,1024,373,5236,32,1060,294,1336,64,3392,4389,4097,3393,352,260,256,32,4160,513]

theorem envBound15405 : H12AffineFastState.Bounded env15405 := by
  intro p hp
  have h : env15405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15404_15405 : H12AffineEnvironment.transform 15 263 env15404 = env15405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env15404 == env15405) = true)

theorem identity15405 : scanCanonicalize (H12AffineFastState.compose env15405 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound15405 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,885,1336,1653,372,263,593,3124,1024,373,1793,32,1060,294,1336,64,3392,592,884,3393,352,260,256,32,821,513]

theorem envBound15406 : H12AffineFastState.Bounded env15406 := by
  intro p hp
  have h : env15406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15405_15406 : H12AffineEnvironment.transform 11 885 env15405 = env15406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env15405 == env15406) = true)

theorem identity15406 : scanCanonicalize (H12AffineFastState.compose env15406 (packedSelected [0,1,2,4,5,6,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15406 : packedSelected [0,1,2,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env15407 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,885,348,529,372,263,593,2128,100,373,869,32,64,294,348,64,2340,592,884,2341,352,260,256,32,821,513]

theorem envBound15407 : H12AffineFastState.Bounded env15407 := by
  intro p hp
  have h : env15407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15406_15407 : H12AffineEnvironment.transform 9 100 env15406 = env15407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15406 == env15407) = true)

theorem identity15407 : scanCanonicalize (H12AffineFastState.compose env15407 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15407 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env15408 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,593,120,529,80,35,593,2128,100,81,577,32,64,2,120,64,2048,592,592,2049,68,32,36,32,529,513]

theorem envBound15408 : H12AffineFastState.Bounded env15408 := by
  intro p hp
  have h : env15408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15407_15408 : H12AffineEnvironment.transform 7 36 env15407 = env15408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15407 == env15408) = true)

def env15409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98645,8193,64,472174,79130,4097,505115,75102,98679,256,33,46092,513]

theorem envBound15409 : H12AffineFastState.Bounded env15409 := by
  intro p hp
  have h : env15409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15399_15409 : H12AffineEnvironment.transform 6 9 env15399 = env15409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15399 == env15409) = true)

theorem identity15409 : scanCanonicalize (H12AffineFastState.compose env15409 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15409 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,45340,32,41292,3,8193,64,439608,46156,4097,406605,41992,33,256,33,46092,513]

theorem envBound15410 : H12AffineFastState.Bounded env15410 := by
  intro p hp
  have h : env15410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15409_15410 : H12AffineEnvironment.transform 15 33110 env15409 = env15410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15409 == env15410) = true)

theorem identity15410 : scanCanonicalize (H12AffineFastState.compose env15410 (packedSelected [2,6,21] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound15410 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env15411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,46108,262144,1024,32769,45340,32,41292,3,8193,64,262436,46156,4097,294993,41992,33,256,33,46092,513]

theorem envBound15411 : H12AffineFastState.Bounded env15411 := by
  intro p hp
  have h : env15411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15410_15411 : H12AffineEnvironment.transform 16 46108 env15410 = env15411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env15410 == env15411) = true)

theorem identity15411 : scanCanonicalize (H12AffineFastState.compose env15411 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15411 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env15412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,343,13341,262144,1024,0,12573,32,8525,3,8193,64,262436,13389,4097,262224,9225,33,256,33,13325,513]

theorem envBound15412 : H12AffineFastState.Bounded env15412 := by
  intro p hp
  have h : env15412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15411_15412 : H12AffineEnvironment.transform 14 1 env15411 = env15412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15411 == env15412) = true)

theorem identity15412 : scanCanonicalize (H12AffineFastState.compose env15412 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound15412 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,343,13341,2420,1024,0,12573,32,8525,3,8193,64,2128,13389,4097,2340,9225,33,256,33,13325,513]

theorem envBound15413 : H12AffineFastState.Bounded env15413 := by
  intro p hp
  have h : env15413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15412_15413 : H12AffineEnvironment.transform 17 2420 env15412 = env15413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env15412 == env15413) = true)

theorem identity15413 : scanCanonicalize (H12AffineFastState.compose env15413 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15413 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,343,5393,2420,1024,0,4113,32,65,3,269,64,2128,5441,4097,2340,1285,33,256,33,5377,513]

theorem envBound15414 : H12AffineFastState.Bounded env15414 := by
  intro p hp
  have h : env15414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15413_15414 : H12AffineEnvironment.transform 12 268 env15413 = env15414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15413 == env15414) = true)

theorem identity15414 : scanCanonicalize (H12AffineFastState.compose env15414 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound15414 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env15415 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,268,4160,1,343,4177,2420,320,0,4113,32,65,3,269,64,2128,4097,4097,2340,69,33,256,33,4161,513]

theorem envBound15415 : H12AffineFastState.Bounded env15415 := by
  intro p hp
  have h : env15415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15414_15415 : H12AffineEnvironment.transform 9 320 env15414 = env15415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env15414 == env15415) = true)

theorem identity15415 : scanCanonicalize (H12AffineFastState.compose env15415 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15415 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15416 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4113,1,262,4096,2341,273,0,4113,32,16,3,269,17,2049,4097,4097,2340,20,33,256,33,4112,513]

theorem envBound15416 : H12AffineFastState.Bounded env15416 := by
  intro p hp
  have h : env15416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15415_15416 : H12AffineEnvironment.transform 5 17 env15415 = env15416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15415 == env15416) = true)

theorem identity15416 : scanCanonicalize (H12AffineFastState.compose env15416 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15417 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4113,1,35,4096,2048,52,0,4113,32,16,3,40,17,2049,4097,4097,2049,20,33,37,33,4112,513]

theorem envBound15417 : H12AffineFastState.Bounded env15417 := by
  intro p hp
  have h : env15417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15416_15417 : H12AffineEnvironment.transform 7 37 env15416 = env15417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15416 == env15417) = true)

theorem identity15417 : scanCanonicalize (H12AffineFastState.compose env15417 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound15417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15418 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,41,32,1,35,49,2048,52,0,32,32,16,3,40,17,2049,48,48,2049,20,33,37,33,33,513]

theorem envBound15418 : H12AffineFastState.Bounded env15418 := by
  intro p hp
  have h : env15418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15417_15418 : H12AffineEnvironment.transform 11 49 env15417 = env15418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env15417 == env15418) = true)

theorem identity15418 : scanCanonicalize (H12AffineFastState.compose env15418 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound15418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15419 : List Nat := [2,4,8,16,32,17,9,37,33,52,2048,49,41,32,1,35,49,2048,52,0,32,32,16,3,40,17,2049,48,48,2049,20,33,37,33,33,32]

theorem envBound15419 : H12AffineFastState.Bounded env15419 := by
  intro p hp
  have h : env15419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15418_15419 : H12AffineEnvironment.transform 8 33 env15418 = env15419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15418 == env15419) = true)

theorem identity15419 : scanCanonicalize (H12AffineFastState.compose env15419 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound15419 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15420 : List Nat := [2,4,8,16,32,17,9,37,33,52,33,49,41,32,1,35,49,33,52,0,32,32,16,3,40,17,32,48,48,32,20,33,37,33,33,32]

theorem envBound15420 : H12AffineFastState.Bounded env15420 := by
  intro p hp
  have h : env15420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15419_15420 : H12AffineEnvironment.transform 10 33 env15419 = env15420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env15419 == env15420) = true)

def env15421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787061,79130,8466578,8819969,8389956,98678,256,8462395,8492191,8462994]

theorem envBound15421 : H12AffineFastState.Bounded env15421 := by
  intro p hp
  have h : env15421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15397_15421 : H12AffineEnvironment.transform 21 33 env15397 = env15421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15397 == env15421) = true)

theorem identity15421 : scanCanonicalize (H12AffineFastState.compose env15421 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound15421 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,4160,33,8388608,41430,8328,64,8787061,5529,8392721,8819969,8389956,41461,256,8388792,8434716,8389137]

theorem envBound15422 : H12AffineFastState.Bounded env15422 := by
  intro p hp
  have h : env15422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15421_15422 : H12AffineEnvironment.transform 15 8323 env15421 = env15422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env15421 == env15422) = true)

def env15423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,262144,1024,32769,4160,33,8388608,41430,8328,64,8651061,5529,8392721,8683585,8389956,41461,256,8388792,8434716,8389137]

theorem envBound15423 : H12AffineFastState.Bounded env15423 := by
  intro p hp
  have h : env15423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15422_15423 : H12AffineEnvironment.transform 16 5440 env15422 = env15423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env15422 == env15423) = true)

theorem identity15423 : scanCanonicalize (H12AffineFastState.compose env15423 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound15423 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,35245,1024,32769,4160,33,8388608,41430,8328,64,8423576,5529,8392721,8391148,8389956,41461,256,8388792,8434716,8389137]

theorem envBound15424 : H12AffineFastState.Bounded env15424 := by
  intro p hp
  have h : env15424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15423_15424 : H12AffineEnvironment.transform 17 35245 env15423 = env15424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env15423 == env15424) = true)

theorem identity15424 : scanCanonicalize (H12AffineFastState.compose env15424 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 41244) := by decide +kernel

theorem selectedBound15424 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env15425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,35245,1024,32769,4160,33,41244,41430,8328,64,10628,5529,45325,43248,42072,41461,256,41380,5376,41741]

theorem envBound15425 : H12AffineFastState.Bounded env15425 := by
  intro p hp
  have h : env15425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15424_15425 : H12AffineEnvironment.transform 22 41244 env15424 = env15425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41244 env15424 == env15425) = true)

theorem identity15425 : scanCanonicalize (H12AffineFastState.compose env15425 (packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound15425 : packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS < 2^1333 := by decide +kernel

def env15426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,81,8323,5440,2556,1024,80,4160,33,8525,8583,8328,64,10628,5529,12636,10401,9225,8612,256,8693,5376,9052]

theorem envBound15426 : H12AffineFastState.Bounded env15426 := by
  intro p hp
  have h : env15426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15425_15426 : H12AffineEnvironment.transform 14 81 env15425 = env15426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env15425 == env15426) = true)

theorem identity15426 : scanCanonicalize (H12AffineFastState.compose env15426 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15426 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env15427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,8202,5440,2421,1024,80,4160,33,8525,8462,8193,64,10509,5392,12636,10280,9225,8493,256,8572,5376,9052]

theorem envBound15427 : H12AffineFastState.Bounded env15427 := by
  intro p hp
  have h : env15427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15426_15427 : H12AffineEnvironment.transform 6 9 env15426 = env15427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15426 == env15427) = true)

def env15428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,262144,1024,32769,4160,33,8388608,41430,8328,64,8651060,5529,8392721,8683584,8389956,41461,256,8388792,8434716,8389137]

theorem envBound15428 : H12AffineFastState.Bounded env15428 := by
  intro p hp
  have h : env15428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15422_15428 : H12AffineEnvironment.transform 16 5441 env15422 = env15428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env15422 == env15428) = true)

theorem identity15428 : scanCanonicalize (H12AffineFastState.compose env15428 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound15428 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,35108,1024,32769,4160,33,8388608,41430,8328,64,8423440,5529,8392721,8391012,8389956,41461,256,8388792,8434716,8389137]

theorem envBound15429 : H12AffineFastState.Bounded env15429 := by
  intro p hp
  have h : env15429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15428_15429 : H12AffineEnvironment.transform 17 35108 env15428 = env15429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env15428 == env15429) = true)

theorem identity15429 : scanCanonicalize (H12AffineFastState.compose env15429 (packedSelected [4,5,7,8,9,10,16,18,20,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound15429 : packedSelected [4,5,7,8,9,10,16,18,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env15430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,80,8323,5441,2420,1024,81,4160,33,8388608,8582,8328,64,8390720,5529,8392721,8391012,8389956,8613,256,8388792,8401996,8389137]

theorem envBound15430 : H12AffineFastState.Bounded env15430 := by
  intro p hp
  have h : env15430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15429_15430 : H12AffineEnvironment.transform 14 80 env15429 = env15430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env15429 == env15430) = true)

theorem identity15430 : scanCanonicalize (H12AffineFastState.compose env15430 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15430 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,80,399,5441,2420,1024,81,4160,33,8388608,138,388,64,8390720,5529,8392721,8391012,8389956,169,256,8388792,8394048,8389137]

theorem envBound15431 : H12AffineFastState.Bounded env15431 := by
  intro p hp
  have h : env15431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15430_15431 : H12AffineEnvironment.transform 12 268 env15430 = env15431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15430 == env15431) = true)

theorem identity15431 : scanCanonicalize (H12AffineFastState.compose env15431 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(22+1) ^^^ 201) := by decide +kernel

theorem selectedBound15431 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env15432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,80,399,5441,2420,1024,81,4160,33,201,138,388,64,2185,5529,4312,2477,1421,169,256,113,5513,728]

theorem envBound15432 : H12AffineFastState.Bounded env15432 := by
  intro p hp
  have h : env15432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15431_15432 : H12AffineEnvironment.transform 22 201 env15431 = env15432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 201 env15431 == env15432) = true)

theorem identity15432 : scanCanonicalize (H12AffineFastState.compose env15432 (packedSelected [0,1,3,5,7,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound15432 : packedSelected [0,1,3,5,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15433 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,268,4161,80,399,4096,2420,321,81,4160,33,201,138,388,64,2185,4312,4312,2477,204,169,256,113,4296,728]

theorem envBound15433 : H12AffineFastState.Bounded env15433 := by
  intro p hp
  have h : env15433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15432_15433 : H12AffineEnvironment.transform 9 321 env15432 = env15433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env15432 == env15433) = true)

theorem identity15433 : scanCanonicalize (H12AffineFastState.compose env15433 (packedSelected [0,1,2,4,5,6,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound15433 : packedSelected [0,1,2,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env15434 : List Nat := [2,4,8,16,32,64,89,256,512,321,2048,4096,268,4161,80,342,4096,2420,321,81,4160,33,16,83,349,64,2128,4097,4097,2420,21,112,256,113,4113,513]

theorem envBound15434 : H12AffineFastState.Bounded env15434 := by
  intro p hp
  have h : env15434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15433_15434 : H12AffineEnvironment.transform 6 89 env15433 = env15434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env15433 == env15434) = true)

theorem identity15434 : scanCanonicalize (H12AffineFastState.compose env15434 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15434 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15435 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,4112,1,263,4096,2341,272,0,4113,33,16,2,268,17,2049,4097,4097,2341,21,33,256,32,4113,513]

theorem envBound15435 : H12AffineFastState.Bounded env15435 := by
  intro p hp
  have h : env15435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15434_15435 : H12AffineEnvironment.transform 5 17 env15434 = env15435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15434 == env15435) = true)

theorem identity15435 : scanCanonicalize (H12AffineFastState.compose env15435 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15436 : List Nat := [2,4,8,16,16,17,8,256,512,272,2048,4096,268,4112,1,263,4096,2325,272,0,4113,17,16,2,268,17,2049,4097,4097,2325,21,17,256,16,4113,513]

theorem envBound15436 : H12AffineFastState.Bounded env15436 := by
  intro p hp
  have h : env15436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15435_15436 : H12AffineEnvironment.transform 4 16 env15435 = env15436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15435 == env15436) = true)

theorem identity15436 : scanCanonicalize (H12AffineFastState.compose env15436 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound15436 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15437 : List Nat := [2,4,8,16,16,17,8,256,512,272,2048,772,268,788,1,263,772,2325,272,0,789,17,16,2,268,17,2049,773,773,2325,21,17,256,16,789,513]

theorem envBound15437 : H12AffineFastState.Bounded env15437 := by
  intro p hp
  have h : env15437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15436_15437 : H12AffineEnvironment.transform 11 772 env15436 = env15437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env15436 == env15437) = true)

theorem identity15437 : scanCanonicalize (H12AffineFastState.compose env15437 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15437 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15438 : List Nat := [2,4,8,16,16,17,8,5,512,21,2048,513,9,529,1,2,513,2064,21,0,528,17,16,2,9,17,2049,512,512,2064,21,17,5,16,528,513]

theorem envBound15438 : H12AffineFastState.Bounded env15438 := by
  intro p hp
  have h : env15438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15437_15438 : H12AffineEnvironment.transform 7 5 env15437 = env15438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15437 == env15438) = true)

theorem identity15438 : scanCanonicalize (H12AffineFastState.compose env15438 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound15438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15439 : List Nat := [2,4,8,16,16,17,8,5,512,21,528,513,9,529,1,2,513,512,21,0,528,17,16,2,9,17,529,512,512,512,21,17,5,16,528,513]

theorem envBound15439 : H12AffineFastState.Bounded env15439 := by
  intro p hp
  have h : env15439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15438_15439 : H12AffineEnvironment.transform 10 528 env15438 = env15439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env15438 == env15439) = true)

theorem identity15439 : scanCanonicalize (H12AffineFastState.compose env15439 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15439 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15440 : List Nat := [2,4,8,16,16,17,8,5,0,21,16,1,9,17,1,2,1,0,21,0,16,17,16,2,9,17,17,0,0,0,21,17,5,16,16,1]

theorem envBound15440 : H12AffineFastState.Bounded env15440 := by
  intro p hp
  have h : env15440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15439_15440 : H12AffineEnvironment.transform 8 0 env15439 = env15440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15439 == env15440) = true)

theorem identity15440 : scanCanonicalize (H12AffineFastState.compose env15440 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15440 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15441 : List Nat := [2,4,8,1,1,0,8,5,0,4,1,1,9,0,1,2,1,0,4,0,1,0,1,2,9,0,0,0,0,0,4,0,5,1,1,1]

theorem envBound15441 : H12AffineFastState.Bounded env15441 := by
  intro p hp
  have h : env15441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15440_15441 : H12AffineEnvironment.transform 3 1 env15440 = env15441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15440 == env15441) = true)

def env15442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981332,79130,8466578,8819968,8389957,4292950,256,8462394,8492191,8462995]

theorem envBound15442 : H12AffineFastState.Bounded env15442 := by
  intro p hp
  have h : env15442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15396_15442 : H12AffineEnvironment.transform 13 5377 env15396 = env15442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15396 == env15442) = true)

def env15443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787060,79130,8466578,8819968,8389957,98678,256,8462394,8492191,8462995]

theorem envBound15443 : H12AffineFastState.Bounded env15443 := by
  intro p hp
  have h : env15443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15442_15443 : H12AffineEnvironment.transform 21 32 env15442 = env15443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15442 == env15443) = true)

theorem identity15443 : scanCanonicalize (H12AffineFastState.compose env15443 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound15443 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,98766,98644,8328,64,497082,79130,45404,464078,99467,98678,256,41460,5457,41821]

theorem envBound15444 : H12AffineFastState.Bounded env15444 := by
  intro p hp
  have h : env15444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15443_15444 : H12AffineEnvironment.transform 22 98766 env15443 = env15444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env15443 == env15444) = true)

theorem identity15444 : scanCanonicalize (H12AffineFastState.compose env15444 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15444 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,78018,32,73874,73736,8328,64,472294,79130,4096,464078,75223,73770,256,168,5457,513]

theorem envBound15445 : H12AffineFastState.Bounded env15445 := by
  intro p hp
  have h : env15445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15444_15445 : H12AffineEnvironment.transform 14 8540 env15444 = env15445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15444 == env15445) = true)

def env15446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10400,1024,8541,78018,32,73874,73736,8328,64,203846,79130,4096,212078,75223,73770,256,168,5457,513]

theorem envBound15446 : H12AffineFastState.Bounded env15446 := by
  intro p hp
  have h : env15446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15445_15446 : H12AffineEnvironment.transform 17 10400 env15445 = env15446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15445 == env15446) = true)

theorem identity15446 : scanCanonicalize (H12AffineFastState.compose env15446 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15446 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,10400,1024,8541,4160,32,16,138,8328,64,146628,5528,4096,138476,1365,168,256,168,5457,513]

theorem envBound15447 : H12AffineFastState.Bounded env15447 := by
  intro p hp
  have h : env15447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15446_15447 : H12AffineEnvironment.transform 15 8322 env15446 = env15447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15446 == env15447) = true)

theorem identity15447 : scanCanonicalize (H12AffineFastState.compose env15447 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound15447 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env15448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,5377,1125,1467,131072,3481,1024,1124,4160,32,16,138,1457,64,137725,5528,4096,138476,1365,168,256,168,5457,513]

theorem envBound15448 : H12AffineFastState.Bounded env15448 := by
  intro p hp
  have h : env15448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15447_15448 : H12AffineEnvironment.transform 12 1337 env15447 = env15448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env15447 == env15448) = true)

theorem identity15448 : scanCanonicalize (H12AffineFastState.compose env15448 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound15448 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env15449 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4248,508,34,131072,2048,409,509,4160,32,16,138,40,64,137725,4097,4096,137589,204,168,256,168,4296,513]

theorem envBound15449 : H12AffineFastState.Bounded env15449 := by
  intro p hp
  have h : env15449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15448_15449 : H12AffineEnvironment.transform 9 409 env15448 = env15449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env15448 == env15449) = true)

theorem identity15449 : scanCanonicalize (H12AffineFastState.compose env15449 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 4524) := by decide +kernel

theorem selectedBound15449 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env15450 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4248,508,34,4524,2048,409,509,4160,32,16,138,40,64,2129,4097,4096,2265,204,168,256,168,4296,513]

theorem envBound15450 : H12AffineFastState.Bounded env15450 := by
  intro p hp
  have h : env15450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15449_15450 : H12AffineEnvironment.transform 16 4524 env15449 = env15450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4524 env15449 == env15450) = true)

theorem identity15450 : scanCanonicalize (H12AffineFastState.compose env15450 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound15450 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15451 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,153,160,1,508,34,309,2048,409,509,217,32,16,138,40,64,2129,152,153,2265,204,168,256,168,81,513]

theorem envBound15451 : H12AffineFastState.Bounded env15451 := by
  intro p hp
  have h : env15451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15450_15451 : H12AffineEnvironment.transform 11 153 env15450 = env15451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env15450 == env15451) = true)

theorem identity15451 : scanCanonicalize (H12AffineFastState.compose env15451 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15451 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15452 : List Nat := [2,4,8,16,32,64,128,36,512,189,2048,153,160,1,216,34,17,2048,189,217,217,32,16,138,40,64,2129,152,153,2265,204,168,36,168,81,513]

theorem envBound15452 : H12AffineFastState.Bounded env15452 := by
  intro p hp
  have h : env15452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15451_15452 : H12AffineEnvironment.transform 7 36 env15451 = env15452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15451 == env15452) = true)

theorem identity15452 : scanCanonicalize (H12AffineFastState.compose env15452 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound15452 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env15453 : List Nat := [2,4,8,16,32,64,72,36,512,117,2048,81,104,1,16,34,17,2048,117,17,17,32,16,66,40,64,2129,80,81,2065,4,96,36,96,81,513]

theorem envBound15453 : H12AffineFastState.Bounded env15453 := by
  intro p hp
  have h : env15453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15452_15453 : H12AffineEnvironment.transform 6 72 env15452 = env15453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env15452 == env15453) = true)

theorem identity15453 : scanCanonicalize (H12AffineFastState.compose env15453 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound15453 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env15454 : List Nat := [2,4,8,16,32,64,72,36,512,117,65,81,104,1,16,34,17,65,117,17,17,32,16,66,40,64,16,80,81,80,4,96,36,96,81,513]

theorem envBound15454 : H12AffineFastState.Bounded env15454 := by
  intro p hp
  have h : env15454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15453_15454 : H12AffineEnvironment.transform 10 65 env15453 = env15454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env15453 == env15454) = true)

theorem identity15454 : scanCanonicalize (H12AffineFastState.compose env15454 (packedSelected [3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound15454 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env15455 : List Nat := [2,4,8,16,32,32,40,36,512,21,33,49,8,1,16,34,17,33,21,17,17,32,16,34,40,32,16,48,49,48,4,0,36,0,49,513]

theorem envBound15455 : H12AffineFastState.Bounded env15455 := by
  intro p hp
  have h : env15455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15454_15455 : H12AffineEnvironment.transform 5 32 env15454 = env15455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env15454 == env15455) = true)

theorem identity15455 : scanCanonicalize (H12AffineFastState.compose env15455 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15455 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15456 : List Nat := [2,4,8,16,16,16,24,20,512,21,17,1,8,1,16,18,17,17,21,17,17,16,16,18,24,16,16,0,1,0,4,0,20,0,1,513]

theorem envBound15456 : H12AffineFastState.Bounded env15456 := by
  intro p hp
  have h : env15456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15455_15456 : H12AffineEnvironment.transform 4 16 env15455 = env15456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15455 == env15456) = true)

def env15457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10401,1024,8541,78018,32,73874,73736,8328,64,203847,79130,4096,212079,75223,73770,256,168,5457,513]

theorem envBound15457 : H12AffineFastState.Bounded env15457 := by
  intro p hp
  have h : env15457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15445_15457 : H12AffineEnvironment.transform 17 10401 env15445 = env15457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15445 == env15457) = true)

theorem identity15457 : scanCanonicalize (H12AffineFastState.compose env15457 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound15457 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env15458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,13389,10401,1024,8541,78018,32,73874,73736,8328,64,75786,79130,4096,67618,75223,73770,256,168,5457,513]

theorem envBound15458 : H12AffineFastState.Bounded env15458 := by
  intro p hp
  have h : env15458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15457_15458 : H12AffineEnvironment.transform 16 13389 env15457 = env15458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env15457 == env15458) = true)

theorem identity15458 : scanCanonicalize (H12AffineFastState.compose env15458 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound15458 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env15459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,65536,5529,2421,1024,137,69910,32,65862,66012,348,64,68062,70862,4096,67618,66563,66046,256,168,5457,513]

theorem envBound15459 : H12AffineFastState.Bounded env15459 := by
  intro p hp
  have h : env15459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15458_15459 : H12AffineEnvironment.transform 12 468 env15458 = env15459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env15458 == env15459) = true)

theorem identity15459 : scanCanonicalize (H12AffineFastState.compose env15459 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound15459 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,478,5529,2421,1024,137,4296,32,152,2,348,64,2048,5392,4096,2556,1501,32,256,168,5457,513]

theorem envBound15460 : H12AffineFastState.Bounded env15460 := by
  intro p hp
  have h : env15460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15459_15460 : H12AffineEnvironment.transform 15 478 env15459 = env15460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env15459 == env15460) = true)

theorem identity15460 : scanCanonicalize (H12AffineFastState.compose env15460 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound15460 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15461 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,301,5377,113,295,5472,2421,1024,112,4145,32,97,2,348,64,2048,5392,4096,2309,1316,32,256,81,5457,513]

theorem envBound15461 : H12AffineFastState.Bounded env15461 := by
  intro p hp
  have h : env15461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15460_15461 : H12AffineEnvironment.transform 6 121 env15460 = env15461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env15460 == env15461) = true)

theorem identity15461 : scanCanonicalize (H12AffineFastState.compose env15461 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15461 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env15462 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,301,5377,1,295,5392,2309,1024,0,4145,32,17,2,300,48,2048,5392,4096,2309,1316,32,256,33,5409,513]

theorem envBound15462 : H12AffineFastState.Bounded env15462 := by
  intro p hp
  have h : env15462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15461_15462 : H12AffineEnvironment.transform 5 48 env15461 = env15462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15461 == env15462) = true)

theorem identity15462 : scanCanonicalize (H12AffineFastState.compose env15462 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound15462 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15463 : List Nat := [2,4,8,16,32,48,9,256,260,1024,2048,4096,301,5377,1,295,5392,2309,1024,0,4145,32,17,2,300,48,2048,5392,4096,2309,1316,32,256,33,5409,261]

theorem envBound15463 : H12AffineFastState.Bounded env15463 := by
  intro p hp
  have h : env15463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15462_15463 : H12AffineEnvironment.transform 8 260 env15462 = env15463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env15462 == env15463) = true)

def env15464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787061,79130,8466578,8819968,8389957,98679,256,8462394,8492191,8462995]

theorem envBound15464 : H12AffineFastState.Bounded env15464 := by
  intro p hp
  have h : env15464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15442_15464 : H12AffineEnvironment.transform 21 33 env15442 = env15464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15442 == env15464) = true)

theorem identity15464 : scanCanonicalize (H12AffineFastState.compose env15464 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound15464 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,45340,33,8388608,138,8328,64,8787061,46276,8433996,8819968,8389957,169,256,8430052,8394049,8430413]

theorem envBound15465 : H12AffineFastState.Bounded env15465 := by
  intro p hp
  have h : env15465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15464_15465 : H12AffineEnvironment.transform 15 33246 env15464 = env15465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env15464 == env15465) = true)

theorem identity15465 : scanCanonicalize (H12AffineFastState.compose env15465 (packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 297453) := by decide +kernel

theorem selectedBound15465 : packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,45340,33,297453,138,8328,64,171416,46276,276641,138477,298152,169,256,272393,302252,273056]

theorem envBound15466 : H12AffineFastState.Bounded env15466 := by
  intro p hp
  have h : env15466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15465_15466 : H12AffineEnvironment.transform 22 297453 env15465 = env15466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297453 env15465 == env15466) = true)

theorem identity15466 : scanCanonicalize (H12AffineFastState.compose env15466 (packedSelected [1,4,7,9,10,11,12,15,18,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound15466 : packedSelected [1,4,7,9,10,11,12,15,18,26,27,28] rootPS < 2^1333 := by decide +kernel

def env15467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,10401,1024,32769,45340,33,41292,138,8328,64,171416,46276,4096,138477,41993,169,256,168,46093,513]

theorem envBound15467 : H12AffineFastState.Bounded env15467 := by
  intro p hp
  have h : env15467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15466_15467 : H12AffineEnvironment.transform 17 10401 env15466 = env15467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15466 == env15467) = true)

theorem identity15467 : scanCanonicalize (H12AffineFastState.compose env15467 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound15467 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env15468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,13460,10401,1024,32769,45340,33,41292,138,8328,64,43276,46276,4096,10361,41993,169,256,168,46093,513]

theorem envBound15468 : H12AffineFastState.Bounded env15468 := by
  intro p hp
  have h : env15468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15467_15468 : H12AffineEnvironment.transform 16 13460 env15467 = env15468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env15467 == env15468) = true)

theorem identity15468 : scanCanonicalize (H12AffineFastState.compose env15468 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15468 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env15469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,32768,33246,5528,2477,1024,32769,36880,33,32832,138,388,64,34816,38344,4096,2421,34053,169,256,168,38145,513]

theorem envBound15469 : H12AffineFastState.Bounded env15469 := by
  intro p hp
  have h : env15469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15468_15469 : H12AffineEnvironment.transform 12 268 env15468 = env15469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15468 == env15469) = true)

def env15470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound15470 : H12AffineFastState.Bounded env15470 := by
  intro p hp
  have h : env15470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15278_15470 : H12AffineEnvironment.transform 18 1025 env15278 = env15470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15278 == env15470) = true)

theorem identity15470 : scanCanonicalize (H12AffineFastState.compose env15470 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10650947) := by decide +kernel

theorem selectedBound15470 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10650947,8328,64,6636867,8585678,10507601,8830976,2294098,12836994,257,213487,237642,2238085]

theorem envBound15471 : H12AffineFastState.Bounded env15471 := by
  intro p hp
  have h : env15471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15470_15471 : H12AffineEnvironment.transform 23 10650947 env15470 = env15471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10650947 env15470 == env15471) = true)

def env15472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180224,2114883,8328,64,6636867,115150,2266449,262144,2294098,4268162,257,213487,237642,2238085]

theorem envBound15472 : H12AffineFastState.Bounded env15472 := by
  intro p hp
  have h : env15472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15471_15472 : H12AffineEnvironment.transform 22 180224 env15471 = env15472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env15471 == env15472) = true)

def env15473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,169235,8328,64,4691219,115150,17665,262144,119042,4268162,257,213487,237642,63189]

theorem envBound15473 : H12AffineFastState.Bounded env15473 := by
  intro p hp
  have h : env15473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15472_15473 : H12AffineEnvironment.transform 20 184400 env15472 = env15473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env15472 == env15473) = true)

def env15474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,169235,8328,64,245139,115150,17665,262144,119042,329730,257,213487,237642,63189]

theorem envBound15474 : H12AffineFastState.Bounded env15474 := by
  intro p hp
  have h : env15474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15473_15474 : H12AffineEnvironment.transform 21 272512 env15473 = env15474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15473 == env15474) = true)

theorem identity15474 : scanCanonicalize (H12AffineFastState.compose env15474 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15474 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272512,180224,169235,8328,64,171417,57796,17665,262144,61704,272392,257,156133,163904,63189]

theorem envBound15475 : H12AffineFastState.Bounded env15475 := by
  intro p hp
  have h : env15475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15474_15475 : H12AffineEnvironment.transform 15 8202 env15474 = env15475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15474 == env15475) = true)

def env15476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272392,180224,169235,8192,64,171281,57676,17665,262144,61704,272392,257,156013,163904,63069]

theorem envBound15476 : H12AffineFastState.Bounded env15476 := by
  intro p hp
  have h : env15476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15475_15476 : H12AffineEnvironment.transform 6 8 env15475 = env15476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15475 == env15476) = true)

def env15477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272392,16,21763,8192,64,23809,57676,17665,262144,61704,272392,257,41341,16464,63069]

theorem envBound15477 : H12AffineFastState.Bounded env15477 := by
  intro p hp
  have h : env15477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15476_15477 : H12AffineEnvironment.transform 16 49168 env15476 = env15477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15476 == env15477) = true)

theorem identity15477 : scanCanonicalize (H12AffineFastState.compose env15477 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound15477 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,13388,262144,1025,29789,4160,272392,16,21763,8192,64,23809,5392,17665,262144,1364,272392,257,21793,16464,513]

theorem envBound15478 : H12AffineFastState.Bounded env15478 := by
  intro p hp
  have h : env15478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15477_15478 : H12AffineEnvironment.transform 14 29788 env15477 = env15478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env15477 == env15478) = true)

theorem identity15478 : scanCanonicalize (H12AffineFastState.compose env15478 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15478 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15479 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8202,13340,262144,1025,29709,4112,272392,16,21763,8192,16,23809,5392,17665,262144,1284,272392,257,21793,16384,513]

theorem envBound15479 : H12AffineFastState.Bounded env15479 := by
  intro p hp
  have h : env15479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15478_15479 : H12AffineEnvironment.transform 5 16 env15478 = env15479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15478 == env15479) = true)

theorem identity15479 : scanCanonicalize (H12AffineFastState.compose env15479 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15479 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15480 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13340,262144,1025,8461,4112,272392,16,3,8192,16,2049,5392,4097,262144,1284,272392,257,33,5376,513]

theorem envBound15480 : H12AffineFastState.Bounded env15480 := by
  intro p hp
  have h : env15480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15479_15480 : H12AffineEnvironment.transform 13 5376 env15479 = env15480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15479 == env15480) = true)

theorem identity15480 : scanCanonicalize (H12AffineFastState.compose env15480 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound15480 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15481 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13340,2340,1025,8461,4112,8492,16,3,8192,16,2049,5392,4097,2340,1284,8492,257,33,5376,513]

theorem envBound15481 : H12AffineFastState.Bounded env15481 := by
  intro p hp
  have h : env15481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15480_15481 : H12AffineEnvironment.transform 17 2340 env15480 = env15481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env15480 == env15481) = true)

theorem identity15481 : scanCanonicalize (H12AffineFastState.compose env15481 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound15481 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15482 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7465,5376,7205,7459,2357,2340,1025,7204,4112,7173,16,3,7465,16,2049,5392,4097,2340,1284,7173,257,33,5376,513]

theorem envBound15482 : H12AffineFastState.Bounded env15482 := by
  intro p hp
  have h : env15482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15481_15482 : H12AffineEnvironment.transform 12 7465 env15481 = env15482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env15481 == env15482) = true)

theorem identity15482 : scanCanonicalize (H12AffineFastState.compose env15482 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15482 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15483 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,7180,5157,7205,7174,2064,2049,1025,7204,4112,7173,16,3,7180,16,2049,5173,4097,2049,1057,7173,36,33,5157,513]

theorem envBound15483 : H12AffineFastState.Bounded env15483 := by
  intro p hp
  have h : env15483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15482_15483 : H12AffineEnvironment.transform 7 37 env15482 = env15483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15482 == env15483) = true)

def env15484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272392,17,21762,8192,64,23808,57676,17665,262144,61704,272392,257,41340,16465,63069]

theorem envBound15484 : H12AffineFastState.Bounded env15484 := by
  intro p hp
  have h : env15484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15476_15484 : H12AffineEnvironment.transform 16 49169 env15476 = env15484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15476 == env15484) = true)

theorem identity15484 : scanCanonicalize (H12AffineFastState.compose env15484 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound15484 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,56436,1025,32769,4161,62588,17,21762,8192,64,23808,57676,17665,56436,61704,62588,257,41340,16465,63069]

theorem envBound15485 : H12AffineFastState.Bounded env15485 := by
  intro p hp
  have h : env15485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15484_15485 : H12AffineEnvironment.transform 17 56436 env15484 = env15485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env15484 == env15485) = true)

theorem identity15485 : scanCanonicalize (H12AffineFastState.compose env15485 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15485 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env15486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,38160,35189,1025,32769,4161,41341,17,3,8192,64,2049,46157,4096,35189,41993,41341,257,41340,5456,41820]

theorem envBound15486 : H12AffineFastState.Bounded env15486 := by
  intro p hp
  have h : env15486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15485_15486 : H12AffineEnvironment.transform 13 5377 env15485 = env15486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15485 == env15486) = true)

theorem identity15486 : scanCanonicalize (H12AffineFastState.compose env15486 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15486 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env15487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,343,38160,35189,1025,32769,4161,32800,17,3,349,64,2049,38160,4096,35189,34132,32800,257,32801,5456,33281]

theorem envBound15487 : H12AffineFastState.Bounded env15487 := by
  intro p hp
  have h : env15487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15486_15487 : H12AffineEnvironment.transform 12 349 env15486 = env15487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15486 == env15487) = true)

theorem identity15487 : scanCanonicalize (H12AffineFastState.compose env15487 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound15487 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env15488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,2049,343,7441,372,1025,2048,4161,2081,17,3,349,64,2049,7441,4096,372,3413,2081,257,2080,5456,2560]

theorem envBound15488 : H12AffineFastState.Bounded env15488 := by
  intro p hp
  have h : env15488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15487_15488 : H12AffineEnvironment.transform 14 2049 env15487 = env15488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env15487 == env15488) = true)

theorem identity15488 : scanCanonicalize (H12AffineFastState.compose env15488 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15488 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env15489 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,349,4404,2049,343,6436,372,52,2048,4161,2081,17,3,349,64,2049,6436,4096,372,2400,2081,257,2080,4453,2560]

theorem envBound15489 : H12AffineFastState.Bounded env15489 := by
  intro p hp
  have h : env15489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15488_15489 : H12AffineEnvironment.transform 9 53 env15488 = env15489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15488 == env15489) = true)

theorem identity15489 : scanCanonicalize (H12AffineFastState.compose env15489 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound15489 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env15490 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,349,2341,2049,343,309,372,52,2048,2128,2081,17,3,349,64,2049,309,2065,372,2400,2081,257,2080,2420,2560]

theorem envBound15490 : H12AffineFastState.Bounded env15490 := by
  intro p hp
  have h : env15490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15489_15490 : H12AffineEnvironment.transform 11 2065 env15489 = env15490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env15489 == env15490) = true)

theorem identity15490 : scanCanonicalize (H12AffineFastState.compose env15490 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15490 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env15491 : List Nat := [2,4,8,16,32,64,8,256,512,53,0,17,349,293,1,343,309,372,52,0,80,33,17,3,349,64,1,309,17,372,352,33,257,32,372,512]

theorem envBound15491 : H12AffineFastState.Bounded env15491 := by
  intro p hp
  have h : env15491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15490_15491 : H12AffineEnvironment.transform 10 0 env15490 = env15491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15490 == env15491) = true)

theorem identity15491 : scanCanonicalize (H12AffineFastState.compose env15491 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15491 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15492 : List Nat := [2,4,8,16,32,64,8,5,512,53,0,17,88,32,1,82,48,113,52,0,80,33,17,3,88,64,1,48,17,113,101,33,4,32,113,512]

theorem envBound15492 : H12AffineFastState.Bounded env15492 := by
  intro p hp
  have h : env15492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15491_15492 : H12AffineEnvironment.transform 7 5 env15491 = env15492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15491 == env15492) = true)

theorem identity15492 : scanCanonicalize (H12AffineFastState.compose env15492 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15492 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15493 : List Nat := [2,4,8,16,32,17,8,5,512,53,0,17,9,32,1,3,48,32,52,0,1,33,17,3,9,17,1,48,17,32,52,33,4,32,32,512]

theorem envBound15493 : H12AffineFastState.Bounded env15493 := by
  intro p hp
  have h : env15493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15492_15493 : H12AffineEnvironment.transform 5 17 env15492 = env15493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15492 == env15493) = true)

theorem identity15493 : scanCanonicalize (H12AffineFastState.compose env15493 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15493 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15494 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,0,1,3,16,0,20,0,1,1,17,3,9,17,1,16,17,0,20,1,4,0,0,512]

theorem envBound15494 : H12AffineFastState.Bounded env15494 := by
  intro p hp
  have h : env15494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15493_15494 : H12AffineEnvironment.transform 4 0 env15493 = env15494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15493 == env15494) = true)

theorem identity15494 : scanCanonicalize (H12AffineFastState.compose env15494 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15495 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,17,9,0,1,3,16,0,20,0,1,1,17,3,9,17,1,16,17,0,20,1,4,0,0,0]

theorem envBound15495 : H12AffineFastState.Bounded env15495 := by
  intro p hp
  have h : env15495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15494_15495 : H12AffineEnvironment.transform 8 0 env15494 = env15495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15494 == env15495) = true)

theorem identity15495 : scanCanonicalize (H12AffineFastState.compose env15495 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound15495 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15496 : List Nat := [2,4,8,15,0,14,8,5,0,10,0,14,9,0,1,3,15,0,11,0,1,1,14,3,9,14,1,15,14,0,11,1,4,0,0,0]

theorem envBound15496 : H12AffineFastState.Bounded env15496 := by
  intro p hp
  have h : env15496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15495_15496 : H12AffineEnvironment.transform 3 15 env15495 = env15496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env15495 == env15496) = true)

def env15497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272393,180224,169235,8193,64,171280,57677,17665,262144,61704,272392,257,156012,163904,63068]

theorem envBound15497 : H12AffineFastState.Bounded env15497 := by
  intro p hp
  have h : env15497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15475_15497 : H12AffineEnvironment.transform 6 9 env15475 = env15497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15475 == env15497) = true)

def env15498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272393,16,21763,8193,64,23808,57677,17665,262144,61704,272392,257,41340,16464,63068]

theorem envBound15498 : H12AffineFastState.Bounded env15498 := by
  intro p hp
  have h : env15498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15497_15498 : H12AffineEnvironment.transform 16 49168 env15497 = env15498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15497 == env15498) = true)

theorem identity15498 : scanCanonicalize (H12AffineFastState.compose env15498 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15498 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,38160,262144,1025,32769,4160,272393,16,3,8193,64,2048,46157,4097,262144,41992,272392,257,41340,5456,41820]

theorem envBound15499 : H12AffineFastState.Bounded env15499 := by
  intro p hp
  have h : env15499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15498_15499 : H12AffineEnvironment.transform 13 5376 env15498 = env15499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15498 == env15499) = true)

theorem identity15499 : scanCanonicalize (H12AffineFastState.compose env15499 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15499 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env15500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,342,38160,262144,1025,32769,4160,264533,16,3,349,64,2048,38161,4097,262144,34132,264532,257,32800,5456,33280]

theorem envBound15500 : H12AffineFastState.Bounded env15500 := by
  intro p hp
  have h : env15500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15499_15500 : H12AffineEnvironment.transform 12 348 env15499 = env15500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15499 == env15500) = true)

theorem identity15500 : scanCanonicalize (H12AffineFastState.compose env15500 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15500 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,262144,1025,0,4160,264533,16,3,349,64,2048,5392,4097,262144,1365,264532,257,33,5456,513]

theorem envBound15501 : H12AffineFastState.Bounded env15501 := by
  intro p hp
  have h : env15501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15500_15501 : H12AffineEnvironment.transform 14 1 env15500 = env15501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15500 == env15501) = true)

theorem identity15501 : scanCanonicalize (H12AffineFastState.compose env15501 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound15501 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15502 : List Nat := [2,4,8,16,32,64,9,256,372,1024,2048,4096,348,5376,1,342,5393,262144,1025,0,4160,264533,16,3,349,64,2048,5392,4097,262144,1365,264532,257,33,5456,373]

theorem envBound15502 : H12AffineFastState.Bounded env15502 := by
  intro p hp
  have h : env15502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15501_15502 : H12AffineEnvironment.transform 8 372 env15501 = env15502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env15501 == env15502) = true)

theorem identity15502 : scanCanonicalize (H12AffineFastState.compose env15502 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15502 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15503 : List Nat := [2,4,8,16,32,16,9,256,292,1024,2048,4096,268,5376,1,262,5393,262144,1025,0,4112,264453,16,3,269,16,2048,5392,4097,262144,1285,264452,257,33,5376,293]

theorem envBound15503 : H12AffineFastState.Bounded env15503 := by
  intro p hp
  have h : env15503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15502_15503 : H12AffineEnvironment.transform 5 16 env15502 = env15503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15502 == env15503) = true)

theorem identity15503 : scanCanonicalize (H12AffineFastState.compose env15503 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound15503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15504 : List Nat := [2,4,8,16,32,16,9,52,16,1024,2048,4096,56,5172,1,50,5157,262144,1025,0,4112,264241,16,3,57,16,2048,5156,4097,262144,1073,264240,53,33,5172,17]

theorem envBound15504 : H12AffineFastState.Bounded env15504 := by
  intro p hp
  have h : env15504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15503_15504 : H12AffineEnvironment.transform 7 52 env15503 = env15504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env15503 == env15504) = true)

theorem identity15504 : scanCanonicalize (H12AffineFastState.compose env15504 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound15504 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15505 : List Nat := [2,4,8,16,32,16,9,52,16,1024,2048,1076,56,0,1,50,17,262144,1025,0,1060,264241,16,3,57,16,2048,16,1077,262144,1073,264240,53,33,0,17]

theorem envBound15505 : H12AffineFastState.Bounded env15505 := by
  intro p hp
  have h : env15505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15504_15505 : H12AffineEnvironment.transform 11 1076 env15504 = env15505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env15504 == env15505) = true)

theorem identity15505 : scanCanonicalize (H12AffineFastState.compose env15505 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 16) := by decide +kernel

theorem selectedBound15505 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15506 : List Nat := [2,4,8,16,32,16,9,52,16,1024,2048,1076,56,0,1,50,17,16,1025,0,1060,2081,16,3,57,16,2048,16,1077,16,1073,2080,53,33,0,17]

theorem envBound15506 : H12AffineFastState.Bounded env15506 := by
  intro p hp
  have h : env15506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15505_15506 : H12AffineEnvironment.transform 17 16 env15505 = env15506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16 env15505 == env15506) = true)

theorem identity15506 : scanCanonicalize (H12AffineFastState.compose env15506 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound15506 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env15507 : List Nat := [2,4,8,16,32,16,9,52,16,1024,16,1076,56,0,1,50,17,16,1025,0,1060,49,16,3,57,16,16,16,1077,16,1073,48,53,33,0,17]

theorem envBound15507 : H12AffineFastState.Bounded env15507 := by
  intro p hp
  have h : env15507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15506_15507 : H12AffineEnvironment.transform 10 16 env15506 = env15507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env15506 == env15507) = true)

theorem identity15507 : scanCanonicalize (H12AffineFastState.compose env15507 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound15507 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15508 : List Nat := [2,4,8,16,32,16,9,52,16,36,16,16,56,0,1,50,17,16,37,0,0,49,16,3,57,16,16,16,17,16,21,48,53,33,0,17]

theorem envBound15508 : H12AffineFastState.Bounded env15508 := by
  intro p hp
  have h : env15508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15507_15508 : H12AffineEnvironment.transform 9 36 env15507 = env15508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env15507 == env15508) = true)

theorem identity15508 : scanCanonicalize (H12AffineFastState.compose env15508 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15508 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15509 : List Nat := [2,4,8,16,17,16,9,5,16,21,16,16,9,0,1,3,17,16,20,0,0,0,16,3,8,16,16,16,17,16,21,1,4,16,0,17]

theorem envBound15509 : H12AffineFastState.Bounded env15509 := by
  intro p hp
  have h : env15509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15508_15509 : H12AffineEnvironment.transform 4 17 env15508 = env15509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15508 == env15509) = true)

theorem identity15509 : scanCanonicalize (H12AffineFastState.compose env15509 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15509 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15510 : List Nat := [2,4,8,1,0,1,9,5,1,4,1,1,9,0,1,3,0,1,5,0,0,0,1,3,8,1,1,1,0,1,4,1,4,1,0,0]

theorem envBound15510 : H12AffineFastState.Bounded env15510 := by
  intro p hp
  have h : env15510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15509_15510 : H12AffineEnvironment.transform 3 1 env15509 = env15510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15509 == env15510) = true)

def env15511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272393,17,21762,8193,64,23809,57677,17665,262144,61704,272392,257,41341,16465,63068]

theorem envBound15511 : H12AffineFastState.Bounded env15511 := by
  intro p hp
  have h : env15511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15497_15511 : H12AffineEnvironment.transform 16 49169 env15497 = env15511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15497 == env15511) = true)

theorem identity15511 : scanCanonicalize (H12AffineFastState.compose env15511 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound15511 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,32041,1025,32769,4161,21792,17,21762,8193,64,23809,57677,17665,32041,61704,21793,257,41341,16465,63068]

theorem envBound15512 : H12AffineFastState.Bounded env15512 := by
  intro p hp
  have h : env15512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15511_15512 : H12AffineEnvironment.transform 17 32041 env15511 = env15512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env15511 == env15512) = true)

theorem identity15512 : scanCanonicalize (H12AffineFastState.compose env15512 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound15512 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env15513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,8202,5221,32041,1025,21621,4161,21792,17,21762,8193,64,23809,13625,17665,32041,9596,21793,257,29961,16465,8744]

theorem envBound15513 : H12AffineFastState.Bounded env15513 := by
  intro p hp
  have h : env15513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15512_15513 : H12AffineEnvironment.transform 14 21620 env15512 = env15513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env15512 == env15513) = true)

theorem identity15513 : scanCanonicalize (H12AffineFastState.compose env15513 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15513 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,21620,34,5221,23809,1025,21621,4161,21792,17,21762,41,64,23809,5393,17665,23809,1364,21793,257,21793,16465,512]

theorem envBound15514 : H12AffineFastState.Bounded env15514 := by
  intro p hp
  have h : env15514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15513_15514 : H12AffineEnvironment.transform 12 40 env15513 = env15514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15513 == env15514) = true)

theorem identity15514 : scanCanonicalize (H12AffineFastState.compose env15514 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15514 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,0,34,5221,2421,1025,1,4161,340,17,374,41,64,2421,5393,4469,2421,1364,341,257,341,5157,512]

theorem envBound15515 : H12AffineFastState.Bounded env15515 := by
  intro p hp
  have h : env15515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15514_15515 : H12AffineEnvironment.transform 13 5236 env15514 = env15515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15514 == env15515) = true)

theorem identity15515 : scanCanonicalize (H12AffineFastState.compose env15515 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15515 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15516 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,40,5236,0,34,5221,2080,1025,1,4161,1,17,35,41,64,2080,5188,4128,2080,1025,0,84,0,5157,512]

theorem envBound15516 : H12AffineFastState.Bounded env15516 := by
  intro p hp
  have h : env15516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15515_15516 : H12AffineEnvironment.transform 7 85 env15515 = env15516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15515 == env15516) = true)

theorem identity15516 : scanCanonicalize (H12AffineFastState.compose env15516 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1087) := by decide +kernel

theorem selectedBound15516 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env15517 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,1087,40,75,0,34,90,2080,1025,1,1150,1,17,35,41,64,2080,123,1055,2080,1025,0,84,0,26,512]

theorem envBound15517 : H12AffineFastState.Bounded env15517 := by
  intro p hp
  have h : env15517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15516_15517 : H12AffineEnvironment.transform 11 1087 env15516 = env15517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1087 env15516 == env15517) = true)

theorem identity15517 : scanCanonicalize (H12AffineFastState.compose env15517 (packedSelected [5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound15517 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env15518 : List Nat := [2,4,8,16,32,64,9,85,512,1024,11,1087,40,75,0,34,90,43,1025,1,1150,1,17,35,41,64,43,123,1055,43,1025,0,84,0,26,512]

theorem envBound15518 : H12AffineFastState.Bounded env15518 := by
  intro p hp
  have h : env15518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15517_15518 : H12AffineEnvironment.transform 10 11 env15517 = env15518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env15517 == env15518) = true)

def env15519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,169235,8328,64,245138,115150,17665,262144,119042,329731,257,213487,237642,63189]

theorem envBound15519 : H12AffineFastState.Bounded env15519 := by
  intro p hp
  have h : env15519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15473_15519 : H12AffineEnvironment.transform 21 272513 env15473 = env15519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15473 == env15519) = true)

theorem identity15519 : scanCanonicalize (H12AffineFastState.compose env15519 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound15519 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272513,73755,95496,8328,64,23945,115150,17665,262144,119042,329731,257,41460,16465,63189]

theorem envBound15520 : H12AffineFastState.Bounded env15520 := by
  intro p hp
  have h : env15520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15519_15520 : H12AffineEnvironment.transform 16 122907 env15519 = env15520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env15519 == env15520) = true)

def env15521 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272473,73755,95496,8272,64,23889,114966,17665,262144,119042,329731,257,41260,16465,62989]

theorem envBound15521 : H12AffineFastState.Bounded env15521 := by
  intro p hp
  have h : env15521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15520_15521 : H12AffineEnvironment.transform 6 88 env15520 = env15521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env15520 == env15521) = true)

theorem identity15521 : scanCanonicalize (H12AffineFastState.compose env15521 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound15521 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15522 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,65536,79131,262144,1025,21761,77899,272473,73755,95496,8272,64,23889,70678,17665,262144,66562,329731,257,29740,16465,8973]

theorem envBound15522 : H12AffineFastState.Bounded env15522 := by
  intro p hp
  have h : env15522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15521_15522 : H12AffineEnvironment.transform 14 21760 env15521 = env15522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env15521 == env15522) = true)

theorem identity15522 : scanCanonicalize (H12AffineFastState.compose env15522 (packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound15522 : packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env15523 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,65536,79131,97326,1025,21761,77899,87159,73755,95496,8272,64,23889,70678,17665,97326,66562,29741,257,29740,16465,8973]

theorem envBound15523 : H12AffineFastState.Bounded env15523 := by
  intro p hp
  have h : env15523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15522_15523 : H12AffineEnvironment.transform 17 97326 env15522 = env15523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env15522 == env15523) = true)

theorem identity15523 : scanCanonicalize (H12AffineFastState.compose env15523 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15523 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env15524 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,262,13341,32040,1025,21761,12621,21873,8477,29710,8272,64,23889,5392,17665,32040,1284,29741,257,29740,16465,8973]

theorem envBound15524 : H12AffineFastState.Bounded env15524 := by
  intro p hp
  have h : env15524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15523_15524 : H12AffineEnvironment.transform 15 262 env15523 = env15524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15523 == env15524) = true)

theorem identity15524 : scanCanonicalize (H12AffineFastState.compose env15524 (packedSelected [2,11,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound15524 : packedSelected [2,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env15525 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4144,1328,262,13341,11544,1025,1329,12621,1345,8477,9278,8272,64,3425,5392,5425,11544,1284,9245,257,9244,4193,8973]

theorem envBound15525 : H12AffineFastState.Bounded env15525 := by
  intro p hp
  have h : env15525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15524_15525 : H12AffineEnvironment.transform 13 4144 env15524 = env15525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env15524 == env15525) = true)

theorem identity15525 : scanCanonicalize (H12AffineFastState.compose env15525 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound15525 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15526 : List Nat := [2,4,8,16,32,64,88,256,512,304,2048,4096,8192,4144,0,262,12589,10280,305,1,12621,113,8477,8462,8272,64,2129,4128,4097,10280,52,8493,257,8492,4193,8973]

theorem envBound15526 : H12AffineFastState.Bounded env15526 := by
  intro p hp
  have h : env15526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15525_15526 : H12AffineEnvironment.transform 9 304 env15525 = env15526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env15525 == env15526) = true)

theorem identity15526 : scanCanonicalize (H12AffineFastState.compose env15526 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound15526 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15527 : List Nat := [2,4,8,16,32,64,88,256,512,304,2048,4096,300,4144,0,262,4097,2308,305,1,4193,113,49,34,380,64,2129,4128,4097,2308,52,1,257,0,4193,545]

theorem envBound15527 : H12AffineFastState.Bounded env15527 := by
  intro p hp
  have h : env15527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15526_15527 : H12AffineEnvironment.transform 12 300 env15526 = env15527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env15526 == env15527) = true)

theorem identity15527 : scanCanonicalize (H12AffineFastState.compose env15527 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15527 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15528 : List Nat := [2,4,8,16,32,48,40,256,512,304,2048,4096,300,4144,0,262,4097,2308,305,1,4113,1,49,34,268,48,2081,4128,4097,2308,52,1,257,0,4113,545]

theorem envBound15528 : H12AffineFastState.Bounded env15528 := by
  intro p hp
  have h : env15528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15527_15528 : H12AffineEnvironment.transform 5 48 env15527 = env15528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15527 == env15528) = true)

theorem identity15528 : scanCanonicalize (H12AffineFastState.compose env15528 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound15528 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15529 : List Nat := [2,4,8,16,32,48,40,256,512,304,308,4096,300,4144,0,262,4097,48,305,1,4113,1,49,34,268,48,277,4128,4097,48,52,1,257,0,4113,545]

theorem envBound15529 : H12AffineFastState.Bounded env15529 := by
  intro p hp
  have h : env15529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15528_15529 : H12AffineEnvironment.transform 10 308 env15528 = env15529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env15528 == env15529) = true)

theorem identity15529 : scanCanonicalize (H12AffineFastState.compose env15529 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15529 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15530 : List Nat := [2,4,8,16,0,16,8,256,512,272,276,4096,268,4112,0,262,4097,16,273,1,4113,1,17,2,268,16,277,4096,4097,16,20,1,257,0,4113,513]

theorem envBound15530 : H12AffineFastState.Bounded env15530 := by
  intro p hp
  have h : env15530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15529_15530 : H12AffineEnvironment.transform 4 0 env15529 = env15530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15529 == env15530) = true)

theorem identity15530 : scanCanonicalize (H12AffineFastState.compose env15530 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound15530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15531 : List Nat := [2,4,8,16,0,16,8,256,512,272,276,276,268,260,0,262,277,16,273,1,261,1,17,2,268,16,277,276,277,16,20,1,257,0,261,513]

theorem envBound15531 : H12AffineFastState.Bounded env15531 := by
  intro p hp
  have h : env15531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15530_15531 : H12AffineEnvironment.transform 11 276 env15530 = env15531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env15530 == env15531) = true)

theorem identity15531 : scanCanonicalize (H12AffineFastState.compose env15531 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15531 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15532 : List Nat := [2,4,8,16,0,16,8,5,512,21,17,17,9,1,0,3,16,16,20,1,0,1,17,2,9,16,16,17,16,16,20,1,4,0,0,513]

theorem envBound15532 : H12AffineFastState.Bounded env15532 := by
  intro p hp
  have h : env15532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15531_15532 : H12AffineEnvironment.transform 7 5 env15531 = env15532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15531 == env15532) = true)

theorem identity15532 : scanCanonicalize (H12AffineFastState.compose env15532 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15532 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15533 : List Nat := [2,4,3,16,0,16,3,5,512,21,17,17,2,1,0,3,16,16,20,1,0,1,17,2,2,16,16,17,16,16,20,1,4,0,0,513]

theorem envBound15533 : H12AffineFastState.Bounded env15533 := by
  intro p hp
  have h : env15533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15532_15533 : H12AffineEnvironment.transform 2 3 env15532 = env15533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15532 == env15533) = true)

theorem identity15533 : scanCanonicalize (H12AffineFastState.compose env15533 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15533 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15534 : List Nat := [2,4,3,16,0,16,3,5,1,21,17,17,2,1,0,3,16,16,20,1,0,1,17,2,2,16,16,17,16,16,20,1,4,0,0,0]

theorem envBound15534 : H12AffineFastState.Bounded env15534 := by
  intro p hp
  have h : env15534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15533_15534 : H12AffineEnvironment.transform 8 1 env15533 = env15534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15533 == env15534) = true)

theorem identity15534 : scanCanonicalize (H12AffineFastState.compose env15534 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15534 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15535 : List Nat := [2,4,3,1,0,1,3,5,1,4,0,0,2,1,0,3,1,1,5,1,0,1,0,2,2,1,1,0,1,1,5,1,4,0,0,0]

theorem envBound15535 : H12AffineFastState.Bounded env15535 := by
  intro p hp
  have h : env15535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15534_15535 : H12AffineEnvironment.transform 3 1 env15534 = env15535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15534 == env15535) = true)

def env15536 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272472,73755,95496,8273,64,23888,114967,17665,262144,119042,329731,257,41261,16465,62988]

theorem envBound15536 : H12AffineFastState.Bounded env15536 := by
  intro p hp
  have h : env15536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15520_15536 : H12AffineEnvironment.transform 6 89 env15520 = env15536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env15520 == env15536) = true)

theorem identity15536 : scanCanonicalize (H12AffineFastState.compose env15536 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound15536 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15537 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57677,262144,1025,32769,12573,272472,8525,29790,8273,64,23888,49217,17665,262144,53332,264533,257,41261,16465,62988]

theorem envBound15537 : H12AffineFastState.Bounded env15537 := by
  intro p hp
  have h : env15537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15536_15537 : H12AffineEnvironment.transform 15 342 env15536 = env15537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env15536 == env15537) = true)

theorem identity15537 : scanCanonicalize (H12AffineFastState.compose env15537 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 64888) := by decide +kernel

theorem selectedBound15537 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env15538 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57677,64888,1025,32769,12573,54560,8525,29790,8273,64,23888,49217,17665,64888,53332,62509,257,41261,16465,62988]

theorem envBound15538 : H12AffineFastState.Bounded env15538 := by
  intro p hp
  have h : env15538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15537_15538 : H12AffineEnvironment.transform 17 64888 env15537 = env15538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64888 env15537 == env15538) = true)

theorem identity15538 : scanCanonicalize (H12AffineFastState.compose env15538 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound15538 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env15539 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21840,342,13341,10280,1025,21841,12573,112,8525,29790,8273,64,23888,5393,17665,10280,1284,8573,257,29821,16465,9052]

theorem envBound15539 : H12AffineFastState.Bounded env15539 := by
  intro p hp
  have h : env15539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15538_15539 : H12AffineEnvironment.transform 14 21840 env15538 = env15539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env15538 == env15539) = true)

theorem identity15539 : scanCanonicalize (H12AffineFastState.compose env15539 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15539 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env15540 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,16384,21840,342,5441,2420,1025,21841,4161,112,17,21762,269,64,23888,5393,17665,2420,1284,33,257,21793,16465,512]

theorem envBound15540 : H12AffineFastState.Bounded env15540 := by
  intro p hp
  have h : env15540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15539_15540 : H12AffineEnvironment.transform 12 348 env15539 = env15540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15539 == env15540) = true)

theorem identity15540 : scanCanonicalize (H12AffineFastState.compose env15540 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound15540 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15541 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5408,112,342,5441,2420,1025,113,4161,112,17,34,269,64,2160,5393,4129,2420,1284,33,257,1,5489,512]

theorem envBound15541 : H12AffineFastState.Bounded env15541 := by
  intro p hp
  have h : env15541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15540_15541 : H12AffineEnvironment.transform 13 5408 env15540 = env15541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env15540 == env15541) = true)

theorem identity15541 : scanCanonicalize (H12AffineFastState.compose env15541 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound15541 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env15542 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,292,348,1028,112,342,1125,2420,1025,113,357,112,17,34,269,64,2160,1077,261,2420,1284,33,257,1,1109,512]

theorem envBound15542 : H12AffineFastState.Bounded env15542 := by
  intro p hp
  have h : env15542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15541_15542 : H12AffineEnvironment.transform 11 292 env15541 = env15542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env15541 == env15542) = true)

theorem identity15542 : scanCanonicalize (H12AffineFastState.compose env15542 (packedSelected [0,1,2,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound15542 : packedSelected [0,1,2,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15543 : List Nat := [2,4,8,16,32,64,89,256,49,1024,2048,292,348,1028,112,342,1125,2420,1025,113,357,112,17,34,269,64,2160,1077,261,2420,1284,33,257,1,1109,49]

theorem envBound15543 : H12AffineFastState.Bounded env15543 := by
  intro p hp
  have h : env15543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15542_15543 : H12AffineEnvironment.transform 8 49 env15542 = env15543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env15542 == env15543) = true)

theorem identity15543 : scanCanonicalize (H12AffineFastState.compose env15543 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15543 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15544 : List Nat := [2,4,8,16,32,64,89,85,49,1024,2048,113,9,1028,112,3,1125,2081,1025,113,48,112,17,34,88,64,2160,1077,80,2081,1105,33,84,1,1109,49]

theorem envBound15544 : H12AffineFastState.Bounded env15544 := by
  intro p hp
  have h : env15544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15543_15544 : H12AffineEnvironment.transform 7 85 env15543 = env15544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15543 == env15544) = true)

theorem identity15544 : scanCanonicalize (H12AffineFastState.compose env15544 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15544 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15545 : List Nat := [2,4,8,16,0,64,89,85,17,1024,2048,81,9,1028,80,3,1093,2049,1025,81,16,80,17,2,88,64,2128,1045,80,2049,1105,1,84,1,1109,17]

theorem envBound15545 : H12AffineFastState.Bounded env15545 := by
  intro p hp
  have h : env15545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15544_15545 : H12AffineEnvironment.transform 4 0 env15544 = env15545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15544 == env15545) = true)

theorem identity15545 : scanCanonicalize (H12AffineFastState.compose env15545 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound15545 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15546 : List Nat := [2,4,8,16,0,1,24,20,17,1024,2048,16,9,1028,17,3,1028,2049,1025,16,16,17,17,2,25,1,2065,1045,17,2049,1040,1,21,1,1044,17]

theorem envBound15546 : H12AffineFastState.Bounded env15546 := by
  intro p hp
  have h : env15546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15545_15546 : H12AffineEnvironment.transform 5 1 env15545 = env15546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env15545 == env15546) = true)

theorem identity15546 : scanCanonicalize (H12AffineFastState.compose env15546 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound15546 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15547 : List Nat := [2,4,8,16,0,1,24,20,17,1024,17,16,9,1028,17,3,1028,16,1025,16,16,17,17,2,25,1,0,1045,17,16,1040,1,21,1,1044,17]

theorem envBound15547 : H12AffineFastState.Bounded env15547 := by
  intro p hp
  have h : env15547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15546_15547 : H12AffineEnvironment.transform 10 17 env15546 = env15547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env15546 == env15547) = true)

theorem identity15547 : scanCanonicalize (H12AffineFastState.compose env15547 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound15547 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15548 : List Nat := [2,4,8,16,0,1,24,20,17,20,17,16,9,16,17,3,16,16,21,16,16,17,17,2,25,1,0,1,17,16,4,1,21,1,0,17]

theorem envBound15548 : H12AffineFastState.Bounded env15548 := by
  intro p hp
  have h : env15548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15547_15548 : H12AffineEnvironment.transform 9 20 env15547 = env15548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env15547 == env15548) = true)

theorem identity15548 : scanCanonicalize (H12AffineFastState.compose env15548 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15548 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15549 : List Nat := [2,4,8,1,0,1,9,5,0,5,0,1,9,1,0,3,1,1,4,1,1,0,0,2,8,1,0,1,0,1,4,1,4,1,0,0]

theorem envBound15549 : H12AffineFastState.Bounded env15549 := by
  intro p hp
  have h : env15549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15548_15549 : H12AffineEnvironment.transform 3 1 env15548 = env15549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15548 == env15549) = true)

theorem identity15549 : scanCanonicalize (H12AffineFastState.compose env15549 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15549 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15550 : List Nat := [2,0,8,1,0,1,9,1,0,1,0,1,9,1,0,3,1,1,0,1,1,0,0,2,8,1,0,1,0,1,0,1,0,1,0,0]

theorem envBound15550 : H12AffineFastState.Bounded env15550 := by
  intro p hp
  have h : env15550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15549_15550 : H12AffineEnvironment.transform 1 0 env15549 = env15550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15549 == env15550) = true)

theorem identity15550 : scanCanonicalize (H12AffineFastState.compose env15550 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound15550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15551 : List Nat := [2,0,1,1,0,1,0,1,0,1,0,1,0,1,0,3,1,1,0,1,1,0,0,2,1,1,0,1,0,1,0,1,0,1,0,0]

theorem envBound15551 : H12AffineFastState.Bounded env15551 := by
  intro p hp
  have h : env15551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15550_15551 : H12AffineEnvironment.transform 2 1 env15550 = env15551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env15550 == env15551) = true)

theorem identity15551 : scanCanonicalize (H12AffineFastState.compose env15551 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound15551 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15552 : List Nat := [1,0,1,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,1,1,0,0,1,1,1,0,1,0,1,0,1,0,1,0,0]

theorem envBound15552 : H12AffineFastState.Bounded env15552 := by
  intro p hp
  have h : env15552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15551_15552 : H12AffineEnvironment.transform 0 1 env15551 = env15552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env15551 == env15552) = true)

def env15553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,169234,8328,64,4691218,115150,17664,262144,119043,4268162,257,213487,237642,63188]

theorem envBound15553 : H12AffineFastState.Bounded env15553 := by
  intro p hp
  have h : env15553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15472_15553 : H12AffineEnvironment.transform 20 184401 env15472 = env15553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env15472 == env15553) = true)

def env15554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,169234,8328,64,245138,115150,17664,262144,119043,329730,257,213487,237642,63188]

theorem envBound15554 : H12AffineFastState.Bounded env15554 := by
  intro p hp
  have h : env15554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15553_15554 : H12AffineEnvironment.transform 21 272512 env15553 = env15554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15553 == env15554) = true)

theorem identity15554 : scanCanonicalize (H12AffineFastState.compose env15554 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound15554 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184401,272512,180224,169234,8328,64,158029,5393,17664,262144,1500,318685,257,169264,160917,63188]

theorem envBound15555 : H12AffineFastState.Bounded env15555 := by
  intro p hp
  have h : env15555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15554_15555 : H12AffineEnvironment.transform 15 54495 env15554 = env15555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env15554 == env15555) = true)

theorem identity15555 : scanCanonicalize (H12AffineFastState.compose env15555 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound15555 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,262144,1025,29908,140420,272512,144597,156103,8328,64,158029,5393,17664,262144,1500,272392,257,156133,160917,513]

theorem envBound15556 : H12AffineFastState.Bounded env15556 := by
  intro p hp
  have h : env15556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15555_15556 : H12AffineEnvironment.transform 14 29909 env15555 = env15556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env15555 == env15556) = true)

theorem identity15556 : scanCanonicalize (H12AffineFastState.compose env15556 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound15556 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env15557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,2557,1025,29908,140420,8573,144597,156103,8328,64,158029,5393,17664,2557,1500,8693,257,156133,160917,513]

theorem envBound15557 : H12AffineFastState.Bounded env15557 := by
  intro p hp
  have h : env15557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15556_15557 : H12AffineEnvironment.transform 17 2557 env15556 = env15557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env15556 == env15557) = true)

theorem identity15557 : scanCanonicalize (H12AffineFastState.compose env15557 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound15557 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env15558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,8202,131072,2557,1025,0,140420,8573,144597,136467,8328,64,138649,5393,12756,2557,1500,8693,257,136497,131137,513]

theorem envBound15558 : H12AffineFastState.Bounded env15558 := by
  intro p hp
  have h : env15558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15557_15558 : H12AffineEnvironment.transform 13 13524 env15557 = env15558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env15557 == env15558) = true)

theorem identity15558 : scanCanonicalize (H12AffineFastState.compose env15558 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound15558 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env15559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,8202,5528,2557,1025,0,12572,8573,8525,139,8328,64,2049,5393,12756,2557,1500,8693,257,169,5593,513]

theorem envBound15559 : H12AffineFastState.Bounded env15559 := by
  intro p hp
  have h : env15559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15558_15559 : H12AffineEnvironment.transform 16 5528 env15558 = env15559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env15558 == env15559) = true)

theorem identity15559 : scanCanonicalize (H12AffineFastState.compose env15559 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound15559 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env15560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2049,8192,11477,1,8202,3481,2557,1025,0,10525,8573,8525,139,8328,64,2049,3344,10709,2557,1500,8693,257,169,3544,513]

theorem envBound15560 : H12AffineFastState.Bounded env15560 := by
  intro p hp
  have h : env15560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15559_15560 : H12AffineEnvironment.transform 11 2049 env15559 = env15560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env15559 == env15560) = true)

theorem identity15560 : scanCanonicalize (H12AffineFastState.compose env15560 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15560 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2049,8192,11357,1,8202,3345,2421,1025,0,10525,8573,8525,3,8192,64,2049,3344,10589,2421,1364,8573,257,33,3408,513]

theorem envBound15561 : H12AffineFastState.Bounded env15561 := by
  intro p hp
  have h : env15561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15560_15561 : H12AffineEnvironment.transform 6 8 env15560 = env15561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15560 == env15561) = true)

theorem identity15561 : scanCanonicalize (H12AffineFastState.compose env15561 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15561 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env15562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2049,348,3329,1,342,3345,2421,1025,0,2113,33,17,3,348,64,2049,3344,2049,2421,1364,33,257,33,3408,513]

theorem envBound15562 : H12AffineFastState.Bounded env15562 := by
  intro p hp
  have h : env15562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15561_15562 : H12AffineEnvironment.transform 12 348 env15561 = env15562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15561 == env15562) = true)

theorem identity15562 : scanCanonicalize (H12AffineFastState.compose env15562 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound15562 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15563 : List Nat := [2,4,8,16,32,64,8,256,512,46,2048,2049,348,2351,1,342,2367,2421,47,0,2113,33,17,3,348,64,2049,2366,2049,2421,378,33,257,33,2430,513]

theorem envBound15563 : H12AffineFastState.Bounded env15563 := by
  intro p hp
  have h : env15563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15562_15563 : H12AffineEnvironment.transform 9 46 env15562 = env15563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env15562 == env15563) = true)

theorem identity15563 : scanCanonicalize (H12AffineFastState.compose env15563 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound15563 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env15564 : List Nat := [2,4,8,16,32,64,8,62,512,46,2048,2049,98,2065,1,104,2049,2123,47,0,2113,33,17,3,98,64,2049,2048,2049,2123,68,33,63,33,2112,513]

theorem envBound15564 : H12AffineFastState.Bounded env15564 := by
  intro p hp
  have h : env15564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15563_15564 : H12AffineEnvironment.transform 7 62 env15563 = env15564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env15563 == env15564) = true)

theorem identity15564 : scanCanonicalize (H12AffineFastState.compose env15564 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound15564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15565 : List Nat := [2,4,8,16,32,27,8,62,512,46,2048,2049,57,2065,1,51,2049,2064,47,0,2074,33,17,3,57,27,2049,2048,2049,2064,31,33,63,33,2075,513]

theorem envBound15565 : H12AffineFastState.Bounded env15565 := by
  intro p hp
  have h : env15565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15564_15565 : H12AffineEnvironment.transform 5 27 env15564 = env15565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env15564 == env15565) = true)

theorem identity15565 : scanCanonicalize (H12AffineFastState.compose env15565 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 531) := by decide +kernel

theorem selectedBound15565 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15566 : List Nat := [2,4,8,16,32,27,8,62,512,46,531,530,57,514,1,51,530,515,47,0,521,33,17,3,57,27,530,531,530,515,31,33,63,33,520,513]

theorem envBound15566 : H12AffineFastState.Bounded env15566 := by
  intro p hp
  have h : env15566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15565_15566 : H12AffineEnvironment.transform 10 531 env15565 = env15566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 531 env15565 == env15566) = true)

theorem identity15566 : scanCanonicalize (H12AffineFastState.compose env15566 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15566 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env15567 : List Nat := [2,4,3,16,32,16,3,53,512,37,531,530,50,514,1,51,530,515,36,0,514,33,17,3,50,16,530,531,530,515,20,33,52,33,515,513]

theorem envBound15567 : H12AffineFastState.Bounded env15567 := by
  intro p hp
  have h : env15567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15566_15567 : H12AffineEnvironment.transform 2 3 env15566 = env15567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15566 == env15567) = true)

theorem identity15567 : scanCanonicalize (H12AffineFastState.compose env15567 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15568 : List Nat := [2,4,3,16,1,16,3,20,512,4,531,530,19,514,1,18,530,515,5,0,514,0,17,3,19,16,530,531,530,515,20,0,21,0,515,513]

theorem envBound15568 : H12AffineFastState.Bounded env15568 := by
  intro p hp
  have h : env15568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15567_15568 : H12AffineEnvironment.transform 4 1 env15567 = env15568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15567 == env15568) = true)

def env15569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,169234,8328,64,245139,115150,17664,262144,119043,329731,257,213487,237642,63188]

theorem envBound15569 : H12AffineFastState.Bounded env15569 := by
  intro p hp
  have h : env15569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15553_15569 : H12AffineEnvironment.transform 21 272513 env15553 = env15569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15553 == env15569) = true)

theorem identity15569 : scanCanonicalize (H12AffineFastState.compose env15569 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound15569 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,115871,272513,120014,98780,8328,64,43357,115150,17664,262144,119043,329731,257,21793,46212,63188]

theorem envBound15570 : H12AffineFastState.Bounded env15570 := by
  intro p hp
  have h : env15570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15569_15570 : H12AffineEnvironment.transform 16 70862 env15569 = env15570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env15569 == env15570) = true)

theorem identity15570 : scanCanonicalize (H12AffineFastState.compose env15570 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound15570 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env15571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,76158,1025,32769,115871,66047,120014,98780,8328,64,43357,115150,17664,76158,119043,8573,257,21793,46212,63188]

theorem envBound15571 : H12AffineFastState.Bounded env15571 := by
  intro p hp
  have h : env15571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15570_15571 : H12AffineEnvironment.transform 17 76158 env15570 = env15571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env15570 == env15571) = true)

def env15572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,115735,65911,119878,98644,8192,64,43357,115014,17664,76158,119043,8573,257,21793,46092,63068]

theorem envBound15572 : H12AffineFastState.Bounded env15572 := by
  intro p hp
  have h : env15572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15571_15572 : H12AffineEnvironment.transform 6 8 env15571 = env15572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15571 == env15572) = true)

theorem identity15572 : scanCanonicalize (H12AffineFastState.compose env15572 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15572 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,70726,76158,1025,29788,77898,65911,73755,95497,8192,64,23808,79131,17664,76158,75102,8573,257,21793,16465,513]

theorem envBound15573 : H12AffineFastState.Bounded env15573 := by
  intro p hp
  have h : env15573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15572_15573 : H12AffineEnvironment.transform 14 29789 env15572 = env15573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15572 == env15573) = true)

theorem identity15573 : scanCanonicalize (H12AffineFastState.compose env15573 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15573 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,70726,76158,1025,8541,77898,65911,73755,73736,8192,64,2049,79131,4097,76158,75102,8573,257,32,5456,513]

theorem envBound15574 : H12AffineFastState.Bounded env15574 := by
  intro p hp
  have h : env15574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15573_15574 : H12AffineEnvironment.transform 13 5377 env15573 = env15574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15573 == env15574) = true)

theorem identity15574 : scanCanonicalize (H12AffineFastState.compose env15574 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15574 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env15575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,70726,67618,1025,1,69910,65911,65863,65876,348,64,2049,70727,4097,67618,66562,33,257,32,5456,513]

theorem envBound15575 : H12AffineFastState.Bounded env15575 := by
  intro p hp
  have h : env15575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15574_15575 : H12AffineEnvironment.transform 12 348 env15574 = env15575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15574 == env15575) = true)

theorem identity15575 : scanCanonicalize (H12AffineFastState.compose env15575 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15575 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env15576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,348,5377,0,65536,70726,66915,1025,1,69910,65911,65863,65876,348,64,1344,70727,4097,66915,66562,33,257,32,5456,513]

theorem envBound15576 : H12AffineFastState.Bounded env15576 := by
  intro p hp
  have h : env15576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15575_15576 : H12AffineEnvironment.transform 10 1345 env15575 = env15576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env15575 == env15576) = true)

theorem identity15576 : scanCanonicalize (H12AffineFastState.compose env15576 (packedSelected [0,1,4,5,7,9,10,18] rootPS)) = affineNative (2^(15+1) ^^^ 5206) := by decide +kernel

theorem selectedBound15576 : packedSelected [0,1,4,5,7,9,10,18] rootPS < 2^1333 := by decide +kernel

def env15577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,348,5377,0,5206,16,4405,1025,1,1344,5409,5393,5378,348,64,1344,17,4097,4405,4180,33,257,32,5456,513]

theorem envBound15577 : H12AffineFastState.Bounded env15577 := by
  intro p hp
  have h : env15577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15576_15577 : H12AffineEnvironment.transform 15 5206 env15576 = env15577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5206 env15576 == env15577) = true)

theorem identity15577 : scanCanonicalize (H12AffineFastState.compose env15577 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound15577 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1361,348,80,0,263,16,1124,1025,1,1344,112,64,83,348,64,1344,17,1360,1124,1285,33,257,32,1,513]

theorem envBound15578 : H12AffineFastState.Bounded env15578 := by
  intro p hp
  have h : env15578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15577_15578 : H12AffineEnvironment.transform 11 1361 env15577 = env15578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env15577 == env15578) = true)

theorem identity15578 : scanCanonicalize (H12AffineFastState.compose env15578 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15578 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15579 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,1281,268,0,0,263,16,1076,1025,1,1296,32,16,3,268,16,1296,17,1280,1076,1285,33,257,32,1,513]

theorem envBound15579 : H12AffineFastState.Bounded env15579 := by
  intro p hp
  have h : env15579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15578_15579 : H12AffineEnvironment.transform 5 16 env15578 = env15579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15578 == env15579) = true)

theorem identity15579 : scanCanonicalize (H12AffineFastState.compose env15579 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound15579 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15580 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,17,268,0,0,263,16,292,273,1,0,32,16,3,268,16,0,17,16,292,21,33,257,32,1,513]

theorem envBound15580 : H12AffineFastState.Bounded env15580 := by
  intro p hp
  have h : env15580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15579_15580 : H12AffineEnvironment.transform 9 272 env15579 = env15580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15579 == env15580) = true)

theorem identity15580 : scanCanonicalize (H12AffineFastState.compose env15580 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15580 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15581 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,40,0,0,35,16,0,53,1,0,32,16,3,40,16,0,17,16,0,21,33,37,32,1,513]

theorem envBound15581 : H12AffineFastState.Bounded env15581 := by
  intro p hp
  have h : env15581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15580_15581 : H12AffineEnvironment.transform 7 36 env15580 = env15581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15580 == env15581) = true)

theorem identity15581 : scanCanonicalize (H12AffineFastState.compose env15581 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15582 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,8,0,0,3,16,0,21,1,0,0,16,3,8,16,0,17,16,0,21,1,5,0,1,513]

theorem envBound15582 : H12AffineFastState.Bounded env15582 := by
  intro p hp
  have h : env15582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15581_15582 : H12AffineEnvironment.transform 4 0 env15581 = env15582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15581 == env15582) = true)

theorem identity15582 : scanCanonicalize (H12AffineFastState.compose env15582 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15582 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15583 : List Nat := [2,4,8,1,0,1,8,4,512,5,1,0,8,0,0,3,1,0,4,1,0,0,1,3,8,1,0,0,1,0,4,1,5,0,1,513]

theorem envBound15583 : H12AffineFastState.Bounded env15583 := by
  intro p hp
  have h : env15583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15582_15583 : H12AffineEnvironment.transform 3 1 env15582 = env15583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15582 == env15583) = true)

def env15584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,76158,1025,32769,115734,65910,119879,98645,8193,64,43357,115015,17664,76158,119043,8573,257,21793,46093,63069]

theorem envBound15584 : H12AffineFastState.Bounded env15584 := by
  intro p hp
  have h : env15584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15571_15584 : H12AffineEnvironment.transform 6 9 env15571 = env15584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15571 == env15584) = true)

theorem identity15584 : scanCanonicalize (H12AffineFastState.compose env15584 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15584 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,70727,76158,1025,1,82966,65910,87111,65877,8193,64,10589,82247,17664,76158,86275,8573,257,21793,13325,30301]

theorem envBound15585 : H12AffineFastState.Bounded env15585 := by
  intro p hp
  have h : env15585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15584_15585 : H12AffineEnvironment.transform 14 0 env15584 = env15585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15584 == env15585) = true)

theorem identity15585 : scanCanonicalize (H12AffineFastState.compose env15585 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound15585 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env15586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,29822,24633,23808,1025,1,12392,29960,8249,29995,8193,64,10589,13625,17664,23808,9597,8573,257,21793,13325,30301]

theorem envBound15586 : H12AffineFastState.Bounded env15586 := by
  intro p hp
  have h : env15586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15585_15586 : H12AffineEnvironment.transform 15 29822 env15585 = env15586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env15585 == env15586) = true)

theorem identity15586 : scanCanonicalize (H12AffineFastState.compose env15586 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound15586 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,34,5221,10588,1025,1,12392,340,8249,375,8193,64,10589,13625,12636,10588,9597,8573,257,8573,13325,513]

theorem envBound15587 : H12AffineFastState.Bounded env15587 := by
  intro p hp
  have h : env15587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15586_15587 : H12AffineEnvironment.transform 13 13404 env15586 = env15587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env15586 == env15587) = true)

theorem identity15587 : scanCanonicalize (H12AffineFastState.compose env15587 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound15587 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4113,0,34,5221,3345,1025,1,5157,340,1140,375,1100,64,3344,4468,5393,3345,304,1328,257,1328,4160,513]

theorem envBound15588 : H12AffineFastState.Bounded env15588 := by
  intro p hp
  have h : env15588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15587_15588 : H12AffineEnvironment.transform 12 1101 env15587 = env15588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env15587 == env15588) = true)

theorem identity15588 : scanCanonicalize (H12AffineFastState.compose env15588 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15588 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15589 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,41,4113,0,34,4097,2421,101,1,4161,340,16,375,40,64,2420,4468,4469,2421,304,340,257,340,4160,513]

theorem envBound15589 : H12AffineFastState.Bounded env15589 := by
  intro p hp
  have h : env15589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15588_15589 : H12AffineEnvironment.transform 9 100 env15588 = env15589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15588 == env15589) = true)

def env15590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180225,2114882,8328,64,6636867,115151,2266448,262145,2294098,4268163,257,213487,237642,2238085]

theorem envBound15590 : H12AffineFastState.Bounded env15590 := by
  intro p hp
  have h : env15590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15471_15590 : H12AffineEnvironment.transform 22 180225 env15471 = env15590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env15471 == env15590) = true)

def env15591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,169234,8328,64,4691219,115151,17664,262145,119042,4268163,257,213487,237642,63189]

theorem envBound15591 : H12AffineFastState.Bounded env15591 := by
  intro p hp
  have h : env15591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15590_15591 : H12AffineEnvironment.transform 20 184400 env15590 = env15591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env15590 == env15591) = true)

end H12CloudChart0