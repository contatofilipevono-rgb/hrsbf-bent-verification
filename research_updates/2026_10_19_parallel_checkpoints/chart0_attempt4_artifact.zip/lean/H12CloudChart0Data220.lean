import H12CloudChart0Data219

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans55707_55708 : H12AffineEnvironment.transform 17 179512 env55707 = env55708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env55707 == env55708) = true)

theorem identity55708 : scanCanonicalize (H12AffineFastState.compose env55708 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound55708 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1025,32769,4160,32,16,41311,8193,64,64604,5393,17665,32041,1365,62589,257,21792,46092,512]

theorem envBound55709 : H12AffineFastState.Bounded env55709 := by
  intro p hp
  have h : env55709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55708_55709 : H12AffineEnvironment.transform 16 38161 env55708 = env55709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env55708 == env55709) = true)

theorem identity55709 : scanCanonicalize (H12AffineFastState.compose env55709 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound55709 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,32768,8203,38161,10281,1025,32769,4160,32,16,41311,8193,64,47437,5393,16,14392,1365,45420,257,4145,46092,512]

theorem envBound55710 : H12AffineFastState.Bounded env55710 := by
  intro p hp
  have h : env55710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55709_55710 : H12AffineEnvironment.transform 13 1297 env55709 = env55710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env55709 == env55710) = true)

theorem identity55710 : scanCanonicalize (H12AffineFastState.compose env55710 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12345) := by decide +kernel

theorem selectedBound55710 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,12345,8203,9512,10281,1025,12344,4160,32,16,4454,8193,64,2420,5393,16,14392,1365,341,257,4145,1077,512]

theorem envBound55711 : H12AffineFastState.Bounded env55711 := by
  intro p hp
  have h : env55711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55710_55711 : H12AffineEnvironment.transform 14 12345 env55710 = env55711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12345 env55710 == env55711) = true)

theorem identity55711 : scanCanonicalize (H12AffineFastState.compose env55711 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound55711 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55712 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,1297,12345,8203,9512,10281,1025,12344,4145,32,16,4375,8193,49,2309,5393,16,14392,1316,292,257,4145,1077,512]

theorem envBound55712 : H12AffineFastState.Bounded env55712 := by
  intro p hp
  have h : env55712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55711_55712 : H12AffineEnvironment.transform 5 49 env55711 = env55712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env55711 == env55712) = true)

def env55713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169217,98781,8328,64,64605,163840,17665,283904,168141,412109,257,21792,46213,243482]

theorem envBound55713 : H12AffineFastState.Bounded env55713 := by
  intro p hp
  have h : env55713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55700_55713 : H12AffineEnvironment.transform 21 272513 env55700 = env55713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env55700 == env55713) = true)

theorem identity55713 : scanCanonicalize (H12AffineFastState.compose env55713 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound55713 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,77898,272513,73754,98781,8328,64,64605,79131,17665,283904,75222,392406,257,21792,46213,513]

theorem envBound55714 : H12AffineFastState.Bounded env55714 := by
  intro p hp
  have h : env55714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55713_55714 : H12AffineEnvironment.transform 16 111899 env55713 = env55714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env55713 == env55714) = true)

def env55715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90139,262144,1025,21761,77898,272513,73754,87261,8328,64,10589,79131,17665,283904,75222,338390,257,21792,24965,513]

theorem envBound55715 : H12AffineFastState.Bounded env55715 := by
  intro p hp
  have h : env55715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55714_55715 : H12AffineEnvironment.transform 14 21760 env55714 = env55715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55714 == env55715) = true)

theorem identity55715 : scanCanonicalize (H12AffineFastState.compose env55715 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55715 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16400,262144,1025,21761,4161,272513,17,29910,8328,64,10589,5392,17665,283904,1501,264669,257,21792,24965,513]

theorem envBound55716 : H12AffineFastState.Bounded env55716 := by
  intro p hp
  have h : env55716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55715_55716 : H12AffineEnvironment.transform 15 8203 env55715 = env55716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55715 == env55716) = true)

theorem identity55716 : scanCanonicalize (H12AffineFastState.compose env55716 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound55716 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16400,2557,1025,21761,4161,8572,17,29910,8328,64,10589,5392,17665,23805,1501,32,257,21792,24965,513]

theorem envBound55717 : H12AffineFastState.Bounded env55717 := by
  intro p hp
  have h : env55717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55716_55717 : H12AffineEnvironment.transform 17 2557 env55716 = env55717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env55716 == env55717) = true)

theorem identity55717 : scanCanonicalize (H12AffineFastState.compose env55717 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound55717 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,136,8203,5528,2557,1025,137,4161,8572,17,8542,8328,64,10589,5392,4233,2421,1501,32,257,168,13325,513]

theorem envBound55718 : H12AffineFastState.Bounded env55718 := by
  intro p hp
  have h : env55718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55717_55718 : H12AffineEnvironment.transform 13 5512 env55717 = env55718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env55717 == env55718) = true)

theorem identity55718 : scanCanonicalize (H12AffineFastState.compose env55718 (packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound55718 : packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env55719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5512,136,431,5528,2557,1025,137,4161,216,17,250,300,64,2297,5392,4233,2421,1501,32,257,168,5545,513]

theorem envBound55719 : H12AffineFastState.Bounded env55719 := by
  intro p hp
  have h : env55719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55718_55719 : H12AffineEnvironment.transform 12 420 env55718 = env55719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env55718 == env55719) = true)

theorem identity55719 : scanCanonicalize (H12AffineFastState.compose env55719 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound55719 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env55720 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,5488,112,343,5472,2309,1025,113,4161,32,17,2,300,64,2049,5392,4209,2421,1317,32,257,80,5457,513]

theorem envBound55720 : H12AffineFastState.Bounded env55720 := by
  intro p hp
  have h : env55720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55719_55720 : H12AffineEnvironment.transform 6 120 env55719 = env55720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env55719 == env55720) = true)

theorem identity55720 : scanCanonicalize (H12AffineFastState.compose env55720 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55720 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55721 : List Nat := [2,4,8,16,32,64,120,84,512,1024,2048,4096,8,5156,112,3,5172,2129,1025,113,4161,32,17,2,120,64,2049,5188,4209,2081,1137,32,85,80,5125,513]

theorem envBound55721 : H12AffineFastState.Bounded env55721 := by
  intro p hp
  have h : env55721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55720_55721 : H12AffineEnvironment.transform 7 84 env55720 = env55721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55720 == env55721) = true)

theorem identity55721 : scanCanonicalize (H12AffineFastState.compose env55721 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound55721 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env55722 : List Nat := [2,4,8,16,32,64,120,84,512,1024,2048,1093,8,97,112,3,113,2129,1025,113,1028,32,17,2,120,64,2049,1,1076,2081,1137,32,85,80,64,513]

theorem envBound55722 : H12AffineFastState.Bounded env55722 := by
  intro p hp
  have h : env55722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55721_55722 : H12AffineEnvironment.transform 11 1093 env55721 = env55722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env55721 == env55722) = true)

theorem identity55722 : scanCanonicalize (H12AffineFastState.compose env55722 (packedSelected [0,3,5,7,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound55722 : packedSelected [0,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env55723 : List Nat := [2,4,8,16,32,64,120,84,512,1024,17,1093,8,97,112,3,113,64,1025,113,1028,32,17,2,120,64,16,1,1076,48,1137,32,85,80,64,513]

theorem envBound55723 : H12AffineFastState.Bounded env55723 := by
  intro p hp
  have h : env55723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55722_55723 : H12AffineEnvironment.transform 10 17 env55722 = env55723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env55722 == env55723) = true)

theorem identity55723 : scanCanonicalize (H12AffineFastState.compose env55723 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55723 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55724 : List Nat := [2,4,8,1,32,64,105,69,512,1024,0,1093,8,97,97,3,96,64,1025,96,1028,32,0,2,105,64,1,1,1061,33,1120,32,68,65,64,513]

theorem envBound55724 : H12AffineFastState.Bounded env55724 := by
  intro p hp
  have h : env55724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55723_55724 : H12AffineEnvironment.transform 3 1 env55723 = env55724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55723 == env55724) = true)

theorem identity55724 : scanCanonicalize (H12AffineFastState.compose env55724 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound55724 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55725 : List Nat := [2,4,8,1,32,64,105,69,65,1024,0,1093,8,97,97,3,96,64,1025,96,1028,32,0,2,105,64,1,1,1061,33,1120,32,68,65,64,64]

theorem envBound55725 : H12AffineFastState.Bounded env55725 := by
  intro p hp
  have h : env55725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55724_55725 : H12AffineEnvironment.transform 8 65 env55724 = env55725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env55724 == env55725) = true)

theorem identity55725 : scanCanonicalize (H12AffineFastState.compose env55725 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound55725 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55726 : List Nat := [2,4,8,1,32,64,105,69,65,1,0,68,8,97,97,3,96,64,0,96,5,32,0,2,105,64,1,1,36,33,97,32,68,65,64,64]

theorem envBound55726 : H12AffineFastState.Bounded env55726 := by
  intro p hp
  have h : env55726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55725_55726 : H12AffineEnvironment.transform 9 1 env55725 = env55726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env55725 == env55726) = true)

theorem identity55726 : scanCanonicalize (H12AffineFastState.compose env55726 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55726 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env55727 : List Nat := [2,4,8,1,11,64,66,69,65,1,0,68,8,74,74,3,75,64,0,75,5,11,0,2,66,64,1,1,15,10,74,11,68,65,64,64]

theorem envBound55727 : H12AffineFastState.Bounded env55727 := by
  intro p hp
  have h : env55727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55726_55727 : H12AffineEnvironment.transform 4 11 env55726 = env55727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55726 == env55727) = true)

theorem identity55727 : scanCanonicalize (H12AffineFastState.compose env55727 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound55727 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env55728 : List Nat := [2,4,8,1,11,2,0,7,3,1,0,6,8,8,8,3,9,2,0,9,5,11,0,2,0,2,1,1,15,10,8,11,6,3,2,2]

theorem envBound55728 : H12AffineFastState.Bounded env55728 := by
  intro p hp
  have h : env55728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55727_55728 : H12AffineEnvironment.transform 5 2 env55727 = env55728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env55727 == env55728) = true)

theorem identity55728 : scanCanonicalize (H12AffineFastState.compose env55728 (packedSelected [0,1,2,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55728 : packedSelected [0,1,2,10] rootPS < 2^1333 := by decide +kernel

def env55729 : List Nat := [2,2,8,1,11,2,0,1,3,1,0,0,8,8,8,3,9,2,0,9,3,11,0,2,0,2,1,1,9,10,8,11,0,3,2,2]

theorem envBound55729 : H12AffineFastState.Bounded env55729 := by
  intro p hp
  have h : env55729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55728_55729 : H12AffineEnvironment.transform 1 2 env55728 = env55729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55728 == env55729) = true)

theorem identity55729 : scanCanonicalize (H12AffineFastState.compose env55729 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55730 : List Nat := [2,2,3,1,0,2,0,1,3,1,0,0,3,3,3,3,2,2,0,2,3,0,0,2,0,2,1,1,2,1,3,0,0,3,2,2]

theorem envBound55730 : H12AffineFastState.Bounded env55730 := by
  intro p hp
  have h : env55730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55729_55730 : H12AffineEnvironment.transform 2 3 env55729 = env55730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55729 == env55730) = true)

theorem identity55730 : scanCanonicalize (H12AffineFastState.compose env55730 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55731 : List Nat := [1,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,1,1,0,1,0,0,0,1,0,1,1,1,1,1,0,0,0,0,1,1]

theorem envBound55731 : H12AffineFastState.Bounded env55731 := by
  intro p hp
  have h : env55731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55730_55731 : H12AffineEnvironment.transform 0 1 env55730 = env55731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55730 == env55731) = true)

def env55732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90138,262144,1025,21760,77898,272513,73754,87260,8328,64,10588,79131,17665,283904,75222,338391,257,21792,24964,513]

theorem envBound55732 : H12AffineFastState.Bounded env55732 := by
  intro p hp
  have h : env55732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55714_55732 : H12AffineEnvironment.transform 14 21761 env55714 = env55732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env55714 == env55732) = true)

def env55733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90138,262144,1025,21760,77898,272393,73754,87124,8192,64,10588,79131,17665,283904,75102,338271,257,21792,24844,513]

theorem envBound55733 : H12AffineFastState.Bounded env55733 := by
  intro p hp
  have h : env55733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55732_55733 : H12AffineEnvironment.transform 6 8 env55732 = env55733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55732 == env55733) = true)

theorem identity55733 : scanCanonicalize (H12AffineFastState.compose env55733 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound55733 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env55734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,21761,65536,82951,262144,1025,21760,70743,265236,66567,87124,1053,64,3393,69894,17665,283904,65859,331074,257,21792,17681,513]

theorem envBound55734 : H12AffineFastState.Bounded env55734 := by
  intro p hp
  have h : env55734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55733_55734 : H12AffineEnvironment.transform 12 1053 env55733 = env55734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env55733 == env55734) = true)

theorem identity55734 : scanCanonicalize (H12AffineFastState.compose env55734 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound55734 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env55735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4404,1077,65536,70963,262144,1025,1076,70743,265236,66567,66912,1053,64,3393,69894,5173,263220,65859,331074,257,1044,5157,513]

theorem envBound55735 : H12AffineFastState.Bounded env55735 := by
  intro p hp
  have h : env55735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55734_55735 : H12AffineEnvironment.transform 13 4404 env55734 = env55735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env55734 == env55735) = true)

theorem identity55735 : scanCanonicalize (H12AffineFastState.compose env55735 (packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound55735 : packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env55736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4404,1077,1047,4388,262144,1025,1076,4160,265236,16,375,1053,64,3393,5393,5173,263220,1364,264533,257,1044,5157,513]

theorem envBound55736 : H12AffineFastState.Bounded env55736 := by
  intro p hp
  have h : env55736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55735_55736 : H12AffineEnvironment.transform 15 1047 env55735 = env55736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env55735 == env55736) = true)

theorem identity55736 : scanCanonicalize (H12AffineFastState.compose env55736 (packedSelected [14] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound55736 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env55737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4404,1077,1047,4388,3173,1025,1076,4160,113,16,375,1053,64,3393,5393,5173,2129,1364,1328,257,1044,5157,513]

theorem envBound55737 : H12AffineFastState.Bounded env55737 := by
  intro p hp
  have h : env55737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55736_55737 : H12AffineEnvironment.transform 17 3173 env55736 = env55737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env55736 == env55737) = true)

theorem identity55737 : scanCanonicalize (H12AffineFastState.compose env55737 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound55737 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env55738 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,348,4404,372,342,4388,2340,320,373,4160,113,16,375,348,64,2048,4176,4468,2129,21,113,257,341,4452,513]

theorem envBound55738 : H12AffineFastState.Bounded env55738 := by
  intro p hp
  have h : env55738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55737_55738 : H12AffineEnvironment.transform 9 321 env55737 = env55738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env55737 == env55738) = true)

theorem identity55738 : scanCanonicalize (H12AffineFastState.compose env55738 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55738 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55739 : List Nat := [2,4,8,16,32,64,8,37,512,100,2048,4096,121,4113,81,115,4097,2049,101,80,4160,113,16,82,121,64,2048,4176,4177,2129,21,113,36,112,4161,513]

theorem envBound55739 : H12AffineFastState.Bounded env55739 := by
  intro p hp
  have h : env55739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55738_55739 : H12AffineEnvironment.transform 7 37 env55738 = env55739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55738 == env55739) = true)

def env55740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,90138,262144,1025,21760,77898,272392,73754,87125,8193,64,10588,79131,17665,283904,75103,338270,257,21792,24845,513]

theorem envBound55740 : H12AffineFastState.Bounded env55740 := by
  intro p hp
  have h : env55740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55732_55740 : H12AffineEnvironment.transform 6 9 env55732 = env55740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55732 == env55740) = true)

theorem identity55740 : scanCanonicalize (H12AffineFastState.compose env55740 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55740 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env55741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,24908,262144,1025,21760,12572,272392,8524,21763,8193,64,10588,13389,17665,283904,9225,272392,257,21792,24845,513]

theorem envBound55741 : H12AffineFastState.Bounded env55741 := by
  intro p hp
  have h : env55741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55740_55741 : H12AffineEnvironment.transform 15 342 env55740 = env55741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55740 == env55741) = true)

theorem identity55741 : scanCanonicalize (H12AffineFastState.compose env55741 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound55741 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,24908,2421,1025,21760,12572,8573,8524,21763,8193,64,10588,13389,17665,23669,9225,8573,257,21792,24845,513]

theorem envBound55742 : H12AffineFastState.Bounded env55742 := by
  intro p hp
  have h : env55742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55741_55742 : H12AffineEnvironment.transform 17 2421 env55741 = env55742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env55741 == env55742) = true)

theorem identity55742 : scanCanonicalize (H12AffineFastState.compose env55742 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,16400,2421,1025,21760,4160,33,16,21763,349,64,2048,5393,17665,23669,1365,33,257,21792,16465,513]

theorem envBound55743 : H12AffineFastState.Bounded env55743 := by
  intro p hp
  have h : env55743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55742_55743 : H12AffineEnvironment.transform 12 348 env55742 = env55743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55742 == env55743) = true)

theorem identity55743 : scanCanonicalize (H12AffineFastState.compose env55743 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55743 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5392,2421,1025,0,4160,33,16,3,349,64,2048,5393,4097,2421,1365,33,257,32,5457,513]

theorem envBound55744 : H12AffineFastState.Bounded env55744 := by
  intro p hp
  have h : env55744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55743_55744 : H12AffineEnvironment.transform 13 5376 env55743 = env55744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55743 == env55744) = true)

theorem identity55744 : scanCanonicalize (H12AffineFastState.compose env55744 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55744 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55745 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,35,5221,2048,1025,0,4160,33,16,3,40,64,2048,5220,4097,2048,1056,33,116,32,5156,513]

theorem envBound55745 : H12AffineFastState.Bounded env55745 := by
  intro p hp
  have h : env55745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55744_55745 : H12AffineEnvironment.transform 7 117 env55744 = env55745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55744 == env55745) = true)

theorem identity55745 : scanCanonicalize (H12AffineFastState.compose env55745 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55745 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55746 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5172,2048,1025,0,4113,33,16,3,40,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound55746 : H12AffineFastState.Bounded env55746 := by
  intro p hp
  have h : env55746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55745_55746 : H12AffineEnvironment.transform 5 17 env55745 = env55746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55745 == env55746) = true)

def env55747 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,1,35,1028,2048,1025,0,33,33,16,3,40,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound55747 : H12AffineFastState.Bounded env55747 := by
  intro p hp
  have h : env55747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55746_55747 : H12AffineEnvironment.transform 11 48 env55746 = env55747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55746 == env55747) = true)

theorem identity55747 : scanCanonicalize (H12AffineFastState.compose env55747 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound55747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55748 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,48,41,1044,1,35,1028,1572,1025,0,33,33,16,3,40,17,1572,1029,49,1572,1056,33,37,32,1044,513]

theorem envBound55748 : H12AffineFastState.Bounded env55748 := by
  intro p hp
  have h : env55748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55747_55748 : H12AffineEnvironment.transform 10 1572 env55747 = env55748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env55747 == env55748) = true)

def env55749 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,41,32,1,35,48,528,53,0,33,33,16,3,40,17,528,49,49,528,20,33,37,32,32,513]

theorem envBound55749 : H12AffineFastState.Bounded env55749 := by
  intro p hp
  have h : env55749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55748_55749 : H12AffineEnvironment.transform 9 52 env55748 = env55749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55748 == env55749) = true)

theorem identity55749 : scanCanonicalize (H12AffineFastState.compose env55749 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55749 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55750 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,48,41,32,1,35,48,58,53,0,33,33,16,3,40,17,58,49,49,58,20,33,37,32,32,43]

theorem envBound55750 : H12AffineFastState.Bounded env55750 := by
  intro p hp
  have h : env55750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55749_55750 : H12AffineEnvironment.transform 8 42 env55749 = env55750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55749 == env55750) = true)

def leafEnv55750 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,48,41,32,1,35,48,58,53,0,33,33,16,3,21,40,1,17,58,49,49,58,20,33,37,32,5,34,32,43,1,33,0]

def active55750 : List Nat := [0,1,2,3,4]

def tree55750 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55750 : H12WitnessSearch.Good tree55750 := H12GlobalWitnessIndex.good

theorem leafIdentity55750 : H12AffineFastState.composeSystem env55750 rootObs = leafEnv55750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55750 rootObs == leafEnv55750) = true)

theorem terminalChecked55750 : H12PackedTerminal.terminalCheckFast leafEnv55750 active55750 tree55750 = true := by decide +kernel

def env55751 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,41,33,1,35,49,529,52,0,33,33,16,3,40,17,529,48,49,529,21,33,37,32,33,513]

theorem envBound55751 : H12AffineFastState.Bounded env55751 := by
  intro p hp
  have h : env55751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55748_55751 : H12AffineEnvironment.transform 9 53 env55748 = env55751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55748 == env55751) = true)

def env55752 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,1,35,1029,2048,1025,0,32,33,16,3,40,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound55752 : H12AffineFastState.Bounded env55752 := by
  intro p hp
  have h : env55752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55746_55752 : H12AffineEnvironment.transform 11 49 env55746 = env55752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55746 == env55752) = true)

theorem identity55752 : scanCanonicalize (H12AffineFastState.compose env55752 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound55752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55753 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,49,41,1045,1,35,1029,528,1025,0,32,33,16,3,40,17,528,1028,48,528,1056,33,37,32,1045,513]

theorem envBound55753 : H12AffineFastState.Bounded env55753 := by
  intro p hp
  have h : env55753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55752_55753 : H12AffineEnvironment.transform 10 528 env55752 = env55753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env55752 == env55753) = true)

def env55754 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,41,33,1,35,49,528,53,0,32,33,16,3,40,17,528,48,48,528,20,33,37,32,33,513]

theorem envBound55754 : H12AffineFastState.Bounded env55754 := by
  intro p hp
  have h : env55754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55753_55754 : H12AffineEnvironment.transform 9 52 env55753 = env55754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55753 == env55754) = true)

theorem identity55754 : scanCanonicalize (H12AffineFastState.compose env55754 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55755 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,49,41,33,1,35,49,59,53,0,32,33,16,3,40,17,59,48,48,59,20,33,37,32,33,42]

theorem envBound55755 : H12AffineFastState.Bounded env55755 := by
  intro p hp
  have h : env55755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55754_55755 : H12AffineEnvironment.transform 8 43 env55754 = env55755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55754 == env55755) = true)

def leafEnv55755 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,49,41,33,1,35,49,59,53,0,32,33,16,3,21,40,1,17,59,48,48,59,20,33,37,32,5,34,33,42,1,32,0]

def active55755 : List Nat := [0,1,2,3,4]

def tree55755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55755 : H12WitnessSearch.Good tree55755 := H12GlobalWitnessIndex.good

theorem leafIdentity55755 : H12AffineFastState.composeSystem env55755 rootObs = leafEnv55755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55755 rootObs == leafEnv55755) = true)

theorem terminalChecked55755 : H12PackedTerminal.terminalCheckFast leafEnv55755 active55755 tree55755 = true := by decide +kernel

def env55756 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,41,32,1,35,48,528,52,0,32,33,16,3,40,17,528,49,48,528,21,33,37,32,32,513]

theorem envBound55756 : H12AffineFastState.Bounded env55756 := by
  intro p hp
  have h : env55756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55753_55756 : H12AffineEnvironment.transform 9 53 env55753 = env55756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55753 == env55756) = true)

def env55757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,8388608,8590557,8328,64,4510941,8393984,8572928,8830977,168140,12645452,257,21793,46212,243483]

theorem envBound55757 : H12AffineFastState.Bounded env55757 := by
  intro p hp
  have h : env55757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55663_55757 : H12AffineEnvironment.transform 23 8590557 env55663 = env55757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590557 env55663 == env55757) = true)

def env55758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169216,98781,8328,64,4510941,163840,17664,283905,168140,4350284,257,21793,46212,243483]

theorem envBound55758 : H12AffineFastState.Bounded env55758 := by
  intro p hp
  have h : env55758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55757_55758 : H12AffineEnvironment.transform 22 169216 env55757 = env55758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env55757 == env55758) = true)

def env55759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169216,98781,8328,64,64605,163840,17664,283905,168140,412108,257,21793,46212,243483]

theorem envBound55759 : H12AffineFastState.Bounded env55759 := by
  intro p hp
  have h : env55759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55758_55759 : H12AffineEnvironment.transform 21 272512 env55758 = env55759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env55758 == env55759) = true)

theorem identity55759 : scanCanonicalize (H12AffineFastState.compose env55759 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound55759 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272512,17,98781,8328,64,64605,5393,17664,283905,1501,318685,257,21793,46212,74250]

theorem envBound55760 : H12AffineFastState.Bounded env55760 := by
  intro p hp
  have h : env55760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55759_55760 : H12AffineEnvironment.transform 16 38161 env55759 = env55760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env55759 == env55760) = true)

theorem identity55760 : scanCanonicalize (H12AffineFastState.compose env55760 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55760 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env55761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4160,272512,17,41430,8328,64,64605,5393,17664,283905,1501,318685,257,21793,46212,513]

theorem envBound55761 : H12AffineFastState.Bounded env55761 := by
  intro p hp
  have h : env55761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55760_55761 : H12AffineEnvironment.transform 15 8203 env55760 = env55761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55760 == env55761) = true)

def env55762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169216,98781,8328,64,64604,163840,17664,283905,168140,412109,257,21793,46212,243483]

theorem envBound55762 : H12AffineFastState.Bounded env55762 := by
  intro p hp
  have h : env55762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55758_55762 : H12AffineEnvironment.transform 21 272513 env55758 = env55762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env55758 == env55762) = true)

def env55763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272393,169216,98645,8192,64,64604,163840,17664,283905,168004,411973,257,21793,46092,243483]

theorem envBound55763 : H12AffineFastState.Bounded env55763 := by
  intro p hp
  have h : env55763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55762_55763 : H12AffineEnvironment.transform 6 8 env55762 = env55763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55762 == env55763) = true)

theorem identity55763 : scanCanonicalize (H12AffineFastState.compose env55763 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound55763 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env55764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,131072,262144,1025,32769,165201,272393,169216,29791,8192,64,64604,163840,17664,283905,168004,411973,257,21793,46092,147985]

theorem envBound55764 : H12AffineFastState.Bounded env55764 := by
  intro p hp
  have h : env55764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55763_55764 : H12AffineEnvironment.transform 15 62730 env55763 = env55764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env55763 == env55764) = true)

theorem identity55764 : scanCanonicalize (H12AffineFastState.compose env55764 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound55764 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,57677,262144,1025,32769,25628,272393,29773,29791,8192,64,64604,24909,17664,283905,28937,305160,257,21793,46092,41820]

theorem envBound55765 : H12AffineFastState.Bounded env55765 := by
  intro p hp
  have h : env55765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55764_55765 : H12AffineEnvironment.transform 16 57677 env55764 = env55765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env55764 == env55765) = true)

theorem identity55765 : scanCanonicalize (H12AffineFastState.compose env55765 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55765 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env55766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21591,16400,262144,1025,8540,25628,272393,29773,29791,8192,64,23809,24909,17664,283905,28937,264533,257,21793,5457,513]

theorem envBound55766 : H12AffineFastState.Bounded env55766 := by
  intro p hp
  have h : env55766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55765_55766 : H12AffineEnvironment.transform 14 8541 env55765 = env55766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55765 == env55766) = true)

theorem identity55766 : scanCanonicalize (H12AffineFastState.compose env55766 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11577) := by decide +kernel

theorem selectedBound55766 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21591,16400,11577,1025,8540,25628,1328,29773,29791,8192,64,23809,24909,17664,30776,28937,9324,257,21793,5457,513]

theorem envBound55767 : H12AffineFastState.Bounded env55767 := by
  intro p hp
  have h : env55767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55766_55767 : H12AffineEnvironment.transform 17 11577 env55766 = env55767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11577 env55766 == env55767) = true)

theorem identity55767 : scanCanonicalize (H12AffineFastState.compose env55767 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55767 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env55768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8202,13389,11577,1025,8540,4161,1328,16,2,8192,64,10588,5392,12637,3173,1364,9324,257,8572,5457,513]

theorem envBound55768 : H12AffineFastState.Bounded env55768 := by
  intro p hp
  have h : env55768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55767_55768 : H12AffineEnvironment.transform 13 13405 env55767 = env55768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55767 == env55768) = true)

theorem identity55768 : scanCanonicalize (H12AffineFastState.compose env55768 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound55768 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4405,1077,1378,4389,2129,1025,1076,4161,1328,16,2,1384,64,3124,5392,5173,3173,1364,260,257,1044,5457,513]

theorem envBound55769 : H12AffineFastState.Bounded env55769 := by
  intro p hp
  have h : env55769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55768_55769 : H12AffineEnvironment.transform 12 1384 env55768 = env55769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env55768 == env55769) = true)

theorem identity55769 : scanCanonicalize (H12AffineFastState.compose env55769 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55769 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env55770 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1336,4405,1077,1330,4389,2049,1025,1076,4113,1328,16,2,1336,16,3124,5392,5173,3125,1284,260,257,1044,5377,513]

theorem envBound55770 : H12AffineFastState.Bounded env55770 := by
  intro p hp
  have h : env55770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55769_55770 : H12AffineEnvironment.transform 5 16 env55769 = env55770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55769 == env55770) = true)

theorem identity55770 : scanCanonicalize (H12AffineFastState.compose env55770 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55770 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55771 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,4113,1077,1046,4097,2049,1025,1076,4113,1044,16,2,1052,16,3124,5172,5173,3125,1056,32,37,1044,5157,513]

theorem envBound55771 : H12AffineFastState.Bounded env55771 := by
  intro p hp
  have h : env55771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55770_55771 : H12AffineEnvironment.transform 7 36 env55770 = env55771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55770 == env55771) = true)

theorem identity55771 : scanCanonicalize (H12AffineFastState.compose env55771 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55771 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55772 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,41,4113,0,35,4097,2049,52,1,4113,33,16,2,41,16,2049,4097,4096,2048,21,32,37,33,4112,513]

theorem envBound55772 : H12AffineFastState.Bounded env55772 := by
  intro p hp
  have h : env55772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55771_55772 : H12AffineEnvironment.transform 9 53 env55771 = env55772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55771 == env55772) = true)

theorem identity55772 : scanCanonicalize (H12AffineFastState.compose env55772 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound55772 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55773 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,4096,41,4113,0,35,4097,49,52,1,4113,33,16,2,41,16,49,4097,4096,48,21,32,37,33,4112,513]

theorem envBound55773 : H12AffineFastState.Bounded env55773 := by
  intro p hp
  have h : env55773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55772_55773 : H12AffineEnvironment.transform 10 48 env55772 = env55773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env55772 == env55773) = true)

theorem identity55773 : scanCanonicalize (H12AffineFastState.compose env55773 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound55773 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55774 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,41,49,0,35,33,49,52,1,49,33,16,2,41,16,49,33,32,48,21,32,37,33,48,513]

theorem envBound55774 : H12AffineFastState.Bounded env55774 := by
  intro p hp
  have h : env55774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55773_55774 : H12AffineEnvironment.transform 11 32 env55773 = env55774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env55773 == env55774) = true)

def leafEnv55774 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,41,49,0,35,33,49,52,1,49,33,16,2,20,41,1,16,49,33,32,48,21,32,37,33,5,35,48,513,1,48,0]

def active55774 : List Nat := [0,1,2,3,4,8]

def tree55774 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55774 : H12WitnessSearch.Good tree55774 := H12GlobalWitnessIndex.good

theorem leafIdentity55774 : H12AffineFastState.composeSystem env55774 rootObs = leafEnv55774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55774 rootObs == leafEnv55774) = true)

theorem terminalChecked55774 : H12PackedTerminal.terminalCheckFast leafEnv55774 active55774 tree55774 = true := by decide +kernel

def env55775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272392,169216,98644,8193,64,64604,163840,17664,283905,168005,411972,257,21793,46093,243483]

theorem envBound55775 : H12AffineFastState.Bounded env55775 := by
  intro p hp
  have h : env55775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55762_55775 : H12AffineEnvironment.transform 6 9 env55762 = env55775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55762 == env55775) = true)

def env55776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272392,16,98644,8193,64,64604,5392,17664,283905,1365,318548,257,21793,46093,74251]

theorem envBound55776 : H12AffineFastState.Bounded env55776 := by
  intro p hp
  have h : env55776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55775_55776 : H12AffineEnvironment.transform 16 38160 env55775 = env55776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env55775 == env55776) = true)

theorem identity55776 : scanCanonicalize (H12AffineFastState.compose env55776 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55776 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env55777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,4161,272392,16,41310,8193,64,64604,5392,17664,283905,1365,318548,257,21793,46093,513]

theorem envBound55777 : H12AffineFastState.Bounded env55777 := by
  intro p hp
  have h : env55777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55776_55777 : H12AffineEnvironment.transform 15 8202 env55776 = env55777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55776 == env55777) = true)

theorem identity55777 : scanCanonicalize (H12AffineFastState.compose env55777 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound55777 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,16400,262144,1025,21761,4161,272392,16,29790,8193,64,10588,5392,17664,283905,1365,264532,257,21793,24845,513]

theorem envBound55778 : H12AffineFastState.Bounded env55778 := by
  intro p hp
  have h : env55778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55777_55778 : H12AffineEnvironment.transform 14 21760 env55777 = env55778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55777 == env55778) = true)

theorem identity55778 : scanCanonicalize (H12AffineFastState.compose env55778 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55778 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8202,13389,262144,1025,8540,4161,272392,16,3,8193,64,10588,5392,12637,270684,1365,264532,257,8572,5456,513]

theorem envBound55779 : H12AffineFastState.Bounded env55779 := by
  intro p hp
  have h : env55779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55778_55779 : H12AffineEnvironment.transform 13 13405 env55778 = env55779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55778 == env55779) = true)

theorem identity55779 : scanCanonicalize (H12AffineFastState.compose env55779 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55779 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,80,263,5440,262144,1025,81,4161,264453,16,3,268,64,2129,5392,4176,262225,1365,264532,257,113,5456,513]

theorem envBound55780 : H12AffineFastState.Bounded env55780 := by
  intro p hp
  have h : env55780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55779_55780 : H12AffineEnvironment.transform 12 269 env55779 = env55780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55779 == env55780) = true)

theorem identity55780 : scanCanonicalize (H12AffineFastState.compose env55780 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55780 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55781 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5237,80,34,5221,262144,1025,81,4161,264224,16,3,41,64,2129,5173,4176,262225,1136,264305,36,113,5237,513]

theorem envBound55781 : H12AffineFastState.Bounded env55781 := by
  intro p hp
  have h : env55781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55780_55781 : H12AffineEnvironment.transform 7 37 env55780 = env55781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55780 == env55781) = true)

theorem identity55781 : scanCanonicalize (H12AffineFastState.compose env55781 (packedSelected [0,2,7] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound55781 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55782 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5237,80,34,5221,2049,1025,81,4161,33,16,3,41,64,2129,5173,4176,2128,1136,112,36,113,5237,513]

theorem envBound55782 : H12AffineFastState.Bounded env55782 := by
  intro p hp
  have h : env55782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55781_55782 : H12AffineEnvironment.transform 17 2049 env55781 = env55782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env55781 == env55782) = true)

theorem identity55782 : scanCanonicalize (H12AffineFastState.compose env55782 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55782 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55783 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,1,34,5172,2049,1025,0,4112,33,16,3,41,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound55783 : H12AffineFastState.Bounded env55783 := by
  intro p hp
  have h : env55783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55782_55783 : H12AffineEnvironment.transform 5 17 env55782 = env55783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55782 == env55783) = true)

def env55784 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1044,1,34,1028,2049,1025,0,32,33,16,3,41,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound55784 : H12AffineFastState.Bounded env55784 := by
  intro p hp
  have h : env55784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55783_55784 : H12AffineEnvironment.transform 11 48 env55783 = env55784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55783 == env55784) = true)

def env55785 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,40,32,1,34,48,2049,53,0,32,33,16,3,41,17,2048,49,49,2049,21,33,36,32,32,513]

theorem envBound55785 : H12AffineFastState.Bounded env55785 := by
  intro p hp
  have h : env55785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55784_55785 : H12AffineEnvironment.transform 9 52 env55784 = env55785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55784 == env55785) = true)

theorem identity55785 : scanCanonicalize (H12AffineFastState.compose env55785 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55786 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,48,40,32,1,34,48,2049,53,0,32,33,16,3,41,17,2048,49,49,2049,21,33,36,32,32,42]

theorem envBound55786 : H12AffineFastState.Bounded env55786 := by
  intro p hp
  have h : env55786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55785_55786 : H12AffineEnvironment.transform 8 43 env55785 = env55786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55785 == env55786) = true)

def leafEnv55786 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,48,40,32,1,34,48,2049,53,0,32,33,16,3,20,41,1,17,2048,49,49,2049,21,33,36,32,5,35,32,42,1,32,0]

def active55786 : List Nat := [0,1,2,3,4,10]

def tree55786 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55786 : H12WitnessSearch.Good tree55786 := H12GlobalWitnessIndex.good

theorem leafIdentity55786 : H12AffineFastState.composeSystem env55786 rootObs = leafEnv55786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55786 rootObs == leafEnv55786) = true)

theorem terminalChecked55786 : H12PackedTerminal.terminalCheckFast leafEnv55786 active55786 tree55786 = true := by decide +kernel

def env55787 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,33,1,34,49,2049,52,0,32,33,16,3,41,17,2048,48,49,2049,20,33,36,32,33,513]

theorem envBound55787 : H12AffineFastState.Bounded env55787 := by
  intro p hp
  have h : env55787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55784_55787 : H12AffineEnvironment.transform 9 53 env55784 = env55787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55784 == env55787) = true)

def env55788 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1045,1,34,1029,2049,1025,0,33,33,16,3,41,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound55788 : H12AffineFastState.Bounded env55788 := by
  intro p hp
  have h : env55788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55783_55788 : H12AffineEnvironment.transform 11 49 env55783 = env55788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55783 == env55788) = true)

theorem identity55788 : scanCanonicalize (H12AffineFastState.compose env55788 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55788 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55789 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,33,1,34,49,2049,53,0,33,33,16,3,41,17,2048,48,48,2049,21,33,36,32,33,513]

theorem envBound55789 : H12AffineFastState.Bounded env55789 := by
  intro p hp
  have h : env55789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55788_55789 : H12AffineEnvironment.transform 9 52 env55788 = env55789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55788 == env55789) = true)

theorem identity55789 : scanCanonicalize (H12AffineFastState.compose env55789 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55789 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55790 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,49,40,33,1,34,49,2049,53,0,33,33,16,3,41,17,2048,48,48,2049,21,33,36,32,33,43]

theorem envBound55790 : H12AffineFastState.Bounded env55790 := by
  intro p hp
  have h : env55790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55789_55790 : H12AffineEnvironment.transform 8 42 env55789 = env55790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55789 == env55790) = true)

def leafEnv55790 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,49,40,33,1,34,49,2049,53,0,33,33,16,3,20,41,1,17,2048,48,48,2049,21,33,36,32,5,35,33,43,1,33,0]

def active55790 : List Nat := [0,1,2,3,4,10]

def tree55790 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55790 : H12WitnessSearch.Good tree55790 := H12GlobalWitnessIndex.good

theorem leafIdentity55790 : H12AffineFastState.composeSystem env55790 rootObs = leafEnv55790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55790 rootObs == leafEnv55790) = true)

theorem terminalChecked55790 : H12PackedTerminal.terminalCheckFast leafEnv55790 active55790 tree55790 = true := by decide +kernel

def env55791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272392,17,98644,8193,64,64604,5393,17664,283905,1364,318549,257,21793,46093,74250]

theorem envBound55791 : H12AffineFastState.Bounded env55791 := by
  intro p hp
  have h : env55791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55775_55791 : H12AffineEnvironment.transform 16 38161 env55775 = env55791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env55775 == env55791) = true)

theorem identity55791 : scanCanonicalize (H12AffineFastState.compose env55791 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55791 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,33,17,98644,8193,64,64604,5393,17664,32040,1364,62588,257,21793,46093,74250]

theorem envBound55792 : H12AffineFastState.Bounded env55792 := by
  intro p hp
  have h : env55792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55791_55792 : H12AffineEnvironment.transform 17 10281 env55791 = env55792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55791 == env55792) = true)

theorem identity55792 : scanCanonicalize (H12AffineFastState.compose env55792 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound55792 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env55793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,24908,10281,1025,29788,4160,33,17,95497,8193,64,2049,5393,17664,32040,1364,33,257,21793,16464,74250]

theorem envBound55793 : H12AffineFastState.Bounded env55793 := by
  intro p hp
  have h : env55793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55792_55793 : H12AffineEnvironment.transform 14 29789 env55792 = env55793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env55792 == env55793) = true)

theorem identity55793 : scanCanonicalize (H12AffineFastState.compose env55793 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55793 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,24908,10281,1025,29788,4160,33,17,29791,8193,64,2049,5393,17664,32040,1364,33,257,21793,16464,9052]

theorem envBound55794 : H12AffineFastState.Bounded env55794 := by
  intro p hp
  have h : env55794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55793_55794 : H12AffineEnvironment.transform 15 342 env55793 = env55794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55793 == env55794) = true)

theorem identity55794 : scanCanonicalize (H12AffineFastState.compose env55794 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55794 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env55795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,342,13389,10281,1025,8541,4160,33,17,8542,8193,64,2049,5393,4097,10281,1364,33,257,32,5457,9052]

theorem envBound55795 : H12AffineFastState.Bounded env55795 := by
  intro p hp
  have h : env55795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55794_55795 : H12AffineEnvironment.transform 13 5377 env55794 = env55795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55794 == env55795) = true)

theorem identity55795 : scanCanonicalize (H12AffineFastState.compose env55795 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound55795 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2396,5377,2048,342,7441,373,1025,2049,4160,33,17,2050,2397,64,2049,5393,4097,373,1364,33,257,32,5457,2560]

theorem envBound55796 : H12AffineFastState.Bounded env55796 := by
  intro p hp
  have h : env55796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55795_55796 : H12AffineEnvironment.transform 12 2396 env55795 = env55796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env55795 == env55796) = true)

theorem identity55796 : scanCanonicalize (H12AffineFastState.compose env55796 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55796 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env55797 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,2396,5377,2048,342,7441,340,1025,2049,4160,0,17,2050,2397,64,2049,5393,4097,340,1364,0,257,1,5457,2560]

theorem envBound55797 : H12AffineFastState.Bounded env55797 := by
  intro p hp
  have h : env55797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55796_55797 : H12AffineEnvironment.transform 4 1 env55796 = env55797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55796 == env55797) = true)

theorem identity55797 : scanCanonicalize (H12AffineFastState.compose env55797 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55797 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55798 : List Nat := [2,4,8,16,1,64,9,256,512,1024,1,4096,349,5377,1,342,5392,340,1025,0,4160,0,17,3,348,64,0,5393,4097,340,1364,0,257,1,5457,513]

theorem envBound55798 : H12AffineFastState.Bounded env55798 := by
  intro p hp
  have h : env55798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55797_55798 : H12AffineEnvironment.transform 10 1 env55797 = env55798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55797 == env55798) = true)

theorem identity55798 : scanCanonicalize (H12AffineFastState.compose env55798 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound55798 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55799 : List Nat := [2,4,8,16,1,64,9,256,512,1024,1,1360,349,81,1,342,64,340,1025,0,1296,0,17,3,348,64,0,65,1361,340,1364,0,257,1,1,513]

theorem envBound55799 : H12AffineFastState.Bounded env55799 := by
  intro p hp
  have h : env55799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55798_55799 : H12AffineEnvironment.transform 11 1360 env55798 = env55799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env55798 == env55799) = true)

theorem identity55799 : scanCanonicalize (H12AffineFastState.compose env55799 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound55799 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55800 : List Nat := [2,4,8,16,1,64,9,256,512,784,1,576,349,81,1,342,64,340,785,0,512,0,17,3,348,64,0,65,577,340,580,0,257,1,1,513]

theorem envBound55800 : H12AffineFastState.Bounded env55800 := by
  intro p hp
  have h : env55800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55799_55800 : H12AffineEnvironment.transform 9 784 env55799 = env55800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env55799 == env55800) = true)

theorem identity55800 : scanCanonicalize (H12AffineFastState.compose env55800 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound55800 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55801 : List Nat := [2,4,8,16,1,64,9,256,17,257,1,81,349,81,1,342,64,340,256,0,17,0,17,3,348,64,0,65,80,340,85,0,257,1,1,16]

theorem envBound55801 : H12AffineFastState.Bounded env55801 := by
  intro p hp
  have h : env55801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55800_55801 : H12AffineEnvironment.transform 8 17 env55800 = env55801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env55800 == env55801) = true)

theorem identity55801 : scanCanonicalize (H12AffineFastState.compose env55801 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55801 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55802 : List Nat := [2,4,8,16,1,64,9,84,17,85,1,81,9,81,1,2,64,0,84,0,17,0,17,3,8,64,0,65,80,0,85,0,85,1,1,16]

theorem envBound55802 : H12AffineFastState.Bounded env55802 := by
  intro p hp
  have h : env55802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55801_55802 : H12AffineEnvironment.transform 7 84 env55801 = env55802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55801 == env55802) = true)

def env55803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169217,98780,8328,64,4510941,163841,17665,283904,168140,4350285,257,21793,46212,243483]

theorem envBound55803 : H12AffineFastState.Bounded env55803 := by
  intro p hp
  have h : env55803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55757_55803 : H12AffineEnvironment.transform 22 169217 env55757 = env55803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env55757 == env55803) = true)

def env55804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169217,98780,8328,64,64605,163841,17665,283904,168140,412109,257,21793,46212,243483]

theorem envBound55804 : H12AffineFastState.Bounded env55804 := by
  intro p hp
  have h : env55804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55803_55804 : H12AffineEnvironment.transform 21 272512 env55803 = env55804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env55803 == env55804) = true)

theorem identity55804 : scanCanonicalize (H12AffineFastState.compose env55804 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound55804 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,58516,272512,62660,98780,8328,64,64605,57796,17665,283904,61705,272392,257,21793,46212,120542]

theorem envBound55805 : H12AffineFastState.Bounded env55805 := by
  intro p hp
  have h : env55805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55804_55805 : H12AffineEnvironment.transform 16 25029 env55804 = env55805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env55804 == env55805) = true)

def env55806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10280,1025,32769,58516,168,62660,98780,8328,64,64605,57796,17665,32040,61705,32,257,21793,46212,120542]

theorem envBound55806 : H12AffineFastState.Bounded env55806 := by
  intro p hp
  have h : env55806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55805_55806 : H12AffineEnvironment.transform 17 10280 env55805 = env55806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55805 == env55806) = true)

theorem identity55806 : scanCanonicalize (H12AffineFastState.compose env55806 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 20972) := by decide +kernel

theorem selectedBound55806 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env55807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20972,65536,25029,10280,1025,20973,13688,168,9512,86064,8328,64,11697,12328,17665,32040,8421,32,257,21793,25960,67378]

theorem envBound55807 : H12AffineFastState.Bounded env55807 := by
  intro p hp
  have h : env55807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55806_55807 : H12AffineEnvironment.transform 14 20972 env55806 = env55807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20972 env55806 == env55807) = true)

theorem identity55807 : scanCanonicalize (H12AffineFastState.compose env55807 (packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound55807 : packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env55808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,9529,65536,5392,10280,1025,9528,13688,168,9512,74981,8328,64,11697,12328,12756,2557,8421,32,257,8692,4541,67378]

theorem envBound55808 : H12AffineFastState.Bounded env55808 := by
  intro p hp
  have h : env55808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55807_55808 : H12AffineEnvironment.transform 13 13525 env55807 = env55808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env55807 == env55808) = true)

theorem identity55808 : scanCanonicalize (H12AffineFastState.compose env55808 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound55808 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,9529,479,5392,10280,1025,9528,13688,168,9512,9530,8328,64,11697,12328,12756,2557,8421,32,257,8692,4541,1773]

theorem envBound55809 : H12AffineFastState.Bounded env55809 := by
  intro p hp
  have h : env55809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55808_55809 : H12AffineEnvironment.transform 15 479 env55808 = env55809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env55808 == env55809) = true)

theorem identity55809 : scanCanonicalize (H12AffineFastState.compose env55809 (packedSelected [1,2,4,6,8,9,10,11,14,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 445) := by decide +kernel

theorem selectedBound55809 : packedSelected [1,2,4,6,8,9,10,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env55810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,445,4096,8192,13525,9529,479,5392,8597,1025,9528,13688,168,9512,9530,8328,64,9228,12328,12756,64,8421,32,257,8692,4541,1773]

theorem envBound55810 : H12AffineFastState.Bounded env55810 := by
  intro p hp
  have h : env55810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55809_55810 : H12AffineEnvironment.transform 10 445 env55809 = env55810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 445 env55809 == env55810) = true)

theorem identity55810 : scanCanonicalize (H12AffineFastState.compose env55810 (packedSelected [0,3,4,5,7,10,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55810 : packedSelected [0,3,4,5,7,10,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55811 : List Nat := [2,4,8,16,32,64,128,256,512,272,445,4096,8192,12741,8233,479,4096,8597,273,8232,12392,168,8248,8234,8328,64,8476,12328,12756,64,8421,32,257,8692,4541,1021]

theorem envBound55811 : H12AffineFastState.Bounded env55811 := by
  intro p hp
  have h : env55811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55810_55811 : H12AffineEnvironment.transform 9 272 env55810 = env55811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55810 == env55811) = true)

theorem identity55811 : scanCanonicalize (H12AffineFastState.compose env55811 (packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound55811 : packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS < 2^1333 := by decide +kernel

def env55812 : List Nat := [2,4,8,16,32,64,128,256,512,272,445,4096,161,4452,136,479,4096,308,273,137,4297,168,153,139,41,64,445,4233,4469,64,68,32,257,341,4541,1021]

theorem envBound55812 : H12AffineFastState.Bounded env55812 := by
  intro p hp
  have h : env55812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55811_55812 : H12AffineEnvironment.transform 12 161 env55811 = env55812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env55811 == env55812) = true)

theorem identity55812 : scanCanonicalize (H12AffineFastState.compose env55812 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound55812 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55813 : List Nat := [2,4,8,16,32,64,128,252,512,236,65,4096,161,4248,136,35,4096,200,237,137,4297,168,153,139,41,64,65,4233,4233,64,68,32,253,169,4161,513]

theorem envBound55813 : H12AffineFastState.Bounded env55813 := by
  intro p hp
  have h : env55813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55812_55813 : H12AffineEnvironment.transform 7 252 env55812 = env55813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env55812 == env55813) = true)

theorem identity55813 : scanCanonicalize (H12AffineFastState.compose env55813 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound55813 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55814 : List Nat := [2,4,8,16,32,64,89,37,512,53,65,4096,120,4161,81,35,4096,17,52,80,4112,113,64,82,41,64,65,4176,4176,64,68,32,36,112,4161,513]

theorem envBound55814 : H12AffineFastState.Bounded env55814 := by
  intro p hp
  have h : env55814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55813_55814 : H12AffineEnvironment.transform 6 89 env55813 = env55814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env55813 == env55814) = true)

theorem identity55814 : scanCanonicalize (H12AffineFastState.compose env55814 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55814 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env55815 : List Nat := [2,4,8,16,32,16,9,37,512,53,17,4096,40,4113,1,35,4096,17,52,0,4112,33,16,2,41,16,17,4096,4096,16,20,32,36,32,4113,513]

theorem envBound55815 : H12AffineFastState.Bounded env55815 := by
  intro p hp
  have h : env55815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55814_55815 : H12AffineEnvironment.transform 5 16 env55814 = env55815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55814 == env55815) = true)

theorem identity55815 : scanCanonicalize (H12AffineFastState.compose env55815 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound55815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55816 : List Nat := [2,4,8,16,32,16,9,37,512,53,17,512,40,529,1,35,512,17,52,0,528,33,16,2,41,16,17,512,512,16,20,32,36,32,529,513]

theorem envBound55816 : H12AffineFastState.Bounded env55816 := by
  intro p hp
  have h : env55816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55815_55816 : H12AffineEnvironment.transform 11 512 env55815 = env55816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env55815 == env55816) = true)

theorem identity55816 : scanCanonicalize (H12AffineFastState.compose env55816 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55817 : List Nat := [2,4,8,10,32,10,9,37,512,47,11,512,40,523,1,35,512,11,46,0,522,33,10,2,41,10,11,512,512,10,14,32,36,32,523,513]

theorem envBound55817 : H12AffineFastState.Bounded env55817 := by
  intro p hp
  have h : env55817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55816_55817 : H12AffineEnvironment.transform 3 10 env55816 = env55817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55816 == env55817) = true)

theorem identity55817 : scanCanonicalize (H12AffineFastState.compose env55817 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55817 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55818 : List Nat := [2,4,2,0,32,0,3,37,512,37,1,512,34,513,1,35,512,1,36,0,512,33,0,2,35,0,1,512,512,0,4,32,36,32,513,513]

theorem envBound55818 : H12AffineFastState.Bounded env55818 := by
  intro p hp
  have h : env55818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55817_55818 : H12AffineEnvironment.transform 2 2 env55817 = env55818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55817 == env55818) = true)

theorem identity55818 : scanCanonicalize (H12AffineFastState.compose env55818 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55818 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55819 : List Nat := [2,4,2,0,32,0,3,37,1,37,1,1,34,0,1,35,1,1,36,0,1,33,0,2,35,0,1,1,1,0,4,32,36,32,0,0]

theorem envBound55819 : H12AffineFastState.Bounded env55819 := by
  intro p hp
  have h : env55819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55818_55819 : H12AffineEnvironment.transform 8 1 env55818 = env55819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55818 == env55819) = true)

def env55820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10281,1025,32769,58516,169,62660,98780,8328,64,64605,57796,17665,32041,61705,33,257,21793,46212,120542]

theorem envBound55820 : H12AffineFastState.Bounded env55820 := by
  intro p hp
  have h : env55820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55805_55820 : H12AffineEnvironment.transform 17 10281 env55805 = env55820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55805 == env55820) = true)

theorem identity55820 : scanCanonicalize (H12AffineFastState.compose env55820 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 21727) := by decide +kernel

theorem selectedBound55820 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env55821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21727,25029,10281,1025,32769,58516,169,62660,54531,8328,64,64605,57796,17665,32041,61705,33,257,21793,46212,33281]

theorem envBound55821 : H12AffineFastState.Bounded env55821 := by
  intro p hp
  have h : env55821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55820_55821 : H12AffineEnvironment.transform 15 21727 env55820 = env55821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21727 env55820 == env55821) = true)

theorem identity55821 : scanCanonicalize (H12AffineFastState.compose env55821 (packedSelected [0,2,4,6,8,9,11,17,18,20,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55821 : packedSelected [0,2,4,6,8,9,11,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,21727,16537,2421,1025,32769,50632,169,54680,54531,468,64,56577,49304,17665,23669,53333,33,257,21793,38360,33281]

theorem envBound55822 : H12AffineFastState.Bounded env55822 := by
  intro p hp
  have h : env55822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55821_55822 : H12AffineEnvironment.transform 12 348 env55821 = env55822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55821 == env55822) = true)

theorem identity55822 : scanCanonicalize (H12AffineFastState.compose env55822 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55822 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,0,21727,16537,2421,1025,1,17864,169,21912,21763,468,64,23809,16536,17665,23669,20565,33,257,21793,5592,513]

theorem envBound55823 : H12AffineFastState.Bounded env55823 := by
  intro p hp
  have h : env55823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55822_55823 : H12AffineEnvironment.transform 14 0 env55822 = env55823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55822 == env55823) = true)

theorem identity55823 : scanCanonicalize (H12AffineFastState.compose env55823 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55823 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,0,21647,16537,2341,1025,1,17816,169,21912,21763,388,16,23809,16536,17665,23589,20485,33,257,21793,5512,513]

theorem envBound55824 : H12AffineFastState.Bounded env55824 := by
  intro p hp
  have h : env55824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55823_55824 : H12AffineEnvironment.transform 5 16 env55823 = env55824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55823 == env55824) = true)

theorem identity55824 : scanCanonicalize (H12AffineFastState.compose env55824 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound55824 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env55825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,0,262,5392,2341,1025,1,4113,169,17,138,388,16,2184,5393,4232,2476,1420,33,257,168,5512,513]

theorem envBound55825 : H12AffineFastState.Bounded env55825 := by
  intro p hp
  have h : env55825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55824_55825 : H12AffineEnvironment.transform 13 5513 env55824 = env55825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env55824 == env55825) = true)

theorem identity55825 : scanCanonicalize (H12AffineFastState.compose env55825 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3856) := by decide +kernel

theorem selectedBound55825 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55826 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3856,268,2713,0,262,2560,2341,1025,1,3841,169,17,138,388,16,2184,2561,3992,2476,1420,33,257,168,2712,513]

theorem envBound55826 : H12AffineFastState.Bounded env55826 := by
  intro p hp
  have h : env55826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55825_55826 : H12AffineEnvironment.transform 11 3856 env55825 = env55826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3856 env55825 == env55826) = true)

theorem identity55826 : scanCanonicalize (H12AffineFastState.compose env55826 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound55826 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55827 : List Nat := [2,4,8,16,32,16,128,256,512,1024,168,1976,268,561,0,262,680,397,1025,1,1961,169,17,138,388,16,32,681,1840,260,1420,33,257,168,560,513]

theorem envBound55827 : H12AffineFastState.Bounded env55827 := by
  intro p hp
  have h : env55827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55826_55827 : H12AffineEnvironment.transform 10 168 env55826 = env55827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env55826 == env55827) = true)

theorem identity55827 : scanCanonicalize (H12AffineFastState.compose env55827 (packedSelected [1,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 953) := by decide +kernel

theorem selectedBound55827 : packedSelected [1,8,11] rootPS < 2^1333 := by decide +kernel

def env55828 : List Nat := [2,4,8,16,32,16,128,256,512,953,168,1,268,561,0,262,680,397,952,1,16,169,17,138,388,16,32,681,137,260,565,33,257,168,560,513]

theorem envBound55828 : H12AffineFastState.Bounded env55828 := by
  intro p hp
  have h : env55828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55827_55828 : H12AffineEnvironment.transform 9 953 env55827 = env55828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 953 env55827 == env55828) = true)

theorem identity55828 : scanCanonicalize (H12AffineFastState.compose env55828 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55828 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env55829 : List Nat := [2,4,8,16,32,16,128,172,512,533,168,1,160,561,0,170,680,33,532,1,16,169,17,138,40,16,32,681,137,168,565,33,173,168,560,513]

theorem envBound55829 : H12AffineFastState.Bounded env55829 := by
  intro p hp
  have h : env55829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55828_55829 : H12AffineEnvironment.transform 7 172 env55828 = env55829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55828 == env55829) = true)

theorem identity55829 : scanCanonicalize (H12AffineFastState.compose env55829 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55830 : List Nat := [2,4,8,16,1,16,128,141,512,533,137,1,129,528,0,139,649,0,532,1,16,136,17,138,9,16,1,648,137,137,532,0,140,137,529,513]

theorem envBound55830 : H12AffineFastState.Bounded env55830 := by
  intro p hp
  have h : env55830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55829_55830 : H12AffineEnvironment.transform 4 1 env55829 = env55830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55829 == env55830) = true)

theorem identity55830 : scanCanonicalize (H12AffineFastState.compose env55830 (packedSelected [0,1,4,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55830 : packedSelected [0,1,4,8,12] rootPS < 2^1333 := by decide +kernel

def env55831 : List Nat := [2,4,8,16,1,16,9,4,512,533,0,1,8,528,0,2,512,0,532,1,16,1,17,3,9,16,1,513,0,0,532,0,5,0,529,513]

theorem envBound55831 : H12AffineFastState.Bounded env55831 := by
  intro p hp
  have h : env55831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55830_55831 : H12AffineEnvironment.transform 6 9 env55830 = env55831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55830 == env55831) = true)

theorem identity55831 : scanCanonicalize (H12AffineFastState.compose env55831 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound55831 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55832 : List Nat := [2,4,8,16,1,16,9,4,16,5,0,1,8,0,0,2,16,0,4,1,16,1,17,3,9,16,1,17,0,0,4,0,5,0,1,17]

theorem envBound55832 : H12AffineFastState.Bounded env55832 := by
  intro p hp
  have h : env55832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55831_55832 : H12AffineEnvironment.transform 8 16 env55831 = env55832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env55831 == env55832) = true)

theorem identity55832 : scanCanonicalize (H12AffineFastState.compose env55832 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55832 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55833 : List Nat := [2,4,8,0,1,0,9,4,0,5,0,1,8,0,0,2,0,0,4,1,0,1,1,3,9,0,1,1,0,0,4,0,5,0,1,1]

theorem envBound55833 : H12AffineFastState.Bounded env55833 := by
  intro p hp
  have h : env55833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55832_55833 : H12AffineEnvironment.transform 3 0 env55832 = env55833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55832 == env55833) = true)

theorem identity55833 : scanCanonicalize (H12AffineFastState.compose env55833 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55834 : List Nat := [2,4,3,0,1,0,2,4,0,5,0,1,3,0,0,2,0,0,4,1,0,1,1,3,2,0,1,1,0,0,4,0,5,0,1,1]

theorem envBound55834 : H12AffineFastState.Bounded env55834 := by
  intro p hp
  have h : env55834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55833_55834 : H12AffineEnvironment.transform 2 3 env55833 = env55834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55833 == env55834) = true)

def env55835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169217,98780,8328,64,64604,163841,17665,283904,168140,412108,257,21793,46212,243483]

theorem envBound55835 : H12AffineFastState.Bounded env55835 := by
  intro p hp
  have h : env55835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55803_55835 : H12AffineEnvironment.transform 21 272513 env55803 = env55835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env55803 == env55835) = true)

theorem identity55835 : scanCanonicalize (H12AffineFastState.compose env55835 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound55835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160132,272513,156116,95497,8328,64,2185,160980,17665,283904,156697,412108,257,21793,16465,213966]

theorem envBound55836 : H12AffineFastState.Bounded env55836 := by
  intro p hp
  have h : env55836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55835_55836 : H12AffineEnvironment.transform 14 29909 env55835 = env55836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env55835 == env55836) = true)

def env55837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160012,272393,155996,95497,8192,64,2049,160860,17665,283904,156697,411972,257,21793,16465,213830]

theorem envBound55837 : H12AffineFastState.Bounded env55837 := by
  intro p hp
  have h : env55837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55836_55837 : H12AffineEnvironment.transform 6 8 env55836 = env55837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55836 == env55837) = true)

theorem identity55837 : scanCanonicalize (H12AffineFastState.compose env55837 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound55837 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env55838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,146745,1025,29788,160012,136496,155996,95497,8192,64,2049,160860,17665,157753,156697,29821,257,21793,16465,213830]

theorem envBound55838 : H12AffineFastState.Bounded env55838 := by
  intro p hp
  have h : env55838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55837_55838 : H12AffineEnvironment.transform 17 146745 env55837 = env55838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env55837 == env55838) = true)

theorem identity55838 : scanCanonicalize (H12AffineFastState.compose env55838 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55838 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,131072,138340,1025,21761,151633,136496,147457,87124,349,64,2049,152833,17665,149860,148804,21792,257,21793,16465,213830]

theorem envBound55839 : H12AffineFastState.Bounded env55839 := by
  intro p hp
  have h : env55839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55838_55839 : H12AffineEnvironment.transform 12 349 env55838 = env55839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55838 == env55839) = true)

theorem identity55839 : scanCanonicalize (H12AffineFastState.compose env55839 (packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound55839 : packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env55840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,114,131072,138340,1025,21761,151633,136496,147457,21542,349,64,2049,152833,17665,149860,148804,21792,257,21793,16465,148276]

theorem envBound55840 : H12AffineFastState.Bounded env55840 := by
  intro p hp
  have h : env55840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55839_55840 : H12AffineEnvironment.transform 15 114 env55839 = env55840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env55839 == env55840) = true)

theorem identity55840 : scanCanonicalize (H12AffineFastState.compose env55840 (packedSelected [0,1,2,5,6,7,8,11,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound55840 : packedSelected [0,1,2,5,6,7,8,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env55841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,373,114,131072,138340,1025,372,132132,136496,136308,83,349,64,2049,131444,4468,138513,135473,341,257,340,5156,137025]

theorem envBound55841 : H12AffineFastState.Bounded env55841 := by
  intro p hp
  have h : env55841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55840_55841 : H12AffineEnvironment.transform 13 5237 env55840 = env55841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env55840 == env55841) = true)

theorem identity55841 : scanCanonicalize (H12AffineFastState.compose env55841 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound55841 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env55842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,373,114,5172,2128,1025,372,4112,260,64,83,349,64,2049,5440,4468,2341,1285,341,257,340,5156,885]

theorem envBound55842 : H12AffineFastState.Bounded env55842 := by
  intro p hp
  have h : env55842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55841_55842 : H12AffineEnvironment.transform 16 5172 env55841 = env55842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env55841 == env55842) = true)

theorem identity55842 : scanCanonicalize (H12AffineFastState.compose env55842 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound55842 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env55843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,349,3172,373,114,3109,2128,1025,372,2049,260,64,83,349,64,2049,3409,2405,2341,1285,341,257,340,3125,885]

theorem envBound55843 : H12AffineFastState.Bounded env55843 := by
  intro p hp
  have h : env55843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55842_55843 : H12AffineEnvironment.transform 11 2065 env55842 = env55843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env55842 == env55843) = true)

theorem identity55843 : scanCanonicalize (H12AffineFastState.compose env55843 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55843 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env55844 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,349,2129,373,114,2064,2128,52,372,2049,260,64,83,349,64,2049,2404,2405,2341,304,341,257,340,2048,885]

theorem envBound55844 : H12AffineFastState.Bounded env55844 := by
  intro p hp
  have h : env55844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55843_55844 : H12AffineEnvironment.transform 9 53 env55843 = env55844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55843 == env55844) = true)

theorem identity55844 : scanCanonicalize (H12AffineFastState.compose env55844 (packedSelected [0,2,3,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound55844 : packedSelected [0,2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55845 : List Nat := [2,4,8,16,32,64,8,256,81,53,2048,2065,349,2129,373,114,2064,2128,52,372,2049,260,64,83,349,64,2049,2404,2405,2341,304,341,257,340,2048,292]

theorem envBound55845 : H12AffineFastState.Bounded env55845 := by
  intro p hp
  have h : env55845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55844_55845 : H12AffineEnvironment.transform 8 81 env55844 = env55845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env55844 == env55845) = true)

theorem identity55845 : scanCanonicalize (H12AffineFastState.compose env55845 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55845 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env55846 : List Nat := [2,4,8,16,32,64,8,256,81,53,0,17,349,81,373,114,16,80,52,372,1,260,64,83,349,64,1,356,357,293,304,341,257,340,0,292]

theorem envBound55846 : H12AffineFastState.Bounded env55846 := by
  intro p hp
  have h : env55846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55845_55846 : H12AffineEnvironment.transform 10 0 env55845 = env55846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55845 == env55846) = true)

theorem identity55846 : scanCanonicalize (H12AffineFastState.compose env55846 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55846 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env55847 : List Nat := [2,4,8,16,32,16,8,256,1,53,0,17,269,1,293,34,16,0,52,292,1,260,16,3,269,16,1,308,309,293,304,261,257,260,0,292]

theorem envBound55847 : H12AffineFastState.Bounded env55847 := by
  intro p hp
  have h : env55847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55846_55847 : H12AffineEnvironment.transform 5 16 env55846 = env55847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55846 == env55847) = true)

def env55848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160013,272392,155997,95497,8193,64,2048,160861,17665,283904,156697,411973,257,21793,16465,213831]

theorem envBound55848 : H12AffineFastState.Bounded env55848 := by
  intro p hp
  have h : env55848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55836_55848 : H12AffineEnvironment.transform 6 9 env55836 = env55848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55836 == env55848) = true)

theorem identity55848 : scanCanonicalize (H12AffineFastState.compose env55848 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound55848 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env55849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,223599,1025,29789,160013,213351,155997,95497,8193,64,2048,160861,17665,212079,156697,73770,257,21793,16465,213831]

theorem envBound55849 : H12AffineFastState.Bounded env55849 := by
  intro p hp
  have h : env55849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55848_55849 : H12AffineEnvironment.transform 17 223599 env55848 = env55849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env55848 == env55849) = true)

theorem identity55849 : scanCanonicalize (H12AffineFastState.compose env55849 (packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 90187) := by decide +kernel

theorem selectedBound55849 : packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90187,2340,1025,29789,69958,8492,65814,95497,8193,64,2048,70678,17665,23588,66642,73770,257,21793,16465,8972]

theorem envBound55850 : H12AffineFastState.Bounded env55850 := by
  intro p hp
  have h : env55850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55849_55850 : H12AffineEnvironment.transform 16 90187 env55849 = env55850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90187 env55849 == env55850) = true)

theorem identity55850 : scanCanonicalize (H12AffineFastState.compose env55850 (packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55850 : packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env55851 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,90139,2340,1025,29709,69910,8492,65814,95497,8193,16,2048,70678,17665,23588,66562,73770,257,21793,16385,8972]

theorem envBound55851 : H12AffineFastState.Bounded env55851 := by
  intro p hp
  have h : env55851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55850_55851 : H12AffineEnvironment.transform 5 16 env55850 = env55851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55850 == env55851) = true)

theorem identity55851 : scanCanonicalize (H12AffineFastState.compose env55851 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound55851 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env55852 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,29962,5393,2340,1025,29709,25628,8492,29724,3,8193,16,2048,24860,17665,23588,28936,21792,257,21793,16385,8972]

theorem envBound55852 : H12AffineFastState.Bounded env55852 := by
  intro p hp
  have h : env55852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55851_55852 : H12AffineEnvironment.transform 15 29962 env55851 = env55852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env55851 == env55852) = true)

theorem identity55852 : scanCanonicalize (H12AffineFastState.compose env55852 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55852 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env55853 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,5393,2340,1025,8461,12572,8492,8476,3,8193,16,2048,13340,4097,2340,9224,32,257,33,5377,8972]

theorem envBound55853 : H12AffineFastState.Bounded env55853 := by
  intro p hp
  have h : env55853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55852_55853 : H12AffineEnvironment.transform 13 5376 env55852 = env55853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55852 == env55853) = true)

theorem identity55853 : scanCanonicalize (H12AffineFastState.compose env55853 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55853 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55854 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5157,8233,8202,5172,2049,1025,8232,12345,8201,8249,3,8193,16,2048,13340,4097,2049,9224,32,36,33,5156,8745]

theorem envBound55854 : H12AffineFastState.Bounded env55854 := by
  intro p hp
  have h : env55854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55853_55854 : H12AffineEnvironment.transform 7 37 env55853 = env55854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55853 == env55854) = true)

theorem identity55854 : scanCanonicalize (H12AffineFastState.compose env55854 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55854 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55855 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,0,35,5172,2049,1025,1,4112,32,16,3,40,16,2048,5173,4097,2049,1057,32,36,33,5156,512]

theorem envBound55855 : H12AffineFastState.Bounded env55855 := by
  intro p hp
  have h : env55855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55854_55855 : H12AffineEnvironment.transform 12 41 env55854 = env55855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55854 == env55855) = true)

theorem identity55855 : scanCanonicalize (H12AffineFastState.compose env55855 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55855 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55856 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5125,0,3,5140,2049,1025,1,4112,0,16,3,8,16,2048,5141,4097,2049,1025,0,4,1,5124,512]

theorem envBound55856 : H12AffineFastState.Bounded env55856 := by
  intro p hp
  have h : env55856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55855_55856 : H12AffineEnvironment.transform 4 0 env55855 = env55856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55855 == env55856) = true)

theorem identity55856 : scanCanonicalize (H12AffineFastState.compose env55856 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound55856 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55857 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3077,9,2048,0,3,2065,2049,1025,1,3093,0,16,3,8,16,2048,2064,3076,2049,1025,0,4,1,2049,512]

theorem envBound55857 : H12AffineFastState.Bounded env55857 := by
  intro p hp
  have h : env55857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55856_55857 : H12AffineEnvironment.transform 11 3077 env55856 = env55857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env55856 == env55857) = true)

theorem identity55857 : scanCanonicalize (H12AffineFastState.compose env55857 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound55857 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55858 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2065,9,2048,0,3,2065,2049,21,1,2049,0,16,3,8,16,2048,2064,2064,2049,21,0,4,1,2049,512]

theorem envBound55858 : H12AffineFastState.Bounded env55858 := by
  intro p hp
  have h : env55858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55857_55858 : H12AffineEnvironment.transform 9 20 env55857 = env55858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env55857 == env55858) = true)

def env55859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound55859 : H12AffineFastState.Bounded env55859 := by
  intro p hp
  have h : env55859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55092_55859 : H12AffineEnvironment.transform 25 65 env55092 = env55859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env55092 == env55859) = true)

def env55860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound55860 : H12AffineFastState.Bounded env55860 := by
  intro p hp
  have h : env55860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55859_55860 : H12AffineEnvironment.transform 26 30393344 env55859 = env55860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env55859 == env55860) = true)

def env55861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound55861 : H12AffineFastState.Bounded env55861 := by
  intro p hp
  have h : env55861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55860_55861 : H12AffineEnvironment.transform 18 1024 env55860 = env55861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env55860 == env55861) = true)

theorem identity55861 : scanCanonicalize (H12AffineFastState.compose env55861 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510001) := by decide +kernel

theorem selectedBound55861 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510001,8328,65,12585009,2510012,10507600,8830977,8801313,6729200,256,10882204,10939705,8874998]

theorem envBound55862 : H12AffineFastState.Bounded env55862 := by
  intro p hp
  have h : env55862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55861_55862 : H12AffineEnvironment.transform 23 510001 env55861 = env55862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510001 env55861 == env55862) = true)

def env55863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513340,510001,8328,65,6705549,2510012,396524,2136509,2102685,6729200,256,21792,46213,2175562]

theorem envBound55863 : H12AffineFastState.Bounded env55863 := by
  intro p hp
  have h : env55863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55862_55863 : H12AffineEnvironment.transform 22 2513340 env55862 = env55863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513340 env55862 == env55863) = true)

def env55864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513340,510001,8328,65,2409525,2510012,396524,2136509,2102685,2373704,256,21792,46213,2175562]

theorem envBound55864 : H12AffineFastState.Bounded env55864 := by
  intro p hp
  have h : env55864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55863_55864 : H12AffineEnvironment.transform 21 169400 env55863 = env55864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env55863 == env55864) = true)

def env55865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,510001,8328,65,316533,417020,396524,35325,1501,272392,256,21792,46213,74250]

theorem envBound55865 : H12AffineFastState.Bounded env55865 := by
  intro p hp
  have h : env55865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55864_55865 : H12AffineEnvironment.transform 20 4160 env55864 = env55865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55864 == env55865) = true)

def env55866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169400,156116,253977,8328,65,64605,160980,140484,35325,1501,32,256,21792,46213,74250]

theorem envBound55866 : H12AffineFastState.Bounded env55866 := by
  intro p hp
  have h : env55866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55865_55866 : H12AffineEnvironment.transform 17 10280 env55865 = env55866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55865 == env55866) = true)

def env55867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21928,41412,73737,8328,65,64605,46276,58580,35325,1501,32,256,21792,46213,74250]

theorem envBound55867 : H12AffineFastState.Bounded env55867 := by
  intro p hp
  have h : env55867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55866_55867 : H12AffineEnvironment.transform 16 49168 env55866 = env55867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55866 == env55867) = true)

theorem identity55867 : scanCanonicalize (H12AffineFastState.compose env55867 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound55867 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1024,8660,4160,21928,17,73737,8328,65,23944,5393,17665,10280,1501,32,256,21792,5456,74250]

theorem envBound55868 : H12AffineFastState.Bounded env55868 := by
  intro p hp
  have h : env55868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55867_55868 : H12AffineEnvironment.transform 14 8661 env55867 = env55868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env55867 == env55868) = true)

theorem identity55868 : scanCanonicalize (H12AffineFastState.compose env55868 (packedSelected [4,5,7,9,19,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound55868 : packedSelected [4,5,7,9,19,24,27] rootPS < 2^1333 := by decide +kernel

def env55869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,28699,25029,10280,1024,8660,4160,21928,17,20498,8328,65,23944,5393,17665,10280,1501,32,256,21792,5456,21009]

theorem envBound55869 : H12AffineFastState.Bounded env55869 := by
  intro p hp
  have h : env55869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55868_55869 : H12AffineEnvironment.transform 15 28699 env55868 = env55869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env55868 == env55869) = true)

theorem identity55869 : scanCanonicalize (H12AffineFastState.compose env55869 (packedSelected [0,2,5,6,7,16,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55869 : packedSelected [0,2,5,6,7,16,19,24] rootPS < 2^1333 := by decide +kernel

def env55870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,217,20759,16585,2340,1024,216,4160,21928,17,20498,388,65,23944,5393,17665,2340,1501,32,256,21792,5456,21009]

theorem envBound55870 : H12AffineFastState.Bounded env55870 := by
  intro p hp
  have h : env55870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55869_55870 : H12AffineEnvironment.transform 12 268 env55869 = env55870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55869 == env55870) = true)

theorem identity55870 : scanCanonicalize (H12AffineFastState.compose env55870 (packedSelected [2,4,6,11,20,22,23] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound55870 : packedSelected [2,4,6,11,20,22,23] rootPS < 2^1333 := by decide +kernel

def env55871 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,268,16384,217,20759,16585,2340,188,216,4160,20756,17,20498,388,65,22836,4525,16829,2340,353,32,256,20892,4588,21009]

theorem envBound55871 : H12AffineFastState.Bounded env55871 := by
  intro p hp
  have h : env55871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55870_55871 : H12AffineEnvironment.transform 9 188 env55870 = env55871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env55870 == env55871) = true)

theorem identity55871 : scanCanonicalize (H12AffineFastState.compose env55871 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55871 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env55872 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,4096,121,16384,217,20578,16585,2129,188,216,4160,20577,17,20498,241,65,22593,4312,16584,2129,20,32,117,20713,4249,21009]

theorem envBound55872 : H12AffineFastState.Bounded env55872 := by
  intro p hp
  have h : env55872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55871_55872 : H12AffineEnvironment.transform 7 117 env55871 = env55872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55871 == env55872) = true)

theorem identity55872 : scanCanonicalize (H12AffineFastState.compose env55872 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound55872 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env55873 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,4096,121,4161,217,35,4232,2129,188,216,4160,32,17,83,241,65,2048,4312,4233,2129,20,32,117,168,4249,592]

theorem envBound55873 : H12AffineFastState.Bounded env55873 := by
  intro p hp
  have h : env55873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55872_55873 : H12AffineEnvironment.transform 13 4161 env55872 = env55873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env55872 == env55873) = true)

theorem identity55873 : scanCanonicalize (H12AffineFastState.compose env55873 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55873 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55874 : List Nat := [2,4,8,16,32,16,128,37,512,188,2048,4096,41,4113,137,35,4232,2049,188,136,4112,32,17,3,161,17,2048,4232,4233,2049,20,32,37,168,4249,512]

theorem envBound55874 : H12AffineFastState.Bounded env55874 := by
  intro p hp
  have h : env55874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55873_55874 : H12AffineEnvironment.transform 5 16 env55873 = env55874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55873 == env55874) = true)

theorem identity55874 : scanCanonicalize (H12AffineFastState.compose env55874 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound55874 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env55875 : List Nat := [2,4,8,16,32,16,128,37,512,188,2048,2096,41,2081,137,35,2232,2049,188,136,2080,32,17,3,161,17,2048,2232,2233,2049,20,32,37,168,2217,512]

theorem envBound55875 : H12AffineFastState.Bounded env55875 := by
  intro p hp
  have h : env55875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55874_55875 : H12AffineEnvironment.transform 11 2096 env55874 = env55875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env55874 == env55875) = true)

theorem identity55875 : scanCanonicalize (H12AffineFastState.compose env55875 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound55875 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55876 : List Nat := [2,4,8,16,32,16,41,37,512,21,2048,2096,41,2081,32,35,2065,2049,21,33,2080,32,17,3,8,17,2048,2065,2064,2049,20,32,37,1,2048,512]

theorem envBound55876 : H12AffineFastState.Bounded env55876 := by
  intro p hp
  have h : env55876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55875_55876 : H12AffineEnvironment.transform 6 41 env55875 = env55876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env55875 == env55876) = true)

theorem identity55876 : scanCanonicalize (H12AffineFastState.compose env55876 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55876 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55877 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,2064,9,2049,0,3,2065,2049,21,1,2048,0,17,3,8,17,2048,2065,2064,2049,20,0,5,1,2048,512]

theorem envBound55877 : H12AffineFastState.Bounded env55877 := by
  intro p hp
  have h : env55877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55876_55877 : H12AffineEnvironment.transform 4 0 env55876 = env55877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55876 == env55877) = true)

def env55878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21929,41413,73736,8328,65,64605,46277,58581,35325,1501,32,256,21792,46213,74250]

theorem envBound55878 : H12AffineFastState.Bounded env55878 := by
  intro p hp
  have h : env55878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55866_55878 : H12AffineEnvironment.transform 16 49169 env55866 = env55878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55866 == env55878) = true)

theorem identity55878 : scanCanonicalize (H12AffineFastState.compose env55878 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55878 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1024,8540,4160,21929,152,73736,8328,65,23808,5528,17800,10400,1501,32,256,21792,5592,74250]

theorem envBound55879 : H12AffineFastState.Bounded env55879 := by
  intro p hp
  have h : env55879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55878_55879 : H12AffineEnvironment.transform 14 8541 env55878 = env55879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55878 == env55879) = true)

theorem identity55879 : scanCanonicalize (H12AffineFastState.compose env55879 (packedSelected [4,5,7,9,18,19,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 4297) := by decide +kernel

theorem selectedBound55879 : packedSelected [4,5,7,9,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env55880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8541,65536,12677,10280,1024,8540,4160,1376,152,73736,8328,65,3529,5528,5441,10400,1501,32,256,1513,5592,74250]

theorem envBound55880 : H12AffineFastState.Bounded env55880 := by
  intro p hp
  have h : env55880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55879_55880 : H12AffineEnvironment.transform 13 4297 env55879 = env55880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4297 env55879 == env55880) = true)

theorem identity55880 : scanCanonicalize (H12AffineFastState.compose env55880 (packedSelected [2,3,4,6,10,16,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound55880 : packedSelected [2,3,4,6,10,16,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8541,399,12677,10280,1024,8540,4160,1376,152,8583,8328,65,3529,5528,5441,10400,1501,32,256,1513,5592,9093]

theorem envBound55881 : H12AffineFastState.Bounded env55881 := by
  intro p hp
  have h : env55881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55880_55881 : H12AffineEnvironment.transform 15 399 env55880 = env55881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env55880 == env55881) = true)

theorem identity55881 : scanCanonicalize (H12AffineFastState.compose env55881 (packedSelected [1,2,4,6,8,11,16,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55881 : packedSelected [1,2,4,6,8,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env55882 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4297,8433,35,12329,10280,1024,8432,4160,1228,152,8235,8328,65,3173,5172,5357,10400,1137,32,172,1093,5236,8745]

theorem envBound55882 : H12AffineFastState.Bounded env55882 := by
  intro p hp
  have h : env55882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55881_55882 : H12AffineEnvironment.transform 7 172 env55881 = env55882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55881 == env55882) = true)

theorem identity55882 : scanCanonicalize (H12AffineFastState.compose env55882 (packedSelected [3,5,10,11,12,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound55882 : packedSelected [3,5,10,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env55883 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1052,4297,1261,35,5173,3124,1024,1260,4160,1228,152,1079,1172,65,3173,5172,5357,3260,1137,32,172,1093,5236,1589]

theorem envBound55883 : H12AffineFastState.Bounded env55883 := by
  intro p hp
  have h : env55883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55882_55883 : H12AffineEnvironment.transform 12 1052 env55882 = env55883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env55882 == env55883) = true)

theorem identity55883 : scanCanonicalize (H12AffineFastState.compose env55883 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound55883 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55884 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,1052,4112,1076,35,5173,3124,1024,1077,4160,1045,65,1079,1101,65,3173,5172,5172,3173,1137,32,117,1093,5236,1589]

theorem envBound55884 : H12AffineFastState.Bounded env55884 := by
  intro p hp
  have h : env55884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55883_55884 : H12AffineEnvironment.transform 6 89 env55883 = env55884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env55883 == env55884) = true)

theorem identity55884 : scanCanonicalize (H12AffineFastState.compose env55884 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound55884 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55885 : List Nat := [2,4,8,16,32,64,89,117,512,100,2048,4096,120,4112,80,35,4177,2128,100,81,4160,113,65,83,41,65,2049,4176,4176,2049,21,32,117,33,4112,593]

theorem envBound55885 : H12AffineFastState.Bounded env55885 := by
  intro p hp
  have h : env55885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55884_55885 : H12AffineEnvironment.transform 9 100 env55884 = env55885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env55884 == env55885) = true)

theorem identity55885 : scanCanonicalize (H12AffineFastState.compose env55885 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55885 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env55886 : List Nat := [2,4,8,16,1,64,89,84,512,69,2048,4096,89,4112,80,2,4177,2128,69,81,4160,80,65,83,8,65,2049,4176,4176,2049,21,1,84,0,4112,593]

theorem envBound55886 : H12AffineFastState.Bounded env55886 := by
  intro p hp
  have h : env55886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55885_55886 : H12AffineEnvironment.transform 4 1 env55885 = env55886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55885 == env55886) = true)

theorem identity55886 : scanCanonicalize (H12AffineFastState.compose env55886 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55886 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env55887 : List Nat := [2,4,8,16,1,17,8,5,512,20,2048,4096,8,4112,1,2,4096,2049,20,0,4113,1,16,2,8,16,2049,4097,4097,2049,21,1,5,0,4112,512]

theorem envBound55887 : H12AffineFastState.Bounded env55887 := by
  intro p hp
  have h : env55887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55886_55887 : H12AffineEnvironment.transform 5 17 env55886 = env55887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55886 == env55887) = true)

theorem identity55887 : scanCanonicalize (H12AffineFastState.compose env55887 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2580) := by decide +kernel

theorem selectedBound55887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55888 : List Nat := [2,4,8,16,1,17,8,5,512,20,2048,2580,8,2564,1,2,2580,2049,20,0,2565,1,16,2,8,16,2049,2581,2581,2049,21,1,5,0,2564,512]

theorem envBound55888 : H12AffineFastState.Bounded env55888 := by
  intro p hp
  have h : env55888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55887_55888 : H12AffineEnvironment.transform 11 2580 env55887 = env55888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2580 env55887 == env55888) = true)

theorem identity55888 : scanCanonicalize (H12AffineFastState.compose env55888 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 533) := by decide +kernel

theorem selectedBound55888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55889 : List Nat := [2,4,8,16,1,17,8,5,512,20,533,1,8,17,1,2,1,532,20,0,16,1,16,2,8,16,532,0,0,532,21,1,5,0,17,512]

theorem envBound55889 : H12AffineFastState.Bounded env55889 := by
  intro p hp
  have h : env55889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55888_55889 : H12AffineEnvironment.transform 10 533 env55888 = env55889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 533 env55888 == env55889) = true)

theorem identity55889 : scanCanonicalize (H12AffineFastState.compose env55889 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound55889 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55890 : List Nat := [2,4,8,16,1,17,8,5,17,20,4,1,8,17,1,2,1,5,20,0,16,1,16,2,8,16,5,0,0,5,21,1,5,0,17,17]

theorem envBound55890 : H12AffineFastState.Bounded env55890 := by
  intro p hp
  have h : env55890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55889_55890 : H12AffineEnvironment.transform 8 17 env55889 = env55890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env55889 == env55890) = true)

theorem identity55890 : scanCanonicalize (H12AffineFastState.compose env55890 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound55890 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55891 : List Nat := [2,4,8,4,1,5,8,5,5,0,4,1,8,5,1,2,1,5,0,0,4,1,4,2,8,4,5,0,0,5,1,1,5,0,5,5]

theorem envBound55891 : H12AffineFastState.Bounded env55891 := by
  intro p hp
  have h : env55891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55890_55891 : H12AffineEnvironment.transform 3 4 env55890 = env55891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env55890 == env55891) = true)

theorem identity55891 : scanCanonicalize (H12AffineFastState.compose env55891 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55891 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55892 : List Nat := [2,1,8,1,1,0,8,0,0,0,1,1,8,0,1,2,1,0,0,0,1,1,1,2,8,1,0,0,0,0,1,1,0,0,0,0]

theorem envBound55892 : H12AffineFastState.Bounded env55892 := by
  intro p hp
  have h : env55892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55891_55892 : H12AffineEnvironment.transform 1 1 env55891 = env55892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55891 == env55892) = true)

def env55893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169400,156117,253976,8328,65,64604,160981,140485,35325,1501,33,256,21792,46213,74250]

theorem envBound55893 : H12AffineFastState.Bounded env55893 := by
  intro p hp
  have h : env55893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55865_55893 : H12AffineEnvironment.transform 17 10281 env55865 = env55893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55865 == env55893) = true)

def env55894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21928,41413,73736,8328,65,64604,46277,58581,35325,1501,33,256,21792,46213,74250]

theorem envBound55894 : H12AffineFastState.Bounded env55894 := by
  intro p hp
  have h : env55894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55893_55894 : H12AffineEnvironment.transform 16 49168 env55893 = env55894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55893 == env55894) = true)

theorem identity55894 : scanCanonicalize (H12AffineFastState.compose env55894 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55894 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21793,41292,73736,8193,65,64604,46156,58460,35188,1364,33,256,21792,46092,74250]

theorem envBound55895 : H12AffineFastState.Bounded env55895 := by
  intro p hp
  have h : env55895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55894_55895 : H12AffineEnvironment.transform 6 9 env55894 = env55895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55894 == env55895) = true)

theorem identity55895 : scanCanonicalize (H12AffineFastState.compose env55895 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound55895 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1024,29789,4160,21793,21776,73736,8193,65,2048,16400,4096,32040,1364,33,256,21792,16464,74250]

theorem envBound55896 : H12AffineFastState.Bounded env55896 := by
  intro p hp
  have h : env55896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55895_55896 : H12AffineEnvironment.transform 14 29788 env55895 = env55896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env55895 == env55896) = true)

theorem identity55896 : scanCanonicalize (H12AffineFastState.compose env55896 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55896 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env55897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13388,10281,1024,8541,4160,33,16,73736,8193,65,2048,5392,4096,10280,1364,33,256,32,5456,74250]

theorem envBound55897 : H12AffineFastState.Bounded env55897 := by
  intro p hp
  have h : env55897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55896_55897 : H12AffineEnvironment.transform 13 5376 env55896 = env55897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55896 == env55897) = true)

theorem identity55897 : scanCanonicalize (H12AffineFastState.compose env55897 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound55897 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,5376,32,65536,5424,2389,1024,33,4160,33,16,65908,381,65,2048,5392,4096,2388,1364,33,256,32,5456,66422]

theorem envBound55898 : H12AffineFastState.Bounded env55898 := by
  intro p hp
  have h : env55898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55897_55898 : H12AffineEnvironment.transform 12 380 env55897 = env55898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env55897 == env55898) = true)

def env55899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21929,41412,73737,8328,65,64604,46276,58580,35325,1501,33,256,21792,46213,74250]

theorem envBound55899 : H12AffineFastState.Bounded env55899 := by
  intro p hp
  have h : env55899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55893_55899 : H12AffineEnvironment.transform 16 49169 env55893 = env55899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55893 == env55899) = true)

def env55900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,49169,2557,1024,32769,4160,21929,32784,66013,348,65,56712,38160,50432,35325,1501,33,256,21792,38225,66526]

theorem envBound55900 : H12AffineFastState.Bounded env55900 := by
  intro p hp
  have h : env55900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55899_55900 : H12AffineEnvironment.transform 12 468 env55899 = env55900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env55899 == env55900) = true)

theorem identity55900 : scanCanonicalize (H12AffineFastState.compose env55900 (packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound55900 : packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env55901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,65536,5393,2557,1024,21761,4160,21929,21776,66013,348,65,2184,16400,4096,23805,1501,33,256,21792,16465,66526]

theorem envBound55901 : H12AffineFastState.Bounded env55901 := by
  intro p hp
  have h : env55901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55900_55901 : H12AffineEnvironment.transform 14 21760 env55900 = env55901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55900 == env55901) = true)

theorem identity55901 : scanCanonicalize (H12AffineFastState.compose env55901 (packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound55901 : packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env55902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,21591,5393,2557,1024,21761,4160,21929,21776,21898,348,65,2184,16400,4096,23805,1501,33,256,21792,16465,22409]

theorem envBound55902 : H12AffineFastState.Bounded env55902 := by
  intro p hp
  have h : env55902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55901_55902 : H12AffineEnvironment.transform 15 21591 env55901 = env55902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env55901 == env55902) = true)

theorem identity55902 : scanCanonicalize (H12AffineFastState.compose env55902 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound55902 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env55903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,478,5393,2557,1024,136,4160,32,153,3,348,65,2184,5529,4096,2420,1501,33,256,169,5592,512]

theorem envBound55903 : H12AffineFastState.Bounded env55903 := by
  intro p hp
  have h : env55903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55902_55903 : H12AffineEnvironment.transform 13 5513 env55902 = env55903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env55902 == env55903) = true)

theorem identity55903 : scanCanonicalize (H12AffineFastState.compose env55903 (packedSelected [2,4,6,9,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound55903 : packedSelected [2,4,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,137,4096,468,5513,137,478,5393,372,1024,136,4160,32,153,3,348,65,1,5529,4096,509,1501,33,256,169,5592,512]

theorem envBound55904 : H12AffineFastState.Bounded env55904 := by
  intro p hp
  have h : env55904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55903_55904 : H12AffineEnvironment.transform 10 137 env55903 = env55904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env55903 == env55904) = true)

theorem identity55904 : scanCanonicalize (H12AffineFastState.compose env55904 (packedSelected [1,3,4,5,8,9,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound55904 : packedSelected [1,3,4,5,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env55905 : List Nat := [2,4,8,16,32,64,120,256,512,1024,113,4096,300,5489,113,294,5393,372,1024,112,4160,32,97,3,348,65,1,5473,4096,261,1317,33,256,81,5408,512]

theorem envBound55905 : H12AffineFastState.Bounded env55905 := by
  intro p hp
  have h : env55905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55904_55905 : H12AffineEnvironment.transform 6 120 env55904 = env55905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env55904 == env55905) = true)

theorem identity55905 : scanCanonicalize (H12AffineFastState.compose env55905 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55905 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env55906 : List Nat := [2,4,8,16,32,64,120,84,512,1024,113,4096,120,5157,113,114,5189,32,1024,112,4160,32,97,3,8,65,1,5173,4096,81,1137,33,84,81,5236,512]

theorem envBound55906 : H12AffineFastState.Bounded env55906 := by
  intro p hp
  have h : env55906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55905_55906 : H12AffineEnvironment.transform 7 84 env55905 = env55906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55905 == env55906) = true)

theorem identity55906 : scanCanonicalize (H12AffineFastState.compose env55906 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound55906 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55907 : List Nat := [2,4,8,16,32,64,120,84,512,1024,113,1028,120,33,113,114,65,32,1024,112,1092,32,97,3,8,65,1,49,1028,81,1137,33,84,81,112,512]

theorem envBound55907 : H12AffineFastState.Bounded env55907 := by
  intro p hp
  have h : env55907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55906_55907 : H12AffineEnvironment.transform 11 1028 env55906 = env55907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env55906 == env55907) = true)

def env55908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,49169,2556,1024,32769,4160,21929,32785,66012,349,65,56713,38161,50433,35325,1501,33,256,21792,38224,66527]

theorem envBound55908 : H12AffineFastState.Bounded env55908 := by
  intro p hp
  have h : env55908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55899_55908 : H12AffineEnvironment.transform 12 469 env55899 = env55908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env55899 == env55908) = true)

theorem identity55908 : scanCanonicalize (H12AffineFastState.compose env55908 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound55908 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env55909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,478,49169,2556,1024,32769,4160,21929,32785,2,349,65,56713,38161,50433,35325,1501,33,256,21792,38224,513]

theorem envBound55909 : H12AffineFastState.Bounded env55909 := by
  intro p hp
  have h : env55909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55908_55909 : H12AffineEnvironment.transform 15 478 env55908 = env55909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env55908 == env55909) = true)

theorem identity55909 : scanCanonicalize (H12AffineFastState.compose env55909 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55909 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,1,478,16400,2556,1024,0,4160,21929,16,2,349,65,23944,5392,17664,2556,1501,33,256,21792,5457,513]

theorem envBound55910 : H12AffineFastState.Bounded env55910 := by
  intro p hp
  have h : env55910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55909_55910 : H12AffineEnvironment.transform 14 1 env55909 = env55910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55909 == env55910) = true)

theorem identity55910 : scanCanonicalize (H12AffineFastState.compose env55910 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55910 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,478,5393,2556,1024,0,4160,168,16,2,349,65,2185,5392,4097,2556,1501,33,256,33,5457,513]

theorem envBound55911 : H12AffineFastState.Bounded env55911 := by
  intro p hp
  have h : env55911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55910_55911 : H12AffineEnvironment.transform 13 5377 env55910 = env55911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55910 == env55911) = true)

theorem identity55911 : scanCanonicalize (H12AffineFastState.compose env55911 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound55911 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55912 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,128,5204,1,139,5188,2217,1024,0,4160,168,16,2,8,65,2185,5189,4097,2217,1160,33,85,33,5124,513]

theorem envBound55912 : H12AffineFastState.Bounded env55912 := by
  intro p hp
  have h : env55912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55911_55912 : H12AffineEnvironment.transform 7 85 env55911 = env55912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env55911 == env55912) = true)

theorem identity55912 : scanCanonicalize (H12AffineFastState.compose env55912 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55912 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55913 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,9,5204,1,2,5188,2080,1024,0,4160,33,16,2,8,65,2048,5189,4097,2080,1025,33,85,33,5124,513]

theorem envBound55913 : H12AffineFastState.Bounded env55913 := by
  intro p hp
  have h : env55913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55912_55913 : H12AffineEnvironment.transform 6 9 env55912 = env55913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55912 == env55913) = true)

theorem identity55913 : scanCanonicalize (H12AffineFastState.compose env55913 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound55913 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55914 : List Nat := [2,4,8,16,32,64,9,85,512,69,2048,4096,9,4113,1,2,4097,2080,69,0,4160,33,16,2,8,65,2048,4096,4097,2080,68,33,85,33,4161,513]

theorem envBound55914 : H12AffineFastState.Bounded env55914 := by
  intro p hp
  have h : env55914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55913_55914 : H12AffineEnvironment.transform 9 69 env55913 = env55914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env55913 == env55914) = true)

theorem identity55914 : scanCanonicalize (H12AffineFastState.compose env55914 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound55914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55915 : List Nat := [2,4,8,16,32,64,9,85,512,69,2048,49,9,32,1,2,48,2080,69,0,113,33,16,2,8,65,2048,49,48,2080,68,33,85,33,112,513]

theorem envBound55915 : H12AffineFastState.Bounded env55915 := by
  intro p hp
  have h : env55915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55914_55915 : H12AffineEnvironment.transform 11 49 env55914 = env55915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55914 == env55915) = true)

theorem identity55915 : scanCanonicalize (H12AffineFastState.compose env55915 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55915 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55916 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,9,0,1,2,16,2048,69,0,81,1,16,2,8,65,2048,17,16,2048,68,1,85,1,80,513]

theorem envBound55916 : H12AffineFastState.Bounded env55916 := by
  intro p hp
  have h : env55916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55915_55916 : H12AffineEnvironment.transform 4 0 env55915 = env55916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55915 == env55916) = true)

theorem identity55916 : scanCanonicalize (H12AffineFastState.compose env55916 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound55916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55917 : List Nat := [2,4,8,16,0,64,9,85,512,69,593,17,9,0,1,2,16,593,69,0,81,1,16,2,8,65,593,17,16,593,68,1,85,1,80,513]

theorem envBound55917 : H12AffineFastState.Bounded env55917 := by
  intro p hp
  have h : env55917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55916_55917 : H12AffineEnvironment.transform 10 593 env55916 = env55917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env55916 == env55917) = true)

theorem identity55917 : scanCanonicalize (H12AffineFastState.compose env55917 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound55917 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55918 : List Nat := [2,4,8,16,0,64,9,85,81,69,0,17,9,0,1,2,16,0,69,0,81,1,16,2,8,65,0,17,16,0,68,1,85,1,80,80]

theorem envBound55918 : H12AffineFastState.Bounded env55918 := by
  intro p hp
  have h : env55918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55917_55918 : H12AffineEnvironment.transform 8 81 env55917 = env55918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env55917 == env55918) = true)

theorem identity55918 : scanCanonicalize (H12AffineFastState.compose env55918 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55919 : List Nat := [2,4,2,16,0,64,3,85,81,69,0,17,3,0,1,2,16,0,69,0,81,1,16,2,2,65,0,17,16,0,68,1,85,1,80,80]

theorem envBound55919 : H12AffineFastState.Bounded env55919 := by
  intro p hp
  have h : env55919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55918_55919 : H12AffineEnvironment.transform 2 2 env55918 = env55919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55918 == env55919) = true)

theorem identity55919 : scanCanonicalize (H12AffineFastState.compose env55919 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55919 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55920 : List Nat := [2,4,2,0,0,64,3,69,65,69,0,1,3,0,1,2,0,0,69,0,65,1,0,2,2,65,0,1,0,0,68,1,69,1,64,64]

theorem envBound55920 : H12AffineFastState.Bounded env55920 := by
  intro p hp
  have h : env55920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55919_55920 : H12AffineEnvironment.transform 3 0 env55919 = env55920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55919 == env55920) = true)

def env55921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,510001,8328,65,316532,417021,396524,35324,1500,272393,256,21792,46213,74251]

theorem envBound55921 : H12AffineFastState.Bounded env55921 := by
  intro p hp
  have h : env55921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55864_55921 : H12AffineEnvironment.transform 20 4161 env55864 = env55921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55864 == env55921) = true)

theorem identity55921 : scanCanonicalize (H12AffineFastState.compose env55921 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound55921 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169400,62660,95496,8328,65,158029,57796,45525,35324,1500,169264,256,21792,46213,74251]

theorem envBound55922 : H12AffineFastState.Bounded env55922 := by
  intro p hp
  have h : env55922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55921_55922 : H12AffineEnvironment.transform 17 179513 env55921 = env55922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env55921 == env55922) = true)

theorem identity55922 : scanCanonicalize (H12AffineFastState.compose env55922 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55922 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env55923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4161,169400,62660,21762,8328,65,158029,57796,45525,35324,1500,169264,256,21792,46213,513]

theorem envBound55923 : H12AffineFastState.Bounded env55923 := by
  intro p hp
  have h : env55923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55922_55923 : H12AffineEnvironment.transform 15 8202 env55922 = env55923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55922 == env55923) = true)

theorem identity55923 : scanCanonicalize (H12AffineFastState.compose env55923 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound55923 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env55924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16537,64928,1024,32769,4161,54561,62660,21762,8328,65,10708,57796,45525,35324,1500,54697,256,21792,46213,513]

theorem envBound55924 : H12AffineFastState.Bounded env55924 := by
  intro p hp
  have h : env55924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55923_55924 : H12AffineEnvironment.transform 16 16537 env55923 = env55924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env55923 == env55924) = true)

theorem identity55924 : scanCanonicalize (H12AffineFastState.compose env55924 (packedSelected [2,3,6,7,10,11,14,15,19,20,24,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound55924 : packedSelected [2,3,6,7,10,11,14,15,19,20,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env55925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,8202,16537,32121,1024,216,4161,22008,29725,21762,8328,65,10708,24861,12556,2341,1500,21872,256,21792,13404,513]

theorem envBound55925 : H12AffineFastState.Bounded env55925 := by
  intro p hp
  have h : env55925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55924_55925 : H12AffineEnvironment.transform 14 217 env55924 = env55925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env55924 == env55925) = true)

theorem identity55925 : scanCanonicalize (H12AffineFastState.compose env55925 (packedSelected [1,2,3,5,6,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55925 : packedSelected [1,2,3,5,6,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env55926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,217,8202,13508,2340,1024,216,4161,8613,64,8543,8328,65,10708,5440,12556,2341,1500,8493,256,8573,13404,513]

theorem envBound55926 : H12AffineFastState.Bounded env55926 := by
  intro p hp
  have h : env55926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55925_55926 : H12AffineEnvironment.transform 13 13405 env55925 = env55926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55925 == env55926) = true)

theorem identity55926 : scanCanonicalize (H12AffineFastState.compose env55926 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55926 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env55927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5457,217,262,5576,2340,1024,216,4161,169,64,83,388,65,2264,5440,4096,2341,1500,33,256,113,5456,513]

theorem envBound55927 : H12AffineFastState.Bounded env55927 := by
  intro p hp
  have h : env55927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55926_55927 : H12AffineEnvironment.transform 12 268 env55926 = env55927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55926 == env55927) = true)

theorem identity55927 : scanCanonicalize (H12AffineFastState.compose env55927 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55927 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,81,262,5440,2340,1024,80,4161,33,64,83,268,65,2128,5440,4096,2341,1364,33,256,113,5456,513]

theorem envBound55928 : H12AffineFastState.Bounded env55928 := by
  intro p hp
  have h : env55928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55927_55928 : H12AffineEnvironment.transform 6 8 env55927 = env55928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55927 == env55928) = true)

theorem identity55928 : scanCanonicalize (H12AffineFastState.compose env55928 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound55928 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2405,268,3124,81,262,3109,2340,1024,80,2340,33,64,83,268,65,2128,3109,2405,2341,1364,33,256,113,3125,513]

theorem envBound55929 : H12AffineFastState.Bounded env55929 := by
  intro p hp
  have h : env55929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55928_55929 : H12AffineEnvironment.transform 11 2405 env55928 = env55929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env55928 == env55929) = true)

theorem identity55929 : scanCanonicalize (H12AffineFastState.compose env55929 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55929 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env55930 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2356,268,3124,0,262,3109,2340,1024,1,2340,33,17,2,268,16,2049,3109,2356,2341,1285,33,256,32,3125,513]

theorem envBound55930 : H12AffineFastState.Bounded env55930 := by
  intro p hp
  have h : env55930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55929_55930 : H12AffineEnvironment.transform 5 17 env55929 = env55930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55929 == env55930) = true)

theorem identity55930 : scanCanonicalize (H12AffineFastState.compose env55930 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55930 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55931 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,2356,268,2340,0,262,2357,2340,272,1,2340,33,17,2,268,16,2049,2357,2356,2341,21,33,256,32,2341,513]

theorem envBound55931 : H12AffineFastState.Bounded env55931 := by
  intro p hp
  have h : env55931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55930_55931 : H12AffineEnvironment.transform 9 272 env55930 = env55931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55930 == env55931) = true)

def env55932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513340,510001,8328,65,2409524,2510012,396524,2136509,2102685,2373705,256,21792,46213,2175562]

theorem envBound55932 : H12AffineFastState.Bounded env55932 := by
  intro p hp
  have h : env55932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55863_55932 : H12AffineEnvironment.transform 21 169401 env55863 = env55932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env55863 == env55932) = true)

def env55933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,510001,8328,65,316532,417020,396524,35325,1501,272393,256,21792,46213,74250]

theorem envBound55933 : H12AffineFastState.Bounded env55933 := by
  intro p hp
  have h : env55933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55932_55933 : H12AffineEnvironment.transform 20 4160 env55932 = env55933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55932 == env55933) = true)

theorem identity55933 : scanCanonicalize (H12AffineFastState.compose env55933 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound55933 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,169401,16,98781,8328,65,171416,5392,17664,35325,1501,156133,256,21792,46213,74250]

theorem envBound55934 : H12AffineFastState.Bounded env55934 := by
  intro p hp
  have h : env55934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55933_55934 : H12AffineEnvironment.transform 17 149996 env55933 = env55934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env55933 == env55934) = true)

def env55935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169265,16,98645,8192,65,171280,5392,17664,35189,1365,156013,256,21792,46093,74250]

theorem envBound55935 : H12AffineFastState.Bounded env55935 := by
  intro p hp
  have h : env55935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55934_55935 : H12AffineEnvironment.transform 6 8 env55934 = env55935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55934 == env55935) = true)

theorem identity55935 : scanCanonicalize (H12AffineFastState.compose env55935 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound55935 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4160,21792,16,98645,8192,65,23809,5392,17664,35189,1365,41340,256,21792,46093,74250]

theorem envBound55936 : H12AffineFastState.Bounded env55936 := by
  intro p hp
  have h : env55936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55935_55936 : H12AffineEnvironment.transform 16 49169 env55935 = env55936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55935 == env55936) = true)

theorem identity55936 : scanCanonicalize (H12AffineFastState.compose env55936 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound55936 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env55937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,49169,35189,1024,32769,4160,21792,16,32851,8192,65,23809,5392,17664,35189,1365,41340,256,21792,46093,8972]

theorem envBound55937 : H12AffineFastState.Bounded env55937 := by
  intro p hp
  have h : env55937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55936_55937 : H12AffineEnvironment.transform 15 262 env55936 = env55937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env55936 == env55937) = true)

theorem identity55937 : scanCanonicalize (H12AffineFastState.compose env55937 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound55937 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,262,24860,10360,1024,8460,4160,21792,16,8542,8192,65,23809,5392,17664,10360,1365,113,256,21792,5376,8972]

theorem envBound55938 : H12AffineFastState.Bounded env55938 := by
  intro p hp
  have h : env55938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55937_55938 : H12AffineEnvironment.transform 14 8461 env55937 = env55938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env55937 == env55938) = true)

theorem identity55938 : scanCanonicalize (H12AffineFastState.compose env55938 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound55938 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8461,262,5393,10360,1024,8460,4160,8493,16,8542,8192,65,10508,5392,12557,10360,1365,113,256,8493,5376,8972]

theorem envBound55939 : H12AffineFastState.Bounded env55939 := by
  intro p hp
  have h : env55939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55938_55939 : H12AffineEnvironment.transform 13 13325 env55938 = env55939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env55938 == env55939) = true)

theorem identity55939 : scanCanonicalize (H12AffineFastState.compose env55939 (packedSelected [1,8,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55939 : packedSelected [1,8,10,14,16] rootPS < 2^1333 := by decide +kernel

def env55940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5157,293,262,5393,2128,1024,292,4160,261,16,374,40,65,2340,5392,4389,2128,1365,113,256,261,5376,804]

theorem envBound55940 : H12AffineFastState.Bounded env55940 := by
  intro p hp
  have h : env55940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55939_55940 : H12AffineEnvironment.transform 12 40 env55939 = env55940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55939 == env55940) = true)

theorem identity55940 : scanCanonicalize (H12AffineFastState.compose env55940 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55940 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55941 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5157,80,115,5220,2128,1024,81,4160,112,16,3,40,65,2129,5221,4176,2128,1056,113,117,112,5237,593]

theorem envBound55941 : H12AffineFastState.Bounded env55941 := by
  intro p hp
  have h : env55941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55940_55941 : H12AffineEnvironment.transform 7 117 env55940 = env55941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55940 == env55941) = true)

theorem identity55941 : scanCanonicalize (H12AffineFastState.compose env55941 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55941 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55942 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,0,35,5172,2048,1024,1,4112,32,16,3,40,17,2049,5173,4096,2048,1056,33,37,32,5157,513]

theorem envBound55942 : H12AffineFastState.Bounded env55942 := by
  intro p hp
  have h : env55942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55941_55942 : H12AffineEnvironment.transform 5 16 env55941 = env55942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55941 == env55942) = true)

theorem identity55942 : scanCanonicalize (H12AffineFastState.compose env55942 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound55942 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55943 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,4096,40,4096,0,35,4113,2048,37,1,4112,32,16,3,40,17,2049,4112,4096,2048,5,33,37,32,4096,513]

theorem envBound55943 : H12AffineFastState.Bounded env55943 := by
  intro p hp
  have h : env55943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55942_55943 : H12AffineEnvironment.transform 9 37 env55942 = env55943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env55942 == env55943) = true)

theorem identity55943 : scanCanonicalize (H12AffineFastState.compose env55943 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound55943 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55944 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,2074,40,2074,0,35,2059,2048,37,1,2058,32,16,3,40,17,2049,2058,2074,2048,5,33,37,32,2074,513]

theorem envBound55944 : H12AffineFastState.Bounded env55944 := by
  intro p hp
  have h : env55944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55943_55944 : H12AffineEnvironment.transform 11 2074 env55943 = env55944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env55943 == env55944) = true)

theorem identity55944 : scanCanonicalize (H12AffineFastState.compose env55944 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound55944 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55945 : List Nat := [2,4,8,16,32,16,8,37,512,37,43,49,40,49,0,35,32,43,37,1,33,32,16,3,40,17,42,33,49,43,5,33,37,32,49,513]

theorem envBound55945 : H12AffineFastState.Bounded env55945 := by
  intro p hp
  have h : env55945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55944_55945 : H12AffineEnvironment.transform 10 43 env55944 = env55945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env55944 == env55945) = true)

theorem identity55945 : scanCanonicalize (H12AffineFastState.compose env55945 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound55945 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55946 : List Nat := [2,4,8,16,32,16,8,37,30,37,43,49,40,49,0,35,32,43,37,1,33,32,16,3,40,17,42,33,49,43,5,33,37,32,49,31]

theorem envBound55946 : H12AffineFastState.Bounded env55946 := by
  intro p hp
  have h : env55946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55945_55946 : H12AffineEnvironment.transform 8 30 env55945 = env55946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env55945 == env55946) = true)

def env55947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,98644,8193,65,171281,5392,17664,35188,1364,156012,256,21792,46092,74250]

theorem envBound55947 : H12AffineFastState.Bounded env55947 := by
  intro p hp
  have h : env55947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55934_55947 : H12AffineEnvironment.transform 6 9 env55934 = env55947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55934 == env55947) = true)

theorem identity55947 : scanCanonicalize (H12AffineFastState.compose env55947 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound55947 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1024,32769,4160,62588,16,98644,8193,65,64605,5392,17664,35188,1364,32,256,21792,46092,74250]

theorem envBound55948 : H12AffineFastState.Bounded env55948 := by
  intro p hp
  have h : env55948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55947_55948 : H12AffineEnvironment.transform 16 24908 env55947 = env55948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env55947 == env55948) = true)

theorem identity55948 : scanCanonicalize (H12AffineFastState.compose env55948 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound55948 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env55949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,10281,1024,32769,4160,62588,16,29790,8193,65,64605,5392,17664,35188,1364,32,256,21792,46092,55040]

theorem envBound55949 : H12AffineFastState.Bounded env55949 := by
  intro p hp
  have h : env55949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55948_55949 : H12AffineEnvironment.transform 15 62730 env55948 = env55949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env55948 == env55949) = true)

theorem identity55949 : scanCanonicalize (H12AffineFastState.compose env55949 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55949 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env55950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,24908,10281,1024,8541,4160,21792,16,29790,8193,65,23809,5392,17664,10280,1364,32,256,21792,5456,30300]

theorem envBound55950 : H12AffineFastState.Bounded env55950 := by
  intro p hp
  have h : env55950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55949_55950 : H12AffineEnvironment.transform 14 8540 env55949 = env55950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55949 == env55950) = true)

theorem identity55950 : scanCanonicalize (H12AffineFastState.compose env55950 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound55950 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,5393,10281,1024,8541,4160,8573,16,3,8193,65,10588,5392,12637,10280,1364,32,256,8573,5456,513]

theorem envBound55951 : H12AffineFastState.Bounded env55951 := by
  intro p hp
  have h : env55951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55950_55951 : H12AffineEnvironment.transform 13 13405 env55950 = env55951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env55950 == env55951) = true)

theorem identity55951 : scanCanonicalize (H12AffineFastState.compose env55951 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55951 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5393,2421,1024,1,4160,33,16,3,349,65,2048,5392,4097,2420,1364,32,256,33,5456,513]

theorem envBound55952 : H12AffineFastState.Bounded env55952 := by
  intro p hp
  have h : env55952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55951_55952 : H12AffineEnvironment.transform 12 348 env55951 = env55952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55951 == env55952) = true)

theorem identity55952 : scanCanonicalize (H12AffineFastState.compose env55952 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound55952 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,17,348,1296,0,343,1280,2421,1024,1,81,33,16,3,349,65,2048,1281,16,2420,1364,32,256,33,1345,513]

theorem envBound55953 : H12AffineFastState.Bounded env55953 := by
  intro p hp
  have h : env55953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55952_55953 : H12AffineEnvironment.transform 11 17 env55952 = env55953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env55952 == env55953) = true)

theorem identity55953 : scanCanonicalize (H12AffineFastState.compose env55953 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound55953 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1556,17,348,1296,0,343,1280,1889,1024,1,81,33,16,3,349,65,1556,1281,16,1888,1364,32,256,33,1345,513]

theorem envBound55954 : H12AffineFastState.Bounded env55954 := by
  intro p hp
  have h : env55954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55953_55954 : H12AffineEnvironment.transform 10 1556 env55953 = env55954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env55953 == env55954) = true)

theorem identity55954 : scanCanonicalize (H12AffineFastState.compose env55954 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 865) := by decide +kernel

theorem selectedBound55954 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55955 : List Nat := [2,4,8,16,32,64,9,256,512,865,373,17,348,625,0,343,609,0,865,1,81,33,16,3,349,65,373,608,16,1,565,32,256,33,544,513]

theorem envBound55955 : H12AffineFastState.Bounded env55955 := by
  intro p hp
  have h : env55955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55954_55955 : H12AffineEnvironment.transform 9 865 env55954 = env55955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 865 env55954 == env55955) = true)

theorem identity55955 : scanCanonicalize (H12AffineFastState.compose env55955 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound55955 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55956 : List Nat := [2,4,8,16,32,64,9,256,276,117,373,17,348,357,0,343,373,0,117,1,81,33,16,3,349,65,373,372,16,1,289,32,256,33,308,277]

theorem envBound55956 : H12AffineFastState.Bounded env55956 := by
  intro p hp
  have h : env55956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55955_55956 : H12AffineEnvironment.transform 8 276 env55955 = env55956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env55955 == env55956) = true)

theorem identity55956 : scanCanonicalize (H12AffineFastState.compose env55956 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55956 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env55957 : List Nat := [2,4,8,16,0,64,9,256,276,85,341,17,348,325,0,343,341,0,85,1,81,1,16,3,349,65,341,340,16,1,257,0,256,1,276,277]

theorem envBound55957 : H12AffineFastState.Bounded env55957 := by
  intro p hp
  have h : env55957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55956_55957 : H12AffineEnvironment.transform 4 0 env55956 = env55957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55956 == env55957) = true)

theorem identity55957 : scanCanonicalize (H12AffineFastState.compose env55957 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55957 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env55958 : List Nat := [2,4,8,0,0,64,9,256,260,69,325,1,332,325,0,327,325,0,69,1,65,1,0,3,333,65,325,324,0,1,257,0,256,1,260,261]

theorem envBound55958 : H12AffineFastState.Bounded env55958 := by
  intro p hp
  have h : env55958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55957_55958 : H12AffineEnvironment.transform 3 0 env55957 = env55958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55957 == env55958) = true)

theorem identity55958 : scanCanonicalize (H12AffineFastState.compose env55958 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound55958 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55959 : List Nat := [2,4,8,0,0,64,9,68,64,69,1,1,8,1,0,3,1,0,69,1,65,1,0,3,9,65,1,0,0,1,69,0,68,1,64,65]

theorem envBound55959 : H12AffineFastState.Bounded env55959 := by
  intro p hp
  have h : env55959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55958_55959 : H12AffineEnvironment.transform 7 68 env55958 = env55959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env55958 == env55959) = true)

def env55960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,510001,8328,65,316533,417021,396524,35324,1500,272392,256,21792,46213,74251]

theorem envBound55960 : H12AffineFastState.Bounded env55960 := by
  intro p hp
  have h : env55960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55932_55960 : H12AffineEnvironment.transform 20 4161 env55932 = env55960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55932 == env55960) = true)

theorem identity55960 : scanCanonicalize (H12AffineFastState.compose env55960 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound55960 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,156013,412157,474341,8328,65,270497,417021,396524,32040,1500,272392,256,21792,16465,74251]

theorem envBound55961 : H12AffineFastState.Bounded env55961 := by
  intro p hp
  have h : env55961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55960_55961 : H12AffineEnvironment.transform 14 29908 env55960 = env55961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env55960 == env55961) = true)

def env55962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32240,1024,29909,4161,156013,144397,213269,8328,65,23889,139533,160028,32040,1500,22008,256,21792,16465,74251]

theorem envBound55962 : H12AffineFastState.Bounded env55962 := by
  intro p hp
  have h : env55962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55961_55962 : H12AffineEnvironment.transform 17 32240 env55961 = env55962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env55961 == env55962) = true)

theorem identity55962 : scanCanonicalize (H12AffineFastState.compose env55962 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

end H12CloudChart0