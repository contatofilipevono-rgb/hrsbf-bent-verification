import H12CloudChart0Data158

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound40310 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40311 : List Nat := [2,4,8,16,0,64,128,256,512,272,2048,4096,349,4249,0,479,4233,2389,273,1,4160,136,153,138,469,64,2049,4232,4097,2525,205,136,257,137,4297,648]

theorem envBound40311 : H12AffineFastState.Bounded env40311 := by
  intro p hp
  have h : env40311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40310_40311 : H12AffineEnvironment.transform 9 272 env40310 = env40311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40310 == env40311) = true)

theorem identity40311 : scanCanonicalize (H12AffineFastState.compose env40311 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound40311 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40312 : List Nat := [2,4,8,16,0,64,128,256,512,272,2048,2324,349,2445,0,479,2461,2389,273,1,2388,136,153,138,469,64,2049,2460,2325,2525,205,136,257,137,2525,648]

theorem envBound40312 : H12AffineFastState.Bounded env40312 := by
  intro p hp
  have h : env40312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40311_40312 : H12AffineEnvironment.transform 11 2324 env40311 = env40312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env40311 == env40312) = true)

theorem identity40312 : scanCanonicalize (H12AffineFastState.compose env40312 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound40312 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env40313 : List Nat := [2,4,8,16,0,64,128,141,512,157,2048,2201,208,2048,0,82,2064,2264,156,1,2265,136,153,138,88,64,2049,2065,2200,2128,205,136,140,137,2128,648]

theorem envBound40313 : H12AffineFastState.Bounded env40313 := by
  intro p hp
  have h : env40313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40312_40313 : H12AffineEnvironment.transform 7 141 env40312 = env40313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env40312 == env40313) = true)

theorem identity40313 : scanCanonicalize (H12AffineFastState.compose env40313 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40313 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40314 : List Nat := [2,4,8,16,0,16,128,141,512,157,2048,2201,128,2048,0,2,2064,2184,156,1,2185,136,153,138,8,16,2049,2065,2200,2048,157,136,140,137,2048,648]

theorem envBound40314 : H12AffineFastState.Bounded env40314 := by
  intro p hp
  have h : env40314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40313_40314 : H12AffineEnvironment.transform 5 16 env40313 = env40314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40313 == env40314) = true)

theorem identity40314 : scanCanonicalize (H12AffineFastState.compose env40314 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40314 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40315 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,2064,9,2048,0,2,2064,2049,21,1,2048,1,16,3,8,16,2049,2065,2065,2048,20,1,5,0,2048,513]

theorem envBound40315 : H12AffineFastState.Bounded env40315 := by
  intro p hp
  have h : env40315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40314_40315 : H12AffineEnvironment.transform 6 9 env40314 = env40315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40314 == env40315) = true)

theorem identity40315 : scanCanonicalize (H12AffineFastState.compose env40315 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound40315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40316 : List Nat := [2,4,8,16,0,16,9,4,512,20,528,512,9,528,0,2,512,529,21,1,528,1,16,3,8,16,529,513,513,528,20,1,5,0,528,513]

theorem envBound40316 : H12AffineFastState.Bounded env40316 := by
  intro p hp
  have h : env40316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40315_40316 : H12AffineEnvironment.transform 10 528 env40315 = env40316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env40315 == env40316) = true)

theorem identity40316 : scanCanonicalize (H12AffineFastState.compose env40316 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40316 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40317 : List Nat := [2,4,8,10,0,10,9,4,512,14,522,512,9,522,0,2,512,523,15,1,522,1,10,3,8,10,523,513,513,522,14,1,5,0,522,513]

theorem envBound40317 : H12AffineFastState.Bounded env40317 := by
  intro p hp
  have h : env40317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40316_40317 : H12AffineEnvironment.transform 3 10 env40316 = env40317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40316 == env40317) = true)

theorem identity40317 : scanCanonicalize (H12AffineFastState.compose env40317 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound40317 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40318 : List Nat := [2,4,8,10,0,10,9,4,11,14,1,11,9,1,0,2,11,0,15,1,1,1,10,3,8,10,0,10,10,1,14,1,5,0,1,10]

theorem envBound40318 : H12AffineFastState.Bounded env40318 := by
  intro p hp
  have h : env40318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40317_40318 : H12AffineEnvironment.transform 8 11 env40317 = env40318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env40317 == env40318) = true)

def env40319 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,262144,1025,29909,4160,272512,73755,29790,8328,64,10588,70727,91402,357763,9344,338271,257,29788,24845,66391]

theorem envBound40319 : H12AffineFastState.Bounded env40319 := by
  intro p hp
  have h : env40319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40305_40319 : H12AffineEnvironment.transform 4 1 env40305 = env40319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40305 == env40319) = true)

theorem identity40319 : scanCanonicalize (H12AffineFastState.compose env40319 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound40319 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env40320 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,2525,1025,29909,4160,8541,73755,29790,8328,64,10588,70727,91402,97374,9344,73858,257,29788,24845,66391]

theorem envBound40320 : H12AffineFastState.Bounded env40320 := by
  intro p hp
  have h : env40320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40319_40320 : H12AffineEnvironment.transform 17 2525 env40319 = env40320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env40319 == env40320) = true)

theorem identity40320 : scanCanonicalize (H12AffineFastState.compose env40320 (packedSelected [1,2,4,6,7,9,10,11,16,17,18,19,20,23,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound40320 : packedSelected [1,2,4,6,7,9,10,11,16,17,18,19,20,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env40321 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29908,479,24909,2525,1025,29909,4160,8541,8644,29790,8328,64,10588,5528,25813,32129,9344,8541,257,29788,24845,648]

theorem envBound40321 : H12AffineFastState.Bounded env40321 := by
  intro p hp
  have h : env40321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40320_40321 : H12AffineEnvironment.transform 15 479 env40320 = env40321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env40320 == env40321) = true)

theorem identity40321 : scanCanonicalize (H12AffineFastState.compose env40321 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound40321 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env40322 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13524,0,479,5529,2525,1025,1,4160,8541,8644,138,8328,64,10588,5528,4097,2389,9344,8541,257,136,5593,648]

theorem envBound40322 : H12AffineFastState.Bounded env40322 := by
  intro p hp
  have h : env40322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40321_40322 : H12AffineEnvironment.transform 13 13524 env40321 = env40322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env40321 == env40322) = true)

theorem identity40322 : scanCanonicalize (H12AffineFastState.compose env40322 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound40322 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40323 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,468,5376,0,479,5529,2525,1025,1,4160,137,16,138,348,64,2184,5528,4097,2389,1364,137,257,136,5593,648]

theorem envBound40323 : H12AffineFastState.Bounded env40323 := by
  intro p hp
  have h : env40323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40322_40323 : H12AffineEnvironment.transform 12 468 env40322 = env40323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env40322 == env40323) = true)

theorem identity40323 : scanCanonicalize (H12AffineFastState.compose env40323 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound40323 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40324 : List Nat := [2,4,8,16,1,64,128,140,512,1024,2048,4096,88,5260,0,83,5141,2129,1025,1,4160,137,16,138,208,64,2184,5140,4097,2265,1240,137,141,136,5205,648]

theorem envBound40324 : H12AffineFastState.Bounded env40324 := by
  intro p hp
  have h : env40324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40323_40324 : H12AffineEnvironment.transform 7 140 env40323 = env40324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env40323 == env40324) = true)

theorem identity40324 : scanCanonicalize (H12AffineFastState.compose env40324 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound40324 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40325 : List Nat := [2,4,8,16,1,64,128,140,512,21,2048,4096,88,4249,0,83,4096,2129,20,1,4160,137,16,138,208,64,2184,4097,4097,2265,205,137,141,136,4160,648]

theorem envBound40325 : H12AffineFastState.Bounded env40325 := by
  intro p hp
  have h : env40325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40324_40325 : H12AffineEnvironment.transform 9 21 env40324 = env40325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env40324 == env40325) = true)

theorem identity40325 : scanCanonicalize (H12AffineFastState.compose env40325 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound40325 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40326 : List Nat := [2,4,8,16,1,64,89,85,512,21,2048,4096,88,4160,0,83,4096,2129,20,1,4160,80,16,83,9,64,2129,4097,4097,2048,20,80,84,81,4160,593]

theorem envBound40326 : H12AffineFastState.Bounded env40326 := by
  intro p hp
  have h : env40326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40325_40326 : H12AffineEnvironment.transform 6 89 env40325 = env40326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env40325 == env40326) = true)

theorem identity40326 : scanCanonicalize (H12AffineFastState.compose env40326 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound40326 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40327 : List Nat := [2,4,8,16,1,64,89,85,512,21,81,4096,88,4160,0,83,4096,0,20,1,4160,80,16,83,9,64,0,4097,4097,81,20,80,84,81,4160,593]

theorem envBound40327 : H12AffineFastState.Bounded env40327 := by
  intro p hp
  have h : env40327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40326_40327 : H12AffineEnvironment.transform 10 81 env40326 = env40327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env40326 == env40327) = true)

theorem identity40327 : scanCanonicalize (H12AffineFastState.compose env40327 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound40327 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40328 : List Nat := [2,4,8,16,1,64,89,85,512,21,81,16,88,80,0,83,16,0,20,1,80,80,16,83,9,64,0,17,17,81,20,80,84,81,80,593]

theorem envBound40328 : H12AffineFastState.Bounded env40328 := by
  intro p hp
  have h : env40328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40327_40328 : H12AffineEnvironment.transform 11 16 env40327 = env40328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env40327 == env40328) = true)

theorem identity40328 : scanCanonicalize (H12AffineFastState.compose env40328 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40328 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env40329 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,16,9,1,0,2,16,0,20,1,1,1,16,2,9,17,0,17,17,0,20,1,5,0,1,512]

theorem envBound40329 : H12AffineFastState.Bounded env40329 := by
  intro p hp
  have h : env40329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40328_40329 : H12AffineEnvironment.transform 5 17 env40328 = env40329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40328 == env40329) = true)

theorem identity40329 : scanCanonicalize (H12AffineFastState.compose env40329 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound40329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40330 : List Nat := [2,4,8,16,1,17,8,4,15,21,0,16,9,1,0,2,16,0,20,1,1,1,16,2,9,17,0,17,17,0,20,1,5,0,1,15]

theorem envBound40330 : H12AffineFastState.Bounded env40330 := by
  intro p hp
  have h : env40330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40329_40330 : H12AffineEnvironment.transform 8 15 env40329 = env40330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env40329 == env40330) = true)

def env40331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound40331 : H12AffineFastState.Bounded env40331 := by
  intro p hp
  have h : env40331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39564_40331 : H12AffineEnvironment.transform 25 65 env39564 = env40331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env39564 == env40331) = true)

def env40332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound40332 : H12AffineFastState.Bounded env40332 := by
  intro p hp
  have h : env40332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40331_40332 : H12AffineEnvironment.transform 26 30393344 env40331 = env40332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env40331 == env40332) = true)

def env40333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound40333 : H12AffineFastState.Bounded env40333 := by
  intro p hp
  have h : env40333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40332_40333 : H12AffineEnvironment.transform 18 1024 env40332 = env40333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env40332 == env40333) = true)

theorem identity40333 : scanCanonicalize (H12AffineFastState.compose env40333 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882103) := by decide +kernel

theorem selectedBound40333 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882103,8328,65,6409271,8882363,10507600,8830977,2590759,13068791,256,510107,469311,2535408]

theorem envBound40334 : H12AffineFastState.Bounded env40334 := by
  intro p hp
  have h : env40334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40333_40334 : H12AffineEnvironment.transform 23 10882103 env40333 = env40334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882103 env40333 == env40334) = true)

def env40335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412020,2114883,8328,65,6409271,115151,2497572,35189,2590759,4268163,256,510107,469311,2535408]

theorem envBound40335 : H12AffineFastState.Bounded env40335 := by
  intro p hp
  have h : env40335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40334_40335 : H12AffineEnvironment.transform 22 412020 env40334 = env40335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412020 env40334 == env40335) = true)

def env40336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412020,2114883,8328,65,215367,115151,2497572,35189,2590759,2336243,256,510107,469311,2535408]

theorem envBound40336 : H12AffineFastState.Bounded env40336 := by
  intro p hp
  have h : env40336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40335_40336 : H12AffineEnvironment.transform 21 2262384 env40335 = env40336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env40335 == env40336) = true)

def env40337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,21763,8328,65,215367,115151,396388,35189,497767,243123,256,510107,469311,442288]

theorem envBound40337 : H12AffineFastState.Bounded env40337 := by
  intro p hp
  have h : env40337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40336_40337 : H12AffineEnvironment.transform 20 4160 env40336 = env40337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40336 == env40337) = true)

theorem identity40337 : scanCanonicalize (H12AffineFastState.compose env40337 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound40337 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,156133,412020,21763,8328,65,215367,79130,396388,32160,486578,213350,256,474190,469311,412517]

theorem envBound40338 : H12AffineFastState.Bounded env40338 := by
  intro p hp
  have h : env40338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40337_40338 : H12AffineEnvironment.transform 14 29909 env40337 = env40338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env40337 == env40338) = true)

def env40339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,4160,156133,156116,21763,8328,65,215367,79130,140484,32160,214034,213350,256,201966,197023,156613]

theorem envBound40339 : H12AffineFastState.Bounded env40339 := by
  intro p hp
  have h : env40339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40338_40339 : H12AffineEnvironment.transform 17 10400 env40338 = env40339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env40338 == env40339) = true)

theorem identity40339 : scanCanonicalize (H12AffineFastState.compose env40339 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40339 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env40340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,131072,10400,1024,136,4160,136633,136584,8543,8328,65,212251,79130,140484,2556,208974,210234,256,201966,197023,137113]

theorem envBound40340 : H12AffineFastState.Bounded env40340 := by
  intro p hp
  have h : env40340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40339_40340 : H12AffineEnvironment.transform 13 13404 env40339 = env40340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40339 == env40340) = true)

theorem identity40340 : scanCanonicalize (H12AffineFastState.compose env40340 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound40340 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env40341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,70963,10400,1024,136,4160,65674,65723,8543,8328,65,10280,79130,78327,2556,9597,8201,256,477,5292,66218]

theorem envBound40341 : H12AffineFastState.Bounded env40341 := by
  intro p hp
  have h : env40341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40340_40341 : H12AffineEnvironment.transform 16 70963 env40340 = env40341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env40340 == env40341) = true)

theorem identity40341 : scanCanonicalize (H12AffineFastState.compose env40341 (packedSelected [0,3,4,5,10,12,14,15,16,17,19,22,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40341 : packedSelected [0,3,4,5,10,12,14,15,16,17,19,22,26,27] rootPS < 2^1333 := by decide +kernel

def env40342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,13624,10400,1024,136,4160,8321,8368,8543,8328,65,10280,5393,4604,2556,9597,8201,256,477,5292,8865]

theorem envBound40342 : H12AffineFastState.Bounded env40342 := by
  intro p hp
  have h : env40342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40341_40342 : H12AffineEnvironment.transform 15 8203 env40341 = env40342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40341 == env40342) = true)

theorem identity40342 : scanCanonicalize (H12AffineFastState.compose env40342 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40342 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40343 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,13404,137,8203,13460,10400,1024,136,4160,8321,8368,8435,8328,65,10280,5309,4176,2128,9425,8201,172,113,5292,8865]

theorem envBound40343 : H12AffineFastState.Bounded env40343 := by
  intro p hp
  have h : env40343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40342_40343 : H12AffineEnvironment.transform 7 172 env40342 = env40343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40342 == env40343) = true)

theorem identity40343 : scanCanonicalize (H12AffineFastState.compose env40343 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound40343 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40344 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,241,5293,137,250,5221,2129,1024,136,4160,112,65,2,121,65,2265,5309,4176,2128,1056,248,172,113,5292,592]

theorem envBound40344 : H12AffineFastState.Bounded env40344 := by
  intro p hp
  have h : env40344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40343_40344 : H12AffineEnvironment.transform 12 241 env40343 = env40344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env40343 == env40344) = true)

theorem identity40344 : scanCanonicalize (H12AffineFastState.compose env40344 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound40344 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env40345 : List Nat := [2,4,8,16,32,48,128,172,512,1024,2048,4096,129,5293,137,138,5141,2081,1024,136,4144,0,49,2,9,49,2217,5309,4128,2080,1056,136,172,1,5292,544]

theorem envBound40345 : H12AffineFastState.Bounded env40345 := by
  intro p hp
  have h : env40345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40344_40345 : H12AffineEnvironment.transform 5 48 env40344 = env40345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env40344 == env40345) = true)

theorem identity40345 : scanCanonicalize (H12AffineFastState.compose env40345 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40345 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40346 : List Nat := [2,4,8,16,0,16,128,140,512,1024,2048,4096,129,5261,137,138,5141,2049,1024,136,4112,0,17,2,9,17,2185,5277,4096,2048,1024,136,140,1,5260,512]

theorem envBound40346 : H12AffineFastState.Bounded env40346 := by
  intro p hp
  have h : env40346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40345_40346 : H12AffineEnvironment.transform 4 0 env40345 = env40346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40345 == env40346) = true)

theorem identity40346 : scanCanonicalize (H12AffineFastState.compose env40346 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40346 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40347 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,8,5124,0,3,5141,2049,1024,1,4112,0,17,2,9,17,2048,5140,4096,2048,1024,1,5,1,5125,512]

theorem envBound40347 : H12AffineFastState.Bounded env40347 := by
  intro p hp
  have h : env40347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40346_40347 : H12AffineEnvironment.transform 6 9 env40346 = env40347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40346 == env40347) = true)

theorem identity40347 : scanCanonicalize (H12AffineFastState.compose env40347 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound40347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40348 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,1045,8,17,0,3,0,2049,1024,1,1029,0,17,2,9,17,2048,1,1045,2048,1024,1,5,1,16,512]

theorem envBound40348 : H12AffineFastState.Bounded env40348 := by
  intro p hp
  have h : env40348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40347_40348 : H12AffineEnvironment.transform 11 1045 env40347 = env40348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env40347 == env40348) = true)

theorem identity40348 : scanCanonicalize (H12AffineFastState.compose env40348 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound40348 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40349 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1038,1045,8,17,0,3,0,1039,1024,1,1029,0,17,2,9,17,1038,1,1045,1038,1024,1,5,1,16,512]

theorem envBound40349 : H12AffineFastState.Bounded env40349 := by
  intro p hp
  have h : env40349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40348_40349 : H12AffineEnvironment.transform 10 1038 env40348 = env40349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env40348 == env40349) = true)

theorem identity40349 : scanCanonicalize (H12AffineFastState.compose env40349 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40349 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40350 : List Nat := [2,4,8,1,0,1,9,5,512,1024,1038,1028,8,0,0,3,0,1039,1024,1,1029,0,0,2,9,0,1038,1,1028,1038,1024,1,5,1,1,512]

theorem envBound40350 : H12AffineFastState.Bounded env40350 := by
  intro p hp
  have h : env40350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40349_40350 : H12AffineEnvironment.transform 3 1 env40349 = env40350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40349 == env40350) = true)

theorem identity40350 : scanCanonicalize (H12AffineFastState.compose env40350 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound40350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40351 : List Nat := [2,4,8,1,0,1,9,5,512,10,4,14,8,0,0,3,0,5,10,1,15,0,0,2,9,0,4,1,14,4,10,1,5,1,1,512]

theorem envBound40351 : H12AffineFastState.Bounded env40351 := by
  intro p hp
  have h : env40351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40350_40351 : H12AffineEnvironment.transform 9 10 env40350 = env40351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env40350 == env40351) = true)

theorem identity40351 : scanCanonicalize (H12AffineFastState.compose env40351 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40351 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40352 : List Nat := [2,4,2,1,0,1,3,5,512,0,4,4,2,0,0,3,0,5,0,1,5,0,0,2,3,0,4,1,4,4,0,1,5,1,1,512]

theorem envBound40352 : H12AffineFastState.Bounded env40352 := by
  intro p hp
  have h : env40352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40351_40352 : H12AffineEnvironment.transform 2 2 env40351 = env40352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40351 == env40352) = true)

def env40353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,4160,156133,156117,21763,8328,65,215367,79130,140485,32160,214035,213350,256,201967,197022,156612]

theorem envBound40353 : H12AffineFastState.Bounded env40353 := by
  intro p hp
  have h : env40353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40338_40353 : H12AffineEnvironment.transform 17 10401 env40338 = env40353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env40338 == env40353) = true)

theorem identity40353 : scanCanonicalize (H12AffineFastState.compose env40353 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound40353 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env40354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,10401,1024,29908,4160,32,16,21763,8328,65,75906,79130,17664,32160,75222,73891,256,95530,90203,513]

theorem envBound40354 : H12AffineFastState.Bounded env40354 := by
  intro p hp
  have h : env40354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40353_40354 : H12AffineEnvironment.transform 16 25029 env40353 = env40354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env40353 == env40354) = true)

theorem identity40354 : scanCanonicalize (H12AffineFastState.compose env40354 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound40354 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env40355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,13388,10401,1024,8541,4160,32,16,138,8328,65,75906,79130,4233,10281,75222,73891,256,73891,79314,513]

theorem envBound40355 : H12AffineFastState.Bounded env40355 := by
  intro p hp
  have h : env40355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40354_40355 : H12AffineEnvironment.transform 13 5513 env40354 = env40355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env40354 == env40355) = true)

theorem identity40355 : scanCanonicalize (H12AffineFastState.compose env40355 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound40355 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env40356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5513,216,65536,5576,2341,1024,217,4160,32,16,138,268,65,67846,70814,4233,2477,66642,65831,256,65831,70742,513]

theorem envBound40356 : H12AffineFastState.Bounded env40356 := by
  intro p hp
  have h : env40356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40355_40356 : H12AffineEnvironment.transform 12 388 env40355 = env40356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env40355 == env40356) = true)

theorem identity40356 : scanCanonicalize (H12AffineFastState.compose env40356 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40356 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env40357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,137,65536,5529,2341,1024,136,4113,32,16,138,268,16,67846,70814,4233,2477,66563,65831,256,65831,70663,513]

theorem envBound40357 : H12AffineFastState.Bounded env40357 := by
  intro p hp
  have h : env40357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40356_40357 : H12AffineEnvironment.transform 5 17 env40356 = env40357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40356 == env40357) = true)

theorem identity40357 : scanCanonicalize (H12AffineFastState.compose env40357 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 6422) := by decide +kernel

theorem selectedBound40357 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env40358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,137,6422,5529,2341,1024,136,4113,32,16,138,268,16,4112,3464,4233,2477,7445,6193,256,6193,3345,513]

theorem envBound40358 : H12AffineFastState.Bounded env40358 := by
  intro p hp
  have h : env40358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40357_40358 : H12AffineEnvironment.transform 15 6422 env40357 = env40358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6422 env40357 == env40358) = true)

def env40359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,21762,8328,65,215367,115151,396389,35189,497766,243122,256,510107,469311,442289]

theorem envBound40359 : H12AffineFastState.Bounded env40359 := by
  intro p hp
  have h : env40359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40336_40359 : H12AffineEnvironment.transform 20 4161 env40336 = env40359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40336 == env40359) = true)

theorem identity40359 : scanCanonicalize (H12AffineFastState.compose env40359 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound40359 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,21762,8328,65,215367,115151,17665,35189,119042,243122,256,98815,90203,63189]

theorem envBound40360 : H12AffineFastState.Bounded env40360 := by
  intro p hp
  have h : env40360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40359_40360 : H12AffineEnvironment.transform 17 149860 env40359 = env40360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env40359 == env40360) = true)

def env40361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,21762,8192,65,215367,115015,17665,35189,119042,243002,256,98679,90203,63069]

theorem envBound40361 : H12AffineFastState.Bounded env40361 := by
  intro p hp
  have h : env40361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40360_40361 : H12AffineEnvironment.transform 6 8 env40360 = env40361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40360 == env40361) = true)

theorem identity40361 : scanCanonicalize (H12AffineFastState.compose env40361 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound40361 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1024,32769,4161,62588,16,21762,8192,65,75786,115015,17665,35189,119042,119927,256,98679,90203,63069]

theorem envBound40362 : H12AffineFastState.Bounded env40362 := by
  intro p hp
  have h : env40362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40361_40362 : H12AffineEnvironment.transform 16 24909 env40361 = env40362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env40361 == env40362) = true)

theorem identity40362 : scanCanonicalize (H12AffineFastState.compose env40362 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40362 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13389,10281,1024,32769,4161,41340,16,2,8192,65,75786,103495,4097,35189,99330,98679,256,98679,79195,41821]

theorem envBound40363 : H12AffineFastState.Bounded env40363 := by
  intro p hp
  have h : env40363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40362_40363 : H12AffineEnvironment.transform 13 5376 env40362 = env40363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40362 == env40363) = true)

theorem identity40363 : scanCanonicalize (H12AffineFastState.compose env40363 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40363 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13389,10281,1024,8541,4161,32,16,2,8192,65,75786,79131,4097,10281,75102,73771,256,73771,79195,513]

theorem envBound40364 : H12AffineFastState.Bounded env40364 := by
  intro p hp
  have h : env40364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40363_40364 : H12AffineEnvironment.transform 14 8540 env40363 = env40364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40363 == env40364) = true)

theorem identity40364 : scanCanonicalize (H12AffineFastState.compose env40364 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40364 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env40365 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,65536,13341,10281,1024,8461,4113,32,16,2,8192,17,75786,79131,4097,10281,75022,73771,256,73771,79115,513]

theorem envBound40365 : H12AffineFastState.Bounded env40365 := by
  intro p hp
  have h : env40365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40364_40365 : H12AffineEnvironment.transform 5 16 env40364 = env40365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40364 == env40365) = true)

theorem identity40365 : scanCanonicalize (H12AffineFastState.compose env40365 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound40365 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40366 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,262,13341,10281,1024,8461,4113,32,16,2,8192,17,10508,13341,4097,10281,9224,8493,256,8493,13325,513]

theorem envBound40366 : H12AffineFastState.Bounded env40366 := by
  intro p hp
  have h : env40366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40365_40366 : H12AffineEnvironment.transform 15 262 env40365 = env40366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env40365 == env40366) = true)

theorem identity40366 : scanCanonicalize (H12AffineFastState.compose env40366 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3354) := by decide +kernel

theorem selectedBound40366 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env40367 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3354,8192,2074,8460,262,10503,10281,1024,8461,3339,32,16,2,8192,17,10508,10503,3355,10281,9224,8493,256,8493,10519,513]

theorem envBound40367 : H12AffineFastState.Bounded env40367 := by
  intro p hp
  have h : env40367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40366_40367 : H12AffineEnvironment.transform 11 3354 env40366 = env40367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3354 env40366 == env40367) = true)

theorem identity40367 : scanCanonicalize (H12AffineFastState.compose env40367 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound40367 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env40368 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3354,50,2074,318,262,2357,2075,1024,319,3339,32,16,2,50,17,2366,2357,3355,2075,1082,287,256,287,2341,513]

theorem envBound40368 : H12AffineFastState.Bounded env40368 := by
  intro p hp
  have h : env40368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40367_40368 : H12AffineEnvironment.transform 12 50 env40367 = env40368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env40367 == env40368) = true)

theorem identity40368 : scanCanonicalize (H12AffineFastState.compose env40368 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound40368 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40369 : List Nat := [2,4,8,16,32,16,8,63,512,1024,2048,3109,50,2074,1,57,2058,2075,1024,0,3124,32,16,2,50,17,2049,2058,3108,2075,1082,32,63,32,2074,513]

theorem envBound40369 : H12AffineFastState.Bounded env40369 := by
  intro p hp
  have h : env40369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40368_40369 : H12AffineEnvironment.transform 7 63 env40368 = env40369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env40368 == env40369) = true)

theorem identity40369 : scanCanonicalize (H12AffineFastState.compose env40369 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound40369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40370 : List Nat := [2,4,8,16,32,16,8,63,512,14,2048,2091,50,2074,1,57,2058,2075,14,0,2106,32,16,2,50,17,2049,2058,2090,2075,52,32,63,32,2074,513]

theorem envBound40370 : H12AffineFastState.Bounded env40370 := by
  intro p hp
  have h : env40370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40369_40370 : H12AffineEnvironment.transform 9 14 env40369 = env40370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env40369 == env40370) = true)

theorem identity40370 : scanCanonicalize (H12AffineFastState.compose env40370 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40370 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40371 : List Nat := [2,4,8,16,32,16,8,63,48,14,2048,2091,50,2074,1,57,2058,2075,14,0,2106,32,16,2,50,17,2049,2058,2090,2075,52,32,63,32,2074,49]

theorem envBound40371 : H12AffineFastState.Bounded env40371 := by
  intro p hp
  have h : env40371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40370_40371 : H12AffineEnvironment.transform 8 48 env40370 = env40371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40370 == env40371) = true)

theorem identity40371 : scanCanonicalize (H12AffineFastState.compose env40371 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound40371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40372 : List Nat := [2,4,8,16,32,16,8,63,48,14,16,59,50,10,1,57,26,11,14,0,42,32,16,2,50,17,17,26,58,11,52,32,63,32,10,49]

theorem envBound40372 : H12AffineFastState.Bounded env40372 := by
  intro p hp
  have h : env40372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40371_40372 : H12AffineEnvironment.transform 10 16 env40371 = env40372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env40371 == env40372) = true)

theorem identity40372 : scanCanonicalize (H12AffineFastState.compose env40372 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound40372 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40373 : List Nat := [2,4,8,16,26,16,8,5,10,14,16,1,8,10,1,3,26,11,14,0,16,26,16,2,8,17,17,26,0,11,14,26,5,26,10,11]

theorem envBound40373 : H12AffineFastState.Bounded env40373 := by
  intro p hp
  have h : env40373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40372_40373 : H12AffineEnvironment.transform 4 26 env40372 = env40373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env40372 == env40373) = true)

theorem identity40373 : scanCanonicalize (H12AffineFastState.compose env40373 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40373 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40374 : List Nat := [2,4,5,16,23,16,5,5,7,3,16,1,5,7,1,3,23,6,3,0,16,23,16,2,5,17,17,23,0,6,3,23,5,23,7,6]

theorem envBound40374 : H12AffineFastState.Bounded env40374 := by
  intro p hp
  have h : env40374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40373_40374 : H12AffineEnvironment.transform 2 5 env40373 = env40374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40373 == env40374) = true)

theorem identity40374 : scanCanonicalize (H12AffineFastState.compose env40374 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40374 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40375 : List Nat := [2,4,5,1,6,1,5,5,7,3,1,1,5,7,1,3,6,6,3,0,1,6,1,2,5,0,0,6,0,6,3,6,5,6,7,6]

theorem envBound40375 : H12AffineFastState.Bounded env40375 := by
  intro p hp
  have h : env40375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40374_40375 : H12AffineEnvironment.transform 3 1 env40374 = env40375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40374 == env40375) = true)

theorem identity40375 : scanCanonicalize (H12AffineFastState.compose env40375 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40376 : List Nat := [0,4,5,1,4,1,5,5,5,1,1,1,5,5,1,1,4,4,1,0,1,4,1,0,5,0,0,4,0,4,1,4,5,4,5,4]

theorem envBound40376 : H12AffineFastState.Bounded env40376 := by
  intro p hp
  have h : env40376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40375_40376 : H12AffineEnvironment.transform 0 0 env40375 = env40376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40375 == env40376) = true)

def env40377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,21762,8193,65,215367,115014,17665,35189,119042,243003,256,98678,90203,63068]

theorem envBound40377 : H12AffineFastState.Bounded env40377 := by
  intro p hp
  have h : env40377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40360_40377 : H12AffineEnvironment.transform 6 9 env40360 = env40377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40360 == env40377) = true)

theorem identity40377 : scanCanonicalize (H12AffineFastState.compose env40377 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound40377 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4161,21792,16,21762,8193,65,100694,115014,17665,35189,119042,95530,256,98678,90203,63068]

theorem envBound40378 : H12AffineFastState.Bounded env40378 := by
  intro p hp
  have h : env40378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40377_40378 : H12AffineEnvironment.transform 16 49169 env40377 = env40378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40377 == env40378) = true)

theorem identity40378 : scanCanonicalize (H12AffineFastState.compose env40378 (packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound40378 : packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21510,49169,35189,1024,32769,4161,21792,16,21762,8193,65,56656,38208,17665,35189,34052,8492,256,54640,13405,63068]

theorem envBound40379 : H12AffineFastState.Bounded env40379 := by
  intro p hp
  have h : env40379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40378_40379 : H12AffineEnvironment.transform 15 21510 env40378 = env40379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env40378 == env40379) = true)

theorem identity40379 : scanCanonicalize (H12AffineFastState.compose env40379 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound40379 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env40380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,21510,16740,2048,1024,372,4161,21792,16,21762,8193,65,23589,5173,17665,2048,1137,8492,256,21509,13405,30505]

theorem envBound40380 : H12AffineFastState.Bounded env40380 := by
  intro p hp
  have h : env40380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40379_40380 : H12AffineEnvironment.transform 14 373 env40379 = env40380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env40379 == env40380) = true)

theorem identity40380 : scanCanonicalize (H12AffineFastState.compose env40380 (packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound40380 : packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env40381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,373,34,5440,2048,1024,372,4161,260,16,294,8193,65,2049,5173,4389,2048,1137,8492,256,33,13405,8973]

theorem envBound40381 : H12AffineFastState.Bounded env40381 := by
  intro p hp
  have h : env40381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40380_40381 : H12AffineEnvironment.transform 13 5156 env40380 = env40381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env40380 == env40381) = true)

theorem identity40381 : scanCanonicalize (H12AffineFastState.compose env40381 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40381 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5156,373,34,5440,2048,1024,372,4161,260,16,294,269,65,2049,5173,4389,2048,1137,32,256,33,5457,513]

theorem envBound40382 : H12AffineFastState.Bounded env40382 := by
  intro p hp
  have h : env40382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40381_40382 : H12AffineEnvironment.transform 12 268 env40381 = env40382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40381 == env40382) = true)

theorem identity40382 : scanCanonicalize (H12AffineFastState.compose env40382 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40382 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40383 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5156,0,34,5173,2048,1024,1,4161,113,16,83,120,65,2049,5173,4176,2048,1137,32,117,33,5156,513]

theorem envBound40383 : H12AffineFastState.Bounded env40383 := by
  intro p hp
  have h : env40383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40382_40383 : H12AffineEnvironment.transform 7 117 env40382 = env40383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40382 == env40383) = true)

theorem identity40383 : scanCanonicalize (H12AffineFastState.compose env40383 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound40383 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env40384 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2048,121,3108,0,34,3125,2048,1024,1,2113,113,16,83,120,65,2049,3125,2128,2048,1137,32,117,33,3108,513]

theorem envBound40384 : H12AffineFastState.Bounded env40384 := by
  intro p hp
  have h : env40384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40383_40384 : H12AffineEnvironment.transform 11 2048 env40383 = env40384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env40383 == env40384) = true)

theorem identity40384 : scanCanonicalize (H12AffineFastState.compose env40384 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound40384 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env40385 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1093,1093,121,97,0,34,112,1093,1024,1,1028,113,16,83,120,65,1092,112,1045,1093,1137,32,117,33,97,513]

theorem envBound40385 : H12AffineFastState.Bounded env40385 := by
  intro p hp
  have h : env40385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40384_40385 : H12AffineEnvironment.transform 10 1093 env40384 = env40385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env40384 == env40385) = true)

theorem identity40385 : scanCanonicalize (H12AffineFastState.compose env40385 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound40385 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40386 : List Nat := [2,4,8,16,32,64,9,117,512,117,48,48,121,97,0,34,112,48,117,1,113,113,16,83,120,65,49,112,96,48,4,32,117,33,97,513]

theorem envBound40386 : H12AffineFastState.Bounded env40386 := by
  intro p hp
  have h : env40386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40385_40386 : H12AffineEnvironment.transform 9 117 env40385 = env40386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env40385 == env40386) = true)

theorem identity40386 : scanCanonicalize (H12AffineFastState.compose env40386 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound40386 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env40387 : List Nat := [2,4,8,16,32,0,9,53,512,53,48,48,57,33,0,34,48,48,53,1,49,49,16,19,56,1,49,48,32,48,4,32,53,33,33,513]

theorem envBound40387 : H12AffineFastState.Bounded env40387 := by
  intro p hp
  have h : env40387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40386_40387 : H12AffineEnvironment.transform 5 0 env40386 = env40387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40386 == env40387) = true)

theorem identity40387 : scanCanonicalize (H12AffineFastState.compose env40387 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40387 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40388 : List Nat := [2,4,8,0,32,0,9,37,512,37,32,32,41,33,0,34,32,32,37,1,33,33,0,3,40,1,33,32,32,32,4,32,37,33,33,513]

theorem envBound40388 : H12AffineFastState.Bounded env40388 := by
  intro p hp
  have h : env40388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40387_40388 : H12AffineEnvironment.transform 3 0 env40387 = env40388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40387 == env40388) = true)

theorem identity40388 : scanCanonicalize (H12AffineFastState.compose env40388 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40389 : List Nat := [2,4,8,0,0,0,9,5,512,5,0,0,9,1,0,2,0,0,5,1,1,1,0,3,8,1,1,0,0,0,4,0,5,1,1,513]

theorem envBound40389 : H12AffineFastState.Bounded env40389 := by
  intro p hp
  have h : env40389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40388_40389 : H12AffineEnvironment.transform 4 0 env40388 = env40389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40388 == env40389) = true)

def env40390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412020,2114883,8328,65,215366,115151,2497572,35189,2590759,2336242,256,510107,469311,2535408]

theorem envBound40390 : H12AffineFastState.Bounded env40390 := by
  intro p hp
  have h : env40390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40335_40390 : H12AffineEnvironment.transform 21 2262385 env40335 = env40390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env40335 == env40390) = true)

def env40391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,21763,8328,65,215366,115151,396388,35189,497767,243122,256,510107,469311,442288]

theorem envBound40391 : H12AffineFastState.Bounded env40391 := by
  intro p hp
  have h : env40391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40390_40391 : H12AffineEnvironment.transform 20 4160 env40390 = env40391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40390 == env40391) = true)

theorem identity40391 : scanCanonicalize (H12AffineFastState.compose env40391 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound40391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,169265,62661,21763,8328,65,215366,115151,45525,35189,75222,243122,256,95530,103566,513]

theorem envBound40392 : H12AffineFastState.Bounded env40392 := by
  intro p hp
  have h : env40392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40391_40392 : H12AffineEnvironment.transform 17 179633 env40391 = env40392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env40391 == env40392) = true)

def env40393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169265,62541,21763,8192,65,215366,115015,45405,35189,75102,243002,256,95530,103430,513]

theorem envBound40393 : H12AffineFastState.Bounded env40393 := by
  intro p hp
  have h : env40393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40392_40393 : H12AffineEnvironment.transform 6 8 env40392 = env40393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40392 == env40393) = true)

theorem identity40393 : scanCanonicalize (H12AffineFastState.compose env40393 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound40393 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env40394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,33,62541,21763,8192,65,121942,115015,45405,35189,75102,73770,256,95530,103430,513]

theorem envBound40394 : H12AffineFastState.Bounded env40394 := by
  intro p hp
  have h : env40394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40393_40394 : H12AffineEnvironment.transform 16 38160 env40393 = env40394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env40393 == env40394) = true)

theorem identity40394 : scanCanonicalize (H12AffineFastState.compose env40394 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound40394 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env40395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,13340,10281,1024,8461,4160,33,21825,21763,8192,65,97626,90187,4177,10361,75102,73770,256,95530,79114,513]

theorem envBound40395 : H12AffineFastState.Bounded env40395 := by
  intro p hp
  have h : env40395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40394_40395 : H12AffineEnvironment.transform 14 8460 env40394 = env40395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env40394 == env40395) = true)

theorem identity40395 : scanCanonicalize (H12AffineFastState.compose env40395 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound40395 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env40396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30043,13340,10281,1024,8461,4160,33,21825,21763,8192,65,2049,5392,4177,10361,20485,21873,256,113,16465,513]

theorem envBound40396 : H12AffineFastState.Bounded env40396 := by
  intro p hp
  have h : env40396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40395_40396 : H12AffineEnvironment.transform 15 30043 env40395 = env40396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env40395 == env40396) = true)

theorem identity40396 : scanCanonicalize (H12AffineFastState.compose env40396 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40396 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,0,21591,5392,2341,1024,1,4160,33,21825,21763,268,65,2049,5392,4177,2421,20485,21873,256,113,16465,513]

theorem envBound40397 : H12AffineFastState.Bounded env40397 := by
  intro p hp
  have h : env40397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40396_40397 : H12AffineEnvironment.transform 12 268 env40396 = env40397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40396 == env40397) = true)

theorem identity40397 : scanCanonicalize (H12AffineFastState.compose env40397 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40397 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,0,343,5392,2341,1024,1,4160,33,65,3,268,65,2049,5392,4177,2421,1285,113,256,113,5457,513]

theorem envBound40398 : H12AffineFastState.Bounded env40398 := by
  intro p hp
  have h : env40398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40397_40398 : H12AffineEnvironment.transform 13 5376 env40397 = env40398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40397 == env40398) = true)

theorem identity40398 : scanCanonicalize (H12AffineFastState.compose env40398 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40398 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40399 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4112,33,17,3,268,17,2049,5392,4097,2341,1285,33,256,33,5377,513]

theorem envBound40399 : H12AffineFastState.Bounded env40399 := by
  intro p hp
  have h : env40399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40398_40399 : H12AffineEnvironment.transform 5 16 env40398 = env40399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40398 == env40399) = true)

theorem identity40399 : scanCanonicalize (H12AffineFastState.compose env40399 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound40399 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40400 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,0,268,1280,0,263,1296,2341,1024,1,16,33,17,3,268,17,2049,1296,1,2341,1285,33,256,33,1281,513]

theorem envBound40400 : H12AffineFastState.Bounded env40400 := by
  intro p hp
  have h : env40400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40399_40400 : H12AffineEnvironment.transform 11 0 env40399 = env40400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env40399 == env40400) = true)

theorem identity40400 : scanCanonicalize (H12AffineFastState.compose env40400 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound40400 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40401 : List Nat := [2,4,8,16,32,16,8,256,512,1024,318,0,268,1280,0,263,1296,27,1024,1,16,33,17,3,268,17,319,1296,1,27,1285,33,256,33,1281,513]

theorem envBound40401 : H12AffineFastState.Bounded env40401 := by
  intro p hp
  have h : env40401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40400_40401 : H12AffineEnvironment.transform 10 318 env40400 = env40401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env40400 == env40401) = true)

theorem identity40401 : scanCanonicalize (H12AffineFastState.compose env40401 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound40401 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40402 : List Nat := [2,4,8,16,32,16,8,256,512,20,318,0,268,276,0,263,260,27,20,1,16,33,17,3,268,17,319,260,1,27,273,33,256,33,277,513]

theorem envBound40402 : H12AffineFastState.Bounded env40402 := by
  intro p hp
  have h : env40402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40401_40402 : H12AffineEnvironment.transform 9 20 env40401 = env40402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40401 == env40402) = true)

theorem identity40402 : scanCanonicalize (H12AffineFastState.compose env40402 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40402 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40403 : List Nat := [2,4,8,16,32,16,8,52,512,20,10,0,56,32,0,51,48,27,20,1,16,33,17,3,56,17,11,48,1,27,37,33,52,33,33,513]

theorem envBound40403 : H12AffineFastState.Bounded env40403 := by
  intro p hp
  have h : env40403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40402_40403 : H12AffineEnvironment.transform 7 52 env40402 = env40403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40402 == env40403) = true)

theorem identity40403 : scanCanonicalize (H12AffineFastState.compose env40403 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound40403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40404 : List Nat := [2,4,8,16,27,16,8,15,512,20,10,0,3,27,0,8,11,27,20,1,16,26,17,3,3,17,11,11,1,27,30,26,15,26,26,513]

theorem envBound40404 : H12AffineFastState.Bounded env40404 := by
  intro p hp
  have h : env40404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40403_40404 : H12AffineEnvironment.transform 4 27 env40403 = env40404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env40403 == env40404) = true)

theorem identity40404 : scanCanonicalize (H12AffineFastState.compose env40404 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40404 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40405 : List Nat := [2,4,2,16,17,16,2,5,512,20,0,0,3,17,0,2,1,17,20,1,16,16,17,3,3,17,1,1,1,17,20,16,5,16,16,513]

theorem envBound40405 : H12AffineFastState.Bounded env40405 := by
  intro p hp
  have h : env40405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40404_40405 : H12AffineEnvironment.transform 2 2 env40404 = env40405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40404 == env40405) = true)

theorem identity40405 : scanCanonicalize (H12AffineFastState.compose env40405 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40406 : List Nat := [1,4,1,16,17,16,1,5,512,20,0,0,0,17,0,1,1,17,20,1,16,16,17,0,0,17,1,1,1,17,20,16,5,16,16,513]

theorem envBound40406 : H12AffineFastState.Bounded env40406 := by
  intro p hp
  have h : env40406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40405_40406 : H12AffineEnvironment.transform 0 1 env40405 = env40406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40405 == env40406) = true)

theorem identity40406 : scanCanonicalize (H12AffineFastState.compose env40406 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40406 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env40407 : List Nat := [1,4,1,1,0,1,1,5,512,5,0,0,0,0,0,1,1,0,5,1,1,1,0,0,0,0,1,1,1,0,5,1,5,1,1,513]

theorem envBound40407 : H12AffineFastState.Bounded env40407 := by
  intro p hp
  have h : env40407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40406_40407 : H12AffineEnvironment.transform 3 1 env40406 = env40407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40406 == env40407) = true)

theorem identity40407 : scanCanonicalize (H12AffineFastState.compose env40407 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound40407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40408 : List Nat := [1,4,1,1,0,1,1,5,4,5,0,0,0,0,0,1,1,0,5,1,1,1,0,0,0,0,1,1,1,0,5,1,5,1,1,5]

theorem envBound40408 : H12AffineFastState.Bounded env40408 := by
  intro p hp
  have h : env40408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40407_40408 : H12AffineEnvironment.transform 8 4 env40407 = env40408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env40407 == env40408) = true)

def env40409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169265,62540,21763,8193,65,215366,115014,45404,35189,75103,243003,256,95530,103431,513]

theorem envBound40409 : H12AffineFastState.Bounded env40409 := by
  intro p hp
  have h : env40409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40392_40409 : H12AffineEnvironment.transform 6 9 env40392 = env40409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40392 == env40409) = true)

theorem identity40409 : scanCanonicalize (H12AffineFastState.compose env40409 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40409 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4160,128299,62540,21763,8193,65,10588,115014,45404,35189,75103,54561,256,95530,103431,513]

theorem envBound40410 : H12AffineFastState.Bounded env40410 := by
  intro p hp
  have h : env40410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40409_40410 : H12AffineEnvironment.transform 16 90138 env40409 = env40410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40409 == env40410) = true)

theorem identity40410 : scanCanonicalize (H12AffineFastState.compose env40410 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 34146) := by decide +kernel

theorem selectedBound40410 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env40411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,34146,58744,22592,1024,32769,4160,28745,62540,21763,8193,65,10588,17444,45404,35189,41021,54561,256,61512,4453,513]

theorem envBound40411 : H12AffineFastState.Bounded env40411 := by
  intro p hp
  have h : env40411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40410_40411 : H12AffineEnvironment.transform 15 34146 env40410 = env40411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34146 env40410 == env40411) = true)

theorem identity40411 : scanCanonicalize (H12AffineFastState.compose env40411 (packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound40411 : packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS < 2^1333 := by decide +kernel

def env40412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21540,20806,12636,22592,1024,21541,4160,28745,8296,21763,8193,65,10588,17444,25976,23889,29721,261,256,9324,4453,513]

theorem envBound40412 : H12AffineFastState.Bounded env40412 := by
  intro p hp
  have h : env40412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40411_40412 : H12AffineEnvironment.transform 14 21540 env40411 = env40412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env40411 == env40412) = true)

theorem identity40412 : scanCanonicalize (H12AffineFastState.compose env40412 (packedSelected [0,1,2,4,5,6,7,8,9,12,14,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40412 : packedSelected [0,1,2,4,5,6,7,8,9,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env40413 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,293,1095,12636,3393,1024,292,4160,9544,8296,2,8193,65,10588,4389,12409,2128,8472,261,256,9324,4453,513]

theorem envBound40413 : H12AffineFastState.Bounded env40413 := by
  intro p hp
  have h : env40413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40412_40413 : H12AffineEnvironment.transform 13 5377 env40412 = env40413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40412 == env40413) = true)

theorem identity40413 : scanCanonicalize (H12AffineFastState.compose env40413 (packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7545) := by decide +kernel

theorem selectedBound40413 : packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env40414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,5377,293,1095,3109,3393,1024,292,4160,6193,7441,2,7544,65,5157,4389,3328,2128,7265,261,256,6421,4453,513]

theorem envBound40414 : H12AffineFastState.Bounded env40414 := by
  intro p hp
  have h : env40414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40413_40414 : H12AffineEnvironment.transform 12 7545 env40413 = env40414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7545 env40413 == env40414) = true)

theorem identity40414 : scanCanonicalize (H12AffineFastState.compose env40414 (packedSelected [3,5,10,11,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40414 : packedSelected [3,5,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env40415 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7464,5377,293,1046,3109,3344,1024,292,4113,6193,7441,2,7465,16,5157,4389,3328,2049,7216,261,256,6421,4404,513]

theorem envBound40415 : H12AffineFastState.Bounded env40415 := by
  intro p hp
  have h : env40415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40414_40415 : H12AffineEnvironment.transform 5 17 env40414 = env40415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40414 == env40415) = true)

theorem identity40415 : scanCanonicalize (H12AffineFastState.compose env40415 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40415 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40416 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,4096,5417,5377,293,1046,1060,1297,1024,292,4113,4144,5392,2,5416,16,5157,4389,1281,0,5169,261,256,4372,4404,513]

theorem envBound40416 : H12AffineFastState.Bounded env40416 := by
  intro p hp
  have h : env40416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40415_40416 : H12AffineEnvironment.transform 10 1 env40415 = env40416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40415 == env40416) = true)

theorem identity40416 : scanCanonicalize (H12AffineFastState.compose env40416 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40416 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env40417 : List Nat := [2,4,8,16,32,17,9,256,512,53,1,4096,4380,4404,293,35,17,292,53,292,4113,4144,4389,2,4381,16,4112,4389,308,0,4100,261,256,4372,4404,513]

theorem envBound40417 : H12AffineFastState.Bounded env40417 := by
  intro p hp
  have h : env40417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40416_40417 : H12AffineEnvironment.transform 9 53 env40416 = env40417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40416 == env40417) = true)

theorem identity40417 : scanCanonicalize (H12AffineFastState.compose env40417 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound40417 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40418 : List Nat := [2,4,8,16,32,17,9,256,512,53,1,308,40,0,293,35,17,292,53,292,293,260,17,2,41,16,292,17,308,0,304,261,256,32,0,513]

theorem envBound40418 : H12AffineFastState.Bounded env40418 := by
  intro p hp
  have h : env40418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40417_40418 : H12AffineEnvironment.transform 11 308 env40417 = env40418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env40417 == env40418) = true)

theorem identity40418 : scanCanonicalize (H12AffineFastState.compose env40418 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40419 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,17,40,0,0,35,17,1,53,1,0,33,17,2,41,16,1,17,17,0,21,32,37,32,0,513]

theorem envBound40419 : H12AffineFastState.Bounded env40419 := by
  intro p hp
  have h : env40419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40418_40419 : H12AffineEnvironment.transform 7 37 env40418 = env40419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40418 == env40419) = true)

theorem identity40419 : scanCanonicalize (H12AffineFastState.compose env40419 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound40419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40420 : List Nat := [2,4,8,16,32,17,9,37,16,53,1,17,40,0,0,35,17,1,53,1,0,33,17,2,41,16,1,17,17,0,21,32,37,32,0,17]

theorem envBound40420 : H12AffineFastState.Bounded env40420 := by
  intro p hp
  have h : env40420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40419_40420 : H12AffineEnvironment.transform 8 16 env40419 = env40420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env40419 == env40420) = true)

theorem identity40420 : scanCanonicalize (H12AffineFastState.compose env40420 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40421 : List Nat := [2,4,8,11,32,10,9,37,11,46,1,10,40,0,0,35,10,1,46,1,0,33,10,2,41,11,1,10,10,0,14,32,37,32,0,10]

theorem envBound40421 : H12AffineFastState.Bounded env40421 := by
  intro p hp
  have h : env40421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40420_40421 : H12AffineEnvironment.transform 3 11 env40420 = env40421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40420 == env40421) = true)

def env40422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,21762,8328,65,215366,115151,396389,35189,497766,243123,256,510107,469311,442289]

theorem envBound40422 : H12AffineFastState.Bounded env40422 := by
  intro p hp
  have h : env40422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40390_40422 : H12AffineEnvironment.transform 20 4161 env40390 = env40422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40390 == env40422) = true)

def env40423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169264,155996,21762,8328,65,215366,115151,140365,35189,241742,243123,256,254131,196887,169881]

theorem envBound40423 : H12AffineFastState.Bounded env40423 := by
  intro p hp
  have h : env40423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40422_40423 : H12AffineEnvironment.transform 17 10280 env40422 = env40423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40422 == env40423) = true)

def env40424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21792,41292,21762,8328,65,100694,115151,58461,35189,94302,95651,256,73891,114951,22409]

theorem envBound40424 : H12AffineFastState.Bounded env40424 := by
  intro p hp
  have h : env40424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40423_40424 : H12AffineEnvironment.transform 16 49168 env40423 = env40424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40423 == env40424) = true)

theorem identity40424 : scanCanonicalize (H12AffineFastState.compose env40424 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40424 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10280,1024,8540,4161,21792,17,21762,8328,65,75787,90258,17664,10280,94302,95651,256,73891,90202,22409]

theorem envBound40425 : H12AffineFastState.Bounded env40425 := by
  intro p hp
  have h : env40425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40424_40425 : H12AffineEnvironment.transform 14 8541 env40424 = env40425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40424 == env40425) = true)

theorem identity40425 : scanCanonicalize (H12AffineFastState.compose env40425 (packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound40425 : packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,16384,1260,65536,17660,3481,1024,1261,4161,21792,17,21762,1337,65,69050,83235,17664,3481,87535,86034,256,66834,83435,22409]

theorem envBound40426 : H12AffineFastState.Bounded env40426 := by
  intro p hp
  have h : env40426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40425_40426 : H12AffineEnvironment.transform 12 1457 env40425 = env40426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env40425 == env40426) = true)

theorem identity40426 : scanCanonicalize (H12AffineFastState.compose env40426 (packedSelected [1,3,5,8,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40426 : packedSelected [1,3,5,8,14,16] rootPS < 2^1333 := by decide +kernel

def env40427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,16384,1125,65536,17525,3344,1024,1124,4161,21792,17,21762,1337,65,68915,83235,17664,3344,87398,86034,256,66834,83298,22272]

theorem envBound40427 : H12AffineFastState.Bounded env40427 := by
  intro p hp
  have h : env40427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40426_40427 : H12AffineEnvironment.transform 6 9 env40426 = env40427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40426 == env40427) = true)

theorem identity40427 : scanCanonicalize (H12AffineFastState.compose env40427 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound40427 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,16384,1125,1331,17525,3344,1024,1124,4161,21792,17,21762,1337,65,2048,16400,17664,3344,20565,21793,256,33,16465,22272]

theorem envBound40428 : H12AffineFastState.Bounded env40428 := by
  intro p hp
  have h : env40428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40427_40428 : H12AffineEnvironment.transform 15 1331 env40427 = env40428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env40427 == env40428) = true)

theorem identity40428 : scanCanonicalize (H12AffineFastState.compose env40428 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound40428 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env40429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4404,1125,1331,5441,3344,1024,1124,4161,1044,17,1078,1337,65,2048,4388,5172,3344,353,1045,256,33,4453,1588]

theorem envBound40429 : H12AffineFastState.Bounded env40429 := by
  intro p hp
  have h : env40429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40428_40429 : H12AffineEnvironment.transform 13 4404 env40428 = env40429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env40428 == env40429) = true)

theorem identity40429 : scanCanonicalize (H12AffineFastState.compose env40429 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40429 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40430 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1053,4113,1125,1046,5220,3125,1024,1124,4161,1044,17,1078,1052,65,2048,4097,5172,3125,68,1045,37,33,4160,1588]

theorem envBound40430 : H12AffineFastState.Bounded env40430 := by
  intro p hp
  have h : env40430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40429_40430 : H12AffineEnvironment.transform 7 37 env40429 = env40430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40429 == env40430) = true)

theorem identity40430 : scanCanonicalize (H12AffineFastState.compose env40430 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound40430 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40431 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,4096,121,4113,1,114,4096,2129,100,0,4161,112,17,82,120,65,2048,4097,4176,2129,68,113,37,33,4160,592]

theorem envBound40431 : H12AffineFastState.Bounded env40431 := by
  intro p hp
  have h : env40431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40430_40431 : H12AffineEnvironment.transform 9 100 env40430 = env40431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env40430 == env40431) = true)

theorem identity40431 : scanCanonicalize (H12AffineFastState.compose env40431 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40431 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env40432 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,40,4113,1,35,4096,2048,53,0,4112,33,17,3,41,16,2048,4097,4097,2048,21,32,37,33,4113,513]

theorem envBound40432 : H12AffineFastState.Bounded env40432 := by
  intro p hp
  have h : env40432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40431_40432 : H12AffineEnvironment.transform 5 17 env40431 = env40432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40431 == env40432) = true)

theorem identity40432 : scanCanonicalize (H12AffineFastState.compose env40432 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound40432 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40433 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2561,40,2576,1,35,2561,2048,53,0,2577,33,17,3,41,16,2048,2560,2560,2048,21,32,37,33,2576,513]

theorem envBound40433 : H12AffineFastState.Bounded env40433 := by
  intro p hp
  have h : env40433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40432_40433 : H12AffineEnvironment.transform 11 2561 env40432 = env40433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env40432 == env40433) = true)

theorem identity40433 : scanCanonicalize (H12AffineFastState.compose env40433 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound40433 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40434 : List Nat := [2,4,8,16,32,17,9,37,512,53,554,43,40,58,1,35,43,554,53,0,59,33,17,3,41,16,554,42,42,554,21,32,37,33,58,513]

theorem envBound40434 : H12AffineFastState.Bounded env40434 := by
  intro p hp
  have h : env40434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40433_40434 : H12AffineEnvironment.transform 10 554 env40433 = env40434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env40433 == env40434) = true)

def env40435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21793,41293,21762,8328,65,100695,115151,58460,35189,94303,95650,256,73890,114950,22408]

theorem envBound40435 : H12AffineFastState.Bounded env40435 := by
  intro p hp
  have h : env40435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40423_40435 : H12AffineEnvironment.transform 16 49169 env40423 = env40435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40423 == env40435) = true)

theorem identity40435 : scanCanonicalize (H12AffineFastState.compose env40435 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound40435 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1024,8661,4161,21793,153,21762,8328,65,75907,90139,17800,10401,94303,95650,256,73890,90322,22408]

theorem envBound40436 : H12AffineFastState.Bounded env40436 := by
  intro p hp
  have h : env40436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40435_40436 : H12AffineEnvironment.transform 14 8660 env40435 = env40436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env40435 == env40436) = true)

theorem identity40436 : scanCanonicalize (H12AffineFastState.compose env40436 (packedSelected [2,4,6,11,19,20,22,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 22010) := by decide +kernel

theorem selectedBound40436 : packedSelected [2,4,6,11,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env40437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,22010,25029,10280,1024,8661,4161,21793,153,21762,8328,65,32121,13793,17800,10401,9637,8280,256,30040,13608,22408]

theorem envBound40437 : H12AffineFastState.Bounded env40437 := by
  intro p hp
  have h : env40437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40436_40437 : H12AffineEnvironment.transform 15 22010 env40436 = env40437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 22010 env40436 == env40437) = true)

theorem identity40437 : scanCanonicalize (H12AffineFastState.compose env40437 (packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40437 : packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,23,27] rootPS < 2^1333 := by decide +kernel

def env40438 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8432,21726,24801,10280,1024,8433,4161,21509,153,21542,8328,65,31837,13509,17580,10401,9345,8280,36,29820,13324,22188]

theorem envBound40438 : H12AffineFastState.Bounded env40438 := by
  intro p hp
  have h : env40438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40437_40438 : H12AffineEnvironment.transform 7 36 env40437 = env40438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40437 == env40438) = true)

theorem identity40438 : scanCanonicalize (H12AffineFastState.compose env40438 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound40438 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40439 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5157,8432,251,13508,10280,1024,8433,4161,32,153,3,8328,65,10360,13509,4233,10401,9345,8280,36,8281,13324,649]

theorem envBound40439 : H12AffineFastState.Bounded env40439 := by
  intro p hp
  have h : env40439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40438_40439 : H12AffineEnvironment.transform 13 5157 env40438 = env40439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env40438 == env40439) = true)

theorem identity40439 : scanCanonicalize (H12AffineFastState.compose env40439 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40439 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40440 : List Nat := [2,4,8,16,32,64,128,36,512,52,2048,4096,8192,4113,8432,251,12528,10280,52,8433,4161,32,153,3,8328,65,10360,12529,4233,10401,8373,8280,36,8281,12344,649]

theorem envBound40440 : H12AffineFastState.Bounded env40440 := by
  intro p hp
  have h : env40440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40439_40440 : H12AffineEnvironment.transform 9 52 env40439 = env40440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40439 == env40440) = true)

theorem identity40440 : scanCanonicalize (H12AffineFastState.compose env40440 (packedSelected [4,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound40440 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env40441 : List Nat := [2,4,8,16,32,64,128,36,512,52,136,4096,8192,4113,8432,251,12528,8352,52,8433,4161,32,153,3,8328,65,8432,12529,4233,8233,8373,8280,36,8281,12344,649]

theorem envBound40441 : H12AffineFastState.Bounded env40441 := by
  intro p hp
  have h : env40441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40440_40441 : H12AffineEnvironment.transform 10 136 env40440 = env40441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env40440 == env40441) = true)

theorem identity40441 : scanCanonicalize (H12AffineFastState.compose env40441 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound40441 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env40442 : List Nat := [2,4,8,16,32,64,128,36,512,52,136,65,8192,80,8432,251,8369,8352,52,8433,0,32,153,3,8328,65,8432,8368,200,8233,8373,8280,36,8281,8313,649]

theorem envBound40442 : H12AffineFastState.Bounded env40442 := by
  intro p hp
  have h : env40442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40441_40442 : H12AffineEnvironment.transform 11 65 env40441 = env40442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env40441 == env40442) = true)

theorem identity40442 : scanCanonicalize (H12AffineFastState.compose env40442 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40442 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env40443 : List Nat := [2,4,8,16,32,64,8,36,512,52,0,65,8192,80,8312,115,8249,8232,52,8313,0,32,17,3,8192,65,8312,8248,64,8233,8253,8280,36,8281,8313,513]

theorem envBound40443 : H12AffineFastState.Bounded env40443 := by
  intro p hp
  have h : env40443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40442_40443 : H12AffineEnvironment.transform 6 8 env40442 = env40443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40442 == env40443) = true)

theorem identity40443 : scanCanonicalize (H12AffineFastState.compose env40443 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound40443 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env40444 : List Nat := [2,4,8,16,32,64,8,36,512,52,0,65,120,80,0,115,65,80,52,1,0,32,17,3,120,65,0,64,64,81,69,32,36,33,1,513]

theorem envBound40444 : H12AffineFastState.Bounded env40444 := by
  intro p hp
  have h : env40444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40443_40444 : H12AffineEnvironment.transform 12 120 env40443 = env40444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env40443 == env40444) = true)

def env40445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169264,155997,21762,8328,65,215366,115151,140364,35189,241743,243123,256,254130,196886,169880]

theorem envBound40445 : H12AffineFastState.Bounded env40445 := by
  intro p hp
  have h : env40445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40422_40445 : H12AffineEnvironment.transform 17 10281 env40422 = env40445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40422 == env40445) = true)

def env40446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21792,41293,21762,8328,65,100694,115151,58460,35189,94303,95651,256,73890,114950,22408]

theorem envBound40446 : H12AffineFastState.Bounded env40446 := by
  intro p hp
  have h : env40446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40445_40446 : H12AffineEnvironment.transform 16 49168 env40445 = env40446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40445 == env40446) = true)

theorem identity40446 : scanCanonicalize (H12AffineFastState.compose env40446 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40446 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21792,41293,21762,8192,65,100694,115015,58460,35189,94303,95531,256,73770,114950,22272]

theorem envBound40447 : H12AffineFastState.Bounded env40447 := by
  intro p hp
  have h : env40447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40446_40447 : H12AffineEnvironment.transform 6 8 env40446 = env40447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40446 == env40447) = true)

theorem identity40447 : scanCanonicalize (H12AffineFastState.compose env40447 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40447 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10281,1024,8541,4161,21792,17,21762,8192,65,75786,90139,17664,10281,94303,95531,256,73770,90202,22272]

theorem envBound40448 : H12AffineFastState.Bounded env40448 := by
  intro p hp
  have h : env40448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40447_40448 : H12AffineEnvironment.transform 14 8540 env40447 = env40448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40447 == env40448) = true)

theorem identity40448 : scanCanonicalize (H12AffineFastState.compose env40448 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40448 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,65536,5393,10281,1024,8541,4161,8573,17,8543,8192,65,75786,70726,12637,10281,66562,65910,256,73770,70663,9053]

theorem envBound40449 : H12AffineFastState.Bounded env40449 := by
  intro p hp
  have h : env40449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40448_40449 : H12AffineEnvironment.transform 13 13405 env40448 = env40449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40448 == env40449) = true)

theorem identity40449 : scanCanonicalize (H12AffineFastState.compose env40449 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40449 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,5393,2421,1024,1,4161,33,17,3,348,65,67926,70726,4097,2421,66562,65910,256,65910,70663,513]

theorem envBound40450 : H12AffineFastState.Bounded env40450 := by
  intro p hp
  have h : env40450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40449_40450 : H12AffineEnvironment.transform 12 348 env40449 = env40450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40449 == env40450) = true)

theorem identity40450 : scanCanonicalize (H12AffineFastState.compose env40450 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound40450 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env40451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5393,2421,1024,1,4161,33,17,3,348,65,2049,5393,4097,2421,1365,33,256,33,5456,513]

theorem envBound40451 : H12AffineFastState.Bounded env40451 := by
  intro p hp
  have h : env40451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40450_40451 : H12AffineEnvironment.transform 15 343 env40450 = env40451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env40450 == env40451) = true)

theorem identity40451 : scanCanonicalize (H12AffineFastState.compose env40451 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2366) := by decide +kernel

theorem selectedBound40451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2366,348,3135,0,343,3119,2421,1024,1,2431,33,17,3,348,65,2049,3119,2367,2421,1365,33,256,33,3182,513]

theorem envBound40452 : H12AffineFastState.Bounded env40452 := by
  intro p hp
  have h : env40452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40451_40452 : H12AffineEnvironment.transform 11 2366 env40451 = env40452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2366 env40451 == env40452) = true)

theorem identity40452 : scanCanonicalize (H12AffineFastState.compose env40452 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound40452 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40453 : List Nat := [2,4,8,16,32,64,8,256,512,126,2048,2366,348,2113,0,343,2129,2421,126,1,2431,33,17,3,348,65,2049,2129,2367,2421,299,33,256,33,2064,513]

theorem envBound40453 : H12AffineFastState.Bounded env40453 := by
  intro p hp
  have h : env40453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40452_40453 : H12AffineEnvironment.transform 9 126 env40452 = env40453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env40452 == env40453) = true)

theorem identity40453 : scanCanonicalize (H12AffineFastState.compose env40453 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40453 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40454 : List Nat := [2,4,8,16,32,64,8,37,512,126,2048,2075,121,2113,0,114,2129,2128,126,1,2138,33,17,3,121,65,2049,2129,2074,2128,14,33,37,33,2064,513]

theorem envBound40454 : H12AffineFastState.Bounded env40454 := by
  intro p hp
  have h : env40454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40453_40454 : H12AffineEnvironment.transform 7 37 env40453 = env40454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40453 == env40454) = true)

theorem identity40454 : scanCanonicalize (H12AffineFastState.compose env40454 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound40454 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40455 : List Nat := [2,4,8,16,32,64,8,37,512,126,16,11,121,81,0,114,65,64,126,1,74,33,17,3,121,65,17,65,10,64,14,33,37,33,0,513]

theorem envBound40455 : H12AffineFastState.Bounded env40455 := by
  intro p hp
  have h : env40455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40454_40455 : H12AffineEnvironment.transform 10 16 env40454 = env40455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env40454 == env40455) = true)

theorem identity40455 : scanCanonicalize (H12AffineFastState.compose env40455 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound40455 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40456 : List Nat := [2,4,8,16,32,43,8,37,512,21,16,11,18,58,0,25,42,43,21,1,33,33,17,3,18,42,17,42,10,43,14,33,37,33,0,513]

theorem envBound40456 : H12AffineFastState.Bounded env40456 := by
  intro p hp
  have h : env40456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40455_40456 : H12AffineEnvironment.transform 5 43 env40455 = env40456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env40455 == env40456) = true)

def env40457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21793,41292,21762,8328,65,100695,115151,58461,35189,94302,95650,256,73891,114951,22409]

theorem envBound40457 : H12AffineFastState.Bounded env40457 := by
  intro p hp
  have h : env40457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40445_40457 : H12AffineEnvironment.transform 16 49169 env40445 = env40457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40445 == env40457) = true)

theorem identity40457 : scanCanonicalize (H12AffineFastState.compose env40457 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound40457 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21511,49169,10281,1024,32769,4161,21793,41292,21762,8328,65,56656,38344,58461,35189,9305,8613,256,29860,38144,22409]

theorem envBound40458 : H12AffineFastState.Bounded env40458 := by
  intro p hp
  have h : env40458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40457_40458 : H12AffineEnvironment.transform 15 21511 env40457 = env40458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env40457 == env40458) = true)

theorem identity40458 : scanCanonicalize (H12AffineFastState.compose env40458 (packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound40458 : packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS < 2^1333 := by decide +kernel

def env40459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,21511,16536,10281,1024,136,4161,21793,8645,21762,8328,65,24025,5441,25812,2556,9305,8613,256,29860,5513,22409]

theorem envBound40459 : H12AffineFastState.Bounded env40459 := by
  intro p hp
  have h : env40459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40458_40459 : H12AffineEnvironment.transform 14 137 env40458 = env40459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env40458 == env40459) = true)

theorem identity40459 : scanCanonicalize (H12AffineFastState.compose env40459 (packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound40459 : packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env40460 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,80,21511,16449,10281,1024,81,4161,21793,8476,21762,8273,65,23808,5441,25613,2341,9305,8572,256,29821,5456,22352]

theorem envBound40460 : H12AffineFastState.Bounded env40460 := by
  intro p hp
  have h : env40460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40459_40460 : H12AffineEnvironment.transform 6 89 env40459 = env40460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env40459 == env40460) = true)

theorem identity40460 : scanCanonicalize (H12AffineFastState.compose env40460 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40460 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env40461 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,16384,80,21511,16449,2341,1024,81,4161,21793,16,21762,349,65,23808,5441,17665,2341,1365,112,256,21873,5456,22352]

theorem envBound40461 : H12AffineFastState.Bounded env40461 := by
  intro p hp
  have h : env40461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40460_40461 : H12AffineEnvironment.transform 12 268 env40460 = env40461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40460 == env40461) = true)

theorem identity40461 : scanCanonicalize (H12AffineFastState.compose env40461 (packedSelected [0,7,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound40461 : packedSelected [0,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env40462 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5236,80,115,5173,2341,1024,81,4161,341,16,374,349,65,2420,5441,4469,2341,1365,112,256,261,5456,804]

theorem envBound40462 : H12AffineFastState.Bounded env40462 := by
  intro p hp
  have h : env40462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40461_40462 : H12AffineEnvironment.transform 13 5236 env40461 = env40462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env40461 == env40462) = true)

theorem identity40462 : scanCanonicalize (H12AffineFastState.compose env40462 (packedSelected [0,7,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40462 : packedSelected [0,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env40463 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,1,34,5173,2341,1024,0,4112,260,16,295,268,16,2341,5392,4388,2341,1284,33,256,261,5377,804]

theorem envBound40463 : H12AffineFastState.Bounded env40463 := by
  intro p hp
  have h : env40463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40462_40463 : H12AffineEnvironment.transform 5 17 env40462 = env40463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40462 == env40463) = true)

theorem identity40463 : scanCanonicalize (H12AffineFastState.compose env40463 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40463 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40464 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5125,1,2,5141,2309,1024,0,4112,260,16,263,268,16,2309,5392,4356,2309,1284,1,256,261,5377,772]

theorem envBound40464 : H12AffineFastState.Bounded env40464 := by
  intro p hp
  have h : env40464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40463_40464 : H12AffineEnvironment.transform 4 0 env40463 = env40464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40463 == env40464) = true)

theorem identity40464 : scanCanonicalize (H12AffineFastState.compose env40464 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40464 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40465 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,8,5125,1,2,5141,2049,1024,0,4112,0,16,3,8,16,2049,5140,4096,2049,1024,1,4,1,5125,512]

theorem envBound40465 : H12AffineFastState.Bounded env40465 := by
  intro p hp
  have h : env40465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40464_40465 : H12AffineEnvironment.transform 7 4 env40464 = env40465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40464 == env40465) = true)

theorem identity40465 : scanCanonicalize (H12AffineFastState.compose env40465 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40466 : List Nat := [2,4,8,0,0,1,8,4,512,1024,2048,4096,8,5125,1,2,5125,2049,1024,0,4096,0,0,3,8,0,2049,5124,4096,2049,1024,1,4,1,5125,512]

theorem envBound40466 : H12AffineFastState.Bounded env40466 := by
  intro p hp
  have h : env40466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40465_40466 : H12AffineEnvironment.transform 3 0 env40465 = env40466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40465 == env40466) = true)

theorem identity40466 : scanCanonicalize (H12AffineFastState.compose env40466 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3086) := by decide +kernel

theorem selectedBound40466 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40467 : List Nat := [2,4,8,0,0,1,8,4,512,1024,2048,3086,8,2059,1,2,2059,2049,1024,0,3086,0,0,3,8,0,2049,2058,3086,2049,1024,1,4,1,2059,512]

theorem envBound40467 : H12AffineFastState.Bounded env40467 := by
  intro p hp
  have h : env40467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40466_40467 : H12AffineEnvironment.transform 11 3086 env40466 = env40467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3086 env40466 == env40467) = true)

theorem identity40467 : scanCanonicalize (H12AffineFastState.compose env40467 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40467 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40468 : List Nat := [2,4,3,0,0,1,3,4,512,1024,2048,3077,3,2048,1,2,2048,2049,1024,0,3077,0,0,3,3,0,2049,2049,3077,2049,1024,1,4,1,2048,512]

theorem envBound40468 : H12AffineFastState.Bounded env40468 := by
  intro p hp
  have h : env40468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40467_40468 : H12AffineEnvironment.transform 2 3 env40467 = env40468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40467 == env40468) = true)

theorem identity40468 : scanCanonicalize (H12AffineFastState.compose env40468 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40468 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40469 : List Nat := [2,4,3,0,0,1,3,4,512,4,2048,2049,3,2048,1,2,2048,2049,4,0,2049,0,0,3,3,0,2049,2049,2049,2049,4,1,4,1,2048,512]

theorem envBound40469 : H12AffineFastState.Bounded env40469 := by
  intro p hp
  have h : env40469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40468_40469 : H12AffineEnvironment.transform 9 4 env40468 = env40469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40468 == env40469) = true)

theorem identity40469 : scanCanonicalize (H12AffineFastState.compose env40469 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40469 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40470 : List Nat := [2,0,3,0,0,1,3,0,512,0,2048,2049,3,2048,1,2,2048,2049,0,0,2049,0,0,3,3,0,2049,2049,2049,2049,0,1,0,1,2048,512]

theorem envBound40470 : H12AffineFastState.Bounded env40470 := by
  intro p hp
  have h : env40470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40469_40470 : H12AffineEnvironment.transform 1 0 env40469 = env40470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40469 == env40470) = true)

theorem identity40470 : scanCanonicalize (H12AffineFastState.compose env40470 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound40470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40471 : List Nat := [2,0,3,0,0,1,3,0,512,0,2,3,3,2,1,2,2,3,0,0,3,0,0,3,3,0,3,3,3,3,0,1,0,1,2,512]

theorem envBound40471 : H12AffineFastState.Bounded env40471 := by
  intro p hp
  have h : env40471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40470_40471 : H12AffineEnvironment.transform 10 2 env40470 = env40471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env40470 == env40471) = true)

theorem identity40471 : scanCanonicalize (H12AffineFastState.compose env40471 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40471 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env40472 : List Nat := [0,0,1,0,0,1,1,0,512,0,0,1,1,0,1,0,0,1,0,0,1,0,0,1,1,0,1,1,1,1,0,1,0,1,0,512]

theorem envBound40472 : H12AffineFastState.Bounded env40472 := by
  intro p hp
  have h : env40472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40471_40472 : H12AffineEnvironment.transform 0 0 env40471 = env40472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40471 == env40472) = true)

def env40473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412021,2114882,8328,65,6409271,115150,2497573,35188,2590759,4268162,256,510107,469311,2535408]

theorem envBound40473 : H12AffineFastState.Bounded env40473 := by
  intro p hp
  have h : env40473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40334_40473 : H12AffineEnvironment.transform 22 412021 env40334 = env40473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412021 env40334 == env40473) = true)

def env40474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412021,2114882,8328,65,215367,115150,2497573,35188,2590759,2336242,256,510107,469311,2535408]

theorem envBound40474 : H12AffineFastState.Bounded env40474 := by
  intro p hp
  have h : env40474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40473_40474 : H12AffineEnvironment.transform 21 2262384 env40473 = env40474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env40473 == env40474) = true)

def env40475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,21762,8328,65,215367,115150,396389,35188,497767,243122,256,510107,469311,442288]

theorem envBound40475 : H12AffineFastState.Bounded env40475 := by
  intro p hp
  have h : env40475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40474_40475 : H12AffineEnvironment.transform 20 4160 env40474 = env40475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40474 == env40475) = true)

theorem identity40475 : scanCanonicalize (H12AffineFastState.compose env40475 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40475 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,169264,412021,21762,8328,65,158029,57796,396389,35188,440429,169400,256,452753,395573,442288]

theorem envBound40476 : H12AffineFastState.Bounded env40476 := by
  intro p hp
  have h : env40476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40475_40476 : H12AffineEnvironment.transform 15 8202 env40475 = env40476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40475 == env40476) = true)

theorem identity40476 : scanCanonicalize (H12AffineFastState.compose env40476 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound40476 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4160,169264,62660,21762,8328,65,158029,57796,45524,35188,1500,169400,256,21792,46212,513]

theorem envBound40477 : H12AffineFastState.Bounded env40477 := by
  intro p hp
  have h : env40477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40476_40477 : H12AffineEnvironment.transform 17 179633 env40476 = env40477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env40476 == env40477) = true)

theorem identity40477 : scanCanonicalize (H12AffineFastState.compose env40477 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40477 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,64928,1024,32769,4160,54561,62660,21762,8328,65,10588,57796,45524,35188,1500,54697,256,21792,46212,513]

theorem envBound40478 : H12AffineFastState.Bounded env40478 := by
  intro p hp
  have h : env40478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40477_40478 : H12AffineEnvironment.transform 16 16401 env40477 = env40478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40477 == env40478) = true)

theorem identity40478 : scanCanonicalize (H12AffineFastState.compose env40478 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40478 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,16401,2420,1024,29909,4160,8693,16,21762,8328,65,10588,5392,17664,32160,1500,8573,256,21792,16464,513]

theorem envBound40479 : H12AffineFastState.Bounded env40479 := by
  intro p hp
  have h : env40479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40478_40479 : H12AffineEnvironment.transform 14 29908 env40478 = env40479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40478 == env40479) = true)

theorem identity40479 : scanCanonicalize (H12AffineFastState.compose env40479 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40479 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,343,16401,2420,1024,21896,4160,168,16,21762,469,65,2049,5392,17664,23805,1500,32,256,21792,16464,513]

theorem envBound40480 : H12AffineFastState.Bounded env40480 := by
  intro p hp
  have h : env40480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40479_40480 : H12AffineEnvironment.transform 12 349 env40479 = env40480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40479 == env40480) = true)

theorem identity40480 : scanCanonicalize (H12AffineFastState.compose env40480 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40480 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16401,2420,1024,21760,4160,32,16,21762,349,65,2049,5392,17664,23669,1364,32,256,21792,16464,513]

theorem envBound40481 : H12AffineFastState.Bounded env40481 := by
  intro p hp
  have h : env40481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40480_40481 : H12AffineEnvironment.transform 6 8 env40480 = env40481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40480 == env40481) = true)

def env40482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,21763,8328,65,215367,115150,396388,35188,497766,243123,256,510107,469311,442289]

theorem envBound40482 : H12AffineFastState.Bounded env40482 := by
  intro p hp
  have h : env40482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40474_40482 : H12AffineEnvironment.transform 20 4161 env40474 = env40482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40474 == env40482) = true)

theorem identity40482 : scanCanonicalize (H12AffineFastState.compose env40482 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound40482 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,4161,169265,120015,21763,8328,65,215367,115150,102878,35188,1500,243123,256,21793,46213,74251]

theorem envBound40483 : H12AffineFastState.Bounded env40483 := by
  intro p hp
  have h : env40483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40482_40483 : H12AffineEnvironment.transform 17 236986 env40482 = env40483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env40482 == env40483) = true)

def env40484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130174,1024,32769,4161,62709,120015,21763,8328,65,75907,115150,102878,35188,1500,119927,256,21793,46213,74251]

theorem envBound40484 : H12AffineFastState.Bounded env40484 := by
  intro p hp
  have h : env40484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40483_40484 : H12AffineEnvironment.transform 16 25028 env40483 = env40484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env40483 == env40484) = true)

theorem identity40484 : scanCanonicalize (H12AffineFastState.compose env40484 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound40484 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,479,25028,64929,1024,32769,4161,62709,54544,21763,8328,65,10588,49169,36865,35188,1500,54696,256,21793,46213,9172]

theorem envBound40485 : H12AffineFastState.Bounded env40485 := by
  intro p hp
  have h : env40485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40484_40485 : H12AffineEnvironment.transform 15 479 env40484 = env40485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env40484 == env40485) = true)

theorem identity40485 : scanCanonicalize (H12AffineFastState.compose env40485 (packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40485 : packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS < 2^1333 := by decide +kernel

def env40486 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,398,24981,64929,1024,32769,4112,62628,54544,21763,8328,16,10509,49169,36865,35109,1421,54696,256,21793,46213,9093]

theorem envBound40486 : H12AffineFastState.Bounded env40486 := by
  intro p hp
  have h : env40486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40485_40486 : H12AffineEnvironment.transform 5 17 env40485 = env40486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40485 == env40486) = true)

theorem identity40486 : scanCanonicalize (H12AffineFastState.compose env40486 (packedSelected [1,5,8,17,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound40486 : packedSelected [1,5,8,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env40487 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21761,398,24981,10400,1024,21760,4112,8613,17,21763,8328,16,10509,5392,17664,23588,1421,169,256,21793,24964,9093]

theorem envBound40487 : H12AffineFastState.Bounded env40487 := by
  intro p hp
  have h : env40487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40486_40487 : H12AffineEnvironment.transform 14 21761 env40486 = env40487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env40486 == env40487) = true)

theorem identity40487 : scanCanonicalize (H12AffineFastState.compose env40487 (packedSelected [1,2,3,5,6,7,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound40487 : packedSelected [1,2,3,5,6,7,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env40488 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,2049,7424,398,10644,10400,1024,7425,4112,8613,17,7426,8328,16,10509,5392,3329,5157,1421,169,256,7456,10629,9093]

theorem envBound40488 : H12AffineFastState.Bounded env40488 := by
  intro p hp
  have h : env40488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40487_40488 : H12AffineEnvironment.transform 13 2049 env40487 = env40488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env40487 == env40488) = true)

theorem identity40488 : scanCanonicalize (H12AffineFastState.compose env40488 (packedSelected [4,7,10,11,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound40488 : packedSelected [4,7,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env40489 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,8192,2049,136,398,10644,10400,1024,137,3480,8613,17,138,8328,16,10509,2200,3329,2477,1421,169,256,168,10629,9093]

theorem envBound40489 : H12AffineFastState.Bounded env40489 := by
  intro p hp
  have h : env40489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40488_40489 : H12AffineEnvironment.transform 11 3464 env40488 = env40489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env40488 == env40489) = true)

theorem identity40489 : scanCanonicalize (H12AffineFastState.compose env40489 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40489 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40490 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,3245,8192,2049,136,171,10417,10400,1024,137,3261,8320,17,138,8328,16,10280,2200,3108,2184,1192,169,37,168,10400,8864]

theorem envBound40490 : H12AffineFastState.Bounded env40490 := by
  intro p hp
  have h : env40490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40489_40490 : H12AffineEnvironment.transform 7 37 env40489 = env40490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40489 == env40490) = true)

theorem identity40490 : scanCanonicalize (H12AffineFastState.compose env40490 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40490 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40491 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3109,8192,2049,0,35,10297,10280,1024,1,3125,8200,17,2,8192,16,10280,2064,3108,2048,1056,33,37,32,10280,8744]

theorem envBound40491 : H12AffineFastState.Bounded env40491 := by
  intro p hp
  have h : env40491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40490_40491 : H12AffineEnvironment.transform 6 8 env40490 = env40491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40490 == env40491) = true)

theorem identity40491 : scanCanonicalize (H12AffineFastState.compose env40491 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound40491 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env40492 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3109,8,2049,0,35,2097,2080,1024,1,3125,0,17,2,8,16,2080,2064,3108,2048,1056,33,37,32,2080,544]

theorem envBound40492 : H12AffineFastState.Bounded env40492 := by
  intro p hp
  have h : env40492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40491_40492 : H12AffineEnvironment.transform 12 8 env40491 = env40492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env40491 == env40492) = true)

def env40493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130175,1024,32769,4161,62708,120015,21763,8328,65,75906,115150,102878,35188,1500,119926,256,21793,46213,74251]

theorem envBound40493 : H12AffineFastState.Bounded env40493 := by
  intro p hp
  have h : env40493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40483_40493 : H12AffineEnvironment.transform 16 25029 env40483 = env40493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env40483 == env40493) = true)

theorem identity40493 : scanCanonicalize (H12AffineFastState.compose env40493 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound40493 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,16401,122283,1024,32769,4161,54560,120015,21763,348,65,67926,115150,102878,35188,1500,119926,256,21793,38225,66527]

theorem envBound40494 : H12AffineFastState.Bounded env40494 := by
  intro p hp
  have h : env40494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40493_40494 : H12AffineEnvironment.transform 12 468 env40493 = env40494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env40493 == env40494) = true)

theorem identity40494 : scanCanonicalize (H12AffineFastState.compose env40494 (packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound40494 : packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS < 2^1333 := by decide +kernel

def env40495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,33111,16401,23804,1024,32769,4161,54560,21912,21763,348,65,34817,16537,4233,35188,1500,21793,256,21793,38225,33416]

theorem envBound40495 : H12AffineFastState.Bounded env40495 := by
  intro p hp
  have h : env40495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40494_40495 : H12AffineEnvironment.transform 15 33111 env40494 = env40495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env40494 == env40495) = true)

theorem identity40495 : scanCanonicalize (H12AffineFastState.compose env40495 (packedSelected [2,4,9,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound40495 : packedSelected [2,4,9,11,18,20] rootPS < 2^1333 := by decide +kernel

def env40496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5373,32768,33111,5356,2049,1024,32769,4161,33245,357,510,348,65,34817,5220,4233,35188,1500,476,256,476,38225,33416]

theorem envBound40496 : H12AffineFastState.Bounded env40496 := by
  intro p hp
  have h : env40496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40495_40496 : H12AffineEnvironment.transform 13 5373 env40495 = env40496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env40495 == env40496) = true)

theorem identity40496 : scanCanonicalize (H12AffineFastState.compose env40496 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40496 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40497 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5373,32768,32802,5356,2049,1024,32769,4161,32936,16,139,41,65,34817,5220,4233,34817,1193,169,117,169,37924,33416]

theorem envBound40497 : H12AffineFastState.Bounded env40497 := by
  intro p hp
  have h : env40497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40496_40497 : H12AffineEnvironment.transform 7 117 env40496 = env40497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40496 == env40497) = true)

theorem identity40497 : scanCanonicalize (H12AffineFastState.compose env40497 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40497 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env40498 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5373,1,35,5356,2049,1024,0,4161,169,16,139,41,65,2048,5220,4233,2048,1193,169,117,169,5157,649]

theorem envBound40498 : H12AffineFastState.Bounded env40498 := by
  intro p hp
  have h : env40498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40497_40498 : H12AffineEnvironment.transform 14 1 env40497 = env40498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40497 == env40498) = true)

theorem identity40498 : scanCanonicalize (H12AffineFastState.compose env40498 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound40498 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40499 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,1141,161,136,1,35,153,2049,1024,0,1076,169,16,139,41,65,2048,17,1276,2048,1193,169,117,169,80,649]

theorem envBound40499 : H12AffineFastState.Bounded env40499 := by
  intro p hp
  have h : env40499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40498_40499 : H12AffineEnvironment.transform 11 1141 env40498 = env40499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env40498 == env40499) = true)

theorem identity40499 : scanCanonicalize (H12AffineFastState.compose env40499 (packedSelected [1,2,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound40499 : packedSelected [1,2,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40500 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,1141,9,32,1,35,49,2049,1024,0,1076,1,16,35,41,65,2048,17,1108,2048,1025,1,117,1,80,545]

theorem envBound40500 : H12AffineFastState.Bounded env40500 := by
  intro p hp
  have h : env40500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40499_40500 : H12AffineEnvironment.transform 6 40 env40499 = env40500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env40499 == env40500) = true)

theorem identity40500 : scanCanonicalize (H12AffineFastState.compose env40500 (packedSelected [0,2,4,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1547) := by decide +kernel

theorem selectedBound40500 : packedSelected [0,2,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env40501 : List Nat := [2,4,8,16,32,64,40,117,512,1024,1547,1141,9,32,1,35,49,1546,1024,0,1076,1,16,35,41,65,1547,17,1108,1547,1025,1,117,1,80,545]

theorem envBound40501 : H12AffineFastState.Bounded env40501 := by
  intro p hp
  have h : env40501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40500_40501 : H12AffineEnvironment.transform 10 1547 env40500 = env40501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1547 env40500 == env40501) = true)

theorem identity40501 : scanCanonicalize (H12AffineFastState.compose env40501 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40501 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40502 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1547,1108,9,1,1,2,16,1546,1024,0,1045,1,16,2,8,65,1547,17,1108,1547,1025,1,84,1,80,512]

theorem envBound40502 : H12AffineFastState.Bounded env40502 := by
  intro p hp
  have h : env40502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40501_40502 : H12AffineEnvironment.transform 4 1 env40501 = env40502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40501 == env40502) = true)

theorem identity40502 : scanCanonicalize (H12AffineFastState.compose env40502 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 590) := by decide +kernel

theorem selectedBound40502 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40503 : List Nat := [2,4,8,16,1,64,9,84,512,590,69,538,9,1,1,2,16,68,590,0,603,1,16,2,8,65,69,17,538,69,591,1,84,1,80,512]

theorem envBound40503 : H12AffineFastState.Bounded env40503 := by
  intro p hp
  have h : env40503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40502_40503 : H12AffineEnvironment.transform 9 590 env40502 = env40503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 590 env40502 == env40503) = true)

theorem identity40503 : scanCanonicalize (H12AffineFastState.compose env40503 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound40503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40504 : List Nat := [2,4,8,4,1,64,9,64,512,590,69,526,9,1,1,2,4,68,590,0,591,1,4,2,8,65,69,5,526,69,591,1,64,1,68,512]

theorem envBound40504 : H12AffineFastState.Bounded env40504 := by
  intro p hp
  have h : env40504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40503_40504 : H12AffineEnvironment.transform 3 4 env40503 = env40504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env40503 == env40504) = true)

theorem identity40504 : scanCanonicalize (H12AffineFastState.compose env40504 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40505 : List Nat := [2,2,8,2,1,64,9,64,512,584,67,520,9,1,1,2,2,66,584,0,585,1,2,2,8,65,67,3,520,67,585,1,64,1,66,512]

theorem envBound40505 : H12AffineFastState.Bounded env40505 := by
  intro p hp
  have h : env40505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40504_40505 : H12AffineEnvironment.transform 1 2 env40504 = env40505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40504 == env40505) = true)

theorem identity40505 : scanCanonicalize (H12AffineFastState.compose env40505 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound40505 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40506 : List Nat := [2,2,8,2,1,3,9,3,512,523,0,520,9,1,1,2,2,1,523,0,522,1,2,2,8,2,0,3,520,0,522,1,3,1,1,512]

theorem envBound40506 : H12AffineFastState.Bounded env40506 := by
  intro p hp
  have h : env40506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40505_40506 : H12AffineEnvironment.transform 5 3 env40505 = env40506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env40505 == env40506) = true)

theorem identity40506 : scanCanonicalize (H12AffineFastState.compose env40506 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound40506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40507 : List Nat := [2,2,8,2,1,3,9,3,11,0,0,3,9,1,1,2,2,1,0,0,1,1,2,2,8,2,0,3,3,0,1,1,3,1,1,11]

theorem envBound40507 : H12AffineFastState.Bounded env40507 := by
  intro p hp
  have h : env40507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40506_40507 : H12AffineEnvironment.transform 8 11 env40506 = env40507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env40506 == env40507) = true)

def env40508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412021,2114882,8328,65,215366,115150,2497573,35188,2590759,2336243,256,510107,469311,2535408]

theorem envBound40508 : H12AffineFastState.Bounded env40508 := by
  intro p hp
  have h : env40508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40473_40508 : H12AffineEnvironment.transform 21 2262385 env40473 = env40508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env40473 == env40508) = true)

def env40509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,21762,8328,65,215366,115150,396389,35188,497767,243123,256,510107,469311,442288]

theorem envBound40509 : H12AffineFastState.Bounded env40509 := by
  intro p hp
  have h : env40509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40508_40509 : H12AffineEnvironment.transform 20 4160 env40508 = env40509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40508 == env40509) = true)

theorem identity40509 : scanCanonicalize (H12AffineFastState.compose env40509 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound40509 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169265,73754,21762,8328,65,215366,115150,91402,35188,61704,243123,256,41460,16464,120543]

theorem envBound40510 : H12AffineFastState.Bounded env40510 := by
  intro p hp
  have h : env40510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40509_40510 : H12AffineEnvironment.transform 17 223599 env40509 = env40510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env40509 == env40510) = true)

def env40511 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4112,169265,73754,21762,8328,17,215318,115102,91402,35108,61704,243123,256,41380,16384,120463]

theorem envBound40511 : H12AffineFastState.Bounded env40511 := by
  intro p hp
  have h : env40511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40510_40511 : H12AffineEnvironment.transform 5 16 env40510 = env40511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40510 == env40511) = true)

theorem identity40511 : scanCanonicalize (H12AffineFastState.compose env40511 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57748) := by decide +kernel

theorem selectedBound40511 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env40512 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,57748,100523,1024,32769,4112,29861,73754,21762,8328,17,108674,115102,91402,35108,61704,87079,256,41380,16384,120463]

theorem envBound40512 : H12AffineFastState.Bounded env40512 := by
  intro p hp
  have h : env40512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40511_40512 : H12AffineEnvironment.transform 16 57748 env40511 = env40512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57748 env40511 == env40512) = true)

theorem identity40512 : scanCanonicalize (H12AffineFastState.compose env40512 (packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound40512 : packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env40513 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,65536,46108,100523,1024,32769,4112,8493,73754,138,8328,17,108674,103446,77954,35108,42112,65967,256,41380,5512,99079]

theorem envBound40513 : H12AffineFastState.Bounded env40513 := by
  intro p hp
  have h : env40513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40512_40513 : H12AffineEnvironment.transform 13 5512 env40512 = env40513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env40512 == env40513) = true)

theorem identity40513 : scanCanonicalize (H12AffineFastState.compose env40513 (packedSelected [0,9,18,22,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40513 : packedSelected [0,9,18,22,23,27] rootPS < 2^1333 := by decide +kernel

def env40514 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,65536,46108,100387,1024,32769,4112,8493,73754,2,8192,17,108554,103446,77834,35108,41992,65831,256,41260,5376,99079]

theorem envBound40514 : H12AffineFastState.Bounded env40514 := by
  intro p hp
  have h : env40514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40513_40514 : H12AffineEnvironment.transform 6 8 env40513 = env40514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40513 == env40514) = true)

theorem identity40514 : scanCanonicalize (H12AffineFastState.compose env40514 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound40514 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env40515 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,263,46108,35108,1024,32769,4112,8493,8477,2,8192,17,43277,38161,12557,35108,41992,32,256,41260,5376,33280]

theorem envBound40515 : H12AffineFastState.Bounded env40515 := by
  intro p hp
  have h : env40515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40514_40515 : H12AffineEnvironment.transform 15 263 env40514 = env40515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env40514 == env40515) = true)

theorem identity40515 : scanCanonicalize (H12AffineFastState.compose env40515 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound40515 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env40516 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,263,5393,10281,1024,8460,4112,8493,8477,2,8192,17,2048,13340,12557,10281,1285,32,256,33,5376,8973]

theorem envBound40516 : H12AffineFastState.Bounded env40516 := by
  intro p hp
  have h : env40516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40515_40516 : H12AffineEnvironment.transform 14 8461 env40515 = env40516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env40515 == env40516) = true)

theorem identity40516 : scanCanonicalize (H12AffineFastState.compose env40516 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40516 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env40517 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1024,0,4112,33,17,2,268,17,2048,5392,4097,2341,1285,32,256,33,5376,513]

theorem envBound40517 : H12AffineFastState.Bounded env40517 := by
  intro p hp
  have h : env40517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40516_40517 : H12AffineEnvironment.transform 12 268 env40516 = env40517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40516 == env40517) = true)

theorem identity40517 : scanCanonicalize (H12AffineFastState.compose env40517 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40518 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,1,34,5172,2048,1024,0,4112,33,17,2,41,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound40518 : H12AffineFastState.Bounded env40518 := by
  intro p hp
  have h : env40518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40517_40518 : H12AffineEnvironment.transform 7 37 env40517 = env40518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40517 == env40518) = true)

def env40519 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1045,1,34,1028,2048,1024,0,32,33,17,2,41,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound40519 : H12AffineFastState.Bounded env40519 := by
  intro p hp
  have h : env40519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40518_40519 : H12AffineEnvironment.transform 11 48 env40518 = env40519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40518 == env40519) = true)

theorem identity40519 : scanCanonicalize (H12AffineFastState.compose env40519 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound40519 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40520 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,48,41,1045,1,34,1028,33,1024,0,32,33,17,2,41,17,33,1029,49,33,1056,32,37,33,1045,513]

theorem envBound40520 : H12AffineFastState.Bounded env40520 := by
  intro p hp
  have h : env40520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40519_40520 : H12AffineEnvironment.transform 10 33 env40519 = env40520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env40519 == env40520) = true)

def env40521 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,41,33,1,34,48,33,52,0,32,33,17,2,41,17,33,49,49,33,20,32,37,33,33,513]

theorem envBound40521 : H12AffineFastState.Bounded env40521 := by
  intro p hp
  have h : env40521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40520_40521 : H12AffineEnvironment.transform 9 52 env40520 = env40521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40520 == env40521) = true)

theorem identity40521 : scanCanonicalize (H12AffineFastState.compose env40521 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40522 : List Nat := [2,4,8,16,32,16,8,37,42,52,33,48,41,33,1,34,48,33,52,0,32,33,17,2,41,17,33,49,49,33,20,32,37,33,33,43]

theorem envBound40522 : H12AffineFastState.Bounded env40522 := by
  intro p hp
  have h : env40522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40521_40522 : H12AffineEnvironment.transform 8 42 env40521 = env40522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40521 == env40522) = true)

def leafEnv40522 : List Nat := [2,4,8,16,32,16,8,37,42,52,33,48,41,33,1,34,48,33,52,0,32,33,17,2,20,41,1,17,33,49,49,33,20,32,37,33,4,34,33,43,1,32,0]

def active40522 : List Nat := [0,1,2,3,4]

def tree40522 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40522 : H12WitnessSearch.Good tree40522 := H12GlobalWitnessIndex.good

theorem leafIdentity40522 : H12AffineFastState.composeSystem env40522 rootObs = leafEnv40522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40522 rootObs == leafEnv40522) = true)

theorem terminalChecked40522 : H12PackedTerminal.terminalCheckFast leafEnv40522 active40522 tree40522 = true := by decide +kernel

def env40523 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,41,32,1,34,49,33,53,0,32,33,17,2,41,17,33,48,49,33,21,32,37,33,32,513]

theorem envBound40523 : H12AffineFastState.Bounded env40523 := by
  intro p hp
  have h : env40523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40520_40523 : H12AffineEnvironment.transform 9 53 env40520 = env40523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40520 == env40523) = true)

def env40524 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1044,1,34,1029,2048,1024,0,33,33,17,2,41,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound40524 : H12AffineFastState.Bounded env40524 := by
  intro p hp
  have h : env40524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40518_40524 : H12AffineEnvironment.transform 11 49 env40518 = env40524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40518 == env40524) = true)

theorem identity40524 : scanCanonicalize (H12AffineFastState.compose env40524 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound40524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40525 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,49,41,1044,1,34,1029,1044,1024,0,33,33,17,2,41,17,1044,1028,48,1044,1056,32,37,33,1044,513]

theorem envBound40525 : H12AffineFastState.Bounded env40525 := by
  intro p hp
  have h : env40525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40524_40525 : H12AffineEnvironment.transform 10 1044 env40524 = env40525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env40524 == env40525) = true)

def env40526 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,41,32,1,34,49,32,52,0,33,33,17,2,41,17,32,48,48,32,20,32,37,33,32,513]

theorem envBound40526 : H12AffineFastState.Bounded env40526 := by
  intro p hp
  have h : env40526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40525_40526 : H12AffineEnvironment.transform 9 52 env40525 = env40526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40525 == env40526) = true)

theorem identity40526 : scanCanonicalize (H12AffineFastState.compose env40526 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound40526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40527 : List Nat := [2,4,8,16,32,16,8,37,43,52,32,49,41,32,1,34,49,32,52,0,33,33,17,2,41,17,32,48,48,32,20,32,37,33,32,42]

theorem envBound40527 : H12AffineFastState.Bounded env40527 := by
  intro p hp
  have h : env40527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40526_40527 : H12AffineEnvironment.transform 8 43 env40526 = env40527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env40526 == env40527) = true)

def leafEnv40527 : List Nat := [2,4,8,16,32,16,8,37,43,52,32,49,41,32,1,34,49,32,52,0,33,33,17,2,20,41,1,17,32,48,48,32,20,32,37,33,4,34,32,42,1,33,0]

def active40527 : List Nat := [0,1,2,3,4]

def tree40527 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40527 : H12WitnessSearch.Good tree40527 := H12GlobalWitnessIndex.good

theorem leafIdentity40527 : H12AffineFastState.composeSystem env40527 rootObs = leafEnv40527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40527 rootObs == leafEnv40527) = true)

theorem terminalChecked40527 : H12PackedTerminal.terminalCheckFast leafEnv40527 active40527 tree40527 = true := by decide +kernel

def env40528 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,41,33,1,34,48,33,53,0,33,33,17,2,41,17,33,49,48,33,21,32,37,33,33,513]

theorem envBound40528 : H12AffineFastState.Bounded env40528 := by
  intro p hp
  have h : env40528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40525_40528 : H12AffineEnvironment.transform 9 53 env40525 = env40528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40525 == env40528) = true)

def env40529 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4113,169265,73754,21762,8328,16,215319,115103,91402,35109,61704,243123,256,41381,16385,120462]

theorem envBound40529 : H12AffineFastState.Bounded env40529 := by
  intro p hp
  have h : env40529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40510_40529 : H12AffineEnvironment.transform 5 17 env40510 = env40529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40510 == env40529) = true)

theorem identity40529 : scanCanonicalize (H12AffineFastState.compose env40529 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 115103) := by decide +kernel

theorem selectedBound40529 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env40530 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,115103,43169,1024,32769,4113,87214,73754,21762,8328,16,34952,115103,91402,35109,61704,29740,256,41381,16385,120462]

theorem envBound40530 : H12AffineFastState.Bounded env40530 := by
  intro p hp
  have h : env40530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40529_40530 : H12AffineEnvironment.transform 16 115103 env40529 = env40530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115103 env40529 == env40530) = true)

theorem identity40530 : scanCanonicalize (H12AffineFastState.compose env40530 (packedSelected [1,3,4,5,7,8,9,17,19,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound40530 : packedSelected [1,3,4,5,7,8,9,17,19,27,31] rootPS < 2^1333 := by decide +kernel

def env40531 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,65536,90138,2340,1024,8580,4113,87214,73754,21762,8328,16,10509,90138,91402,10400,20621,29740,256,32,16385,96011]

theorem envBound40531 : H12AffineFastState.Bounded env40531 := by
  intro p hp
  have h : env40531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40530_40531 : H12AffineEnvironment.transform 14 8581 env40530 = env40531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env40530 == env40531) = true)

theorem identity40531 : scanCanonicalize (H12AffineFastState.compose env40531 (packedSelected [0,9,18,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound40531 : packedSelected [0,9,18,22,23,27] rootPS < 2^1333 := by decide +kernel

def env40532 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8322,16536,2340,1024,8580,4113,29740,152,21762,8328,16,10509,16536,17800,10400,20621,29740,256,32,16385,22409]

theorem envBound40532 : H12AffineFastState.Bounded env40532 := by
  intro p hp
  have h : env40532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40531_40532 : H12AffineEnvironment.transform 15 8322 env40531 = env40532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env40531 == env40532) = true)

theorem identity40532 : scanCanonicalize (H12AffineFastState.compose env40532 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40532 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env40533 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,8322,5529,2340,1024,8580,4113,8493,152,3,8328,16,10509,5529,4233,10400,1420,8493,256,32,5376,648]

theorem envBound40533 : H12AffineFastState.Bounded env40533 := by
  intro p hp
  have h : env40533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40532_40533 : H12AffineEnvironment.transform 13 5377 env40532 = env40533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40532 == env40533) = true)

theorem identity40533 : scanCanonicalize (H12AffineFastState.compose env40533 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40533 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40534 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,5392,2340,1024,8461,4113,8493,17,3,8193,16,10509,5392,4096,10281,1285,8493,256,32,5376,513]

theorem envBound40534 : H12AffineFastState.Bounded env40534 := by
  intro p hp
  have h : env40534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40533_40534 : H12AffineEnvironment.transform 6 9 env40533 = env40534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40533 == env40534) = true)

theorem identity40534 : scanCanonicalize (H12AffineFastState.compose env40534 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40534 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40535 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,4112,8460,8203,4097,2340,273,8461,4113,8493,17,3,8193,16,10509,4097,4096,10281,20,8493,256,32,4113,513]

theorem envBound40535 : H12AffineFastState.Bounded env40535 := by
  intro p hp
  have h : env40535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40534_40535 : H12AffineEnvironment.transform 9 273 env40534 = env40535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40534 == env40535) = true)

theorem identity40535 : scanCanonicalize (H12AffineFastState.compose env40535 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40535 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40536 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,0,263,4097,2340,273,1,4113,33,17,3,269,16,2049,4097,4096,2341,20,33,256,32,4113,513]

theorem envBound40536 : H12AffineFastState.Bounded env40536 := by
  intro p hp
  have h : env40536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40535_40536 : H12AffineEnvironment.transform 12 268 env40535 = env40536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40535 == env40536) = true)

theorem identity40536 : scanCanonicalize (H12AffineFastState.compose env40536 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound40536 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40537 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,268,2049,0,263,2064,2340,273,1,2048,33,17,3,269,16,2049,2064,2065,2341,20,33,256,32,2048,513]

theorem envBound40537 : H12AffineFastState.Bounded env40537 := by
  intro p hp
  have h : env40537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40536_40537 : H12AffineEnvironment.transform 11 2065 env40536 = env40537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env40536 == env40537) = true)

theorem identity40537 : scanCanonicalize (H12AffineFastState.compose env40537 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40537 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40538 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2065,40,2049,0,35,2064,2048,53,1,2048,33,17,3,41,16,2049,2064,2065,2049,20,33,36,32,2048,513]

theorem envBound40538 : H12AffineFastState.Bounded env40538 := by
  intro p hp
  have h : env40538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40537_40538 : H12AffineEnvironment.transform 7 36 env40537 = env40538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40537 == env40538) = true)

theorem identity40538 : scanCanonicalize (H12AffineFastState.compose env40538 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound40538 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40539 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,40,48,0,35,33,49,53,1,49,33,17,3,41,16,48,33,32,48,20,33,36,32,49,513]

theorem envBound40539 : H12AffineFastState.Bounded env40539 := by
  intro p hp
  have h : env40539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40538_40539 : H12AffineEnvironment.transform 10 49 env40538 = env40539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env40538 == env40539) = true)

def leafEnv40539 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,40,48,0,35,33,49,53,1,49,33,17,3,20,41,1,16,48,33,32,48,20,33,36,32,4,34,49,513,1,48,0]

def active40539 : List Nat := [0,1,2,3,4,8]

def tree40539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40539 : H12WitnessSearch.Good tree40539 := H12GlobalWitnessIndex.good

theorem leafIdentity40539 : H12AffineFastState.composeSystem env40539 rootObs = leafEnv40539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40539 rootObs == leafEnv40539) = true)

theorem terminalChecked40539 : H12PackedTerminal.terminalCheckFast leafEnv40539 active40539 tree40539 = true := by decide +kernel

def env40540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,21763,8328,65,215366,115150,396388,35188,497766,243122,256,510107,469311,442289]

theorem envBound40540 : H12AffineFastState.Bounded env40540 := by
  intro p hp
  have h : env40540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40508_40540 : H12AffineEnvironment.transform 20 4161 env40508 = env40540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40508 == env40540) = true)

theorem identity40540 : scanCanonicalize (H12AffineFastState.compose env40540 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound40540 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,169264,412021,21763,8328,65,171417,5393,396388,35188,412857,156013,256,400452,458208,442289]

theorem envBound40541 : H12AffineFastState.Bounded env40541 := by
  intro p hp
  have h : env40541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40540_40541 : H12AffineEnvironment.transform 15 54495 env40540 = env40541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env40540 == env40541) = true)

def env40542 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4113,169264,411941,21763,8328,17,171417,5393,396340,35108,412857,155965,256,400404,458160,442289]

theorem envBound40542 : H12AffineFastState.Bounded env40542 := by
  intro p hp
  have h : env40542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40541_40542 : H12AffineEnvironment.transform 5 16 env40541 = env40542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40541 == env40542) = true)

theorem identity40542 : scanCanonicalize (H12AffineFastState.compose env40542 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23724) := by decide +kernel

theorem selectedBound40542 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env40543 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,23724,1024,32769,4113,169264,136585,21763,8328,17,171417,5393,151704,35108,135189,155965,256,147640,172316,189213]

theorem envBound40543 : H12AffineFastState.Bounded env40543 := by
  intro p hp
  have h : env40543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40542_40543 : H12AffineEnvironment.transform 17 23724 env40542 = env40543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23724 env40542 == env40543) = true)

theorem identity40543 : scanCanonicalize (H12AffineFastState.compose env40543 (packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound40543 : packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env40544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46109,23724,1024,32769,4113,8493,41364,21763,8328,17,10628,5393,58501,35108,41992,54560,256,62629,5377,22272]

theorem envBound40544 : H12AffineFastState.Bounded env40544 := by
  intro p hp
  have h : env40544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40543_40544 : H12AffineEnvironment.transform 16 46109 env40543 = env40544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env40543 == env40544) = true)

theorem identity40544 : scanCanonicalize (H12AffineFastState.compose env40544 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40544 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env40545 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,46109,23588,1024,32769,4113,8493,41244,21763,8192,17,10508,5393,58381,35108,41992,54560,256,62509,5377,22272]

theorem envBound40545 : H12AffineFastState.Bounded env40545 := by
  intro p hp
  have h : env40545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40544_40545 : H12AffineEnvironment.transform 6 8 env40544 = env40545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40544 == env40545) = true)

theorem identity40545 : scanCanonicalize (H12AffineFastState.compose env40545 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40545 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env40546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33030,46109,2341,1024,32769,4113,8493,41244,2,8192,17,10508,5393,45324,35108,41992,32801,256,41260,5377,513]

theorem envBound40546 : H12AffineFastState.Bounded env40546 := by
  intro p hp
  have h : env40546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40545_40546 : H12AffineEnvironment.transform 13 5377 env40545 = env40546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40545 == env40546) = true)

theorem identity40546 : scanCanonicalize (H12AffineFastState.compose env40546 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound40546 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env40547 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,5392,2341,1024,8460,4113,8493,17,2,8192,17,10508,5393,4097,10281,1285,8492,256,33,5377,513]

theorem envBound40547 : H12AffineFastState.Bounded env40547 := by
  intro p hp
  have h : env40547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40546_40547 : H12AffineEnvironment.transform 14 8461 env40546 = env40547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env40546 == env40547) = true)

theorem identity40547 : scanCanonicalize (H12AffineFastState.compose env40547 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40548 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,8233,8203,5172,2049,1024,8232,4113,8201,17,2,8192,17,10280,5173,4097,10281,1057,8200,36,33,5157,513]

theorem envBound40548 : H12AffineFastState.Bounded env40548 := by
  intro p hp
  have h : env40548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40547_40548 : H12AffineEnvironment.transform 7 36 env40547 = env40548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40547 == env40548) = true)

theorem identity40548 : scanCanonicalize (H12AffineFastState.compose env40548 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40548 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40549 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5172,2049,1024,0,4113,33,17,2,40,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound40549 : H12AffineFastState.Bounded env40549 := by
  intro p hp
  have h : env40549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40548_40549 : H12AffineEnvironment.transform 12 40 env40548 = env40549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40548 == env40549) = true)

def env40550 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,1,35,1028,2049,1024,0,33,33,17,2,40,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound40550 : H12AffineFastState.Bounded env40550 := by
  intro p hp
  have h : env40550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40549_40550 : H12AffineEnvironment.transform 11 48 env40549 = env40550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40549 == env40550) = true)

theorem identity40550 : scanCanonicalize (H12AffineFastState.compose env40550 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound40550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40551 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,48,40,529,1,35,512,2049,516,0,33,33,17,2,40,17,2048,513,49,2049,549,32,36,33,529,513]

theorem envBound40551 : H12AffineFastState.Bounded env40551 := by
  intro p hp
  have h : env40551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40550_40551 : H12AffineEnvironment.transform 9 516 env40550 = env40551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env40550 == env40551) = true)

def env40552 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,40,33,1,35,48,2049,52,0,33,33,17,2,40,17,2048,49,49,2049,21,32,36,33,33,49]

theorem envBound40552 : H12AffineFastState.Bounded env40552 := by
  intro p hp
  have h : env40552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40551_40552 : H12AffineEnvironment.transform 8 48 env40551 = env40552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40551 == env40552) = true)

theorem identity40552 : scanCanonicalize (H12AffineFastState.compose env40552 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40552 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40553 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,43,40,33,1,35,43,2049,47,0,33,33,10,2,40,10,2048,42,42,2049,14,32,36,33,33,42]

theorem envBound40553 : H12AffineFastState.Bounded env40553 := by
  intro p hp
  have h : env40553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40552_40553 : H12AffineEnvironment.transform 3 11 env40552 = env40553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40552 == env40553) = true)

def leafEnv40553 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,43,40,33,1,35,43,2049,47,0,33,33,10,2,14,40,1,10,2048,42,42,2049,14,32,36,33,4,35,33,42,1,33,0]

def active40553 : List Nat := [0,1,2,4,10]

def tree40553 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40553 : H12WitnessSearch.Good tree40553 := H12GlobalWitnessIndex.good

theorem leafIdentity40553 : H12AffineFastState.composeSystem env40553 rootObs = leafEnv40553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40553 rootObs == leafEnv40553) = true)

theorem terminalChecked40553 : H12PackedTerminal.terminalCheckFast leafEnv40553 active40553 tree40553 = true := by decide +kernel

def env40554 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,40,32,1,35,49,2049,53,0,33,33,17,2,40,17,2048,48,49,2049,20,32,36,33,32,48]

theorem envBound40554 : H12AffineFastState.Bounded env40554 := by
  intro p hp
  have h : env40554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40551_40554 : H12AffineEnvironment.transform 8 49 env40551 = env40554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40551 == env40554) = true)

def env40555 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,1,35,1029,2049,1024,0,32,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound40555 : H12AffineFastState.Bounded env40555 := by
  intro p hp
  have h : env40555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40549_40555 : H12AffineEnvironment.transform 11 49 env40549 = env40555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40549 == env40555) = true)

theorem identity40555 : scanCanonicalize (H12AffineFastState.compose env40555 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound40555 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40556 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,49,40,1044,1,35,1029,2049,1024,0,32,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,48]

theorem envBound40556 : H12AffineFastState.Bounded env40556 := by
  intro p hp
  have h : env40556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40555_40556 : H12AffineEnvironment.transform 8 49 env40555 = env40556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40555 == env40556) = true)

def env40557 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,40,32,1,35,49,2049,52,0,32,33,17,2,40,17,2048,48,48,2049,21,32,36,33,32,48]

theorem envBound40557 : H12AffineFastState.Bounded env40557 := by
  intro p hp
  have h : env40557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40556_40557 : H12AffineEnvironment.transform 9 52 env40556 = env40557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40556 == env40557) = true)

theorem identity40557 : scanCanonicalize (H12AffineFastState.compose env40557 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40558 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,42,40,32,1,35,42,2049,47,0,32,33,10,2,40,10,2048,43,43,2049,14,32,36,33,32,43]

theorem envBound40558 : H12AffineFastState.Bounded env40558 := by
  intro p hp
  have h : env40558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40557_40558 : H12AffineEnvironment.transform 3 11 env40557 = env40558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40557 == env40558) = true)

def leafEnv40558 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,42,40,32,1,35,42,2049,47,0,32,33,10,2,14,40,1,10,2048,43,43,2049,14,32,36,33,4,35,32,43,1,32,0]

def active40558 : List Nat := [0,1,2,4,10]

def tree40558 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40558 : H12WitnessSearch.Good tree40558 := H12GlobalWitnessIndex.good

theorem leafIdentity40558 : H12AffineFastState.composeSystem env40558 rootObs = leafEnv40558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40558 rootObs == leafEnv40558) = true)

theorem terminalChecked40558 : H12PackedTerminal.terminalCheckFast leafEnv40558 active40558 tree40558 = true := by decide +kernel

def env40559 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,40,33,1,35,48,2049,53,0,32,33,17,2,40,17,2048,49,48,2049,20,32,36,33,33,48]

theorem envBound40559 : H12AffineFastState.Bounded env40559 := by
  intro p hp
  have h : env40559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40556_40559 : H12AffineEnvironment.transform 9 53 env40556 = env40559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40556 == env40559) = true)

def env40560 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4112,169264,411940,21763,8328,16,171417,5393,396341,35109,412857,155964,256,400405,458161,442289]

theorem envBound40560 : H12AffineFastState.Bounded env40560 := by
  intro p hp
  have h : env40560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40541_40560 : H12AffineEnvironment.transform 5 17 env40541 = env40560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40541 == env40560) = true)

theorem identity40560 : scanCanonicalize (H12AffineFastState.compose env40560 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound40560 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env40561 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,5393,262144,1024,32769,4112,32801,285749,21763,8328,16,34952,5393,268580,35109,285096,29741,256,264452,321696,305824]

theorem envBound40561 : H12AffineFastState.Bounded env40561 := by
  intro p hp
  have h : env40561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40560_40561 : H12AffineEnvironment.transform 16 5393 env40560 = env40561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env40560 == env40561) = true)

theorem identity40561 : scanCanonicalize (H12AffineFastState.compose env40561 (packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound40561 : packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40562 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8322,5393,262144,1024,29709,4112,29741,285749,21763,8328,16,31876,5393,268580,32041,285096,29741,256,264452,269484,286380]

theorem envBound40562 : H12AffineFastState.Bounded env40562 := by
  intro p hp
  have h : env40562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40561_40562 : H12AffineEnvironment.transform 14 29708 env40561 = env40562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env40561 == env40562) = true)

theorem identity40562 : scanCanonicalize (H12AffineFastState.compose env40562 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound40562 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env40563 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8322,5393,23725,1024,29709,4112,29741,152,21763,8328,16,31876,5393,17801,32041,1285,29741,256,21929,16385,513]

theorem envBound40563 : H12AffineFastState.Bounded env40563 := by
  intro p hp
  have h : env40563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40562_40563 : H12AffineEnvironment.transform 17 23725 env40562 = env40563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env40562 == env40563) = true)

theorem identity40563 : scanCanonicalize (H12AffineFastState.compose env40563 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound40563 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0