import H12CloudChart0Data193

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env49132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound49132 : H12AffineFastState.Bounded env49132 := by
  intro p hp
  have h : env49132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48373_49132 : H12AffineEnvironment.transform 25 65 env48373 = env49132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env48373 == env49132) = true)

def env49133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound49133 : H12AffineFastState.Bounded env49133 := by
  intro p hp
  have h : env49133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49132_49133 : H12AffineEnvironment.transform 26 30393344 env49132 = env49133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env49132 == env49133) = true)

def env49134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound49134 : H12AffineFastState.Bounded env49134 := by
  intro p hp
  have h : env49134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49133_49134 : H12AffineEnvironment.transform 18 1024 env49133 = env49134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env49133 == env49134) = true)

theorem identity49134 : scanCanonicalize (H12AffineFastState.compose env49134 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493628) := by decide +kernel

theorem selectedBound49134 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493628,16777216,8328,65,23186620,18973837,416237,2149565,19368108,23160257,256,17287185,17246645,19312507]

theorem envBound49135 : H12AffineFastState.Bounded env49135 := by
  intro p hp
  have h : env49135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49134_49135 : H12AffineEnvironment.transform 22 2493628 env49134 = env49135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493628 env49134 == env49135) = true)

def env49136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493628,498992,8328,65,6705548,2496957,416237,2149565,2102684,6748401,256,21793,46213,2175563]

theorem envBound49136 : H12AffineFastState.Bounded env49136 := by
  intro p hp
  have h : env49136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49135_49136 : H12AffineEnvironment.transform 23 498992 env49135 = env49136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env49135 == env49136) = true)

def env49137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493628,498992,8328,65,2396468,2496957,416237,2149565,2102684,2373705,256,21793,46213,2175563]

theorem envBound49137 : H12AffineFastState.Bounded env49137 := by
  intro p hp
  have h : env49137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49136_49137 : H12AffineEnvironment.transform 21 180408 env49136 = env49137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env49136 == env49137) = true)

def env49138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400636,498992,8328,65,295284,395773,416237,56573,1500,272393,256,21793,46213,74251]

theorem envBound49138 : H12AffineFastState.Bounded env49138 := by
  intro p hp
  have h : env49138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49137_49138 : H12AffineEnvironment.transform 20 4160 env49137 = env49138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49137 == env49138) = true)

theorem identity49138 : scanCanonicalize (H12AffineFastState.compose env49138 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,180408,400636,441658,8328,65,295284,395773,416237,56573,1500,272393,256,21793,46213,513]

theorem envBound49139 : H12AffineFastState.Bounded env49139 := by
  intro p hp
  have h : env49139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49138_49139 : H12AffineEnvironment.transform 15 8202 env49138 = env49139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49138 == env49139) = true)

def env49140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,32936,285932,326954,8328,65,295284,281069,268797,56573,1500,272393,256,21793,46213,513]

theorem envBound49140 : H12AffineFastState.Bounded env49140 := by
  intro p hp
  have h : env49140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49139_49140 : H12AffineEnvironment.transform 16 16400 env49139 = env49140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49139 == env49140) = true)

def env49141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,32800,285796,326954,8192,65,295284,280933,268661,56437,1364,272393,256,21793,46093,513]

theorem envBound49141 : H12AffineFastState.Bounded env49141 := by
  intro p hp
  have h : env49141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49140_49141 : H12AffineEnvironment.transform 6 8 env49140 = env49141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49140 == env49141) = true)

def env49142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,32801,285797,326954,8193,65,295284,280932,268660,56436,1365,272393,256,21793,46092,513]

theorem envBound49142 : H12AffineFastState.Bounded env49142 := by
  intro p hp
  have h : env49142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49140_49142 : H12AffineEnvironment.transform 6 9 env49140 = env49142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49140 == env49142) = true)

theorem identity49142 : scanCanonicalize (H12AffineFastState.compose env49142 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound49142 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env49143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,3172,1024,32769,4160,32801,20481,61774,8193,65,36112,17664,5392,56436,1365,9325,256,21793,46092,513]

theorem envBound49143 : H12AffineFastState.Bounded env49143 := by
  intro p hp
  have h : env49143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49142_49143 : H12AffineEnvironment.transform 17 3172 env49142 = env49143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env49142 == env49143) = true)

theorem identity49143 : scanCanonicalize (H12AffineFastState.compose env49143 (packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 20496) := by decide +kernel

theorem selectedBound49143 : packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env49144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,20496,8202,16400,3172,1024,20497,4160,20529,20481,8542,8193,65,23808,17664,5392,3172,1365,9325,256,21793,25628,513]

theorem envBound49144 : H12AffineFastState.Bounded env49144 := by
  intro p hp
  have h : env49144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49143_49144 : H12AffineEnvironment.transform 14 20496 env49143 = env49144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20496 env49143 == env49144) = true)

theorem identity49144 : scanCanonicalize (H12AffineFastState.compose env49144 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound49144 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,8541,8202,12637,3172,1024,8540,4160,8572,8524,8542,8193,65,11341,13389,5392,3172,1365,9325,256,9324,5457,513]

theorem envBound49145 : H12AffineFastState.Bounded env49145 := by
  intro p hp
  have h : env49145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49144_49145 : H12AffineEnvironment.transform 13 12621 env49144 = env49145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env49144 == env49145) = true)

theorem identity49145 : scanCanonicalize (H12AffineFastState.compose env49145 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound49145 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env49146 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,12621,8541,8202,12637,2048,100,8540,4160,8572,8524,8542,8193,65,10281,12329,4468,2048,305,8201,256,8200,4405,513]

theorem envBound49146 : H12AffineFastState.Bounded env49146 := by
  intro p hp
  have h : env49146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49145_49146 : H12AffineEnvironment.transform 9 100 env49145 = env49146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env49145 == env49146) = true)

theorem identity49146 : scanCanonicalize (H12AffineFastState.compose env49146 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49146 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env49147 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,12344,8232,8202,12328,2048,100,8233,4160,8201,8249,8235,8193,65,10281,12329,4097,2048,68,8201,117,8200,4160,513]

theorem envBound49147 : H12AffineFastState.Bounded env49147 := by
  intro p hp
  have h : env49147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49146_49147 : H12AffineEnvironment.transform 7 117 env49146 = env49147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49146 == env49147) = true)

theorem identity49147 : scanCanonicalize (H12AffineFastState.compose env49147 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49147 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env49148 : List Nat := [2,4,8,16,32,64,9,117,512,100,33,4096,8192,12344,8232,8202,12328,33,100,8233,4160,8201,8249,8235,8193,65,8200,12329,4097,33,68,8201,117,8200,4160,513]

theorem envBound49148 : H12AffineFastState.Bounded env49148 := by
  intro p hp
  have h : env49148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49147_49148 : H12AffineEnvironment.transform 10 33 env49147 = env49148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49147 == env49148) = true)

theorem identity49148 : scanCanonicalize (H12AffineFastState.compose env49148 (packedSelected [0,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 4707) := by decide +kernel

theorem selectedBound49148 : packedSelected [0,6,7,8] rootPS < 2^1333 := by decide +kernel

def env49149 : List Nat := [2,4,8,16,32,64,9,117,512,100,33,4096,4707,603,4683,4713,587,33,100,4682,4160,4714,4698,4680,4706,65,4715,586,4097,33,68,4714,117,4715,4160,513]

theorem envBound49149 : H12AffineFastState.Bounded env49149 := by
  intro p hp
  have h : env49149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49148_49149 : H12AffineEnvironment.transform 12 4707 env49148 = env49149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4707 env49148 == env49149) = true)

theorem identity49149 : scanCanonicalize (H12AffineFastState.compose env49149 (packedSelected [0,1,2,3,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49149 : packedSelected [0,1,2,3,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49150 : List Nat := [2,4,8,16,1,64,9,84,512,69,0,4096,4674,603,4683,4680,587,0,69,4682,4160,4683,4698,4680,4675,65,4682,586,4097,0,68,4683,84,4682,4160,513]

theorem envBound49150 : H12AffineFastState.Bounded env49150 := by
  intro p hp
  have h : env49150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49149_49150 : H12AffineEnvironment.transform 4 1 env49149 = env49150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49149 == env49150) = true)

theorem identity49150 : scanCanonicalize (H12AffineFastState.compose env49150 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49151 : List Nat := [2,4,8,16,1,0,9,20,512,5,0,4096,4610,539,4619,4616,523,0,5,4618,4096,4619,4634,4616,4611,1,4618,522,4097,0,4,4619,20,4618,4096,513]

theorem envBound49151 : H12AffineFastState.Bounded env49151 := by
  intro p hp
  have h : env49151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49150_49151 : H12AffineEnvironment.transform 5 0 env49150 = env49151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49150 == env49151) = true)

theorem identity49151 : scanCanonicalize (H12AffineFastState.compose env49151 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound49151 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env49152 : List Nat := [2,4,8,16,1,0,9,20,512,5,0,1,515,539,522,521,523,0,5,523,1,522,539,521,514,1,523,522,0,0,4,522,20,523,1,513]

theorem envBound49152 : H12AffineFastState.Bounded env49152 := by
  intro p hp
  have h : env49152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49151_49152 : H12AffineEnvironment.transform 11 1 env49151 = env49152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49151 == env49152) = true)

theorem identity49152 : scanCanonicalize (H12AffineFastState.compose env49152 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound49152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49153 : List Nat := [2,4,8,16,1,0,9,20,10,5,0,1,9,17,0,3,1,0,5,1,1,0,17,3,8,1,1,0,0,0,4,0,20,1,1,11]

theorem envBound49153 : H12AffineFastState.Bounded env49153 := by
  intro p hp
  have h : env49153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49152_49153 : H12AffineEnvironment.transform 8 10 env49152 = env49153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env49152 == env49153) = true)

def env49154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4160,32937,285933,326955,8328,65,295284,281068,268796,56573,1500,272393,256,21793,46213,513]

theorem envBound49154 : H12AffineFastState.Bounded env49154 := by
  intro p hp
  have h : env49154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49139_49154 : H12AffineEnvironment.transform 16 16401 env49139 = env49154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49139 == env49154) = true)

theorem identity49154 : scanCanonicalize (H12AffineFastState.compose env49154 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23805) := by decide +kernel

theorem selectedBound49154 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,23805,1024,32769,4160,32937,16,41430,8328,65,56713,5393,17665,56573,1500,29940,256,21793,46213,513]

theorem envBound49155 : H12AffineFastState.Bounded env49155 := by
  intro p hp
  have h : env49155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49154_49155 : H12AffineEnvironment.transform 17 23805 env49154 = env49155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23805 env49154 == env49155) = true)

theorem identity49155 : scanCanonicalize (H12AffineFastState.compose env49155 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49155 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16401,23805,1024,0,4160,168,16,8663,8328,65,23944,5393,17665,23804,1500,29940,256,21793,13444,513]

theorem envBound49156 : H12AffineFastState.Bounded env49156 := by
  intro p hp
  have h : env49156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49155_49156 : H12AffineEnvironment.transform 14 1 env49155 = env49156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49155 == env49156) = true)

theorem identity49156 : scanCanonicalize (H12AffineFastState.compose env49156 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49156 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env49157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,1,8202,13389,10401,1024,0,4160,168,16,8663,8328,65,10708,5393,12637,10400,1500,168,256,8573,13444,513]

theorem envBound49157 : H12AffineFastState.Bounded env49157 := by
  intro p hp
  have h : env49157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49156_49157 : H12AffineEnvironment.transform 13 13404 env49156 = env49157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49156 == env49157) = true)

theorem identity49157 : scanCanonicalize (H12AffineFastState.compose env49157 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound49157 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,1,479,5528,2420,1024,0,4160,168,16,2,349,65,2049,5393,4232,2421,1500,168,256,168,5457,513]

theorem envBound49158 : H12AffineFastState.Bounded env49158 := by
  intro p hp
  have h : env49158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49157_49158 : H12AffineEnvironment.transform 12 469 env49157 = env49158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env49157 == env49158) = true)

theorem identity49158 : scanCanonicalize (H12AffineFastState.compose env49158 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound49158 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env49159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,137,469,1280,1,479,1297,2420,1024,0,201,168,16,2,349,65,2049,1432,1,2421,1500,168,256,168,1496,513]

theorem envBound49159 : H12AffineFastState.Bounded env49159 := by
  intro p hp
  have h : env49159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49158_49159 : H12AffineEnvironment.transform 11 137 env49158 = env49159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env49158 == env49159) = true)

theorem identity49159 : scanCanonicalize (H12AffineFastState.compose env49159 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 382) := by decide +kernel

theorem selectedBound49159 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env49160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,382,137,469,1280,1,479,1297,10,1024,0,201,168,16,2,349,65,383,1432,1,11,1500,168,256,168,1496,513]

theorem envBound49160 : H12AffineFastState.Bounded env49160 := by
  intro p hp
  have h : env49160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49159_49160 : H12AffineEnvironment.transform 10 382 env49159 = env49160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 382 env49159 == env49160) = true)

theorem identity49160 : scanCanonicalize (H12AffineFastState.compose env49160 (packedSelected [1,3,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49160 : packedSelected [1,3,11,18] rootPS < 2^1333 := by decide +kernel

def env49161 : List Nat := [2,4,8,16,32,17,128,256,512,1024,303,137,388,1280,1,398,1297,10,1024,0,152,168,16,2,268,16,302,1432,1,11,1421,168,256,168,1417,513]

theorem envBound49161 : H12AffineFastState.Bounded env49161 := by
  intro p hp
  have h : env49161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49160_49161 : H12AffineEnvironment.transform 5 17 env49160 = env49161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49160 == env49161) = true)

theorem identity49161 : scanCanonicalize (H12AffineFastState.compose env49161 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 403) := by decide +kernel

theorem selectedBound49161 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49162 : List Nat := [2,4,8,16,32,17,128,256,512,403,303,137,388,147,1,398,130,10,403,0,152,168,16,2,268,16,302,11,1,11,30,168,256,168,26,513]

theorem envBound49162 : H12AffineFastState.Bounded env49162 := by
  intro p hp
  have h : env49162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49161_49162 : H12AffineEnvironment.transform 9 403 env49161 = env49162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 403 env49161 == env49162) = true)

theorem identity49162 : scanCanonicalize (H12AffineFastState.compose env49162 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound49162 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env49163 : List Nat := [2,4,8,16,32,17,51,256,512,288,303,58,311,32,1,317,49,10,288,0,43,27,16,2,268,16,302,11,1,11,30,27,256,27,26,513]

theorem envBound49163 : H12AffineFastState.Bounded env49163 := by
  intro p hp
  have h : env49163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49162_49163 : H12AffineEnvironment.transform 6 51 env49162 = env49163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env49162 == env49163) = true)

theorem identity49163 : scanCanonicalize (H12AffineFastState.compose env49163 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound49163 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env49164 : List Nat := [2,4,8,16,32,17,51,62,512,30,17,58,9,32,1,3,49,10,30,0,43,27,16,2,50,16,16,11,1,11,30,27,62,27,26,513]

theorem envBound49164 : H12AffineFastState.Bounded env49164 := by
  intro p hp
  have h : env49164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49163_49164 : H12AffineEnvironment.transform 7 62 env49163 = env49164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env49163 == env49164) = true)

theorem identity49164 : scanCanonicalize (H12AffineFastState.compose env49164 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49164 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49165 : List Nat := [2,4,8,16,0,17,19,30,512,30,17,26,9,0,1,3,17,10,30,0,11,27,16,2,18,16,16,11,1,11,30,27,30,27,26,513]

theorem envBound49165 : H12AffineFastState.Bounded env49165 := by
  intro p hp
  have h : env49165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49164_49165 : H12AffineEnvironment.transform 4 0 env49164 = env49165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49164 == env49165) = true)

theorem identity49165 : scanCanonicalize (H12AffineFastState.compose env49165 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound49165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49166 : List Nat := [2,4,8,16,0,17,19,30,4,30,17,26,9,0,1,3,17,10,30,0,11,27,16,2,18,16,16,11,1,11,30,27,30,27,26,5]

theorem envBound49166 : H12AffineFastState.Bounded env49166 := by
  intro p hp
  have h : env49166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49165_49166 : H12AffineEnvironment.transform 8 4 env49165 = env49166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env49165 == env49166) = true)

theorem identity49166 : scanCanonicalize (H12AffineFastState.compose env49166 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49166 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49167 : List Nat := [2,4,8,11,0,10,8,5,4,5,10,1,9,0,1,3,10,10,5,0,11,0,11,2,9,11,11,11,1,11,5,0,5,0,1,5]

theorem envBound49167 : H12AffineFastState.Bounded env49167 := by
  intro p hp
  have h : env49167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49166_49167 : H12AffineEnvironment.transform 3 11 env49166 = env49167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49166 == env49167) = true)

def env49168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400637,498992,8328,65,295285,395772,416237,56572,1501,272392,256,21793,46213,74250]

theorem envBound49168 : H12AffineFastState.Bounded env49168 := by
  intro p hp
  have h : env49168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49137_49168 : H12AffineEnvironment.transform 20 4161 env49137 = env49168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49137 == env49168) = true)

theorem identity49168 : scanCanonicalize (H12AffineFastState.compose env49168 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound49168 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180408,120014,21763,8328,65,215366,115151,102878,56572,1501,254011,256,21793,46213,74250]

theorem envBound49169 : H12AffineFastState.Bounded env49169 := by
  intro p hp
  have h : env49169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49168_49169 : H12AffineEnvironment.transform 17 247859 env49168 = env49169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env49168 == env49169) = true)

def env49170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130175,1024,32769,4161,62708,120014,21763,8328,65,97546,115151,102878,56572,1501,119927,256,21793,46213,74250]

theorem envBound49170 : H12AffineFastState.Bounded env49170 := by
  intro p hp
  have h : env49170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49169_49170 : H12AffineEnvironment.transform 16 13388 env49169 = env49170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env49169 == env49170) = true)

theorem identity49170 : scanCanonicalize (H12AffineFastState.compose env49170 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound49170 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env49171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13388,10401,1024,32769,4161,62708,16,21763,8328,65,43476,5393,17664,56572,1501,169,256,21793,46213,63188]

theorem envBound49171 : H12AffineFastState.Bounded env49171 := by
  intro p hp
  have h : env49171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49170_49171 : H12AffineEnvironment.transform 15 54494 env49170 = env49171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env49170 == env49171) = true)

theorem identity49171 : scanCanonicalize (H12AffineFastState.compose env49171 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49171 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env49172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8323,13388,10401,1024,29788,4161,169,16,21763,8328,65,23945,5393,17664,10401,1501,169,256,21793,16600,649]

theorem envBound49172 : H12AffineFastState.Bounded env49172 := by
  intro p hp
  have h : env49172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49171_49172 : H12AffineEnvironment.transform 14 29789 env49171 = env49172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49171 == env49172) = true)

theorem identity49172 : scanCanonicalize (H12AffineFastState.compose env49172 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound49172 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env49173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8323,13388,10401,1024,8661,4161,169,16,138,8328,65,2048,5393,4233,10401,1501,169,256,168,5457,649]

theorem envBound49173 : H12AffineFastState.Bounded env49173 := by
  intro p hp
  have h : env49173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49172_49173 : H12AffineEnvironment.transform 13 5513 env49172 = env49173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env49172 == env49173) = true)

theorem identity49173 : scanCanonicalize (H12AffineFastState.compose env49173 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49173 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env49174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13388,10281,1024,8541,4161,33,16,2,8192,65,2048,5393,4097,10281,1365,33,256,32,5457,513]

theorem envBound49174 : H12AffineFastState.Bounded env49174 := by
  intro p hp
  have h : env49174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49173_49174 : H12AffineEnvironment.transform 6 8 env49173 = env49174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49173 == env49174) = true)

theorem identity49174 : scanCanonicalize (H12AffineFastState.compose env49174 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49174 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,263,5440,2341,1024,81,4161,33,16,2,268,65,2048,5393,4097,2341,1365,33,256,32,5457,513]

theorem envBound49175 : H12AffineFastState.Bounded env49175 := by
  intro p hp
  have h : env49175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49174_49175 : H12AffineEnvironment.transform 12 268 env49174 = env49175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49174 == env49175) = true)

theorem identity49175 : scanCanonicalize (H12AffineFastState.compose env49175 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49175 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49176 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5156,80,34,5221,2048,1024,81,4161,33,16,2,41,65,2048,5172,4097,2048,1136,33,37,32,5236,513]

theorem envBound49176 : H12AffineFastState.Bounded env49176 := by
  intro p hp
  have h : env49176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49175_49176 : H12AffineEnvironment.transform 7 37 env49175 = env49176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49175 == env49176) = true)

theorem identity49176 : scanCanonicalize (H12AffineFastState.compose env49176 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49176 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env49177 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5172,2048,1024,0,4112,33,16,2,41,16,2048,5172,4097,2048,1057,33,37,32,5157,513]

theorem envBound49177 : H12AffineFastState.Bounded env49177 := by
  intro p hp
  have h : env49177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49176_49177 : H12AffineEnvironment.transform 5 17 env49176 = env49177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49176 == env49177) = true)

theorem identity49177 : scanCanonicalize (H12AffineFastState.compose env49177 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound49177 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49178 : List Nat := [2,4,8,16,32,17,8,37,512,1024,522,4096,41,5156,1,34,5172,522,1024,0,4112,33,16,2,41,16,522,5172,4097,522,1057,33,37,32,5157,513]

theorem envBound49178 : H12AffineFastState.Bounded env49178 := by
  intro p hp
  have h : env49178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49177_49178 : H12AffineEnvironment.transform 10 522 env49177 = env49178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env49177 == env49178) = true)

theorem identity49178 : scanCanonicalize (H12AffineFastState.compose env49178 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49178 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49179 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,4096,9,5124,1,2,5140,522,1024,0,4112,1,16,2,9,16,522,5140,4097,522,1025,1,5,0,5125,513]

theorem envBound49179 : H12AffineFastState.Bounded env49179 := by
  intro p hp
  have h : env49179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49178_49179 : H12AffineEnvironment.transform 4 0 env49178 = env49179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49178 == env49179) = true)

def env49180 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,16,9,1044,1,2,1028,522,1024,0,0,1,16,2,9,16,522,1028,17,522,1025,1,5,0,1045,513]

theorem envBound49180 : H12AffineFastState.Bounded env49180 := by
  intro p hp
  have h : env49180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49179_49180 : H12AffineEnvironment.transform 11 16 env49179 = env49180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49179 == env49180) = true)

theorem identity49180 : scanCanonicalize (H12AffineFastState.compose env49180 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound49180 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49181 : List Nat := [2,4,8,16,0,17,8,5,512,522,522,16,9,542,1,2,526,522,522,0,0,1,16,2,9,16,522,526,17,522,523,1,5,0,543,513]

theorem envBound49181 : H12AffineFastState.Bounded env49181 := by
  intro p hp
  have h : env49181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49180_49181 : H12AffineEnvironment.transform 9 522 env49180 = env49181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env49180 == env49181) = true)

def env49182 : List Nat := [2,4,8,4,0,5,8,5,512,522,522,4,9,522,1,2,526,522,522,0,0,1,4,2,9,4,522,526,5,522,523,1,5,0,523,513]

theorem envBound49182 : H12AffineFastState.Bounded env49182 := by
  intro p hp
  have h : env49182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49181_49182 : H12AffineEnvironment.transform 3 4 env49181 = env49182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env49181 == env49182) = true)

theorem identity49182 : scanCanonicalize (H12AffineFastState.compose env49182 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound49182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49183 : List Nat := [2,4,8,4,0,5,8,5,9,3,3,4,9,3,1,2,7,3,3,0,0,1,4,2,9,4,3,7,5,3,2,1,5,0,2,8]

theorem envBound49183 : H12AffineFastState.Bounded env49183 := by
  intro p hp
  have h : env49183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49182_49183 : H12AffineEnvironment.transform 8 9 env49182 = env49183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env49182 == env49183) = true)

def leafEnv49183 : List Nat := [2,4,8,4,0,5,8,5,9,3,3,4,9,3,1,2,7,3,3,0,0,1,4,2,3,9,1,4,3,7,5,3,2,1,5,0,5,2,2,8,1,1,0]

def active49183 : List Nat := [0,1,2]

def tree49183 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49183 : H12WitnessSearch.Good tree49183 := H12GlobalWitnessIndex.good

theorem leafIdentity49183 : H12AffineFastState.composeSystem env49183 rootObs = leafEnv49183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49183 rootObs == leafEnv49183) = true)

theorem terminalChecked49183 : H12PackedTerminal.terminalCheckFast leafEnv49183 active49183 tree49183 = true := by decide +kernel

def env49184 : List Nat := [2,4,8,5,0,4,8,5,512,522,522,5,9,523,1,2,526,522,522,0,0,1,5,2,9,5,522,526,4,522,523,1,5,0,522,513]

theorem envBound49184 : H12AffineFastState.Bounded env49184 := by
  intro p hp
  have h : env49184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49181_49184 : H12AffineEnvironment.transform 3 5 env49181 = env49184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49181 == env49184) = true)

theorem identity49184 : scanCanonicalize (H12AffineFastState.compose env49184 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49185 : List Nat := [0,4,8,5,0,4,8,5,512,520,520,5,9,521,1,0,524,520,520,0,0,1,5,0,9,5,520,524,4,520,521,1,5,0,520,513]

theorem envBound49185 : H12AffineFastState.Bounded env49185 := by
  intro p hp
  have h : env49185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49184_49185 : H12AffineEnvironment.transform 0 0 env49184 = env49185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49184 == env49185) = true)

def leafEnv49185 : List Nat := [0,4,8,5,0,4,8,5,512,520,520,5,9,521,1,0,524,520,520,0,0,1,5,0,520,9,1,5,520,524,4,520,521,1,5,0,5,0,520,513,1,1,0]

def active49185 : List Nat := [1,2,8]

def tree49185 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49185 : H12WitnessSearch.Good tree49185 := H12GlobalWitnessIndex.good

theorem leafIdentity49185 : H12AffineFastState.composeSystem env49185 rootObs = leafEnv49185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49185 rootObs == leafEnv49185) = true)

theorem terminalChecked49185 : H12PackedTerminal.terminalCheckFast leafEnv49185 active49185 tree49185 = true := by decide +kernel

def env49186 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,17,9,1045,1,2,1029,522,1024,0,1,1,16,2,9,16,522,1029,16,522,1025,1,5,0,1044,513]

theorem envBound49186 : H12AffineFastState.Bounded env49186 := by
  intro p hp
  have h : env49186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49179_49186 : H12AffineEnvironment.transform 11 17 env49179 = env49186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49179 == env49186) = true)

theorem identity49186 : scanCanonicalize (H12AffineFastState.compose env49186 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound49186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49187 : List Nat := [2,4,8,16,0,17,8,5,30,1024,20,17,9,1045,1,2,1029,20,1024,0,1,1,16,2,9,16,20,1029,16,20,1025,1,5,0,1044,31]

theorem envBound49187 : H12AffineFastState.Bounded env49187 := by
  intro p hp
  have h : env49187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49186_49187 : H12AffineEnvironment.transform 8 30 env49186 = env49187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env49186 == env49187) = true)

def env49188 : List Nat := [2,4,8,16,0,17,8,5,30,0,20,17,9,21,1,2,5,20,0,0,1,1,16,2,9,16,20,5,16,20,1,1,5,0,20,31]

theorem envBound49188 : H12AffineFastState.Bounded env49188 := by
  intro p hp
  have h : env49188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49187_49188 : H12AffineEnvironment.transform 9 0 env49187 = env49188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env49187 == env49188) = true)

theorem identity49188 : scanCanonicalize (H12AffineFastState.compose env49188 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound49188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49189 : List Nat := [2,4,8,7,0,6,8,5,9,0,3,6,9,2,1,2,5,3,0,0,1,1,7,2,9,7,3,5,7,3,1,1,5,0,3,8]

theorem envBound49189 : H12AffineFastState.Bounded env49189 := by
  intro p hp
  have h : env49189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49188_49189 : H12AffineEnvironment.transform 3 7 env49188 = env49189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env49188 == env49189) = true)

def leafEnv49189 : List Nat := [2,4,8,7,0,6,8,5,9,0,3,6,9,2,1,2,5,3,0,0,1,1,7,2,0,9,1,7,3,5,7,3,1,1,5,0,5,2,3,8,1,0,0]

def active49189 : List Nat := [0,1,2]

def tree49189 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49189 : H12WitnessSearch.Good tree49189 := H12GlobalWitnessIndex.good

theorem leafIdentity49189 : H12AffineFastState.composeSystem env49189 rootObs = leafEnv49189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49189 rootObs == leafEnv49189) = true)

theorem terminalChecked49189 : H12PackedTerminal.terminalCheckFast leafEnv49189 active49189 tree49189 = true := by decide +kernel

def env49190 : List Nat := [2,4,8,16,0,17,8,5,30,1,20,17,9,20,1,2,4,20,1,0,1,1,16,2,9,16,20,4,16,20,0,1,5,0,21,31]

theorem envBound49190 : H12AffineFastState.Bounded env49190 := by
  intro p hp
  have h : env49190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49187_49190 : H12AffineEnvironment.transform 9 1 env49187 = env49190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env49187 == env49190) = true)

theorem identity49190 : scanCanonicalize (H12AffineFastState.compose env49190 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49191 : List Nat := [0,4,8,16,0,17,8,5,28,1,20,17,9,20,1,0,4,20,1,0,1,1,16,0,9,16,20,4,16,20,0,1,5,0,21,29]

theorem envBound49191 : H12AffineFastState.Bounded env49191 := by
  intro p hp
  have h : env49191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49190_49191 : H12AffineEnvironment.transform 0 0 env49190 = env49191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49190 == env49191) = true)

def leafEnv49191 : List Nat := [0,4,8,16,0,17,8,5,28,1,20,17,9,20,1,0,4,20,1,0,1,1,16,0,1,9,1,16,20,4,16,20,0,1,5,0,5,0,21,29,1,0,0]

def active49191 : List Nat := [1,2,3]

def tree49191 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49191 : H12WitnessSearch.Good tree49191 := H12GlobalWitnessIndex.good

theorem leafIdentity49191 : H12AffineFastState.composeSystem env49191 rootObs = leafEnv49191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49191 rootObs == leafEnv49191) = true)

theorem terminalChecked49191 : H12PackedTerminal.terminalCheckFast leafEnv49191 active49191 tree49191 = true := by decide +kernel

def env49192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4161,62709,120014,21763,8328,65,97547,115151,102878,56572,1501,119926,256,21793,46213,74250]

theorem envBound49192 : H12AffineFastState.Bounded env49192 := by
  intro p hp
  have h : env49192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49169_49192 : H12AffineEnvironment.transform 16 13389 env49169 = env49192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env49169 == env49192) = true)

theorem identity49192 : scanCanonicalize (H12AffineFastState.compose env49192 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49192 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env49193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,67755,1024,29908,4161,32,73755,21763,8328,65,97547,79130,91403,10281,1501,73891,256,21793,16464,74250]

theorem envBound49193 : H12AffineFastState.Bounded env49193 := by
  intro p hp
  have h : env49193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49192_49193 : H12AffineEnvironment.transform 14 29909 env49192 = env49193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49192 == env49193) = true)

theorem identity49193 : scanCanonicalize (H12AffineFastState.compose env49193 (packedSelected [0,1,2,3,6,7,8,10,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 20894) := by decide +kernel

theorem selectedBound49193 : packedSelected [0,1,2,3,6,7,8,10,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,20894,13389,22837,1024,29908,4161,32,29061,21763,8328,65,11413,25732,13461,10281,1501,28989,256,21793,16464,29588]

theorem envBound49194 : H12AffineFastState.Bounded env49194 := by
  intro p hp
  have h : env49194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49193_49194 : H12AffineEnvironment.transform 15 20894 env49193 = env49194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20894 env49193 == env49194) = true)

theorem identity49194 : scanCanonicalize (H12AffineFastState.compose env49194 (packedSelected [3,5,9,11,15,16,18,22,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound49194 : packedSelected [3,5,9,11,15,16,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env49195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6429,16384,19912,20894,3408,22837,1024,19913,4161,32,18584,21763,6549,65,5512,23961,3464,4404,1501,18464,256,21793,16464,19081]

theorem envBound49195 : H12AffineFastState.Bounded env49195 := by
  intro p hp
  have h : env49195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49194_49195 : H12AffineEnvironment.transform 12 6429 env49194 = env49195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env49194 == env49195) = true)

theorem identity49195 : scanCanonicalize (H12AffineFastState.compose env49195 (packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,17,18,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49195 : packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env49196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1213,4096,5536,16384,16757,20894,493,21896,1024,16756,4161,32,17445,21763,5416,65,5512,20772,309,4404,1501,17565,256,21793,16464,17972]

theorem envBound49196 : H12AffineFastState.Bounded env49196 := by
  intro p hp
  have h : env49196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49195_49196 : H12AffineEnvironment.transform 10 1213 env49195 = env49196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env49195 == env49196) = true)

theorem identity49196 : scanCanonicalize (H12AffineFastState.compose env49196 (packedSelected [0,1,2,4,8,9,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound49196 : packedSelected [0,1,2,4,8,9,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env49197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1213,4096,5536,4113,4452,399,493,1433,1024,4453,4161,32,5172,1298,5416,65,5512,309,309,4404,1501,5260,256,1328,4161,5669]

theorem envBound49197 : H12AffineFastState.Bounded env49197 := by
  intro p hp
  have h : env49197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49196_49197 : H12AffineEnvironment.transform 13 4113 env49196 = env49197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env49196 == env49197) = true)

theorem identity49197 : scanCanonicalize (H12AffineFastState.compose env49197 (packedSelected [0,1,2,8,9,11,12,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound49197 : packedSelected [0,1,2,8,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env49198 : List Nat := [2,4,8,16,32,64,128,256,512,189,0,4096,4381,4113,4452,399,493,292,189,4453,4161,32,4233,431,4501,65,4405,309,309,4404,352,4145,256,397,4161,4760]

theorem envBound49198 : H12AffineFastState.Bounded env49198 := by
  intro p hp
  have h : env49198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49197_49198 : H12AffineEnvironment.transform 9 189 env49197 = env49198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env49197 == env49198) = true)

theorem identity49198 : scanCanonicalize (H12AffineFastState.compose env49198 (packedSelected [0,3,5,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound49198 : packedSelected [0,3,5,9,11] rootPS < 2^1333 := by decide +kernel

def env49199 : List Nat := [2,4,8,16,32,64,128,256,512,189,0,65,348,80,293,399,493,292,189,292,0,32,200,431,468,65,372,309,309,373,352,112,256,397,0,729]

theorem envBound49199 : H12AffineFastState.Bounded env49199 := by
  intro p hp
  have h : env49199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49198_49199 : H12AffineEnvironment.transform 11 65 env49198 = env49199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env49198 == env49199) = true)

theorem identity49199 : scanCanonicalize (H12AffineFastState.compose env49199 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49199 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env49200 : List Nat := [2,4,8,16,32,64,9,256,512,52,0,65,348,80,293,262,356,292,52,292,0,32,65,294,349,65,372,309,309,373,352,112,256,260,0,592]

theorem envBound49200 : H12AffineFastState.Bounded env49200 := by
  intro p hp
  have h : env49200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49199_49200 : H12AffineEnvironment.transform 6 9 env49199 = env49200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49199 == env49200) = true)

theorem identity49200 : scanCanonicalize (H12AffineFastState.compose env49200 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49200 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env49201 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,65,41,80,80,115,17,81,52,81,0,32,65,83,40,65,1,64,64,0,21,112,117,113,0,592]

theorem envBound49201 : H12AffineFastState.Bounded env49201 := by
  intro p hp
  have h : env49201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49200_49201 : H12AffineEnvironment.transform 7 117 env49200 = env49201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49200 == env49201) = true)

theorem identity49201 : scanCanonicalize (H12AffineFastState.compose env49201 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49201 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49202 : List Nat := [2,4,8,16,1,64,9,84,512,21,0,65,8,80,80,82,17,81,21,81,0,1,65,83,9,65,1,64,64,0,21,81,84,80,0,592]

theorem envBound49202 : H12AffineFastState.Bounded env49202 := by
  intro p hp
  have h : env49202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49201_49202 : H12AffineEnvironment.transform 4 1 env49201 = env49202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49201 == env49202) = true)

theorem identity49202 : scanCanonicalize (H12AffineFastState.compose env49202 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49202 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49203 : List Nat := [2,4,8,16,1,16,9,4,512,21,0,17,8,0,0,2,17,1,21,1,0,1,17,3,9,17,1,16,16,0,21,1,4,0,0,512]

theorem envBound49203 : H12AffineFastState.Bounded env49203 := by
  intro p hp
  have h : env49203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49202_49203 : H12AffineEnvironment.transform 5 16 env49202 = env49203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49202 == env49203) = true)

theorem identity49203 : scanCanonicalize (H12AffineFastState.compose env49203 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound49203 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49204 : List Nat := [2,4,8,16,1,16,9,4,17,21,0,17,8,0,0,2,17,1,21,1,0,1,17,3,9,17,1,16,16,0,21,1,4,0,0,17]

theorem envBound49204 : H12AffineFastState.Bounded env49204 := by
  intro p hp
  have h : env49204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49203_49204 : H12AffineEnvironment.transform 8 17 env49203 = env49204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env49203 == env49204) = true)

theorem identity49204 : scanCanonicalize (H12AffineFastState.compose env49204 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound49204 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49205 : List Nat := [2,4,6,16,1,16,7,4,17,21,0,17,6,0,0,2,17,1,21,1,0,1,17,3,7,17,1,16,16,0,21,1,4,0,0,17]

theorem envBound49205 : H12AffineFastState.Bounded env49205 := by
  intro p hp
  have h : env49205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49204_49205 : H12AffineEnvironment.transform 2 6 env49204 = env49205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env49204 == env49205) = true)

theorem identity49205 : scanCanonicalize (H12AffineFastState.compose env49205 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49205 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49206 : List Nat := [2,4,6,0,1,0,7,4,1,5,0,1,6,0,0,2,1,1,5,1,0,1,1,3,7,1,1,0,0,0,5,1,4,0,0,1]

theorem envBound49206 : H12AffineFastState.Bounded env49206 := by
  intro p hp
  have h : env49206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49205_49206 : H12AffineEnvironment.transform 3 0 env49205 = env49206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49205 == env49206) = true)

def env49207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493628,498992,8328,65,2396469,2496957,416237,2149565,2102684,2373704,256,21793,46213,2175563]

theorem envBound49207 : H12AffineFastState.Bounded env49207 := by
  intro p hp
  have h : env49207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49136_49207 : H12AffineEnvironment.transform 21 180409 env49136 = env49207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env49136 == env49207) = true)

def env49208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400636,498992,8328,65,295285,395773,416237,56573,1500,272392,256,21793,46213,74251]

theorem envBound49208 : H12AffineFastState.Bounded env49208 := by
  intro p hp
  have h : env49208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49207_49208 : H12AffineEnvironment.transform 20 4160 env49207 = env49208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49207 == env49208) = true)

theorem identity49208 : scanCanonicalize (H12AffineFastState.compose env49208 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound49208 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4160,180409,73754,41430,8328,65,245139,79131,91403,56573,1500,201966,256,21793,46213,74251]

theorem envBound49209 : H12AffineFastState.Bounded env49209 := by
  intro p hp
  have h : env49209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49208_49209 : H12AffineEnvironment.transform 17 212198 env49208 = env49209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env49208 == env49209) = true)

def env49210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67754,1024,32769,4160,62709,73754,41430,8328,65,100831,79131,91403,56573,1500,73890,256,21793,46213,74251]

theorem envBound49210 : H12AffineFastState.Bounded env49210 := by
  intro p hp
  have h : env49210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49209_49210 : H12AffineEnvironment.transform 16 13388 env49209 = env49210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env49209 == env49210) = true)

theorem identity49210 : scanCanonicalize (H12AffineFastState.compose env49210 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 9577) := by decide +kernel

theorem selectedBound49210 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env49211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9577,65536,13388,67754,1024,9576,4160,20892,73754,1215,8328,65,76982,79131,91403,31124,1500,73890,256,21793,4588,74251]

theorem envBound49211 : H12AffineFastState.Bounded env49211 := by
  intro p hp
  have h : env49211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49210_49211 : H12AffineEnvironment.transform 14 9577 env49210 = env49211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9577 env49210 == env49211) = true)

theorem identity49211 : scanCanonicalize (H12AffineFastState.compose env49211 (packedSelected [0,1,3,5,14,15,16,18,19,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 6379) := by decide +kernel

theorem selectedBound49211 : packedSelected [0,1,3,5,14,15,16,18,19,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env49212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9577,6379,13388,4161,1024,9576,4160,20892,14577,1215,8328,65,13405,11760,32224,31124,1500,14409,256,21793,4588,15072]

theorem envBound49212 : H12AffineFastState.Bounded env49212 := by
  intro p hp
  have h : env49212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49211_49212 : H12AffineEnvironment.transform 15 6379 env49211 = env49212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6379 env49211 == env49212) = true)

theorem identity49212 : scanCanonicalize (H12AffineFastState.compose env49212 (packedSelected [5,9,10,11,16,22,24,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 7420) := by decide +kernel

theorem selectedBound49212 : packedSelected [5,9,10,11,16,22,24,26,31] rootPS < 2^1333 := by decide +kernel

def env49213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,7420,9577,6379,13388,4161,1024,9576,4160,3424,14577,1215,8328,65,13405,11760,8476,9576,1500,14409,256,2525,4588,15072]

theorem envBound49213 : H12AffineFastState.Bounded env49213 := by
  intro p hp
  have h : env49213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49212_49213 : H12AffineEnvironment.transform 13 7420 env49212 = env49213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7420 env49212 == env49213) = true)

theorem identity49213 : scanCanonicalize (H12AffineFastState.compose env49213 (packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49213 : packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS < 2^1333 := by decide +kernel

def env49214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,7420,1124,6379,5441,4161,1024,1125,4160,3424,6652,1215,389,65,5456,3325,17,1125,1500,6468,256,2525,4588,7149]

theorem envBound49214 : H12AffineFastState.Bounded env49214 := by
  intro p hp
  have h : env49214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49213_49214 : H12AffineEnvironment.transform 12 269 env49213 = env49214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49213 == env49214) = true)

theorem identity49214 : scanCanonicalize (H12AffineFastState.compose env49214 (packedSelected [5,9,10,11,12,16,22,24] rootPS)) = affineNative (2^(11+1) ^^^ 3545) := by decide +kernel

theorem selectedBound49214 : packedSelected [5,9,10,11,12,16,22,24] rootPS < 2^1333 := by decide +kernel

def env49215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3545,269,293,1124,1330,2200,3480,1024,1125,3481,3424,1061,1215,389,65,2185,3325,17,1125,1500,1181,256,2525,3125,1588]

theorem envBound49215 : H12AffineFastState.Bounded env49215 := by
  intro p hp
  have h : env49215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49214_49215 : H12AffineEnvironment.transform 11 3545 env49214 = env49215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3545 env49214 == env49215) = true)

theorem identity49215 : scanCanonicalize (H12AffineFastState.compose env49215 (packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound49215 : packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env49216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,508,1061,269,293,1124,1330,356,1124,1024,1125,1125,1180,1061,1215,389,65,373,1281,17,1125,1500,1181,256,33,1481,1588]

theorem envBound49216 : H12AffineFastState.Bounded env49216 := by
  intro p hp
  have h : env49216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49215_49216 : H12AffineEnvironment.transform 10 508 env49215 = env49216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env49215 == env49216) = true)

theorem identity49216 : scanCanonicalize (H12AffineFastState.compose env49216 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49216 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env49217 : List Nat := [2,4,8,16,32,64,128,37,512,1024,217,1061,40,0,1124,1047,65,1124,1024,1125,1125,1180,1061,1215,160,65,80,1060,17,1125,1273,1181,37,33,1260,1588]

theorem envBound49217 : H12AffineFastState.Bounded env49217 := by
  intro p hp
  have h : env49217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49216_49217 : H12AffineEnvironment.transform 7 37 env49216 = env49217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49216 == env49217) = true)

theorem identity49217 : scanCanonicalize (H12AffineFastState.compose env49217 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound49217 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env49218 : List Nat := [2,4,8,16,32,64,128,37,512,188,217,153,40,0,216,171,65,216,188,217,217,32,153,3,160,65,80,152,17,217,69,33,37,33,80,648]

theorem envBound49218 : H12AffineFastState.Bounded env49218 := by
  intro p hp
  have h : env49218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49217_49218 : H12AffineEnvironment.transform 9 188 env49217 = env49218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env49217 == env49218) = true)

theorem identity49218 : scanCanonicalize (H12AffineFastState.compose env49218 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound49218 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env49219 : List Nat := [2,4,8,16,32,49,128,37,512,188,168,153,40,0,169,171,48,169,188,168,168,32,153,3,160,48,33,152,17,168,52,33,37,33,33,648]

theorem envBound49219 : H12AffineFastState.Bounded env49219 := by
  intro p hp
  have h : env49219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49218_49219 : H12AffineEnvironment.transform 5 49 env49218 = env49219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env49218 == env49219) = true)

theorem identity49219 : scanCanonicalize (H12AffineFastState.compose env49219 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49219 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49220 : List Nat := [2,4,8,1,32,32,128,37,512,173,168,136,40,0,169,171,33,169,173,168,168,32,136,3,160,33,33,137,0,168,37,33,37,33,33,648]

theorem envBound49220 : H12AffineFastState.Bounded env49220 := by
  intro p hp
  have h : env49220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49219_49220 : H12AffineEnvironment.transform 3 1 env49219 = env49220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49219 == env49220) = true)

theorem identity49220 : scanCanonicalize (H12AffineFastState.compose env49220 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound49220 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49221 : List Nat := [2,4,8,1,32,32,128,37,33,173,168,136,40,0,169,171,33,169,173,168,168,32,136,3,160,33,33,137,0,168,37,33,37,33,33,169]

theorem envBound49221 : H12AffineFastState.Bounded env49221 := by
  intro p hp
  have h : env49221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49220_49221 : H12AffineEnvironment.transform 8 33 env49220 = env49221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env49220 == env49221) = true)

theorem identity49221 : scanCanonicalize (H12AffineFastState.compose env49221 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound49221 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49222 : List Nat := [2,4,8,1,32,32,40,37,33,5,0,32,40,0,1,3,33,1,5,0,0,32,32,3,8,33,33,33,0,0,37,33,37,33,33,1]

theorem envBound49222 : H12AffineFastState.Bounded env49222 := by
  intro p hp
  have h : env49222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49221_49222 : H12AffineEnvironment.transform 6 40 env49221 = env49222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env49221 == env49222) = true)

theorem identity49222 : scanCanonicalize (H12AffineFastState.compose env49222 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49222 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49223 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,1,9,0,1,3,0,1,5,0,0,1,1,3,8,0,0,0,0,0,4,0,4,0,0,1]

theorem envBound49223 : H12AffineFastState.Bounded env49223 := by
  intro p hp
  have h : env49223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49222_49223 : H12AffineEnvironment.transform 4 1 env49222 = env49223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49222 == env49223) = true)

theorem identity49223 : scanCanonicalize (H12AffineFastState.compose env49223 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49224 : List Nat := [2,0,8,1,1,1,9,0,0,1,0,1,9,0,1,3,0,1,1,0,0,1,1,3,8,0,0,0,0,0,0,0,0,0,0,1]

theorem envBound49224 : H12AffineFastState.Bounded env49224 := by
  intro p hp
  have h : env49224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49223_49224 : H12AffineEnvironment.transform 1 0 env49223 = env49224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49223 == env49224) = true)

theorem identity49224 : scanCanonicalize (H12AffineFastState.compose env49224 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49225 : List Nat := [0,0,8,1,1,1,9,0,0,1,0,1,9,0,1,1,0,1,1,0,0,1,1,1,8,0,0,0,0,0,0,0,0,0,0,1]

theorem envBound49225 : H12AffineFastState.Bounded env49225 := by
  intro p hp
  have h : env49225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49224_49225 : H12AffineEnvironment.transform 0 0 env49224 = env49225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49224 == env49225) = true)

theorem identity49225 : scanCanonicalize (H12AffineFastState.compose env49225 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound49225 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49226 : List Nat := [0,0,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1]

theorem envBound49226 : H12AffineFastState.Bounded env49226 := by
  intro p hp
  have h : env49226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49225_49226 : H12AffineEnvironment.transform 2 0 env49225 = env49226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env49225 == env49226) = true)

def env49227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,67755,1024,32769,4160,62708,73754,41430,8328,65,100830,79131,91403,56573,1500,73891,256,21793,46213,74251]

theorem envBound49227 : H12AffineFastState.Bounded env49227 := by
  intro p hp
  have h : env49227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49209_49227 : H12AffineEnvironment.transform 16 13389 env49209 = env49227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env49209 == env49227) = true)

theorem identity49227 : scanCanonicalize (H12AffineFastState.compose env49227 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound49227 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env49228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,40970,13389,43169,1024,32769,4160,62708,32784,41430,8328,65,10708,38161,50433,56573,1500,32937,256,21793,46213,33281]

theorem envBound49228 : H12AffineFastState.Bounded env49228 := by
  intro p hp
  have h : env49228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49227_49228 : H12AffineEnvironment.transform 15 40970 env49227 = env49228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env49227 == env49228) = true)

theorem identity49228 : scanCanonicalize (H12AffineFastState.compose env49228 (packedSelected [0,2,3,6,7,9,11,15,16,17,18,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound49228 : packedSelected [0,2,3,6,7,9,11,15,16,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env49229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,479,13389,2420,1024,8660,4160,21793,8645,3,8328,65,10708,13508,25812,32040,1500,8572,256,21793,5456,9172]

theorem envBound49229 : H12AffineFastState.Bounded env49229 := by
  intro p hp
  have h : env49229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49228_49229 : H12AffineEnvironment.transform 14 8661 env49228 = env49229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env49228 == env49229) = true)

theorem identity49229 : scanCanonicalize (H12AffineFastState.compose env49229 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49229 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,13389,2420,1024,8540,4160,21793,8525,3,8192,65,10588,13388,25692,32040,1364,8572,256,21793,5456,9052]

theorem envBound49230 : H12AffineFastState.Bounded env49230 := by
  intro p hp
  have h : env49230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49229_49230 : H12AffineEnvironment.transform 6 8 env49229 = env49230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49229 == env49230) = true)

theorem identity49230 : scanCanonicalize (H12AffineFastState.compose env49230 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound49230 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env49231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,343,13389,2420,1024,8540,4160,8493,8525,3,8192,65,10588,13388,4176,2340,1364,8572,256,8493,5456,9052]

theorem envBound49231 : H12AffineFastState.Bounded env49231 := by
  intro p hp
  have h : env49231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49230_49231 : H12AffineEnvironment.transform 13 13324 env49230 = env49231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env49230 == env49231) = true)

theorem identity49231 : scanCanonicalize (H12AffineFastState.compose env49231 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49231 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env49232 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8461,263,13341,2340,1024,8460,4112,8493,8477,3,8192,17,10508,13340,4096,2340,1284,8492,256,8493,5376,8972]

theorem envBound49232 : H12AffineFastState.Bounded env49232 := by
  intro p hp
  have h : env49232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49231_49232 : H12AffineEnvironment.transform 5 16 env49231 = env49232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49231 == env49232) = true)

theorem identity49232 : scanCanonicalize (H12AffineFastState.compose env49232 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49232 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49233 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,263,5392,2340,1024,1,4112,32,16,3,269,17,2049,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound49233 : H12AffineFastState.Bounded env49233 := by
  intro p hp
  have h : env49233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49232_49233 : H12AffineEnvironment.transform 12 269 env49232 = env49233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49232 == env49233) = true)

theorem identity49233 : scanCanonicalize (H12AffineFastState.compose env49233 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound49233 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49234 : List Nat := [2,4,8,16,32,16,8,53,512,1024,2048,4096,56,5172,0,50,5157,2065,1024,1,4112,32,16,3,56,17,2049,5156,4096,2065,1073,33,53,32,5173,513]

theorem envBound49234 : H12AffineFastState.Bounded env49234 := by
  intro p hp
  have h : env49234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49233_49234 : H12AffineEnvironment.transform 7 53 env49233 = env49234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env49233 == env49234) = true)

theorem identity49234 : scanCanonicalize (H12AffineFastState.compose env49234 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound49234 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49235 : List Nat := [2,4,8,16,32,16,8,53,512,1024,2048,3119,56,2075,0,50,2058,2065,1024,1,3135,32,16,3,56,17,2049,2059,3119,2065,1073,33,53,32,2074,513]

theorem envBound49235 : H12AffineFastState.Bounded env49235 := by
  intro p hp
  have h : env49235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49234_49235 : H12AffineEnvironment.transform 11 3119 env49234 = env49235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env49234 == env49235) = true)

theorem identity49235 : scanCanonicalize (H12AffineFastState.compose env49235 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49235 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49236 : List Nat := [2,4,8,16,16,16,8,5,512,1024,2048,3103,8,2075,0,2,2058,2065,1024,1,3087,16,16,3,8,17,2049,2059,3103,2065,1025,17,5,16,2074,513]

theorem envBound49236 : H12AffineFastState.Bounded env49236 := by
  intro p hp
  have h : env49236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49235_49236 : H12AffineEnvironment.transform 4 16 env49235 = env49236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49235 == env49236) = true)

theorem identity49236 : scanCanonicalize (H12AffineFastState.compose env49236 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound49236 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49237 : List Nat := [2,4,8,16,16,16,8,5,512,15,2048,2064,8,2075,0,2,2058,2065,15,1,2048,16,16,3,8,17,2049,2059,2064,2065,14,17,5,16,2074,513]

theorem envBound49237 : H12AffineFastState.Bounded env49237 := by
  intro p hp
  have h : env49237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49236_49237 : H12AffineEnvironment.transform 9 15 env49236 = env49237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env49236 == env49237) = true)

theorem identity49237 : scanCanonicalize (H12AffineFastState.compose env49237 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49237 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49238 : List Nat := [2,4,2,16,16,16,2,5,512,5,2048,2064,2,2065,0,2,2048,2065,5,1,2048,16,16,3,2,17,2049,2049,2064,2065,4,17,5,16,2064,513]

theorem envBound49238 : H12AffineFastState.Bounded env49238 := by
  intro p hp
  have h : env49238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49237_49238 : H12AffineEnvironment.transform 2 2 env49237 = env49238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49237 == env49238) = true)

theorem identity49238 : scanCanonicalize (H12AffineFastState.compose env49238 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 518) := by decide +kernel

theorem selectedBound49238 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49239 : List Nat := [2,4,2,16,16,16,2,5,512,5,518,534,2,535,0,2,518,535,5,1,518,16,16,3,2,17,519,519,534,535,4,17,5,16,534,513]

theorem envBound49239 : H12AffineFastState.Bounded env49239 := by
  intro p hp
  have h : env49239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49238_49239 : H12AffineEnvironment.transform 10 518 env49238 = env49239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 518 env49238 == env49239) = true)

def env49240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400637,498992,8328,65,295284,395772,416237,56572,1501,272393,256,21793,46213,74250]

theorem envBound49240 : H12AffineFastState.Bounded env49240 := by
  intro p hp
  have h : env49240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49207_49240 : H12AffineEnvironment.transform 20 4161 env49207 = env49240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49207 == env49240) = true)

theorem identity49240 : scanCanonicalize (H12AffineFastState.compose env49240 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound49240 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,180409,400637,412142,8328,65,295284,395772,416237,56572,1501,272393,256,21793,46213,63188]

theorem envBound49241 : H12AffineFastState.Bounded env49241 := by
  intro p hp
  have h : env49241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49240_49241 : H12AffineEnvironment.transform 15 54494 env49240 = env49241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env49240 == env49241) = true)

def env49242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180273,400501,412006,8192,65,295284,395636,416101,56436,1365,272393,256,21793,46093,63068]

theorem envBound49242 : H12AffineFastState.Bounded env49242 := by
  intro p hp
  have h : env49242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49241_49242 : H12AffineEnvironment.transform 6 8 env49241 = env49242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49241 == env49242) = true)

theorem identity49242 : scanCanonicalize (H12AffineFastState.compose env49242 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound49242 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env49243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,16449,262144,1024,32769,4161,32880,285748,264487,8192,65,295284,280885,268580,56436,1365,272393,256,21793,46093,63068]

theorem envBound49243 : H12AffineFastState.Bounded env49243 := by
  intro p hp
  have h : env49243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49242_49243 : H12AffineEnvironment.transform 16 16449 env49242 = env49243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env49242 == env49243) = true)

theorem identity49243 : scanCanonicalize (H12AffineFastState.compose env49243 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound49243 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env49244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16449,262144,1024,29788,4161,29741,285748,264487,8192,65,292137,280885,268580,10281,1365,272393,256,21793,16464,513]

theorem envBound49244 : H12AffineFastState.Bounded env49244 := by
  intro p hp
  have h : env49244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49243_49244 : H12AffineEnvironment.transform 14 29789 env49243 = env49244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env49243 == env49244) = true)

theorem identity49244 : scanCanonicalize (H12AffineFastState.compose env49244 (packedSelected [2,3,5,6,10,12,15,16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound49244 : packedSelected [2,3,5,6,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env49245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16449,2421,1024,29788,4161,29741,21825,82,8192,65,31836,16448,4177,10281,1365,8572,256,21793,16464,513]

theorem envBound49245 : H12AffineFastState.Bounded env49245 := by
  intro p hp
  have h : env49245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49244_49245 : H12AffineEnvironment.transform 17 2421 env49244 = env49245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env49244 == env49245) = true)

theorem identity49245 : scanCanonicalize (H12AffineFastState.compose env49245 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49245 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49246 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,16401,2341,1024,29708,4113,29741,21777,2,8192,17,31756,16400,4097,10281,1285,8492,256,21793,16384,513]

theorem envBound49246 : H12AffineFastState.Bounded env49246 := by
  intro p hp
  have h : env49246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49245_49246 : H12AffineEnvironment.transform 5 16 env49245 = env49246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49245 == env49246) = true)

theorem identity49246 : scanCanonicalize (H12AffineFastState.compose env49246 (packedSelected [0,2,5,6,8,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49246 : packedSelected [0,2,5,6,8,9,18] rootPS < 2^1333 := by decide +kernel

def env49247 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8203,5393,2341,1024,8460,4113,8493,17,2,8192,17,10508,5392,4097,10281,1285,8492,256,33,5376,513]

theorem envBound49247 : H12AffineFastState.Bounded env49247 := by
  intro p hp
  have h : env49247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49246_49247 : H12AffineEnvironment.transform 13 5376 env49246 = env49247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49246 == env49247) = true)

theorem identity49247 : scanCanonicalize (H12AffineFastState.compose env49247 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49248 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8233,8203,5173,2049,1024,8232,4113,8201,17,2,8192,17,10280,5172,4097,10281,1057,8200,36,33,5156,513]

theorem envBound49248 : H12AffineFastState.Bounded env49248 := by
  intro p hp
  have h : env49248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49247_49248 : H12AffineEnvironment.transform 7 36 env49247 = env49248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49247 == env49248) = true)

theorem identity49248 : scanCanonicalize (H12AffineFastState.compose env49248 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49248 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49249 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,35,5173,2049,1024,0,4113,33,17,2,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound49249 : H12AffineFastState.Bounded env49249 := by
  intro p hp
  have h : env49249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49248_49249 : H12AffineEnvironment.transform 12 40 env49248 = env49249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49248 == env49249) = true)

def env49250 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,1,35,1029,2049,1024,0,33,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound49250 : H12AffineFastState.Bounded env49250 := by
  intro p hp
  have h : env49250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49249_49250 : H12AffineEnvironment.transform 11 48 env49249 = env49250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49249 == env49250) = true)

theorem identity49250 : scanCanonicalize (H12AffineFastState.compose env49250 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound49250 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49251 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,48,40,1044,1,35,1029,2049,1024,0,33,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,48]

theorem envBound49251 : H12AffineFastState.Bounded env49251 := by
  intro p hp
  have h : env49251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49250_49251 : H12AffineEnvironment.transform 8 49 env49250 = env49251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env49250 == env49251) = true)

def env49252 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,40,32,1,35,49,2049,52,0,33,33,17,2,40,17,2048,48,49,2049,21,32,36,33,32,48]

theorem envBound49252 : H12AffineFastState.Bounded env49252 := by
  intro p hp
  have h : env49252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49251_49252 : H12AffineEnvironment.transform 9 52 env49251 = env49252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49251 == env49252) = true)

def env49253 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,40,33,1,35,48,2049,53,0,33,33,17,2,40,17,2048,49,49,2049,20,32,36,33,33,48]

theorem envBound49253 : H12AffineFastState.Bounded env49253 := by
  intro p hp
  have h : env49253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49251_49253 : H12AffineEnvironment.transform 9 53 env49251 = env49253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49251 == env49253) = true)

theorem identity49253 : scanCanonicalize (H12AffineFastState.compose env49253 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49253 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49254 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,43,40,33,1,35,43,2049,46,0,33,33,10,2,40,10,2048,42,42,2049,15,32,36,33,33,43]

theorem envBound49254 : H12AffineFastState.Bounded env49254 := by
  intro p hp
  have h : env49254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49253_49254 : H12AffineEnvironment.transform 3 11 env49253 = env49254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49253 == env49254) = true)

def leafEnv49254 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,43,40,33,1,35,43,2049,46,0,33,33,10,2,15,40,1,10,2048,42,42,2049,15,32,36,33,4,35,33,43,1,33,0]

def active49254 : List Nat := [0,1,2,4,10]

def tree49254 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49254 : H12WitnessSearch.Good tree49254 := H12GlobalWitnessIndex.good

theorem leafIdentity49254 : H12AffineFastState.composeSystem env49254 rootObs = leafEnv49254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49254 rootObs == leafEnv49254) = true)

theorem terminalChecked49254 : H12PackedTerminal.terminalCheckFast leafEnv49254 active49254 tree49254 = true := by decide +kernel

def env49255 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,1,35,1028,2049,1024,0,32,33,17,2,40,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound49255 : H12AffineFastState.Bounded env49255 := by
  intro p hp
  have h : env49255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49249_49255 : H12AffineEnvironment.transform 11 49 env49249 = env49255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49249 == env49255) = true)

theorem identity49255 : scanCanonicalize (H12AffineFastState.compose env49255 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound49255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49256 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,49,40,528,1,35,513,2049,517,0,32,33,17,2,40,17,2048,512,48,2049,548,32,36,33,528,513]

theorem envBound49256 : H12AffineFastState.Bounded env49256 := by
  intro p hp
  have h : env49256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49255_49256 : H12AffineEnvironment.transform 9 517 env49255 = env49256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env49255 == env49256) = true)

def env49257 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,40,32,1,35,49,2049,53,0,32,33,17,2,40,17,2048,48,48,2049,20,32,36,33,32,49]

theorem envBound49257 : H12AffineFastState.Bounded env49257 := by
  intro p hp
  have h : env49257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49256_49257 : H12AffineEnvironment.transform 8 48 env49256 = env49257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49256 == env49257) = true)

theorem identity49257 : scanCanonicalize (H12AffineFastState.compose env49257 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49257 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49258 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,42,40,32,1,35,42,2049,46,0,32,33,10,2,40,10,2048,43,43,2049,15,32,36,33,32,42]

theorem envBound49258 : H12AffineFastState.Bounded env49258 := by
  intro p hp
  have h : env49258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49257_49258 : H12AffineEnvironment.transform 3 11 env49257 = env49258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49257 == env49258) = true)

def leafEnv49258 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,42,40,32,1,35,42,2049,46,0,32,33,10,2,15,40,1,10,2048,43,43,2049,15,32,36,33,4,35,32,42,1,32,0]

def active49258 : List Nat := [0,1,2,4,10]

def tree49258 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49258 : H12WitnessSearch.Good tree49258 := H12GlobalWitnessIndex.good

theorem leafIdentity49258 : H12AffineFastState.composeSystem env49258 rootObs = leafEnv49258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49258 rootObs == leafEnv49258) = true)

theorem terminalChecked49258 : H12PackedTerminal.terminalCheckFast leafEnv49258 active49258 tree49258 = true := by decide +kernel

def env49259 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,40,33,1,35,48,2049,52,0,32,33,17,2,40,17,2048,49,48,2049,21,32,36,33,33,48]

theorem envBound49259 : H12AffineFastState.Bounded env49259 := by
  intro p hp
  have h : env49259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49256_49259 : H12AffineEnvironment.transform 8 49 env49256 = env49259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env49256 == env49259) = true)

def env49260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180272,400500,412007,8193,65,295284,395637,416100,56437,1364,272393,256,21793,46092,63069]

theorem envBound49260 : H12AffineFastState.Bounded env49260 := by
  intro p hp
  have h : env49260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49241_49260 : H12AffineEnvironment.transform 6 9 env49241 = env49260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49241 == env49260) = true)

theorem identity49260 : scanCanonicalize (H12AffineFastState.compose env49260 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound49260 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env49261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,34,131072,262144,1024,21620,4161,136261,400500,412007,8193,65,283905,395637,416100,2048,1364,272393,256,21793,24697,8744]

theorem envBound49261 : H12AffineFastState.Bounded env49261 := by
  intro p hp
  have h : env49261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49260_49261 : H12AffineEnvironment.transform 14 21621 env49260 = env49261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env49260 == env49261) = true)

theorem identity49261 : scanCanonicalize (H12AffineFastState.compose env49261 (packedSelected [2,4,6,7,8,10,11,12,14,15,17,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound49261 : packedSelected [2,4,6,7,8,10,11,12,14,15,17,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env49262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,34,5220,262144,1024,21620,4161,33,264208,285955,8193,65,283905,269585,281856,2048,1364,272393,256,21793,24697,8744]

theorem envBound49262 : H12AffineFastState.Bounded env49262 := by
  intro p hp
  have h : env49262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49261_49262 : H12AffineEnvironment.transform 16 5220 env49261 = env49262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env49261 == env49262) = true)

theorem identity49262 : scanCanonicalize (H12AffineFastState.compose env49262 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound49262 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env49263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,34,5220,23808,1024,21620,4161,33,21776,3,8193,65,2049,16401,4096,2048,1364,29961,256,21793,24697,8744]

theorem envBound49263 : H12AffineFastState.Bounded env49263 := by
  intro p hp
  have h : env49263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49262_49263 : H12AffineEnvironment.transform 17 23808 env49262 = env49263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env49262 == env49263) = true)

theorem identity49263 : scanCanonicalize (H12AffineFastState.compose env49263 (packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound49263 : packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env49264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,0,34,5220,2421,1024,1,4161,33,357,3,8193,65,2049,5220,4096,2048,1364,8572,256,340,13324,8744]

theorem envBound49264 : H12AffineFastState.Bounded env49264 := by
  intro p hp
  have h : env49264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49263_49264 : H12AffineEnvironment.transform 13 5237 env49263 = env49264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env49263 == env49264) = true)

theorem identity49264 : scanCanonicalize (H12AffineFastState.compose env49264 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49264 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env49265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,0,34,5220,2421,1024,1,4161,33,357,3,40,65,2049,5220,4096,2048,1364,341,256,340,5157,513]

theorem envBound49265 : H12AffineFastState.Bounded env49265 := by
  intro p hp
  have h : env49265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49264_49265 : H12AffineEnvironment.transform 12 41 env49264 = env49265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49264 == env49265) = true)

theorem identity49265 : scanCanonicalize (H12AffineFastState.compose env49265 (packedSelected [2,3,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound49265 : packedSelected [2,3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env49266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,41,3345,0,34,3328,2421,1024,1,2341,33,357,3,40,65,2049,3328,2404,2048,1364,341,256,340,3393,513]

theorem envBound49266 : H12AffineFastState.Bounded env49266 := by
  intro p hp
  have h : env49266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49265_49266 : H12AffineEnvironment.transform 11 2404 env49265 = env49266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env49265 == env49266) = true)

theorem identity49266 : scanCanonicalize (H12AffineFastState.compose env49266 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49266 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49267 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2064,41,3173,0,34,3188,2049,1024,1,2129,33,17,3,40,65,2049,3188,2064,2048,1056,33,116,32,3125,513]

theorem envBound49267 : H12AffineFastState.Bounded env49267 := by
  intro p hp
  have h : env49267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49266_49267 : H12AffineEnvironment.transform 7 116 env49266 = env49267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49266 == env49267) = true)

theorem identity49267 : scanCanonicalize (H12AffineFastState.compose env49267 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49267 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49268 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,2064,41,3124,0,34,3109,2049,1024,1,2048,33,17,3,40,16,2049,3109,2064,2048,1056,33,37,32,3125,513]

theorem envBound49268 : H12AffineFastState.Bounded env49268 := by
  intro p hp
  have h : env49268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49267_49268 : H12AffineEnvironment.transform 5 17 env49267 = env49268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49267 == env49268) = true)

theorem identity49268 : scanCanonicalize (H12AffineFastState.compose env49268 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49269 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2064,41,2049,0,34,2064,2049,53,1,2048,33,17,3,40,16,2049,2064,2064,2048,21,33,37,32,2048,513]

theorem envBound49269 : H12AffineFastState.Bounded env49269 := by
  intro p hp
  have h : env49269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49268_49269 : H12AffineEnvironment.transform 9 53 env49268 = env49269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49268 == env49269) = true)

theorem identity49269 : scanCanonicalize (H12AffineFastState.compose env49269 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound49269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49270 : List Nat := [2,4,8,16,32,17,9,37,512,53,513,529,41,512,0,34,529,512,53,1,513,33,17,3,40,16,512,529,529,513,21,33,37,32,513,513]

theorem envBound49270 : H12AffineFastState.Bounded env49270 := by
  intro p hp
  have h : env49270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49269_49270 : H12AffineEnvironment.transform 10 513 env49269 = env49270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env49269 == env49270) = true)

theorem identity49270 : scanCanonicalize (H12AffineFastState.compose env49270 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49271 : List Nat := [2,4,3,16,32,17,2,37,512,53,513,529,34,512,0,34,529,512,53,1,513,33,17,3,35,16,512,529,529,513,21,33,37,32,513,513]

theorem envBound49271 : H12AffineFastState.Bounded env49271 := by
  intro p hp
  have h : env49271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49270_49271 : H12AffineEnvironment.transform 2 3 env49270 = env49271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49270 == env49271) = true)

def env49272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493628,498993,8328,65,6705549,2496956,416237,2149565,2102685,6748400,256,21792,46212,2175562]

theorem envBound49272 : H12AffineFastState.Bounded env49272 := by
  intro p hp
  have h : env49272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49135_49272 : H12AffineEnvironment.transform 23 498993 env49135 = env49272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env49135 == env49272) = true)

def env49273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493628,498993,8328,65,2396469,2496956,416237,2149565,2102685,2373704,256,21792,46212,2175562]

theorem envBound49273 : H12AffineFastState.Bounded env49273 := by
  intro p hp
  have h : env49273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49272_49273 : H12AffineEnvironment.transform 21 180408 env49272 = env49273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env49272 == env49273) = true)

def env49274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400636,498993,8328,65,295285,395772,416237,56573,1501,272392,256,21792,46212,74250]

theorem envBound49274 : H12AffineFastState.Bounded env49274 := by
  intro p hp
  have h : env49274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49273_49274 : H12AffineEnvironment.transform 20 4160 env49273 = env49274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49273 == env49274) = true)

theorem identity49274 : scanCanonicalize (H12AffineFastState.compose env49274 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound49274 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180408,62660,95497,8328,65,158029,57796,45525,56573,1501,180272,256,21792,46212,74250]

theorem envBound49275 : H12AffineFastState.Bounded env49275 := by
  intro p hp
  have h : env49275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49274_49275 : H12AffineEnvironment.transform 17 190520 env49274 = env49275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env49274 == env49275) = true)

theorem identity49275 : scanCanonicalize (H12AffineFastState.compose env49275 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49275 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4160,180408,62660,21762,8328,65,158029,57796,45525,56573,1501,180272,256,21792,46212,513]

theorem envBound49276 : H12AffineFastState.Bounded env49276 := by
  intro p hp
  have h : env49276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49275_49276 : H12AffineEnvironment.transform 15 8203 env49275 = env49276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49275 == env49276) = true)

theorem identity49276 : scanCanonicalize (H12AffineFastState.compose env49276 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49276 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env49277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,131072,138476,1024,29909,4160,144492,16,21762,8328,65,158029,5392,17665,10281,1501,144612,256,21792,16464,513]

theorem envBound49277 : H12AffineFastState.Bounded env49277 := by
  intro p hp
  have h : env49277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49276_49277 : H12AffineEnvironment.transform 14 29908 env49276 = env49277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49276 == env49277) = true)

theorem identity49277 : scanCanonicalize (H12AffineFastState.compose env49277 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound49277 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env49278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,5441,2477,1024,29909,4160,8493,16,21762,8328,65,31756,5392,17665,10281,1501,8613,256,21792,16464,513]

theorem envBound49278 : H12AffineFastState.Bounded env49278 := by
  intro p hp
  have h : env49278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49277_49278 : H12AffineEnvironment.transform 16 5441 env49277 = env49278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env49277 == env49278) = true)

theorem identity49278 : scanCanonicalize (H12AffineFastState.compose env49278 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound49278 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env49279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21840,399,5441,2477,1024,21841,4160,169,16,21762,268,65,23944,5392,17665,2477,1501,33,256,21792,16464,513]

theorem envBound49279 : H12AffineFastState.Bounded env49279 := by
  intro p hp
  have h : env49279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49278_49279 : H12AffineEnvironment.transform 12 388 env49278 = env49279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env49278 == env49279) = true)

theorem identity49279 : scanCanonicalize (H12AffineFastState.compose env49279 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49279 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env49280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,80,399,5441,2477,1024,81,4160,169,16,2,268,65,2184,5392,4097,2477,1501,33,256,32,5456,513]

theorem envBound49280 : H12AffineFastState.Bounded env49280 := by
  intro p hp
  have h : env49280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49279_49280 : H12AffineEnvironment.transform 13 5376 env49279 = env49280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49279 == env49280) = true)

theorem identity49280 : scanCanonicalize (H12AffineFastState.compose env49280 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49280 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5441,2341,1024,81,4160,33,16,2,268,65,2048,5392,4097,2341,1365,33,256,32,5456,513]

theorem envBound49281 : H12AffineFastState.Bounded env49281 := by
  intro p hp
  have h : env49281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49280_49281 : H12AffineEnvironment.transform 6 8 env49280 = env49281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49280 == env49281) = true)

theorem identity49281 : scanCanonicalize (H12AffineFastState.compose env49281 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49281 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49282 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5236,80,115,5173,2129,1024,81,4160,33,16,2,120,65,2048,5220,4097,2129,1057,33,116,32,5156,513]

theorem envBound49282 : H12AffineFastState.Bounded env49282 := by
  intro p hp
  have h : env49282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49281_49282 : H12AffineEnvironment.transform 7 116 env49281 = env49282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49281 == env49282) = true)

theorem identity49282 : scanCanonicalize (H12AffineFastState.compose env49282 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49282 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env49283 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5173,2048,1024,0,4113,33,16,2,41,16,2048,5173,4097,2048,1057,33,37,32,5156,513]

theorem envBound49283 : H12AffineFastState.Bounded env49283 := by
  intro p hp
  have h : env49283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49282_49283 : H12AffineEnvironment.transform 5 17 env49282 = env49283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49282 == env49283) = true)

theorem identity49283 : scanCanonicalize (H12AffineFastState.compose env49283 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound49283 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49284 : List Nat := [2,4,8,16,32,17,8,37,512,1024,523,4096,41,5157,1,34,5173,523,1024,0,4113,33,16,2,41,16,523,5173,4097,523,1057,33,37,32,5156,513]

theorem envBound49284 : H12AffineFastState.Bounded env49284 := by
  intro p hp
  have h : env49284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49283_49284 : H12AffineEnvironment.transform 10 523 env49283 = env49284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env49283 == env49284) = true)

theorem identity49284 : scanCanonicalize (H12AffineFastState.compose env49284 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49284 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49285 : List Nat := [2,4,8,16,1,17,8,4,512,1024,523,4096,8,5124,1,3,5140,523,1024,0,4113,0,16,2,8,16,523,5140,4097,523,1024,0,4,1,5125,513]

theorem envBound49285 : H12AffineFastState.Bounded env49285 := by
  intro p hp
  have h : env49285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49284_49285 : H12AffineEnvironment.transform 4 1 env49284 = env49285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49284 == env49285) = true)

def env49286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400637,498993,8328,65,295284,395773,416237,56572,1500,272393,256,21792,46212,74251]

theorem envBound49286 : H12AffineFastState.Bounded env49286 := by
  intro p hp
  have h : env49286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49273_49286 : H12AffineEnvironment.transform 20 4161 env49273 = env49286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49273 == env49286) = true)

def env49287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180408,144597,242969,8328,65,43356,139733,160197,56572,1500,33,256,21792,46212,74251]

theorem envBound49287 : H12AffineFastState.Bounded env49287 := by
  intro p hp
  have h : env49287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49286_49287 : H12AffineEnvironment.transform 17 10280 env49286 = env49287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49286 == env49287) = true)

def env49288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4161,21928,41413,73737,8328,65,43356,46277,58581,56572,1500,33,256,21792,46212,74251]

theorem envBound49288 : H12AffineFastState.Bounded env49288 := by
  intro p hp
  have h : env49288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49287_49288 : H12AffineEnvironment.transform 16 38160 env49287 = env49288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env49287 == env49288) = true)

theorem identity49288 : scanCanonicalize (H12AffineFastState.compose env49288 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound49288 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13508,10280,1024,8661,4161,21928,17,73737,8328,65,2184,5393,17665,32040,1500,33,256,21792,5456,74251]

theorem envBound49289 : H12AffineFastState.Bounded env49289 := by
  intro p hp
  have h : env49289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49288_49289 : H12AffineEnvironment.transform 14 8660 env49288 = env49289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env49288 == env49289) = true)

theorem identity49289 : scanCanonicalize (H12AffineFastState.compose env49289 (packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 1467) := by decide +kernel

theorem selectedBound49289 : packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS < 2^1333 := by decide +kernel

def env49290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,1467,13508,10280,1024,8661,4161,21928,17,9650,8328,65,2184,5393,17665,32040,1500,33,256,21792,5456,10160]

theorem envBound49290 : H12AffineFastState.Bounded env49290 := by
  intro p hp
  have h : env49290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49289_49290 : H12AffineEnvironment.transform 15 1467 env49289 = env49290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1467 env49289 == env49290) = true)

theorem identity49290 : scanCanonicalize (H12AffineFastState.compose env49290 (packedSelected [1,2,4,6,8,12,15,16,18,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49290 : packedSelected [1,2,4,6,8,12,15,16,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env49291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8660,1467,13508,10280,1024,8661,4161,8692,17,9650,8328,65,2184,5393,12637,2420,1500,33,256,8572,5456,10160]

theorem envBound49291 : H12AffineFastState.Bounded env49291 := by
  intro p hp
  have h : env49291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49290_49291 : H12AffineEnvironment.transform 13 13404 env49290 = env49291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49290 == env49291) = true)

theorem identity49291 : scanCanonicalize (H12AffineFastState.compose env49291 (packedSelected [16,20] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound49291 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49292 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12344,8660,479,12448,10280,100,8661,4161,8692,17,8662,8328,65,2184,4469,12637,2420,440,33,256,8572,4404,9172]

theorem envBound49292 : H12AffineFastState.Bounded env49292 := by
  intro p hp
  have h : env49292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49291_49292 : H12AffineEnvironment.transform 9 100 env49291 = env49292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env49291 == env49292) = true)

theorem identity49292 : scanCanonicalize (H12AffineFastState.compose env49292 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49292 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49293 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,40,4112,508,479,4232,2048,100,509,4161,476,17,510,160,65,2184,4469,4469,2420,440,33,256,340,4404,1020]

theorem envBound49293 : H12AffineFastState.Bounded env49293 := by
  intro p hp
  have h : env49293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49292_49293 : H12AffineEnvironment.transform 12 40 env49292 = env49293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49292 == env49293) = true)

theorem identity49293 : scanCanonicalize (H12AffineFastState.compose env49293 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound49293 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49294 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,4096,40,4112,293,262,4177,2048,100,292,4161,261,17,295,121,65,2129,4469,4469,2420,353,33,256,340,4404,805]

theorem envBound49294 : H12AffineFastState.Bounded env49294 := by
  intro p hp
  have h : env49294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49293_49294 : H12AffineEnvironment.transform 6 89 env49293 = env49294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env49293 == env49294) = true)

theorem identity49294 : scanCanonicalize (H12AffineFastState.compose env49294 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49294 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49295 : List Nat := [2,4,8,16,32,64,89,116,512,100,2048,4096,40,4112,81,114,4177,2048,100,80,4161,113,17,83,121,65,2129,4097,4097,2048,21,33,116,32,4160,593]

theorem envBound49295 : H12AffineFastState.Bounded env49295 := by
  intro p hp
  have h : env49295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49294_49295 : H12AffineEnvironment.transform 7 116 env49294 = env49295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49294 == env49295) = true)

theorem identity49295 : scanCanonicalize (H12AffineFastState.compose env49295 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49295 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49296 : List Nat := [2,4,8,16,1,64,89,85,512,69,2048,4096,9,4112,81,83,4177,2048,69,80,4161,80,17,83,88,65,2129,4097,4097,2048,21,0,85,1,4160,593]

theorem envBound49296 : H12AffineFastState.Bounded env49296 := by
  intro p hp
  have h : env49296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49295_49296 : H12AffineEnvironment.transform 4 1 env49295 = env49296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49295 == env49296) = true)

theorem identity49296 : scanCanonicalize (H12AffineFastState.compose env49296 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound49296 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env49297 : List Nat := [2,4,8,16,1,64,89,85,512,69,2048,2113,9,2129,81,83,2064,2048,69,80,2048,80,17,83,88,65,2129,2112,2112,2048,21,0,85,1,2049,593]

theorem envBound49297 : H12AffineFastState.Bounded env49297 := by
  intro p hp
  have h : env49297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49296_49297 : H12AffineEnvironment.transform 11 2113 env49296 = env49297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env49296 == env49297) = true)

theorem identity49297 : scanCanonicalize (H12AffineFastState.compose env49297 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49297 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env49298 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,9,2048,0,2,2064,2048,20,1,2048,1,17,2,9,16,2048,2065,2065,2048,21,0,4,1,2049,512]

theorem envBound49298 : H12AffineFastState.Bounded env49298 := by
  intro p hp
  have h : env49298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49297_49298 : H12AffineEnvironment.transform 5 17 env49297 = env49298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49297 == env49298) = true)

def env49299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4161,21929,41412,73736,8328,65,43356,46276,58580,56572,1500,33,256,21792,46212,74251]

theorem envBound49299 : H12AffineFastState.Bounded env49299 := by
  intro p hp
  have h : env49299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49287_49299 : H12AffineEnvironment.transform 16 38161 env49287 = env49299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env49287 == env49299) = true)

theorem identity49299 : scanCanonicalize (H12AffineFastState.compose env49299 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49299 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,13388,10280,1024,8540,4161,21929,153,73736,8328,65,2049,5529,17801,32161,1500,33,256,21792,5593,74251]

theorem envBound49300 : H12AffineFastState.Bounded env49300 := by
  intro p hp
  have h : env49300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49299_49300 : H12AffineEnvironment.transform 14 8541 env49299 = env49300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49299 == env49300) = true)

theorem identity49300 : scanCanonicalize (H12AffineFastState.compose env49300 (packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8402) := by decide +kernel

theorem selectedBound49300 : packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8402,13388,10280,1024,8540,4161,21929,153,218,8328,65,2049,5529,17801,32161,1500,33,256,21792,5593,729]

theorem envBound49301 : H12AffineFastState.Bounded env49301 := by
  intro p hp
  have h : env49301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49300_49301 : H12AffineEnvironment.transform 15 8402 env49300 = env49301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8402 env49300 == env49301) = true)

theorem identity49301 : scanCanonicalize (H12AffineFastState.compose env49301 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound49301 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env49302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1336,16384,1125,1514,4468,3344,1024,1124,4161,21929,153,218,1456,65,2049,5529,17801,22681,1500,33,256,21792,5593,729]

theorem envBound49302 : H12AffineFastState.Bounded env49302 := by
  intro p hp
  have h : env49302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49301_49302 : H12AffineEnvironment.transform 12 1336 env49301 = env49302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env49301 == env49302) = true)

theorem identity49302 : scanCanonicalize (H12AffineFastState.compose env49302 (packedSelected [1,3,8,10,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49302 : packedSelected [1,3,8,10,16,20,24] rootPS < 2^1333 := by decide +kernel

def env49303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1336,4112,1125,1514,4468,3344,1024,1124,4161,1465,153,218,1456,65,2049,5529,5529,2185,1500,33,256,1328,5593,729]

theorem envBound49303 : H12AffineFastState.Bounded env49303 := by
  intro p hp
  have h : env49303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49302_49303 : H12AffineEnvironment.transform 13 4112 env49302 = env49303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49302 == env49303) = true)

theorem identity49303 : scanCanonicalize (H12AffineFastState.compose env49303 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49303 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env49304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4112,1125,1378,4468,3344,1024,1124,4161,1329,17,82,1336,65,2049,5393,5393,2049,1364,33,256,1328,5457,593]

theorem envBound49304 : H12AffineFastState.Bounded env49304 := by
  intro p hp
  have h : env49304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49303_49304 : H12AffineEnvironment.transform 6 8 env49303 = env49304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49303 == env49304) = true)

theorem identity49304 : scanCanonicalize (H12AffineFastState.compose env49304 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49304 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49305 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,1053,4112,1125,1095,4177,3125,1024,1124,4161,1044,17,82,1053,65,2049,5172,5172,2049,1137,33,37,1045,5236,593]

theorem envBound49305 : H12AffineFastState.Bounded env49305 := by
  intro p hp
  have h : env49305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49304_49305 : H12AffineEnvironment.transform 7 37 env49304 = env49305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49304 == env49305) = true)

theorem identity49305 : scanCanonicalize (H12AffineFastState.compose env49305 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49305 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49306 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,120,4112,0,34,4177,2128,101,1,4161,113,17,82,120,65,2049,4177,4177,2049,20,33,37,112,4113,593]

theorem envBound49306 : H12AffineFastState.Bounded env49306 := by
  intro p hp
  have h : env49306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49305_49306 : H12AffineEnvironment.transform 9 101 env49305 = env49306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49305 == env49306) = true)

theorem identity49306 : scanCanonicalize (H12AffineFastState.compose env49306 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound49306 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49307 : List Nat := [2,4,8,16,32,64,8,37,512,101,113,4096,120,4112,0,34,4177,33,101,1,4161,113,17,82,120,65,112,4177,4177,112,20,33,37,112,4113,593]

theorem envBound49307 : H12AffineFastState.Bounded env49307 := by
  intro p hp
  have h : env49307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49306_49307 : H12AffineEnvironment.transform 10 113 env49306 = env49307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env49306 == env49307) = true)

theorem identity49307 : scanCanonicalize (H12AffineFastState.compose env49307 (packedSelected [0,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound49307 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env49308 : List Nat := [2,4,8,16,32,64,8,37,512,101,113,64,120,80,0,34,17,33,101,1,1,113,17,82,120,65,112,17,17,112,20,33,37,112,81,593]

theorem envBound49308 : H12AffineFastState.Bounded env49308 := by
  intro p hp
  have h : env49308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49307_49308 : H12AffineEnvironment.transform 11 64 env49307 = env49308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env49307 == env49308) = true)

def env49309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180408,144596,242968,8328,65,43357,139732,160196,56572,1500,32,256,21792,46212,74251]

theorem envBound49309 : H12AffineFastState.Bounded env49309 := by
  intro p hp
  have h : env49309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49286_49309 : H12AffineEnvironment.transform 17 10281 env49286 = env49309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49286 == env49309) = true)

def env49310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,21928,41412,73736,8328,65,43357,46276,58580,56572,1500,32,256,21792,46212,74251]

theorem envBound49310 : H12AffineFastState.Bounded env49310 := by
  intro p hp
  have h : env49310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49309_49310 : H12AffineEnvironment.transform 16 38160 env49309 = env49310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env49309 == env49310) = true)

theorem identity49310 : scanCanonicalize (H12AffineFastState.compose env49310 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49310 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,21792,41292,73736,8192,65,43357,46156,58460,56436,1364,32,256,21792,46092,74251]

theorem envBound49311 : H12AffineFastState.Bounded env49311 := by
  intro p hp
  have h : env49311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49310_49311 : H12AffineEnvironment.transform 6 8 env49310 = env49311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49310 == env49311) = true)

theorem identity49311 : scanCanonicalize (H12AffineFastState.compose env49311 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound49311 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,38160,10281,1024,32769,4161,21792,41292,32771,8192,65,43357,46156,58460,56436,1364,32,256,21792,46092,33280]

theorem envBound49312 : H12AffineFastState.Bounded env49312 := by
  intro p hp
  have h : env49312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49311_49312 : H12AffineEnvironment.transform 15 40971 env49311 = env49312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env49311 == env49312) = true)

theorem identity49312 : scanCanonicalize (H12AffineFastState.compose env49312 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49312 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,5393,10281,1024,0,4161,21792,8525,2,8192,65,10588,13389,25693,23669,1364,32,256,21792,13325,513]

theorem envBound49313 : H12AffineFastState.Bounded env49313 := by
  intro p hp
  have h : env49313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49312_49313 : H12AffineEnvironment.transform 14 1 env49312 = env49313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49312 == env49313) = true)

theorem identity49313 : scanCanonicalize (H12AffineFastState.compose env49313 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49313 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env49314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,5393,10281,1024,0,4161,8572,8525,2,8192,65,10588,13389,4097,10281,1364,32,256,8572,13325,513]

theorem envBound49314 : H12AffineFastState.Bounded env49314 := by
  intro p hp
  have h : env49314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49313_49314 : H12AffineEnvironment.transform 13 13404 env49313 = env49314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49313 == env49314) = true)

theorem identity49314 : scanCanonicalize (H12AffineFastState.compose env49314 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49314 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env49315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,262,5393,2341,1024,0,4161,112,65,2,268,65,2128,5441,4097,2341,1364,32,256,112,5377,513]

theorem envBound49315 : H12AffineFastState.Bounded env49315 := by
  intro p hp
  have h : env49315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49314_49315 : H12AffineEnvironment.transform 12 268 env49314 = env49315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49314 == env49315) = true)

theorem identity49315 : scanCanonicalize (H12AffineFastState.compose env49315 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49315 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49316 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1024,0,4112,33,16,2,268,16,2049,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound49316 : H12AffineFastState.Bounded env49316 := by
  intro p hp
  have h : env49316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49315_49316 : H12AffineEnvironment.transform 5 17 env49315 = env49316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49315 == env49316) = true)

theorem identity49316 : scanCanonicalize (H12AffineFastState.compose env49316 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound49316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49317 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,277,268,1044,1,262,1028,2341,1024,0,261,33,16,2,268,16,2049,1029,276,2341,1285,32,256,33,1044,513]

theorem envBound49317 : H12AffineFastState.Bounded env49317 := by
  intro p hp
  have h : env49317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49316_49317 : H12AffineEnvironment.transform 11 277 env49316 = env49317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env49316 == env49317) = true)

theorem identity49317 : scanCanonicalize (H12AffineFastState.compose env49317 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound49317 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49318 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,277,268,0,1,262,16,2341,20,0,261,33,16,2,268,16,2049,17,276,2341,273,32,256,33,0,513]

theorem envBound49318 : H12AffineFastState.Bounded env49318 := by
  intro p hp
  have h : env49318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49317_49318 : H12AffineEnvironment.transform 9 20 env49317 = env49318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env49317 == env49318) = true)

theorem identity49318 : scanCanonicalize (H12AffineFastState.compose env49318 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound49318 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49319 : List Nat := [2,4,8,16,32,17,8,256,260,20,2048,277,268,0,1,262,16,2341,20,0,261,33,16,2,268,16,2049,17,276,2341,273,32,256,33,0,261]

theorem envBound49319 : H12AffineFastState.Bounded env49319 := by
  intro p hp
  have h : env49319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49318_49319 : H12AffineEnvironment.transform 8 260 env49318 = env49319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env49318 == env49319) = true)

theorem identity49319 : scanCanonicalize (H12AffineFastState.compose env49319 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49319 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49320 : List Nat := [2,4,8,16,32,17,8,256,260,20,48,277,268,0,1,262,16,277,20,0,261,33,16,2,268,16,49,17,276,277,273,32,256,33,0,261]

theorem envBound49320 : H12AffineFastState.Bounded env49320 := by
  intro p hp
  have h : env49320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49319_49320 : H12AffineEnvironment.transform 10 48 env49319 = env49320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49319 == env49320) = true)

theorem identity49320 : scanCanonicalize (H12AffineFastState.compose env49320 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49320 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49321 : List Nat := [2,4,8,16,17,17,8,256,260,20,1,277,268,0,1,262,16,277,20,0,261,16,16,2,268,16,0,17,276,277,273,17,256,16,0,261]

theorem envBound49321 : H12AffineFastState.Bounded env49321 := by
  intro p hp
  have h : env49321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49320_49321 : H12AffineEnvironment.transform 4 17 env49320 = env49321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49320 == env49321) = true)

theorem identity49321 : scanCanonicalize (H12AffineFastState.compose env49321 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49321 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49322 : List Nat := [2,4,8,16,17,17,8,5,1,20,1,16,9,0,1,3,16,16,20,0,0,16,16,2,9,16,0,17,17,16,20,17,5,16,0,0]

theorem envBound49322 : H12AffineFastState.Bounded env49322 := by
  intro p hp
  have h : env49322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49321_49322 : H12AffineEnvironment.transform 7 5 env49321 = env49322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49321 == env49322) = true)

theorem identity49322 : scanCanonicalize (H12AffineFastState.compose env49322 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49322 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49323 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,1,9,0,1,3,1,1,5,0,0,1,1,2,9,1,0,0,0,1,5,0,5,1,0,0]

theorem envBound49323 : H12AffineFastState.Bounded env49323 := by
  intro p hp
  have h : env49323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49322_49323 : H12AffineEnvironment.transform 3 1 env49322 = env49323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49322 == env49323) = true)

def env49324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,21929,41413,73737,8328,65,43357,46277,58581,56572,1500,32,256,21792,46212,74251]

theorem envBound49324 : H12AffineFastState.Bounded env49324 := by
  intro p hp
  have h : env49324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49309_49324 : H12AffineEnvironment.transform 16 38161 env49309 = env49324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env49309 == env49324) = true)

def env49325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,65536,38161,10281,1024,32769,4161,8573,41413,73737,8328,65,43357,46277,36865,43048,1500,32,256,8692,46212,74251]

theorem envBound49325 : H12AffineFastState.Bounded env49325 := by
  intro p hp
  have h : env49325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49324_49325 : H12AffineEnvironment.transform 13 13524 env49324 = env49325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env49324 == env49325) = true)

theorem identity49325 : scanCanonicalize (H12AffineFastState.compose env49325 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49325 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env49326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,38161,10281,1024,32769,4161,8573,41413,3,8328,65,43357,46277,36865,43048,1500,32,256,8692,46212,513]

theorem envBound49326 : H12AffineFastState.Bounded env49326 := by
  intro p hp
  have h : env49326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49325_49326 : H12AffineEnvironment.transform 15 8202 env49325 = env49326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49325 == env49326) = true)

theorem identity49326 : scanCanonicalize (H12AffineFastState.compose env49326 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound49326 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8661,8202,13508,10281,1024,8660,4161,8573,16,3,8328,65,2184,5392,12756,2557,1500,32,256,8692,5457,513]

theorem envBound49327 : H12AffineFastState.Bounded env49327 := by
  intro p hp
  have h : env49327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49326_49327 : H12AffineEnvironment.transform 14 8661 env49326 = env49327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env49326 == env49327) = true)

theorem identity49327 : scanCanonicalize (H12AffineFastState.compose env49327 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49327 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,8202,13388,10281,1024,8540,4161,8573,16,3,8192,65,2048,5392,12636,2421,1364,32,256,8572,5457,513]

theorem envBound49328 : H12AffineFastState.Bounded env49328 := by
  intro p hp
  have h : env49328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49327_49328 : H12AffineEnvironment.transform 6 8 env49327 = env49328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49327 == env49328) = true)

theorem identity49328 : scanCanonicalize (H12AffineFastState.compose env49328 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49328 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5393,2420,1024,1,4161,32,16,3,349,65,2048,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound49329 : H12AffineFastState.Bounded env49329 := by
  intro p hp
  have h : env49329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49328_49329 : H12AffineEnvironment.transform 12 349 env49328 = env49329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49328 == env49329) = true)

theorem identity49329 : scanCanonicalize (H12AffineFastState.compose env49329 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound49329 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,349,1296,0,343,1280,2420,1024,1,80,32,16,3,349,65,2048,1281,16,2421,1364,32,256,33,1344,513]

theorem envBound49330 : H12AffineFastState.Bounded env49330 := by
  intro p hp
  have h : env49330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49329_49330 : H12AffineEnvironment.transform 11 17 env49329 = env49330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49329 == env49330) = true)

theorem identity49330 : scanCanonicalize (H12AffineFastState.compose env49330 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49330 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,17,349,1296,0,343,1280,1345,1024,1,80,32,16,3,349,65,1077,1281,16,1344,1364,32,256,33,1344,513]

theorem envBound49331 : H12AffineFastState.Bounded env49331 := by
  intro p hp
  have h : env49331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49330_49331 : H12AffineEnvironment.transform 10 1077 env49330 = env49331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env49330 == env49331) = true)

theorem identity49331 : scanCanonicalize (H12AffineFastState.compose env49331 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49331 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49332 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,17,268,1296,0,262,1280,1296,1024,1,1,32,16,3,268,16,1077,1281,16,1297,1285,32,256,33,1297,513]

theorem envBound49332 : H12AffineFastState.Bounded env49332 := by
  intro p hp
  have h : env49332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49331_49332 : H12AffineEnvironment.transform 5 17 env49331 = env49332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49331 == env49332) = true)

theorem identity49332 : scanCanonicalize (H12AffineFastState.compose env49332 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49333 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1077,17,41,1077,0,35,1061,1077,1024,1,1,32,16,3,41,16,1077,1060,16,1076,1056,32,37,33,1076,513]

theorem envBound49333 : H12AffineFastState.Bounded env49333 := by
  intro p hp
  have h : env49333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49332_49333 : H12AffineEnvironment.transform 7 37 env49332 = env49333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49332 == env49333) = true)

theorem identity49333 : scanCanonicalize (H12AffineFastState.compose env49333 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49333 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49334 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,17,41,0,0,35,16,0,53,1,1,32,16,3,41,16,0,17,16,1,21,32,37,33,1,513]

theorem envBound49334 : H12AffineFastState.Bounded env49334 := by
  intro p hp
  have h : env49334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49333_49334 : H12AffineEnvironment.transform 9 53 env49333 = env49334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49333 == env49334) = true)

theorem identity49334 : scanCanonicalize (H12AffineFastState.compose env49334 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49335 : List Nat := [2,4,8,1,32,0,8,37,512,36,0,0,41,0,0,35,1,0,36,1,1,32,1,3,41,1,0,0,1,1,4,32,37,33,1,513]

theorem envBound49335 : H12AffineFastState.Bounded env49335 := by
  intro p hp
  have h : env49335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49334_49335 : H12AffineEnvironment.transform 3 1 env49334 = env49335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49334 == env49335) = true)

theorem identity49335 : scanCanonicalize (H12AffineFastState.compose env49335 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49336 : List Nat := [2,4,8,1,32,0,8,37,43,36,0,0,41,0,0,35,1,0,36,1,1,32,1,3,41,1,0,0,1,1,4,32,37,33,1,42]

theorem envBound49336 : H12AffineFastState.Bounded env49336 := by
  intro p hp
  have h : env49336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49335_49336 : H12AffineEnvironment.transform 8 43 env49335 = env49336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49335 == env49336) = true)

def env49337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,38161,10281,1024,32769,4161,8572,41413,73737,8328,65,43357,46277,36864,43049,1500,32,256,8693,46212,74251]

theorem envBound49337 : H12AffineFastState.Bounded env49337 := by
  intro p hp
  have h : env49337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49324_49337 : H12AffineEnvironment.transform 13 13525 env49324 = env49337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env49324 == env49337) = true)

theorem identity49337 : scanCanonicalize (H12AffineFastState.compose env49337 (packedSelected [3,4,5,7,9,10,14,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound49337 : packedSelected [3,4,5,7,9,10,14,27,35] rootPS < 2^1333 := by decide +kernel

def env49338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,41090,38161,10281,1024,32769,4161,8572,41413,32907,8328,65,43357,46277,36864,43049,1500,32,256,8693,46212,33417]

theorem envBound49338 : H12AffineFastState.Bounded env49338 := by
  intro p hp
  have h : env49338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49337_49338 : H12AffineEnvironment.transform 15 41090 env49337 = env49338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env49337 == env49338) = true)

theorem identity49338 : scanCanonicalize (H12AffineFastState.compose env49338 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49338 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env49339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,32768,33247,38161,2420,1024,32769,4161,33,32920,32907,469,65,34816,38296,36864,35188,1500,32,256,168,38361,33417]

theorem envBound49339 : H12AffineFastState.Bounded env49339 := by
  intro p hp
  have h : env49339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49338_49339 : H12AffineEnvironment.transform 12 349 env49338 = env49339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49338 == env49339) = true)

theorem identity49339 : scanCanonicalize (H12AffineFastState.compose env49339 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49339 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,1,478,5392,2420,1024,0,4161,33,153,138,469,65,2049,5529,4097,2421,1500,32,256,168,5592,648]

theorem envBound49340 : H12AffineFastState.Bounded env49340 := by
  intro p hp
  have h : env49340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49339_49340 : H12AffineEnvironment.transform 14 1 env49339 = env49340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49339 == env49340) = true)

def env49341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493628,498993,8328,65,2396468,2496956,416237,2149565,2102685,2373705,256,21792,46212,2175562]

theorem envBound49341 : H12AffineFastState.Bounded env49341 := by
  intro p hp
  have h : env49341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49272_49341 : H12AffineEnvironment.transform 21 180409 env49272 = env49341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env49272 == env49341) = true)

def env49342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400636,498993,8328,65,295284,395772,416237,56573,1501,272393,256,21792,46212,74250]

theorem envBound49342 : H12AffineFastState.Bounded env49342 := by
  intro p hp
  have h : env49342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49341_49342 : H12AffineEnvironment.transform 20 4160 env49341 = env49342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49341 == env49342) = true)

theorem identity49342 : scanCanonicalize (H12AffineFastState.compose env49342 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49342 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,144493,400636,485861,8328,65,292256,395772,416237,10281,1501,272393,256,21792,16464,74250]

theorem envBound49343 : H12AffineFastState.Bounded env49343 := by
  intro p hp
  have h : env49343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49342_49343 : H12AffineEnvironment.transform 14 29908 env49342 = env49343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49342 == env49343) = true)

def env49344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144493,400500,485741,8192,65,292136,395636,416101,10281,1365,272393,256,21792,16464,74250]

theorem envBound49344 : H12AffineFastState.Bounded env49344 := by
  intro p hp
  have h : env49344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49343_49344 : H12AffineEnvironment.transform 6 8 env49343 = env49344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49343 == env49344) = true)

theorem identity49344 : scanCanonicalize (H12AffineFastState.compose env49344 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound49344 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env49345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5440,262144,1024,29789,4160,8493,264500,359469,8192,65,292136,269364,281637,10281,1365,272393,256,21792,16464,74250]

theorem envBound49345 : H12AffineFastState.Bounded env49345 := by
  intro p hp
  have h : env49345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49344_49345 : H12AffineEnvironment.transform 16 5440 env49344 = env49345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env49344 == env49345) = true)

theorem identity49345 : scanCanonicalize (H12AffineFastState.compose env49345 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound49345 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5440,89459,1024,29789,4160,8493,87111,8542,8192,65,75867,82247,69974,10281,1365,95610,256,21792,16464,74250]

theorem envBound49346 : H12AffineFastState.Bounded env49346 := by
  intro p hp
  have h : env49346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49345_49346 : H12AffineEnvironment.transform 17 89459 env49345 = env49346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env49345 == env49346) = true)

theorem identity49346 : scanCanonicalize (H12AffineFastState.compose env49346 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49346 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env49347 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,5392,89379,1024,29709,4112,8493,87063,8462,8192,17,75787,82199,69894,10281,1285,95530,256,21792,16384,74250]

theorem envBound49347 : H12AffineFastState.Bounded env49347 := by
  intro p hp
  have h : env49347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49346_49347 : H12AffineEnvironment.transform 5 16 env49346 = env49347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49346 == env49347) = true)

theorem identity49347 : scanCanonicalize (H12AffineFastState.compose env49347 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound49347 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env49348 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,29962,5392,10281,1024,29709,4112,8493,8477,8462,8192,17,23809,13341,25612,10281,1285,32,256,21792,16384,22272]

theorem envBound49348 : H12AffineFastState.Bounded env49348 := by
  intro p hp
  have h : env49348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49347_49348 : H12AffineEnvironment.transform 15 29962 env49347 = env49348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env49347 == env49348) = true)

theorem identity49348 : scanCanonicalize (H12AffineFastState.compose env49348 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49348 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49349 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,5392,10281,1024,8460,4112,8493,8477,8462,8192,17,2048,13341,12557,10281,1285,32,256,33,5377,513]

theorem envBound49349 : H12AffineFastState.Bounded env49349 := by
  intro p hp
  have h : env49349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49348_49349 : H12AffineEnvironment.transform 13 5377 env49348 = env49349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49348 == env49349) = true)

theorem identity49349 : scanCanonicalize (H12AffineFastState.compose env49349 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49349 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49350 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5392,2341,1024,0,4112,33,17,2,268,17,2048,5393,4097,2341,1285,32,256,33,5377,513]

theorem envBound49350 : H12AffineFastState.Bounded env49350 := by
  intro p hp
  have h : env49350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49349_49350 : H12AffineEnvironment.transform 12 268 env49349 = env49350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49349 == env49350) = true)

theorem identity49350 : scanCanonicalize (H12AffineFastState.compose env49350 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49351 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4112,33,17,2,41,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound49351 : H12AffineFastState.Bounded env49351 := by
  intro p hp
  have h : env49351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49350_49351 : H12AffineEnvironment.transform 7 37 env49350 = env49351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49350 == env49351) = true)

def env49352 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1044,1,34,1029,2048,1024,0,32,33,17,2,41,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound49352 : H12AffineFastState.Bounded env49352 := by
  intro p hp
  have h : env49352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49351_49352 : H12AffineEnvironment.transform 11 48 env49351 = env49352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49351 == env49352) = true)

theorem identity49352 : scanCanonicalize (H12AffineFastState.compose env49352 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound49352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49353 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1045,48,41,1044,1,34,1029,1045,1024,0,32,33,17,2,41,17,1045,1028,49,1045,1056,32,37,33,1044,513]

theorem envBound49353 : H12AffineFastState.Bounded env49353 := by
  intro p hp
  have h : env49353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49352_49353 : H12AffineEnvironment.transform 10 1045 env49352 = env49353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env49352 == env49353) = true)

def env49354 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,41,32,1,34,49,33,52,0,32,33,17,2,41,17,33,48,49,33,20,32,37,33,32,513]

theorem envBound49354 : H12AffineFastState.Bounded env49354 := by
  intro p hp
  have h : env49354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49353_49354 : H12AffineEnvironment.transform 9 52 env49353 = env49354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49353 == env49354) = true)

def env49355 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,48,41,33,1,34,48,32,53,0,32,33,17,2,41,17,32,49,49,32,21,32,37,33,33,513]

theorem envBound49355 : H12AffineFastState.Bounded env49355 := by
  intro p hp
  have h : env49355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49353_49355 : H12AffineEnvironment.transform 9 53 env49353 = env49355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49353 == env49355) = true)

theorem identity49355 : scanCanonicalize (H12AffineFastState.compose env49355 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49356 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,48,41,33,1,34,48,32,53,0,32,33,17,2,41,17,32,49,49,32,21,32,37,33,33,42]

theorem envBound49356 : H12AffineFastState.Bounded env49356 := by
  intro p hp
  have h : env49356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49355_49356 : H12AffineEnvironment.transform 8 43 env49355 = env49356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49355 == env49356) = true)

def leafEnv49356 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,48,41,33,1,34,48,32,53,0,32,33,17,2,21,41,1,17,32,49,49,32,21,32,37,33,4,34,33,42,1,32,0]

def active49356 : List Nat := [0,1,2,3,4]

def tree49356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49356 : H12WitnessSearch.Good tree49356 := H12GlobalWitnessIndex.good

theorem leafIdentity49356 : H12AffineFastState.composeSystem env49356 rootObs = leafEnv49356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49356 rootObs == leafEnv49356) = true)

theorem terminalChecked49356 : H12PackedTerminal.terminalCheckFast leafEnv49356 active49356 tree49356 = true := by decide +kernel

def env49357 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1045,1,34,1028,2048,1024,0,33,33,17,2,41,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound49357 : H12AffineFastState.Bounded env49357 := by
  intro p hp
  have h : env49357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49351_49357 : H12AffineEnvironment.transform 11 49 env49351 = env49357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49351 == env49357) = true)

theorem identity49357 : scanCanonicalize (H12AffineFastState.compose env49357 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49358 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,49,41,1045,1,34,1028,33,1024,0,33,33,17,2,41,17,33,1029,48,33,1056,32,37,33,1045,513]

theorem envBound49358 : H12AffineFastState.Bounded env49358 := by
  intro p hp
  have h : env49358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49357_49358 : H12AffineEnvironment.transform 10 33 env49357 = env49358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49357 == env49358) = true)

def env49359 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,49,41,33,1,34,48,33,52,0,33,33,17,2,41,17,33,49,48,33,20,32,37,33,33,513]

theorem envBound49359 : H12AffineFastState.Bounded env49359 := by
  intro p hp
  have h : env49359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49358_49359 : H12AffineEnvironment.transform 9 52 env49358 = env49359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49358 == env49359) = true)

def env49360 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,41,32,1,34,49,33,53,0,33,33,17,2,41,17,33,48,48,33,21,32,37,33,32,513]

theorem envBound49360 : H12AffineFastState.Bounded env49360 := by
  intro p hp
  have h : env49360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49358_49360 : H12AffineEnvironment.transform 9 53 env49358 = env49360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49358 == env49360) = true)

theorem identity49360 : scanCanonicalize (H12AffineFastState.compose env49360 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49361 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,49,41,32,1,34,49,33,53,0,33,33,17,2,41,17,33,48,48,33,21,32,37,33,32,43]

theorem envBound49361 : H12AffineFastState.Bounded env49361 := by
  intro p hp
  have h : env49361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49360_49361 : H12AffineEnvironment.transform 8 42 env49360 = env49361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49360 == env49361) = true)

def leafEnv49361 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,49,41,32,1,34,49,33,53,0,33,33,17,2,21,41,1,17,33,48,48,33,21,32,37,33,4,34,32,43,1,33,0]

def active49361 : List Nat := [0,1,2,3,4]

def tree49361 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49361 : H12WitnessSearch.Good tree49361 := H12GlobalWitnessIndex.good

theorem leafIdentity49361 : H12AffineFastState.composeSystem env49361 rootObs = leafEnv49361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49361 rootObs == leafEnv49361) = true)

theorem terminalChecked49361 : H12PackedTerminal.terminalCheckFast leafEnv49361 active49361 tree49361 = true := by decide +kernel

def env49362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144493,400501,485740,8193,65,292137,395637,416100,10281,1364,272393,256,21792,16464,74250]

theorem envBound49362 : H12AffineFastState.Bounded env49362 := by
  intro p hp
  have h : env49362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49343_49362 : H12AffineEnvironment.transform 6 9 env49343 = env49362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49343 == env49362) = true)

theorem identity49362 : scanCanonicalize (H12AffineFastState.compose env49362 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound49362 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env49363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,79130,262144,1024,29788,4160,65911,338287,285814,8193,65,292137,343151,355454,10281,1364,272393,256,21792,16464,74250]

theorem envBound49363 : H12AffineFastState.Bounded env49363 := by
  intro p hp
  have h : env49363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49362_49363 : H12AffineEnvironment.transform 16 79130 env49362 = env49363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env49362 == env49363) = true)

theorem identity49363 : scanCanonicalize (H12AffineFastState.compose env49363 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound49363 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env49364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,16401,262144,1024,29788,4160,29820,285796,285814,8193,65,292137,280932,268661,10281,1364,272393,256,21792,16464,22273]

theorem envBound49364 : H12AffineFastState.Bounded env49364 := by
  intro p hp
  have h : env49364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49363_49364 : H12AffineEnvironment.transform 15 29963 env49363 = env49364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env49363 == env49364) = true)

theorem identity49364 : scanCanonicalize (H12AffineFastState.compose env49364 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound49364 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS < 2^1333 := by decide +kernel

def env49365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,16401,23808,1024,29788,4160,29820,356,374,8193,65,10281,5220,17525,10281,1364,29961,256,21792,16464,22273]

theorem envBound49365 : H12AffineFastState.Bounded env49365 := by
  intro p hp
  have h : env49365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49364_49365 : H12AffineEnvironment.transform 17 23808 env49364 = env49365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env49364 == env49365) = true)

theorem identity49365 : scanCanonicalize (H12AffineFastState.compose env49365 (packedSelected [0,2,6,11,14,16,18,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49365 : packedSelected [0,2,6,11,14,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env49366 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29789,29822,16401,23669,1024,29788,4160,29820,17,3,8193,65,10281,5220,17525,10281,1057,29820,117,21589,16464,22132]

theorem envBound49366 : H12AffineFastState.Bounded env49366 := by
  intro p hp
  have h : env49366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49365_49366 : H12AffineEnvironment.transform 7 117 env49365 = env49366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49365 == env49366) = true)

theorem identity49366 : scanCanonicalize (H12AffineFastState.compose env49366 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound49366 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49367 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13324,81,114,13341,10361,1024,80,4160,112,17,3,8193,65,10281,5220,12409,10281,1057,112,117,8281,13404,8824]

theorem envBound49367 : H12AffineFastState.Bounded env49367 := by
  intro p hp
  have h : env49367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49366_49367 : H12AffineEnvironment.transform 13 13324 env49366 = env49367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env49366 == env49367) = true)

theorem identity49367 : scanCanonicalize (H12AffineFastState.compose env49367 (packedSelected [0,1,2,3,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6249) := by decide +kernel

theorem selectedBound49367 : packedSelected [0,1,2,3,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49368 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,6249,3173,81,114,3188,4112,1024,80,4160,112,17,3,6248,65,4160,5220,2064,4160,1057,112,117,6192,3125,6673]

theorem envBound49368 : H12AffineFastState.Bounded env49368 := by
  intro p hp
  have h : env49368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49367_49368 : H12AffineEnvironment.transform 12 6249 env49367 = env49368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6249 env49367 == env49368) = true)

theorem identity49368 : scanCanonicalize (H12AffineFastState.compose env49368 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound49368 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49369 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2064,121,3173,81,114,3188,2048,1024,80,2128,112,17,3,120,65,2128,3188,2064,2128,1057,112,117,32,3125,513]

theorem envBound49369 : H12AffineFastState.Bounded env49369 := by
  intro p hp
  have h : env49369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49368_49369 : H12AffineEnvironment.transform 11 2064 env49368 = env49369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env49368 == env49369) = true)

theorem identity49369 : scanCanonicalize (H12AffineFastState.compose env49369 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49369 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49370 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2064,121,2048,81,114,2065,2048,101,80,2128,112,17,3,120,65,2128,2065,2064,2128,68,112,117,32,2128,513]

theorem envBound49370 : H12AffineFastState.Bounded env49370 := by
  intro p hp
  have h : env49370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49369_49370 : H12AffineEnvironment.transform 9 101 env49369 = env49370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49369 == env49370) = true)

theorem identity49370 : scanCanonicalize (H12AffineFastState.compose env49370 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49371 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,40,2048,0,35,2065,2048,52,1,2049,33,17,3,41,16,2049,2065,2064,2049,21,33,36,32,2049,513]

theorem envBound49371 : H12AffineFastState.Bounded env49371 := by
  intro p hp
  have h : env49371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49370_49371 : H12AffineEnvironment.transform 5 17 env49370 = env49371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49370 == env49371) = true)

theorem identity49371 : scanCanonicalize (H12AffineFastState.compose env49371 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound49371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49372 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,40,49,0,35,32,49,52,1,48,33,17,3,41,16,48,32,33,48,21,33,36,32,48,513]

theorem envBound49372 : H12AffineFastState.Bounded env49372 := by
  intro p hp
  have h : env49372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49371_49372 : H12AffineEnvironment.transform 10 49 env49371 = env49372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env49371 == env49372) = true)

def leafEnv49372 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,40,49,0,35,32,49,52,1,48,33,17,3,21,41,1,16,48,32,33,48,21,33,36,32,4,34,48,513,1,49,0]

def active49372 : List Nat := [0,1,2,3,4,8]

def tree49372 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49372 : H12WitnessSearch.Good tree49372 := H12GlobalWitnessIndex.good

theorem leafIdentity49372 : H12AffineFastState.composeSystem env49372 rootObs = leafEnv49372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49372 rootObs == leafEnv49372) = true)

theorem terminalChecked49372 : H12PackedTerminal.terminalCheckFast leafEnv49372 active49372 tree49372 = true := by decide +kernel

def env49373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400637,498993,8328,65,295285,395773,416237,56572,1500,272392,256,21792,46212,74251]

theorem envBound49373 : H12AffineFastState.Bounded env49373 := by
  intro p hp
  have h : env49373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49341_49373 : H12AffineEnvironment.transform 20 4161 env49341 = env49373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49341 == env49373) = true)

theorem identity49373 : scanCanonicalize (H12AffineFastState.compose env49373 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound49373 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,4161,180409,16,98780,8328,65,171416,5392,17664,56572,1500,144613,256,21792,46212,74251]

theorem envBound49374 : H12AffineFastState.Bounded env49374 := by
  intro p hp
  have h : env49374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49373_49374 : H12AffineEnvironment.transform 17 138477 env49373 = env49374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env49373 == env49374) = true)

def env49375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180273,16,98644,8192,65,171280,5392,17664,56436,1364,144493,256,21792,46092,74251]

theorem envBound49375 : H12AffineFastState.Bounded env49375 := by
  intro p hp
  have h : env49375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49374_49375 : H12AffineEnvironment.transform 6 8 env49374 = env49375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49374 == env49375) = true)

theorem identity49375 : scanCanonicalize (H12AffineFastState.compose env49375 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound49375 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1024,32769,4161,62589,16,98644,8192,65,43356,5392,17664,56436,1364,33,256,21792,46092,74251]

theorem envBound49376 : H12AffineFastState.Bounded env49376 := by
  intro p hp
  have h : env49376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49375_49376 : H12AffineEnvironment.transform 16 13388 env49375 = env49376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env49375 == env49376) = true)

theorem identity49376 : scanCanonicalize (H12AffineFastState.compose env49376 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound49376 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env49377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1024,29789,4161,33,16,95496,8192,65,23808,5392,17664,10280,1364,33,256,21792,16464,74251]

theorem envBound49377 : H12AffineFastState.Bounded env49377 := by
  intro p hp
  have h : env49377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49376_49377 : H12AffineEnvironment.transform 14 29788 env49376 = env49377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env49376 == env49377) = true)

theorem identity49377 : scanCanonicalize (H12AffineFastState.compose env49377 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound49377 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env49378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,13388,10281,1024,29789,4161,33,16,8542,8192,65,23808,5392,17664,10280,1364,33,256,21792,16464,30301]

theorem envBound49378 : H12AffineFastState.Bounded env49378 := by
  intro p hp
  have h : env49378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49377_49378 : H12AffineEnvironment.transform 15 21590 env49377 = env49378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env49377 == env49378) = true)

theorem identity49378 : scanCanonicalize (H12AffineFastState.compose env49378 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49378 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,13388,10281,1024,1,4161,33,16,8542,8192,65,10588,5392,12636,10280,1364,33,256,8572,13324,513]

theorem envBound49379 : H12AffineFastState.Bounded env49379 := by
  intro p hp
  have h : env49379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49378_49379 : H12AffineEnvironment.transform 13 13404 env49378 = env49379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49378 == env49379) = true)

theorem identity49379 : scanCanonicalize (H12AffineFastState.compose env49379 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49379 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5393,2420,1024,1,4161,33,16,3,349,65,2049,5392,4097,2421,1364,33,256,33,5457,513]

theorem envBound49380 : H12AffineFastState.Bounded env49380 := by
  intro p hp
  have h : env49380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49379_49380 : H12AffineEnvironment.transform 12 349 env49379 = env49380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49379 == env49380) = true)

theorem identity49380 : scanCanonicalize (H12AffineFastState.compose env49380 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49381 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1024,1,4112,33,16,3,268,16,2049,5392,4097,2340,1285,33,256,33,5376,513]

theorem envBound49381 : H12AffineFastState.Bounded env49381 := by
  intro p hp
  have h : env49381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49380_49381 : H12AffineEnvironment.transform 5 17 env49380 = env49381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49380 == env49381) = true)

theorem identity49381 : scanCanonicalize (H12AffineFastState.compose env49381 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound49381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49382 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,49,268,1328,0,262,1312,2341,1024,1,33,33,16,3,268,16,2049,1313,48,2340,1285,33,256,33,1329,513]

theorem envBound49382 : H12AffineFastState.Bounded env49382 := by
  intro p hp
  have h : env49382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49381_49382 : H12AffineEnvironment.transform 11 49 env49381 = env49382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49381 == env49382) = true)

theorem identity49382 : scanCanonicalize (H12AffineFastState.compose env49382 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound49382 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49383 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1556,49,268,1328,0,262,1312,1841,1024,1,33,33,16,3,268,16,1557,1313,48,1840,1285,33,256,33,1329,513]

end H12CloudChart0