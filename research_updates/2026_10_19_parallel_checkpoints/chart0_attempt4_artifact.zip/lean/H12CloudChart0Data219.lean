import H12CloudChart0Data218

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound55451 : H12AffineFastState.Bounded env55451 := by
  intro p hp
  have h : env55451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55450_55451 : H12AffineEnvironment.transform 16 79130 env55450 = env55451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env55450 == env55451) = true)

theorem identity55451 : scanCanonicalize (H12AffineFastState.compose env55451 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55451 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env55452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,5393,32120,1025,29788,4161,8493,29773,8543,8192,64,2049,24908,12637,10361,1365,21873,257,21793,16464,513]

theorem envBound55452 : H12AffineFastState.Bounded env55452 := by
  intro p hp
  have h : env55452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55451_55452 : H12AffineEnvironment.transform 15 8203 env55451 = env55452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55451 == env55452) = true)

theorem identity55452 : scanCanonicalize (H12AffineFastState.compose env55452 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,10361,1025,8541,4161,8493,8524,8543,8192,64,2049,13389,12637,10361,1365,112,257,32,5457,513]

theorem envBound55453 : H12AffineFastState.Bounded env55453 := by
  intro p hp
  have h : env55453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55452_55453 : H12AffineEnvironment.transform 13 5377 env55452 = env55453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55452 == env55453) = true)

theorem identity55453 : scanCanonicalize (H12AffineFastState.compose env55453 (packedSelected [0,4,7,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 317) := by decide +kernel

theorem selectedBound55453 : packedSelected [0,4,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,317,5377,97,310,5393,2372,1025,96,4161,16,113,98,317,64,2049,5488,4192,2372,1365,112,257,32,5457,513]

theorem envBound55454 : H12AffineFastState.Bounded env55454 := by
  intro p hp
  have h : env55454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55453_55454 : H12AffineEnvironment.transform 12 317 env55453 = env55454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 317 env55453 == env55454) = true)

theorem identity55454 : scanCanonicalize (H12AffineFastState.compose env55454 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound55454 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55455 : List Nat := [2,4,8,16,17,64,8,256,512,1024,2048,4096,268,5377,80,263,5393,2372,1025,81,4161,16,64,83,268,64,2049,5441,4177,2372,1365,65,257,17,5457,513]

theorem envBound55455 : H12AffineFastState.Bounded env55455 := by
  intro p hp
  have h : env55455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55454_55455 : H12AffineEnvironment.transform 4 17 env55454 = env55455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env55454 == env55455) = true)

theorem identity55455 : scanCanonicalize (H12AffineFastState.compose env55455 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound55455 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env55456 : List Nat := [2,4,8,16,17,64,8,256,512,1024,11,4096,268,5377,80,263,5393,335,1025,81,4161,16,64,83,268,64,10,5441,4177,335,1365,65,257,17,5457,513]

theorem envBound55456 : H12AffineFastState.Bounded env55456 := by
  intro p hp
  have h : env55456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55455_55456 : H12AffineEnvironment.transform 10 11 env55455 = env55456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env55455 == env55456) = true)

theorem identity55456 : scanCanonicalize (H12AffineFastState.compose env55456 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound55456 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env55457 : List Nat := [2,4,8,16,17,64,8,79,512,1024,11,4096,67,5198,80,72,5214,0,1025,81,4161,16,64,83,67,64,10,5134,4177,0,1050,65,78,17,5150,513]

theorem envBound55457 : H12AffineFastState.Bounded env55457 := by
  intro p hp
  have h : env55457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55456_55457 : H12AffineEnvironment.transform 7 79 env55456 = env55457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env55456 == env55457) = true)

theorem identity55457 : scanCanonicalize (H12AffineFastState.compose env55457 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1103) := by decide +kernel

theorem selectedBound55457 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55458 : List Nat := [2,4,8,16,17,64,8,79,512,1024,11,1103,67,1,80,72,17,0,1025,81,1038,16,64,83,67,64,10,65,1054,0,1050,65,78,17,81,513]

theorem envBound55458 : H12AffineFastState.Bounded env55458 := by
  intro p hp
  have h : env55458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55457_55458 : H12AffineEnvironment.transform 11 1103 env55457 = env55458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1103 env55457 == env55458) = true)

theorem identity55458 : scanCanonicalize (H12AffineFastState.compose env55458 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55459 : List Nat := [2,4,8,0,1,64,8,79,512,1024,11,1103,67,1,64,72,1,0,1025,65,1038,0,64,67,67,64,10,65,1038,0,1034,65,78,1,65,513]

theorem envBound55459 : H12AffineFastState.Bounded env55459 := by
  intro p hp
  have h : env55459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55458_55459 : H12AffineEnvironment.transform 3 0 env55458 = env55459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55458 == env55459) = true)

theorem identity55459 : scanCanonicalize (H12AffineFastState.compose env55459 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound55459 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55460 : List Nat := [2,4,8,0,1,10,8,5,512,1024,11,1029,9,1,10,2,1,0,1025,11,1038,0,10,9,9,10,10,11,1038,0,1034,11,4,1,11,513]

theorem envBound55460 : H12AffineFastState.Bounded env55460 := by
  intro p hp
  have h : env55460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55459_55460 : H12AffineEnvironment.transform 5 10 env55459 = env55460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env55459 == env55460) = true)

theorem identity55460 : scanCanonicalize (H12AffineFastState.compose env55460 (packedSelected [0,1,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55460 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env55461 : List Nat := [2,1,8,0,1,10,8,0,512,1024,11,1024,9,1,10,2,1,0,1025,11,1035,0,10,9,9,10,10,11,1035,0,1034,11,1,1,11,513]

theorem envBound55461 : H12AffineFastState.Bounded env55461 := by
  intro p hp
  have h : env55461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55460_55461 : H12AffineEnvironment.transform 1 1 env55460 = env55461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55460 == env55461) = true)

def env55462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,411973,155996,201797,8193,64,2049,160861,140364,283904,1364,272393,257,21793,16464,74250]

theorem envBound55462 : H12AffineFastState.Bounded env55462 := by
  intro p hp
  have h : env55462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55448_55462 : H12AffineEnvironment.transform 6 9 env55448 = env55462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55448 == env55462) = true)

theorem identity55462 : scanCanonicalize (H12AffineFastState.compose env55462 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound55462 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,215090,1025,29789,4161,65911,155996,201797,8193,64,2049,160861,140364,204082,1364,221243,257,21793,16464,74250]

theorem envBound55463 : H12AffineFastState.Bounded env55463 := by
  intro p hp
  have h : env55463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55462_55463 : H12AffineEnvironment.transform 17 215090 env55462 = env55463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env55462 == env55463) = true)

theorem identity55463 : scanCanonicalize (H12AffineFastState.compose env55463 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound55463 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,16401,67619,1025,29789,4161,65911,8525,87124,8193,64,2049,13388,25693,89379,1364,73770,257,21793,16464,74250]

theorem envBound55464 : H12AffineFastState.Bounded env55464 := by
  intro p hp
  have h : env55464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55463_55464 : H12AffineEnvironment.transform 16 16401 env55463 = env55464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55463 == env55464) = true)

theorem identity55464 : scanCanonicalize (H12AffineFastState.compose env55464 (packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55464 : packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env55465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,65536,16401,67619,1025,21760,4161,65911,16,87124,348,64,2049,5393,17664,89379,1364,65911,257,21793,16464,66391]

theorem envBound55465 : H12AffineFastState.Bounded env55465 := by
  intro p hp
  have h : env55465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55464_55465 : H12AffineEnvironment.transform 12 349 env55464 = env55465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55464 == env55465) = true)

theorem identity55465 : scanCanonicalize (H12AffineFastState.compose env55465 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound55465 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env55466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21591,16401,23668,1025,21760,4161,21792,16,3,348,64,2049,5393,17664,2420,1364,21792,257,21793,16464,22272]

theorem envBound55466 : H12AffineFastState.Bounded env55466 := by
  intro p hp
  have h : env55466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55465_55466 : H12AffineEnvironment.transform 15 21591 env55465 = env55466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env55465 == env55466) = true)

theorem identity55466 : scanCanonicalize (H12AffineFastState.compose env55466 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55466 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env55467 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,21541,21591,16401,23668,1025,21540,4161,21508,16,3,120,64,2049,5173,17444,2128,1136,21508,37,21509,16464,22052]

theorem envBound55467 : H12AffineFastState.Bounded env55467 := by
  intro p hp
  have h : env55467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55466_55467 : H12AffineEnvironment.transform 7 36 env55466 = env55467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55466 == env55467) = true)

theorem identity55467 : scanCanonicalize (H12AffineFastState.compose env55467 (packedSelected [0,1,6,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound55467 : packedSelected [0,1,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env55468 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,121,16384,18432,18546,16401,16465,1025,18433,3172,18465,16,3,120,64,2049,2064,17444,2128,1136,18465,37,18464,16464,18945]

theorem envBound55468 : H12AffineFastState.Bounded env55468 := by
  intro p hp
  have h : env55468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55467_55468 : H12AffineEnvironment.transform 11 3109 env55467 = env55468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env55467 == env55468) = true)

theorem identity55468 : scanCanonicalize (H12AffineFastState.compose env55468 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound55468 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55469 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,121,2129,81,35,2112,2048,1025,80,3172,112,16,3,120,64,2049,2064,3189,2128,1136,112,37,113,2049,592]

theorem envBound55469 : H12AffineFastState.Bounded env55469 := by
  intro p hp
  have h : env55469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55468_55469 : H12AffineEnvironment.transform 13 2129 env55468 = env55469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env55468 == env55469) = true)

theorem identity55469 : scanCanonicalize (H12AffineFastState.compose env55469 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55469 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55470 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2065,121,2129,81,35,2112,2048,53,80,2128,112,16,3,120,64,2049,2064,2113,2128,68,112,37,113,2049,592]

theorem envBound55470 : H12AffineFastState.Bounded env55470 := by
  intro p hp
  have h : env55470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55469_55470 : H12AffineEnvironment.transform 9 52 env55469 = env55470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55469 == env55470) = true)

theorem identity55470 : scanCanonicalize (H12AffineFastState.compose env55470 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound55470 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env55471 : List Nat := [2,4,8,16,32,64,9,36,512,52,17,0,121,64,81,35,81,17,53,80,65,112,16,3,120,64,16,1,80,65,68,112,37,113,16,592]

theorem envBound55471 : H12AffineFastState.Bounded env55471 := by
  intro p hp
  have h : env55471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55470_55471 : H12AffineEnvironment.transform 10 17 env55470 = env55471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env55470 == env55471) = true)

theorem identity55471 : scanCanonicalize (H12AffineFastState.compose env55471 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55471 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55472 : List Nat := [2,4,8,16,32,17,9,36,512,52,17,0,40,17,0,35,0,17,53,1,16,33,16,3,41,17,16,1,1,16,21,33,37,32,16,513]

theorem envBound55472 : H12AffineFastState.Bounded env55472 := by
  intro p hp
  have h : env55472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55471_55472 : H12AffineEnvironment.transform 5 17 env55471 = env55472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55471 == env55472) = true)

def env55473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound55473 : H12AffineFastState.Bounded env55473 := by
  intro p hp
  have h : env55473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55093_55473 : H12AffineEnvironment.transform 26 30393345 env55093 = env55473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env55093 == env55473) = true)

def env55474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound55474 : H12AffineFastState.Bounded env55474 := by
  intro p hp
  have h : env55474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55473_55474 : H12AffineEnvironment.transform 18 1024 env55473 = env55474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env55473 == env55474) = true)

theorem identity55474 : scanCanonicalize (H12AffineFastState.compose env55474 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577360) := by decide +kernel

theorem selectedBound55474 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577360,8328,64,6727121,8446301,10507601,8830976,2154945,12582928,256,41340,16600,2213399]

theorem envBound55475 : H12AffineFastState.Bounded env55475 := by
  intro p hp
  have h : env55475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55474_55475 : H12AffineEnvironment.transform 23 10577360 env55474 = env55475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577360 env55474 == env55475) = true)

def env55476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,8388608,10577360,8328,64,6705549,8393985,10507601,8795228,2102685,12582928,256,21792,16600,2175563]

theorem envBound55476 : H12AffineFastState.Bounded env55476 := by
  intro p hp
  have h : env55476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55475_55476 : H12AffineEnvironment.transform 14 29788 env55475 = env55476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env55475 == env55476) = true)

def env55477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114896,73856,8328,64,6705549,2117713,4097,2519308,2102685,6309184,256,21792,16600,2175563]

theorem envBound55477 : H12AffineFastState.Bounded env55477 := by
  intro p hp
  have h : env55477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55476_55477 : H12AffineEnvironment.transform 22 2114896 env55476 = env55477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env55476 == env55477) = true)

def env55478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,16,73856,8328,64,4592845,5393,4097,406604,20701,4194304,256,21792,16600,96011]

theorem envBound55478 : H12AffineFastState.Bounded env55478 := by
  intro p hp
  have h : env55478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55477_55478 : H12AffineEnvironment.transform 20 17728 env55477 = env55478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env55477 == env55478) = true)

theorem identity55478 : scanCanonicalize (H12AffineFastState.compose env55478 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55478 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,16,73736,8192,64,4592709,5393,4097,406604,20565,4194304,256,21792,16464,96011]

theorem envBound55479 : H12AffineFastState.Bounded env55479 := by
  intro p hp
  have h : env55479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55478_55479 : H12AffineEnvironment.transform 6 8 env55478 = env55479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55478 == env55479) = true)

def env55480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,16400,262144,1024,29789,17728,4194304,16,73736,8192,64,4478037,5393,4097,291932,20565,4194304,256,21792,16464,96011]

theorem envBound55480 : H12AffineFastState.Bounded env55480 := by
  intro p hp
  have h : env55480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55479_55480 : H12AffineEnvironment.transform 16 16400 env55479 = env55480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55479 == env55480) = true)

def env55481 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,16400,262144,1024,29709,17680,4194304,16,73736,8192,16,4477957,5393,4097,291852,20485,4194304,256,21792,16384,96011]

theorem envBound55481 : H12AffineFastState.Bounded env55481 := by
  intro p hp
  have h : env55481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55480_55481 : H12AffineEnvironment.transform 5 16 env55480 = env55481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55480 == env55481) = true)

theorem identity55481 : scanCanonicalize (H12AffineFastState.compose env55481 (packedSelected [0,4,7,14,16,20,22,35] rootPS)) = affineNative (2^(21+1) ^^^ 294153) := by decide +kernel

theorem selectedBound55481 : packedSelected [0,4,7,14,16,20,22,35] rootPS < 2^1333 := by decide +kernel

def env55482 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,16400,262144,1024,29709,17680,294153,16,73736,8192,16,10508,5393,4097,291852,20485,294153,256,21792,16384,96011]

theorem envBound55482 : H12AffineFastState.Bounded env55482 := by
  intro p hp
  have h : env55482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55481_55482 : H12AffineEnvironment.transform 21 294153 env55481 = env55482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 294153 env55481 == env55482) = true)

theorem identity55482 : scanCanonicalize (H12AffineFastState.compose env55482 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound55482 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55483 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,35,16400,262144,1024,29709,17680,294153,16,8235,8192,16,10508,5393,4097,291852,20485,294153,256,21792,16384,30504]

theorem envBound55483 : H12AffineFastState.Bounded env55483 := by
  intro p hp
  have h : env55483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55482_55483 : H12AffineEnvironment.transform 15 35 env55482 = env55483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env55482 == env55483) = true)

theorem identity55483 : scanCanonicalize (H12AffineFastState.compose env55483 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(17+1) ^^^ 31756) := by decide +kernel

theorem selectedBound55483 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env55484 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,35,16400,31756,1024,29709,17680,261,16,8235,8192,16,10508,5393,4097,2048,20485,261,256,21792,16384,30504]

theorem envBound55484 : H12AffineFastState.Bounded env55484 := by
  intro p hp
  have h : env55484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55483_55484 : H12AffineEnvironment.transform 17 31756 env55483 = env55484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31756 env55483 == env55484) = true)

theorem identity55484 : scanCanonicalize (H12AffineFastState.compose env55484 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound55484 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env55485 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,35,13341,2049,1024,0,12573,261,16,8235,8192,16,10508,5393,4097,2048,9224,261,256,8493,13325,805]

theorem envBound55485 : H12AffineFastState.Bounded env55485 := by
  intro p hp
  have h : env55485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55484_55485 : H12AffineEnvironment.transform 13 13325 env55484 = env55485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env55484 == env55485) = true)

def env55486 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,16400,262144,1024,29708,17681,4194304,16,73736,8192,17,4477956,5393,4097,291853,20484,4194304,256,21792,16385,96011]

theorem envBound55486 : H12AffineFastState.Bounded env55486 := by
  intro p hp
  have h : env55486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55480_55486 : H12AffineEnvironment.transform 5 17 env55480 = env55486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55480 == env55486) = true)

theorem identity55486 : scanCanonicalize (H12AffineFastState.compose env55486 (packedSelected [0,4,7,14,16,20,22,35] rootPS)) = affineNative (2^(21+1) ^^^ 351491) := by decide +kernel

theorem selectedBound55486 : packedSelected [0,4,7,14,16,20,22,35] rootPS < 2^1333 := by decide +kernel

def env55487 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,16400,262144,1024,29708,17681,351491,16,73736,8192,17,67847,5393,4097,291853,20484,351491,256,21792,16385,96011]

theorem envBound55487 : H12AffineFastState.Bounded env55487 := by
  intro p hp
  have h : env55487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55486_55487 : H12AffineEnvironment.transform 21 351491 env55486 = env55487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 351491 env55486 == env55487) = true)

theorem identity55487 : scanCanonicalize (H12AffineFastState.compose env55487 (packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound55487 : packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env55488 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,16400,89378,1024,29708,17681,33,16,73736,8192,17,67847,5393,4097,76079,20484,33,256,21792,16385,96011]

theorem envBound55488 : H12AffineFastState.Bounded env55488 := by
  intro p hp
  have h : env55488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55487_55488 : H12AffineEnvironment.transform 17 89378 env55487 = env55488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env55487 == env55488) = true)

theorem identity55488 : scanCanonicalize (H12AffineFastState.compose env55488 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound55488 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env55489 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,35,16400,23809,1024,29708,17681,33,16,8235,8192,17,2340,5393,4097,10508,20484,33,256,21792,16385,30504]

theorem envBound55489 : H12AffineFastState.Bounded env55489 := by
  intro p hp
  have h : env55489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55488_55489 : H12AffineEnvironment.transform 15 35 env55488 = env55489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env55488 == env55489) = true)

theorem identity55489 : scanCanonicalize (H12AffineFastState.compose env55489 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound55489 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env55490 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2356,8192,16384,27961,35,16400,17461,1024,27960,17681,33,16,8235,8192,17,2340,3109,2357,10508,18736,33,256,19476,16385,28188]

theorem envBound55490 : H12AffineFastState.Bounded env55490 := by
  intro p hp
  have h : env55490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55489_55490 : H12AffineEnvironment.transform 11 2356 env55489 = env55490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env55489 == env55490) = true)

theorem identity55490 : scanCanonicalize (H12AffineFastState.compose env55490 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound55490 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env55491 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2356,8192,1,11576,35,17,1076,1024,11577,1296,33,16,8235,8192,17,2340,3109,2357,10508,2353,33,256,3093,0,11805]

theorem envBound55491 : H12AffineFastState.Bounded env55491 := by
  intro p hp
  have h : env55491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55490_55491 : H12AffineEnvironment.transform 13 1 env55490 = env55491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env55490 == env55491) = true)

theorem identity55491 : scanCanonicalize (H12AffineFastState.compose env55491 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55491 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env55492 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,308,8192,1,9528,35,17,1076,1024,9529,1296,33,16,8235,8192,17,292,1061,309,8460,305,33,256,1045,0,9757]

theorem envBound55492 : H12AffineFastState.Bounded env55492 := by
  intro p hp
  have h : env55492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55491_55492 : H12AffineEnvironment.transform 10 0 env55491 = env55492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55491 == env55492) = true)

theorem identity55492 : scanCanonicalize (H12AffineFastState.compose env55492 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55492 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55493 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,308,269,1,1077,35,17,1076,1024,1076,1296,33,16,294,269,17,292,1061,309,1,305,33,256,1045,0,1808]

theorem envBound55493 : H12AffineFastState.Bounded env55493 := by
  intro p hp
  have h : env55493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55492_55493 : H12AffineEnvironment.transform 12 269 env55492 = env55493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55492 == env55493) = true)

theorem identity55493 : scanCanonicalize (H12AffineFastState.compose env55493 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55493 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55494 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,16,41,1,1077,35,17,1076,1024,1076,1076,33,16,2,41,17,0,1061,17,1,21,33,36,1045,0,1588]

theorem envBound55494 : H12AffineFastState.Bounded env55494 := by
  intro p hp
  have h : env55494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55493_55494 : H12AffineEnvironment.transform 7 36 env55493 = env55494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55493 == env55494) = true)

theorem identity55494 : scanCanonicalize (H12AffineFastState.compose env55494 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound55494 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env55495 : List Nat := [2,4,8,16,32,17,8,36,512,37,0,16,41,1,16,35,17,17,37,17,17,33,16,2,41,17,0,0,17,1,21,33,36,48,0,529]

theorem envBound55495 : H12AffineFastState.Bounded env55495 := by
  intro p hp
  have h : env55495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55494_55495 : H12AffineEnvironment.transform 9 37 env55494 = env55495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env55494 == env55495) = true)

theorem identity55495 : scanCanonicalize (H12AffineFastState.compose env55495 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55495 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55496 : List Nat := [2,4,8,1,32,0,8,36,512,37,0,1,41,1,1,35,0,0,37,0,0,33,1,2,41,0,0,0,0,1,4,33,36,33,0,512]

theorem envBound55496 : H12AffineFastState.Bounded env55496 := by
  intro p hp
  have h : env55496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55495_55496 : H12AffineEnvironment.transform 3 1 env55495 = env55496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55495 == env55496) = true)

theorem identity55496 : scanCanonicalize (H12AffineFastState.compose env55496 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55497 : List Nat := [2,0,8,1,32,0,8,32,512,33,0,1,41,1,1,35,0,0,33,0,0,33,1,2,41,0,0,0,0,1,0,33,32,33,0,512]

theorem envBound55497 : H12AffineFastState.Bounded env55497 := by
  intro p hp
  have h : env55497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55496_55497 : H12AffineEnvironment.transform 1 0 env55496 = env55497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55496 == env55497) = true)

theorem identity55497 : scanCanonicalize (H12AffineFastState.compose env55497 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound55497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55498 : List Nat := [2,0,8,1,32,0,8,32,35,33,0,1,41,1,1,35,0,0,33,0,0,33,1,2,41,0,0,0,0,1,0,33,32,33,0,35]

theorem envBound55498 : H12AffineFastState.Bounded env55498 := by
  intro p hp
  have h : env55498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55497_55498 : H12AffineEnvironment.transform 8 35 env55497 = env55498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env55497 == env55498) = true)

theorem identity55498 : scanCanonicalize (H12AffineFastState.compose env55498 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound55498 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55499 : List Nat := [2,0,0,1,32,0,0,32,35,33,0,1,33,1,1,35,0,0,33,0,0,33,1,2,33,0,0,0,0,1,0,33,32,33,0,35]

theorem envBound55499 : H12AffineFastState.Bounded env55499 := by
  intro p hp
  have h : env55499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55498_55499 : H12AffineEnvironment.transform 2 0 env55498 = env55499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env55498 == env55499) = true)

theorem identity55499 : scanCanonicalize (H12AffineFastState.compose env55499 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound55499 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55500 : List Nat := [2,0,0,1,2,0,0,2,1,3,0,1,3,1,1,1,0,0,3,0,0,3,1,2,3,0,0,0,0,1,0,3,2,3,0,1]

theorem envBound55500 : H12AffineFastState.Bounded env55500 := by
  intro p hp
  have h : env55500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55499_55500 : H12AffineEnvironment.transform 4 2 env55499 = env55500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env55499 == env55500) = true)

theorem identity55500 : scanCanonicalize (H12AffineFastState.compose env55500 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55500 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55501 : List Nat := [1,0,0,1,1,0,0,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,1,0,0,1,0,0,1]

theorem envBound55501 : H12AffineFastState.Bounded env55501 := by
  intro p hp
  have h : env55501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55500_55501 : H12AffineEnvironment.transform 0 1 env55500 = env55501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55500 == env55501) = true)

def env55502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,16401,262144,1024,29789,17728,4194304,16,73736,8192,64,4478036,5393,4097,291933,20565,4194304,256,21792,16464,96011]

theorem envBound55502 : H12AffineFastState.Bounded env55502 := by
  intro p hp
  have h : env55502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55479_55502 : H12AffineEnvironment.transform 16 16401 env55479 = env55502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55479 == env55502) = true)

theorem identity55502 : scanCanonicalize (H12AffineFastState.compose env55502 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound55502 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env55503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,16401,262144,1024,29789,17728,4194304,16,21762,8192,64,4478036,5393,4097,291933,20565,4194304,256,21792,16464,513]

theorem envBound55503 : H12AffineFastState.Bounded env55503 := by
  intro p hp
  have h : env55503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55502_55503 : H12AffineEnvironment.transform 15 29962 env55502 = env55503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env55502 == env55503) = true)

theorem identity55503 : scanCanonicalize (H12AffineFastState.compose env55503 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55503 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5392,262144,1024,8540,4161,4194304,16,3,8192,64,4456789,5393,4097,270684,1364,4194304,256,33,5457,513]

theorem envBound55504 : H12AffineFastState.Bounded env55504 := by
  intro p hp
  have h : env55504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55503_55504 : H12AffineEnvironment.transform 13 5377 env55503 = env55504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55503 == env55504) = true)

theorem identity55504 : scanCanonicalize (H12AffineFastState.compose env55504 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound55504 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5392,262144,1024,8540,4161,8492,16,3,8192,64,270457,5393,4097,270684,1364,8492,256,33,5457,513]

theorem envBound55505 : H12AffineFastState.Bounded env55505 := by
  intro p hp
  have h : env55505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55504_55505 : H12AffineEnvironment.transform 21 8492 env55504 = env55505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env55504 == env55505) = true)

theorem identity55505 : scanCanonicalize (H12AffineFastState.compose env55505 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound55505 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env55506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5392,2341,1024,8540,4161,8492,16,3,8192,64,10588,5393,4097,10361,1364,8492,256,33,5457,513]

theorem envBound55506 : H12AffineFastState.Bounded env55506 := by
  intro p hp
  have h : env55506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55505_55506 : H12AffineEnvironment.transform 17 2341 env55505 = env55506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env55505 == env55506) = true)

theorem identity55506 : scanCanonicalize (H12AffineFastState.compose env55506 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound55506 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5377,32,374,5392,2341,1024,33,4161,81,16,3,381,64,2081,5393,4097,2308,1364,81,256,33,5457,513]

theorem envBound55507 : H12AffineFastState.Bounded env55507 := by
  intro p hp
  have h : env55507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55506_55507 : H12AffineEnvironment.transform 12 381 env55506 = env55507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env55506 == env55507) = true)

theorem identity55507 : scanCanonicalize (H12AffineFastState.compose env55507 (packedSelected [0,4,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1856) := by decide +kernel

theorem selectedBound55507 : packedSelected [0,4,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1856,381,577,32,374,592,2341,1024,33,1793,81,16,3,381,64,2081,593,1857,2308,1364,81,256,33,529,513]

theorem envBound55508 : H12AffineFastState.Bounded env55508 := by
  intro p hp
  have h : env55508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55507_55508 : H12AffineEnvironment.transform 11 1856 env55507 = env55508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1856 env55507 == env55508) = true)

theorem identity55508 : scanCanonicalize (H12AffineFastState.compose env55508 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55508 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env55509 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1809,300,528,32,295,513,2341,1024,33,1793,0,16,3,300,17,2081,512,1808,2308,1285,0,256,33,529,513]

theorem envBound55509 : H12AffineFastState.Bounded env55509 := by
  intro p hp
  have h : env55509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55508_55509 : H12AffineEnvironment.transform 5 17 env55508 = env55509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55508 == env55509) = true)

theorem identity55509 : scanCanonicalize (H12AffineFastState.compose env55509 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55510 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,1557,40,528,32,35,513,2081,1024,33,1541,0,16,3,40,17,2081,512,1556,2048,1025,0,4,33,529,513]

theorem envBound55510 : H12AffineFastState.Bounded env55510 := by
  intro p hp
  have h : env55510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55509_55510 : H12AffineEnvironment.transform 7 4 env55509 = env55510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55509 == env55510) = true)

theorem identity55510 : scanCanonicalize (H12AffineFastState.compose env55510 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55510 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55511 : List Nat := [2,4,8,16,32,17,8,4,512,21,2048,512,40,528,32,35,513,2081,21,33,528,0,16,3,40,17,2081,512,513,2048,20,0,4,33,529,513]

theorem envBound55511 : H12AffineFastState.Bounded env55511 := by
  intro p hp
  have h : env55511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55510_55511 : H12AffineEnvironment.transform 9 21 env55510 = env55511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55510 == env55511) = true)

theorem identity55511 : scanCanonicalize (H12AffineFastState.compose env55511 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound55511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55512 : List Nat := [2,4,8,16,32,17,8,4,512,21,49,512,40,528,32,35,513,16,21,33,528,0,16,3,40,17,16,512,513,49,20,0,4,33,529,513]

theorem envBound55512 : H12AffineFastState.Bounded env55512 := by
  intro p hp
  have h : env55512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55511_55512 : H12AffineEnvironment.transform 10 49 env55511 = env55512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env55511 == env55512) = true)

def env55513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,17,73856,8328,64,4592844,5392,4097,406605,20700,4194305,256,21792,16600,96010]

theorem envBound55513 : H12AffineFastState.Bounded env55513 := by
  intro p hp
  have h : env55513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55477_55513 : H12AffineEnvironment.transform 20 17729 env55477 = env55513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env55477 == env55513) = true)

theorem identity55513 : scanCanonicalize (H12AffineFastState.compose env55513 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound55513 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,168,17,73856,8328,64,398436,5392,4097,406605,20700,169,256,21792,16600,96010]

theorem envBound55514 : H12AffineFastState.Bounded env55514 := by
  intro p hp
  have h : env55514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55513_55514 : H12AffineEnvironment.transform 21 168 env55513 = env55514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env55513 == env55514) = true)

theorem identity55514 : scanCanonicalize (H12AffineFastState.compose env55514 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound55514 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env55515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,5393,262144,1024,29789,17729,168,17,73856,8328,64,262517,5392,4097,270684,20700,169,256,21792,16600,96010]

theorem envBound55515 : H12AffineFastState.Bounded env55515 := by
  intro p hp
  have h : env55515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55514_55515 : H12AffineEnvironment.transform 16 5393 env55514 = env55515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55514 == env55515) = true)

theorem identity55515 : scanCanonicalize (H12AffineFastState.compose env55515 (packedSelected [0,4,7,11,16,18,20,21,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound55515 : packedSelected [0,4,7,11,16,18,20,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env55516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,30083,5393,262144,1024,29789,17729,168,17,21763,8328,64,262517,5392,4097,270684,20700,169,256,21792,16600,649]

theorem envBound55516 : H12AffineFastState.Bounded env55516 := by
  intro p hp
  have h : env55516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55515_55516 : H12AffineEnvironment.transform 15 30083 env55515 = env55516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env55515 == env55516) = true)

theorem identity55516 : scanCanonicalize (H12AffineFastState.compose env55516 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55516 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21761,21726,5393,262144,1024,21760,17729,168,17,21763,469,64,262517,5392,4097,262145,20700,169,256,21792,16600,649]

theorem envBound55517 : H12AffineFastState.Bounded env55517 := by
  intro p hp
  have h : env55517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55516_55517 : H12AffineEnvironment.transform 12 349 env55516 = env55517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55516 == env55517) = true)

theorem identity55517 : scanCanonicalize (H12AffineFastState.compose env55517 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound55517 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,137,342,5393,262144,1024,136,4297,168,17,139,469,64,262517,5392,4097,262145,1364,169,256,168,5456,649]

theorem envBound55518 : H12AffineFastState.Bounded env55518 := by
  intro p hp
  have h : env55518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55517_55518 : H12AffineEnvironment.transform 13 5512 env55517 = env55518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env55517 == env55518) = true)

theorem identity55518 : scanCanonicalize (H12AffineFastState.compose env55518 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound55518 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,137,342,5393,2420,1024,136,4297,168,17,139,469,64,2049,5392,4097,2421,1364,169,256,168,5456,649]

theorem envBound55519 : H12AffineFastState.Bounded env55519 := by
  intro p hp
  have h : env55519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55518_55519 : H12AffineEnvironment.transform 17 2420 env55518 = env55519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env55518 == env55519) = true)

theorem identity55519 : scanCanonicalize (H12AffineFastState.compose env55519 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound55519 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55520 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,349,5488,113,342,5393,2420,1024,112,4145,80,17,115,301,64,2049,5392,4097,2421,1364,81,256,80,5456,625]

theorem envBound55520 : H12AffineFastState.Bounded env55520 := by
  intro p hp
  have h : env55520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55519_55520 : H12AffineEnvironment.transform 6 120 env55519 = env55520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env55519 == env55520) = true)

def env55521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114897,73857,8328,64,6705549,2117712,4096,2519309,2102685,6309185,256,21792,16600,2175563]

theorem envBound55521 : H12AffineFastState.Bounded env55521 := by
  intro p hp
  have h : env55521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55476_55521 : H12AffineEnvironment.transform 22 2114897 env55476 = env55521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env55476 == env55521) = true)

def env55522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,17,73857,8328,64,4592845,5392,4096,406605,20701,4194305,256,21792,16600,96011]

theorem envBound55522 : H12AffineFastState.Bounded env55522 := by
  intro p hp
  have h : env55522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55521_55522 : H12AffineEnvironment.transform 20 17728 env55521 = env55522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env55521 == env55522) = true)

theorem identity55522 : scanCanonicalize (H12AffineFastState.compose env55522 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound55522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,32,17,73857,8328,64,398573,5392,4096,406605,20701,33,256,21792,16600,96011]

theorem envBound55523 : H12AffineFastState.Bounded env55523 := by
  intro p hp
  have h : env55523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55522_55523 : H12AffineEnvironment.transform 21 32 env55522 = env55523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55522 == env55523) = true)

def env55524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,32,17,73857,8328,64,398573,5392,4096,406605,1501,33,256,32,5592,74251]

theorem envBound55524 : H12AffineFastState.Bounded env55524 := by
  intro p hp
  have h : env55524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55523_55524 : H12AffineEnvironment.transform 13 5376 env55523 = env55524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55523 == env55524) = true)

theorem identity55524 : scanCanonicalize (H12AffineFastState.compose env55524 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound55524 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,4160,32,17,73857,8328,64,146508,5392,4096,138476,1501,33,256,32,5592,74251]

theorem envBound55525 : H12AffineFastState.Bounded env55525 := by
  intro p hp
  have h : env55525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55524_55525 : H12AffineEnvironment.transform 17 10401 env55524 = env55525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55524 == env55525) = true)

def env55526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4161,32,17,73857,8328,64,398573,5392,4096,406605,1500,33,256,33,5593,74250]

theorem envBound55526 : H12AffineFastState.Bounded env55526 := by
  intro p hp
  have h : env55526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55523_55526 : H12AffineEnvironment.transform 13 5377 env55523 = env55526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55523 == env55526) = true)

theorem identity55526 : scanCanonicalize (H12AffineFastState.compose env55526 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55526 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,4161,32,17,73857,8328,64,146628,5392,4096,138340,1500,33,256,33,5593,74250]

theorem envBound55527 : H12AffineFastState.Bounded env55527 := by
  intro p hp
  have h : env55527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55526_55527 : H12AffineEnvironment.transform 17 10281 env55526 = env55527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55526 == env55527) = true)

theorem identity55527 : scanCanonicalize (H12AffineFastState.compose env55527 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound55527 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,5392,10281,1024,8540,4161,32,17,73857,8328,64,10708,5392,4096,2420,1500,33,256,33,5593,74250]

theorem envBound55528 : H12AffineFastState.Bounded env55528 := by
  intro p hp
  have h : env55528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55527_55528 : H12AffineEnvironment.transform 16 5392 env55527 = env55528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env55527 == env55528) = true)

theorem identity55528 : scanCanonicalize (H12AffineFastState.compose env55528 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55528 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10281,1024,8540,4161,32,17,138,8328,64,10708,5392,4096,2420,1500,33,256,33,5593,513]

theorem envBound55529 : H12AffineFastState.Bounded env55529 := by
  intro p hp
  have h : env55529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55528_55529 : H12AffineEnvironment.transform 15 8203 env55528 = env55529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55528 == env55529) = true)

theorem identity55529 : scanCanonicalize (H12AffineFastState.compose env55529 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55529 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10281,1024,8540,4161,32,17,2,8192,64,10588,5392,4096,2420,1364,33,256,33,5457,513]

theorem envBound55530 : H12AffineFastState.Bounded env55530 := by
  intro p hp
  have h : env55530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55529_55530 : H12AffineEnvironment.transform 6 8 env55529 = env55530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55529 == env55530) = true)

theorem identity55530 : scanCanonicalize (H12AffineFastState.compose env55530 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound55530 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,5377,261,83,5392,2161,1024,260,4161,32,17,2,88,64,2308,5392,4096,2420,1364,33,256,33,5457,513]

theorem envBound55531 : H12AffineFastState.Bounded env55531 := by
  intro p hp
  have h : env55531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55530_55531 : H12AffineEnvironment.transform 12 88 env55530 = env55531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env55530 == env55531) = true)

theorem identity55531 : scanCanonicalize (H12AffineFastState.compose env55531 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55531 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env55532 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,5377,261,2,5392,2080,1024,260,4112,32,17,2,9,17,2308,5392,4096,2341,1285,33,256,33,5376,513]

theorem envBound55532 : H12AffineFastState.Bounded env55532 := by
  intro p hp
  have h : env55532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55531_55532 : H12AffineEnvironment.transform 5 17 env55531 = env55532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55531 == env55532) = true)

theorem identity55532 : scanCanonicalize (H12AffineFastState.compose env55532 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound55532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55533 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,292,9,1061,261,2,1076,2080,1024,260,308,32,17,2,9,17,2308,1076,292,2341,1285,33,256,33,1060,513]

theorem envBound55533 : H12AffineFastState.Bounded env55533 := by
  intro p hp
  have h : env55533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55532_55533 : H12AffineEnvironment.transform 11 292 env55532 = env55533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env55532 == env55533) = true)

theorem identity55533 : scanCanonicalize (H12AffineFastState.compose env55533 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55533 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55534 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,292,9,1061,261,2,1076,2080,1024,260,308,32,17,2,9,17,2308,1076,292,2341,1285,33,256,33,1060,0]

theorem envBound55534 : H12AffineFastState.Bounded env55534 := by
  intro p hp
  have h : env55534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55533_55534 : H12AffineEnvironment.transform 8 1 env55533 = env55534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55533 == env55534) = true)

def env55535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,16,73857,8328,64,4592844,5393,4096,406604,20700,4194304,256,21792,16600,96010]

theorem envBound55535 : H12AffineFastState.Bounded env55535 := by
  intro p hp
  have h : env55535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55521_55535 : H12AffineEnvironment.transform 20 17729 env55521 = env55535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env55521 == env55535) = true)

def env55536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4161,4194304,16,73857,8328,64,4592844,5393,4096,406604,1500,4194304,256,32,5592,74250]

theorem envBound55536 : H12AffineFastState.Bounded env55536 := by
  intro p hp
  have h : env55536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55535_55536 : H12AffineEnvironment.transform 13 5376 env55535 = env55536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55535 == env55536) = true)

def env55537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5392,262144,1024,8541,4161,4194304,16,73857,8328,64,4456924,5393,4096,270684,1500,4194304,256,32,5592,74250]

theorem envBound55537 : H12AffineFastState.Bounded env55537 := by
  intro p hp
  have h : env55537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55536_55537 : H12AffineEnvironment.transform 16 5392 env55536 = env55537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env55536 == env55537) = true)

theorem identity55537 : scanCanonicalize (H12AffineFastState.compose env55537 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound55537 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5392,67754,1024,8541,4161,4194304,16,73857,8328,64,4262262,5393,4096,76278,1500,4194304,256,32,5592,74250]

theorem envBound55538 : H12AffineFastState.Bounded env55538 := by
  intro p hp
  have h : env55538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55537_55538 : H12AffineEnvironment.transform 17 67754 env55537 = env55538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env55537 == env55538) = true)

theorem identity55538 : scanCanonicalize (H12AffineFastState.compose env55538 (packedSelected [0,1,4,7,8,9,10,11,15,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55538 : packedSelected [0,1,4,7,8,9,10,11,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env55539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,80,65536,5392,67754,1024,81,4161,4194304,16,65933,388,64,4262262,5393,4096,67834,1500,4194304,256,32,5592,66310]

theorem envBound55539 : H12AffineFastState.Bounded env55539 := by
  intro p hp
  have h : env55539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55538_55539 : H12AffineEnvironment.transform 12 268 env55538 = env55539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55538 == env55539) = true)

def env55540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5393,262144,1024,8541,4161,4194304,16,73857,8328,64,4456925,5393,4096,270685,1500,4194304,256,32,5592,74250]

theorem envBound55540 : H12AffineFastState.Bounded env55540 := by
  intro p hp
  have h : env55540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55536_55540 : H12AffineEnvironment.transform 16 5393 env55536 = env55540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55536 == env55540) = true)

theorem identity55540 : scanCanonicalize (H12AffineFastState.compose env55540 (packedSelected [5,8,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55540 : packedSelected [5,8,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5393,262144,1024,8541,4161,4194304,16,138,8328,64,4456925,5393,4096,270685,1500,4194304,256,32,5592,513]

theorem envBound55541 : H12AffineFastState.Bounded env55541 := by
  intro p hp
  have h : env55541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55540_55541 : H12AffineEnvironment.transform 15 8203 env55540 = env55541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55540 == env55541) = true)

theorem identity55541 : scanCanonicalize (H12AffineFastState.compose env55541 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10481) := by decide +kernel

theorem selectedBound55541 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10481,1024,8541,4161,4194304,16,138,8328,64,4204844,5393,4096,2476,1500,4194304,256,32,5592,513]

theorem envBound55542 : H12AffineFastState.Bounded env55542 := by
  intro p hp
  have h : env55542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55541_55542 : H12AffineEnvironment.transform 17 10481 env55541 = env55542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10481 env55541 == env55542) = true)

theorem identity55542 : scanCanonicalize (H12AffineFastState.compose env55542 (packedSelected [1,11,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound55542 : packedSelected [1,11,23,24] rootPS < 2^1333 := by decide +kernel

def env55543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10481,1024,8541,4161,8572,16,138,8328,64,2128,5393,4096,2476,1500,8572,256,32,5592,513]

theorem envBound55543 : H12AffineFastState.Bounded env55543 := by
  intro p hp
  have h : env55543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55542_55543 : H12AffineEnvironment.transform 21 8572 env55542 = env55543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env55542 == env55543) = true)

theorem identity55543 : scanCanonicalize (H12AffineFastState.compose env55543 (packedSelected [4,5,8,9,11,14,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55543 : packedSelected [4,5,8,9,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env55544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8460,8203,5393,10401,1024,8461,4113,8492,16,138,8328,16,2048,5393,4096,2476,1420,8492,256,32,5512,513]

theorem envBound55544 : H12AffineFastState.Bounded env55544 := by
  intro p hp
  have h : env55544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55543_55544 : H12AffineEnvironment.transform 5 16 env55543 = env55544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55543 == env55544) = true)

theorem identity55544 : scanCanonicalize (H12AffineFastState.compose env55544 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55544 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55545 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5292,8352,8203,5309,10401,1024,8353,4113,8320,16,138,8328,16,2048,5309,4096,2048,1056,8320,172,32,5156,513]

theorem envBound55545 : H12AffineFastState.Bounded env55545 := by
  intro p hp
  have h : env55545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55544_55545 : H12AffineEnvironment.transform 7 172 env55544 = env55545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55544 == env55545) = true)

theorem identity55545 : scanCanonicalize (H12AffineFastState.compose env55545 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55545 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55546 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8232,8203,5173,10281,1024,8233,4113,8200,16,2,8192,16,2048,5173,4096,2048,1056,8200,36,32,5156,513]

theorem envBound55546 : H12AffineFastState.Bounded env55546 := by
  intro p hp
  have h : env55546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55545_55546 : H12AffineEnvironment.transform 6 8 env55545 = env55546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55545 == env55546) = true)

theorem identity55546 : scanCanonicalize (H12AffineFastState.compose env55546 (packedSelected [0,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55546 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env55547 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4113,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound55547 : H12AffineFastState.Bounded env55547 := by
  intro p hp
  have h : env55547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55546_55547 : H12AffineEnvironment.transform 12 41 env55546 = env55547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55546 == env55547) = true)

def env55548 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,1,34,1029,2048,1024,0,33,33,16,2,41,16,2048,1029,48,2048,1056,33,36,32,1044,513]

theorem envBound55548 : H12AffineFastState.Bounded env55548 := by
  intro p hp
  have h : env55548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55547_55548 : H12AffineEnvironment.transform 11 48 env55547 = env55548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55547 == env55548) = true)

theorem identity55548 : scanCanonicalize (H12AffineFastState.compose env55548 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55549 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,48,41,1044,1,34,1029,1,1024,0,33,33,16,2,41,16,1,1029,48,1,1056,33,36,32,1044,513]

theorem envBound55549 : H12AffineFastState.Bounded env55549 := by
  intro p hp
  have h : env55549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55548_55549 : H12AffineEnvironment.transform 10 1 env55548 = env55549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55548 == env55549) = true)

def env55550 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,41,32,1,34,49,1,52,0,33,33,16,2,41,16,1,49,48,1,20,33,36,32,32,513]

theorem envBound55550 : H12AffineFastState.Bounded env55550 := by
  intro p hp
  have h : env55550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55549_55550 : H12AffineEnvironment.transform 9 52 env55549 = env55550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55549 == env55550) = true)

theorem identity55550 : scanCanonicalize (H12AffineFastState.compose env55550 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55551 : List Nat := [2,4,8,16,32,16,8,36,42,52,1,48,41,32,1,34,49,1,52,0,33,33,16,2,41,16,1,49,48,1,20,33,36,32,32,43]

theorem envBound55551 : H12AffineFastState.Bounded env55551 := by
  intro p hp
  have h : env55551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55550_55551 : H12AffineEnvironment.transform 8 42 env55550 = env55551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55550 == env55551) = true)

def leafEnv55551 : List Nat := [2,4,8,16,32,16,8,36,42,52,1,48,41,32,1,34,49,1,52,0,33,33,16,2,20,41,1,16,1,49,48,1,20,33,36,32,4,34,32,43,1,33,0]

def active55551 : List Nat := [0,1,2,3,4]

def tree55551 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55551 : H12WitnessSearch.Good tree55551 := H12GlobalWitnessIndex.good

theorem leafIdentity55551 : H12AffineFastState.composeSystem env55551 rootObs = leafEnv55551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55551 rootObs == leafEnv55551) = true)

theorem terminalChecked55551 : H12PackedTerminal.terminalCheckFast leafEnv55551 active55551 tree55551 = true := by decide +kernel

def env55552 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,48,41,33,1,34,48,1,53,0,33,33,16,2,41,16,1,48,48,1,21,33,36,32,33,513]

theorem envBound55552 : H12AffineFastState.Bounded env55552 := by
  intro p hp
  have h : env55552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55549_55552 : H12AffineEnvironment.transform 9 53 env55549 = env55552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55549 == env55552) = true)

def env55553 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,1,34,1028,2048,1024,0,32,33,16,2,41,16,2048,1028,49,2048,1056,33,36,32,1045,513]

theorem envBound55553 : H12AffineFastState.Bounded env55553 := by
  intro p hp
  have h : env55553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55547_55553 : H12AffineEnvironment.transform 11 49 env55547 = env55553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55547 == env55553) = true)

theorem identity55553 : scanCanonicalize (H12AffineFastState.compose env55553 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound55553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55554 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,49,41,1045,1,34,1028,1077,1024,0,32,33,16,2,41,16,1077,1028,49,1077,1056,33,36,32,1045,513]

theorem envBound55554 : H12AffineFastState.Bounded env55554 := by
  intro p hp
  have h : env55554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55553_55554 : H12AffineEnvironment.transform 10 1077 env55553 = env55554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env55553 == env55554) = true)

def env55555 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,49,41,33,1,34,48,1,52,0,32,33,16,2,41,16,1,48,49,1,20,33,36,32,33,513]

theorem envBound55555 : H12AffineFastState.Bounded env55555 := by
  intro p hp
  have h : env55555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55554_55555 : H12AffineEnvironment.transform 9 52 env55554 = env55555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55554 == env55555) = true)

theorem identity55555 : scanCanonicalize (H12AffineFastState.compose env55555 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55556 : List Nat := [2,4,8,16,32,16,8,36,42,52,1,49,41,33,1,34,48,1,52,0,32,33,16,2,41,16,1,48,49,1,20,33,36,32,33,43]

theorem envBound55556 : H12AffineFastState.Bounded env55556 := by
  intro p hp
  have h : env55556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55555_55556 : H12AffineEnvironment.transform 8 42 env55555 = env55556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55555 == env55556) = true)

def leafEnv55556 : List Nat := [2,4,8,16,32,16,8,36,42,52,1,49,41,33,1,34,48,1,52,0,32,33,16,2,20,41,1,16,1,48,49,1,20,33,36,32,4,34,33,43,1,32,0]

def active55556 : List Nat := [0,1,2,3,4]

def tree55556 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55556 : H12WitnessSearch.Good tree55556 := H12GlobalWitnessIndex.good

theorem leafIdentity55556 : H12AffineFastState.composeSystem env55556 rootObs = leafEnv55556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55556 rootObs == leafEnv55556) = true)

theorem terminalChecked55556 : H12PackedTerminal.terminalCheckFast leafEnv55556 active55556 tree55556 = true := by decide +kernel

def env55557 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,49,41,32,1,34,49,0,53,0,32,33,16,2,41,16,0,49,49,0,21,33,36,32,32,513]

theorem envBound55557 : H12AffineFastState.Bounded env55557 := by
  intro p hp
  have h : env55557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55554_55557 : H12AffineEnvironment.transform 9 53 env55554 = env55557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55554 == env55557) = true)

def env55558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,4194304,16,73857,8328,64,4592844,5393,4096,406604,1501,4194304,256,33,5593,74251]

theorem envBound55558 : H12AffineFastState.Bounded env55558 := by
  intro p hp
  have h : env55558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55535_55558 : H12AffineEnvironment.transform 13 5377 env55535 = env55558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55535 == env55558) = true)

theorem identity55558 : scanCanonicalize (H12AffineFastState.compose env55558 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55558 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,4194304,16,73737,8192,64,4592708,5393,4096,406604,1365,4194304,256,33,5457,74251]

theorem envBound55559 : H12AffineFastState.Bounded env55559 := by
  intro p hp
  have h : env55559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55558_55559 : H12AffineEnvironment.transform 6 8 env55558 = env55559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55558 == env55559) = true)

theorem identity55559 : scanCanonicalize (H12AffineFastState.compose env55559 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound55559 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env55560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,67619,1024,8540,4160,4194304,16,73737,8192,64,4398183,5393,4096,212079,1365,4194304,256,33,5457,74251]

theorem envBound55560 : H12AffineFastState.Bounded env55560 := by
  intro p hp
  have h : env55560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55559_55560 : H12AffineEnvironment.transform 17 67619 env55559 = env55560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env55559 == env55560) = true)

theorem identity55560 : scanCanonicalize (H12AffineFastState.compose env55560 (packedSelected [0,2,6,11,14,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound55560 : packedSelected [0,2,6,11,14,23,27] rootPS < 2^1333 := by decide +kernel

def env55561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,5393,67619,1024,8540,4160,4194304,16,73737,8192,64,4262262,5393,4096,76158,1365,4194304,256,33,5457,74251]

theorem envBound55561 : H12AffineFastState.Bounded env55561 := by
  intro p hp
  have h : env55561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55560_55561 : H12AffineEnvironment.transform 16 5393 env55560 = env55561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55560 == env55561) = true)

theorem identity55561 : scanCanonicalize (H12AffineFastState.compose env55561 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55561 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env55562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,342,5393,2421,1024,8540,4160,4194304,16,8543,8192,64,4196384,5393,4096,10280,1365,4194304,256,33,5457,9053]

theorem envBound55562 : H12AffineFastState.Bounded env55562 := by
  intro p hp
  have h : env55562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55561_55562 : H12AffineEnvironment.transform 15 342 env55561 = env55562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55561 == env55562) = true)

theorem identity55562 : scanCanonicalize (H12AffineFastState.compose env55562 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound55562 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55563 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,342,5393,2421,1024,8540,4160,8573,16,8543,8192,64,10589,5393,4096,10280,1365,8573,256,33,5457,9053]

theorem envBound55563 : H12AffineFastState.Bounded env55563 := by
  intro p hp
  have h : env55563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55562_55563 : H12AffineEnvironment.transform 21 8573 env55562 = env55563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env55562 == env55563) = true)

theorem identity55563 : scanCanonicalize (H12AffineFastState.compose env55563 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55563 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55564 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,5205,8201,2,5189,2081,1024,8200,4160,8233,16,8203,8192,64,10249,5189,4096,10280,1025,8233,84,33,5125,8713]

theorem envBound55564 : H12AffineFastState.Bounded env55564 := by
  intro p hp
  have h : env55564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55563_55564 : H12AffineEnvironment.transform 7 84 env55563 = env55564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55563 == env55564) = true)

theorem identity55564 : scanCanonicalize (H12AffineFastState.compose env55564 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55564 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env55565 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,8192,5124,8201,2,5140,2081,1024,8200,4113,8233,16,8203,8192,17,10249,5140,4096,10280,1025,8233,5,33,5125,8713]

theorem envBound55565 : H12AffineFastState.Bounded env55565 := by
  intro p hp
  have h : env55565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55564_55565 : H12AffineEnvironment.transform 5 17 env55564 = env55565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55564 == env55565) = true)

theorem identity55565 : scanCanonicalize (H12AffineFastState.compose env55565 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound55565 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55566 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,3108,8192,2080,8201,2,2096,2081,1024,8200,3125,8233,16,8203,8192,17,10249,2096,3108,10280,1025,8233,5,33,2081,8713]

theorem envBound55566 : H12AffineFastState.Bounded env55566 := by
  intro p hp
  have h : env55566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55565_55566 : H12AffineEnvironment.transform 11 3108 env55565 = env55566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env55565 == env55566) = true)

theorem identity55566 : scanCanonicalize (H12AffineFastState.compose env55566 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55566 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env55567 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,2065,8192,2080,8201,2,2096,2081,53,8200,2048,8233,16,8203,8192,17,10249,2096,2065,10280,52,8233,5,33,2081,8713]

theorem envBound55567 : H12AffineFastState.Bounded env55567 := by
  intro p hp
  have h : env55567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55566_55567 : H12AffineEnvironment.transform 9 53 env55566 = env55567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55566 == env55567) = true)

theorem identity55567 : scanCanonicalize (H12AffineFastState.compose env55567 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound55567 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env55568 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,2065,9,2080,0,2,2096,2081,53,1,2048,32,16,2,9,17,2048,2096,2065,2081,52,32,5,33,2081,512]

theorem envBound55568 : H12AffineFastState.Bounded env55568 := by
  intro p hp
  have h : env55568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55567_55568 : H12AffineEnvironment.transform 12 9 env55567 = env55568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env55567 == env55568) = true)

theorem identity55568 : scanCanonicalize (H12AffineFastState.compose env55568 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55568 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55569 : List Nat := [2,4,8,16,0,17,8,5,512,21,2048,2065,9,2048,0,2,2064,2049,21,1,2048,0,16,2,9,17,2048,2064,2065,2049,20,0,5,1,2049,512]

theorem envBound55569 : H12AffineFastState.Bounded env55569 := by
  intro p hp
  have h : env55569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55568_55569 : H12AffineEnvironment.transform 4 0 env55568 = env55569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55568 == env55569) = true)

theorem identity55569 : scanCanonicalize (H12AffineFastState.compose env55569 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55570 : List Nat := [2,4,8,16,0,17,8,5,1,21,2048,2065,9,2048,0,2,2064,2049,21,1,2048,0,16,2,9,17,2048,2064,2065,2049,20,0,5,1,2049,1]

theorem envBound55570 : H12AffineFastState.Bounded env55570 := by
  intro p hp
  have h : env55570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55569_55570 : H12AffineEnvironment.transform 8 1 env55569 = env55570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55569 == env55570) = true)

theorem identity55570 : scanCanonicalize (H12AffineFastState.compose env55570 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound55570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55571 : List Nat := [2,4,8,16,0,17,8,5,1,21,30,15,9,30,0,2,14,31,21,1,30,0,16,2,9,17,30,14,15,31,20,0,5,1,31,1]

theorem envBound55571 : H12AffineFastState.Bounded env55571 := by
  intro p hp
  have h : env55571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55570_55571 : H12AffineEnvironment.transform 10 30 env55570 = env55571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env55570 == env55571) = true)

def leafEnv55571 : List Nat := [2,4,8,16,0,17,8,5,1,21,30,15,9,30,0,2,14,31,21,1,30,0,16,2,20,9,1,17,30,14,15,31,20,0,5,1,4,2,31,1,1,31,0]

def active55571 : List Nat := [0,1,2,3]

def tree55571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55571 : H12WitnessSearch.Good tree55571 := H12GlobalWitnessIndex.good

theorem leafIdentity55571 : H12AffineFastState.composeSystem env55571 rootObs = leafEnv55571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55571 rootObs == leafEnv55571) = true)

theorem terminalChecked55571 : H12PackedTerminal.terminalCheckFast leafEnv55571 active55571 tree55571 = true := by decide +kernel

def env55572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,8388608,10577360,8328,64,6705548,8393984,10507601,8795229,2102684,12582928,256,21793,16600,2175562]

theorem envBound55572 : H12AffineFastState.Bounded env55572 := by
  intro p hp
  have h : env55572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55475_55572 : H12AffineEnvironment.transform 14 29789 env55475 = env55572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env55475 == env55572) = true)

def env55573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114896,73856,8328,64,6705548,2117712,4097,2519309,2102684,6309184,256,21793,16600,2175562]

theorem envBound55573 : H12AffineFastState.Bounded env55573 := by
  intro p hp
  have h : env55573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55572_55573 : H12AffineEnvironment.transform 22 2114896 env55572 = env55573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env55572 == env55573) = true)

def env55574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,16,73856,8328,64,4592844,5392,4097,406605,20700,4194304,256,21793,16600,96010]

theorem envBound55574 : H12AffineFastState.Bounded env55574 := by
  intro p hp
  have h : env55574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55573_55574 : H12AffineEnvironment.transform 20 17728 env55573 = env55574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env55573 == env55574) = true)

theorem identity55574 : scanCanonicalize (H12AffineFastState.compose env55574 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound55574 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,30083,131072,262144,1024,29788,17728,4194304,16,21763,8328,64,4592844,5392,4097,406605,20700,4194304,256,21793,16600,649]

theorem envBound55575 : H12AffineFastState.Bounded env55575 := by
  intro p hp
  have h : env55575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55574_55575 : H12AffineEnvironment.transform 15 30083 env55574 = env55575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env55574 == env55575) = true)

def env55576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8323,131072,262144,1024,8540,4160,4194304,16,3,8328,64,4592844,5392,4097,406605,1500,4194304,256,33,5592,649]

theorem envBound55576 : H12AffineFastState.Bounded env55576 := by
  intro p hp
  have h : env55576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55575_55576 : H12AffineEnvironment.transform 13 5376 env55575 = env55576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55575 == env55576) = true)

theorem identity55576 : scanCanonicalize (H12AffineFastState.compose env55576 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55576 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,4194304,16,3,8192,64,4592708,5392,4097,406605,1364,4194304,256,33,5456,513]

theorem envBound55577 : H12AffineFastState.Bounded env55577 := by
  intro p hp
  have h : env55577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55576_55577 : H12AffineEnvironment.transform 6 8 env55576 = env55577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55576 == env55577) = true)

theorem identity55577 : scanCanonicalize (H12AffineFastState.compose env55577 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound55577 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,8492,16,3,8192,64,406888,5392,4097,406605,1364,8492,256,33,5456,513]

theorem envBound55578 : H12AffineFastState.Bounded env55578 := by
  intro p hp
  have h : env55578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55577_55578 : H12AffineEnvironment.transform 21 8492 env55577 = env55578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env55577 == env55578) = true)

theorem identity55578 : scanCanonicalize (H12AffineFastState.compose env55578 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound55578 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,2420,1024,8540,4160,8492,16,3,8192,64,146460,5392,4097,146745,1364,8492,256,33,5456,513]

theorem envBound55579 : H12AffineFastState.Bounded env55579 := by
  intro p hp
  have h : env55579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55578_55579 : H12AffineEnvironment.transform 17 2420 env55578 = env55579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env55578 == env55579) = true)

theorem identity55579 : scanCanonicalize (H12AffineFastState.compose env55579 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55579 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,131072,2420,1024,1,4160,113,16,3,349,64,138561,5392,4097,138340,1364,113,256,33,5456,513]

theorem envBound55580 : H12AffineFastState.Bounded env55580 := by
  intro p hp
  have h : env55580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55579_55580 : H12AffineEnvironment.transform 12 349 env55579 = env55580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55579 == env55580) = true)

theorem identity55580 : scanCanonicalize (H12AffineFastState.compose env55580 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound55580 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5393,2420,1024,1,4160,113,16,3,349,64,2128,5392,4097,2421,1364,113,256,33,5456,513]

theorem envBound55581 : H12AffineFastState.Bounded env55581 := by
  intro p hp
  have h : env55581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55580_55581 : H12AffineEnvironment.transform 16 5393 env55580 = env55581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55580 == env55581) = true)

theorem identity55581 : scanCanonicalize (H12AffineFastState.compose env55581 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55581 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55582 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1024,1,4113,32,16,3,268,17,2049,5392,4097,2340,1285,32,256,33,5377,513]

theorem envBound55582 : H12AffineFastState.Bounded env55582 := by
  intro p hp
  have h : env55582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55581_55582 : H12AffineEnvironment.transform 5 17 env55581 = env55582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55581 == env55582) = true)

theorem identity55582 : scanCanonicalize (H12AffineFastState.compose env55582 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55583 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,9,5125,0,2,5140,2080,1024,1,4113,32,16,3,9,17,2049,5141,4097,2081,1024,32,5,33,5124,513]

theorem envBound55583 : H12AffineFastState.Bounded env55583 := by
  intro p hp
  have h : env55583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55582_55583 : H12AffineEnvironment.transform 7 5 env55582 = env55583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55582 == env55583) = true)

theorem identity55583 : scanCanonicalize (H12AffineFastState.compose env55583 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55583 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55584 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,4096,9,4144,0,2,4129,2080,53,1,4113,32,16,3,9,17,2049,4128,4097,2081,53,32,5,33,4145,513]

theorem envBound55584 : H12AffineFastState.Bounded env55584 := by
  intro p hp
  have h : env55584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55583_55584 : H12AffineEnvironment.transform 9 53 env55583 = env55584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55583 == env55584) = true)

theorem identity55584 : scanCanonicalize (H12AffineFastState.compose env55584 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound55584 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55585 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,2609,9,2561,0,2,2576,2080,53,1,2592,32,16,3,9,17,2049,2577,2608,2081,53,32,5,33,2560,513]

theorem envBound55585 : H12AffineFastState.Bounded env55585 := by
  intro p hp
  have h : env55585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55584_55585 : H12AffineEnvironment.transform 11 2609 env55584 = env55585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env55584 == env55585) = true)

theorem identity55585 : scanCanonicalize (H12AffineFastState.compose env55585 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55585 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55586 : List Nat := [2,4,8,16,32,17,8,5,1,53,2048,2096,9,2048,0,2,2065,2080,53,1,2081,32,16,3,9,17,2049,2064,2097,2081,53,32,5,33,2049,0]

theorem envBound55586 : H12AffineFastState.Bounded env55586 := by
  intro p hp
  have h : env55586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55585_55586 : H12AffineEnvironment.transform 8 1 env55585 = env55586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55585 == env55586) = true)

theorem identity55586 : scanCanonicalize (H12AffineFastState.compose env55586 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound55586 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55587 : List Nat := [2,4,8,16,32,17,8,5,1,53,49,1,9,49,0,2,32,17,53,1,16,32,16,3,9,17,48,33,0,16,53,32,5,33,48,0]

theorem envBound55587 : H12AffineFastState.Bounded env55587 := by
  intro p hp
  have h : env55587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55586_55587 : H12AffineEnvironment.transform 10 49 env55586 = env55587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env55586 == env55587) = true)

theorem identity55587 : scanCanonicalize (H12AffineFastState.compose env55587 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55587 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55588 : List Nat := [2,4,8,16,1,17,8,5,1,20,16,1,9,16,0,2,1,17,20,1,16,1,16,3,9,17,17,0,0,16,20,1,5,0,17,0]

theorem envBound55588 : H12AffineFastState.Bounded env55588 := by
  intro p hp
  have h : env55588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55587_55588 : H12AffineEnvironment.transform 4 1 env55587 = env55588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55587 == env55588) = true)

theorem identity55588 : scanCanonicalize (H12AffineFastState.compose env55588 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55588 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55589 : List Nat := [2,4,8,0,1,1,8,5,1,4,0,1,9,0,0,2,1,1,4,1,0,1,0,3,9,1,1,0,0,0,4,1,5,0,1,0]

theorem envBound55589 : H12AffineFastState.Bounded env55589 := by
  intro p hp
  have h : env55589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55588_55589 : H12AffineEnvironment.transform 3 0 env55588 = env55589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55588 == env55589) = true)

def env55590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,262144,1024,8541,4161,4194304,16,2,8328,64,4592844,5392,4097,406605,1501,4194304,256,32,5593,649]

theorem envBound55590 : H12AffineFastState.Bounded env55590 := by
  intro p hp
  have h : env55590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55575_55590 : H12AffineEnvironment.transform 13 5377 env55575 = env55590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55575 == env55590) = true)

theorem identity55590 : scanCanonicalize (H12AffineFastState.compose env55590 (packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound55590 : packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env55591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,10401,1024,8541,4161,4194304,16,2,8328,64,4340845,5392,4097,138476,1501,4194304,256,32,5593,649]

theorem envBound55591 : H12AffineFastState.Bounded env55591 := by
  intro p hp
  have h : env55591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55590_55591 : H12AffineEnvironment.transform 17 10401 env55590 = env55591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55590 == env55591) = true)

theorem identity55591 : scanCanonicalize (H12AffineFastState.compose env55591 (packedSelected [4,9,11,14,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 8692) := by decide +kernel

theorem selectedBound55591 : packedSelected [4,9,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env55592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,10401,1024,8541,4161,8692,16,2,8328,64,138649,5392,4097,138476,1501,8692,256,32,5593,649]

theorem envBound55592 : H12AffineFastState.Bounded env55592 := by
  intro p hp
  have h : env55592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55591_55592 : H12AffineEnvironment.transform 21 8692 env55591 = env55592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8692 env55591 == env55592) = true)

theorem identity55592 : scanCanonicalize (H12AffineFastState.compose env55592 (packedSelected [2,6,9,11,14,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound55592 : packedSelected [2,6,9,11,14,22,23] rootPS < 2^1333 := by decide +kernel

def env55593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,5392,10401,1024,8541,4161,8692,16,2,8328,64,2185,5392,4097,2556,1501,8692,256,32,5593,649]

theorem envBound55593 : H12AffineFastState.Bounded env55593 := by
  intro p hp
  have h : env55593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55592_55593 : H12AffineEnvironment.transform 16 5392 env55592 = env55593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env55592 == env55593) = true)

theorem identity55593 : scanCanonicalize (H12AffineFastState.compose env55593 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55593 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env55594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,1,479,5392,2556,1024,0,4161,169,16,2,469,64,2185,5392,4097,2556,1501,169,256,32,5593,649]

theorem envBound55594 : H12AffineFastState.Bounded env55594 := by
  intro p hp
  have h : env55594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55593_55594 : H12AffineEnvironment.transform 12 349 env55593 = env55594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55593 == env55594) = true)

theorem identity55594 : scanCanonicalize (H12AffineFastState.compose env55594 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55594 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55595 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,1,399,5392,2476,1024,0,4113,169,16,2,389,16,2185,5392,4097,2476,1421,169,256,32,5513,649]

theorem envBound55595 : H12AffineFastState.Bounded env55595 := by
  intro p hp
  have h : env55595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55594_55595 : H12AffineEnvironment.transform 5 16 env55594 = env55595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55594 == env55595) = true)

theorem identity55595 : scanCanonicalize (H12AffineFastState.compose env55595 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound55595 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env55596 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1809,4096,269,5377,1,399,5392,1725,1024,0,4113,169,16,2,389,16,1944,5392,4097,1725,1421,169,256,32,5513,649]

theorem envBound55596 : H12AffineFastState.Bounded env55596 := by
  intro p hp
  have h : env55596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55595_55596 : H12AffineEnvironment.transform 10 1809 env55595 = env55596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env55595 == env55596) = true)

theorem identity55596 : scanCanonicalize (H12AffineFastState.compose env55596 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55596 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env55597 : List Nat := [2,4,8,1,32,1,128,256,512,1024,1792,4096,269,5377,1,399,5377,1708,1024,0,4096,169,1,2,389,1,1929,5377,4097,1708,1421,169,256,32,5513,649]

theorem envBound55597 : H12AffineFastState.Bounded env55597 := by
  intro p hp
  have h : env55597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55596_55597 : H12AffineEnvironment.transform 3 1 env55596 = env55597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55596 == env55597) = true)

theorem identity55597 : scanCanonicalize (H12AffineFastState.compose env55597 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound55597 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env55598 : List Nat := [2,4,8,1,32,1,128,256,512,1024,1792,0,269,1281,1,399,1281,1708,1024,0,0,169,1,2,389,1,1929,1281,1,1708,1421,169,256,32,1417,649]

theorem envBound55598 : H12AffineFastState.Bounded env55598 := by
  intro p hp
  have h : env55598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55597_55598 : H12AffineEnvironment.transform 11 0 env55597 = env55598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env55597 == env55598) = true)

theorem identity55598 : scanCanonicalize (H12AffineFastState.compose env55598 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55598 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env55599 : List Nat := [2,4,8,1,0,1,128,256,512,1024,1792,0,269,1281,1,399,1281,1676,1024,0,0,137,1,2,389,1,1929,1281,1,1676,1421,137,256,0,1417,649]

theorem envBound55599 : H12AffineFastState.Bounded env55599 := by
  intro p hp
  have h : env55599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55598_55599 : H12AffineEnvironment.transform 4 0 env55598 = env55599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55598 == env55599) = true)

theorem identity55599 : scanCanonicalize (H12AffineFastState.compose env55599 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 137) := by decide +kernel

theorem selectedBound55599 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55600 : List Nat := [2,4,8,1,0,1,128,137,512,1024,1673,0,132,1160,1,6,1160,1676,1024,0,0,137,1,2,12,1,1536,1160,1,1676,1028,137,137,0,1024,649]

theorem envBound55600 : H12AffineFastState.Bounded env55600 := by
  intro p hp
  have h : env55600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55599_55600 : H12AffineEnvironment.transform 7 137 env55599 = env55600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 137 env55599 == env55600) = true)

def env55601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,17,73856,8328,64,4592845,5393,4097,406604,20701,4194305,256,21793,16600,96011]

theorem envBound55601 : H12AffineFastState.Bounded env55601 := by
  intro p hp
  have h : env55601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55573_55601 : H12AffineEnvironment.transform 20 17729 env55573 = env55601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env55573 == env55601) = true)

theorem identity55601 : scanCanonicalize (H12AffineFastState.compose env55601 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound55601 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,95650,17,73856,8328,64,483695,5393,4097,406604,20701,95651,256,21793,16600,96011]

theorem envBound55602 : H12AffineFastState.Bounded env55602 := by
  intro p hp
  have h : env55602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55601_55602 : H12AffineEnvironment.transform 21 95650 env55601 = env55602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env55601 == env55602) = true)

theorem identity55602 : scanCanonicalize (H12AffineFastState.compose env55602 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound55602 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env55603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,5392,262144,1024,29788,17729,95650,17,73856,8328,64,357503,5393,4097,270684,20701,95651,256,21793,16600,96011]

theorem envBound55603 : H12AffineFastState.Bounded env55603 := by
  intro p hp
  have h : env55603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55602_55603 : H12AffineEnvironment.transform 16 5392 env55602 = env55603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env55602 == env55603) = true)

theorem identity55603 : scanCanonicalize (H12AffineFastState.compose env55603 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound55603 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,29962,5392,262144,1024,29788,17729,168,17,21898,8328,64,262517,5393,4097,270684,20701,169,256,21793,16600,513]

theorem envBound55604 : H12AffineFastState.Bounded env55604 := by
  intro p hp
  have h : env55604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55603_55604 : H12AffineEnvironment.transform 15 29962 env55603 = env55604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env55603 == env55604) = true)

theorem identity55604 : scanCanonicalize (H12AffineFastState.compose env55604 (packedSelected [11,18,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55604 : packedSelected [11,18,21,23,32] rootPS < 2^1333 := by decide +kernel

def env55605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,262144,1024,29788,17729,32,17,21762,8192,64,262517,5393,4097,270684,20565,33,256,21793,16464,513]

theorem envBound55605 : H12AffineFastState.Bounded env55605 := by
  intro p hp
  have h : env55605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55604_55605 : H12AffineEnvironment.transform 6 8 env55604 = env55605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55604 == env55605) = true)

theorem identity55605 : scanCanonicalize (H12AffineFastState.compose env55605 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound55605 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,2420,1024,29788,17729,32,17,21762,8192,64,2049,5393,4097,10280,20565,33,256,21793,16464,513]

theorem envBound55606 : H12AffineFastState.Bounded env55606 := by
  intro p hp
  have h : env55606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55605_55606 : H12AffineEnvironment.transform 17 2420 env55605 = env55606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env55605 == env55606) = true)

theorem identity55606 : scanCanonicalize (H12AffineFastState.compose env55606 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55606 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5392,2420,1024,8540,4161,32,17,2,8192,64,2049,5393,4097,10280,1365,33,256,33,5456,513]

theorem envBound55607 : H12AffineFastState.Bounded env55607 := by
  intro p hp
  have h : env55607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55606_55607 : H12AffineEnvironment.transform 13 5376 env55606 = env55607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55606 == env55607) = true)

theorem identity55607 : scanCanonicalize (H12AffineFastState.compose env55607 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55607 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55608 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8202,5392,2341,1024,8461,4112,32,17,2,8192,17,2049,5393,4097,10280,1284,33,256,33,5377,513]

theorem envBound55608 : H12AffineFastState.Bounded env55608 := by
  intro p hp
  have h : env55608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55607_55608 : H12AffineEnvironment.transform 5 17 env55607 = env55608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55607 == env55608) = true)

theorem identity55608 : scanCanonicalize (H12AffineFastState.compose env55608 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound55608 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55609 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,5376,8460,8202,5392,1296,1024,8461,4112,32,17,2,8192,17,1076,5393,4097,9245,1284,33,256,33,5377,513]

theorem envBound55609 : H12AffineFastState.Bounded env55609 := by
  intro p hp
  have h : env55609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55608_55609 : H12AffineEnvironment.transform 10 1077 env55608 = env55609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env55608 == env55609) = true)

theorem identity55609 : scanCanonicalize (H12AffineFastState.compose env55609 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound55609 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55610 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,5416,5376,5156,5410,5392,1296,1024,5157,4112,32,17,2,5416,17,1076,5393,4097,4405,1284,33,256,33,5377,513]

theorem envBound55610 : H12AffineFastState.Bounded env55610 := by
  intro p hp
  have h : env55610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55609_55610 : H12AffineEnvironment.transform 12 5416 env55609 = env55610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env55609 == env55610) = true)

theorem identity55610 : scanCanonicalize (H12AffineFastState.compose env55610 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound55610 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env55611 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,1061,269,293,1,263,309,1296,1024,0,1077,32,17,2,269,17,1076,308,1060,1296,1284,33,256,33,292,513]

theorem envBound55611 : H12AffineFastState.Bounded env55611 := by
  intro p hp
  have h : env55611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55610_55611 : H12AffineEnvironment.transform 11 1061 env55610 = env55611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env55610 == env55611) = true)

theorem identity55611 : scanCanonicalize (H12AffineFastState.compose env55611 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55611 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55612 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1044,1028,269,260,1,263,276,1296,1024,0,1044,1,17,2,269,17,1045,277,1029,1296,1284,0,256,0,261,513]

theorem envBound55612 : H12AffineFastState.Bounded env55612 := by
  intro p hp
  have h : env55612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55611_55612 : H12AffineEnvironment.transform 4 1 env55611 = env55612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55611 == env55612) = true)

theorem identity55612 : scanCanonicalize (H12AffineFastState.compose env55612 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55612 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55613 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1044,1028,8,1,1,2,17,1045,1024,0,1044,1,17,2,8,17,1045,16,1029,1045,1025,0,5,0,0,513]

theorem envBound55613 : H12AffineFastState.Bounded env55613 := by
  intro p hp
  have h : env55613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55612_55613 : H12AffineEnvironment.transform 7 5 env55612 = env55613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55612 == env55613) = true)

theorem identity55613 : scanCanonicalize (H12AffineFastState.compose env55613 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55614 : List Nat := [2,4,8,0,1,1,8,5,512,1024,1028,1028,8,1,1,2,1,1029,1024,0,1028,1,1,2,8,1,1029,0,1029,1029,1025,0,5,0,0,513]

theorem envBound55614 : H12AffineFastState.Bounded env55614 := by
  intro p hp
  have h : env55614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55613_55614 : H12AffineEnvironment.transform 3 0 env55613 = env55614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55613 == env55614) = true)

theorem identity55614 : scanCanonicalize (H12AffineFastState.compose env55614 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound55614 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55615 : List Nat := [2,4,8,0,1,1,8,5,512,516,512,512,8,1,1,2,1,513,516,0,512,1,1,2,8,1,513,0,513,513,517,0,5,0,0,513]

theorem envBound55615 : H12AffineFastState.Bounded env55615 := by
  intro p hp
  have h : env55615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55614_55615 : H12AffineEnvironment.transform 9 516 env55614 = env55615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env55614 == env55615) = true)

def env55616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114897,73857,8328,64,6705548,2117713,4096,2519308,2102684,6309185,256,21793,16600,2175562]

theorem envBound55616 : H12AffineFastState.Bounded env55616 := by
  intro p hp
  have h : env55616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55572_55616 : H12AffineEnvironment.transform 22 2114897 env55572 = env55616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env55572 == env55616) = true)

def env55617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,17,73857,8328,64,4592844,5393,4096,406604,20700,4194305,256,21793,16600,96010]

theorem envBound55617 : H12AffineFastState.Bounded env55617 := by
  intro p hp
  have h : env55617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55616_55617 : H12AffineEnvironment.transform 20 17728 env55616 = env55617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env55616 == env55617) = true)

theorem identity55617 : scanCanonicalize (H12AffineFastState.compose env55617 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95531) := by decide +kernel

theorem selectedBound55617 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,95531,17,73857,8328,64,483815,5393,4096,406604,20700,95530,256,21793,16600,96010]

theorem envBound55618 : H12AffineFastState.Bounded env55618 := by
  intro p hp
  have h : env55618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55617_55618 : H12AffineEnvironment.transform 21 95531 env55617 = env55618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95531 env55617 == env55618) = true)

def env55619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,73771,17,73857,8328,64,472295,5393,4096,406604,1500,73770,256,33,5592,74250]

theorem envBound55619 : H12AffineFastState.Bounded env55619 := by
  intro p hp
  have h : env55619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55618_55619 : H12AffineEnvironment.transform 13 5376 env55618 = env55619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55618 == env55619) = true)

theorem identity55619 : scanCanonicalize (H12AffineFastState.compose env55619 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55619 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,4160,73771,17,73857,8328,64,203982,5393,4096,138341,1500,73770,256,33,5592,74250]

theorem envBound55620 : H12AffineFastState.Bounded env55620 := by
  intro p hp
  have h : env55620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55619_55620 : H12AffineEnvironment.transform 17 10281 env55619 = env55620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55619 == env55620) = true)

theorem identity55620 : scanCanonicalize (H12AffineFastState.compose env55620 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound55620 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5393,10281,1024,8540,4160,73771,17,73857,8328,64,68063,5393,4096,2420,1500,73770,256,33,5592,74250]

theorem envBound55621 : H12AffineFastState.Bounded env55621 := by
  intro p hp
  have h : env55621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55620_55621 : H12AffineEnvironment.transform 16 5393 env55620 = env55621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55620 == env55621) = true)

theorem identity55621 : scanCanonicalize (H12AffineFastState.compose env55621 (packedSelected [5,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound55621 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env55622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8323,5393,10281,1024,8540,4160,168,17,2,8328,64,10588,5393,4096,2420,1500,169,256,33,5592,649]

theorem envBound55622 : H12AffineFastState.Bounded env55622 := by
  intro p hp
  have h : env55622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55621_55622 : H12AffineEnvironment.transform 15 8323 env55621 = env55622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env55621 == env55622) = true)

theorem identity55622 : scanCanonicalize (H12AffineFastState.compose env55622 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55622 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10281,1024,8540,4160,33,17,2,8193,64,10588,5393,4096,2420,1365,32,256,33,5457,512]

theorem envBound55623 : H12AffineFastState.Bounded env55623 := by
  intro p hp
  have h : env55623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55622_55623 : H12AffineEnvironment.transform 6 9 env55622 = env55623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55622 == env55623) = true)

theorem identity55623 : scanCanonicalize (H12AffineFastState.compose env55623 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound55623 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5376,112,295,5393,2308,1024,113,4160,33,17,2,300,64,2161,5393,4096,2420,1365,32,256,33,5457,512]

theorem envBound55624 : H12AffineFastState.Bounded env55624 := by
  intro p hp
  have h : env55624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55623_55624 : H12AffineEnvironment.transform 12 301 env55623 = env55624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env55623 == env55624) = true)

theorem identity55624 : scanCanonicalize (H12AffineFastState.compose env55624 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55624 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env55625 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,268,5376,81,262,5393,2308,1024,80,4160,0,17,2,269,64,2128,5393,4096,2389,1365,1,256,0,5457,512]

theorem envBound55625 : H12AffineFastState.Bounded env55625 := by
  intro p hp
  have h : env55625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55624_55625 : H12AffineEnvironment.transform 4 1 env55624 = env55625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55624 == env55625) = true)

theorem identity55625 : scanCanonicalize (H12AffineFastState.compose env55625 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55625 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env55626 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5204,81,82,5189,2128,1024,80,4160,0,17,2,89,64,2128,5189,4096,2049,1025,1,84,0,5125,512]

theorem envBound55626 : H12AffineFastState.Bounded env55626 := by
  intro p hp
  have h : env55626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55625_55626 : H12AffineEnvironment.transform 7 84 env55625 = env55626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55625 == env55626) = true)

theorem identity55626 : scanCanonicalize (H12AffineFastState.compose env55626 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55626 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55627 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1,4096,88,5204,81,82,5189,81,1024,80,4160,0,17,2,89,64,81,5189,4096,0,1025,1,84,0,5125,512]

theorem envBound55627 : H12AffineFastState.Bounded env55627 := by
  intro p hp
  have h : env55627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55626_55627 : H12AffineEnvironment.transform 10 1 env55626 = env55627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55626 == env55627) = true)

def env55628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4161,73770,17,73857,8328,64,472294,5393,4096,406604,1501,73771,256,32,5593,74251]

theorem envBound55628 : H12AffineFastState.Bounded env55628 := by
  intro p hp
  have h : env55628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55618_55628 : H12AffineEnvironment.transform 13 5377 env55618 = env55628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55618 == env55628) = true)

theorem identity55628 : scanCanonicalize (H12AffineFastState.compose env55628 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound55628 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10401,1024,8541,4161,73770,17,73857,8328,64,203847,5393,4096,138477,1501,73771,256,32,5593,74251]

theorem envBound55629 : H12AffineFastState.Bounded env55629 := by
  intro p hp
  have h : env55629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55628_55629 : H12AffineEnvironment.transform 17 10401 env55628 = env55629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55628 == env55629) = true)

theorem identity55629 : scanCanonicalize (H12AffineFastState.compose env55629 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55629 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8202,131072,10401,1024,8541,4161,32,17,139,8328,64,146509,5393,4096,138477,1501,33,256,32,5593,513]

theorem envBound55630 : H12AffineFastState.Bounded env55630 := by
  intro p hp
  have h : env55630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55629_55630 : H12AffineEnvironment.transform 15 8202 env55629 = env55630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55629 == env55630) = true)

theorem identity55630 : scanCanonicalize (H12AffineFastState.compose env55630 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound55630 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8202,13461,10401,1024,8541,4161,32,17,139,8328,64,2264,5393,4096,10360,1501,33,256,32,5593,513]

theorem envBound55631 : H12AffineFastState.Bounded env55631 := by
  intro p hp
  have h : env55631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55630_55631 : H12AffineEnvironment.transform 16 13461 env55630 = env55631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env55630 == env55631) = true)

theorem identity55631 : scanCanonicalize (H12AffineFastState.compose env55631 (packedSelected [11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55631 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env55632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,13340,10280,1024,8541,4161,32,17,2,8193,64,2129,5393,4096,10360,1364,33,256,32,5456,513]

theorem envBound55632 : H12AffineFastState.Bounded env55632 := by
  intro p hp
  have h : env55632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55631_55632 : H12AffineEnvironment.transform 6 9 env55631 = env55632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55631 == env55632) = true)

theorem identity55632 : scanCanonicalize (H12AffineFastState.compose env55632 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound55632 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,292,114,5220,2128,1024,293,4161,32,17,2,121,64,2129,5393,4096,2048,1364,33,256,32,5456,513]

theorem envBound55633 : H12AffineFastState.Bounded env55633 := by
  intro p hp
  have h : env55633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55632_55633 : H12AffineEnvironment.transform 12 120 env55632 = env55633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env55632 == env55633) = true)

theorem identity55633 : scanCanonicalize (H12AffineFastState.compose env55633 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound55633 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env55634 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,120,4453,292,114,4096,2128,100,293,4161,32,17,2,121,64,2129,4469,4096,2048,304,33,256,32,4404,513]

theorem envBound55634 : H12AffineFastState.Bounded env55634 := by
  intro p hp
  have h : env55634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55633_55634 : H12AffineEnvironment.transform 9 100 env55633 = env55634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env55633 == env55634) = true)

theorem identity55634 : scanCanonicalize (H12AffineFastState.compose env55634 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound55634 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55635 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,120,2340,292,114,2113,2128,100,293,2048,32,17,2,121,64,2129,2356,2113,2048,304,33,256,32,2421,513]

theorem envBound55635 : H12AffineFastState.Bounded env55635 := by
  intro p hp
  have h : env55635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55634_55635 : H12AffineEnvironment.transform 11 2113 env55634 = env55635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env55634 == env55635) = true)

theorem identity55635 : scanCanonicalize (H12AffineFastState.compose env55635 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55635 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env55636 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2113,120,2128,80,114,2113,2128,100,81,2048,32,17,2,121,64,2129,2112,2113,2048,68,33,116,32,2049,513]

theorem envBound55636 : H12AffineFastState.Bounded env55636 := by
  intro p hp
  have h : env55636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55635_55636 : H12AffineEnvironment.transform 7 116 env55635 = env55636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55635 == env55636) = true)

theorem identity55636 : scanCanonicalize (H12AffineFastState.compose env55636 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 50) := by decide +kernel

theorem selectedBound55636 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55637 : List Nat := [2,4,8,16,32,64,9,116,512,100,50,115,120,98,80,114,115,98,100,81,50,32,17,2,121,64,99,114,115,50,68,33,116,32,51,513]

theorem envBound55637 : H12AffineFastState.Bounded env55637 := by
  intro p hp
  have h : env55637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55636_55637 : H12AffineEnvironment.transform 10 50 env55636 = env55637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 50 env55636 == env55637) = true)

theorem identity55637 : scanCanonicalize (H12AffineFastState.compose env55637 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound55637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55638 : List Nat := [2,4,8,16,32,1,9,53,512,37,50,50,57,35,17,51,50,35,37,16,50,32,17,2,56,1,34,51,50,50,5,33,53,32,51,513]

theorem envBound55638 : H12AffineFastState.Bounded env55638 := by
  intro p hp
  have h : env55638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55637_55638 : H12AffineEnvironment.transform 5 1 env55637 = env55638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55637 == env55638) = true)

theorem identity55638 : scanCanonicalize (H12AffineFastState.compose env55638 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55638 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55639 : List Nat := [2,4,2,16,32,1,3,53,512,37,50,50,51,35,17,51,50,35,37,16,50,32,17,2,50,1,34,51,50,50,5,33,53,32,51,513]

theorem envBound55639 : H12AffineFastState.Bounded env55639 := by
  intro p hp
  have h : env55639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55638_55639 : H12AffineEnvironment.transform 2 2 env55638 = env55639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55638 == env55639) = true)

theorem identity55639 : scanCanonicalize (H12AffineFastState.compose env55639 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55639 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55640 : List Nat := [2,4,2,16,0,1,3,21,512,5,18,18,19,3,17,19,18,3,5,16,18,0,17,2,18,1,2,19,18,18,5,1,21,0,19,513]

theorem envBound55640 : H12AffineFastState.Bounded env55640 := by
  intro p hp
  have h : env55640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55639_55640 : H12AffineEnvironment.transform 4 0 env55639 = env55640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55639 == env55640) = true)

theorem identity55640 : scanCanonicalize (H12AffineFastState.compose env55640 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55640 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55641 : List Nat := [2,4,2,1,0,1,3,4,512,5,3,3,2,3,0,2,3,3,5,1,3,0,0,2,3,1,2,2,3,3,5,1,4,0,2,513]

theorem envBound55641 : H12AffineFastState.Bounded env55641 := by
  intro p hp
  have h : env55641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55640_55641 : H12AffineEnvironment.transform 3 1 env55640 = env55641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55640 == env55641) = true)

theorem identity55641 : scanCanonicalize (H12AffineFastState.compose env55641 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55642 : List Nat := [2,1,2,1,0,1,3,1,512,0,3,3,2,3,0,2,3,3,0,1,3,0,0,2,3,1,2,2,3,3,0,1,1,0,2,513]

theorem envBound55642 : H12AffineFastState.Bounded env55642 := by
  intro p hp
  have h : env55642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55641_55642 : H12AffineEnvironment.transform 1 1 env55641 = env55642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55641 == env55642) = true)

def env55643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,16,73857,8328,64,4592845,5392,4096,406605,20701,4194304,256,21793,16600,96011]

theorem envBound55643 : H12AffineFastState.Bounded env55643 := by
  intro p hp
  have h : env55643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55616_55643 : H12AffineEnvironment.transform 20 17729 env55616 = env55643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env55616 == env55643) = true)

theorem identity55643 : scanCanonicalize (H12AffineFastState.compose env55643 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound55643 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,17729,4194304,16,21899,8328,64,4592845,5392,4096,406605,20701,4194304,256,21793,16600,513]

theorem envBound55644 : H12AffineFastState.Bounded env55644 := by
  intro p hp
  have h : env55644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55643_55644 : H12AffineEnvironment.transform 15 29962 env55643 = env55644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env55643 == env55644) = true)

def env55645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,131072,262144,1024,8540,4161,4194304,16,139,8328,64,4592845,5392,4096,406605,1501,4194304,256,33,5592,513]

theorem envBound55645 : H12AffineFastState.Bounded env55645 := by
  intro p hp
  have h : env55645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55644_55645 : H12AffineEnvironment.transform 13 5376 env55644 = env55645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55644 == env55645) = true)

theorem identity55645 : scanCanonicalize (H12AffineFastState.compose env55645 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound55645 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,131072,138477,1024,8540,4161,4194304,16,139,8328,64,4196384,5392,4096,10400,1501,4194304,256,33,5592,513]

theorem envBound55646 : H12AffineFastState.Bounded env55646 := by
  intro p hp
  have h : env55646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55645_55646 : H12AffineEnvironment.transform 17 138477 env55645 = env55646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env55645 == env55646) = true)

theorem identity55646 : scanCanonicalize (H12AffineFastState.compose env55646 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55646 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,138341,1024,8540,4161,4194304,16,3,8192,64,4196384,5392,4096,10280,1365,4194304,256,33,5456,513]

theorem envBound55647 : H12AffineFastState.Bounded env55647 := by
  intro p hp
  have h : env55647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55646_55647 : H12AffineEnvironment.transform 6 8 env55646 = env55647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55646 == env55647) = true)

theorem identity55647 : scanCanonicalize (H12AffineFastState.compose env55647 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound55647 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env55648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,138341,1024,8540,4161,136497,16,3,8192,64,138513,5392,4096,10280,1365,136497,256,33,5456,513]

theorem envBound55648 : H12AffineFastState.Bounded env55648 := by
  intro p hp
  have h : env55648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55647_55648 : H12AffineEnvironment.transform 21 136497 env55647 = env55648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env55647 == env55648) = true)

theorem identity55648 : scanCanonicalize (H12AffineFastState.compose env55648 (packedSelected [0,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound55648 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env55649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,13388,10281,1024,8540,4161,8573,16,3,8192,64,10589,5392,4096,10280,1365,8573,256,33,5456,513]

theorem envBound55649 : H12AffineFastState.Bounded env55649 := by
  intro p hp
  have h : env55649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55648_55649 : H12AffineEnvironment.transform 16 13388 env55648 = env55649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env55648 == env55649) = true)

theorem identity55649 : scanCanonicalize (H12AffineFastState.compose env55649 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55649 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5392,2421,1024,0,4161,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5456,513]

theorem envBound55650 : H12AffineFastState.Bounded env55650 := by
  intro p hp
  have h : env55650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55649_55650 : H12AffineEnvironment.transform 12 348 env55649 = env55650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55649 == env55650) = true)

theorem identity55650 : scanCanonicalize (H12AffineFastState.compose env55650 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound55650 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55651 : List Nat := [2,4,8,16,32,64,8,256,81,1024,2048,4096,348,5376,1,342,5392,2421,1024,0,4161,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5456,80]

theorem envBound55651 : H12AffineFastState.Bounded env55651 := by
  intro p hp
  have h : env55651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55650_55651 : H12AffineEnvironment.transform 8 81 env55650 = env55651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env55650 == env55651) = true)

theorem identity55651 : scanCanonicalize (H12AffineFastState.compose env55651 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound55651 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55652 : List Nat := [2,4,8,16,32,64,8,256,81,1024,2048,1297,348,17,1,342,1,2421,1024,0,1360,33,16,3,348,64,2049,1,1297,2420,1365,33,256,33,65,80]

theorem envBound55652 : H12AffineFastState.Bounded env55652 := by
  intro p hp
  have h : env55652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55651_55652 : H12AffineEnvironment.transform 11 1297 env55651 = env55652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env55651 == env55652) = true)

theorem identity55652 : scanCanonicalize (H12AffineFastState.compose env55652 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound55652 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env55653 : List Nat := [2,4,8,16,32,64,8,84,81,1024,2048,1093,8,17,1,2,1,2081,1024,0,1028,33,16,3,8,64,2049,1,1093,2080,1025,33,84,33,65,80]

theorem envBound55653 : H12AffineFastState.Bounded env55653 := by
  intro p hp
  have h : env55653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55652_55653 : H12AffineEnvironment.transform 7 84 env55652 = env55653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env55652 == env55653) = true)

def env55654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4160,4194304,16,138,8328,64,4592845,5392,4096,406605,1500,4194304,256,32,5593,513]

theorem envBound55654 : H12AffineFastState.Bounded env55654 := by
  intro p hp
  have h : env55654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55644_55654 : H12AffineEnvironment.transform 13 5377 env55644 = env55654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55644 == env55654) = true)

theorem identity55654 : scanCanonicalize (H12AffineFastState.compose env55654 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10481) := by decide +kernel

theorem selectedBound55654 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10481,1024,8541,4160,4194304,16,138,8328,64,4340796,5392,4096,138428,1500,4194304,256,32,5593,513]

theorem envBound55655 : H12AffineFastState.Bounded env55655 := by
  intro p hp
  have h : env55655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55654_55655 : H12AffineEnvironment.transform 17 10481 env55654 = env55655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10481 env55654 == env55655) = true)

theorem identity55655 : scanCanonicalize (H12AffineFastState.compose env55655 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound55655 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env55656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10481,1024,8541,4160,33,16,138,8328,64,146461,5392,4096,138428,1500,33,256,32,5593,513]

theorem envBound55656 : H12AffineFastState.Bounded env55656 := by
  intro p hp
  have h : env55656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55655_55656 : H12AffineEnvironment.transform 21 33 env55655 = env55656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55655 == env55656) = true)

theorem identity55656 : scanCanonicalize (H12AffineFastState.compose env55656 (packedSelected [1,3,15,18,23,24,28,38] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound55656 : packedSelected [1,3,15,18,23,24,28,38] rootPS < 2^1333 := by decide +kernel

def env55657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,13461,10481,1024,8541,4160,33,16,138,8328,64,2184,5392,4096,10281,1500,33,256,32,5593,513]

theorem envBound55657 : H12AffineFastState.Bounded env55657 := by
  intro p hp
  have h : env55657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55656_55657 : H12AffineEnvironment.transform 16 13461 env55656 = env55657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env55656 == env55657) = true)

theorem identity55657 : scanCanonicalize (H12AffineFastState.compose env55657 (packedSelected [18,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55657 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env55658 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8460,8203,13461,10401,1024,8461,4112,33,16,138,8328,16,2184,5392,4096,10281,1420,33,256,32,5513,513]

theorem envBound55658 : H12AffineFastState.Bounded env55658 := by
  intro p hp
  have h : env55658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55657_55658 : H12AffineEnvironment.transform 5 16 env55657 = env55658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55657 == env55658) = true)

theorem identity55658 : scanCanonicalize (H12AffineFastState.compose env55658 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55658 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env55659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,1,262,5528,2476,1024,0,4112,33,16,138,389,16,2184,5392,4096,2340,1420,33,256,32,5513,513]

theorem envBound55659 : H12AffineFastState.Bounded env55659 := by
  intro p hp
  have h : env55659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55658_55659 : H12AffineEnvironment.transform 12 269 env55658 = env55659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55658 == env55659) = true)

theorem identity55659 : scanCanonicalize (H12AffineFastState.compose env55659 (packedSelected [1,2,4,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55659 : packedSelected [1,2,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55660 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,1,35,5309,2185,1024,0,4112,33,16,138,160,16,2184,5173,4096,2049,1193,33,37,32,5292,513]

theorem envBound55660 : H12AffineFastState.Bounded env55660 := by
  intro p hp
  have h : env55660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55659_55660 : H12AffineEnvironment.transform 7 37 env55659 = env55660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55659 == env55660) = true)

theorem identity55660 : scanCanonicalize (H12AffineFastState.compose env55660 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55660 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env55661 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,35,5173,2049,1024,0,4112,33,16,2,40,16,2048,5173,4096,2049,1057,33,37,32,5156,513]

theorem envBound55661 : H12AffineFastState.Bounded env55661 := by
  intro p hp
  have h : env55661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55660_55661 : H12AffineEnvironment.transform 6 8 env55660 = env55661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55660 == env55661) = true)

def env55662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound55662 : H12AffineFastState.Bounded env55662 := by
  intro p hp
  have h : env55662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55473_55662 : H12AffineEnvironment.transform 18 1025 env55473 = env55662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env55473 == env55662) = true)

theorem identity55662 : scanCanonicalize (H12AffineFastState.compose env55662 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165201) := by decide +kernel

theorem selectedBound55662 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,8388608,16777216,8328,64,29868032,16974301,8572928,8830977,25265169,21225617,257,25379324,25403481,25207750]

theorem envBound55663 : H12AffineFastState.Bounded env55663 := by
  intro p hp
  have h : env55663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55662_55663 : H12AffineEnvironment.transform 20 165201 env55662 = env55663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env55662 == env55663) = true)

def env55664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,8388608,8590556,8328,64,4510940,8393985,8572928,8830977,168141,12645453,257,21792,46213,243482]

theorem envBound55664 : H12AffineFastState.Bounded env55664 := by
  intro p hp
  have h : env55664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55663_55664 : H12AffineEnvironment.transform 23 8590556 env55663 = env55664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590556 env55663 == env55664) = true)

def env55665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169216,98780,8328,64,4510940,163841,17664,283905,168141,4350285,257,21792,46213,243482]

theorem envBound55665 : H12AffineFastState.Bounded env55665 := by
  intro p hp
  have h : env55665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55664_55665 : H12AffineEnvironment.transform 22 169216 env55664 = env55665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env55664 == env55665) = true)

def env55666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169216,98780,8328,64,64604,163841,17664,283905,168141,412109,257,21792,46213,243482]

theorem envBound55666 : H12AffineFastState.Bounded env55666 := by
  intro p hp
  have h : env55666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55665_55666 : H12AffineEnvironment.transform 21 272512 env55665 = env55666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env55665 == env55666) = true)

theorem identity55666 : scanCanonicalize (H12AffineFastState.compose env55666 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound55666 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,165201,272512,169216,21762,8328,64,64604,163841,17664,283905,168141,412109,257,21792,46213,156612]

theorem envBound55667 : H12AffineFastState.Bounded env55667 := by
  intro p hp
  have h : env55667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55666_55667 : H12AffineEnvironment.transform 15 54494 env55666 = env55667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env55666 == env55667) = true)

def env55668 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165201,272392,169216,21762,8192,64,64604,163841,17664,283905,168005,411973,257,21792,46093,156492]

theorem envBound55668 : H12AffineFastState.Bounded env55668 := by
  intro p hp
  have h : env55668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55667_55668 : H12AffineEnvironment.transform 6 8 env55667 = env55668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55667 == env55668) = true)

theorem identity55668 : scanCanonicalize (H12AffineFastState.compose env55668 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound55668 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env55669 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,2421,1025,32769,165201,8573,169216,21762,8192,64,64604,163841,17664,23668,168005,147504,257,21792,46093,156492]

theorem envBound55669 : H12AffineFastState.Bounded env55669 := by
  intro p hp
  have h : env55669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55668_55669 : H12AffineEnvironment.transform 17 2421 env55668 = env55669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env55668 == env55669) = true)

theorem identity55669 : scanCanonicalize (H12AffineFastState.compose env55669 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound55669 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,2421,1025,32769,17729,8573,21776,21762,8192,64,64604,16401,17664,23668,20565,32800,257,21792,46093,41820]

theorem envBound55670 : H12AffineFastState.Bounded env55670 := by
  intro p hp
  have h : env55670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55669_55670 : H12AffineEnvironment.transform 16 49168 env55669 = env55670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55669 == env55670) = true)

theorem identity55670 : scanCanonicalize (H12AffineFastState.compose env55670 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound55670 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,5393,2421,1025,21760,17729,8573,21776,21762,8192,64,10589,16401,17664,23668,20565,21793,257,21792,24844,30301]

theorem envBound55671 : H12AffineFastState.Bounded env55671 := by
  intro p hp
  have h : env55671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55670_55671 : H12AffineEnvironment.transform 14 21761 env55670 = env55671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env55670 == env55671) = true)

def env55672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165201,272393,169216,21762,8193,64,64604,163841,17664,283905,168004,411972,257,21792,46092,156493]

theorem envBound55672 : H12AffineFastState.Bounded env55672 := by
  intro p hp
  have h : env55672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55667_55672 : H12AffineEnvironment.transform 6 9 env55667 = env55672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55667 == env55672) = true)

theorem identity55672 : scanCanonicalize (H12AffineFastState.compose env55672 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55672 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env55673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,165201,32,169216,21762,8193,64,64604,163841,17664,32040,168004,156013,257,21792,46092,156493]

theorem envBound55673 : H12AffineFastState.Bounded env55673 := by
  intro p hp
  have h : env55673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55672_55673 : H12AffineEnvironment.transform 17 10281 env55672 = env55673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55672 == env55673) = true)

theorem identity55673 : scanCanonicalize (H12AffineFastState.compose env55673 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound55673 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env55674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,10281,1025,32769,17728,32,21777,21762,8193,64,64604,16400,17664,32040,20565,41340,257,21792,46092,41820]

theorem envBound55674 : H12AffineFastState.Bounded env55674 := by
  intro p hp
  have h : env55674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55673_55674 : H12AffineEnvironment.transform 16 49169 env55673 = env55674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55673 == env55674) = true)

theorem identity55674 : scanCanonicalize (H12AffineFastState.compose env55674 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55674 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,24908,10281,1025,8540,17728,32,21777,21762,8193,64,23809,16400,17664,32040,20565,33,257,21792,5457,513]

theorem envBound55675 : H12AffineFastState.Bounded env55675 := by
  intro p hp
  have h : env55675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55674_55675 : H12AffineEnvironment.transform 14 8541 env55674 = env55675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55674 == env55675) = true)

theorem identity55675 : scanCanonicalize (H12AffineFastState.compose env55675 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55675 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env55676 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,29962,24860,10281,1025,8460,17680,32,21777,21762,8193,16,23809,16400,17664,32040,20485,33,257,21792,5377,513]

theorem envBound55676 : H12AffineFastState.Bounded env55676 := by
  intro p hp
  have h : env55676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55675_55676 : H12AffineEnvironment.transform 5 16 env55675 = env55676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55675 == env55676) = true)

theorem identity55676 : scanCanonicalize (H12AffineFastState.compose env55676 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55676 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55677 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,21510,16400,2341,1025,0,17680,32,21777,21762,269,16,23809,16400,17664,23588,20485,33,257,21792,5377,513]

theorem envBound55677 : H12AffineFastState.Bounded env55677 := by
  intro p hp
  have h : env55677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55676_55677 : H12AffineEnvironment.transform 12 268 env55676 = env55677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55676 == env55677) = true)

def env55678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169216,98780,8328,64,64605,163841,17664,283905,168141,412108,257,21792,46213,243482]

theorem envBound55678 : H12AffineFastState.Bounded env55678 := by
  intro p hp
  have h : env55678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55665_55678 : H12AffineEnvironment.transform 21 272513 env55665 = env55678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env55665 == env55678) = true)

theorem identity55678 : scanCanonicalize (H12AffineFastState.compose env55678 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound55678 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115870,272513,120015,98780,8328,64,64605,115150,17664,283905,119042,329731,257,21792,46213,63189]

theorem envBound55679 : H12AffineFastState.Bounded env55679 := by
  intro p hp
  have h : env55679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55678_55679 : H12AffineEnvironment.transform 16 82383 env55678 = env55679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env55678 == env55679) = true)

def env55680 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115870,272513,119967,98700,8328,16,64525,115102,17664,283905,119042,329731,257,21792,46213,63109]

theorem envBound55680 : H12AffineFastState.Bounded env55680 := by
  intro p hp
  have h : env55680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55679_55680 : H12AffineEnvironment.transform 5 16 env55679 = env55680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55679 == env55680) = true)

theorem identity55680 : scanCanonicalize (H12AffineFastState.compose env55680 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound55680 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env55681 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54279,38296,262144,1025,32769,4249,272513,152,21899,8328,16,64525,5529,17664,283905,1285,318468,257,21792,46213,63109]

theorem envBound55681 : H12AffineFastState.Bounded env55681 := by
  intro p hp
  have h : env55681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55680_55681 : H12AffineEnvironment.transform 15 54279 env55680 = env55681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env55680 == env55681) = true)

theorem identity55681 : scanCanonicalize (H12AffineFastState.compose env55681 (packedSelected [5,8,17,19,24,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound55681 : packedSelected [5,8,17,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env55682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,40971,38296,262144,1025,32769,4249,272513,152,8583,8328,16,34817,5529,12556,270605,1285,305160,257,8492,46213,33417]

theorem envBound55682 : H12AffineFastState.Bounded env55682 := by
  intro p hp
  have h : env55682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55681_55682 : H12AffineEnvironment.transform 13 13324 env55681 = env55682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env55681 == env55682) = true)

theorem identity55682 : scanCanonicalize (H12AffineFastState.compose env55682 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound55682 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env55683 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,40971,38296,10400,1025,32769,4249,33,152,8583,8328,16,34817,5529,12556,2477,1285,32936,257,8492,46213,33417]

theorem envBound55683 : H12AffineFastState.Bounded env55683 := by
  intro p hp
  have h : env55683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55682_55683 : H12AffineEnvironment.transform 17 10400 env55682 = env55683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env55682 == env55683) = true)

theorem identity55683 : scanCanonicalize (H12AffineFastState.compose env55683 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55683 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env55684 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,1,8202,5529,10400,1025,0,4249,33,152,8583,8328,16,2048,5529,12556,2477,1285,169,257,8492,13444,648]

theorem envBound55684 : H12AffineFastState.Bounded env55684 := by
  intro p hp
  have h : env55684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55683_55684 : H12AffineEnvironment.transform 14 1 env55683 = env55684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55683 == env55684) = true)

theorem identity55684 : scanCanonicalize (H12AffineFastState.compose env55684 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound55684 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55685 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,1,398,5529,2340,1025,0,4249,33,152,3,268,16,2048,5529,4232,2477,1285,169,257,168,5376,648]

theorem envBound55685 : H12AffineFastState.Bounded env55685 := by
  intro p hp
  have h : env55685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55684_55685 : H12AffineEnvironment.transform 12 388 env55684 = env55685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env55684 == env55685) = true)

theorem identity55685 : scanCanonicalize (H12AffineFastState.compose env55685 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55685 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55686 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,40,5156,1,34,5173,2184,1025,0,4249,33,152,3,160,16,2048,5173,4232,2049,1193,169,173,168,5292,648]

theorem envBound55686 : H12AffineFastState.Bounded env55686 := by
  intro p hp
  have h : env55686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55685_55686 : H12AffineEnvironment.transform 7 172 env55685 = env55686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55685 == env55686) = true)

theorem identity55686 : scanCanonicalize (H12AffineFastState.compose env55686 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound55686 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55687 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,40,5156,1,34,5173,2081,1025,0,4144,33,49,3,9,16,2048,5173,4129,2049,1024,0,4,1,5125,545]

theorem envBound55687 : H12AffineFastState.Bounded env55687 := by
  intro p hp
  have h : env55687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55686_55687 : H12AffineEnvironment.transform 6 41 env55686 = env55687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env55686 == env55687) = true)

theorem identity55687 : scanCanonicalize (H12AffineFastState.compose env55687 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55687 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55688 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5125,1,3,5140,2048,1025,0,4113,0,16,3,9,16,2048,5140,4096,2049,1024,0,4,1,5125,512]

theorem envBound55688 : H12AffineFastState.Bounded env55688 := by
  intro p hp
  have h : env55688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55687_55688 : H12AffineEnvironment.transform 4 1 env55687 = env55688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55687 == env55688) = true)

theorem identity55688 : scanCanonicalize (H12AffineFastState.compose env55688 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound55688 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55689 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,16,9,1045,1,3,1028,2048,1025,0,1,0,16,3,9,16,2048,1028,16,2049,1024,0,4,1,1045,512]

theorem envBound55689 : H12AffineFastState.Bounded env55689 := by
  intro p hp
  have h : env55689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55688_55689 : H12AffineEnvironment.transform 11 16 env55688 = env55689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env55688 == env55689) = true)

def env55690 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115870,272513,119966,98701,8328,17,64524,115103,17664,283905,119042,329731,257,21792,46213,63108]

theorem envBound55690 : H12AffineFastState.Bounded env55690 := by
  intro p hp
  have h : env55690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55679_55690 : H12AffineEnvironment.transform 5 17 env55679 = env55690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55679 == env55690) = true)

theorem identity55690 : scanCanonicalize (H12AffineFastState.compose env55690 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound55690 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env55691 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,65536,82334,262144,1025,8580,91419,272513,95515,73736,8328,17,23945,90138,17664,283905,94343,329731,257,21792,5376,22273]

theorem envBound55691 : H12AffineFastState.Bounded env55691 := by
  intro p hp
  have h : env55691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55690_55691 : H12AffineEnvironment.transform 14 8581 env55690 = env55691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env55690 == env55691) = true)

theorem identity55691 : scanCanonicalize (H12AffineFastState.compose env55691 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound55691 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env55692 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,65536,82334,32041,1025,8580,91419,21928,95515,73736,8328,17,23945,90138,17664,10280,94343,95530,257,21792,5376,22273]

theorem envBound55692 : H12AffineFastState.Bounded env55692 := by
  intro p hp
  have h : env55692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55691_55692 : H12AffineEnvironment.transform 17 32041 env55691 = env55692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env55691 == env55692) = true)

theorem identity55692 : scanCanonicalize (H12AffineFastState.compose env55692 (packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound55692 : packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env55693 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8581,65536,79131,2476,1025,8580,70046,8493,65950,73736,8328,17,10508,70815,12677,10280,66562,65967,257,8613,5376,9092]

theorem envBound55693 : H12AffineFastState.Bounded env55693 := by
  intro p hp
  have h : env55693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55692_55693 : H12AffineEnvironment.transform 13 13445 env55692 = env55693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env55692 == env55693) = true)

theorem identity55693 : scanCanonicalize (H12AffineFastState.compose env55693 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound55693 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55694 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,65536,70814,2476,1025,1,70046,168,65950,65933,269,17,2185,70815,4096,2477,66562,65967,257,32,5376,513]

theorem envBound55694 : H12AffineFastState.Bounded env55694 := by
  intro p hp
  have h : env55694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55693_55694 : H12AffineEnvironment.transform 12 389 env55693 = env55694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env55693 == env55694) = true)

theorem identity55694 : scanCanonicalize (H12AffineFastState.compose env55694 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound55694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55695 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,399,5393,2476,1025,1,4113,168,17,2,269,17,2185,5392,4096,2477,1421,32,257,32,5376,513]

theorem envBound55695 : H12AffineFastState.Bounded env55695 := by
  intro p hp
  have h : env55695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55694_55695 : H12AffineEnvironment.transform 15 399 env55694 = env55695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env55694 == env55695) = true)

theorem identity55695 : scanCanonicalize (H12AffineFastState.compose env55695 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1939) := by decide +kernel

theorem selectedBound55695 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env55696 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1939,4096,389,5376,0,399,5393,1599,1025,1,4113,168,17,2,269,17,1818,5392,4096,1598,1421,32,257,32,5376,513]

theorem envBound55696 : H12AffineFastState.Bounded env55696 := by
  intro p hp
  have h : env55696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55695_55696 : H12AffineEnvironment.transform 10 1939 env55695 = env55696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1939 env55695 == env55696) = true)

theorem identity55696 : scanCanonicalize (H12AffineFastState.compose env55696 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55696 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env55697 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1599,4096,41,5292,0,35,5309,1599,1025,1,4113,168,17,2,161,17,1718,5308,4096,1598,1057,32,173,32,5292,513]

theorem envBound55697 : H12AffineFastState.Bounded env55697 := by
  intro p hp
  have h : env55697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55696_55697 : H12AffineEnvironment.transform 7 172 env55696 = env55697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55696 == env55697) = true)

theorem identity55697 : scanCanonicalize (H12AffineFastState.compose env55697 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1671) := by decide +kernel

theorem selectedBound55697 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55698 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1599,1671,41,555,0,35,570,1599,1025,1,1686,168,17,2,161,17,1718,571,1671,1598,1057,32,173,32,555,513]

theorem envBound55698 : H12AffineFastState.Bounded env55698 := by
  intro p hp
  have h : env55698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55697_55698 : H12AffineEnvironment.transform 11 1671 env55697 = env55698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1671 env55697 == env55698) = true)

theorem identity55698 : scanCanonicalize (H12AffineFastState.compose env55698 (packedSelected [2,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55698 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env55699 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1599,1550,41,555,0,35,570,1599,1025,1,1567,33,17,2,40,17,1599,571,1550,1598,1057,32,36,32,555,513]

theorem envBound55699 : H12AffineFastState.Bounded env55699 := by
  intro p hp
  have h : env55699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55698_55699 : H12AffineEnvironment.transform 6 9 env55698 = env55699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55698 == env55699) = true)

def env55700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169217,98781,8328,64,4510940,163840,17665,283904,168141,4350284,257,21792,46213,243482]

theorem envBound55700 : H12AffineFastState.Bounded env55700 := by
  intro p hp
  have h : env55700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55664_55700 : H12AffineEnvironment.transform 22 169217 env55664 = env55700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env55664 == env55700) = true)

def env55701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169217,98781,8328,64,64604,163840,17665,283904,168141,412108,257,21792,46213,243482]

theorem envBound55701 : H12AffineFastState.Bounded env55701 := by
  intro p hp
  have h : env55701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55700_55701 : H12AffineEnvironment.transform 21 272512 env55700 = env55701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env55700 == env55701) = true)

theorem identity55701 : scanCanonicalize (H12AffineFastState.compose env55701 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55701 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165201,272512,169217,41430,8328,64,64604,163840,17665,283904,168141,412108,257,21792,46213,169745]

theorem envBound55702 : H12AffineFastState.Bounded env55702 := by
  intro p hp
  have h : env55702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55701_55702 : H12AffineEnvironment.transform 15 8203 env55701 = env55702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55701 == env55702) = true)

def env55703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165201,272392,169217,41310,8192,64,64604,163840,17665,283904,168005,411972,257,21792,46093,169745]

theorem envBound55703 : H12AffineFastState.Bounded env55703 := by
  intro p hp
  have h : env55703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55702_55703 : H12AffineEnvironment.transform 6 8 env55702 = env55703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55702 == env55703) = true)

theorem identity55703 : scanCanonicalize (H12AffineFastState.compose env55703 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound55703 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1025,32769,165201,144492,169217,41310,8192,64,64604,163840,17665,149860,168005,21792,257,21792,46093,169745]

theorem envBound55704 : H12AffineFastState.Bounded env55704 := by
  intro p hp
  have h : env55704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55703_55704 : H12AffineEnvironment.transform 17 138340 env55703 = env55704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env55703 == env55704) = true)

theorem identity55704 : scanCanonicalize (H12AffineFastState.compose env55704 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound55704 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8203,131072,138340,1025,8232,140664,144492,144680,375,8192,64,23669,139305,17665,149860,143468,21792,257,21792,5156,145208]

theorem envBound55705 : H12AffineFastState.Bounded env55705 := by
  intro p hp
  have h : env55705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55704_55705 : H12AffineEnvironment.transform 14 8233 env55704 = env55705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env55704 == env55705) = true)

theorem identity55705 : scanCanonicalize (H12AffineFastState.compose env55705 (packedSelected [1,2,3,5,6,8,9,10,11,14,17,18,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound55705 : packedSelected [1,2,3,5,6,8,9,10,11,14,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env55706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8203,13389,10281,1025,8232,4405,33,357,375,8192,64,23669,5220,17665,32041,1057,21792,257,21792,5156,885]

theorem envBound55706 : H12AffineFastState.Bounded env55706 := by
  intro p hp
  have h : env55706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55705_55706 : H12AffineEnvironment.transform 16 13389 env55705 = env55706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env55705 == env55706) = true)

def env55707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165201,272393,169217,41311,8193,64,64604,163840,17665,283904,168004,411973,257,21792,46092,169745]

theorem envBound55707 : H12AffineFastState.Bounded env55707 := by
  intro p hp
  have h : env55707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55702_55707 : H12AffineEnvironment.transform 6 9 env55702 = env55707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55702 == env55707) = true)

theorem identity55707 : scanCanonicalize (H12AffineFastState.compose env55707 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound55707 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1025,32769,165201,169265,169217,41311,8193,64,64604,163840,17665,190520,168004,62589,257,21792,46092,169745]

theorem envBound55708 : H12AffineFastState.Bounded env55708 := by
  intro p hp
  have h : env55708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0