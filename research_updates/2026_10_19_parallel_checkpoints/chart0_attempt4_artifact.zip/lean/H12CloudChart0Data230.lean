import H12CloudChart0Data229

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound58321 : H12AffineFastState.Bounded env58321 := by
  intro p hp
  have h : env58321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58320_58321 : H12AffineEnvironment.transform 17 609 env58320 = env58321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 609 env58320 == env58321) = true)

theorem identity58321 : scanCanonicalize (H12AffineFastState.compose env58321 (packedSelected [5,7,9,10,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 123) := by decide +kernel

theorem selectedBound58321 : packedSelected [5,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58322 : List Nat := [2,4,8,16,32,64,89,256,512,85,554,123,348,43,292,115,350,609,85,292,270,32,869,515,268,820,277,43,271,783,769,113,257,544,351,512]

theorem envBound58322 : H12AffineFastState.Bounded env58322 := by
  intro p hp
  have h : env58322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58321_58322 : H12AffineEnvironment.transform 11 123 env58321 = env58322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 123 env58321 == env58322) = true)

def env58323 : List Nat := [2,4,8,16,32,64,89,256,276,85,318,123,348,43,292,115,350,373,85,292,270,32,113,279,268,32,277,43,271,27,21,113,257,308,351,276]

theorem envBound58323 : H12AffineFastState.Bounded env58323 := by
  intro p hp
  have h : env58323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58322_58323 : H12AffineEnvironment.transform 8 276 env58322 = env58323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env58322 == env58323) = true)

theorem identity58323 : scanCanonicalize (H12AffineFastState.compose env58323 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58323 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env58324 : List Nat := [2,4,8,11,32,64,66,256,271,78,293,96,327,43,292,104,325,366,78,292,270,32,106,268,268,32,270,43,271,0,14,106,257,303,324,271]

theorem envBound58324 : H12AffineFastState.Bounded env58324 := by
  intro p hp
  have h : env58324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58323_58324 : H12AffineEnvironment.transform 3 11 env58323 = env58324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58323 == env58324) = true)

theorem identity58324 : scanCanonicalize (H12AffineFastState.compose env58324 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58324 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58325 : List Nat := [2,4,8,11,32,33,35,256,271,47,293,1,294,43,292,9,292,271,47,292,270,32,11,268,268,32,270,43,271,0,14,11,257,303,293,271]

theorem envBound58325 : H12AffineFastState.Bounded env58325 := by
  intro p hp
  have h : env58325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58324_58325 : H12AffineEnvironment.transform 5 33 env58324 = env58325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58324 == env58325) = true)

def env58326 : List Nat := [2,4,8,16,32,64,89,256,277,85,319,123,348,43,292,115,350,372,85,292,270,32,112,278,268,33,277,43,271,26,20,113,257,309,351,277]

theorem envBound58326 : H12AffineFastState.Bounded env58326 := by
  intro p hp
  have h : env58326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58322_58326 : H12AffineEnvironment.transform 8 277 env58322 = env58326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env58322 == env58326) = true)

theorem identity58326 : scanCanonicalize (H12AffineFastState.compose env58326 (packedSelected [9,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58326 : packedSelected [9,10] rootPS < 2^1333 := by decide +kernel

def env58327 : List Nat := [2,4,8,16,32,64,89,68,81,85,123,123,24,43,96,115,26,48,85,96,74,32,112,82,72,33,81,43,75,26,20,113,69,113,27,81]

theorem envBound58327 : H12AffineFastState.Bounded env58327 := by
  intro p hp
  have h : env58327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58326_58327 : H12AffineEnvironment.transform 7 68 env58326 = env58327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58326 == env58327) = true)

theorem identity58327 : scanCanonicalize (H12AffineFastState.compose env58327 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound58327 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58328 : List Nat := [2,4,8,16,32,58,35,62,43,47,1,1,24,43,26,9,26,48,47,26,48,32,10,40,50,33,43,43,49,26,20,11,63,11,27,43]

theorem envBound58328 : H12AffineFastState.Bounded env58328 := by
  intro p hp
  have h : env58328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58327_58328 : H12AffineEnvironment.transform 5 58 env58327 = env58328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env58327 == env58328) = true)

theorem identity58328 : scanCanonicalize (H12AffineFastState.compose env58328 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58328 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58329 : List Nat := [2,4,8,16,16,10,19,14,27,31,1,1,24,27,26,9,26,0,31,26,0,16,10,24,2,17,27,27,1,26,20,11,15,11,27,27]

theorem envBound58329 : H12AffineFastState.Bounded env58329 := by
  intro p hp
  have h : env58329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58328_58329 : H12AffineEnvironment.transform 4 16 env58328 = env58329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58328 == env58329) = true)

def env58330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,4227081,8388689,10785996,4176,77954,4294795,8463815,2101508,257,14725224,78034,4235904]

theorem envBound58330 : H12AffineFastState.Bounded env58330 := by
  intro p hp
  have h : env58330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58259_58330 : H12AffineEnvironment.transform 24 4227081 env58259 = env58330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env58259 == env58330) = true)

theorem identity58330 : scanCanonicalize (H12AffineFastState.compose env58330 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71051) := by decide +kernel

theorem selectedBound58330 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71051,4194304,8388608,8430023,4227081,8388689,8749383,4176,77954,4294795,8463815,66703,257,12690915,78034,4235904]

theorem envBound58331 : H12AffineFastState.Bounded env58331 := by
  intro p hp
  have h : env58331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58330_58331 : H12AffineEnvironment.transform 20 71051 env58330 = env58331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71051 env58330 == env58331) = true)

theorem identity58331 : scanCanonicalize (H12AffineFastState.compose env58331 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound58331 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71051,41088,8388608,8430023,8329,8388689,8749383,4176,77954,75787,8463815,66703,257,8455523,78034,512]

theorem envBound58332 : H12AffineFastState.Bounded env58332 := by
  intro p hp
  have h : env58332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58331_58332 : H12AffineEnvironment.transform 21 41088 env58331 = env58332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env58331 == env58332) = true)

theorem identity58332 : scanCanonicalize (H12AffineFastState.compose env58332 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound58332 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37893,41088,8388608,8430023,8329,8388689,8650953,4176,45324,43397,8430665,34049,257,8422637,45404,512]

theorem envBound58333 : H12AffineFastState.Bounded env58333 := by
  intro p hp
  have h : env58333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58332_58333 : H12AffineEnvironment.transform 15 33166 env58332 = env58333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env58332 == env58333) = true)

theorem identity58333 : scanCanonicalize (H12AffineFastState.compose env58333 (packedSelected [5,8] rootPS)) = affineNative (2^(22+1) ^^^ 311200) := by decide +kernel

theorem selectedBound58333 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37893,41088,311200,269927,8329,311281,49001,4176,45324,43397,269289,34049,257,277325,45404,512]

theorem envBound58334 : H12AffineFastState.Bounded env58334 := by
  intro p hp
  have h : env58334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58333_58334 : H12AffineEnvironment.transform 22 311200 env58333 = env58334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 311200 env58333 == env58334) = true)

theorem identity58334 : scanCanonicalize (H12AffineFastState.compose env58334 (packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound58334 : packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS < 2^1333 := by decide +kernel

def env58335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8352,8494,4605,262144,1024,8352,13477,32,270080,269927,8329,270161,8137,4176,4524,2341,269289,9633,257,277325,4604,512]

theorem envBound58335 : H12AffineFastState.Bounded env58335 := by
  intro p hp
  have h : env58335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58334_58335 : H12AffineEnvironment.transform 14 8352 env58334 = env58335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env58334 == env58335) = true)

def env58336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1448,1062,4605,262144,1024,1448,4525,32,270080,269927,1409,270161,8137,4176,4524,2341,269289,169,257,269893,4604,512]

theorem envBound58336 : H12AffineFastState.Bounded env58336 := by
  intro p hp
  have h : env58336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58335_58336 : H12AffineEnvironment.transform 12 1288 env58335 = env58336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env58335 == env58336) = true)

theorem identity58336 : scanCanonicalize (H12AffineFastState.compose env58336 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4582) := by decide +kernel

theorem selectedBound58336 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1448,1062,4605,4582,1024,1448,4525,32,3814,3969,1409,3767,8137,4176,4524,2341,2575,169,257,4003,4604,512]

theorem envBound58337 : H12AffineFastState.Bounded env58337 := by
  intro p hp
  have h : env58337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58336_58337 : H12AffineEnvironment.transform 17 4582 env58336 = env58337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4582 env58336 == env58337) = true)

def env58338 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,348,4176,508,114,4605,4582,84,508,4525,32,2738,3029,469,2787,7069,4176,4524,2341,2575,169,257,3063,4604,512]

theorem envBound58338 : H12AffineFastState.Bounded env58338 := by
  intro p hp
  have h : env58338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58337_58338 : H12AffineEnvironment.transform 9 84 env58337 = env58338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58337 == env58338) = true)

def env58339 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,4096,348,4176,292,114,4389,4414,84,292,4469,32,2666,2829,269,2619,6981,4176,4468,2341,2575,113,257,2863,4388,512]

theorem envBound58339 : H12AffineFastState.Bounded env58339 := by
  intro p hp
  have h : env58339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58338_58339 : H12AffineEnvironment.transform 6 88 env58338 = env58339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58338 == env58339) = true)

theorem identity58339 : scanCanonicalize (H12AffineFastState.compose env58339 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 863) := by decide +kernel

theorem selectedBound58339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58340 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,863,348,783,292,114,634,609,84,292,554,32,2666,2829,269,2619,2074,783,555,2341,2575,113,257,2863,635,512]

theorem envBound58340 : H12AffineFastState.Bounded env58340 := by
  intro p hp
  have h : env58340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58339_58340 : H12AffineEnvironment.transform 11 863 env58339 = env58340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 863 env58339 == env58340) = true)

theorem identity58340 : scanCanonicalize (H12AffineFastState.compose env58340 (packedSelected [3,7,9,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 837) := by decide +kernel

theorem selectedBound58340 : packedSelected [3,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58341 : List Nat := [2,4,8,16,32,64,88,256,512,84,837,863,348,783,292,114,634,609,84,292,554,32,303,72,269,382,863,783,555,608,330,113,257,106,635,512]

theorem envBound58341 : H12AffineFastState.Bounded env58341 := by
  intro p hp
  have h : env58341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58340_58341 : H12AffineEnvironment.transform 10 837 env58340 = env58341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 837 env58340 == env58341) = true)

theorem identity58341 : scanCanonicalize (H12AffineFastState.compose env58341 (packedSelected [0,1,3,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound58341 : packedSelected [0,1,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env58342 : List Nat := [2,4,8,16,32,64,88,14,512,84,587,593,82,513,42,114,634,609,84,42,554,32,33,72,3,112,593,513,555,608,68,113,15,106,635,512]

theorem envBound58342 : H12AffineFastState.Bounded env58342 := by
  intro p hp
  have h : env58342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58341_58342 : H12AffineEnvironment.transform 7 14 env58341 = env58342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env58341 == env58342) = true)

theorem identity58342 : scanCanonicalize (H12AffineFastState.compose env58342 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58342 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58343 : List Nat := [2,4,8,16,11,64,88,14,512,84,587,593,82,513,1,89,593,586,84,1,513,11,10,72,3,91,593,513,512,587,68,90,15,65,592,512]

theorem envBound58343 : H12AffineFastState.Bounded env58343 := by
  intro p hp
  have h : env58343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58342_58343 : H12AffineEnvironment.transform 4 11 env58342 = env58343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58342 == env58343) = true)

def env58344 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,4096,348,4176,293,114,4388,4415,84,293,4468,32,2667,2828,268,2618,6980,4176,4469,2341,2575,112,257,2862,4389,512]

theorem envBound58344 : H12AffineFastState.Bounded env58344 := by
  intro p hp
  have h : env58344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58338_58344 : H12AffineEnvironment.transform 6 89 env58338 = env58344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58338 == env58344) = true)

theorem identity58344 : scanCanonicalize (H12AffineFastState.compose env58344 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58344 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58345 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,555,348,635,293,114,783,788,84,293,863,32,2667,2828,268,2618,2415,635,862,2341,2575,112,257,2862,782,512]

theorem envBound58345 : H12AffineFastState.Bounded env58345 := by
  intro p hp
  have h : env58345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58344_58345 : H12AffineEnvironment.transform 11 555 env58344 = env58345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58344 == env58345) = true)

theorem identity58345 : scanCanonicalize (H12AffineFastState.compose env58345 (packedSelected [5,7,9,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound58345 : packedSelected [5,7,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58346 : List Nat := [2,4,8,16,32,64,89,256,512,84,351,555,348,635,293,114,783,788,84,293,863,32,820,595,268,869,48,635,862,122,848,112,257,625,782,512]

theorem envBound58346 : H12AffineFastState.Bounded env58346 := by
  intro p hp
  have h : env58346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58345_58346 : H12AffineEnvironment.transform 10 351 env58345 = env58346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env58345 == env58346) = true)

def env58347 : List Nat := [2,4,8,16,32,64,89,256,276,84,351,319,348,367,293,114,27,0,84,293,75,32,32,327,268,113,48,367,74,122,68,112,257,357,26,276]

theorem envBound58347 : H12AffineFastState.Bounded env58347 := by
  intro p hp
  have h : env58347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58346_58347 : H12AffineEnvironment.transform 8 276 env58346 = env58347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env58346 == env58347) = true)

theorem identity58347 : scanCanonicalize (H12AffineFastState.compose env58347 (packedSelected [0,1,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound58347 : packedSelected [0,1,4,10] rootPS < 2^1333 := by decide +kernel

def env58348 : List Nat := [2,4,8,16,32,64,89,14,26,84,81,49,82,97,43,114,27,0,84,43,75,32,32,73,2,113,48,97,74,122,68,112,15,107,26,26]

theorem envBound58348 : H12AffineFastState.Bounded env58348 := by
  intro p hp
  have h : env58348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58347_58348 : H12AffineEnvironment.transform 7 14 env58347 = env58348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env58347 == env58348) = true)

theorem identity58348 : scanCanonicalize (H12AffineFastState.compose env58348 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58348 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env58349 : List Nat := [2,4,8,16,17,64,89,14,26,84,81,0,82,80,26,67,27,0,84,26,75,17,17,73,2,64,1,80,74,75,68,65,15,90,26,26]

theorem envBound58349 : H12AffineFastState.Bounded env58349 := by
  intro p hp
  have h : env58349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58348_58349 : H12AffineEnvironment.transform 4 17 env58348 = env58349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58348 == env58349) = true)

theorem identity58349 : scanCanonicalize (H12AffineFastState.compose env58349 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58349 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58350 : List Nat := [2,4,8,11,10,64,66,14,1,79,74,0,73,75,1,67,0,0,79,1,75,10,10,73,2,64,1,75,74,75,68,65,15,65,1,1]

theorem envBound58350 : H12AffineFastState.Bounded env58350 := by
  intro p hp
  have h : env58350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58349_58350 : H12AffineEnvironment.transform 3 11 env58349 = env58350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58349 == env58350) = true)

theorem identity58350 : scanCanonicalize (H12AffineFastState.compose env58350 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58351 : List Nat := [2,4,8,11,10,10,8,14,1,5,0,0,3,1,1,9,0,0,5,1,1,10,10,3,2,10,1,1,0,1,14,11,15,11,1,1]

theorem envBound58351 : H12AffineFastState.Bounded env58351 := by
  intro p hp
  have h : env58351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58350_58351 : H12AffineEnvironment.transform 5 10 env58350 = env58351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58350 == env58351) = true)

def env58352 : List Nat := [2,4,8,16,32,64,89,256,277,84,351,318,348,366,293,114,26,1,84,293,74,32,33,326,268,112,48,366,75,122,69,112,257,356,27,277]

theorem envBound58352 : H12AffineFastState.Bounded env58352 := by
  intro p hp
  have h : env58352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58346_58352 : H12AffineEnvironment.transform 8 277 env58346 = env58352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env58346 == env58352) = true)

theorem identity58352 : scanCanonicalize (H12AffineFastState.compose env58352 (packedSelected [1,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58352 : packedSelected [1,5,7] rootPS < 2^1333 := by decide +kernel

def env58353 : List Nat := [2,4,8,16,32,11,18,256,277,31,276,318,279,293,293,57,26,1,31,293,1,32,33,269,268,59,48,293,0,49,14,59,257,303,27,277]

theorem envBound58353 : H12AffineFastState.Bounded env58353 := by
  intro p hp
  have h : env58353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58352_58353 : H12AffineEnvironment.transform 5 11 env58352 = env58353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58352 == env58353) = true)

theorem identity58353 : scanCanonicalize (H12AffineFastState.compose env58353 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58354 : List Nat := [2,4,8,16,32,11,18,37,48,31,49,27,50,0,0,57,26,1,31,0,1,32,33,40,41,59,48,0,0,49,14,59,36,10,27,48]

theorem envBound58354 : H12AffineFastState.Bounded env58354 := by
  intro p hp
  have h : env58354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58353_58354 : H12AffineEnvironment.transform 7 37 env58353 = env58354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58353 == env58354) = true)

theorem identity58354 : scanCanonicalize (H12AffineFastState.compose env58354 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58354 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58355 : List Nat := [2,4,8,16,17,11,18,20,1,31,0,27,3,0,0,8,26,1,31,0,1,17,16,25,24,10,1,0,0,0,14,10,21,10,27,1]

theorem envBound58355 : H12AffineFastState.Bounded env58355 := by
  intro p hp
  have h : env58355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58354_58355 : H12AffineEnvironment.transform 4 17 env58354 = env58355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58354 == env58355) = true)

theorem identity58355 : scanCanonicalize (H12AffineFastState.compose env58355 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58355 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58356 : List Nat := [2,4,8,11,10,11,9,15,1,4,0,0,3,0,0,8,1,1,4,0,1,10,11,2,3,10,1,0,0,0,14,10,14,10,0,1]

theorem envBound58356 : H12AffineFastState.Bounded env58356 := by
  intro p hp
  have h : env58356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58355_58356 : H12AffineEnvironment.transform 3 11 env58355 = env58356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58355 == env58356) = true)

def env58357 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,349,4176,509,115,4605,4582,85,509,4525,32,2739,3028,468,2786,7068,4176,4524,2341,2575,169,257,3062,4604,512]

theorem envBound58357 : H12AffineFastState.Bounded env58357 := by
  intro p hp
  have h : env58357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58337_58357 : H12AffineEnvironment.transform 9 85 env58337 = env58357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58337 == env58357) = true)

def env58358 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,4096,349,4176,293,115,4389,4414,85,293,4469,32,2667,2828,268,2618,6980,4176,4468,2341,2575,113,257,2862,4388,512]

theorem envBound58358 : H12AffineFastState.Bounded env58358 := by
  intro p hp
  have h : env58358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58357_58358 : H12AffineEnvironment.transform 6 88 env58357 = env58358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58357 == env58358) = true)

theorem identity58358 : scanCanonicalize (H12AffineFastState.compose env58358 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound58358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58359 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,2048,349,2128,293,115,2341,2366,85,293,2421,32,2667,2828,268,2618,836,2128,2420,2341,2575,113,257,2862,2340,512]

theorem envBound58359 : H12AffineFastState.Bounded env58359 := by
  intro p hp
  have h : env58359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58358_58359 : H12AffineEnvironment.transform 11 2048 env58358 = env58359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env58358 == env58359) = true)

theorem identity58359 : scanCanonicalize (H12AffineFastState.compose env58359 (packedSelected [0,3,4,12,15,18] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58359 : packedSelected [0,3,4,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58360 : List Nat := [2,4,8,11,32,64,67,256,512,78,2048,2048,326,2123,293,104,2341,2341,78,293,2414,32,2667,2828,268,2593,836,2123,2415,2341,2575,106,257,2862,2340,512]

theorem envBound58360 : H12AffineFastState.Bounded env58360 := by
  intro p hp
  have h : env58360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58359_58360 : H12AffineEnvironment.transform 3 11 env58359 = env58360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58359 == env58360) = true)

theorem identity58360 : scanCanonicalize (H12AffineFastState.compose env58360 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 837) := by decide +kernel

theorem selectedBound58360 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env58361 : List Nat := [2,4,8,11,32,64,67,256,512,78,837,837,326,782,293,104,608,608,78,293,555,32,302,73,268,356,836,782,554,608,330,106,257,107,609,512]

theorem envBound58361 : H12AffineFastState.Bounded env58361 := by
  intro p hp
  have h : env58361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58360_58361 : H12AffineEnvironment.transform 10 837 env58360 = env58361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 837 env58360 == env58361) = true)

theorem identity58361 : scanCanonicalize (H12AffineFastState.compose env58361 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound58361 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58362 : List Nat := [2,4,8,11,32,64,67,14,512,78,587,587,72,512,43,104,608,608,78,43,555,32,32,73,2,106,586,512,554,608,68,106,15,107,609,512]

theorem envBound58362 : H12AffineFastState.Bounded env58362 := by
  intro p hp
  have h : env58362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58361_58362 : H12AffineEnvironment.transform 7 14 env58361 = env58362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env58361 == env58362) = true)

theorem identity58362 : scanCanonicalize (H12AffineFastState.compose env58362 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58362 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58363 : List Nat := [2,4,8,11,32,10,9,14,512,4,513,513,2,512,43,34,554,554,4,43,555,32,32,3,2,32,512,512,554,554,14,32,15,33,555,512]

theorem envBound58363 : H12AffineFastState.Bounded env58363 := by
  intro p hp
  have h : env58363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58362_58363 : H12AffineEnvironment.transform 5 10 env58362 = env58363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58362 == env58363) = true)

theorem identity58363 : scanCanonicalize (H12AffineFastState.compose env58363 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58364 : List Nat := [2,4,8,11,11,10,9,14,512,4,513,513,2,512,0,9,513,513,4,0,512,11,11,3,2,11,512,512,513,513,14,11,15,10,512,512]

theorem envBound58364 : H12AffineFastState.Bounded env58364 := by
  intro p hp
  have h : env58364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58363_58364 : H12AffineEnvironment.transform 4 11 env58363 = env58364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58363 == env58364) = true)

theorem identity58364 : scanCanonicalize (H12AffineFastState.compose env58364 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58364 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58365 : List Nat := [2,4,8,11,11,10,9,14,0,4,1,1,2,0,0,9,1,1,4,0,0,11,11,3,2,11,0,0,1,1,14,11,15,10,0,0]

theorem envBound58365 : H12AffineFastState.Bounded env58365 := by
  intro p hp
  have h : env58365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58364_58365 : H12AffineEnvironment.transform 8 0 env58364 = env58365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58364 == env58365) = true)

def env58366 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,4096,349,4176,292,115,4388,4415,85,292,4468,32,2666,2829,269,2619,6981,4176,4469,2341,2575,112,257,2863,4389,512]

theorem envBound58366 : H12AffineFastState.Bounded env58366 := by
  intro p hp
  have h : env58366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58357_58366 : H12AffineEnvironment.transform 6 89 env58357 = env58366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58357 == env58366) = true)

theorem identity58366 : scanCanonicalize (H12AffineFastState.compose env58366 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound58366 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58367 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,2420,349,2340,292,115,2128,2123,85,292,2048,32,2666,2829,269,2619,561,2340,2049,2341,2575,112,257,2863,2129,512]

theorem envBound58367 : H12AffineFastState.Bounded env58367 := by
  intro p hp
  have h : env58367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58366_58367 : H12AffineEnvironment.transform 11 2420 env58366 = env58367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env58366 == env58367) = true)

theorem identity58367 : scanCanonicalize (H12AffineFastState.compose env58367 (packedSelected [0,4,5,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound58367 : packedSelected [0,4,5,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58368 : List Nat := [2,4,8,16,32,64,89,256,512,85,351,43,349,123,292,115,271,276,85,292,351,32,821,594,269,868,561,123,350,122,848,112,257,624,270,512]

theorem envBound58368 : H12AffineFastState.Bounded env58368 := by
  intro p hp
  have h : env58368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58367_58368 : H12AffineEnvironment.transform 10 351 env58367 = env58368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env58367 == env58368) = true)

theorem identity58368 : scanCanonicalize (H12AffineFastState.compose env58368 (packedSelected [5,7,9,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58368 : packedSelected [5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env58369 : List Nat := [2,4,8,10,32,64,67,256,512,79,325,43,327,97,292,105,271,270,79,292,325,32,815,584,269,868,555,97,324,96,842,106,257,618,270,512]

theorem envBound58369 : H12AffineFastState.Bounded env58369 := by
  intro p hp
  have h : env58369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58368_58369 : H12AffineEnvironment.transform 3 10 env58368 = env58369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58368 == env58369) = true)

theorem identity58369 : scanCanonicalize (H12AffineFastState.compose env58369 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58369 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58370 : List Nat := [2,4,8,10,32,64,67,256,1,79,325,43,327,97,292,105,271,270,79,292,325,32,302,73,269,357,42,97,324,96,331,106,257,107,270,1]

theorem envBound58370 : H12AffineFastState.Bounded env58370 := by
  intro p hp
  have h : env58370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58369_58370 : H12AffineEnvironment.transform 8 1 env58369 = env58370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58369 == env58370) = true)

def env58371 : List Nat := [2,4,8,10,32,64,67,36,1,79,97,43,99,97,0,105,43,42,79,0,97,32,10,73,41,65,42,97,96,96,111,106,37,107,42,1]

theorem envBound58371 : H12AffineFastState.Bounded env58371 := by
  intro p hp
  have h : env58371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58370_58371 : H12AffineEnvironment.transform 7 36 env58370 = env58371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58370 == env58371) = true)

def env58372 : List Nat := [2,4,8,10,32,64,67,37,1,79,96,43,98,97,1,105,42,43,79,1,96,32,11,73,40,64,42,97,97,96,110,106,36,107,43,1]

theorem envBound58372 : H12AffineFastState.Bounded env58372 := by
  intro p hp
  have h : env58372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58370_58372 : H12AffineEnvironment.transform 7 37 env58370 = env58372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58370 == env58372) = true)

theorem identity58372 : scanCanonicalize (H12AffineFastState.compose env58372 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58373 : List Nat := [2,4,8,10,11,64,67,14,1,79,75,0,73,74,1,66,1,0,79,1,75,11,11,73,3,64,1,74,74,75,69,65,15,64,0,1]

theorem envBound58373 : H12AffineFastState.Bounded env58373 := by
  intro p hp
  have h : env58373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58372_58373 : H12AffineEnvironment.transform 4 11 env58372 = env58373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58372 == env58373) = true)

def env58374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1449,1063,4605,262144,1024,1449,4524,32,270080,269927,1408,270161,8137,4176,4524,2341,269289,168,257,269892,4604,512]

theorem envBound58374 : H12AffineFastState.Bounded env58374 := by
  intro p hp
  have h : env58374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58335_58374 : H12AffineEnvironment.transform 12 1289 env58335 = env58374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env58335 == env58374) = true)

theorem identity58374 : scanCanonicalize (H12AffineFastState.compose env58374 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound58374 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,4096,1289,4176,1449,1063,4605,262144,1024,1449,4524,32,266250,266605,1408,266331,4291,4176,4524,1583,267491,168,257,266574,4604,512]

theorem envBound58375 : H12AffineFastState.Bounded env58375 := by
  intro p hp
  have h : env58375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58374_58375 : H12AffineEnvironment.transform 10 1802 env58374 = env58375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env58374 == env58375) = true)

def env58376 : List Nat := [2,4,8,16,32,64,128,256,512,84,862,4096,349,4176,509,115,4605,262144,84,509,4524,32,266250,266605,468,266331,4291,4176,4524,635,266423,168,257,266574,4604,512]

theorem envBound58376 : H12AffineFastState.Bounded env58376 := by
  intro p hp
  have h : env58376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58375_58376 : H12AffineEnvironment.transform 9 84 env58375 = env58376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58375 == env58376) = true)

def env58377 : List Nat := [2,4,8,16,32,64,88,256,512,84,862,4096,349,4176,293,115,4389,262144,84,293,4468,32,266250,266605,268,266331,4123,4176,4468,635,266351,112,257,266574,4388,512]

theorem envBound58377 : H12AffineFastState.Bounded env58377 := by
  intro p hp
  have h : env58377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58376_58377 : H12AffineEnvironment.transform 6 88 env58376 = env58377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58376 == env58377) = true)

theorem identity58377 : scanCanonicalize (H12AffineFastState.compose env58377 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 863) := by decide +kernel

theorem selectedBound58377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58378 : List Nat := [2,4,8,16,32,64,88,256,512,84,862,863,349,783,293,115,634,262144,84,293,555,32,262997,262706,268,262916,836,783,555,635,262960,112,257,262673,635,512]

theorem envBound58378 : H12AffineFastState.Bounded env58378 := by
  intro p hp
  have h : env58378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58377_58378 : H12AffineEnvironment.transform 11 863 env58377 = env58378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 863 env58377 == env58378) = true)

theorem identity58378 : scanCanonicalize (H12AffineFastState.compose env58378 (packedSelected [0,3,4,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58378 : packedSelected [0,3,4,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58379 : List Nat := [2,4,8,16,32,64,88,21,512,84,587,586,72,538,48,115,634,262144,84,48,555,32,262720,262706,25,262673,593,538,555,635,262693,112,20,262673,635,512]

theorem envBound58379 : H12AffineFastState.Bounded env58379 := by
  intro p hp
  have h : env58379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58378_58379 : H12AffineEnvironment.transform 7 21 env58378 = env58379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58378 == env58379) = true)

theorem identity58379 : scanCanonicalize (H12AffineFastState.compose env58379 (packedSelected [1,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58379 : packedSelected [1,7,9] rootPS < 2^1333 := by decide +kernel

def env58380 : List Nat := [2,4,8,16,17,64,88,21,512,84,587,586,72,538,1,66,587,262144,84,1,538,17,262720,262659,25,262673,593,538,538,586,262676,65,20,262673,586,512]

theorem envBound58380 : H12AffineFastState.Bounded env58380 := by
  intro p hp
  have h : env58380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58379_58380 : H12AffineEnvironment.transform 4 17 env58379 = env58380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58379 == env58380) = true)

theorem identity58380 : scanCanonicalize (H12AffineFastState.compose env58380 (packedSelected [0,3,10] rootPS)) = affineNative (2^(17+1) ^^^ 512) := by decide +kernel

theorem selectedBound58380 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env58381 : List Nat := [2,4,8,16,17,64,88,21,512,84,587,586,72,538,1,66,587,512,84,1,538,17,64,3,25,17,593,538,538,586,20,65,20,17,586,512]

theorem envBound58381 : H12AffineFastState.Bounded env58381 := by
  intro p hp
  have h : env58381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58380_58381 : H12AffineEnvironment.transform 17 512 env58380 = env58381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env58380 == env58381) = true)

theorem identity58381 : scanCanonicalize (H12AffineFastState.compose env58381 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58381 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58382 : List Nat := [2,4,8,16,17,17,9,21,512,5,538,539,25,538,1,19,538,512,5,1,538,17,17,3,25,17,512,538,538,539,20,16,20,17,539,512]

theorem envBound58382 : H12AffineFastState.Bounded env58382 := by
  intro p hp
  have h : env58382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58381_58382 : H12AffineEnvironment.transform 5 17 env58381 = env58382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58381 == env58382) = true)

theorem identity58382 : scanCanonicalize (H12AffineFastState.compose env58382 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58382 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58383 : List Nat := [2,4,8,10,11,11,9,15,512,5,512,513,3,512,1,9,512,512,5,1,512,11,11,3,3,11,512,512,512,513,14,10,14,11,513,512]

theorem envBound58383 : H12AffineFastState.Bounded env58383 := by
  intro p hp
  have h : env58383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58382_58383 : H12AffineEnvironment.transform 3 10 env58382 = env58383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58382 == env58383) = true)

theorem identity58383 : scanCanonicalize (H12AffineFastState.compose env58383 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58384 : List Nat := [2,4,8,10,11,11,9,15,0,5,0,1,3,0,1,9,0,0,5,1,0,11,11,3,3,11,0,0,0,1,14,10,14,11,1,0]

theorem envBound58384 : H12AffineFastState.Bounded env58384 := by
  intro p hp
  have h : env58384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58383_58384 : H12AffineEnvironment.transform 8 0 env58383 = env58384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58383 == env58384) = true)

def env58385 : List Nat := [2,4,8,16,32,64,89,256,512,84,862,4096,349,4176,292,115,4388,262144,84,292,4469,32,266250,266605,269,266331,4122,4176,4469,635,266350,113,257,266574,4389,512]

theorem envBound58385 : H12AffineFastState.Bounded env58385 := by
  intro p hp
  have h : env58385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58376_58385 : H12AffineEnvironment.transform 6 89 env58376 = env58385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58376 == env58385) = true)

theorem identity58385 : scanCanonicalize (H12AffineFastState.compose env58385 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58385 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58386 : List Nat := [2,4,8,16,32,64,89,256,512,84,862,555,349,635,292,115,783,262144,84,292,862,32,262689,262982,269,262768,561,635,862,635,262725,113,257,263013,782,512]

theorem envBound58386 : H12AffineFastState.Bounded env58386 := by
  intro p hp
  have h : env58386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58385_58386 : H12AffineEnvironment.transform 11 555 env58385 = env58386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58385 == env58386) = true)

theorem identity58386 : scanCanonicalize (H12AffineFastState.compose env58386 (packedSelected [0,4,5,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound58386 : packedSelected [0,4,5,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58387 : List Nat := [2,4,8,16,32,64,89,256,271,84,81,292,349,372,292,115,0,262144,84,292,81,32,262446,262217,269,262527,318,372,81,372,262474,113,257,262250,1,271]

theorem envBound58387 : H12AffineFastState.Bounded env58387 := by
  intro p hp
  have h : env58387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58386_58387 : H12AffineEnvironment.transform 8 271 env58386 = env58387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env58386 == env58387) = true)

theorem identity58387 : scanCanonicalize (H12AffineFastState.compose env58387 (packedSelected [0,4,5,7,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound58387 : packedSelected [0,4,5,7,9,18] rootPS < 2^1333 := by decide +kernel

def env58388 : List Nat := [2,4,8,16,32,64,89,256,271,84,81,292,349,372,292,115,0,26,84,292,81,32,308,83,269,357,318,372,81,372,336,113,257,112,1,271]

theorem envBound58388 : H12AffineFastState.Bounded env58388 := by
  intro p hp
  have h : env58388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58387_58388 : H12AffineEnvironment.transform 17 26 env58387 = env58388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env58387 == env58388) = true)

theorem identity58388 : scanCanonicalize (H12AffineFastState.compose env58388 (packedSelected [1,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58388 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env58389 : List Nat := [2,4,8,10,32,64,67,256,271,78,75,292,327,366,292,105,0,0,78,292,75,32,302,73,269,357,292,366,75,366,330,107,257,106,1,271]

theorem envBound58389 : H12AffineFastState.Bounded env58389 := by
  intro p hp
  have h : env58389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58388_58389 : H12AffineEnvironment.transform 3 10 env58388 = env58389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58388 == env58389) = true)

def env58390 : List Nat := [2,4,8,10,32,64,67,36,43,78,75,0,99,74,0,105,0,0,78,0,75,32,10,73,41,65,0,74,75,74,110,107,37,106,1,43]

theorem envBound58390 : H12AffineFastState.Bounded env58390 := by
  intro p hp
  have h : env58390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58389_58390 : H12AffineEnvironment.transform 7 36 env58389 = env58390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58389 == env58390) = true)

theorem identity58390 : scanCanonicalize (H12AffineFastState.compose env58390 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58391 : List Nat := [2,4,8,10,11,64,67,15,0,78,75,0,72,74,0,66,0,0,78,0,75,11,10,73,2,65,0,74,75,74,69,64,14,65,1,0]

theorem envBound58391 : H12AffineFastState.Bounded env58391 := by
  intro p hp
  have h : env58391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58390_58391 : H12AffineEnvironment.transform 4 11 env58390 = env58391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58390 == env58391) = true)

def env58392 : List Nat := [2,4,8,10,32,64,67,37,42,78,75,1,98,75,1,105,0,0,78,1,75,32,11,73,40,64,1,75,75,75,111,107,36,106,1,42]

theorem envBound58392 : H12AffineFastState.Bounded env58392 := by
  intro p hp
  have h : env58392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58389_58392 : H12AffineEnvironment.transform 7 37 env58389 = env58392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58389 == env58392) = true)

def env58393 : List Nat := [2,4,8,16,32,64,128,256,512,85,863,4096,348,4176,508,114,4605,262144,85,508,4524,32,266250,266605,469,266331,4291,4176,4524,634,266422,168,257,266574,4604,512]

theorem envBound58393 : H12AffineFastState.Bounded env58393 := by
  intro p hp
  have h : env58393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58375_58393 : H12AffineEnvironment.transform 9 85 env58375 = env58393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58375 == env58393) = true)

def env58394 : List Nat := [2,4,8,16,32,64,88,256,512,85,863,4096,348,4176,292,114,4389,262144,85,292,4468,32,266250,266605,269,266331,4123,4176,4468,634,266350,112,257,266574,4388,512]

theorem envBound58394 : H12AffineFastState.Bounded env58394 := by
  intro p hp
  have h : env58394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58393_58394 : H12AffineEnvironment.transform 6 88 env58393 = env58394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58393 == env58394) = true)

theorem identity58394 : scanCanonicalize (H12AffineFastState.compose env58394 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 609) := by decide +kernel

theorem selectedBound58394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58395 : List Nat := [2,4,8,16,32,64,88,256,512,85,863,4096,348,4176,292,114,4389,609,85,292,4468,32,4715,4876,269,4666,4123,4176,4468,634,4623,112,257,4911,4388,512]

theorem envBound58395 : H12AffineFastState.Bounded env58395 := by
  intro p hp
  have h : env58395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58394_58395 : H12AffineEnvironment.transform 17 609 env58394 = env58395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 609 env58394 == env58395) = true)

theorem identity58395 : scanCanonicalize (H12AffineFastState.compose env58395 (packedSelected [3,7,9,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound58395 : packedSelected [3,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58396 : List Nat := [2,4,8,16,32,64,88,256,512,85,863,586,348,538,292,114,879,609,85,292,830,32,33,326,269,112,593,538,830,634,69,112,257,357,878,512]

theorem envBound58396 : H12AffineFastState.Bounded env58396 := by
  intro p hp
  have h : env58396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58395_58396 : H12AffineEnvironment.transform 11 586 env58395 = env58396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env58395 == env58396) = true)

theorem identity58396 : scanCanonicalize (H12AffineFastState.compose env58396 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound58396 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58397 : List Nat := [2,4,8,16,32,64,88,62,512,85,609,586,98,538,26,114,593,609,85,26,512,32,33,120,51,112,593,538,512,634,69,112,63,91,592,512]

theorem envBound58397 : H12AffineFastState.Bounded env58397 := by
  intro p hp
  have h : env58397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58396_58397 : H12AffineEnvironment.transform 7 62 env58396 = env58397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env58396 == env58397) = true)

theorem identity58397 : scanCanonicalize (H12AffineFastState.compose env58397 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58397 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58398 : List Nat := [2,4,8,16,32,10,18,62,512,31,555,512,40,538,26,56,539,555,31,26,512,32,33,50,51,58,539,538,512,560,15,58,63,17,538,512]

theorem envBound58398 : H12AffineFastState.Bounded env58398 := by
  intro p hp
  have h : env58398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58397_58398 : H12AffineEnvironment.transform 5 10 env58397 = env58398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58397 == env58398) = true)

theorem identity58398 : scanCanonicalize (H12AffineFastState.compose env58398 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58398 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env58399 : List Nat := [2,4,8,10,32,10,8,36,512,5,555,512,40,512,0,34,513,555,5,0,512,32,33,40,41,32,513,512,512,554,15,32,37,11,512,512]

theorem envBound58399 : H12AffineFastState.Bounded env58399 := by
  intro p hp
  have h : env58399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58398_58399 : H12AffineEnvironment.transform 3 10 env58398 = env58399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58398 == env58399) = true)

theorem identity58399 : scanCanonicalize (H12AffineFastState.compose env58399 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58400 : List Nat := [2,4,8,10,11,10,8,15,512,5,512,512,3,512,0,9,513,512,5,0,512,11,10,3,2,11,513,512,512,513,15,11,14,11,512,512]

theorem envBound58400 : H12AffineFastState.Bounded env58400 := by
  intro p hp
  have h : env58400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58399_58400 : H12AffineEnvironment.transform 4 11 env58399 = env58400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58399 == env58400) = true)

theorem identity58400 : scanCanonicalize (H12AffineFastState.compose env58400 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58400 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58401 : List Nat := [2,4,8,10,11,10,8,15,0,5,0,0,3,0,0,9,1,0,5,0,0,11,10,3,2,11,1,0,0,1,15,11,14,11,0,0]

theorem envBound58401 : H12AffineFastState.Bounded env58401 := by
  intro p hp
  have h : env58401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58400_58401 : H12AffineEnvironment.transform 8 0 env58400 = env58401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58400 == env58401) = true)

def env58402 : List Nat := [2,4,8,16,32,64,89,256,512,85,863,4096,348,4176,293,114,4388,262144,85,293,4469,32,266250,266605,268,266331,4122,4176,4469,634,266351,113,257,266574,4389,512]

theorem envBound58402 : H12AffineFastState.Bounded env58402 := by
  intro p hp
  have h : env58402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58393_58402 : H12AffineEnvironment.transform 6 89 env58393 = env58402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58393 == env58402) = true)

theorem identity58402 : scanCanonicalize (H12AffineFastState.compose env58402 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 788) := by decide +kernel

theorem selectedBound58402 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58403 : List Nat := [2,4,8,16,32,64,89,256,512,85,863,4096,348,4176,293,114,4388,788,85,293,4469,32,4894,4729,268,4943,4122,4176,4469,634,4987,113,257,4698,4389,512]

theorem envBound58403 : H12AffineFastState.Bounded env58403 := by
  intro p hp
  have h : env58403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58402_58403 : H12AffineEnvironment.transform 17 788 env58402 = env58403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 788 env58402 == env58403) = true)

theorem identity58403 : scanCanonicalize (H12AffineFastState.compose env58403 (packedSelected [5,7,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound58403 : packedSelected [5,7,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58404 : List Nat := [2,4,8,16,32,64,89,256,270,85,81,4096,348,4176,293,114,4388,26,85,293,4469,32,4112,4471,268,4161,4122,4176,4469,372,4213,113,257,4436,4389,270]

theorem envBound58404 : H12AffineFastState.Bounded env58404 := by
  intro p hp
  have h : env58404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58403_58404 : H12AffineEnvironment.transform 8 270 env58403 = env58404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env58403 == env58404) = true)

theorem identity58404 : scanCanonicalize (H12AffineFastState.compose env58404 (packedSelected [0,4,5,7,9,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58404 : packedSelected [0,4,5,7,9,18] rootPS < 2^1333 := by decide +kernel

def env58405 : List Nat := [2,4,8,10,32,64,67,256,270,79,75,4096,326,4170,293,104,4388,0,79,293,4463,32,4106,4461,268,4161,4096,4170,4463,366,4207,107,257,4430,4389,270]

theorem envBound58405 : H12AffineFastState.Bounded env58405 := by
  intro p hp
  have h : env58405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58404_58405 : H12AffineEnvironment.transform 3 10 env58404 = env58405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58404 == env58405) = true)

theorem identity58405 : scanCanonicalize (H12AffineFastState.compose env58405 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound58405 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58406 : List Nat := [2,4,8,10,32,64,67,256,270,79,75,292,326,366,293,104,0,0,79,293,75,32,302,73,268,357,292,366,75,366,331,107,257,106,1,270]

theorem envBound58406 : H12AffineFastState.Bounded env58406 := by
  intro p hp
  have h : env58406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58405_58406 : H12AffineEnvironment.transform 11 292 env58405 = env58406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env58405 == env58406) = true)

def env58407 : List Nat := [2,4,8,10,32,64,67,36,42,79,75,0,98,74,1,104,0,0,79,1,75,32,10,73,40,65,0,74,75,74,111,107,37,106,1,42]

theorem envBound58407 : H12AffineFastState.Bounded env58407 := by
  intro p hp
  have h : env58407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58406_58407 : H12AffineEnvironment.transform 7 36 env58406 = env58407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58406 == env58407) = true)

theorem identity58407 : scanCanonicalize (H12AffineFastState.compose env58407 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58408 : List Nat := [2,4,8,10,11,64,67,15,1,79,75,0,73,74,1,67,0,0,79,1,75,11,10,73,3,65,0,74,75,74,68,64,14,65,1,1]

theorem envBound58408 : H12AffineFastState.Bounded env58408 := by
  intro p hp
  have h : env58408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58407_58408 : H12AffineEnvironment.transform 4 11 env58407 = env58408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58407 == env58408) = true)

def env58409 : List Nat := [2,4,8,10,32,64,67,37,43,79,75,1,99,75,0,104,0,0,79,0,75,32,11,73,41,64,1,75,75,75,110,107,36,106,1,43]

theorem envBound58409 : H12AffineFastState.Bounded env58409 := by
  intro p hp
  have h : env58409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58406_58409 : H12AffineEnvironment.transform 7 37 env58406 = env58409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58406 == env58409) = true)

def env58410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388689,10785997,4176,77954,4294795,8463815,2101508,257,14725224,78034,33563273]

theorem envBound58410 : H12AffineFastState.Bounded env58410 := by
  intro p hp
  have h : env58410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58258_58410 : H12AffineEnvironment.transform 26 10785997 env58258 = env58410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 10785997 env58258 == env58410) = true)

def env58411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,4227080,8388689,10785997,4176,77954,4294795,8463815,2101508,257,14725224,78034,4235905]

theorem envBound58411 : H12AffineFastState.Bounded env58411 := by
  intro p hp
  have h : env58411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58410_58411 : H12AffineEnvironment.transform 24 4227080 env58410 = env58411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env58410 == env58411) = true)

theorem identity58411 : scanCanonicalize (H12AffineFastState.compose env58411 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 2209034) := by decide +kernel

theorem selectedBound58411 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,2209034,8388608,8430023,2176258,8388689,10785997,4176,77954,2112897,8463815,2101508,257,8455522,78034,2168715]

theorem envBound58412 : H12AffineFastState.Bounded env58412 := by
  intro p hp
  have h : env58412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58411_58412 : H12AffineEnvironment.transform 21 2209034 env58411 = env58412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2209034 env58411 == env58412) = true)

theorem identity58412 : scanCanonicalize (H12AffineFastState.compose env58412 (packedSelected [15,17,19,21,26,38] rootPS)) = affineNative (2^(20+1) ^^^ 71051) := by decide +kernel

theorem selectedBound58412 : packedSelected [15,17,19,21,26,38] rootPS < 2^1333 := by decide +kernel

def env58413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71051,41089,8388608,8430023,8329,8388689,8749382,4176,77954,75786,8463815,66703,257,8455522,78034,512]

theorem envBound58413 : H12AffineFastState.Bounded env58413 := by
  intro p hp
  have h : env58413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58412_58413 : H12AffineEnvironment.transform 20 71051 env58412 = env58413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71051 env58412 == env58413) = true)

theorem identity58413 : scanCanonicalize (H12AffineFastState.compose env58413 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound58413 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37893,41089,8388608,8430023,8329,8388689,8650952,4176,45324,43396,8430665,34049,257,8422636,45404,512]

theorem envBound58414 : H12AffineFastState.Bounded env58414 := by
  intro p hp
  have h : env58414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58413_58414 : H12AffineEnvironment.transform 15 33166 env58413 = env58414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env58413 == env58414) = true)

theorem identity58414 : scanCanonicalize (H12AffineFastState.compose env58414 (packedSelected [5,8] rootPS)) = affineNative (2^(22+1) ^^^ 311201) := by decide +kernel

theorem selectedBound58414 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37893,41089,311201,269926,8329,311280,49001,4176,45324,43396,269288,34049,257,277325,45404,512]

theorem envBound58415 : H12AffineFastState.Bounded env58415 := by
  intro p hp
  have h : env58415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58414_58415 : H12AffineEnvironment.transform 22 311201 env58414 = env58415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 311201 env58414 == env58415) = true)

theorem identity58415 : scanCanonicalize (H12AffineFastState.compose env58415 (packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound58415 : packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS < 2^1333 := by decide +kernel

def env58416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8353,8495,4604,262144,1024,8353,13476,32,270080,269926,8329,270161,8136,4176,4525,2341,269288,9632,257,277325,4605,512]

theorem envBound58416 : H12AffineFastState.Bounded env58416 := by
  intro p hp
  have h : env58416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58415_58416 : H12AffineEnvironment.transform 14 8353 env58415 = env58416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env58415 == env58416) = true)

def env58417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1449,1063,4604,262144,1024,1449,4524,32,270080,269926,1409,270161,8136,4176,4525,2341,269288,168,257,269893,4605,512]

theorem envBound58417 : H12AffineFastState.Bounded env58417 := by
  intro p hp
  have h : env58417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58416_58417 : H12AffineEnvironment.transform 12 1288 env58416 = env58417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env58416 == env58417) = true)

theorem identity58417 : scanCanonicalize (H12AffineFastState.compose env58417 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound58417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,4096,1288,4176,1449,1063,4604,262144,1024,1449,4524,32,266663,266433,1409,266742,4463,4176,4525,1922,267599,168,257,266466,4605,512]

theorem envBound58418 : H12AffineFastState.Bounded env58418 := by
  intro p hp
  have h : env58418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58417_58418 : H12AffineEnvironment.transform 10 1703 env58417 = env58418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env58417 == env58418) = true)

def env58419 : List Nat := [2,4,8,16,32,64,128,256,512,84,755,4096,348,4176,509,115,4604,262144,84,509,4524,32,266663,266433,469,266742,4463,4176,4525,982,266523,168,257,266466,4605,512]

theorem envBound58419 : H12AffineFastState.Bounded env58419 := by
  intro p hp
  have h : env58419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58418_58419 : H12AffineEnvironment.transform 9 84 env58418 = env58419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58418 == env58419) = true)

def env58420 : List Nat := [2,4,8,16,32,64,88,256,512,84,555,4096,348,4176,293,115,4388,262144,84,293,4468,32,266623,266265,269,266542,4463,4176,4469,782,266523,112,257,266298,4389,512]

theorem envBound58420 : H12AffineFastState.Bounded env58420 := by
  intro p hp
  have h : env58420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58419_58420 : H12AffineEnvironment.transform 6 88 env58419 = env58420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58419 == env58420) = true)

theorem identity58420 : scanCanonicalize (H12AffineFastState.compose env58420 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 788) := by decide +kernel

theorem selectedBound58420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58421 : List Nat := [2,4,8,16,32,64,88,256,512,84,555,4096,348,4176,293,115,4388,788,84,293,4468,32,4715,4877,269,4666,4463,4176,4469,782,4623,112,257,4910,4389,512]

theorem envBound58421 : H12AffineFastState.Bounded env58421 := by
  intro p hp
  have h : env58421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58420_58421 : H12AffineEnvironment.transform 17 788 env58420 = env58421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 788 env58420 == env58421) = true)

theorem identity58421 : scanCanonicalize (H12AffineFastState.compose env58421 (packedSelected [3,7,9,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58421 : packedSelected [3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58422 : List Nat := [2,4,8,16,32,64,88,36,512,84,555,4096,120,4176,1,115,4096,560,84,1,4176,32,4715,4649,41,4666,4171,4176,4177,554,4623,112,37,4618,4097,512]

theorem envBound58422 : H12AffineFastState.Bounded env58422 := by
  intro p hp
  have h : env58422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58421_58422 : H12AffineEnvironment.transform 7 36 env58421 = env58422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58421 == env58422) = true)

theorem identity58422 : scanCanonicalize (H12AffineFastState.compose env58422 (packedSelected [1,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound58422 : packedSelected [1,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env58423 : List Nat := [2,4,8,16,32,64,88,36,512,84,555,561,120,609,1,115,561,560,84,1,609,32,90,24,41,11,634,609,608,554,62,112,37,59,560,512]

theorem envBound58423 : H12AffineFastState.Bounded env58423 := by
  intro p hp
  have h : env58423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58422_58423 : H12AffineEnvironment.transform 11 561 env58422 = env58423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env58422 == env58423) = true)

def env58424 : List Nat := [2,4,8,16,32,64,89,256,512,84,554,4096,348,4176,292,115,4389,262144,84,292,4469,32,266622,266264,268,266543,4463,4176,4468,783,266523,113,257,266299,4388,512]

theorem envBound58424 : H12AffineFastState.Bounded env58424 := by
  intro p hp
  have h : env58424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58419_58424 : H12AffineEnvironment.transform 6 89 env58419 = env58424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58419 == env58424) = true)

theorem identity58424 : scanCanonicalize (H12AffineFastState.compose env58424 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 609) := by decide +kernel

theorem selectedBound58424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58425 : List Nat := [2,4,8,16,32,64,89,256,512,84,554,4096,348,4176,292,115,4389,609,84,292,4469,32,4895,4729,268,4942,4463,4176,4468,783,4986,113,257,4698,4388,512]

theorem envBound58425 : H12AffineFastState.Bounded env58425 := by
  intro p hp
  have h : env58425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58424_58425 : H12AffineEnvironment.transform 17 609 env58424 = env58425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 609 env58424 == env58425) = true)

theorem identity58425 : scanCanonicalize (H12AffineFastState.compose env58425 (packedSelected [5,7,9,10,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound58425 : packedSelected [5,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58426 : List Nat := [2,4,8,16,32,64,89,256,512,84,554,97,348,49,292,115,324,609,84,292,276,32,894,536,268,815,270,49,277,783,795,113,257,571,325,512]

theorem envBound58426 : H12AffineFastState.Bounded env58426 := by
  intro p hp
  have h : env58426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58425_58426 : H12AffineEnvironment.transform 11 97 env58425 = env58426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env58425 == env58426) = true)

theorem identity58426 : scanCanonicalize (H12AffineFastState.compose env58426 (packedSelected [0,1,7,11,13,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58426 : packedSelected [0,1,7,11,13,15] rootPS < 2^1333 := by decide +kernel

def env58427 : List Nat := [2,4,8,11,32,64,66,256,512,79,554,97,327,42,292,104,324,609,79,292,271,32,869,515,268,815,270,42,270,783,768,106,257,544,325,512]

theorem envBound58427 : H12AffineFastState.Bounded env58427 := by
  intro p hp
  have h : env58427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58426_58427 : H12AffineEnvironment.transform 3 11 env58426 = env58427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58426 == env58427) = true)

theorem identity58427 : scanCanonicalize (H12AffineFastState.compose env58427 (packedSelected [1,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound58427 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env58428 : List Nat := [2,4,8,11,32,64,66,256,75,79,97,97,327,42,292,104,324,42,79,292,271,32,302,72,268,356,270,42,270,324,331,106,257,107,325,75]

theorem envBound58428 : H12AffineFastState.Bounded env58428 := by
  intro p hp
  have h : env58428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58427_58428 : H12AffineEnvironment.transform 8 75 env58427 = env58428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env58427 == env58428) = true)

def env58429 : List Nat := [2,4,8,11,32,32,34,256,43,47,1,1,295,42,292,8,292,42,47,292,271,32,302,40,268,260,270,42,270,292,299,10,257,11,293,43]

theorem envBound58429 : H12AffineFastState.Bounded env58429 := by
  intro p hp
  have h : env58429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58428_58429 : H12AffineEnvironment.transform 5 32 env58428 = env58429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58428 == env58429) = true)

def env58430 : List Nat := [2,4,8,11,32,33,35,256,42,46,0,0,294,42,292,9,293,42,46,292,271,32,302,41,268,261,270,42,270,293,298,11,257,10,292,42]

theorem envBound58430 : H12AffineFastState.Bounded env58430 := by
  intro p hp
  have h : env58430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58428_58430 : H12AffineEnvironment.transform 5 33 env58428 = env58430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58428 == env58430) = true)

theorem identity58430 : scanCanonicalize (H12AffineFastState.compose env58430 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58431 : List Nat := [2,4,8,11,32,33,35,37,42,46,0,0,3,42,1,9,0,42,46,1,42,32,11,41,41,32,43,42,43,0,15,11,36,10,1,42]

theorem envBound58431 : H12AffineFastState.Bounded env58431 := by
  intro p hp
  have h : env58431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58430_58431 : H12AffineEnvironment.transform 7 37 env58430 = env58431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58430 == env58431) = true)

def env58432 : List Nat := [2,4,8,16,32,64,128,256,512,85,754,4096,349,4176,508,114,4604,262144,85,508,4524,32,266663,266433,468,266742,4463,4176,4525,983,266522,168,257,266466,4605,512]

theorem envBound58432 : H12AffineFastState.Bounded env58432 := by
  intro p hp
  have h : env58432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58418_58432 : H12AffineEnvironment.transform 9 85 env58418 = env58432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58418 == env58432) = true)

def env58433 : List Nat := [2,4,8,16,32,64,88,256,512,85,554,4096,349,4176,292,114,4388,262144,85,292,4468,32,266623,266265,268,266542,4463,4176,4469,783,266522,112,257,266298,4389,512]

theorem envBound58433 : H12AffineFastState.Bounded env58433 := by
  intro p hp
  have h : env58433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58432_58433 : H12AffineEnvironment.transform 6 88 env58432 = env58433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58432 == env58433) = true)

theorem identity58433 : scanCanonicalize (H12AffineFastState.compose env58433 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound58433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58434 : List Nat := [2,4,8,16,32,64,88,256,512,85,554,862,349,782,292,114,634,262144,85,292,554,32,262689,262983,268,262768,561,782,555,783,262724,112,257,263012,635,512]

theorem envBound58434 : H12AffineFastState.Bounded env58434 := by
  intro p hp
  have h : env58434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58433_58434 : H12AffineEnvironment.transform 11 862 env58433 = env58434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env58433 == env58434) = true)

theorem identity58434 : scanCanonicalize (H12AffineFastState.compose env58434 (packedSelected [0,3,4,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58434 : packedSelected [0,3,4,11,13] rootPS < 2^1333 := by decide +kernel

def env58435 : List Nat := [2,4,8,16,32,64,88,37,512,85,554,635,120,555,1,114,634,262144,85,1,554,32,262689,262754,41,262768,561,555,555,554,262724,112,36,262721,635,512]

theorem envBound58435 : H12AffineFastState.Bounded env58435 := by
  intro p hp
  have h : env58435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58434_58435 : H12AffineEnvironment.transform 7 37 env58434 = env58435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58434 == env58435) = true)

theorem identity58435 : scanCanonicalize (H12AffineFastState.compose env58435 (packedSelected [1,4,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58435 : packedSelected [1,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env58436 : List Nat := [2,4,8,16,32,11,19,37,512,30,554,560,51,555,1,57,561,262144,30,1,554,32,262689,262697,41,262715,561,555,555,554,262671,59,36,262666,560,512]

theorem envBound58436 : H12AffineFastState.Bounded env58436 := by
  intro p hp
  have h : env58436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58435_58436 : H12AffineEnvironment.transform 5 11 env58435 = env58436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58435 == env58436) = true)

theorem identity58436 : scanCanonicalize (H12AffineFastState.compose env58436 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58436 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58437 : List Nat := [2,4,8,16,17,11,19,20,512,30,539,513,2,538,1,8,512,262144,30,1,539,17,262672,262680,24,262666,512,538,538,539,262671,10,21,262666,513,512]

theorem envBound58437 : H12AffineFastState.Bounded env58437 := by
  intro p hp
  have h : env58437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58436_58437 : H12AffineEnvironment.transform 4 17 env58436 = env58437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58436 == env58437) = true)

theorem identity58437 : scanCanonicalize (H12AffineFastState.compose env58437 (packedSelected [1,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 513) := by decide +kernel

theorem selectedBound58437 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env58438 : List Nat := [2,4,8,16,17,11,19,20,512,30,539,513,2,538,1,8,512,513,30,1,539,17,17,25,24,11,512,538,538,539,14,10,21,11,513,512]

theorem envBound58438 : H12AffineFastState.Bounded env58438 := by
  intro p hp
  have h : env58438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58437_58438 : H12AffineEnvironment.transform 17 513 env58437 = env58438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env58437 == env58438) = true)

def env58439 : List Nat := [2,4,8,16,32,64,89,256,512,85,555,4096,349,4176,293,114,4389,262144,85,293,4469,32,266622,266264,269,266543,4463,4176,4468,782,266522,113,257,266299,4388,512]

theorem envBound58439 : H12AffineFastState.Bounded env58439 := by
  intro p hp
  have h : env58439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58432_58439 : H12AffineEnvironment.transform 6 89 env58432 = env58439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58432 == env58439) = true)

theorem identity58439 : scanCanonicalize (H12AffineFastState.compose env58439 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58440 : List Nat := [2,4,8,16,32,64,89,256,512,85,555,555,349,635,293,114,782,262144,85,293,862,32,262997,262707,269,262916,836,635,863,782,262961,113,257,262672,783,512]

theorem envBound58440 : H12AffineFastState.Bounded env58440 := by
  intro p hp
  have h : env58440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58439_58440 : H12AffineEnvironment.transform 11 555 env58439 = env58440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58439 == env58440) = true)

theorem identity58440 : scanCanonicalize (H12AffineFastState.compose env58440 (packedSelected [0,4,5,10,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound58440 : packedSelected [0,4,5,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58441 : List Nat := [2,4,8,16,32,64,89,256,74,85,97,97,349,49,293,114,324,262144,85,293,276,32,262431,262265,269,262478,270,49,277,324,262523,113,257,262234,325,74]

theorem envBound58441 : H12AffineFastState.Bounded env58441 := by
  intro p hp
  have h : env58441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58440_58441 : H12AffineEnvironment.transform 8 74 env58440 = env58441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env58440 == env58441) = true)

theorem identity58441 : scanCanonicalize (H12AffineFastState.compose env58441 (packedSelected [0,1,4,5,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 42) := by decide +kernel

theorem selectedBound58441 : packedSelected [0,1,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env58442 : List Nat := [2,4,8,16,32,64,89,256,74,85,97,97,349,49,293,114,324,42,85,293,276,32,309,83,269,356,270,49,277,324,337,113,257,112,325,74]

theorem envBound58442 : H12AffineFastState.Bounded env58442 := by
  intro p hp
  have h : env58442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58441_58442 : H12AffineEnvironment.transform 17 42 env58441 = env58442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 42 env58441 == env58442) = true)

theorem identity58442 : scanCanonicalize (H12AffineFastState.compose env58442 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58442 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env58443 : List Nat := [2,4,8,11,32,64,66,256,74,78,97,97,326,42,293,105,324,42,78,293,271,32,302,72,269,356,270,42,270,324,330,106,257,107,325,74]

theorem envBound58443 : H12AffineFastState.Bounded env58443 := by
  intro p hp
  have h : env58443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58442_58443 : H12AffineEnvironment.transform 3 11 env58442 = env58443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58442 == env58443) = true)

def env58444 : List Nat := [2,4,8,11,32,32,34,256,42,46,1,1,294,42,293,9,292,42,46,293,271,32,302,40,269,260,270,42,270,292,298,10,257,11,293,42]

theorem envBound58444 : H12AffineFastState.Bounded env58444 := by
  intro p hp
  have h : env58444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58443_58444 : H12AffineEnvironment.transform 5 32 env58443 = env58444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58443 == env58444) = true)

def env58445 : List Nat := [2,4,8,11,32,33,35,256,43,47,0,0,295,42,293,8,293,42,47,293,271,32,302,41,269,261,270,42,270,293,299,11,257,10,292,43]

theorem envBound58445 : H12AffineFastState.Bounded env58445 := by
  intro p hp
  have h : env58445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58443_58445 : H12AffineEnvironment.transform 5 33 env58443 = env58445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58443 == env58445) = true)

theorem identity58445 : scanCanonicalize (H12AffineFastState.compose env58445 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58446 : List Nat := [2,4,8,11,32,33,35,37,43,47,0,0,2,42,0,8,0,42,47,0,42,32,11,41,40,32,43,42,43,0,14,11,36,10,1,43]

theorem envBound58446 : H12AffineFastState.Bounded env58446 := by
  intro p hp
  have h : env58446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58445_58446 : H12AffineEnvironment.transform 7 37 env58445 = env58446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58445 == env58446) = true)

def env58447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1448,1062,4604,262144,1024,1448,4525,32,270080,269926,1408,270161,8136,4176,4525,2341,269288,169,257,269892,4605,512]

theorem envBound58447 : H12AffineFastState.Bounded env58447 := by
  intro p hp
  have h : env58447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58416_58447 : H12AffineEnvironment.transform 12 1289 env58416 = env58447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env58416 == env58447) = true)

theorem identity58447 : scanCanonicalize (H12AffineFastState.compose env58447 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4170) := by decide +kernel

theorem selectedBound58447 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1448,1062,4604,4170,1024,1448,4525,32,3914,3628,1408,3867,8136,4176,4525,2341,2978,169,257,3598,4605,512]

theorem envBound58448 : H12AffineFastState.Bounded env58448 := by
  intro p hp
  have h : env58448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58447_58448 : H12AffineEnvironment.transform 17 4170 env58447 = env58448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4170 env58447 == env58448) = true)

def env58449 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,349,4176,508,114,4604,4170,84,508,4525,32,2846,2680,468,2895,7068,4176,4525,2341,2978,169,257,2650,4605,512]

theorem envBound58449 : H12AffineFastState.Bounded env58449 := by
  intro p hp
  have h : env58449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58448_58449 : H12AffineEnvironment.transform 9 84 env58448 = env58449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58448 == env58449) = true)

def env58450 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,4096,349,4176,292,114,4388,4170,84,292,4469,32,2846,2680,268,2895,6980,4176,4469,2341,2938,113,257,2650,4389,512]

theorem envBound58450 : H12AffineFastState.Bounded env58450 := by
  intro p hp
  have h : env58450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58449_58450 : H12AffineEnvironment.transform 6 88 env58449 = env58450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58449 == env58450) = true)

theorem identity58450 : scanCanonicalize (H12AffineFastState.compose env58450 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2421) := by decide +kernel

theorem selectedBound58450 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58451 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,2421,349,2341,292,114,2129,2367,84,292,2048,32,2846,2680,268,2895,561,2341,2048,2341,2938,113,257,2650,2128,512]

theorem envBound58451 : H12AffineFastState.Bounded env58451 := by
  intro p hp
  have h : env58451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58450_58451 : H12AffineEnvironment.transform 11 2421 env58450 = env58451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2421 env58450 == env58451) = true)

theorem identity58451 : scanCanonicalize (H12AffineFastState.compose env58451 (packedSelected [0,3,4,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound58451 : packedSelected [0,3,4,11,13] rootPS < 2^1333 := by decide +kernel

def env58452 : List Nat := [2,4,8,16,32,64,88,95,512,84,2048,2090,2,2170,123,114,2129,2144,84,123,2048,32,2625,2680,83,2576,561,2170,2048,2170,2597,113,94,2650,2128,512]

theorem envBound58452 : H12AffineFastState.Bounded env58452 := by
  intro p hp
  have h : env58452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58451_58452 : H12AffineEnvironment.transform 7 95 env58451 = env58452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env58451 == env58452) = true)

theorem identity58452 : scanCanonicalize (H12AffineFastState.compose env58452 (packedSelected [4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound58452 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env58453 : List Nat := [2,4,8,16,32,64,88,95,512,84,539,561,2,609,123,114,586,635,84,123,539,32,90,99,83,11,561,609,539,609,62,113,94,65,587,512]

theorem envBound58453 : H12AffineFastState.Bounded env58453 := by
  intro p hp
  have h : env58453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58452_58453 : H12AffineEnvironment.transform 10 539 env58452 = env58453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env58452 == env58453) = true)

theorem identity58453 : scanCanonicalize (H12AffineFastState.compose env58453 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound58453 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58454 : List Nat := [2,4,8,16,32,59,35,36,512,47,539,561,2,538,0,9,561,512,47,0,539,32,33,24,40,11,561,538,539,538,62,10,37,58,560,512]

theorem envBound58454 : H12AffineFastState.Bounded env58454 := by
  intro p hp
  have h : env58454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58453_58454 : H12AffineEnvironment.transform 5 59 env58453 = env58454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env58453 == env58454) = true)

theorem identity58454 : scanCanonicalize (H12AffineFastState.compose env58454 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58454 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58455 : List Nat := [2,4,8,16,17,10,18,21,512,30,539,512,2,538,0,9,512,512,30,0,539,17,16,24,25,11,512,538,539,538,15,10,20,11,513,512]

theorem envBound58455 : H12AffineFastState.Bounded env58455 := by
  intro p hp
  have h : env58455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58454_58455 : H12AffineEnvironment.transform 4 17 env58454 = env58455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58454 == env58455) = true)

def env58456 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,4096,349,4176,293,114,4389,4170,84,293,4468,32,2846,2680,269,2895,6981,4176,4468,2341,2939,112,257,2650,4388,512]

theorem envBound58456 : H12AffineFastState.Bounded env58456 := by
  intro p hp
  have h : env58456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58449_58456 : H12AffineEnvironment.transform 6 89 env58449 = env58456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58449 == env58456) = true)

theorem identity58456 : scanCanonicalize (H12AffineFastState.compose env58456 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound58456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58457 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,2049,349,2129,293,114,2340,2123,84,293,2421,32,2846,2680,269,2895,836,2129,2421,2341,2939,112,257,2650,2341,512]

theorem envBound58457 : H12AffineFastState.Bounded env58457 := by
  intro p hp
  have h : env58457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58456_58457 : H12AffineEnvironment.transform 11 2049 env58456 = env58457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env58456 == env58457) = true)

theorem identity58457 : scanCanonicalize (H12AffineFastState.compose env58457 (packedSelected [0,4,5,10,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound58457 : packedSelected [0,4,5,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58458 : List Nat := [2,4,8,16,32,64,89,256,512,84,26,27,349,75,293,114,318,81,84,293,367,32,772,610,269,853,836,75,367,319,865,112,257,576,319,512]

theorem envBound58458 : H12AffineFastState.Bounded env58458 := by
  intro p hp
  have h : env58458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58457_58458 : H12AffineEnvironment.transform 10 26 env58457 = env58458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env58457 == env58458) = true)

theorem identity58458 : scanCanonicalize (H12AffineFastState.compose env58458 (packedSelected [0,1,3,5,7,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58458 : packedSelected [0,1,3,5,7,10,13] rootPS < 2^1333 := by decide +kernel

def env58459 : List Nat := [2,4,8,11,32,64,66,256,512,79,1,0,326,75,293,105,293,74,79,293,367,32,772,610,269,846,836,75,367,292,865,107,257,576,292,512]

theorem envBound58459 : H12AffineFastState.Bounded env58459 := by
  intro p hp
  have h : env58459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58458_58459 : H12AffineEnvironment.transform 3 11 env58458 = env58459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58458 == env58459) = true)

theorem identity58459 : scanCanonicalize (H12AffineFastState.compose env58459 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58459 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58460 : List Nat := [2,4,8,11,32,64,66,256,42,79,1,0,326,75,293,105,293,74,79,293,367,32,302,72,269,356,366,75,367,292,331,107,257,106,292,42]

theorem envBound58460 : H12AffineFastState.Bounded env58460 := by
  intro p hp
  have h : env58460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58459_58460 : H12AffineEnvironment.transform 8 42 env58459 = env58460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58459 == env58460) = true)

def env58461 : List Nat := [2,4,8,11,32,32,34,256,42,47,1,0,294,43,293,9,293,42,47,293,271,32,302,40,269,260,270,43,271,292,299,11,257,10,292,42]

theorem envBound58461 : H12AffineFastState.Bounded env58461 := by
  intro p hp
  have h : env58461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58460_58461 : H12AffineEnvironment.transform 5 32 env58460 = env58461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58460 == env58461) = true)

theorem identity58461 : scanCanonicalize (H12AffineFastState.compose env58461 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58461 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58462 : List Nat := [2,4,8,11,32,32,34,36,42,47,1,0,2,43,1,9,1,42,47,1,43,32,10,40,41,32,42,43,43,0,15,11,37,10,0,42]

theorem envBound58462 : H12AffineFastState.Bounded env58462 := by
  intro p hp
  have h : env58462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58461_58462 : H12AffineEnvironment.transform 7 36 env58461 = env58462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58461 == env58462) = true)

def env58463 : List Nat := [2,4,8,11,32,33,35,256,42,46,1,0,295,42,293,8,293,43,46,293,270,32,302,41,269,261,271,42,270,292,298,10,257,11,292,42]

theorem envBound58463 : H12AffineFastState.Bounded env58463 := by
  intro p hp
  have h : env58463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58460_58463 : H12AffineEnvironment.transform 5 33 env58460 = env58463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58460 == env58463) = true)

def env58464 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,348,4176,509,115,4604,4170,85,509,4525,32,2847,2681,469,2894,7069,4176,4525,2341,2978,169,257,2651,4605,512]

theorem envBound58464 : H12AffineFastState.Bounded env58464 := by
  intro p hp
  have h : env58464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58448_58464 : H12AffineEnvironment.transform 9 85 env58448 = env58464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58448 == env58464) = true)

def env58465 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,4096,348,4176,293,115,4388,4170,85,293,4469,32,2847,2681,269,2894,6981,4176,4469,2341,2938,113,257,2651,4389,512]

theorem envBound58465 : H12AffineFastState.Bounded env58465 := by
  intro p hp
  have h : env58465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58464_58465 : H12AffineEnvironment.transform 6 88 env58464 = env58465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58464 == env58465) = true)

theorem identity58465 : scanCanonicalize (H12AffineFastState.compose env58465 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound58465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58466 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,862,348,782,293,115,634,788,85,293,555,32,2847,2681,269,2894,2075,782,555,2341,2938,113,257,2651,635,512]

theorem envBound58466 : H12AffineFastState.Bounded env58466 := by
  intro p hp
  have h : env58466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58465_58466 : H12AffineEnvironment.transform 11 862 env58465 = env58466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env58465 == env58466) = true)

theorem identity58466 : scanCanonicalize (H12AffineFastState.compose env58466 (packedSelected [3,7,9,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound58466 : packedSelected [3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58467 : List Nat := [2,4,8,16,32,64,88,94,512,85,2048,512,2,592,123,115,634,586,85,123,555,32,2625,2681,83,2576,2075,592,555,2171,2596,113,95,2651,635,512]

theorem envBound58467 : H12AffineFastState.Bounded env58467 := by
  intro p hp
  have h : env58467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58466_58467 : H12AffineEnvironment.transform 7 94 env58466 = env58467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env58466 == env58467) = true)

theorem identity58467 : scanCanonicalize (H12AffineFastState.compose env58467 (packedSelected [0,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound58467 : packedSelected [0,9,10] rootPS < 2^1333 := by decide +kernel

def env58468 : List Nat := [2,4,8,16,32,64,88,94,512,85,555,512,2,592,123,115,634,586,85,123,555,32,106,82,83,59,560,592,555,592,15,113,95,112,635,512]

theorem envBound58468 : H12AffineFastState.Bounded env58468 := by
  intro p hp
  have h : env58468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58467_58468 : H12AffineEnvironment.transform 10 555 env58467 = env58468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env58467 == env58468) = true)

theorem identity58468 : scanCanonicalize (H12AffineFastState.compose env58468 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58468 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env58469 : List Nat := [2,4,8,16,16,64,88,94,512,85,539,512,2,592,75,67,586,586,85,75,539,16,90,82,83,11,512,592,539,592,15,65,95,64,587,512]

theorem envBound58469 : H12AffineFastState.Bounded env58469 := by
  intro p hp
  have h : env58469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58468_58469 : H12AffineEnvironment.transform 4 16 env58468 = env58469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58468 == env58469) = true)

def env58470 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,4096,348,4176,292,115,4389,4170,85,292,4468,32,2847,2681,268,2894,6980,4176,4468,2341,2939,112,257,2651,4388,512]

theorem envBound58470 : H12AffineFastState.Bounded env58470 := by
  intro p hp
  have h : env58470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58464_58470 : H12AffineEnvironment.transform 6 89 env58464 = env58470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58464 == env58470) = true)

theorem identity58470 : scanCanonicalize (H12AffineFastState.compose env58470 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58471 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,555,348,635,292,115,782,609,85,292,863,32,2847,2681,268,2894,2415,635,863,2341,2939,112,257,2651,783,512]

theorem envBound58471 : H12AffineFastState.Bounded env58471 := by
  intro p hp
  have h : env58471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58470_58471 : H12AffineEnvironment.transform 11 555 env58470 = env58471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58470 == env58471) = true)

theorem identity58471 : scanCanonicalize (H12AffineFastState.compose env58471 (packedSelected [5,7,9,10,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound58471 : packedSelected [5,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58472 : List Nat := [2,4,8,16,32,64,89,256,48,85,2048,27,348,75,292,115,318,81,85,292,367,32,2351,2121,268,2430,2415,75,367,2341,2379,112,257,2155,319,48]

theorem envBound58472 : H12AffineFastState.Bounded env58472 := by
  intro p hp
  have h : env58472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58471_58472 : H12AffineEnvironment.transform 8 48 env58471 = env58472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58471 == env58472) = true)

theorem identity58472 : scanCanonicalize (H12AffineFastState.compose env58472 (packedSelected [1,4,5,7,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58472 : packedSelected [1,4,5,7,12,15] rootPS < 2^1333 := by decide +kernel

def env58473 : List Nat := [2,4,8,11,32,64,66,256,43,78,2048,0,327,75,292,104,293,74,78,292,367,32,2351,2121,268,2405,2415,75,367,2341,2379,107,257,2155,292,43]

theorem envBound58473 : H12AffineFastState.Bounded env58473 := by
  intro p hp
  have h : env58473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58472_58473 : H12AffineEnvironment.transform 3 11 env58472 = env58473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58472 == env58473) = true)

theorem identity58473 : scanCanonicalize (H12AffineFastState.compose env58473 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58473 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58474 : List Nat := [2,4,8,11,32,64,66,256,43,78,1,0,327,75,292,104,293,74,78,292,367,32,302,72,268,356,366,75,367,292,330,107,257,106,292,43]

theorem envBound58474 : H12AffineFastState.Bounded env58474 := by
  intro p hp
  have h : env58474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58473_58474 : H12AffineEnvironment.transform 10 1 env58473 = env58474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58473 == env58474) = true)

def env58475 : List Nat := [2,4,8,11,32,32,34,256,43,46,1,0,295,43,292,8,293,42,46,292,271,32,302,40,268,260,270,43,271,292,298,11,257,10,292,43]

theorem envBound58475 : H12AffineFastState.Bounded env58475 := by
  intro p hp
  have h : env58475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58474_58475 : H12AffineEnvironment.transform 5 32 env58474 = env58475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58474 == env58475) = true)

theorem identity58475 : scanCanonicalize (H12AffineFastState.compose env58475 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58476 : List Nat := [2,4,8,11,32,32,34,36,43,46,1,0,3,43,0,8,1,42,46,0,43,32,10,40,40,32,42,43,43,0,14,11,37,10,0,43]

theorem envBound58476 : H12AffineFastState.Bounded env58476 := by
  intro p hp
  have h : env58476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58475_58476 : H12AffineEnvironment.transform 7 36 env58475 = env58476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58475 == env58476) = true)

def env58477 : List Nat := [2,4,8,11,32,33,35,256,43,47,1,0,294,42,292,9,293,43,47,292,270,32,302,41,268,261,271,42,270,292,299,10,257,11,292,43]

theorem envBound58477 : H12AffineFastState.Bounded env58477 := by
  intro p hp
  have h : env58477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58474_58477 : H12AffineEnvironment.transform 5 33 env58474 = env58477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58474 == env58477) = true)

def env58478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,4227081,8388689,10785997,4176,77954,4294795,8463815,2101508,257,14725224,78034,4235904]

theorem envBound58478 : H12AffineFastState.Bounded env58478 := by
  intro p hp
  have h : env58478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58410_58478 : H12AffineEnvironment.transform 24 4227081 env58410 = env58478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env58410 == env58478) = true)

theorem identity58478 : scanCanonicalize (H12AffineFastState.compose env58478 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound58478 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71050,4194304,8388608,8430023,4227081,8388689,8749383,4176,77954,4294795,8463815,66702,257,12690914,78034,4235904]

theorem envBound58479 : H12AffineFastState.Bounded env58479 := by
  intro p hp
  have h : env58479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58478_58479 : H12AffineEnvironment.transform 20 71050 env58478 = env58479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env58478 == env58479) = true)

theorem identity58479 : scanCanonicalize (H12AffineFastState.compose env58479 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound58479 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71050,41088,8388608,8430023,8329,8388689,8749383,4176,77954,75787,8463815,66702,257,8455522,78034,512]

theorem envBound58480 : H12AffineFastState.Bounded env58480 := by
  intro p hp
  have h : env58480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58479_58480 : H12AffineEnvironment.transform 21 41088 env58479 = env58480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env58479 == env58480) = true)

theorem identity58480 : scanCanonicalize (H12AffineFastState.compose env58480 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound58480 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37892,41088,8388608,8430023,8329,8388689,8650953,4176,45324,43397,8430665,34048,257,8422636,45404,512]

theorem envBound58481 : H12AffineFastState.Bounded env58481 := by
  intro p hp
  have h : env58481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58480_58481 : H12AffineEnvironment.transform 15 33166 env58480 = env58481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env58480 == env58481) = true)

theorem identity58481 : scanCanonicalize (H12AffineFastState.compose env58481 (packedSelected [5,8] rootPS)) = affineNative (2^(22+1) ^^^ 311200) := by decide +kernel

theorem selectedBound58481 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,45405,262144,1024,32768,37892,41088,311200,269927,8329,311281,49001,4176,45324,43397,269289,34048,257,277324,45404,512]

theorem envBound58482 : H12AffineFastState.Bounded env58482 := by
  intro p hp
  have h : env58482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58481_58482 : H12AffineEnvironment.transform 22 311200 env58481 = env58482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 311200 env58481 == env58482) = true)

theorem identity58482 : scanCanonicalize (H12AffineFastState.compose env58482 (packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound58482 : packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS < 2^1333 := by decide +kernel

def env58483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8352,8494,4605,262144,1024,8352,13476,32,270080,269927,8329,270161,8137,4176,4524,2341,269289,9632,257,277324,4604,512]

theorem envBound58483 : H12AffineFastState.Bounded env58483 := by
  intro p hp
  have h : env58483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58482_58483 : H12AffineEnvironment.transform 14 8352 env58482 = env58483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env58482 == env58483) = true)

def env58484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1448,1062,4605,262144,1024,1448,4524,32,270080,269927,1409,270161,8137,4176,4524,2341,269289,168,257,269892,4604,512]

theorem envBound58484 : H12AffineFastState.Bounded env58484 := by
  intro p hp
  have h : env58484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58483_58484 : H12AffineEnvironment.transform 12 1288 env58483 = env58484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env58483 == env58484) = true)

theorem identity58484 : scanCanonicalize (H12AffineFastState.compose env58484 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound58484 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,1288,4176,1448,1062,4605,262144,1024,1448,4524,32,266251,266604,1409,266330,4290,4176,4524,1582,267490,168,257,266575,4604,512]

theorem envBound58485 : H12AffineFastState.Bounded env58485 := by
  intro p hp
  have h : env58485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58484_58485 : H12AffineEnvironment.transform 10 1803 env58484 = env58485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env58484 == env58485) = true)

def env58486 : List Nat := [2,4,8,16,32,64,128,256,512,84,863,4096,348,4176,508,114,4605,262144,84,508,4524,32,266251,266604,469,266330,4290,4176,4524,634,266422,168,257,266575,4604,512]

theorem envBound58486 : H12AffineFastState.Bounded env58486 := by
  intro p hp
  have h : env58486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58485_58486 : H12AffineEnvironment.transform 9 84 env58485 = env58486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58485 == env58486) = true)

def env58487 : List Nat := [2,4,8,16,32,64,88,256,512,84,863,4096,348,4176,292,114,4389,262144,84,292,4468,32,266251,266604,269,266330,4122,4176,4468,634,266350,112,257,266575,4388,512]

theorem envBound58487 : H12AffineFastState.Bounded env58487 := by
  intro p hp
  have h : env58487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58486_58487 : H12AffineEnvironment.transform 6 88 env58486 = env58487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58486 == env58487) = true)

theorem identity58487 : scanCanonicalize (H12AffineFastState.compose env58487 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 609) := by decide +kernel

theorem selectedBound58487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58488 : List Nat := [2,4,8,16,32,64,88,256,512,84,863,4096,348,4176,292,114,4389,609,84,292,4468,32,4714,4877,269,4667,4122,4176,4468,634,4623,112,257,4910,4388,512]

theorem envBound58488 : H12AffineFastState.Bounded env58488 := by
  intro p hp
  have h : env58488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58487_58488 : H12AffineEnvironment.transform 17 609 env58487 = env58488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 609 env58487 == env58488) = true)

theorem identity58488 : scanCanonicalize (H12AffineFastState.compose env58488 (packedSelected [3,7,9,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 805) := by decide +kernel

theorem selectedBound58488 : packedSelected [3,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58489 : List Nat := [2,4,8,16,32,64,88,256,512,84,863,805,348,885,292,114,512,609,84,292,593,32,335,40,269,286,831,885,593,634,298,112,257,11,513,512]

theorem envBound58489 : H12AffineFastState.Bounded env58489 := by
  intro p hp
  have h : env58489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58488_58489 : H12AffineEnvironment.transform 11 805 env58488 = env58489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 805 env58488 == env58489) = true)

theorem identity58489 : scanCanonicalize (H12AffineFastState.compose env58489 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58489 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env58490 : List Nat := [2,4,8,16,10,64,88,256,512,84,863,783,348,863,270,88,512,587,84,270,593,10,335,2,269,286,789,863,593,592,256,90,257,11,513,512]

theorem envBound58490 : H12AffineFastState.Bounded env58490 := by
  intro p hp
  have h : env58490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58489_58490 : H12AffineEnvironment.transform 4 10 env58489 = env58490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58489 == env58490) = true)

theorem identity58490 : scanCanonicalize (H12AffineFastState.compose env58490 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound58490 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env58491 : List Nat := [2,4,8,16,10,64,88,94,512,84,513,593,2,513,80,88,512,587,84,80,593,10,17,2,83,64,587,513,593,592,94,90,95,11,513,512]

theorem envBound58491 : H12AffineFastState.Bounded env58491 := by
  intro p hp
  have h : env58491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58490_58491 : H12AffineEnvironment.transform 7 94 env58490 = env58491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env58490 == env58491) = true)

theorem identity58491 : scanCanonicalize (H12AffineFastState.compose env58491 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58491 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env58492 : List Nat := [2,4,8,16,10,16,8,14,512,4,513,513,2,513,0,8,512,539,4,0,513,10,17,2,3,16,539,513,513,512,14,10,15,11,513,512]

theorem envBound58492 : H12AffineFastState.Bounded env58492 := by
  intro p hp
  have h : env58492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58491_58492 : H12AffineEnvironment.transform 5 16 env58491 = env58492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58491 == env58492) = true)

theorem identity58492 : scanCanonicalize (H12AffineFastState.compose env58492 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58493 : List Nat := [2,4,8,10,10,10,8,14,512,4,513,513,2,513,0,8,512,513,4,0,513,10,11,2,3,10,513,513,513,512,14,10,15,11,513,512]

theorem envBound58493 : H12AffineFastState.Bounded env58493 := by
  intro p hp
  have h : env58493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58492_58493 : H12AffineEnvironment.transform 3 10 env58492 = env58493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58492 == env58493) = true)

def env58494 : List Nat := [2,4,8,16,32,64,89,256,512,84,863,4096,348,4176,293,114,4388,262144,84,293,4469,32,266251,266604,268,266330,4123,4176,4469,634,266351,113,257,266575,4389,512]

theorem envBound58494 : H12AffineFastState.Bounded env58494 := by
  intro p hp
  have h : env58494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58486_58494 : H12AffineEnvironment.transform 6 89 env58486 = env58494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58486 == env58494) = true)

theorem identity58494 : scanCanonicalize (H12AffineFastState.compose env58494 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 788) := by decide +kernel

theorem selectedBound58494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58495 : List Nat := [2,4,8,16,32,64,89,256,512,84,863,4096,348,4176,293,114,4388,788,84,293,4469,32,4895,4728,268,4942,4123,4176,4469,634,4987,113,257,4699,4389,512]

theorem envBound58495 : H12AffineFastState.Bounded env58495 := by
  intro p hp
  have h : env58495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58494_58495 : H12AffineEnvironment.transform 17 788 env58494 = env58495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 788 env58494 == env58495) = true)

theorem identity58495 : scanCanonicalize (H12AffineFastState.compose env58495 (packedSelected [5,7,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound58495 : packedSelected [5,7,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58496 : List Nat := [2,4,8,16,32,64,89,256,276,84,75,4096,348,4176,293,114,4388,0,84,293,4469,32,4107,4460,268,4186,4123,4176,4469,366,4207,113,257,4431,4389,276]

theorem envBound58496 : H12AffineFastState.Bounded env58496 := by
  intro p hp
  have h : env58496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58495_58496 : H12AffineEnvironment.transform 8 276 env58495 = env58496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env58495 == env58496) = true)

theorem identity58496 : scanCanonicalize (H12AffineFastState.compose env58496 (packedSelected [0,1,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound58496 : packedSelected [0,1,4,10] rootPS < 2^1333 := by decide +kernel

def env58497 : List Nat := [2,4,8,16,32,64,89,256,276,84,75,293,348,373,293,114,1,0,84,293,80,32,302,73,268,383,318,373,80,366,330,113,257,106,0,276]

theorem envBound58497 : H12AffineFastState.Bounded env58497 := by
  intro p hp
  have h : env58497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58496_58497 : H12AffineEnvironment.transform 11 293 env58496 = env58497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env58496 == env58497) = true)

theorem identity58497 : scanCanonicalize (H12AffineFastState.compose env58497 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58497 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58498 : List Nat := [2,4,8,10,32,64,67,256,270,78,75,293,326,367,293,104,1,0,78,293,74,32,302,73,268,357,292,367,74,366,330,107,257,106,0,270]

theorem envBound58498 : H12AffineFastState.Bounded env58498 := by
  intro p hp
  have h : env58498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58497_58498 : H12AffineEnvironment.transform 3 10 env58497 = env58498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58497 == env58498) = true)

def env58499 : List Nat := [2,4,8,10,32,64,67,36,42,78,75,1,98,75,1,104,1,0,78,1,74,32,10,73,40,65,0,75,74,74,110,107,37,106,0,42]

theorem envBound58499 : H12AffineFastState.Bounded env58499 := by
  intro p hp
  have h : env58499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58498_58499 : H12AffineEnvironment.transform 7 36 env58498 = env58499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58498 == env58499) = true)

theorem identity58499 : scanCanonicalize (H12AffineFastState.compose env58499 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58500 : List Nat := [2,4,8,10,11,64,67,15,1,78,75,1,73,75,1,67,1,0,78,1,74,11,10,73,3,65,0,75,74,74,69,64,14,65,0,1]

theorem envBound58500 : H12AffineFastState.Bounded env58500 := by
  intro p hp
  have h : env58500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58499_58500 : H12AffineEnvironment.transform 4 11 env58499 = env58500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58499 == env58500) = true)

def env58501 : List Nat := [2,4,8,10,32,64,67,37,43,78,75,0,99,74,0,104,1,0,78,0,74,32,11,73,41,64,1,74,74,75,111,107,36,106,0,43]

theorem envBound58501 : H12AffineFastState.Bounded env58501 := by
  intro p hp
  have h : env58501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58498_58501 : H12AffineEnvironment.transform 7 37 env58498 = env58501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58498 == env58501) = true)

def env58502 : List Nat := [2,4,8,16,32,64,128,256,512,85,862,4096,349,4176,509,115,4605,262144,85,509,4524,32,266251,266604,468,266330,4290,4176,4524,635,266423,168,257,266575,4604,512]

theorem envBound58502 : H12AffineFastState.Bounded env58502 := by
  intro p hp
  have h : env58502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58485_58502 : H12AffineEnvironment.transform 9 85 env58485 = env58502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58485 == env58502) = true)

def env58503 : List Nat := [2,4,8,16,32,64,88,256,512,85,862,4096,349,4176,293,115,4389,262144,85,293,4468,32,266251,266604,268,266330,4122,4176,4468,635,266351,112,257,266575,4388,512]

theorem envBound58503 : H12AffineFastState.Bounded env58503 := by
  intro p hp
  have h : env58503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58502_58503 : H12AffineEnvironment.transform 6 88 env58502 = env58503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58502 == env58503) = true)

theorem identity58503 : scanCanonicalize (H12AffineFastState.compose env58503 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound58503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58504 : List Nat := [2,4,8,16,32,64,88,256,512,85,862,862,349,782,293,115,635,262144,85,293,554,32,262997,262706,268,262916,836,782,554,635,262961,112,257,262673,634,512]

theorem envBound58504 : H12AffineFastState.Bounded env58504 := by
  intro p hp
  have h : env58504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58503_58504 : H12AffineEnvironment.transform 11 862 env58503 = env58504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env58503 == env58504) = true)

theorem identity58504 : scanCanonicalize (H12AffineFastState.compose env58504 (packedSelected [0,3,4,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 539) := by decide +kernel

theorem selectedBound58504 : packedSelected [0,3,4,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58505 : List Nat := [2,4,8,16,32,64,88,256,512,85,862,862,349,782,293,115,635,539,85,293,554,32,334,41,268,287,836,782,554,635,298,112,257,10,634,512]

theorem envBound58505 : H12AffineFastState.Bounded env58505 := by
  intro p hp
  have h : env58505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58504_58505 : H12AffineEnvironment.transform 17 539 env58504 = env58505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 539 env58504 == env58505) = true)

theorem identity58505 : scanCanonicalize (H12AffineFastState.compose env58505 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58505 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env58506 : List Nat := [2,4,8,16,32,64,88,36,512,85,634,634,121,554,1,115,635,539,85,1,554,32,106,41,40,59,608,554,554,635,14,112,37,10,634,512]

theorem envBound58506 : H12AffineFastState.Bounded env58506 := by
  intro p hp
  have h : env58506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58505_58506 : H12AffineEnvironment.transform 7 36 env58505 = env58506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58505 == env58506) = true)

theorem identity58506 : scanCanonicalize (H12AffineFastState.compose env58506 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound58506 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env58507 : List Nat := [2,4,8,16,32,59,35,36,512,46,513,513,2,554,1,8,512,539,46,1,554,32,17,41,40,59,539,554,554,512,14,11,37,10,513,512]

theorem envBound58507 : H12AffineFastState.Bounded env58507 := by
  intro p hp
  have h : env58507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58506_58507 : H12AffineEnvironment.transform 5 59 env58506 = env58507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env58506 == env58507) = true)

theorem identity58507 : scanCanonicalize (H12AffineFastState.compose env58507 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58507 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58508 : List Nat := [2,4,8,16,11,16,8,15,512,5,513,513,2,513,1,8,512,539,5,1,513,11,17,2,3,16,539,513,513,512,14,11,14,10,513,512]

theorem envBound58508 : H12AffineFastState.Bounded env58508 := by
  intro p hp
  have h : env58508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58507_58508 : H12AffineEnvironment.transform 4 11 env58507 = env58508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58507 == env58508) = true)

theorem identity58508 : scanCanonicalize (H12AffineFastState.compose env58508 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58508 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58509 : List Nat := [2,4,8,11,11,11,8,15,512,5,513,513,2,513,1,8,512,512,5,1,513,11,10,2,3,11,512,513,513,512,14,11,14,10,513,512]

theorem envBound58509 : H12AffineFastState.Bounded env58509 := by
  intro p hp
  have h : env58509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58508_58509 : H12AffineEnvironment.transform 3 11 env58508 = env58509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58508 == env58509) = true)

theorem identity58509 : scanCanonicalize (H12AffineFastState.compose env58509 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58509 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58510 : List Nat := [2,4,8,11,11,11,8,15,1,5,0,0,2,0,1,8,1,1,5,1,0,11,10,2,3,11,1,0,0,1,14,11,14,10,0,1]

theorem envBound58510 : H12AffineFastState.Bounded env58510 := by
  intro p hp
  have h : env58510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58509_58510 : H12AffineEnvironment.transform 8 1 env58509 = env58510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58509 == env58510) = true)

def env58511 : List Nat := [2,4,8,16,32,64,89,256,512,85,862,4096,349,4176,292,115,4388,262144,85,292,4469,32,266251,266604,269,266330,4123,4176,4469,635,266350,113,257,266575,4389,512]

theorem envBound58511 : H12AffineFastState.Bounded env58511 := by
  intro p hp
  have h : env58511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58502_58511 : H12AffineEnvironment.transform 6 89 env58502 = env58511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58502 == env58511) = true)

theorem identity58511 : scanCanonicalize (H12AffineFastState.compose env58511 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound58511 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58512 : List Nat := [2,4,8,16,32,64,89,256,512,85,862,554,349,634,292,115,782,262144,85,292,863,32,262689,262982,269,262768,561,634,863,635,262724,113,257,263013,783,512]

theorem envBound58512 : H12AffineFastState.Bounded env58512 := by
  intro p hp
  have h : env58512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58511_58512 : H12AffineEnvironment.transform 11 554 env58511 = env58512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env58511 == env58512) = true)

theorem identity58512 : scanCanonicalize (H12AffineFastState.compose env58512 (packedSelected [0,4,5,10,11,13] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound58512 : packedSelected [0,4,5,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58513 : List Nat := [2,4,8,16,32,64,89,256,512,85,862,554,349,634,292,115,782,0,85,292,863,32,545,838,269,624,561,634,863,635,580,113,257,869,783,512]

theorem envBound58513 : H12AffineFastState.Bounded env58513 := by
  intro p hp
  have h : env58513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58512_58513 : H12AffineEnvironment.transform 17 0 env58512 = env58513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env58512 == env58513) = true)

theorem identity58513 : scanCanonicalize (H12AffineFastState.compose env58513 (packedSelected [0,1,4,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58513 : packedSelected [0,1,4,10] rootPS < 2^1333 := by decide +kernel

def env58514 : List Nat := [2,4,8,10,32,64,67,256,512,79,836,554,327,608,292,105,782,0,79,292,837,32,545,838,269,618,555,608,837,609,580,107,257,869,783,512]

theorem envBound58514 : H12AffineFastState.Bounded env58514 := by
  intro p hp
  have h : env58514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58513_58514 : H12AffineEnvironment.transform 3 10 env58513 = env58514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58513 == env58514) = true)

theorem identity58514 : scanCanonicalize (H12AffineFastState.compose env58514 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound58514 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58515 : List Nat := [2,4,8,10,32,64,67,256,271,79,75,293,327,367,292,105,1,0,79,292,74,32,302,73,269,357,292,367,74,366,331,107,257,106,0,271]

theorem envBound58515 : H12AffineFastState.Bounded env58515 := by
  intro p hp
  have h : env58515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58514_58515 : H12AffineEnvironment.transform 8 271 env58514 = env58515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env58514 == env58515) = true)

def env58516 : List Nat := [2,4,8,10,32,64,67,36,43,79,75,1,99,75,0,105,1,0,79,0,74,32,10,73,41,65,0,75,74,74,111,107,37,106,0,43]

theorem envBound58516 : H12AffineFastState.Bounded env58516 := by
  intro p hp
  have h : env58516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58515_58516 : H12AffineEnvironment.transform 7 36 env58515 = env58516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58515 == env58516) = true)

theorem identity58516 : scanCanonicalize (H12AffineFastState.compose env58516 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58516 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58517 : List Nat := [2,4,8,10,11,64,67,15,0,79,75,1,72,75,0,66,1,0,79,0,74,11,10,73,2,65,0,75,74,74,68,64,14,65,0,0]

theorem envBound58517 : H12AffineFastState.Bounded env58517 := by
  intro p hp
  have h : env58517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58516_58517 : H12AffineEnvironment.transform 4 11 env58516 = env58517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58516 == env58517) = true)

def env58518 : List Nat := [2,4,8,10,32,64,67,37,42,79,75,0,98,74,1,105,1,0,79,1,74,32,11,73,40,64,1,74,74,75,110,107,36,106,0,42]

theorem envBound58518 : H12AffineFastState.Bounded env58518 := by
  intro p hp
  have h : env58518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58515_58518 : H12AffineEnvironment.transform 7 37 env58515 = env58518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58515 == env58518) = true)

def env58519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1449,1063,4605,262144,1024,1449,4525,32,270080,269927,1408,270161,8137,4176,4524,2341,269289,169,257,269893,4604,512]

theorem envBound58519 : H12AffineFastState.Bounded env58519 := by
  intro p hp
  have h : env58519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58483_58519 : H12AffineEnvironment.transform 12 1289 env58483 = env58519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env58483 == env58519) = true)

theorem identity58519 : scanCanonicalize (H12AffineFastState.compose env58519 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4583) := by decide +kernel

theorem selectedBound58519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1449,1063,4605,4583,1024,1449,4525,32,3815,3968,1408,3766,8137,4176,4524,2341,2574,169,257,4002,4604,512]

theorem envBound58520 : H12AffineFastState.Bounded env58520 := by
  intro p hp
  have h : env58520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58519_58520 : H12AffineEnvironment.transform 17 4583 env58519 = env58520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4583 env58519 == env58520) = true)

def env58521 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,349,4176,509,115,4605,4583,84,509,4525,32,2739,3028,468,2786,7069,4176,4524,2341,2574,169,257,3062,4604,512]

theorem envBound58521 : H12AffineFastState.Bounded env58521 := by
  intro p hp
  have h : env58521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58520_58521 : H12AffineEnvironment.transform 9 84 env58520 = env58521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58520 == env58521) = true)

def env58522 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,4096,349,4176,293,115,4389,4415,84,293,4469,32,2667,2828,268,2618,6981,4176,4468,2341,2574,113,257,2862,4388,512]

theorem envBound58522 : H12AffineFastState.Bounded env58522 := by
  intro p hp
  have h : env58522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58521_58522 : H12AffineEnvironment.transform 6 88 env58521 = env58522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58521 == env58522) = true)

theorem identity58522 : scanCanonicalize (H12AffineFastState.compose env58522 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound58522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58523 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,2049,349,2129,293,115,2340,2366,84,293,2420,32,2667,2828,268,2618,836,2129,2421,2341,2574,113,257,2862,2341,512]

theorem envBound58523 : H12AffineFastState.Bounded env58523 := by
  intro p hp
  have h : env58523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58522_58523 : H12AffineEnvironment.transform 11 2049 env58522 = env58523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env58522 == env58523) = true)

theorem identity58523 : scanCanonicalize (H12AffineFastState.compose env58523 (packedSelected [0,3,4,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58523 : packedSelected [0,3,4,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58524 : List Nat := [2,4,8,16,32,64,88,117,512,84,2048,2049,40,2129,80,115,2129,2123,84,80,2049,32,2667,2681,121,2618,561,2129,2048,2128,2574,113,116,2651,2128,512]

theorem envBound58524 : H12AffineFastState.Bounded env58524 := by
  intro p hp
  have h : env58524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58523_58524 : H12AffineEnvironment.transform 7 117 env58523 = env58524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58523 == env58524) = true)

theorem identity58524 : scanCanonicalize (H12AffineFastState.compose env58524 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound58524 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env58525 : List Nat := [2,4,8,16,32,64,88,117,512,84,513,512,40,592,80,115,592,586,84,80,512,32,106,120,121,59,561,592,513,593,15,113,116,90,593,512]

theorem envBound58525 : H12AffineFastState.Bounded env58525 := by
  intro p hp
  have h : env58525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58524_58525 : H12AffineEnvironment.transform 10 513 env58524 = env58525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58524 == env58525) = true)

theorem identity58525 : scanCanonicalize (H12AffineFastState.compose env58525 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58525 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58526 : List Nat := [2,4,8,11,32,64,67,110,512,79,513,512,40,587,75,104,587,586,79,75,512,32,106,99,98,32,554,587,513,586,15,106,111,65,586,512]

theorem envBound58526 : H12AffineFastState.Bounded env58526 := by
  intro p hp
  have h : env58526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58525_58526 : H12AffineEnvironment.transform 3 11 env58525 = env58526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58525 == env58526) = true)

theorem identity58526 : scanCanonicalize (H12AffineFastState.compose env58526 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound58526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58527 : List Nat := [2,4,8,11,32,32,35,14,512,47,513,512,40,555,43,8,555,554,47,43,512,32,10,3,2,32,554,555,513,554,15,10,15,33,554,512]

theorem envBound58527 : H12AffineFastState.Bounded env58527 := by
  intro p hp
  have h : env58527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58526_58527 : H12AffineEnvironment.transform 5 32 env58526 = env58527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58526 == env58527) = true)

theorem identity58527 : scanCanonicalize (H12AffineFastState.compose env58527 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58528 : List Nat := [2,4,8,11,11,11,8,14,512,4,513,512,3,512,0,8,512,513,4,0,512,11,10,3,2,11,513,512,513,513,15,10,15,10,513,512]

theorem envBound58528 : H12AffineFastState.Bounded env58528 := by
  intro p hp
  have h : env58528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58527_58528 : H12AffineEnvironment.transform 4 11 env58527 = env58528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58527 == env58528) = true)

theorem identity58528 : scanCanonicalize (H12AffineFastState.compose env58528 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58528 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58529 : List Nat := [2,4,8,11,11,11,8,14,1,4,0,1,3,1,0,8,1,0,4,0,1,11,10,3,2,11,0,1,0,0,15,10,15,10,0,1]

theorem envBound58529 : H12AffineFastState.Bounded env58529 := by
  intro p hp
  have h : env58529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58528_58529 : H12AffineEnvironment.transform 8 1 env58528 = env58529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58528 == env58529) = true)

def env58530 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,4096,349,4176,292,115,4388,4414,84,292,4468,32,2666,2829,269,2619,6980,4176,4469,2341,2574,112,257,2863,4389,512]

theorem envBound58530 : H12AffineFastState.Bounded env58530 := by
  intro p hp
  have h : env58530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58521_58530 : H12AffineEnvironment.transform 6 89 env58521 = env58530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58521 == env58530) = true)

theorem identity58530 : scanCanonicalize (H12AffineFastState.compose env58530 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2421) := by decide +kernel

theorem selectedBound58530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58531 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,2421,349,2341,292,115,2129,2123,84,292,2049,32,2666,2829,269,2619,561,2341,2048,2341,2574,112,257,2863,2128,512]

theorem envBound58531 : H12AffineFastState.Bounded env58531 := by
  intro p hp
  have h : env58531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58530_58531 : H12AffineEnvironment.transform 11 2421 env58530 = env58531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2421 env58530 == env58531) = true)

theorem identity58531 : scanCanonicalize (H12AffineFastState.compose env58531 (packedSelected [0,4,5,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound58531 : packedSelected [0,4,5,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58532 : List Nat := [2,4,8,16,32,64,89,256,512,84,325,48,349,96,292,115,276,270,84,292,324,32,815,584,269,894,561,96,325,96,843,112,257,618,277,512]

theorem envBound58532 : H12AffineFastState.Bounded env58532 := by
  intro p hp
  have h : env58532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58531_58532 : H12AffineEnvironment.transform 10 325 env58531 = env58532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env58531 == env58532) = true)

theorem identity58532 : scanCanonicalize (H12AffineFastState.compose env58532 (packedSelected [1,7,9,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58532 : packedSelected [1,7,9,18] rootPS < 2^1333 := by decide +kernel

def env58533 : List Nat := [2,4,8,10,32,64,67,256,512,78,325,42,327,96,292,105,270,270,78,292,324,32,815,584,269,868,555,96,325,96,843,106,257,618,271,512]

theorem envBound58533 : H12AffineFastState.Bounded env58533 := by
  intro p hp
  have h : env58533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58532_58533 : H12AffineEnvironment.transform 3 10 env58532 = env58533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58532 == env58533) = true)

theorem identity58533 : scanCanonicalize (H12AffineFastState.compose env58533 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58533 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58534 : List Nat := [2,4,8,10,32,64,67,256,1,78,325,42,327,96,292,105,270,270,78,292,324,32,302,73,269,357,42,96,325,96,330,106,257,107,271,1]

theorem envBound58534 : H12AffineFastState.Bounded env58534 := by
  intro p hp
  have h : env58534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58533_58534 : H12AffineEnvironment.transform 8 1 env58533 = env58534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58533 == env58534) = true)

def env58535 : List Nat := [2,4,8,10,32,64,67,36,1,78,97,42,99,96,0,105,42,42,78,0,96,32,10,73,41,65,42,96,97,96,110,106,37,107,43,1]

theorem envBound58535 : H12AffineFastState.Bounded env58535 := by
  intro p hp
  have h : env58535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58534_58535 : H12AffineEnvironment.transform 7 36 env58534 = env58535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58534 == env58535) = true)

def env58536 : List Nat := [2,4,8,10,32,64,67,37,1,78,96,42,98,96,1,105,43,43,78,1,97,32,11,73,40,64,42,96,96,96,111,106,36,107,42,1]

theorem envBound58536 : H12AffineFastState.Bounded env58536 := by
  intro p hp
  have h : env58536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58534_58536 : H12AffineEnvironment.transform 7 37 env58534 = env58536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58534 == env58536) = true)

theorem identity58536 : scanCanonicalize (H12AffineFastState.compose env58536 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58537 : List Nat := [2,4,8,10,11,64,67,14,1,78,75,1,73,75,1,66,0,0,78,1,74,11,11,73,3,64,1,75,75,75,68,65,15,64,1,1]

theorem envBound58537 : H12AffineFastState.Bounded env58537 := by
  intro p hp
  have h : env58537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58536_58537 : H12AffineEnvironment.transform 4 11 env58536 = env58537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58536 == env58537) = true)

def env58538 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,348,4176,508,114,4605,4583,85,508,4525,32,2738,3029,469,2787,7068,4176,4524,2341,2574,169,257,3063,4604,512]

theorem envBound58538 : H12AffineFastState.Bounded env58538 := by
  intro p hp
  have h : env58538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58520_58538 : H12AffineEnvironment.transform 9 85 env58520 = env58538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58520 == env58538) = true)

def env58539 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,4096,348,4176,292,114,4389,4415,85,292,4469,32,2666,2829,269,2619,6980,4176,4468,2341,2574,113,257,2863,4388,512]

theorem envBound58539 : H12AffineFastState.Bounded env58539 := by
  intro p hp
  have h : env58539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58538_58539 : H12AffineEnvironment.transform 6 88 env58538 = env58539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58538 == env58539) = true)

theorem identity58539 : scanCanonicalize (H12AffineFastState.compose env58539 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound58539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58540 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,862,348,782,292,114,635,609,85,292,555,32,2666,2829,269,2619,2074,782,554,2341,2574,113,257,2863,634,512]

theorem envBound58540 : H12AffineFastState.Bounded env58540 := by
  intro p hp
  have h : env58540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58539_58540 : H12AffineEnvironment.transform 11 862 env58539 = env58540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env58539 == env58540) = true)

theorem identity58540 : scanCanonicalize (H12AffineFastState.compose env58540 (packedSelected [3,7,9,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound58540 : packedSelected [3,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58541 : List Nat := [2,4,8,16,32,64,88,116,512,85,2048,554,40,634,80,114,635,609,85,80,555,32,2666,2681,121,2619,2074,634,554,2129,2574,113,117,2651,634,512]

theorem envBound58541 : H12AffineFastState.Bounded env58541 := by
  intro p hp
  have h : env58541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58540_58541 : H12AffineEnvironment.transform 7 116 env58540 = env58541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env58540 == env58541) = true)

theorem identity58541 : scanCanonicalize (H12AffineFastState.compose env58541 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58541 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env58542 : List Nat := [2,4,8,16,32,17,9,37,512,4,2048,554,40,555,1,35,554,560,4,1,555,32,2619,2600,40,2619,2074,555,554,2048,2574,32,36,2570,555,512]

theorem envBound58542 : H12AffineFastState.Bounded env58542 := by
  intro p hp
  have h : env58542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58541_58542 : H12AffineEnvironment.transform 5 17 env58541 = env58542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58541 == env58542) = true)

theorem identity58542 : scanCanonicalize (H12AffineFastState.compose env58542 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58542 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env58543 : List Nat := [2,4,8,16,16,17,9,21,512,4,2048,538,24,539,1,19,538,512,4,1,539,16,2571,2584,24,2571,2074,539,538,2048,2574,16,20,2570,539,512]

theorem envBound58543 : H12AffineFastState.Bounded env58543 := by
  intro p hp
  have h : env58543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58542_58543 : H12AffineEnvironment.transform 4 16 env58542 = env58543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58542 == env58543) = true)

theorem identity58543 : scanCanonicalize (H12AffineFastState.compose env58543 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58543 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env58544 : List Nat := [2,4,8,10,10,11,9,15,512,4,2048,512,2,513,1,9,512,512,4,1,513,10,2571,2562,2,2571,2048,513,512,2048,2574,10,14,2570,513,512]

theorem envBound58544 : H12AffineFastState.Bounded env58544 := by
  intro p hp
  have h : env58544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58543_58544 : H12AffineEnvironment.transform 3 10 env58543 = env58544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58543 == env58544) = true)

theorem identity58544 : scanCanonicalize (H12AffineFastState.compose env58544 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound58544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58545 : List Nat := [2,4,8,10,10,11,9,15,512,4,513,512,2,513,1,9,512,512,4,1,513,10,10,3,2,10,513,513,512,513,15,10,14,11,513,512]

theorem envBound58545 : H12AffineFastState.Bounded env58545 := by
  intro p hp
  have h : env58545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58544_58545 : H12AffineEnvironment.transform 10 513 env58544 = env58545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env58544 == env58545) = true)

def env58546 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,4096,348,4176,293,114,4388,4414,85,293,4468,32,2667,2828,268,2618,6981,4176,4469,2341,2574,112,257,2862,4389,512]

theorem envBound58546 : H12AffineFastState.Bounded env58546 := by
  intro p hp
  have h : env58546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58538_58546 : H12AffineEnvironment.transform 6 89 env58538 = env58546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58538 == env58546) = true)

theorem identity58546 : scanCanonicalize (H12AffineFastState.compose env58546 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound58546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58547 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,554,348,634,293,114,782,788,85,293,862,32,2667,2828,268,2618,2415,634,863,2341,2574,112,257,2862,783,512]

theorem envBound58547 : H12AffineFastState.Bounded env58547 := by
  intro p hp
  have h : env58547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58546_58547 : H12AffineEnvironment.transform 11 554 env58546 = env58547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env58546 == env58547) = true)

theorem identity58547 : scanCanonicalize (H12AffineFastState.compose env58547 (packedSelected [5,7,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58547 : packedSelected [5,7,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58548 : List Nat := [2,4,8,16,32,64,89,256,26,85,2048,48,348,96,293,114,276,270,85,293,324,32,2161,2326,268,2080,2415,96,325,2341,2068,112,257,2356,277,26]

theorem envBound58548 : H12AffineFastState.Bounded env58548 := by
  intro p hp
  have h : env58548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58547_58548 : H12AffineEnvironment.transform 8 26 env58547 = env58548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58547 == env58548) = true)

theorem identity58548 : scanCanonicalize (H12AffineFastState.compose env58548 (packedSelected [0,4,5,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound58548 : packedSelected [0,4,5,11,12] rootPS < 2^1333 := by decide +kernel

def env58549 : List Nat := [2,4,8,16,32,64,89,256,26,85,351,48,348,96,293,114,276,270,85,293,324,32,302,73,268,383,48,96,325,122,331,112,257,107,277,26]

theorem envBound58549 : H12AffineFastState.Bounded env58549 := by
  intro p hp
  have h : env58549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58548_58549 : H12AffineEnvironment.transform 10 351 env58548 = env58549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env58548 == env58549) = true)

theorem identity58549 : scanCanonicalize (H12AffineFastState.compose env58549 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58549 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58550 : List Nat := [2,4,8,10,32,64,67,256,0,79,325,42,326,96,293,104,270,270,79,293,324,32,302,73,268,357,42,96,325,96,331,106,257,107,271,0]

theorem envBound58550 : H12AffineFastState.Bounded env58550 := by
  intro p hp
  have h : env58550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58549_58550 : H12AffineEnvironment.transform 3 10 env58549 = env58550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58549 == env58550) = true)

def env58551 : List Nat := [2,4,8,10,32,64,67,36,0,79,97,42,98,96,1,104,42,42,79,1,96,32,10,73,40,65,42,96,97,96,111,106,37,107,43,0]

theorem envBound58551 : H12AffineFastState.Bounded env58551 := by
  intro p hp
  have h : env58551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58550_58551 : H12AffineEnvironment.transform 7 36 env58550 = env58551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58550 == env58551) = true)

def env58552 : List Nat := [2,4,8,10,32,64,67,37,0,79,96,42,99,96,0,104,43,43,79,0,97,32,11,73,41,64,42,96,96,96,110,106,36,107,42,0]

theorem envBound58552 : H12AffineFastState.Bounded env58552 := by
  intro p hp
  have h : env58552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58550_58552 : H12AffineEnvironment.transform 7 37 env58550 = env58552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58550 == env58552) = true)

theorem identity58552 : scanCanonicalize (H12AffineFastState.compose env58552 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58553 : List Nat := [2,4,8,10,11,64,67,14,0,79,75,1,72,75,0,67,0,0,79,0,74,11,11,73,2,64,1,75,75,75,69,65,15,64,1,0]

theorem envBound58553 : H12AffineFastState.Bounded env58553 := by
  intro p hp
  have h : env58553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58552_58553 : H12AffineEnvironment.transform 4 11 env58552 = env58553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58552 == env58553) = true)

def env58554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388688,134217728,4177,77954,4294794,8463815,2101509,257,14725224,78034,33563273]

theorem envBound58554 : H12AffineFastState.Bounded env58554 := by
  intro p hp
  have h : env58554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58257_58554 : H12AffineEnvironment.transform 13 4177 env58257 = env58554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58257 == env58554) = true)

theorem identity58554 : scanCanonicalize (H12AffineFastState.compose env58554 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58554 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388688,134217728,4177,77954,4294794,8463815,2101509,257,14725224,78034,513]

theorem envBound58555 : H12AffineFastState.Bounded env58555 := by
  intro p hp
  have h : env58555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58554_58555 : H12AffineEnvironment.transform 24 8328 env58554 = env58555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58554 == env58555) = true)

theorem identity58555 : scanCanonicalize (H12AffineFastState.compose env58555 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound58555 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388688,8724554,4177,77954,4294794,8463815,2101509,257,14725224,78034,513]

theorem envBound58556 : H12AffineFastState.Bounded env58556 := by
  intro p hp
  have h : env58556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58555_58556 : H12AffineEnvironment.transform 26 8724554 env58555 = env58556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env58555 == env58556) = true)

theorem identity58556 : scanCanonicalize (H12AffineFastState.compose env58556 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound58556 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,4097,4194304,8388608,8430023,8328,8388688,8724554,4177,77954,4294794,8463815,260,257,12623977,78034,513]

theorem envBound58557 : H12AffineFastState.Bounded env58557 := by
  intro p hp
  have h : env58557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58556_58557 : H12AffineEnvironment.transform 20 4097 env58556 = env58557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env58556 == env58557) = true)

theorem identity58557 : scanCanonicalize (H12AffineFastState.compose env58557 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4292675) := by decide +kernel

theorem selectedBound58557 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,4097,4194304,4292675,4268420,8328,4292627,4497417,4177,77954,4294794,4236676,260,257,73770,78034,513]

theorem envBound58558 : H12AffineFastState.Bounded env58558 := by
  intro p hp
  have h : env58558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58557_58558 : H12AffineEnvironment.transform 22 4292675 env58557 = env58558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292675 env58557 == env58558) = true)

theorem identity58558 : scanCanonicalize (H12AffineFastState.compose env58558 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound58558 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,4097,396,98767,73736,8328,98719,303493,4177,77954,100614,41992,260,257,73770,78034,513]

theorem envBound58559 : H12AffineFastState.Bounded env58559 := by
  intro p hp
  have h : env58559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58558_58559 : H12AffineEnvironment.transform 21 396 env58558 = env58559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env58558 == env58559) = true)

theorem identity58559 : scanCanonicalize (H12AffineFastState.compose env58559 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound58559 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,8282,4233,262144,1024,32768,4097,396,41365,82,8328,41413,303493,4177,4312,43356,41992,260,257,112,4232,513]

theorem envBound58560 : H12AffineFastState.Bounded env58560 := by
  intro p hp
  have h : env58560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58559_58560 : H12AffineEnvironment.transform 15 8282 env58559 = env58560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env58559 == env58560) = true)

theorem identity58560 : scanCanonicalize (H12AffineFastState.compose env58560 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8433) := by decide +kernel

theorem selectedBound58560 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8433,8282,4233,262144,1024,8433,4097,396,356,82,8328,308,262516,4177,4312,2477,1273,260,257,112,4232,513]

theorem envBound58561 : H12AffineFastState.Bounded env58561 := by
  intro p hp
  have h : env58561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58560_58561 : H12AffineEnvironment.transform 14 8433 env58560 = env58561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env58560 == env58561) = true)

theorem identity58561 : scanCanonicalize (H12AffineFastState.compose env58561 (packedSelected [2,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound58561 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env58562 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4177,8433,8282,4233,262144,1024,8433,4097,112,152,82,8328,200,262280,4177,4312,2129,1273,248,253,112,4232,513]

theorem envBound58562 : H12AffineFastState.Bounded env58562 := by
  intro p hp
  have h : env58562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58561_58562 : H12AffineEnvironment.transform 7 252 env58561 = env58562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env58561 == env58562) = true)

theorem identity58562 : scanCanonicalize (H12AffineFastState.compose env58562 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58562 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58563 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8,4177,249,82,4233,262144,1024,249,4097,112,152,82,128,200,262280,4177,4312,2129,1273,248,253,112,4232,513]

theorem envBound58563 : H12AffineFastState.Bounded env58563 := by
  intro p hp
  have h : env58563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58562_58563 : H12AffineEnvironment.transform 12 8 env58562 = env58563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58562 == env58563) = true)

theorem identity58563 : scanCanonicalize (H12AffineFastState.compose env58563 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound58563 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58564 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,577,8,528,249,82,712,262144,1024,249,576,112,152,82,128,200,262280,528,665,2129,1273,248,253,112,713,513]

theorem envBound58564 : H12AffineFastState.Bounded env58564 := by
  intro p hp
  have h : env58564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58563_58564 : H12AffineEnvironment.transform 11 577 env58563 = env58564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env58563 == env58564) = true)

theorem identity58564 : scanCanonicalize (H12AffineFastState.compose env58564 (packedSelected [1,12,13,15,24] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound58564 : packedSelected [1,12,13,15,24] rootPS < 2^1333 := by decide +kernel

def env58565 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1702,577,8,528,249,82,712,262144,1024,249,576,112,152,82,128,200,262280,528,665,1783,1273,248,253,112,713,513]

theorem envBound58565 : H12AffineFastState.Bounded env58565 := by
  intro p hp
  have h : env58565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58564_58565 : H12AffineEnvironment.transform 10 1702 env58564 = env58565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env58564 == env58565) = true)

theorem identity58565 : scanCanonicalize (H12AffineFastState.compose env58565 (packedSelected [3,12,13,15,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound58565 : packedSelected [3,12,13,15,28] rootPS < 2^1333 := by decide +kernel

def env58566 : List Nat := [2,4,8,16,32,64,89,37,512,1024,1663,577,8,528,32,82,529,262144,1024,32,576,112,65,82,89,17,262225,528,576,1582,1056,33,36,112,528,513]

theorem envBound58566 : H12AffineFastState.Bounded env58566 := by
  intro p hp
  have h : env58566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58565_58566 : H12AffineEnvironment.transform 6 89 env58565 = env58566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58565 == env58566) = true)

theorem identity58566 : scanCanonicalize (H12AffineFastState.compose env58566 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58567 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1583,529,8,528,32,2,529,262144,1024,32,528,32,17,2,9,17,262145,528,528,1582,1056,33,36,32,528,513]

theorem envBound58567 : H12AffineFastState.Bounded env58567 := by
  intro p hp
  have h : env58567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58566_58567 : H12AffineEnvironment.transform 5 16 env58566 = env58567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58566 == env58567) = true)

theorem identity58567 : scanCanonicalize (H12AffineFastState.compose env58567 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 518) := by decide +kernel

theorem selectedBound58567 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58568 : List Nat := [2,4,8,16,32,16,9,37,512,518,41,529,8,528,32,2,529,262144,518,32,528,32,17,2,9,17,262145,528,528,40,550,33,36,32,528,513]

theorem envBound58568 : H12AffineFastState.Bounded env58568 := by
  intro p hp
  have h : env58568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58567_58568 : H12AffineEnvironment.transform 9 518 env58567 = env58568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 518 env58567 == env58568) = true)

theorem identity58568 : scanCanonicalize (H12AffineFastState.compose env58568 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound58568 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58569 : List Nat := [2,4,8,16,32,16,9,37,48,54,41,33,8,32,32,2,33,262144,54,32,32,32,17,2,9,17,262145,32,32,40,22,33,36,32,32,49]

theorem envBound58569 : H12AffineFastState.Bounded env58569 := by
  intro p hp
  have h : env58569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58568_58569 : H12AffineEnvironment.transform 8 48 env58568 = env58569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58568 == env58569) = true)

theorem identity58569 : scanCanonicalize (H12AffineFastState.compose env58569 (packedSelected [4,9] rootPS)) = affineNative (2^(17+1) ^^^ 41) := by decide +kernel

theorem selectedBound58569 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env58570 : List Nat := [2,4,8,16,32,16,9,37,48,54,41,33,8,32,32,2,33,41,54,32,32,32,17,2,9,17,40,32,32,40,22,33,36,32,32,49]

theorem envBound58570 : H12AffineFastState.Bounded env58570 := by
  intro p hp
  have h : env58570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58569_58570 : H12AffineEnvironment.transform 17 41 env58569 = env58570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41 env58569 == env58570) = true)

theorem identity58570 : scanCanonicalize (H12AffineFastState.compose env58570 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58571 : List Nat := [2,4,8,11,32,11,9,37,43,45,41,33,8,32,32,2,33,41,45,32,32,32,10,2,9,10,40,32,32,40,13,33,36,32,32,42]

theorem envBound58571 : H12AffineFastState.Bounded env58571 := by
  intro p hp
  have h : env58571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58570_58571 : H12AffineEnvironment.transform 3 11 env58570 = env58571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58570 == env58571) = true)

def env58572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131152,4315354,8463815,4294967296,256,4307611964,34359738368,33563273]

theorem envBound58572 : H12AffineFastState.Bounded env58572 := by
  intro p hp
  have h : env58572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57668_58572 : H12AffineEnvironment.transform 18 1025 env57668 = env58572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env57668 == env58572) = true)

def env58573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131152,4315354,8463815,4294967296,256,4307611964,131072,33563273]

theorem envBound58573 : H12AffineFastState.Bounded env58573 := by
  intro p hp
  have h : env58573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58572_58573 : H12AffineEnvironment.transform 34 131072 env58572 = env58573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58572 == env58573) = true)

theorem identity58573 : scanCanonicalize (H12AffineFastState.compose env58573 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 8594567) := by decide +kernel

theorem selectedBound58573 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131152,4315354,8463815,8594567,256,4445627,131072,33563273]

theorem envBound58574 : H12AffineFastState.Bounded env58574 := by
  intro p hp
  have h : env58574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58573_58574 : H12AffineEnvironment.transform 31 8594567 env58573 = env58574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8594567 env58573 == env58574) = true)

theorem identity58574 : scanCanonicalize (H12AffineFastState.compose env58574 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919239) := by decide +kernel

theorem selectedBound58574 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,12919239,16384,131152,4315354,8463815,8594567,256,4445627,131072,33563273]

theorem envBound58575 : H12AffineFastState.Bounded env58575 := by
  intro p hp
  have h : env58575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58574_58575 : H12AffineEnvironment.transform 26 12919239 env58574 = env58575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919239 env58574 == env58575) = true)

theorem identity58575 : scanCanonicalize (H12AffineFastState.compose env58575 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28888) := by decide +kernel

theorem selectedBound58575 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env58576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,28888,8409089,12919239,16384,131152,4315354,8463815,8594567,256,4445627,131072,21073]

theorem envBound58576 : H12AffineFastState.Bounded env58576 := by
  intro p hp
  have h : env58576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58575_58576 : H12AffineEnvironment.transform 24 28888 env58575 = env58576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28888 env58575 == env58576) = true)

def env58577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388689,12919239,4176,131152,4294794,8463815,8594567,256,4425195,131072,513]

theorem envBound58577 : H12AffineFastState.Bounded env58577 := by
  intro p hp
  have h : env58577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58576_58577 : H12AffineEnvironment.transform 13 4176 env58576 = env58577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58576 == env58577) = true)

theorem identity58577 : scanCanonicalize (H12AffineFastState.compose env58577 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58577 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,397,8388608,8430022,8328,8388689,8724554,4176,131152,100615,8463815,8594567,256,230502,131072,513]

theorem envBound58578 : H12AffineFastState.Bounded env58578 := by
  intro p hp
  have h : env58578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58577_58578 : H12AffineEnvironment.transform 21 397 env58577 = env58578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58577 == env58578) = true)

theorem identity58578 : scanCanonicalize (H12AffineFastState.compose env58578 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58578 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,397,8388608,8430022,8328,8388689,8724554,4176,131152,100615,8463815,8594567,256,230502,131072,513]

theorem envBound58579 : H12AffineFastState.Bounded env58579 := by
  intro p hp
  have h : env58579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58578_58579 : H12AffineEnvironment.transform 20 4096 env58578 = env58579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58578 == env58579) = true)

theorem identity58579 : scanCanonicalize (H12AffineFastState.compose env58579 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176412) := by decide +kernel

theorem selectedBound58579 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,397,176412,135386,8328,176461,495958,4176,131152,100615,234715,103835,256,230502,131072,513]

theorem envBound58580 : H12AffineFastState.Bounded env58580 := by
  intro p hp
  have h : env58580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58579_58580 : H12AffineEnvironment.transform 22 176412 env58579 = env58580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176412 env58579 == env58580) = true)

theorem identity58580 : scanCanonicalize (H12AffineFastState.compose env58580 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58580 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,131072,262144,1025,8460,4096,397,135184,135386,8328,135233,471130,4176,131152,75787,210391,78999,256,206186,131072,513]

theorem envBound58581 : H12AffineFastState.Bounded env58581 := by
  intro p hp
  have h : env58581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58580_58581 : H12AffineEnvironment.transform 14 8460 env58580 = env58581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58580 == env58581) = true)

theorem identity58581 : scanCanonicalize (H12AffineFastState.compose env58581 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58581 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,1212,262144,1025,8460,4096,397,5292,5222,8328,5373,341222,4176,1260,75787,78187,78999,256,74198,1212,513]

theorem envBound58582 : H12AffineFastState.Bounded env58582 := by
  intro p hp
  have h : env58582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58581_58582 : H12AffineEnvironment.transform 16 1212 env58581 = env58582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env58581 == env58582) = true)

theorem identity58582 : scanCanonicalize (H12AffineFastState.compose env58582 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 81127) := by decide +kernel

theorem selectedBound58582 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,1212,81127,1025,8460,4096,397,5292,5222,8328,5373,2049,4176,1260,75787,78187,78999,256,74198,1212,513]

theorem envBound58583 : H12AffineFastState.Bounded env58583 := by
  intro p hp
  have h : env58583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58582_58583 : H12AffineEnvironment.transform 17 81127 env58582 = env58583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81127 env58582 == env58583) = true)

theorem identity58583 : scanCanonicalize (H12AffineFastState.compose env58583 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58583 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58584 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4176,8352,65536,1212,81127,1025,8352,4096,33,5292,5222,8328,5373,2049,4176,1260,75787,78023,78999,172,73850,1212,513]

theorem envBound58584 : H12AffineFastState.Bounded env58584 := by
  intro p hp
  have h : env58584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58583_58584 : H12AffineEnvironment.transform 7 172 env58583 = env58584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58583 == env58584) = true)

theorem identity58584 : scanCanonicalize (H12AffineFastState.compose env58584 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound58584 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58585 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1782,4096,8192,4176,8352,65536,1212,78353,1025,8352,4096,33,5292,5222,8328,5373,1783,4176,1260,75517,78023,78999,172,73850,1212,513]

theorem envBound58585 : H12AffineFastState.Bounded env58585 := by
  intro p hp
  have h : env58585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58584_58585 : H12AffineEnvironment.transform 10 1782 env58584 = env58585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env58584 == env58585) = true)

theorem identity58585 : scanCanonicalize (H12AffineFastState.compose env58585 (packedSelected [0,2,5,6,7,8,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 1791) := by decide +kernel

theorem selectedBound58585 : packedSelected [0,2,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env58586 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1782,4096,8192,4176,8352,1791,1212,13550,1025,8352,4096,33,5292,5222,8328,5373,1783,4176,1260,8194,13880,12904,172,9861,1212,513]

theorem envBound58586 : H12AffineFastState.Bounded env58586 := by
  intro p hp
  have h : env58586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58585_58586 : H12AffineEnvironment.transform 15 1791 env58585 = env58586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1791 env58585 == env58586) = true)

theorem identity58586 : scanCanonicalize (H12AffineFastState.compose env58586 (packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58586 : packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env58587 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1782,1212,8192,1260,8352,1791,1212,8274,1025,8352,1212,33,16,218,8328,65,1783,1260,1260,8194,8836,9940,172,9861,1212,513]

theorem envBound58587 : H12AffineFastState.Bounded env58587 := by
  intro p hp
  have h : env58587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58586_58587 : H12AffineEnvironment.transform 11 1212 env58586 = env58587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env58586 == env58587) = true)

theorem identity58587 : scanCanonicalize (H12AffineFastState.compose env58587 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound58587 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58588 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1782,1212,88,1260,248,1791,1212,10,1025,248,1212,33,16,218,208,65,1783,1260,1260,90,732,1676,172,1757,1212,513]

theorem envBound58588 : H12AffineFastState.Bounded env58588 := by
  intro p hp
  have h : env58588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58587_58588 : H12AffineEnvironment.transform 12 88 env58587 = env58588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env58587 == env58588) = true)

theorem identity58588 : scanCanonicalize (H12AffineFastState.compose env58588 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 183) := by decide +kernel

theorem selectedBound58588 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58589 : List Nat := [2,4,8,16,32,64,128,172,512,183,577,11,88,91,248,584,11,10,182,248,11,33,16,218,208,65,576,91,91,90,732,571,172,618,11,513]

theorem envBound58589 : H12AffineFastState.Bounded env58589 := by
  intro p hp
  have h : env58589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58588_58589 : H12AffineEnvironment.transform 9 183 env58588 = env58589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 183 env58588 == env58589) = true)

theorem identity58589 : scanCanonicalize (H12AffineFastState.compose env58589 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58589 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env58590 : List Nat := [2,4,8,16,32,16,128,172,512,183,529,11,8,11,168,536,11,10,182,168,11,33,16,138,128,17,528,11,11,10,652,571,172,570,11,513]

theorem envBound58590 : H12AffineFastState.Bounded env58590 := by
  intro p hp
  have h : env58590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58589_58590 : H12AffineEnvironment.transform 5 16 env58589 = env58590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58589 == env58590) = true)

theorem identity58590 : scanCanonicalize (H12AffineFastState.compose env58590 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound58590 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58591 : List Nat := [2,4,8,16,32,16,128,172,147,183,130,11,8,11,168,139,11,10,182,168,11,33,16,138,128,17,131,11,11,10,31,168,172,169,11,146]

theorem envBound58591 : H12AffineFastState.Bounded env58591 := by
  intro p hp
  have h : env58591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58590_58591 : H12AffineEnvironment.transform 8 147 env58590 = env58591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env58590 == env58591) = true)

end H12CloudChart0