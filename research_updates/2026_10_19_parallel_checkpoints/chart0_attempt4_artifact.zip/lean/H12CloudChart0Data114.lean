import H12CloudChart0Data113

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound28907 : H12AffineFastState.Bounded env28907 := by
  intro p hp
  have h : env28907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28906_28907 : H12AffineEnvironment.transform 15 8322 env28906 = env28907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env28906 == env28907) = true)

theorem identity28907 : scanCanonicalize (H12AffineFastState.compose env28907 (packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound28907 : packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env28908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29829,8322,24981,10281,1024,29828,4160,21929,21825,138,8328,65,24024,16448,4177,10360,1500,32,256,21793,16384,649]

theorem envBound28908 : H12AffineFastState.Bounded env28908 := by
  intro p hp
  have h : env28908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28907_28908 : H12AffineEnvironment.transform 14 29829 env28907 = env28908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env28907 == env28908) = true)

theorem identity28908 : scanCanonicalize (H12AffineFastState.compose env28908 (packedSelected [10,11,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound28908 : packedSelected [10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env28909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21761,262,16401,2477,1024,21760,4160,21929,21825,138,268,65,24024,16448,4177,2556,1500,32,256,21793,16384,649]

theorem envBound28909 : H12AffineFastState.Bounded env28909 := by
  intro p hp
  have h : env28909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28908_28909 : H12AffineEnvironment.transform 12 388 env28908 = env28909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env28908 == env28909) = true)

theorem identity28909 : scanCanonicalize (H12AffineFastState.compose env28909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28910 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,262,16401,2477,1024,21760,4112,21929,21777,138,268,17,23944,16400,4097,2476,1420,32,256,21793,16384,649]

theorem envBound28910 : H12AffineFastState.Bounded env28910 := by
  intro p hp
  have h : env28910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28909_28910 : H12AffineEnvironment.transform 5 16 env28909 = env28910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28909 == env28910) = true)

theorem identity28910 : scanCanonicalize (H12AffineFastState.compose env28910 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28910 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28911 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,136,262,5528,2477,1024,137,4112,32,152,138,268,17,2049,5529,4097,2476,1420,32,256,168,5513,649]

theorem envBound28911 : H12AffineFastState.Bounded env28911 := by
  intro p hp
  have h : env28911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28910_28911 : H12AffineEnvironment.transform 13 5513 env28910 = env28911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28910 == env28911) = true)

def env28912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,21928,41413,73737,8328,65,43357,46276,58581,56573,1500,32,256,21793,46213,74251]

theorem envBound28912 : H12AffineFastState.Bounded env28912 := by
  intro p hp
  have h : env28912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28905_28912 : H12AffineEnvironment.transform 16 38161 env28905 = env28912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28905 == env28912) = true)

theorem identity28912 : scanCanonicalize (H12AffineFastState.compose env28912 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28912 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1024,32769,4160,21928,41413,3,8328,65,43357,46276,58581,56573,1500,32,256,21793,46213,513]

theorem envBound28913 : H12AffineFastState.Bounded env28913 := by
  intro p hp
  have h : env28913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28912_28913 : H12AffineEnvironment.transform 15 8202 env28912 = env28913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28912 == env28913) = true)

theorem identity28913 : scanCanonicalize (H12AffineFastState.compose env28913 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28913 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8202,38161,10281,1024,32769,4160,32,41413,3,8328,65,43357,46276,45405,35189,1500,32,256,169,46213,513]

theorem envBound28914 : H12AffineFastState.Bounded env28914 := by
  intro p hp
  have h : env28914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28913_28914 : H12AffineEnvironment.transform 13 5512 env28913 = env28914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28913 == env28914) = true)

theorem identity28914 : scanCanonicalize (H12AffineFastState.compose env28914 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound28914 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env28915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,32768,479,38161,2556,1024,32769,4160,32,32784,3,349,65,34952,38161,37000,35189,1500,32,256,169,38224,513]

theorem envBound28915 : H12AffineFastState.Bounded env28915 := by
  intro p hp
  have h : env28915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28914_28915 : H12AffineEnvironment.transform 12 469 env28914 = env28915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env28914 == env28915) = true)

theorem identity28915 : scanCanonicalize (H12AffineFastState.compose env28915 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound28915 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,136,479,5529,2556,1024,137,4160,32,152,3,349,65,2048,5529,4096,2557,1500,32,256,169,5592,513]

theorem envBound28916 : H12AffineFastState.Bounded env28916 := by
  intro p hp
  have h : env28916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28915_28916 : H12AffineEnvironment.transform 14 136 env28915 = env28916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env28915 == env28916) = true)

theorem identity28916 : scanCanonicalize (H12AffineFastState.compose env28916 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28916 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env28917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2421,1024,0,4160,32,17,3,349,65,2048,5392,4096,2420,1365,32,256,32,5457,513]

theorem envBound28917 : H12AffineFastState.Bounded env28917 := by
  intro p hp
  have h : env28917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28916_28917 : H12AffineEnvironment.transform 6 9 env28916 = env28917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28916 == env28917) = true)

theorem identity28917 : scanCanonicalize (H12AffineFastState.compose env28917 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1792) := by decide +kernel

theorem selectedBound28917 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1792,348,513,1,342,528,2421,1024,0,1856,32,17,3,349,65,2048,528,1792,2420,1365,32,256,32,593,513]

theorem envBound28918 : H12AffineFastState.Bounded env28918 := by
  intro p hp
  have h : env28918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28917_28918 : H12AffineEnvironment.transform 11 1792 env28917 = env28918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1792 env28917 == env28918) = true)

theorem identity28918 : scanCanonicalize (H12AffineFastState.compose env28918 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28918 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28919 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1792,269,513,1,263,528,2340,1024,0,1809,32,17,3,268,16,2048,528,1792,2341,1284,32,256,32,512,513]

theorem envBound28919 : H12AffineFastState.Bounded env28919 := by
  intro p hp
  have h : env28919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28918_28919 : H12AffineEnvironment.transform 5 17 env28918 = env28919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28918 == env28919) = true)

theorem identity28919 : scanCanonicalize (H12AffineFastState.compose env28919 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound28919 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28920 : List Nat := [2,4,8,16,32,17,9,256,512,288,2048,544,269,513,1,263,528,2340,288,0,561,32,17,3,268,16,2048,528,544,2341,36,32,256,32,512,513]

theorem envBound28920 : H12AffineFastState.Bounded env28920 := by
  intro p hp
  have h : env28920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28919_28920 : H12AffineEnvironment.transform 9 288 env28919 = env28920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env28919 == env28920) = true)

theorem identity28920 : scanCanonicalize (H12AffineFastState.compose env28920 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound28920 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28921 : List Nat := [2,4,8,16,32,17,9,256,512,288,49,544,269,513,1,263,528,277,288,0,561,32,17,3,268,16,49,528,544,276,36,32,256,32,512,513]

theorem envBound28921 : H12AffineFastState.Bounded env28921 := by
  intro p hp
  have h : env28921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28920_28921 : H12AffineEnvironment.transform 10 49 env28920 = env28921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env28920 == env28921) = true)

theorem identity28921 : scanCanonicalize (H12AffineFastState.compose env28921 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound28921 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28922 : List Nat := [2,4,8,16,32,17,9,256,17,288,49,49,269,16,1,263,1,277,288,0,32,32,17,3,268,16,49,1,49,276,36,32,256,32,17,16]

theorem envBound28922 : H12AffineFastState.Bounded env28922 := by
  intro p hp
  have h : env28922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28921_28922 : H12AffineEnvironment.transform 8 17 env28921 = env28922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env28921 == env28922) = true)

theorem identity28922 : scanCanonicalize (H12AffineFastState.compose env28922 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28922 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28923 : List Nat := [2,4,8,16,32,17,9,21,17,53,49,49,24,16,1,18,1,0,53,0,32,32,17,3,25,16,49,1,49,1,36,32,21,32,17,16]

theorem envBound28923 : H12AffineFastState.Bounded env28923 := by
  intro p hp
  have h : env28923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28922_28923 : H12AffineEnvironment.transform 7 21 env28922 = env28923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28922 == env28923) = true)

theorem identity28923 : scanCanonicalize (H12AffineFastState.compose env28923 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28923 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28924 : List Nat := [2,4,8,0,32,1,9,5,1,37,33,33,8,0,1,2,1,0,37,0,32,32,1,3,9,0,33,1,33,1,36,32,5,32,1,0]

theorem envBound28924 : H12AffineFastState.Bounded env28924 := by
  intro p hp
  have h : env28924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28923_28924 : H12AffineEnvironment.transform 3 0 env28923 = env28924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28923 == env28924) = true)

def env28925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400636,498993,8328,65,295285,395773,416237,56572,1501,272392,256,21793,46213,74250]

theorem envBound28925 : H12AffineFastState.Bounded env28925 := by
  intro p hp
  have h : env28925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28880_28925 : H12AffineEnvironment.transform 20 4161 env28880 = env28925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28880 == env28925) = true)

theorem identity28925 : scanCanonicalize (H12AffineFastState.compose env28925 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound28925 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180409,62661,95496,8328,65,158028,57796,45524,56572,1501,180273,256,21793,46213,74250]

theorem envBound28926 : H12AffineFastState.Bounded env28926 := by
  intro p hp
  have h : env28926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28925_28926 : H12AffineEnvironment.transform 17 190521 env28925 = env28926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env28925 == env28926) = true)

theorem identity28926 : scanCanonicalize (H12AffineFastState.compose env28926 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28926 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4161,180409,62661,21763,8328,65,158028,57796,45524,56572,1501,180273,256,21793,46213,513]

theorem envBound28927 : H12AffineFastState.Bounded env28927 := by
  intro p hp
  have h : env28927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28926_28927 : H12AffineEnvironment.transform 15 8203 env28926 = env28927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28926 == env28927) = true)

def env28928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound28928 : H12AffineFastState.Bounded env28928 := by
  intro p hp
  have h : env28928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28732_28928 : H12AffineEnvironment.transform 18 1025 env28732 = env28928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env28732 == env28928) = true)

theorem identity28928 : scanCanonicalize (H12AffineFastState.compose env28928 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485308) := by decide +kernel

theorem selectedBound28928 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485308,8328,65,14822460,288944,10507600,8830977,10774572,4491773,257,8661136,8702261,10833914]

theorem envBound28929 : H12AffineFastState.Bounded env28929 := by
  intro p hp
  have h : env28929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28928_28929 : H12AffineEnvironment.transform 23 2485308 env28928 = env28929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485308 env28928 == env28929) = true)

def env28930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294320,2485308,8328,65,6705548,288944,2369760,179633,2102684,4491773,257,21792,46213,2175562]

theorem envBound28930 : H12AffineFastState.Bounded env28930 := by
  intro p hp
  have h : env28930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28929_28930 : H12AffineEnvironment.transform 22 294320 env28929 = env28930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294320 env28929 == env28930) = true)

def env28931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294320,98780,8328,65,4340844,288944,17664,179633,292988,4491773,257,21792,46213,352170]

theorem envBound28931 : H12AffineFastState.Bounded env28931 := by
  intro p hp
  have h : env28931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28930_28931 : H12AffineEnvironment.transform 20 290272 env28930 = env28931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env28930 == env28931) = true)

def env28932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294320,98780,8328,65,398572,288944,17664,179633,292988,41341,257,21792,46213,352170]

theorem envBound28932 : H12AffineFastState.Bounded env28932 := by
  intro p hp
  have h : env28932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28931_28932 : H12AffineEnvironment.transform 21 272512 env28931 = env28932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28931 == env28932) = true)

def env28933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272392,294200,98644,8192,65,398436,288824,17664,179513,292988,41341,257,21792,46093,352034]

theorem envBound28933 : H12AffineFastState.Bounded env28933 := by
  intro p hp
  have h : env28933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28932_28933 : H12AffineEnvironment.transform 6 8 env28932 = env28933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28932 == env28933) = true)

theorem identity28933 : scanCanonicalize (H12AffineFastState.compose env28933 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 204083) := by decide +kernel

theorem selectedBound28933 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,204083,1025,32769,225371,210235,221195,98644,8192,65,67927,226571,17664,179513,222543,41341,257,21792,46093,147985]

theorem envBound28934 : H12AffineFastState.Bounded env28934 := by
  intro p hp
  have h : env28934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28933_28934 : H12AffineEnvironment.transform 17 204083 env28933 = env28934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204083 env28933 == env28934) = true)

theorem identity28934 : scanCanonicalize (H12AffineFastState.compose env28934 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound28934 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env28935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103495,35188,1025,32769,58396,41340,62540,98644,8192,65,67927,57676,17664,76158,61704,41341,257,21792,46093,120406]

theorem envBound28935 : H12AffineFastState.Bounded env28935 := by
  intro p hp
  have h : env28935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28934_28935 : H12AffineEnvironment.transform 16 103495 env28934 = env28935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env28934 == env28935) = true)

theorem identity28935 : scanCanonicalize (H12AffineFastState.compose env28935 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28935 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env28936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,32040,1025,29789,4160,21792,16,95496,8192,65,67927,5392,17664,76158,1364,21793,257,21792,16465,74250]

theorem envBound28936 : H12AffineFastState.Bounded env28936 := by
  intro p hp
  have h : env28936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28935_28936 : H12AffineEnvironment.transform 14 29788 env28935 = env28936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28935 == env28936) = true)

theorem identity28936 : scanCanonicalize (H12AffineFastState.compose env28936 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16400,32040,1025,29789,4160,21792,16,21763,8192,65,10588,5392,17664,2421,1364,21793,257,21792,16465,513]

theorem envBound28937 : H12AffineFastState.Bounded env28937 := by
  intro p hp
  have h : env28937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28936_28937 : H12AffineEnvironment.transform 15 8203 env28936 = env28937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28936 == env28937) = true)

theorem identity28937 : scanCanonicalize (H12AffineFastState.compose env28937 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound28937 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,20544,1047,16400,22836,1025,20545,4160,21792,16,21763,1052,65,3392,5392,17664,2421,1364,21793,257,21792,16465,513]

theorem envBound28938 : H12AffineFastState.Bounded env28938 := by
  intro p hp
  have h : env28938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28937_28938 : H12AffineEnvironment.transform 12 1052 env28937 = env28938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env28937 == env28938) = true)

theorem identity28938 : scanCanonicalize (H12AffineFastState.compose env28938 (packedSelected [0,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 7204) := by decide +kernel

theorem selectedBound28938 : packedSelected [0,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env28939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,7204,3172,1047,7220,1296,1025,3173,4160,2308,16,2343,1052,65,3392,5392,6436,2421,1364,2309,257,2308,7285,513]

theorem envBound28939 : H12AffineFastState.Bounded env28939 := by
  intro p hp
  have h : env28939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28938_28939 : H12AffineEnvironment.transform 13 7204 env28938 = env28939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7204 env28938 == env28939) = true)

theorem identity28939 : scanCanonicalize (H12AffineFastState.compose env28939 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound28939 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env28940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,65,1052,3173,3172,1047,3189,1296,1025,3173,1,2308,16,2343,1052,65,3392,1361,2405,2421,1364,2309,257,2308,3124,513]

theorem envBound28940 : H12AffineFastState.Bounded env28940 := by
  intro p hp
  have h : env28940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28939_28940 : H12AffineEnvironment.transform 11 65 env28939 = env28940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env28939 == env28940) = true)

theorem identity28940 : scanCanonicalize (H12AffineFastState.compose env28940 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound28940 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env28941 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,65,41,2128,2129,34,2112,293,52,2128,1,2308,16,2343,41,65,2421,356,2405,2421,353,2309,257,2308,2049,513]

theorem envBound28941 : H12AffineFastState.Bounded env28941 := by
  intro p hp
  have h : env28941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28940_28941 : H12AffineEnvironment.transform 9 53 env28940 = env28941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env28940 == env28941) = true)

theorem identity28941 : scanCanonicalize (H12AffineFastState.compose env28941 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28941 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28942 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,65,41,2128,2129,34,2112,1,52,2128,1,2080,16,2051,41,65,2129,64,2113,2129,69,2081,37,2080,2049,513]

theorem envBound28942 : H12AffineFastState.Bounded env28942 := by
  intro p hp
  have h : env28942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28941_28942 : H12AffineEnvironment.transform 7 36 env28941 = env28942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28941 == env28942) = true)

theorem identity28942 : scanCanonicalize (H12AffineFastState.compose env28942 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28942 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28943 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,16,41,2049,2048,34,2065,1,52,2049,1,2080,16,2051,41,16,2048,17,2064,2048,20,2081,37,2080,2049,513]

theorem envBound28943 : H12AffineFastState.Bounded env28943 := by
  intro p hp
  have h : env28943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28942_28943 : H12AffineEnvironment.transform 5 17 env28942 = env28943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28942 == env28943) = true)

theorem identity28943 : scanCanonicalize (H12AffineFastState.compose env28943 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28943 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28944 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,1,0,34,17,1,52,1,1,32,16,3,41,16,0,17,16,0,20,33,37,32,1,513]

theorem envBound28944 : H12AffineFastState.Bounded env28944 := by
  intro p hp
  have h : env28944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28943_28944 : H12AffineEnvironment.transform 10 0 env28943 = env28944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28943 == env28944) = true)

theorem identity28944 : scanCanonicalize (H12AffineFastState.compose env28944 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound28944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28945 : List Nat := [2,4,8,16,32,17,8,36,48,53,0,16,41,1,0,34,17,1,52,1,1,32,16,3,41,16,0,17,16,0,20,33,37,32,1,49]

theorem envBound28945 : H12AffineFastState.Bounded env28945 := by
  intro p hp
  have h : env28945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28944_28945 : H12AffineEnvironment.transform 8 48 env28944 = env28945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env28944 == env28945) = true)

def env28946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294201,98645,8193,65,398437,288825,17664,179512,292988,41341,257,21792,46092,352035]

theorem envBound28946 : H12AffineFastState.Bounded env28946 := by
  intro p hp
  have h : env28946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28932_28946 : H12AffineEnvironment.transform 6 9 env28932 = env28946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28932 == env28946) = true)

def env28947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,276585,272393,272441,98645,8193,65,398437,277817,4096,179512,273788,41341,257,32,46092,330275]

theorem envBound28947 : H12AffineFastState.Bounded env28947 := by
  intro p hp
  have h : env28947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28946_28947 : H12AffineEnvironment.transform 13 5376 env28946 = env28947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28946 == env28947) = true)

theorem identity28947 : scanCanonicalize (H12AffineFastState.compose env28947 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound28947 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1025,32769,77899,73771,73755,98645,8193,65,203847,79131,4096,179512,75102,41341,257,32,46092,513]

theorem envBound28948 : H12AffineFastState.Bounded env28948 := by
  intro p hp
  have h : env28948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28947_28948 : H12AffineEnvironment.transform 17 67618 env28947 = env28948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env28947 == env28948) = true)

theorem identity28948 : scanCanonicalize (H12AffineFastState.compose env28948 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28948 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67618,1025,8540,77899,73771,73755,73736,8193,65,203847,79131,4096,138341,75102,32,257,32,5457,513]

theorem envBound28949 : H12AffineFastState.Bounded env28949 := by
  intro p hp
  have h : env28949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28948_28949 : H12AffineEnvironment.transform 14 8541 env28948 = env28949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28948 == env28949) = true)

theorem identity28949 : scanCanonicalize (H12AffineFastState.compose env28949 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28949 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,131072,67618,1025,0,69911,65911,65863,65876,349,65,203847,70727,4096,138341,66562,32,257,32,5457,513]

theorem envBound28950 : H12AffineFastState.Bounded env28950 := by
  intro p hp
  have h : env28950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28949_28950 : H12AffineEnvironment.transform 12 348 env28949 = env28950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28949 == env28950) = true)

theorem identity28950 : scanCanonicalize (H12AffineFastState.compose env28950 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound28950 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env28951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,70679,67618,1025,0,69911,65911,65863,65876,349,65,2128,70727,4096,67698,66562,32,257,32,5457,513]

theorem envBound28951 : H12AffineFastState.Bounded env28951 := by
  intro p hp
  have h : env28951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28950_28951 : H12AffineEnvironment.transform 16 70679 env28950 = env28951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env28950 == env28951) = true)

theorem identity28951 : scanCanonicalize (H12AffineFastState.compose env28951 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 7538) := by decide +kernel

theorem selectedBound28951 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,7538,2405,5456,1025,0,3173,7173,7221,7206,349,65,2128,2357,4096,5376,6512,32,257,32,5457,513]

theorem envBound28952 : H12AffineFastState.Bounded env28952 := by
  intro p hp
  have h : env28952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28951_28952 : H12AffineEnvironment.transform 15 7538 env28951 = env28952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7538 env28951 == env28952) = true)

theorem identity28952 : scanCanonicalize (H12AffineFastState.compose env28952 (packedSelected [1,3,4,5,8,9,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28952 : packedSelected [1,3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env28953 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,7458,2357,5376,1025,0,3125,7173,7221,7206,269,17,2048,2357,4096,5376,6432,32,257,32,5377,513]

theorem envBound28953 : H12AffineFastState.Bounded env28953 := by
  intro p hp
  have h : env28953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28952_28953 : H12AffineEnvironment.transform 5 16 env28952 = env28953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28952 == env28953) = true)

theorem identity28953 : scanCanonicalize (H12AffineFastState.compose env28953 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound28953 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env28954 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,268,3345,1,1331,2357,3345,1025,0,3125,1044,1060,1079,269,17,2048,2357,2065,3345,305,32,257,32,3344,513]

theorem envBound28954 : H12AffineFastState.Bounded env28954 := by
  intro p hp
  have h : env28954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28953_28954 : H12AffineEnvironment.transform 11 2065 env28953 = env28954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env28953 == env28954) = true)

theorem identity28954 : scanCanonicalize (H12AffineFastState.compose env28954 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound28954 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28955 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2065,268,2340,1,262,2357,2340,52,0,2048,33,17,2,269,17,2048,2357,2065,2340,305,32,257,32,2341,513]

theorem envBound28955 : H12AffineFastState.Bounded env28955 := by
  intro p hp
  have h : env28955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28954_28955 : H12AffineEnvironment.transform 9 53 env28954 = env28955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env28954 == env28955) = true)

theorem identity28955 : scanCanonicalize (H12AffineFastState.compose env28955 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28956 : List Nat := [2,4,8,16,0,16,9,256,512,21,2048,2065,268,2308,1,262,2325,2308,20,0,2048,1,17,2,269,17,2048,2325,2065,2308,273,0,257,0,2309,513]

theorem envBound28956 : H12AffineFastState.Bounded env28956 := by
  intro p hp
  have h : env28956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28955_28956 : H12AffineEnvironment.transform 4 0 env28955 = env28956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28955 == env28956) = true)

theorem identity28956 : scanCanonicalize (H12AffineFastState.compose env28956 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound28956 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28957 : List Nat := [2,4,8,16,0,16,9,256,512,21,772,789,268,512,1,262,529,512,20,0,772,1,17,2,269,17,772,529,789,512,273,0,257,0,513,513]

theorem envBound28957 : H12AffineFastState.Bounded env28957 := by
  intro p hp
  have h : env28957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28956_28957 : H12AffineEnvironment.transform 10 772 env28956 = env28957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env28956 == env28957) = true)

theorem identity28957 : scanCanonicalize (H12AffineFastState.compose env28957 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28957 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28958 : List Nat := [2,4,8,0,0,0,9,256,512,5,772,773,268,512,1,262,513,512,4,0,772,1,1,2,269,1,772,513,773,512,257,0,257,0,513,513]

theorem envBound28958 : H12AffineFastState.Bounded env28958 := by
  intro p hp
  have h : env28958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28957_28958 : H12AffineEnvironment.transform 3 0 env28957 = env28958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28957 == env28958) = true)

theorem identity28958 : scanCanonicalize (H12AffineFastState.compose env28958 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28958 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28959 : List Nat := [2,4,8,0,0,0,9,4,512,5,512,513,8,512,1,2,513,512,4,0,512,1,1,2,9,1,512,513,513,512,5,0,5,0,513,513]

theorem envBound28959 : H12AffineFastState.Bounded env28959 := by
  intro p hp
  have h : env28959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28958_28959 : H12AffineEnvironment.transform 7 4 env28958 = env28959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28958 == env28959) = true)

theorem identity28959 : scanCanonicalize (H12AffineFastState.compose env28959 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28960 : List Nat := [2,4,8,0,0,0,9,4,1,5,1,0,8,1,1,2,0,1,4,0,1,1,1,2,9,1,1,0,0,1,5,0,5,0,0,0]

theorem envBound28960 : H12AffineFastState.Bounded env28960 := by
  intro p hp
  have h : env28960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28959_28960 : H12AffineEnvironment.transform 8 1 env28959 = env28960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28959 == env28960) = true)

def env28961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1025,32769,276584,272393,272440,98645,8193,65,398437,277816,4097,179512,273789,41341,257,33,46092,330274]

theorem envBound28961 : H12AffineFastState.Bounded env28961 := by
  intro p hp
  have h : env28961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28946_28961 : H12AffineEnvironment.transform 13 5377 env28946 = env28961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28946 == env28961) = true)

theorem identity28961 : scanCanonicalize (H12AffineFastState.compose env28961 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28961 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1025,32769,276584,272393,272440,41311,8193,65,398437,277816,4097,179512,273789,41341,257,33,46092,272936]

theorem envBound28962 : H12AffineFastState.Bounded env28962 := by
  intro p hp
  have h : env28962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28961_28962 : H12AffineEnvironment.transform 15 8202 env28961 = env28962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28961 == env28962) = true)

theorem identity28962 : scanCanonicalize (H12AffineFastState.compose env28962 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28962 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env28963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,263,131072,262144,1025,32769,268645,264452,264501,32850,268,65,398437,269365,4097,171061,265328,32880,257,33,38145,264997]

theorem envBound28963 : H12AffineFastState.Bounded env28963 := by
  intro p hp
  have h : env28963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28962_28963 : H12AffineEnvironment.transform 12 269 env28962 = env28963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28962 == env28963) = true)

theorem identity28963 : scanCanonicalize (H12AffineFastState.compose env28963 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 38208) := by decide +kernel

theorem selectedBound28963 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env28964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,263,38208,262144,1025,32769,268645,264452,264501,32850,268,65,295205,269365,4097,2421,265328,32880,257,33,38145,264997]

theorem envBound28964 : H12AffineFastState.Bounded env28964 := by
  intro p hp
  have h : env28964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28963_28964 : H12AffineEnvironment.transform 16 38208 env28963 = env28964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38208 env28963 == env28964) = true)

theorem identity28964 : scanCanonicalize (H12AffineFastState.compose env28964 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound28964 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,263,5393,262144,1025,80,268645,264452,264501,3,268,65,262516,269365,4097,2421,265328,33,257,33,5456,264997]

theorem envBound28965 : H12AffineFastState.Bounded env28965 := by
  intro p hp
  have h : env28965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28964_28965 : H12AffineEnvironment.transform 14 81 env28964 = env28965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env28964 == env28965) = true)

theorem identity28965 : scanCanonicalize (H12AffineFastState.compose env28965 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound28965 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,263,5393,4112,1025,80,2421,6420,6437,3,268,65,4452,3109,4097,2421,7264,33,257,33,5456,6965]

theorem envBound28966 : H12AffineFastState.Bounded env28966 := by
  intro p hp
  have h : env28966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28965_28966 : H12AffineEnvironment.transform 17 4112 env28965 = env28966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env28965 == env28966) = true)

theorem identity28966 : scanCanonicalize (H12AffineFastState.compose env28966 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound28966 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env28967 : List Nat := [2,4,8,16,32,64,9,256,324,1024,2048,4096,269,5377,81,263,5393,4112,1025,80,2421,6420,6437,3,268,65,4452,3109,4097,2421,7264,33,257,33,5456,6257]

theorem envBound28967 : H12AffineFastState.Bounded env28967 := by
  intro p hp
  have h : env28967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28966_28967 : H12AffineEnvironment.transform 8 324 env28966 = env28967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env28966 == env28967) = true)

theorem identity28967 : scanCanonicalize (H12AffineFastState.compose env28967 (packedSelected [0,2,3,5,6,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound28967 : packedSelected [0,2,3,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env28968 : List Nat := [2,4,8,16,32,64,9,256,324,1024,2048,2097,269,3376,81,263,3360,2081,1025,80,2421,293,276,3,268,65,2389,3109,2096,2421,1105,33,257,33,3425,64]

theorem envBound28968 : H12AffineFastState.Bounded env28968 := by
  intro p hp
  have h : env28968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28967_28968 : H12AffineEnvironment.transform 11 2097 env28967 = env28968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env28967 == env28968) = true)

theorem identity28968 : scanCanonicalize (H12AffineFastState.compose env28968 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound28968 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env28969 : List Nat := [2,4,8,16,32,64,9,84,16,1024,2048,2097,89,3172,81,83,3188,2081,1025,80,2081,113,64,3,88,65,2049,3109,2096,2081,1105,33,85,33,3125,64]

theorem envBound28969 : H12AffineFastState.Bounded env28969 := by
  intro p hp
  have h : env28969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28968_28969 : H12AffineEnvironment.transform 7 84 env28968 = env28969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env28968 == env28969) = true)

theorem identity28969 : scanCanonicalize (H12AffineFastState.compose env28969 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1108) := by decide +kernel

theorem selectedBound28969 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28970 : List Nat := [2,4,8,16,32,64,9,84,16,1024,1108,1125,89,48,81,83,32,1141,1025,80,1141,113,64,3,88,65,1109,113,1124,1141,1105,33,85,33,97,64]

theorem envBound28970 : H12AffineFastState.Bounded env28970 := by
  intro p hp
  have h : env28970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28969_28970 : H12AffineEnvironment.transform 10 1108 env28969 = env28970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1108 env28969 == env28970) = true)

theorem identity28970 : scanCanonicalize (H12AffineFastState.compose env28970 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound28970 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env28971 : List Nat := [2,4,8,16,32,64,9,84,16,36,112,65,89,48,81,83,32,81,37,80,81,113,64,3,88,65,113,113,64,81,117,33,85,33,97,64]

theorem envBound28971 : H12AffineFastState.Bounded env28971 := by
  intro p hp
  have h : env28971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28970_28971 : H12AffineEnvironment.transform 9 36 env28970 = env28971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env28970 == env28971) = true)

theorem identity28971 : scanCanonicalize (H12AffineFastState.compose env28971 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound28971 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env28972 : List Nat := [2,4,8,16,32,0,9,20,16,36,48,1,25,48,17,19,32,17,37,16,17,49,0,3,24,1,49,49,0,17,53,33,21,33,33,0]

theorem envBound28972 : H12AffineFastState.Bounded env28972 := by
  intro p hp
  have h : env28972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28971_28972 : H12AffineEnvironment.transform 5 0 env28971 = env28972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28971 == env28972) = true)

theorem identity28972 : scanCanonicalize (H12AffineFastState.compose env28972 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28973 : List Nat := [2,4,8,0,32,0,9,4,0,36,32,1,9,32,1,3,32,1,37,0,1,33,0,3,8,1,33,33,0,1,37,33,5,33,33,0]

theorem envBound28973 : H12AffineFastState.Bounded env28973 := by
  intro p hp
  have h : env28973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28972_28973 : H12AffineEnvironment.transform 3 0 env28972 = env28973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28972 == env28973) = true)

def env28974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294320,98780,8328,65,398573,288944,17664,179633,292988,41340,257,21792,46213,352170]

theorem envBound28974 : H12AffineFastState.Bounded env28974 := by
  intro p hp
  have h : env28974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28931_28974 : H12AffineEnvironment.transform 21 272513 env28931 = env28974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28931 == env28974) = true)

theorem identity28974 : scanCanonicalize (H12AffineFastState.compose env28974 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound28974 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,21792,17,98780,8328,65,158028,5393,17664,179633,1501,41340,257,21792,46213,74251]

theorem envBound28975 : H12AffineFastState.Bounded env28975 := by
  intro p hp
  have h : env28975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28974_28975 : H12AffineEnvironment.transform 17 32161 env28974 = env28975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env28974 == env28975) = true)

theorem identity28975 : scanCanonicalize (H12AffineFastState.compose env28975 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28975 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4161,21792,17,41430,8328,65,158028,5393,17664,179633,1501,41340,257,21792,46213,513]

theorem envBound28976 : H12AffineFastState.Bounded env28976 := by
  intro p hp
  have h : env28976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28975_28976 : H12AffineEnvironment.transform 15 8202 env28975 = env28976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28975 == env28976) = true)

theorem identity28976 : scanCanonicalize (H12AffineFastState.compose env28976 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound28976 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env28977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,131072,23589,1025,32769,4161,21792,17,32850,268,65,149704,5393,17664,171061,1501,33016,257,21792,38145,513]

theorem envBound28977 : H12AffineFastState.Bounded env28977 := by
  intro p hp
  have h : env28977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28976_28977 : H12AffineEnvironment.transform 12 388 env28976 = env28977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env28976 == env28977) = true)

theorem identity28977 : scanCanonicalize (H12AffineFastState.compose env28977 (packedSelected [4,9,14,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound28977 : packedSelected [4,9,14,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env28978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,49304,23589,1025,32769,4161,21792,17,32850,268,65,34896,5393,17664,23725,1501,33016,257,21792,38145,513]

theorem envBound28978 : H12AffineFastState.Bounded env28978 := by
  intro p hp
  have h : env28978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28977_28978 : H12AffineEnvironment.transform 16 49304 env28977 = env28978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env28977 == env28978) = true)

theorem identity28978 : scanCanonicalize (H12AffineFastState.compose env28978 (packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28978 : packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env28979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,1,398,16537,23589,1025,0,4161,21792,17,83,268,65,2129,5393,17664,23725,1501,249,257,21792,5376,513]

theorem envBound28979 : H12AffineFastState.Bounded env28979 := by
  intro p hp
  have h : env28979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28978_28979 : H12AffineEnvironment.transform 14 1 env28978 = env28979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28978 == env28979) = true)

theorem identity28979 : scanCanonicalize (H12AffineFastState.compose env28979 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound28979 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env28980 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,1,343,16448,23589,1025,0,4161,21792,17,83,268,65,2129,5393,17664,23668,1284,32,257,21792,5376,513]

theorem envBound28980 : H12AffineFastState.Bounded env28980 := by
  intro p hp
  have h : env28980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28979_28980 : H12AffineEnvironment.transform 6 89 env28979 = env28980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env28979 == env28980) = true)

theorem identity28980 : scanCanonicalize (H12AffineFastState.compose env28980 (packedSelected [1,2,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound28980 : packedSelected [1,2,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env28981 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,3393,1,343,3329,4452,1025,0,4161,6241,17,83,268,65,2129,5393,2113,4405,1284,32,257,6241,5376,513]

theorem envBound28981 : H12AffineFastState.Bounded env28981 := by
  intro p hp
  have h : env28981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28980_28981 : H12AffineEnvironment.transform 13 3393 env28980 = env28981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env28980 == env28981) = true)

theorem identity28981 : scanCanonicalize (H12AffineFastState.compose env28981 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound28981 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env28982 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3108,349,3393,1,343,3329,3392,1025,0,3173,1093,17,83,268,65,2129,2357,2113,3345,1284,32,257,1093,2340,513]

theorem envBound28982 : H12AffineFastState.Bounded env28982 := by
  intro p hp
  have h : env28982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28981_28982 : H12AffineEnvironment.transform 11 3108 env28981 = env28982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env28981 == env28982) = true)

theorem identity28982 : scanCanonicalize (H12AffineFastState.compose env28982 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28982 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env28983 : List Nat := [2,4,8,16,32,64,89,256,512,52,2048,2064,349,2421,1,343,2357,2420,53,0,2129,113,17,83,268,65,2129,2357,2113,2341,304,32,257,113,2340,513]

theorem envBound28983 : H12AffineFastState.Bounded env28983 := by
  intro p hp
  have h : env28983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28982_28983 : H12AffineEnvironment.transform 9 52 env28982 = env28983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28982 == env28983) = true)

theorem identity28983 : scanCanonicalize (H12AffineFastState.compose env28983 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28983 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28984 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,268,2340,1,262,2357,2341,53,0,2048,32,17,2,268,16,2048,2357,2064,2341,304,32,257,32,2340,513]

theorem envBound28984 : H12AffineFastState.Bounded env28984 := by
  intro p hp
  have h : env28984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28983_28984 : H12AffineEnvironment.transform 5 17 env28983 = env28984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28983 == env28984) = true)

theorem identity28984 : scanCanonicalize (H12AffineFastState.compose env28984 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28984 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28985 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2064,41,2049,1,35,2064,2048,53,0,2048,32,17,2,41,16,2048,2064,2064,2048,21,32,36,32,2049,513]

theorem envBound28985 : H12AffineFastState.Bounded env28985 := by
  intro p hp
  have h : env28985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28984_28985 : H12AffineEnvironment.transform 7 37 env28984 = env28985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28984 == env28985) = true)

theorem identity28985 : scanCanonicalize (H12AffineFastState.compose env28985 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28985 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28986 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,8,2049,1,2,2064,2048,20,0,2048,1,17,2,8,16,2048,2064,2064,2048,21,1,5,1,2049,513]

theorem envBound28986 : H12AffineFastState.Bounded env28986 := by
  intro p hp
  have h : env28986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28985_28986 : H12AffineEnvironment.transform 4 1 env28985 = env28986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28985 == env28986) = true)

theorem identity28986 : scanCanonicalize (H12AffineFastState.compose env28986 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28987 : List Nat := [2,4,8,1,1,0,8,4,512,4,2048,2049,8,2049,1,2,2049,2048,5,0,2048,1,0,2,8,1,2048,2049,2049,2048,4,1,5,1,2049,513]

theorem envBound28987 : H12AffineFastState.Bounded env28987 := by
  intro p hp
  have h : env28987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28986_28987 : H12AffineEnvironment.transform 3 1 env28986 = env28987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28986 == env28987) = true)

def env28988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294320,98781,8328,65,4340845,288944,17665,179633,292989,4491773,257,21792,46213,352171]

theorem envBound28988 : H12AffineFastState.Bounded env28988 := by
  intro p hp
  have h : env28988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28930_28988 : H12AffineEnvironment.transform 20 290273 env28930 = env28988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env28930 == env28988) = true)

def env28989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294320,98781,8328,65,398573,288944,17665,179633,292989,41341,257,21792,46213,352171]

theorem envBound28989 : H12AffineFastState.Bounded env28989 := by
  intro p hp
  have h : env28989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28988_28989 : H12AffineEnvironment.transform 21 272512 env28988 = env28989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28988 == env28989) = true)

theorem identity28989 : scanCanonicalize (H12AffineFastState.compose env28989 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound28989 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,290273,272512,294320,95497,8328,65,398573,288944,17665,149861,292989,21929,257,21792,16465,352171]

theorem envBound28990 : H12AffineFastState.Bounded env28990 := by
  intro p hp
  have h : env28990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28989_28990 : H12AffineEnvironment.transform 14 29908 env28989 = env28990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env28989 == env28990) = true)

def env28991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1025,8661,276705,272512,272560,73737,8328,65,398573,277936,4097,138341,273789,169,257,32,5457,330411]

theorem envBound28991 : H12AffineFastState.Bounded env28991 := by
  intro p hp
  have h : env28991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28990_28991 : H12AffineEnvironment.transform 13 5376 env28990 = env28991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28990 == env28991) = true)

theorem identity28991 : scanCanonicalize (H12AffineFastState.compose env28991 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound28991 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,67754,1025,8661,77899,73770,73754,73737,8328,65,203847,79130,4097,138341,75223,169,257,32,5457,513]

theorem envBound28992 : H12AffineFastState.Bounded env28992 := by
  intro p hp
  have h : env28992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28991_28992 : H12AffineEnvironment.transform 17 67754 env28991 = env28992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env28991 == env28992) = true)

theorem identity28992 : scanCanonicalize (H12AffineFastState.compose env28992 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound28992 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79131,67754,1025,8661,77899,73770,73754,73737,8328,65,10588,79130,4097,76158,75223,169,257,32,5457,513]

theorem envBound28993 : H12AffineFastState.Bounded env28993 := by
  intro p hp
  have h : env28993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28992_28993 : H12AffineEnvironment.transform 16 79131 env28992 = env28993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env28992 == env28993) = true)

theorem identity28993 : scanCanonicalize (H12AffineFastState.compose env28993 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28993 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env28994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,5393,10400,1025,8661,4161,32,16,3,8328,65,10588,5392,4097,2420,1501,169,257,32,5457,513]

theorem envBound28994 : H12AffineFastState.Bounded env28994 := by
  intro p hp
  have h : env28994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28993_28994 : H12AffineEnvironment.transform 15 8202 env28993 = env28994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28993 == env28994) = true)

theorem identity28994 : scanCanonicalize (H12AffineFastState.compose env28994 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound28994 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,88,5376,396,82,5393,2296,1025,397,4161,32,16,3,208,65,2308,5392,4097,2420,1501,169,257,32,5457,513]

theorem envBound28995 : H12AffineFastState.Bounded env28995 := by
  intro p hp
  have h : env28995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28994_28995 : H12AffineEnvironment.transform 12 88 env28994 = env28995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env28994 == env28995) = true)

theorem identity28995 : scanCanonicalize (H12AffineFastState.compose env28995 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28995 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env28996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5376,261,82,5393,2161,1025,260,4161,32,16,3,89,65,2308,5392,4097,2420,1364,32,257,32,5457,513]

theorem envBound28996 : H12AffineFastState.Bounded env28996 := by
  intro p hp
  have h : env28996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28995_28996 : H12AffineEnvironment.transform 6 9 env28995 = env28996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28995 == env28996) = true)

def env28997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1025,8660,276704,272512,272561,73736,8328,65,398573,277937,4096,138340,273788,168,257,33,5456,330410]

theorem envBound28997 : H12AffineFastState.Bounded env28997 := by
  intro p hp
  have h : env28997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28990_28997 : H12AffineEnvironment.transform 13 5377 env28990 = env28997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28990 == env28997) = true)

theorem identity28997 : scanCanonicalize (H12AffineFastState.compose env28997 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound28997 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,131072,262144,1025,8660,276704,272512,272561,138,8328,65,398573,277937,4096,138340,273788,168,257,33,5456,272936]

theorem envBound28998 : H12AffineFastState.Bounded env28998 := by
  intro p hp
  have h : env28998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28997_28998 : H12AffineEnvironment.transform 15 8322 env28997 = env28998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env28997 == env28998) = true)

theorem identity28998 : scanCanonicalize (H12AffineFastState.compose env28998 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28998 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1025,8540,276584,272392,272441,2,8192,65,398437,277817,4096,138340,273788,32,257,33,5456,272936]

theorem envBound28999 : H12AffineFastState.Bounded env28999 := by
  intro p hp
  have h : env28999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28998_28999 : H12AffineEnvironment.transform 6 8 env28998 = env28999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28998 == env28999) = true)

theorem identity28999 : scanCanonicalize (H12AffineFastState.compose env28999 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 3361) := by decide +kernel

theorem selectedBound28999 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env29000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,3361,262144,1025,8540,276584,272392,272441,2,8192,65,268612,277817,4096,4421,273788,32,257,33,5456,272936]

theorem envBound29000 : H12AffineFastState.Bounded env29000 := by
  intro p hp
  have h : env29000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28999_29000 : H12AffineEnvironment.transform 16 3361 env28999 = env29000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3361 env28999 == env29000) = true)

theorem identity29000 : scanCanonicalize (H12AffineFastState.compose env29000 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 4404) := by decide +kernel

theorem selectedBound29000 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env29001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,3361,4404,1025,8540,10588,14652,14605,2,8192,65,2160,11277,4096,4421,15432,32,257,33,5456,15132]

theorem envBound29001 : H12AffineFastState.Bounded env29001 := by
  intro p hp
  have h : env29001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29000_29001 : H12AffineEnvironment.transform 17 4404 env29000 = env29001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4404 env29000 == env29001) = true)

theorem identity29001 : scanCanonicalize (H12AffineFastState.compose env29001 (packedSelected [4,6,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound29001 : packedSelected [4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env29002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2348,5377,2161,2342,3361,4404,1025,2160,112,4112,4129,2,2348,65,2160,1313,4096,4421,5476,32,257,33,5456,4656]

theorem envBound29002 : H12AffineFastState.Bounded env29002 := by
  intro p hp
  have h : env29002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29001_29002 : H12AffineEnvironment.transform 12 2348 env29001 = env29002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env29001 == env29002) = true)

theorem identity29002 : scanCanonicalize (H12AffineFastState.compose env29002 (packedSelected [1,8,10,11,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound29002 : packedSelected [1,8,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env29003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,2348,2341,2161,2342,3361,3344,1025,2160,112,3124,3077,2,2348,65,2160,1313,3108,3425,2368,32,257,33,2420,3604]

theorem envBound29003 : H12AffineFastState.Bounded env29003 := by
  intro p hp
  have h : env29003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29002_29003 : H12AffineEnvironment.transform 11 3108 env29002 = env29003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env29002 == env29003) = true)

theorem identity29003 : scanCanonicalize (H12AffineFastState.compose env29003 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound29003 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env29004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,1028,268,261,81,262,1281,1328,1025,80,112,1044,1061,2,268,65,80,1313,1028,1345,352,32,257,33,340,1588]

theorem envBound29004 : H12AffineFastState.Bounded env29004 := by
  intro p hp
  have h : env29004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29003_29004 : H12AffineEnvironment.transform 10 32 env29003 = env29004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env29003 == env29004) = true)

theorem identity29004 : scanCanonicalize (H12AffineFastState.compose env29004 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound29004 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env29005 : List Nat := [2,4,8,16,32,64,8,256,512,768,32,772,268,261,81,262,513,560,769,80,112,788,805,2,268,65,80,545,772,577,352,32,257,33,340,308]

theorem envBound29005 : H12AffineFastState.Bounded env29005 := by
  intro p hp
  have h : env29005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29004_29005 : H12AffineEnvironment.transform 9 768 env29004 = env29005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env29004 == env29005) = true)

theorem identity29005 : scanCanonicalize (H12AffineFastState.compose env29005 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29005 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env29006 : List Nat := [2,4,8,16,32,64,8,37,512,549,32,545,41,32,81,35,513,560,548,80,112,561,512,2,41,65,80,545,545,577,69,32,36,33,113,17]

theorem envBound29006 : H12AffineFastState.Bounded env29006 := by
  intro p hp
  have h : env29006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29005_29006 : H12AffineEnvironment.transform 7 37 env29005 = env29006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29005 == env29006) = true)

theorem identity29006 : scanCanonicalize (H12AffineFastState.compose env29006 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29006 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env29007 : List Nat := [2,4,8,16,32,32,8,37,512,549,32,545,41,32,49,35,513,560,548,48,16,561,512,2,41,33,48,545,545,545,37,32,36,33,17,17]

theorem envBound29007 : H12AffineFastState.Bounded env29007 := by
  intro p hp
  have h : env29007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29006_29007 : H12AffineEnvironment.transform 5 32 env29006 = env29007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29006 == env29007) = true)

theorem identity29007 : scanCanonicalize (H12AffineFastState.compose env29007 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29007 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29008 : List Nat := [2,4,8,16,17,17,8,20,512,532,17,528,24,17,0,18,513,513,533,1,16,512,512,2,24,16,1,528,528,528,20,17,21,16,17,17]

theorem envBound29008 : H12AffineFastState.Bounded env29008 := by
  intro p hp
  have h : env29008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29007_29008 : H12AffineEnvironment.transform 4 17 env29007 = env29008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29007 == env29008) = true)

theorem identity29008 : scanCanonicalize (H12AffineFastState.compose env29008 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29008 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29009 : List Nat := [2,4,8,0,1,1,8,4,512,516,1,512,8,1,0,2,513,513,517,1,0,512,512,2,8,0,1,512,512,512,4,1,5,0,1,1]

theorem envBound29009 : H12AffineFastState.Bounded env29009 := by
  intro p hp
  have h : env29009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29008_29009 : H12AffineEnvironment.transform 3 0 env29008 = env29009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29008 == env29009) = true)

theorem identity29009 : scanCanonicalize (H12AffineFastState.compose env29009 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29009 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29010 : List Nat := [2,0,8,0,1,1,8,0,512,512,1,512,8,1,0,2,513,513,513,1,0,512,512,2,8,0,1,512,512,512,0,1,1,0,1,1]

theorem envBound29010 : H12AffineFastState.Bounded env29010 := by
  intro p hp
  have h : env29010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29009_29010 : H12AffineEnvironment.transform 1 0 env29009 = env29010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29009 == env29010) = true)

theorem identity29010 : scanCanonicalize (H12AffineFastState.compose env29010 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound29010 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29011 : List Nat := [2,0,8,0,1,1,8,0,11,11,1,11,8,1,0,2,10,10,10,1,0,11,11,2,8,0,1,11,11,11,0,1,1,0,1,1]

theorem envBound29011 : H12AffineFastState.Bounded env29011 := by
  intro p hp
  have h : env29011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29010_29011 : H12AffineEnvironment.transform 8 11 env29010 = env29011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env29010 == env29011) = true)

theorem identity29011 : scanCanonicalize (H12AffineFastState.compose env29011 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound29011 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29012 : List Nat := [2,0,0,0,1,1,0,0,3,3,1,3,0,1,0,2,2,2,2,1,0,3,3,2,0,0,1,3,3,3,0,1,1,0,1,1]

theorem envBound29012 : H12AffineFastState.Bounded env29012 := by
  intro p hp
  have h : env29012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29011_29012 : H12AffineEnvironment.transform 2 0 env29011 = env29012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env29011 == env29012) = true)

theorem identity29012 : scanCanonicalize (H12AffineFastState.compose env29012 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29012 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29013 : List Nat := [0,0,0,0,1,1,0,0,1,1,1,1,0,1,0,0,0,0,0,1,0,1,1,0,0,0,1,1,1,1,0,1,1,0,1,1]

theorem envBound29013 : H12AffineFastState.Bounded env29013 := by
  intro p hp
  have h : env29013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29012_29013 : H12AffineEnvironment.transform 0 0 env29012 = env29013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29012 == env29013) = true)

def env29014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294320,98781,8328,65,398572,288944,17665,179633,292989,41340,257,21792,46213,352171]

theorem envBound29014 : H12AffineFastState.Bounded env29014 := by
  intro p hp
  have h : env29014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28988_29014 : H12AffineEnvironment.transform 21 272513 env28988 = env29014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28988 == env29014) = true)

theorem identity29014 : scanCanonicalize (H12AffineFastState.compose env29014 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound29014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,58516,41460,62661,98781,8328,65,171417,57797,17665,179633,61704,41340,257,21792,46213,120542]

theorem envBound29015 : H12AffineFastState.Bounded env29015 := by
  intro p hp
  have h : env29015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29014_29015 : H12AffineEnvironment.transform 17 35189 env29014 = env29015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env29014 == env29015) = true)

def env29016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,35189,1025,32769,45340,41460,41293,98781,8328,65,171417,46157,4233,179633,42112,41340,257,168,46213,99158]

theorem envBound29016 : H12AffineFastState.Bounded env29016 := by
  intro p hp
  have h : env29016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29015_29016 : H12AffineEnvironment.transform 13 5512 env29015 = env29016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env29015 == env29016) = true)

theorem identity29016 : scanCanonicalize (H12AffineFastState.compose env29016 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29016 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,131072,35189,1025,32769,45340,41460,41293,41430,8328,65,171417,46157,4233,179633,42112,41340,257,168,46213,41821]

theorem envBound29017 : H12AffineFastState.Bounded env29017 := by
  intro p hp
  have h : env29017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29016_29017 : H12AffineEnvironment.transform 15 8203 env29016 = env29017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29016 == env29017) = true)

theorem identity29017 : scanCanonicalize (H12AffineFastState.compose env29017 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29017 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env29018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,131072,10281,1025,8541,4160,168,17,138,8328,65,146629,5393,4233,138477,1500,32,257,168,5593,513]

theorem envBound29018 : H12AffineFastState.Bounded env29018 := by
  intro p hp
  have h : env29018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29017_29018 : H12AffineEnvironment.transform 14 8540 env29017 = env29018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29017 == env29018) = true)

theorem identity29018 : scanCanonicalize (H12AffineFastState.compose env29018 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29018 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,0,343,131072,2421,1025,1,4160,168,17,138,468,65,138649,5393,4233,138477,1500,32,257,168,5593,513]

theorem envBound29019 : H12AffineFastState.Bounded env29019 := by
  intro p hp
  have h : env29019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29018_29019 : H12AffineEnvironment.transform 12 348 env29018 = env29019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29018 == env29019) = true)

theorem identity29019 : scanCanonicalize (H12AffineFastState.compose env29019 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29019 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env29020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,131072,2421,1025,1,4160,32,17,2,348,65,138513,5393,4097,138341,1364,32,257,32,5457,513]

theorem envBound29020 : H12AffineFastState.Bounded env29020 := by
  intro p hp
  have h : env29020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29019_29020 : H12AffineEnvironment.transform 6 8 env29019 = env29020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29019 == env29020) = true)

theorem identity29020 : scanCanonicalize (H12AffineFastState.compose env29020 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound29020 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5392,2421,1025,1,4160,32,17,2,348,65,2049,5393,4097,2421,1364,32,257,32,5457,513]

theorem envBound29021 : H12AffineFastState.Bounded env29021 := by
  intro p hp
  have h : env29021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29020_29021 : H12AffineEnvironment.transform 16 5392 env29020 = env29021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env29020 == env29021) = true)

theorem identity29021 : scanCanonicalize (H12AffineFastState.compose env29021 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound29021 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,820,348,1588,0,343,1572,2421,1025,1,884,32,17,2,348,65,2049,1573,821,2421,1364,32,257,32,1637,513]

theorem envBound29022 : H12AffineFastState.Bounded env29022 := by
  intro p hp
  have h : env29022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29021_29022 : H12AffineEnvironment.transform 11 820 env29021 = env29022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env29021 == env29022) = true)

theorem identity29022 : scanCanonicalize (H12AffineFastState.compose env29022 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound29022 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1573,820,348,1588,0,343,1572,1872,1025,1,884,32,17,2,348,65,1572,1573,821,1872,1364,32,257,32,1637,513]

theorem envBound29023 : H12AffineFastState.Bounded env29023 := by
  intro p hp
  have h : env29023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29022_29023 : H12AffineEnvironment.transform 10 1573 env29022 = env29023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env29022 == env29023) = true)

theorem identity29023 : scanCanonicalize (H12AffineFastState.compose env29023 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound29023 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env29024 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1573,608,8,1588,0,3,1572,1540,1025,1,544,32,17,2,8,65,1572,1573,609,1540,1024,32,85,32,1637,513]

theorem envBound29024 : H12AffineFastState.Bounded env29024 := by
  intro p hp
  have h : env29024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29023_29024 : H12AffineEnvironment.transform 7 84 env29023 = env29024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env29023 == env29024) = true)

theorem identity29024 : scanCanonicalize (H12AffineFastState.compose env29024 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound29024 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env29025 : List Nat := [2,4,8,16,32,64,8,84,512,612,65,608,8,80,0,3,64,96,613,1,544,32,17,2,8,65,64,65,609,96,612,32,85,32,1,513]

theorem envBound29025 : H12AffineFastState.Bounded env29025 := by
  intro p hp
  have h : env29025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29024_29025 : H12AffineEnvironment.transform 9 612 env29024 = env29025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env29024 == env29025) = true)

theorem identity29025 : scanCanonicalize (H12AffineFastState.compose env29025 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound29025 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29026 : List Nat := [2,4,8,16,32,48,8,36,512,532,49,528,8,32,0,3,48,16,533,1,544,32,17,2,8,49,48,49,529,16,532,32,37,32,1,513]

theorem envBound29026 : H12AffineFastState.Bounded env29026 := by
  intro p hp
  have h : env29026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29025_29026 : H12AffineEnvironment.transform 5 48 env29025 = env29026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env29025 == env29026) = true)

theorem identity29026 : scanCanonicalize (H12AffineFastState.compose env29026 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29026 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env29027 : List Nat := [2,4,8,16,32,48,8,36,0,20,49,16,8,32,0,3,48,16,21,1,32,32,17,2,8,49,48,49,17,16,20,32,37,32,1,1]

theorem envBound29027 : H12AffineFastState.Bounded env29027 := by
  intro p hp
  have h : env29027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29026_29027 : H12AffineEnvironment.transform 8 0 env29026 = env29027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29026 == env29027) = true)

theorem identity29027 : scanCanonicalize (H12AffineFastState.compose env29027 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29027 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29028 : List Nat := [2,4,8,16,17,1,8,21,0,20,0,16,8,17,0,3,1,16,21,1,17,17,17,2,8,0,1,0,17,16,20,17,20,17,1,1]

theorem envBound29028 : H12AffineFastState.Bounded env29028 := by
  intro p hp
  have h : env29028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29027_29028 : H12AffineEnvironment.transform 4 17 env29027 = env29028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29027 == env29028) = true)

def env29029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,35189,1025,32769,45341,41460,41292,98781,8328,65,171417,46156,4232,179633,42113,41340,257,169,46213,99159]

theorem envBound29029 : H12AffineFastState.Bounded env29029 := by
  intro p hp
  have h : env29029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29015_29029 : H12AffineEnvironment.transform 13 5513 env29015 = env29029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env29015 == env29029) = true)

theorem identity29029 : scanCanonicalize (H12AffineFastState.compose env29029 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound29029 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,35189,1025,32769,45341,41460,41292,2,8328,65,171417,46156,4232,179633,42113,41340,257,169,46213,648]

theorem envBound29030 : H12AffineFastState.Bounded env29030 := by
  intro p hp
  have h : env29030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29029_29030 : H12AffineEnvironment.transform 15 33247 env29029 = env29030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env29029 == env29030) = true)

theorem identity29030 : scanCanonicalize (H12AffineFastState.compose env29030 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29030 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,131072,35189,1025,32769,45341,41341,41292,2,8193,65,171280,46156,4097,179512,41992,41340,257,32,46092,513]

theorem envBound29031 : H12AffineFastState.Bounded env29031 := by
  intro p hp
  have h : env29031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29030_29031 : H12AffineEnvironment.transform 6 9 env29030 = env29031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29030 == env29031) = true)

theorem identity29031 : scanCanonicalize (H12AffineFastState.compose env29031 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,342,131072,2421,1025,1,12573,8573,8524,2,8193,65,138512,13388,4097,146744,9224,8572,257,32,13324,513]

theorem envBound29032 : H12AffineFastState.Bounded env29032 := by
  intro p hp
  have h : env29032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29031_29032 : H12AffineEnvironment.transform 14 0 env29031 = env29032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29031 == env29032) = true)

theorem identity29032 : scanCanonicalize (H12AffineFastState.compose env29032 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29032 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29033 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,262,131072,2341,1025,1,12573,8493,8476,2,8193,17,138512,13340,4097,146744,9224,8492,257,32,13324,513]

theorem envBound29033 : H12AffineFastState.Bounded env29033 := by
  intro p hp
  have h : env29033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29032_29033 : H12AffineEnvironment.transform 5 16 env29032 = env29033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29032 == env29033) = true)

theorem identity29033 : scanCanonicalize (H12AffineFastState.compose env29033 (packedSelected [0,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29033 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env29034 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,262,13340,2341,1025,1,12573,8493,8476,2,8193,17,10508,13340,4097,2340,9224,8492,257,32,13324,513]

theorem envBound29034 : H12AffineFastState.Bounded env29034 := by
  intro p hp
  have h : env29034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29033_29034 : H12AffineEnvironment.transform 16 13340 env29033 = env29034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env29033 == env29034) = true)

theorem identity29034 : scanCanonicalize (H12AffineFastState.compose env29034 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound29034 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29035 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,8192,2049,0,262,10525,2341,1025,1,11292,8493,8476,2,8193,17,10508,10525,3328,2340,9224,8492,257,32,10509,513]

theorem envBound29035 : H12AffineFastState.Bounded env29035 := by
  intro p hp
  have h : env29035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29034_29035 : H12AffineEnvironment.transform 11 3329 env29034 = env29035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env29034 == env29035) = true)

theorem identity29035 : scanCanonicalize (H12AffineFastState.compose env29035 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound29035 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env29036 : List Nat := [2,4,8,16,32,16,9,256,512,1024,814,1583,8192,815,0,262,8755,523,1025,1,10034,8493,8476,2,8193,17,8738,8755,1582,522,9224,8492,257,32,8739,513]

theorem envBound29036 : H12AffineFastState.Bounded env29036 := by
  intro p hp
  have h : env29036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29035_29036 : H12AffineEnvironment.transform 10 814 env29035 = env29036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env29035 == env29036) = true)

theorem identity29036 : scanCanonicalize (H12AffineFastState.compose env29036 (packedSelected [1,3,11] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound29036 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env29037 : List Nat := [2,4,8,16,32,16,9,256,512,1024,814,1583,1337,815,0,262,1802,523,1025,1,523,1044,1061,2,1336,17,1819,1802,1582,522,305,1045,257,32,1818,513]

theorem envBound29037 : H12AffineFastState.Bounded env29037 := by
  intro p hp
  have h : env29037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29036_29037 : H12AffineEnvironment.transform 12 1337 env29036 = env29037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env29036 == env29037) = true)

theorem identity29037 : scanCanonicalize (H12AffineFastState.compose env29037 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound29037 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29038 : List Nat := [2,4,8,16,32,16,9,256,512,574,814,17,775,815,0,262,308,523,575,1,523,554,539,2,774,17,293,308,16,522,305,555,257,32,292,513]

theorem envBound29038 : H12AffineFastState.Bounded env29038 := by
  intro p hp
  have h : env29038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29037_29038 : H12AffineEnvironment.transform 9 574 env29037 = env29038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env29037 == env29038) = true)

def env29039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294321,2485308,8328,65,6705549,288944,2369761,179632,2102685,4491773,257,21793,46212,2175563]

theorem envBound29039 : H12AffineFastState.Bounded env29039 := by
  intro p hp
  have h : env29039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28929_29039 : H12AffineEnvironment.transform 22 294321 env28929 = env29039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294321 env28929 == env29039) = true)

def env29040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294321,98780,8328,65,4340845,288944,17665,179632,292989,4491773,257,21793,46212,352171]

theorem envBound29040 : H12AffineFastState.Bounded env29040 := by
  intro p hp
  have h : env29040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29039_29040 : H12AffineEnvironment.transform 20 290272 env29039 = env29040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env29039 == env29040) = true)

def env29041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294321,98780,8328,65,398573,288944,17665,179632,292989,41341,257,21793,46212,352171]

theorem envBound29041 : H12AffineFastState.Bounded env29041 := by
  intro p hp
  have h : env29041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29040_29041 : H12AffineEnvironment.transform 21 272512 env29040 = env29041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29040 == env29041) = true)

theorem identity29041 : scanCanonicalize (H12AffineFastState.compose env29041 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound29041 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89514,1025,32769,77898,95530,73755,98780,8328,65,215367,79130,17665,179632,75223,41341,257,21793,46212,513]

theorem envBound29042 : H12AffineFastState.Bounded env29042 := by
  intro p hp
  have h : env29042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29041_29042 : H12AffineEnvironment.transform 17 89514 env29041 = env29042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env29041 == env29042) = true)

def env29043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77898,95530,73755,98644,8192,65,215367,79130,17665,179512,75103,41341,257,21793,46092,513]

theorem envBound29043 : H12AffineFastState.Bounded env29043 := by
  intro p hp
  have h : env29043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29042_29043 : H12AffineEnvironment.transform 6 8 env29042 = env29043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29042 == env29043) = true)

theorem identity29043 : scanCanonicalize (H12AffineFastState.compose env29043 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 17665) := by decide +kernel

theorem selectedBound29043 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env29044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,17665,89378,1025,32769,77898,95530,73755,98644,8192,65,68678,79130,17665,63545,75103,41341,257,21793,46092,513]

theorem envBound29044 : H12AffineFastState.Bounded env29044 := by
  intro p hp
  have h : env29044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29043_29044 : H12AffineEnvironment.transform 16 17665 env29043 = env29044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17665 env29043 == env29044) = true)

theorem identity29044 : scanCanonicalize (H12AffineFastState.compose env29044 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound29044 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env29045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,9498,17665,30776,1025,32769,5456,20528,1281,42062,8192,65,10588,4096,17665,63545,69,41341,257,21793,46092,513]

theorem envBound29045 : H12AffineFastState.Bounded env29045 := by
  intro p hp
  have h : env29045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29044_29045 : H12AffineEnvironment.transform 15 9498 env29044 = env29045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env29044 == env29045) = true)

theorem identity29045 : scanCanonicalize (H12AffineFastState.compose env29045 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29045 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env29046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,9498,17665,30776,1025,8541,5456,20528,1281,1298,8192,65,10588,4096,17665,22885,69,33,257,21793,5456,513]

theorem envBound29046 : H12AffineFastState.Bounded env29046 := by
  intro p hp
  have h : env29046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29045_29046 : H12AffineEnvironment.transform 14 8540 env29045 = env29046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29045 == env29046) = true)

theorem identity29046 : scanCanonicalize (H12AffineFastState.compose env29046 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29046 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,4096,11577,1025,8541,5456,1329,1281,1298,8192,65,10588,4096,4096,3172,69,33,257,32,5456,513]

theorem envBound29047 : H12AffineFastState.Bounded env29047 := by
  intro p hp
  have h : env29047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29046_29047 : H12AffineEnvironment.transform 13 5377 env29046 = env29047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29046 == env29047) = true)

theorem identity29047 : scanCanonicalize (H12AffineFastState.compose env29047 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29047 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29048 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8540,8202,4096,10281,273,8541,4160,33,17,2,8192,65,10588,4096,4096,2420,69,33,257,32,4160,513]

theorem envBound29048 : H12AffineFastState.Bounded env29048 := by
  intro p hp
  have h : env29048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29047_29048 : H12AffineEnvironment.transform 9 272 env29047 = env29048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29047 == env29048) = true)

theorem identity29048 : scanCanonicalize (H12AffineFastState.compose env29048 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound29048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29049 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,88,4113,260,82,4096,2161,273,261,4160,33,17,2,88,65,2308,4096,4096,2420,69,33,257,32,4160,513]

theorem envBound29049 : H12AffineFastState.Bounded env29049 := by
  intro p hp
  have h : env29049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29048_29049 : H12AffineEnvironment.transform 12 88 env29048 = env29049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env29048 == env29049) = true)

theorem identity29049 : scanCanonicalize (H12AffineFastState.compose env29049 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29049 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29050 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8,4113,260,2,4096,2081,273,261,4112,33,17,2,8,17,2308,4096,4096,2340,21,33,257,32,4112,513]

theorem envBound29050 : H12AffineFastState.Bounded env29050 := by
  intro p hp
  have h : env29050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29049_29050 : H12AffineEnvironment.transform 5 16 env29049 = env29050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29049 == env29050) = true)

theorem identity29050 : scanCanonicalize (H12AffineFastState.compose env29050 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29050 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29051 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,276,8,261,260,2,276,2081,273,261,260,33,17,2,8,17,2308,276,276,2340,21,33,257,32,260,513]

theorem envBound29051 : H12AffineFastState.Bounded env29051 := by
  intro p hp
  have h : env29051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29050_29051 : H12AffineEnvironment.transform 11 276 env29050 = env29051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29050 == env29051) = true)

theorem identity29051 : scanCanonicalize (H12AffineFastState.compose env29051 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound29051 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29052 : List Nat := [2,4,8,16,32,16,8,256,512,272,49,276,8,261,260,2,276,16,273,261,260,33,17,2,8,17,309,276,276,277,21,33,257,32,260,513]

theorem envBound29052 : H12AffineFastState.Bounded env29052 := by
  intro p hp
  have h : env29052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29051_29052 : H12AffineEnvironment.transform 10 49 env29051 = env29052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env29051 == env29052) = true)

theorem identity29052 : scanCanonicalize (H12AffineFastState.compose env29052 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29052 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29053 : List Nat := [2,4,8,16,32,16,8,36,512,52,49,48,8,33,32,2,48,16,53,33,32,33,17,2,8,17,17,48,48,49,21,33,37,32,32,513]

theorem envBound29053 : H12AffineFastState.Bounded env29053 := by
  intro p hp
  have h : env29053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29052_29053 : H12AffineEnvironment.transform 7 36 env29052 = env29053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29052 == env29053) = true)

theorem identity29053 : scanCanonicalize (H12AffineFastState.compose env29053 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29054 : List Nat := [2,4,8,16,32,16,8,36,1,52,49,48,8,33,32,2,48,16,53,33,32,33,17,2,8,17,17,48,48,49,21,33,37,32,32,0]

theorem envBound29054 : H12AffineFastState.Bounded env29054 := by
  intro p hp
  have h : env29054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29053_29054 : H12AffineEnvironment.transform 8 1 env29053 = env29054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29053 == env29054) = true)

theorem identity29054 : scanCanonicalize (H12AffineFastState.compose env29054 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29054 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29055 : List Nat := [2,4,8,16,17,16,8,21,1,5,0,1,8,16,17,2,1,16,4,16,17,16,17,2,8,17,17,1,1,0,21,16,20,17,17,0]

theorem envBound29055 : H12AffineFastState.Bounded env29055 := by
  intro p hp
  have h : env29055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29054_29055 : H12AffineEnvironment.transform 4 17 env29054 = env29055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29054 == env29055) = true)

def env29056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73755,98645,8193,65,215367,79130,17665,179513,75102,41341,257,21793,46093,513]

theorem envBound29056 : H12AffineFastState.Bounded env29056 := by
  intro p hp
  have h : env29056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29042_29056 : H12AffineEnvironment.transform 6 9 env29042 = env29056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29042 == env29056) = true)

theorem identity29056 : scanCanonicalize (H12AffineFastState.compose env29056 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29056 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env29057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89379,1025,29789,77898,95530,73755,95497,8193,65,215367,79130,17665,149861,75102,21793,257,21793,16465,513]

theorem envBound29057 : H12AffineFastState.Bounded env29057 := by
  intro p hp
  have h : env29057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29056_29057 : H12AffineEnvironment.transform 14 29788 env29056 = env29057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29056 == env29057) = true)

theorem identity29057 : scanCanonicalize (H12AffineFastState.compose env29057 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound29057 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env29058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,5441,89379,1025,29789,77898,95530,73755,95497,8193,65,89094,79130,17665,23588,75102,21793,257,21793,16465,513]

theorem envBound29058 : H12AffineFastState.Bounded env29058 := by
  intro p hp
  have h : env29058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29057_29058 : H12AffineEnvironment.transform 16 5441 env29057 = env29058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env29057 == env29058) = true)

theorem identity29058 : scanCanonicalize (H12AffineFastState.compose env29058 (packedSelected [0,2,4,6,7,9,14,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound29058 : packedSelected [0,2,4,6,7,9,14,17,18,23] rootPS < 2^1333 := by decide +kernel

def env29059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8282,5441,32121,1025,29789,4112,21872,65,21843,8193,65,31836,5440,17665,23588,1284,21793,257,21793,16465,513]

theorem envBound29059 : H12AffineFastState.Bounded env29059 := by
  intro p hp
  have h : env29059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29058_29059 : H12AffineEnvironment.transform 15 8282 env29058 = env29059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env29058 == env29059) = true)

def env29060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294321,98780,8328,65,398572,288944,17665,179632,292989,41340,257,21793,46212,352171]

theorem envBound29060 : H12AffineFastState.Bounded env29060 := by
  intro p hp
  have h : env29060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29040_29060 : H12AffineEnvironment.transform 21 272513 env29040 = env29060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29040 == env29060) = true)

theorem identity29060 : scanCanonicalize (H12AffineFastState.compose env29060 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29060 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,290272,272513,294321,41430,8328,65,398572,288944,17665,179632,292989,41340,257,21793,46212,294817]

theorem envBound29061 : H12AffineFastState.Bounded env29061 := by
  intro p hp
  have h : env29061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29060_29061 : H12AffineEnvironment.transform 15 8202 env29060 = env29061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29060 == env29061) = true)

def env29062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4160,21793,17,41430,8328,65,158028,5392,17665,179632,1501,41340,257,21793,46212,513]

theorem envBound29062 : H12AffineFastState.Bounded env29062 := by
  intro p hp
  have h : env29062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29061_29062 : H12AffineEnvironment.transform 17 32160 env29061 = env29062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env29061 == env29062) = true)

theorem identity29062 : scanCanonicalize (H12AffineFastState.compose env29062 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound29062 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env29063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,131072,23588,1025,32769,4160,21793,17,32850,268,65,149704,5392,17665,171060,1501,33016,257,21793,38144,513]

theorem envBound29063 : H12AffineFastState.Bounded env29063 := by
  intro p hp
  have h : env29063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29062_29063 : H12AffineEnvironment.transform 12 388 env29062 = env29063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env29062 == env29063) = true)

theorem identity29063 : scanCanonicalize (H12AffineFastState.compose env29063 (packedSelected [4,9,14,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound29063 : packedSelected [4,9,14,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env29064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,49304,23588,1025,32769,4160,21793,17,32850,268,65,34896,5392,17665,23724,1501,33016,257,21793,38144,513]

theorem envBound29064 : H12AffineFastState.Bounded env29064 := by
  intro p hp
  have h : env29064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29063_29064 : H12AffineEnvironment.transform 16 49304 env29063 = env29064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env29063 == env29064) = true)

theorem identity29064 : scanCanonicalize (H12AffineFastState.compose env29064 (packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29064 : packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env29065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,1,398,16537,23588,1025,0,4160,21793,17,83,268,65,2129,5392,17665,23724,1501,249,257,21793,5377,513]

theorem envBound29065 : H12AffineFastState.Bounded env29065 := by
  intro p hp
  have h : env29065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29064_29065 : H12AffineEnvironment.transform 14 1 env29064 = env29065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29064 == env29065) = true)

theorem identity29065 : scanCanonicalize (H12AffineFastState.compose env29065 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29065 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29066 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,1,343,16448,23588,1025,0,4160,21793,17,83,268,65,2129,5392,17665,23669,1284,32,257,21793,5377,513]

theorem envBound29066 : H12AffineFastState.Bounded env29066 := by
  intro p hp
  have h : env29066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29065_29066 : H12AffineEnvironment.transform 6 89 env29065 = env29066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29065 == env29066) = true)

theorem identity29066 : scanCanonicalize (H12AffineFastState.compose env29066 (packedSelected [1,2,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound29066 : packedSelected [1,2,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29067 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,3344,1,343,3408,4404,1025,0,4160,6193,17,83,268,65,2129,5392,2065,4453,1284,32,257,6193,5377,513]

theorem envBound29067 : H12AffineFastState.Bounded env29067 := by
  intro p hp
  have h : env29067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29066_29067 : H12AffineEnvironment.transform 13 3344 env29066 = env29067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env29066 == env29067) = true)

theorem identity29067 : scanCanonicalize (H12AffineFastState.compose env29067 (packedSelected [4,6,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound29067 : packedSelected [4,6,7,10] rootPS < 2^1333 := by decide +kernel

def env29068 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3109,349,3344,1,343,3408,3345,1025,0,3173,1044,17,83,268,65,2129,2357,2065,3392,1284,32,257,1044,2340,513]

theorem envBound29068 : H12AffineFastState.Bounded env29068 := by
  intro p hp
  have h : env29068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29067_29068 : H12AffineEnvironment.transform 11 3109 env29067 = env29068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env29067 == env29068) = true)

theorem identity29068 : scanCanonicalize (H12AffineFastState.compose env29068 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29068 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env29069 : List Nat := [2,4,8,16,32,64,89,256,512,101,2048,2112,349,2421,1,343,2357,2420,100,0,2048,113,17,83,268,65,2129,2357,2065,2341,353,32,257,113,2340,513]

theorem envBound29069 : H12AffineFastState.Bounded env29069 := by
  intro p hp
  have h : env29069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29068_29069 : H12AffineEnvironment.transform 9 101 env29068 = env29069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29068 == env29069) = true)

theorem identity29069 : scanCanonicalize (H12AffineFastState.compose env29069 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29070 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2065,268,2340,1,262,2357,2341,53,0,2048,32,17,2,268,16,2048,2357,2065,2341,304,32,257,32,2340,513]

theorem envBound29070 : H12AffineFastState.Bounded env29070 := by
  intro p hp
  have h : env29070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29069_29070 : H12AffineEnvironment.transform 5 17 env29069 = env29070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29069 == env29070) = true)

theorem identity29070 : scanCanonicalize (H12AffineFastState.compose env29070 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29070 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29071 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2065,41,2049,1,35,2064,2048,53,0,2048,32,17,2,41,16,2048,2064,2065,2048,21,32,36,32,2049,513]

theorem envBound29071 : H12AffineFastState.Bounded env29071 := by
  intro p hp
  have h : env29071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29070_29071 : H12AffineEnvironment.transform 7 37 env29070 = env29071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29070 == env29071) = true)

theorem identity29071 : scanCanonicalize (H12AffineFastState.compose env29071 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound29071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29072 : List Nat := [2,4,8,16,32,17,8,37,512,52,17,0,41,16,1,35,1,17,53,0,17,32,17,2,41,16,17,1,0,17,21,32,36,32,16,513]

theorem envBound29072 : H12AffineFastState.Bounded env29072 := by
  intro p hp
  have h : env29072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29071_29072 : H12AffineEnvironment.transform 10 17 env29071 = env29072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env29071 == env29072) = true)

theorem identity29072 : scanCanonicalize (H12AffineFastState.compose env29072 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29073 : List Nat := [2,4,2,16,32,17,2,37,512,52,17,0,35,16,1,35,1,17,53,0,17,32,17,2,35,16,17,1,0,17,21,32,36,32,16,513]

theorem envBound29073 : H12AffineFastState.Bounded env29073 := by
  intro p hp
  have h : env29073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29072_29073 : H12AffineEnvironment.transform 2 2 env29072 = env29073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29072 == env29073) = true)

def env29074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4161,21792,16,41430,8328,65,158029,5393,17665,179632,1500,41340,257,21793,46212,512]

theorem envBound29074 : H12AffineFastState.Bounded env29074 := by
  intro p hp
  have h : env29074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29061_29074 : H12AffineEnvironment.transform 17 32161 env29061 = env29074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env29061 == env29074) = true)

theorem identity29074 : scanCanonicalize (H12AffineFastState.compose env29074 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound29074 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8202,131072,32161,1025,8352,4161,21792,16,375,8328,65,158029,5393,17665,138513,1500,477,257,21793,5157,512]

theorem envBound29075 : H12AffineFastState.Bounded env29075 := by
  intro p hp
  have h : env29075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29074_29075 : H12AffineEnvironment.transform 14 8353 env29074 = env29075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env29074 == env29075) = true)

theorem identity29075 : scanCanonicalize (H12AffineFastState.compose env29075 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound29075 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env29076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8353,8202,131072,10629,1025,8352,4161,260,16,375,8328,65,146793,5393,4389,138513,1500,477,257,261,5157,512]

theorem envBound29076 : H12AffineFastState.Bounded env29076 := by
  intro p hp
  have h : env29076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29075_29076 : H12AffineEnvironment.transform 13 5156 env29075 = env29076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env29075 == env29076) = true)

theorem identity29076 : scanCanonicalize (H12AffineFastState.compose env29076 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 13540) := by decide +kernel

theorem selectedBound29076 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env29077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8353,8202,13540,10629,1025,8352,4161,260,16,375,8328,65,2445,5393,4389,10741,1500,477,257,261,5157,512]

theorem envBound29077 : H12AffineFastState.Bounded env29077 := by
  intro p hp
  have h : env29077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29076_29077 : H12AffineEnvironment.transform 16 13540 env29076 = env29077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13540 env29076 == env29077) = true)

theorem identity29077 : scanCanonicalize (H12AffineFastState.compose env29077 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound29077 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,381,5156,476,375,5529,2296,1025,477,4161,260,16,375,501,65,2445,5393,4389,2184,1500,477,257,261,5157,512]

theorem envBound29078 : H12AffineFastState.Bounded env29078 := by
  intro p hp
  have h : env29078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29077_29078 : H12AffineEnvironment.transform 12 381 env29077 = env29078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env29077 == env29078) = true)

theorem identity29078 : scanCanonicalize (H12AffineFastState.compose env29078 (packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound29078 : packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env29079 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,128,5156,33,138,5220,2296,1025,32,4161,249,16,138,8,65,2160,5356,4312,2184,1057,32,252,248,5157,512]

theorem envBound29079 : H12AffineFastState.Bounded env29079 := by
  intro p hp
  have h : env29079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29078_29079 : H12AffineEnvironment.transform 7 253 env29078 = env29079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env29078 == env29079) = true)

theorem identity29079 : scanCanonicalize (H12AffineFastState.compose env29079 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29079 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29080 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,128,5156,33,138,5141,2185,1025,32,4144,136,16,138,8,48,2049,5277,4265,2184,1057,32,141,137,5157,512]

theorem envBound29080 : H12AffineFastState.Bounded env29080 := by
  intro p hp
  have h : env29080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29079_29080 : H12AffineEnvironment.transform 5 49 env29079 = env29080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29079 == env29080) = true)

theorem identity29080 : scanCanonicalize (H12AffineFastState.compose env29080 (packedSelected [0,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29080 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env29081 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,4096,128,5125,0,138,5141,2185,1025,1,4113,136,16,138,8,17,2049,5277,4232,2184,1024,1,141,137,5124,512]

theorem envBound29081 : H12AffineFastState.Bounded env29081 := by
  intro p hp
  have h : env29081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29080_29081 : H12AffineEnvironment.transform 4 1 env29080 = env29081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29080 == env29081) = true)

theorem identity29081 : scanCanonicalize (H12AffineFastState.compose env29081 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29082 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,0,128,1029,0,138,1045,2185,1025,1,17,136,16,138,8,17,2049,1181,136,2184,1024,1,141,137,1028,512]

theorem envBound29082 : H12AffineFastState.Bounded env29082 := by
  intro p hp
  have h : env29082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29081_29082 : H12AffineEnvironment.transform 11 0 env29081 = env29082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29081 == env29082) = true)

theorem identity29082 : scanCanonicalize (H12AffineFastState.compose env29082 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound29082 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29083 : List Nat := [2,4,8,16,1,16,128,140,512,516,2048,0,128,513,0,138,529,2185,517,1,17,136,16,138,8,17,2049,665,136,2184,516,1,141,137,512,512]

theorem envBound29083 : H12AffineFastState.Bounded env29083 := by
  intro p hp
  have h : env29083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29082_29083 : H12AffineEnvironment.transform 9 516 env29082 = env29083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env29082 == env29083) = true)

theorem identity29083 : scanCanonicalize (H12AffineFastState.compose env29083 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound29083 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29084 : List Nat := [2,4,8,16,1,16,128,140,512,516,152,0,128,513,0,138,529,17,517,1,17,136,16,138,8,17,153,665,136,16,516,1,141,137,512,512]

theorem envBound29084 : H12AffineFastState.Bounded env29084 := by
  intro p hp
  have h : env29084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29083_29084 : H12AffineEnvironment.transform 10 152 env29083 = env29084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env29083 == env29084) = true)

theorem identity29084 : scanCanonicalize (H12AffineFastState.compose env29084 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29084 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29085 : List Nat := [2,4,8,16,1,16,8,4,512,516,16,0,8,513,0,2,529,17,517,1,17,0,16,2,8,17,17,529,0,16,516,1,5,1,512,512]

theorem envBound29085 : H12AffineFastState.Bounded env29085 := by
  intro p hp
  have h : env29085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29084_29085 : H12AffineEnvironment.transform 6 8 env29084 = env29085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29084 == env29085) = true)

theorem identity29085 : scanCanonicalize (H12AffineFastState.compose env29085 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29085 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29086 : List Nat := [2,4,8,16,1,16,8,4,1,5,16,0,8,0,0,2,16,17,4,1,17,0,16,2,8,17,17,16,0,16,5,1,5,1,1,1]

theorem envBound29086 : H12AffineFastState.Bounded env29086 := by
  intro p hp
  have h : env29086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29085_29086 : H12AffineEnvironment.transform 8 1 env29085 = env29086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29085 == env29086) = true)

theorem identity29086 : scanCanonicalize (H12AffineFastState.compose env29086 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29087 : List Nat := [2,4,8,1,1,1,8,4,1,5,1,0,8,0,0,2,1,0,4,1,0,0,1,2,8,0,0,1,0,1,5,1,5,1,1,1]

theorem envBound29087 : H12AffineFastState.Bounded env29087 := by
  intro p hp
  have h : env29087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29086_29087 : H12AffineEnvironment.transform 3 1 env29086 = env29087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29086 == env29087) = true)

theorem identity29087 : scanCanonicalize (H12AffineFastState.compose env29087 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29088 : List Nat := [2,1,8,1,1,1,8,1,1,0,1,0,8,0,0,2,1,0,1,1,0,0,1,2,8,0,0,1,0,1,0,1,0,1,1,1]

theorem envBound29088 : H12AffineFastState.Bounded env29088 := by
  intro p hp
  have h : env29088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29087_29088 : H12AffineEnvironment.transform 1 1 env29087 = env29088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29087 == env29088) = true)

def env29089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294321,98781,8328,65,4340844,288944,17664,179632,292988,4491773,257,21793,46212,352170]

theorem envBound29089 : H12AffineFastState.Bounded env29089 := by
  intro p hp
  have h : env29089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29039_29089 : H12AffineEnvironment.transform 20 290273 env29039 = env29089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env29039 == env29089) = true)

def env29090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294321,98781,8328,65,398572,288944,17664,179632,292988,41341,257,21793,46212,352170]

theorem envBound29090 : H12AffineFastState.Bounded env29090 := by
  intro p hp
  have h : env29090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29089_29090 : H12AffineEnvironment.transform 21 272512 env29089 = env29090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29089 == env29090) = true)

theorem identity29090 : scanCanonicalize (H12AffineFastState.compose env29090 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound29090 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108926,1025,32769,115871,98814,120015,98781,8328,65,245138,115150,17664,179632,119042,41341,257,21793,46212,63188]

theorem envBound29091 : H12AffineFastState.Bounded env29091 := by
  intro p hp
  have h : env29091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29090_29091 : H12AffineEnvironment.transform 17 108926 env29090 = env29091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env29090 == env29091) = true)

def env29092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1025,32769,102815,98814,98767,98781,8328,65,245138,103630,4096,179632,99330,41341,257,33,46212,41940]

theorem envBound29092 : H12AffineFastState.Bounded env29092 := by
  intro p hp
  have h : env29092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29091_29092 : H12AffineEnvironment.transform 13 5376 env29091 = env29092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29091 == env29092) = true)

theorem identity29092 : scanCanonicalize (H12AffineFastState.compose env29092 (packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29092 : packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env29093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,131072,35324,1025,32769,45341,41340,41293,41311,8328,65,171280,46156,4096,179632,42112,41341,257,33,46212,41940]

theorem envBound29093 : H12AffineFastState.Bounded env29093 := by
  intro p hp
  have h : env29093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29092_29093 : H12AffineEnvironment.transform 15 8322 env29092 = env29093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29092 == env29093) = true)

theorem identity29093 : scanCanonicalize (H12AffineFastState.compose env29093 (packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound29093 : packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,5392,35324,1025,32769,45341,41340,41293,41311,8328,65,34816,46156,4096,43168,42112,41341,257,33,46212,41940]

theorem envBound29094 : H12AffineFastState.Bounded env29094 := by
  intro p hp
  have h : env29094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29093_29094 : H12AffineEnvironment.transform 16 5392 env29093 = env29094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env29093 == env29094) = true)

theorem identity29094 : scanCanonicalize (H12AffineFastState.compose env29094 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29094 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5392,35189,1025,32769,45341,41340,41293,41311,8193,65,34816,46156,4096,43049,41993,41341,257,33,46093,41821]

theorem envBound29095 : H12AffineFastState.Bounded env29095 := by
  intro p hp
  have h : env29095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29094_29095 : H12AffineEnvironment.transform 6 9 env29094 = env29095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29094 == env29095) = true)

theorem identity29095 : scanCanonicalize (H12AffineFastState.compose env29095 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29095 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,8203,5392,2340,1025,80,12620,8493,8476,8462,8193,65,2129,13341,4096,10360,9304,8492,257,33,13404,8972]

theorem envBound29096 : H12AffineFastState.Bounded env29096 := by
  intro p hp
  have h : env29096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29095_29096 : H12AffineEnvironment.transform 14 81 env29095 = env29096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29095 == env29096) = true)

theorem identity29096 : scanCanonicalize (H12AffineFastState.compose env29096 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound29096 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env29097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7544,5376,81,7539,5392,2340,1025,80,3124,7253,7268,7286,7545,65,2129,2405,4096,5376,6432,7252,257,33,2340,7796]

theorem envBound29097 : H12AffineFastState.Bounded env29097 := by
  intro p hp
  have h : env29097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29096_29097 : H12AffineEnvironment.transform 12 7544 env29096 = env29097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env29096 == env29097) = true)

theorem identity29097 : scanCanonicalize (H12AffineFastState.compose env29097 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound29097 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2048,1400,3328,81,1395,3344,2340,1025,80,3124,1109,1124,1142,1401,65,2129,2405,2048,3328,288,1108,257,33,2340,1652]

theorem envBound29098 : H12AffineFastState.Bounded env29098 := by
  intro p hp
  have h : env29098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29097_29098 : H12AffineEnvironment.transform 11 2048 env29097 = env29098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env29097 == env29098) = true)

theorem identity29098 : scanCanonicalize (H12AffineFastState.compose env29098 (packedSelected [1,2,3,4,5,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29098 : packedSelected [1,2,3,4,5,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env29099 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2048,1037,3189,81,1030,3173,2129,1025,80,3124,1109,1124,1142,1036,65,2129,2064,2048,3189,85,1108,116,33,2129,1652]

theorem envBound29099 : H12AffineFastState.Bounded env29099 := by
  intro p hp
  have h : env29099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29098_29099 : H12AffineEnvironment.transform 7 117 env29098 = env29099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29098 == env29099) = true)

theorem identity29099 : scanCanonicalize (H12AffineFastState.compose env29099 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound29099 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env29100 : List Nat := [2,4,8,16,32,64,9,117,512,37,2048,2048,40,2128,81,35,2112,2129,36,80,2065,112,65,83,41,65,2129,2064,2048,2128,85,113,116,33,2129,593]

theorem envBound29100 : H12AffineFastState.Bounded env29100 := by
  intro p hp
  have h : env29100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29099_29100 : H12AffineEnvironment.transform 9 37 env29099 = env29100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env29099 == env29100) = true)

theorem identity29100 : scanCanonicalize (H12AffineFastState.compose env29100 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29100 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env29101 : List Nat := [2,4,8,16,32,17,9,36,512,37,2048,2048,40,2049,0,35,2065,2048,36,1,2065,33,16,2,41,16,2048,2064,2048,2049,4,32,37,33,2048,512]

theorem envBound29101 : H12AffineFastState.Bounded env29101 := by
  intro p hp
  have h : env29101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29100_29101 : H12AffineEnvironment.transform 5 17 env29100 = env29101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29100 == env29101) = true)

theorem identity29101 : scanCanonicalize (H12AffineFastState.compose env29101 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29102 : List Nat := [2,4,8,16,16,17,9,20,512,21,2048,2048,24,2049,0,19,2065,2048,20,1,2065,17,16,2,25,16,2048,2064,2048,2049,4,16,21,17,2048,512]

theorem envBound29102 : H12AffineFastState.Bounded env29102 := by
  intro p hp
  have h : env29102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29101_29102 : H12AffineEnvironment.transform 4 16 env29101 = env29102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29101 == env29102) = true)

theorem identity29102 : scanCanonicalize (H12AffineFastState.compose env29102 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29102 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29103 : List Nat := [2,4,2,16,16,17,3,20,512,21,2048,2048,18,2049,0,19,2065,2048,20,1,2065,17,16,2,19,16,2048,2064,2048,2049,4,16,21,17,2048,512]

theorem envBound29103 : H12AffineFastState.Bounded env29103 := by
  intro p hp
  have h : env29103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29102_29103 : H12AffineEnvironment.transform 2 2 env29102 = env29103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29102 == env29103) = true)

theorem identity29103 : scanCanonicalize (H12AffineFastState.compose env29103 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29103 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29104 : List Nat := [2,4,2,0,0,1,3,4,512,5,2048,2048,2,2049,0,3,2049,2048,4,1,2049,1,0,2,3,0,2048,2048,2048,2049,4,0,5,1,2048,512]

theorem envBound29104 : H12AffineFastState.Bounded env29104 := by
  intro p hp
  have h : env29104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29103_29104 : H12AffineEnvironment.transform 3 0 env29103 = env29104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29103 == env29104) = true)

theorem identity29104 : scanCanonicalize (H12AffineFastState.compose env29104 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 517) := by decide +kernel

theorem selectedBound29104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29105 : List Nat := [2,4,2,0,0,1,3,4,512,5,517,517,2,516,0,3,516,517,4,1,516,1,0,2,3,0,517,517,517,516,4,0,5,1,517,512]

theorem envBound29105 : H12AffineFastState.Bounded env29105 := by
  intro p hp
  have h : env29105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29104_29105 : H12AffineEnvironment.transform 10 517 env29104 = env29105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 517 env29104 == env29105) = true)

theorem identity29105 : scanCanonicalize (H12AffineFastState.compose env29105 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound29105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29106 : List Nat := [2,4,2,0,0,1,3,4,6,5,3,3,2,2,0,3,2,3,4,1,2,1,0,2,3,0,3,3,3,2,4,0,5,1,3,6]

theorem envBound29106 : H12AffineFastState.Bounded env29106 := by
  intro p hp
  have h : env29106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29105_29106 : H12AffineEnvironment.transform 8 6 env29105 = env29106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env29105 == env29106) = true)

def env29107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1025,32769,102814,98814,98766,98781,8328,65,245138,103631,4097,179632,99331,41341,257,32,46212,41941]

theorem envBound29107 : H12AffineFastState.Bounded env29107 := by
  intro p hp
  have h : env29107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29091_29107 : H12AffineEnvironment.transform 13 5377 env29091 = env29107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29091 == env29107) = true)

theorem identity29107 : scanCanonicalize (H12AffineFastState.compose env29107 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29107 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env29108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8202,131072,35188,1025,32769,45460,41460,41412,41431,8328,65,171416,46277,4097,179632,41993,41341,257,32,46212,41941]

theorem envBound29108 : H12AffineFastState.Bounded env29108 := by
  intro p hp
  have h : env29108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29107_29108 : H12AffineEnvironment.transform 15 8202 env29107 = env29108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29107 == env29108) = true)

theorem identity29108 : scanCanonicalize (H12AffineFastState.compose env29108 (packedSelected [3,5,6,12,17,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound29108 : packedSelected [3,5,6,12,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env29109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,32768,2,131072,35188,1025,32769,37276,33276,33228,33247,128,65,171416,38093,4097,171448,33793,33141,257,32,38028,33757]

theorem envBound29109 : H12AffineFastState.Bounded env29109 := by
  intro p hp
  have h : env29109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29108_29109 : H12AffineEnvironment.transform 12 8 env29108 = env29109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env29108 == env29109) = true)

theorem identity29109 : scanCanonicalize (H12AffineFastState.compose env29109 (packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 5577) := by decide +kernel

theorem selectedBound29109 : packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env29110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,32768,2,5577,35188,1025,32769,37276,33276,33228,33247,128,65,34897,38093,4097,34929,33793,33141,257,32,38028,33757]

theorem envBound29110 : H12AffineFastState.Bounded env29110 := by
  intro p hp
  have h : env29110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29109_29110 : H12AffineEnvironment.transform 16 5577 env29109 = env29110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5577 env29109 == env29110) = true)

theorem identity29110 : scanCanonicalize (H12AffineFastState.compose env29110 (packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 396) := by decide +kernel

theorem selectedBound29110 : packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env29111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,396,2,5577,2296,1025,397,4112,112,64,83,128,65,2525,5441,4097,2557,1421,249,257,32,5376,593]

theorem envBound29111 : H12AffineFastState.Bounded env29111 := by
  intro p hp
  have h : env29111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29110_29111 : H12AffineEnvironment.transform 14 396 env29110 = env29111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 396 env29110 == env29111) = true)

theorem identity29111 : scanCanonicalize (H12AffineFastState.compose env29111 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29111 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5377,261,2,5440,2161,1025,260,4112,112,64,83,9,65,2388,5441,4097,2420,1284,112,257,32,5376,593]

theorem envBound29112 : H12AffineFastState.Bounded env29112 := by
  intro p hp
  have h : env29112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29111_29112 : H12AffineEnvironment.transform 6 9 env29111 = env29112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29111 == env29112) = true)

theorem identity29112 : scanCanonicalize (H12AffineFastState.compose env29112 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29112 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29113 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8,5124,0,2,5189,2161,1025,1,4112,112,64,83,9,65,2129,5188,4097,2161,1025,112,4,32,5125,593]

theorem envBound29113 : H12AffineFastState.Bounded env29113 := by
  intro p hp
  have h : env29113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29112_29113 : H12AffineEnvironment.transform 7 5 env29112 = env29113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29112 == env29113) = true)

theorem identity29113 : scanCanonicalize (H12AffineFastState.compose env29113 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound29113 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env29114 : List Nat := [2,4,8,16,32,64,9,5,512,1024,65,4096,8,5124,0,2,5189,48,1025,1,4112,112,64,83,9,65,16,5188,4097,48,1025,112,4,32,5125,593]

theorem envBound29114 : H12AffineFastState.Bounded env29114 := by
  intro p hp
  have h : env29114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29113_29114 : H12AffineEnvironment.transform 10 65 env29113 = env29114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env29113 == env29114) = true)

theorem identity29114 : scanCanonicalize (H12AffineFastState.compose env29114 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound29114 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env29115 : List Nat := [2,4,8,16,32,64,9,5,512,1024,65,544,8,1572,0,2,1637,48,1025,1,560,112,64,83,9,65,16,1636,545,48,1025,112,4,32,1573,593]

theorem envBound29115 : H12AffineFastState.Bounded env29115 := by
  intro p hp
  have h : env29115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29114_29115 : H12AffineEnvironment.transform 11 544 env29114 = env29115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env29114 == env29115) = true)

theorem identity29115 : scanCanonicalize (H12AffineFastState.compose env29115 (packedSelected [0,1,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29115 : packedSelected [0,1,4,6,8] rootPS < 2^1333 := by decide +kernel

def env29116 : List Nat := [2,4,8,16,32,64,9,5,512,100,65,544,8,576,0,2,513,48,101,1,560,112,64,83,9,65,16,512,545,48,101,112,4,32,577,593]

theorem envBound29116 : H12AffineFastState.Bounded env29116 := by
  intro p hp
  have h : env29116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29115_29116 : H12AffineEnvironment.transform 9 100 env29115 = env29116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29115 == env29116) = true)

def env29117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294321,98781,8328,65,398573,288944,17664,179632,292988,41340,257,21793,46212,352170]

theorem envBound29117 : H12AffineFastState.Bounded env29117 := by
  intro p hp
  have h : env29117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29089_29117 : H12AffineEnvironment.transform 21 272513 env29089 = env29117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29089 == env29117) = true)

theorem identity29117 : scanCanonicalize (H12AffineFastState.compose env29117 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound29117 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,290273,272513,294321,21763,8328,65,398573,288944,17664,179632,292988,41340,257,21793,46212,297844]

theorem envBound29118 : H12AffineFastState.Bounded env29118 := by
  intro p hp
  have h : env29118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29117_29118 : H12AffineEnvironment.transform 15 54494 env29117 = env29118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env29117 == env29118) = true)

def env29119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,290153,272393,294201,21763,8192,65,398437,288824,17664,179512,292988,41340,257,21793,46092,297844]

theorem envBound29119 : H12AffineFastState.Bounded env29119 := by
  intro p hp
  have h : env29119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29118_29119 : H12AffineEnvironment.transform 6 8 env29118 = env29119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29118 == env29119) = true)

theorem identity29119 : scanCanonicalize (H12AffineFastState.compose env29119 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound29119 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,146744,1025,32769,151633,136497,147457,21763,8192,65,10589,152832,17664,179512,148804,41340,257,21793,46092,177740]

theorem envBound29120 : H12AffineFastState.Bounded env29120 := by
  intro p hp
  have h : env29120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29119_29120 : H12AffineEnvironment.transform 17 146744 env29119 = env29120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env29119 == env29120) = true)

theorem identity29120 : scanCanonicalize (H12AffineFastState.compose env29120 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29120 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env29121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,146744,1025,29789,151633,136497,147457,21763,8192,65,10589,152832,17664,149860,148804,21792,257,21793,16464,147984]

theorem envBound29121 : H12AffineFastState.Bounded env29121 := by
  intro p hp
  have h : env29121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29120_29121 : H12AffineEnvironment.transform 14 29788 env29120 = env29121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29120 == env29121) = true)

theorem identity29121 : scanCanonicalize (H12AffineFastState.compose env29121 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound29121 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env29122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16400,32040,1025,29789,4161,21793,17,21763,8192,65,10589,5392,17664,2420,1364,21792,257,21793,16464,512]

theorem envBound29122 : H12AffineFastState.Bounded env29122 := by
  intro p hp
  have h : env29122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29121_29122 : H12AffineEnvironment.transform 16 16400 env29121 = env29122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env29121 == env29122) = true)

theorem identity29122 : scanCanonicalize (H12AffineFastState.compose env29122 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29122 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21540,114,16400,23888,1025,21541,4161,21793,17,21763,120,65,2341,5392,17664,2420,1364,21792,257,21793,16464,512]

theorem envBound29123 : H12AffineFastState.Bounded env29123 := by
  intro p hp
  have h : env29123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29122_29123 : H12AffineEnvironment.transform 12 120 env29122 = env29123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29122 == env29123) = true)

theorem identity29123 : scanCanonicalize (H12AffineFastState.compose env29123 (packedSelected [0,2,4,5,6,7,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29123 : packedSelected [0,2,4,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env29124 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,88,16384,21508,82,16400,23888,1025,21509,4161,21761,17,21763,88,65,2309,5392,17664,2388,1364,21760,257,21761,16464,512]

theorem envBound29124 : H12AffineFastState.Bounded env29124 := by
  intro p hp
  have h : env29124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29123_29124 : H12AffineEnvironment.transform 4 0 env29123 = env29124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29123 == env29124) = true)

theorem identity29124 : scanCanonicalize (H12AffineFastState.compose env29124 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound29124 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env29125 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,88,5205,81,82,5189,2309,1025,80,4161,340,17,342,88,65,2309,5392,4437,2388,1364,341,257,340,5125,512]

theorem envBound29125 : H12AffineFastState.Bounded env29125 := by
  intro p hp
  have h : env29125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29124_29125 : H12AffineEnvironment.transform 13 5205 env29124 = env29125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env29124 == env29125) = true)

theorem identity29125 : scanCanonicalize (H12AffineFastState.compose env29125 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound29125 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env29126 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,88,5205,81,82,5189,2129,1025,80,4161,0,17,2,88,65,2129,5188,4097,2048,1024,1,85,0,5125,512]

theorem envBound29126 : H12AffineFastState.Bounded env29126 := by
  intro p hp
  have h : env29126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29125_29126 : H12AffineEnvironment.transform 7 84 env29125 = env29126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env29125 == env29126) = true)

theorem identity29126 : scanCanonicalize (H12AffineFastState.compose env29126 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29126 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env29127 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5125,1,2,5141,2049,1025,0,4113,0,17,2,8,17,2049,5140,4097,2048,1024,1,5,0,5125,512]

theorem envBound29127 : H12AffineFastState.Bounded env29127 := by
  intro p hp
  have h : env29127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29126_29127 : H12AffineEnvironment.transform 5 16 env29126 = env29127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29126 == env29127) = true)

def env29128 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1045,1,2,1029,2049,1025,0,1,0,17,2,8,17,2049,1028,17,2048,1024,1,5,0,1045,512]

theorem envBound29128 : H12AffineFastState.Bounded env29128 := by
  intro p hp
  have h : env29128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29127_29128 : H12AffineEnvironment.transform 11 16 env29127 = env29128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env29127 == env29128) = true)

theorem identity29128 : scanCanonicalize (H12AffineFastState.compose env29128 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29129 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,8,1045,1,2,1029,1,1025,0,1,0,17,2,8,17,1,1028,17,0,1024,1,5,0,1045,512]

theorem envBound29129 : H12AffineFastState.Bounded env29129 := by
  intro p hp
  have h : env29129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29128_29129 : H12AffineEnvironment.transform 10 0 env29128 = env29129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29128 == env29129) = true)

def env29130 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,1,1,2,17,1,21,0,1,0,17,2,8,17,1,16,17,0,20,1,5,0,1,512]

theorem envBound29130 : H12AffineFastState.Bounded env29130 := by
  intro p hp
  have h : env29130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29129_29130 : H12AffineEnvironment.transform 9 20 env29129 = env29130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29129 == env29130) = true)

theorem identity29130 : scanCanonicalize (H12AffineFastState.compose env29130 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound29130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29131 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,8,1,1,2,17,1,21,0,1,0,17,2,8,17,1,16,17,0,20,1,5,0,1,30]

theorem envBound29131 : H12AffineFastState.Bounded env29131 := by
  intro p hp
  have h : env29131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29130_29131 : H12AffineEnvironment.transform 8 30 env29130 = env29131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env29130 == env29131) = true)

def leafEnv29131 : List Nat := [2,4,8,16,0,16,8,4,30,20,0,16,8,1,1,2,17,1,21,0,1,0,17,2,21,8,1,17,1,16,17,0,20,1,5,0,5,2,1,30,1,1,0]

def active29131 : List Nat := [0,1,2,3]

def tree29131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29131 : H12WitnessSearch.Good tree29131 := H12GlobalWitnessIndex.good

theorem leafIdentity29131 : H12AffineFastState.composeSystem env29131 rootObs = leafEnv29131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29131 rootObs == leafEnv29131) = true)

theorem terminalChecked29131 : H12PackedTerminal.terminalCheckFast leafEnv29131 active29131 tree29131 = true := by decide +kernel

def env29132 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,0,1,2,16,1,20,0,1,0,17,2,8,17,1,17,17,0,21,1,5,0,0,512]

theorem envBound29132 : H12AffineFastState.Bounded env29132 := by
  intro p hp
  have h : env29132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29129_29132 : H12AffineEnvironment.transform 9 21 env29129 = env29132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29129 == env29132) = true)

theorem identity29132 : scanCanonicalize (H12AffineFastState.compose env29132 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound29132 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29133 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,1,2,5,1,1,0,1,0,4,2,8,4,1,4,4,0,0,1,5,0,0,512]

theorem envBound29133 : H12AffineFastState.Bounded env29133 := by
  intro p hp
  have h : env29133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29132_29133 : H12AffineEnvironment.transform 3 5 env29132 = env29133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env29132 == env29133) = true)

def leafEnv29133 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,1,2,5,1,1,0,1,0,4,2,1,8,1,4,1,4,4,0,0,1,5,0,5,2,0,512,1,1,0]

def active29133 : List Nat := [0,1,2,8]

def tree29133 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29133 : H12WitnessSearch.Good tree29133 := H12GlobalWitnessIndex.good

theorem leafIdentity29133 : H12AffineFastState.composeSystem env29133 rootObs = leafEnv29133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29133 rootObs == leafEnv29133) = true)

theorem terminalChecked29133 : H12PackedTerminal.terminalCheckFast leafEnv29133 active29133 tree29133 = true := by decide +kernel

def env29134 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1044,1,2,1028,2049,1025,0,0,0,17,2,8,17,2049,1029,16,2048,1024,1,5,0,1044,512]

theorem envBound29134 : H12AffineFastState.Bounded env29134 := by
  intro p hp
  have h : env29134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29127_29134 : H12AffineEnvironment.transform 11 17 env29127 = env29134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env29127 == env29134) = true)

theorem identity29134 : scanCanonicalize (H12AffineFastState.compose env29134 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound29134 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29135 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,17,8,1044,1,2,1028,1044,1025,0,0,0,17,2,8,17,1044,1029,16,1045,1024,1,5,0,1044,512]

theorem envBound29135 : H12AffineFastState.Bounded env29135 := by
  intro p hp
  have h : env29135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29134_29135 : H12AffineEnvironment.transform 10 1045 env29134 = env29135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env29134 == env29135) = true)

def env29136 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,8,0,1,2,16,0,21,0,0,0,17,2,8,17,0,17,16,1,20,1,5,0,0,512]

theorem envBound29136 : H12AffineFastState.Bounded env29136 := by
  intro p hp
  have h : env29136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29135_29136 : H12AffineEnvironment.transform 9 20 env29135 = env29136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29135 == env29136) = true)

theorem identity29136 : scanCanonicalize (H12AffineFastState.compose env29136 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound29136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29137 : List Nat := [2,4,8,16,0,16,8,4,31,20,1,17,8,0,1,2,16,0,21,0,0,0,17,2,8,17,0,17,16,1,20,1,5,0,0,31]

theorem envBound29137 : H12AffineFastState.Bounded env29137 := by
  intro p hp
  have h : env29137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29136_29137 : H12AffineEnvironment.transform 8 31 env29136 = env29137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env29136 == env29137) = true)

def leafEnv29137 : List Nat := [2,4,8,16,0,16,8,4,31,20,1,17,8,0,1,2,16,0,21,0,0,0,17,2,21,8,1,17,0,17,16,1,20,1,5,0,5,2,0,31,1,0,0]

def active29137 : List Nat := [0,1,2,3]

def tree29137 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29137 : H12WitnessSearch.Good tree29137 := H12GlobalWitnessIndex.good

theorem leafIdentity29137 : H12AffineFastState.composeSystem env29137 rootObs = leafEnv29137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29137 rootObs == leafEnv29137) = true)

theorem terminalChecked29137 : H12PackedTerminal.terminalCheckFast leafEnv29137 active29137 tree29137 = true := by decide +kernel

def env29138 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,1,1,2,17,1,20,0,0,0,17,2,8,17,1,16,16,0,21,1,5,0,1,512]

theorem envBound29138 : H12AffineFastState.Bounded env29138 := by
  intro p hp
  have h : env29138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29135_29138 : H12AffineEnvironment.transform 9 21 env29135 = env29138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29135 == env29138) = true)

theorem identity29138 : scanCanonicalize (H12AffineFastState.compose env29138 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound29138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29139 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,8,1,1,2,4,1,1,0,0,0,4,2,8,4,1,5,5,0,0,1,5,0,1,512]

theorem envBound29139 : H12AffineFastState.Bounded env29139 := by
  intro p hp
  have h : env29139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29138_29139 : H12AffineEnvironment.transform 3 5 env29138 = env29139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env29138 == env29139) = true)

def leafEnv29139 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,8,1,1,2,4,1,1,0,0,0,4,2,1,8,1,4,1,5,5,0,0,1,5,0,5,2,1,512,1,0,0]

def active29139 : List Nat := [0,1,2,8]

def tree29139 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood29139 : H12WitnessSearch.Good tree29139 := H12GlobalWitnessIndex.good

theorem leafIdentity29139 : H12AffineFastState.composeSystem env29139 rootObs = leafEnv29139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env29139 rootObs == leafEnv29139) = true)

theorem terminalChecked29139 : H12PackedTerminal.terminalCheckFast leafEnv29139 active29139 tree29139 = true := by decide +kernel

def env29140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,290152,272392,294200,21763,8193,65,398436,288825,17664,179513,292988,41340,257,21793,46093,297844]

theorem envBound29140 : H12AffineFastState.Bounded env29140 := by
  intro p hp
  have h : env29140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29118_29140 : H12AffineEnvironment.transform 6 9 env29118 = env29140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29118 == env29140) = true)

theorem identity29140 : scanCanonicalize (H12AffineFastState.compose env29140 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound29140 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35189,1025,32769,58397,41341,62541,21763,8193,65,171281,57676,17664,179513,61705,41340,257,21793,46093,513]

theorem envBound29141 : H12AffineFastState.Bounded env29141 := by
  intro p hp
  have h : env29141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29140_29141 : H12AffineEnvironment.transform 17 35189 env29140 = env29141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env29140 == env29141) = true)

theorem identity29141 : scanCanonicalize (H12AffineFastState.compose env29141 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound29141 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env29142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16400,35189,1025,32769,58397,41341,62541,21763,8193,65,56577,57676,17664,64809,61705,41340,257,21793,46093,513]

theorem envBound29142 : H12AffineFastState.Bounded env29142 := by
  intro p hp
  have h : env29142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29141_29142 : H12AffineEnvironment.transform 16 16400 env29141 = env29142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env29141 == env29142) = true)

theorem identity29142 : scanCanonicalize (H12AffineFastState.compose env29142 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29142 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16400,32041,1025,29789,4161,21793,17,21763,8193,65,10589,5392,17664,2421,1365,21792,257,21793,16465,513]

theorem envBound29143 : H12AffineFastState.Bounded env29143 := by
  intro p hp
  have h : env29143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29142_29143 : H12AffineEnvironment.transform 14 29788 env29142 = env29143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29142 == env29143) = true)

def env29144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound29144 : H12AffineFastState.Bounded env29144 := by
  intro p hp
  have h : env29144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26528_29144 : H12AffineEnvironment.transform 31 145662401 env26528 = env29144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env26528 == env29144) = true)

def env29145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound29145 : H12AffineFastState.Bounded env29145 := by
  intro p hp
  have h : env29145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29144_29145 : H12AffineEnvironment.transform 29 155254784 env29144 = env29145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env29144 == env29145) = true)

def env29146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound29146 : H12AffineFastState.Bounded env29146 := by
  intro p hp
  have h : env29146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29145_29146 : H12AffineEnvironment.transform 25 64 env29145 = env29146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env29145 == env29146) = true)

def env29147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound29147 : H12AffineFastState.Bounded env29147 := by
  intro p hp
  have h : env29147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29146_29147 : H12AffineEnvironment.transform 26 30393344 env29146 = env29147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env29146 == env29147) = true)

def env29148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound29148 : H12AffineFastState.Bounded env29148 := by
  intro p hp
  have h : env29148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29147_29148 : H12AffineEnvironment.transform 18 1024 env29147 = env29148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env29147 == env29148) = true)

theorem identity29148 : scanCanonicalize (H12AffineFastState.compose env29148 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601477) := by decide +kernel

theorem selectedBound29148 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601477,8328,64,6685701,8405128,10507601,8830976,2113556,12624324,256,168,57612,2189250]

theorem envBound29149 : H12AffineFastState.Bounded env29149 := by
  intro p hp
  have h : env29149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29148_29149 : H12AffineEnvironment.transform 23 10601477 env29148 = env29149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601477 env29148 == env29149) = true)

def env29150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685701,8393984,10485977,8820104,2102684,12624324,256,168,46212,2175562]

theorem envBound29150 : H12AffineFastState.Bounded env29150 := by
  intro p hp
  have h : env29150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29149_29150 : H12AffineEnvironment.transform 13 5512 env29149 = env29150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env29149 == env29150) = true)

def env29151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685701,2098648,4097,2524496,2102684,6336796,256,168,46212,2175562]

theorem envBound29151 : H12AffineFastState.Bounded env29151 := by
  intro p hp
  have h : env29151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29150_29151 : H12AffineEnvironment.transform 22 2101464 env29150 = env29151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env29150 == env29151) = true)

def env29152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491429,2098648,4097,2524496,2102684,2142524,256,168,46212,2175562]

theorem envBound29152 : H12AffineFastState.Bounded env29152 := by
  intro p hp
  have h : env29152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29151_29152 : H12AffineEnvironment.transform 21 32 env29151 = env29152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29151 == env29152) = true)

def env29153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98645,8192,64,2491429,2098512,4097,2524496,2102548,2142524,256,32,46092,2175562]

theorem envBound29153 : H12AffineFastState.Bounded env29153 := by
  intro p hp
  have h : env29153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29152_29153 : H12AffineEnvironment.transform 6 8 env29152 = env29153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29152 == env29153) = true)

def env29154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98645,8192,64,398437,5392,4097,431376,1364,41340,256,32,46092,74250]

theorem envBound29154 : H12AffineFastState.Bounded env29154 := by
  intro p hp
  have h : env29154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29153_29154 : H12AffineEnvironment.transform 20 4160 env29153 = env29154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29153 == env29154) = true)

theorem identity29154 : scanCanonicalize (H12AffineFastState.compose env29154 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound29154 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,32,16,2,8192,64,398437,5392,4097,431376,1364,41340,256,32,46092,41821]

theorem envBound29155 : H12AffineFastState.Bounded env29155 := by
  intro p hp
  have h : env29155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29154_29155 : H12AffineEnvironment.transform 15 33111 env29154 = env29155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env29154 == env29155) = true)

theorem identity29155 : scanCanonicalize (H12AffineFastState.compose env29155 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29155 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,262144,1024,32769,4160,32,16,2,8192,64,262516,5392,4097,294913,1364,41340,256,32,46092,41821]

theorem envBound29156 : H12AffineFastState.Bounded env29156 := by
  intro p hp
  have h : env29156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29155_29156 : H12AffineEnvironment.transform 16 5393 env29155 = env29156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29155 == env29156) = true)

theorem identity29156 : scanCanonicalize (H12AffineFastState.compose env29156 (packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound29156 : packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env29157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,2049,1024,32769,4160,32,16,2,8192,64,2421,5392,4097,34816,1364,41340,256,32,46092,41821]

theorem envBound29157 : H12AffineFastState.Bounded env29157 := by
  intro p hp
  have h : env29157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29156_29157 : H12AffineEnvironment.transform 17 2049 env29156 = env29157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env29156 == env29157) = true)

theorem identity29157 : scanCanonicalize (H12AffineFastState.compose env29157 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29157 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env29158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,32768,33111,5393,2049,1024,32769,4160,32,16,2,120,64,2421,5392,4097,34816,1364,33028,256,32,38004,33573]

theorem envBound29158 : H12AffineFastState.Bounded env29158 := by
  intro p hp
  have h : env29158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29157_29158 : H12AffineEnvironment.transform 12 120 env29157 = env29158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29157 == env29158) = true)

theorem identity29158 : scanCanonicalize (H12AffineFastState.compose env29158 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29158 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29159 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5376,32768,33030,5393,2049,1024,32769,4113,32,16,2,41,17,2340,5392,4097,34816,1285,33028,256,32,37925,33573]

theorem envBound29159 : H12AffineFastState.Bounded env29159 := by
  intro p hp
  have h : env29159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29158_29159 : H12AffineEnvironment.transform 5 17 env29158 = env29159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29158 == env29159) = true)

theorem identity29159 : scanCanonicalize (H12AffineFastState.compose env29159 (packedSelected [1,2,3,5,8,11,12,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29159 : packedSelected [1,2,3,5,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29160 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,9,5376,32768,33030,5393,2049,1024,32769,4113,0,16,2,9,17,2308,5392,4097,34816,1285,33028,256,0,37893,33541]

theorem envBound29160 : H12AffineFastState.Bounded env29160 := by
  intro p hp
  have h : env29160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29159_29160 : H12AffineEnvironment.transform 4 0 env29159 = env29160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29159 == env29160) = true)

theorem identity29160 : scanCanonicalize (H12AffineFastState.compose env29160 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound29160 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29161 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,9,5376,261,3,5393,2049,1024,260,4113,0,16,2,9,17,2308,5392,4097,2309,1285,1,256,0,5376,512]

theorem envBound29161 : H12AffineFastState.Bounded env29161 := by
  intro p hp
  have h : env29161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29160_29161 : H12AffineEnvironment.transform 14 261 env29160 = env29161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env29160 == env29161) = true)

theorem identity29161 : scanCanonicalize (H12AffineFastState.compose env29161 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29161 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0