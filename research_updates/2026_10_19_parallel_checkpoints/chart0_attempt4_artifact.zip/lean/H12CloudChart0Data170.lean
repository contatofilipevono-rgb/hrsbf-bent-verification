import H12CloudChart0Data169

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans43073_43074 : H12AffineEnvironment.transform 13 5377 env43073 = env43074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43073 == env43074) = true)

theorem identity43074 : scanCanonicalize (H12AffineFastState.compose env43074 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43074 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,13389,10281,1025,8541,4160,32,17,2,8192,64,75786,79131,4097,10281,75102,73771,257,73771,79195,513]

theorem envBound43075 : H12AffineFastState.Bounded env43075 := by
  intro p hp
  have h : env43075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43074_43075 : H12AffineEnvironment.transform 14 8540 env43074 = env43075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43074 == env43075) = true)

theorem identity43075 : scanCanonicalize (H12AffineFastState.compose env43075 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43075 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env43076 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,65536,13340,10281,1025,8460,4113,32,17,2,8192,17,75786,79131,4097,10281,75023,73771,257,73771,79114,513]

theorem envBound43076 : H12AffineFastState.Bounded env43076 := by
  intro p hp
  have h : env43076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43075_43076 : H12AffineEnvironment.transform 5 17 env43075 = env43076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43075 == env43076) = true)

theorem identity43076 : scanCanonicalize (H12AffineFastState.compose env43076 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound43076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43077 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,263,13340,10281,1025,8460,4113,32,17,2,8192,17,10509,13340,4097,10281,9224,8492,257,8492,13325,513]

theorem envBound43077 : H12AffineFastState.Bounded env43077 := by
  intro p hp
  have h : env43077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43076_43077 : H12AffineEnvironment.transform 15 263 env43076 = env43077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env43076 == env43077) = true)

theorem identity43077 : scanCanonicalize (H12AffineFastState.compose env43077 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3354) := by decide +kernel

theorem selectedBound43077 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43078 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3354,8192,2075,8461,263,10502,10281,1025,8460,3339,32,17,2,8192,17,10509,10502,3355,10281,9224,8492,257,8492,10519,513]

theorem envBound43078 : H12AffineFastState.Bounded env43078 := by
  intro p hp
  have h : env43078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43077_43078 : H12AffineEnvironment.transform 11 3354 env43077 = env43078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3354 env43077 == env43078) = true)

theorem identity43078 : scanCanonicalize (H12AffineFastState.compose env43078 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound43078 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env43079 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3354,51,2075,318,263,2357,2074,1025,319,3339,32,17,2,51,17,2366,2357,3355,2074,1083,287,257,287,2340,513]

theorem envBound43079 : H12AffineFastState.Bounded env43079 := by
  intro p hp
  have h : env43079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43078_43079 : H12AffineEnvironment.transform 12 51 env43078 = env43079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env43078 == env43079) = true)

theorem identity43079 : scanCanonicalize (H12AffineFastState.compose env43079 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound43079 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43080 : List Nat := [2,4,8,16,32,17,8,63,512,1024,2048,3109,51,2075,1,56,2058,2074,1025,0,3124,32,17,2,51,17,2049,2058,3108,2074,1083,32,62,32,2075,513]

theorem envBound43080 : H12AffineFastState.Bounded env43080 := by
  intro p hp
  have h : env43080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43079_43080 : H12AffineEnvironment.transform 7 63 env43079 = env43080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env43079 == env43080) = true)

theorem identity43080 : scanCanonicalize (H12AffineFastState.compose env43080 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound43080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43081 : List Nat := [2,4,8,16,32,17,8,63,512,15,2048,2090,51,2075,1,56,2058,2074,14,0,2107,32,17,2,51,17,2049,2058,2091,2074,52,32,62,32,2075,513]

theorem envBound43081 : H12AffineFastState.Bounded env43081 := by
  intro p hp
  have h : env43081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43080_43081 : H12AffineEnvironment.transform 9 15 env43080 = env43081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env43080 == env43081) = true)

theorem identity43081 : scanCanonicalize (H12AffineFastState.compose env43081 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound43081 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43082 : List Nat := [2,4,8,16,32,17,8,63,49,15,2048,2090,51,2075,1,56,2058,2074,14,0,2107,32,17,2,51,17,2049,2058,2091,2074,52,32,62,32,2075,48]

theorem envBound43082 : H12AffineFastState.Bounded env43082 := by
  intro p hp
  have h : env43082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43081_43082 : H12AffineEnvironment.transform 8 49 env43081 = env43082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env43081 == env43082) = true)

theorem identity43082 : scanCanonicalize (H12AffineFastState.compose env43082 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound43082 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43083 : List Nat := [2,4,8,16,32,17,8,63,49,15,16,58,51,11,1,56,26,10,14,0,43,32,17,2,51,17,17,26,59,10,52,32,62,32,11,48]

theorem envBound43083 : H12AffineFastState.Bounded env43083 := by
  intro p hp
  have h : env43083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43082_43083 : H12AffineEnvironment.transform 10 16 env43082 = env43083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env43082 == env43083) = true)

theorem identity43083 : scanCanonicalize (H12AffineFastState.compose env43083 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound43083 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43084 : List Nat := [2,4,8,16,27,17,8,4,10,15,16,1,8,11,1,3,26,10,14,0,16,27,17,2,8,17,17,26,0,10,15,27,5,27,11,11]

theorem envBound43084 : H12AffineFastState.Bounded env43084 := by
  intro p hp
  have h : env43084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43083_43084 : H12AffineEnvironment.transform 4 27 env43083 = env43084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env43083 == env43084) = true)

theorem identity43084 : scanCanonicalize (H12AffineFastState.compose env43084 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43084 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43085 : List Nat := [2,3,8,16,27,17,8,3,10,8,16,1,8,11,1,3,26,10,9,0,16,27,17,2,8,17,17,26,0,10,8,27,2,27,11,11]

theorem envBound43085 : H12AffineFastState.Bounded env43085 := by
  intro p hp
  have h : env43085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43084_43085 : H12AffineEnvironment.transform 1 3 env43084 = env43085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43084 == env43085) = true)

theorem identity43085 : scanCanonicalize (H12AffineFastState.compose env43085 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43085 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43086 : List Nat := [2,3,8,1,10,0,8,3,10,8,1,1,8,11,1,3,11,10,9,0,1,10,0,2,8,0,0,11,0,10,8,10,2,10,11,11]

theorem envBound43086 : H12AffineFastState.Bounded env43086 := by
  intro p hp
  have h : env43086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43085_43086 : H12AffineEnvironment.transform 3 1 env43085 = env43086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43085 == env43086) = true)

theorem identity43086 : scanCanonicalize (H12AffineFastState.compose env43086 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43087 : List Nat := [2,3,1,1,3,0,1,3,3,1,1,1,1,2,1,3,2,3,0,0,1,3,0,2,1,0,0,2,0,3,1,3,2,3,2,2]

theorem envBound43087 : H12AffineFastState.Bounded env43087 := by
  intro p hp
  have h : env43087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43086_43087 : H12AffineEnvironment.transform 2 1 env43086 = env43087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43086 == env43087) = true)

def env43088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,21763,8193,64,75786,115015,17664,303452,119043,392286,257,98678,90202,63069]

theorem envBound43088 : H12AffineFastState.Bounded env43088 := by
  intro p hp
  have h : env43088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43071_43088 : H12AffineEnvironment.transform 6 9 env43071 = env43088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43071 == env43088) = true)

theorem identity43088 : scanCanonicalize (H12AffineFastState.compose env43088 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound43088 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1025,32769,4160,21793,17,21763,8193,64,75786,115015,17664,10281,119043,95531,257,98678,90202,63069]

theorem envBound43089 : H12AffineFastState.Bounded env43089 := by
  intro p hp
  have h : env43089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43088_43089 : H12AffineEnvironment.transform 17 35189 env43088 = env43089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env43088 == env43089) = true)

theorem identity43089 : scanCanonicalize (H12AffineFastState.compose env43089 (packedSelected [1,3,18,19,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound43089 : packedSelected [1,3,18,19,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33030,24908,35189,1025,32769,4160,21793,17,21763,8193,64,43276,16449,17664,10281,20485,62509,257,112,57692,63069]

theorem envBound43090 : H12AffineFastState.Bounded env43090 := by
  intro p hp
  have h : env43090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43089_43090 : H12AffineEnvironment.transform 15 33030 env43089 = env43090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env43089 == env43090) = true)

theorem identity43090 : scanCanonicalize (H12AffineFastState.compose env43090 (packedSelected [0,3,5,7,9,10,12,14,15,19,20,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43090 : packedSelected [0,3,5,7,9,10,12,14,15,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env43091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,33030,13625,35189,1025,32769,4160,340,17,374,8193,64,43276,5172,4469,10281,1136,41048,257,112,46377,41512]

theorem envBound43091 : H12AffineFastState.Bounded env43091 := by
  intro p hp
  have h : env43091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43090_43091 : H12AffineEnvironment.transform 13 5237 env43090 = env43091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43090 == env43091) = true)

theorem identity43091 : scanCanonicalize (H12AffineFastState.compose env43091 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound43091 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env43092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,32768,33030,5441,35189,1025,32769,4160,340,17,374,121,64,35188,5172,4469,2129,1136,32800,257,112,38225,33360]

theorem envBound43092 : H12AffineFastState.Bounded env43092 := by
  intro p hp
  have h : env43092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43091_43092 : H12AffineEnvironment.transform 12 120 env43091 = env43092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env43091 == env43092) = true)

theorem identity43092 : scanCanonicalize (H12AffineFastState.compose env43092 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound43092 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43093 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,81,343,5441,2340,1025,80,4160,340,17,374,121,64,2341,5172,4469,2129,1136,113,257,112,5376,513]

theorem envBound43093 : H12AffineFastState.Bounded env43093 := by
  intro p hp
  have h : env43093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43092_43093 : H12AffineEnvironment.transform 14 81 env43092 = env43093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env43092 == env43093) = true)

theorem identity43093 : scanCanonicalize (H12AffineFastState.compose env43093 (packedSelected [1,2,5,6,7,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound43093 : packedSelected [1,2,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env43094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,120,3393,81,343,3189,2340,1025,80,2420,340,17,374,121,64,2341,3328,2113,2129,1136,113,257,112,3124,513]

theorem envBound43094 : H12AffineFastState.Bounded env43094 := by
  intro p hp
  have h : env43094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43093_43094 : H12AffineEnvironment.transform 11 2356 env43093 = env43094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env43093 == env43094) = true)

theorem identity43094 : scanCanonicalize (H12AffineFastState.compose env43094 (packedSelected [3,4,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43094 : packedSelected [3,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43095 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2356,120,2129,81,343,2405,2340,273,80,2420,340,17,374,121,64,2341,2064,2113,2129,352,113,257,112,2340,513]

theorem envBound43095 : H12AffineFastState.Bounded env43095 := by
  intro p hp
  have h : env43095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43094_43095 : H12AffineEnvironment.transform 9 272 env43094 = env43095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43094 == env43095) = true)

theorem identity43095 : scanCanonicalize (H12AffineFastState.compose env43095 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43095 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43096 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2113,120,2129,81,34,2064,2129,100,80,2049,33,17,3,121,64,2128,2064,2113,2129,21,113,116,112,2129,513]

theorem envBound43096 : H12AffineFastState.Bounded env43096 := by
  intro p hp
  have h : env43096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43095_43096 : H12AffineEnvironment.transform 7 117 env43095 = env43096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43095 == env43096) = true)

def env43097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,21762,8328,64,215366,115150,140365,303452,241742,499098,257,254131,196886,169881]

theorem envBound43097 : H12AffineFastState.Bounded env43097 := by
  intro p hp
  have h : env43097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43069_43097 : H12AffineEnvironment.transform 20 4161 env43069 = env43097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43069 == env43097) = true)

theorem identity43097 : scanCanonicalize (H12AffineFastState.compose env43097 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound43097 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,412109,155997,21762,8328,64,215366,79130,140365,284040,214170,485710,257,201831,196886,156493]

theorem envBound43098 : H12AffineFastState.Bounded env43098 := by
  intro p hp
  have h : env43098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43097_43098 : H12AffineEnvironment.transform 14 29908 env43097 = env43098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env43097 == env43098) = true)

def env43099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,411973,155997,21762,8192,64,215366,79130,140365,283904,214034,485710,257,201831,196886,156493]

theorem envBound43099 : H12AffineFastState.Bounded env43099 := by
  intro p hp
  have h : env43099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43098_43099 : H12AffineEnvironment.transform 6 8 env43098 = env43099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43098 == env43099) = true)

theorem identity43099 : scanCanonicalize (H12AffineFastState.compose env43099 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43099 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env43100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1025,8541,4161,400453,144477,2,8192,64,203846,79130,140365,262144,200978,474190,257,201831,196886,144973]

theorem envBound43100 : H12AffineFastState.Bounded env43100 := by
  intro p hp
  have h : env43100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43099_43100 : H12AffineEnvironment.transform 13 5376 env43099 = env43100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43099 == env43100) = true)

theorem identity43100 : scanCanonicalize (H12AffineFastState.compose env43100 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound43100 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,76159,1025,8541,4161,210234,144477,2,8192,64,203846,79130,140365,76159,200978,136497,257,201831,196886,144973]

theorem envBound43101 : H12AffineFastState.Bounded env43101 := by
  intro p hp
  have h : env43101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43100_43101 : H12AffineEnvironment.transform 17 76159 env43100 = env43101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env43100 == env43101) = true)

theorem identity43101 : scanCanonicalize (H12AffineFastState.compose env43101 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound43101 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env43102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13389,76159,1025,8541,4161,65911,16,2,8192,64,75787,79130,4096,76159,75103,8572,257,73770,79195,512]

theorem envBound43102 : H12AffineFastState.Bounded env43102 := by
  intro p hp
  have h : env43102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43101_43102 : H12AffineEnvironment.transform 16 13389 env43101 = env43102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env43101 == env43102) = true)

theorem identity43102 : scanCanonicalize (H12AffineFastState.compose env43102 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 1298) := by decide +kernel

theorem selectedBound43102 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,1298,13389,11373,1025,8541,4161,1125,16,2,8192,64,11545,12296,4096,11373,8269,8572,257,9528,12361,512]

theorem envBound43103 : H12AffineFastState.Bounded env43103 := by
  intro p hp
  have h : env43103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43102_43103 : H12AffineEnvironment.transform 15 1298 env43102 = env43103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1298 env43102 == env43103) = true)

theorem identity43103 : scanCanonicalize (H12AffineFastState.compose env43103 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound43103 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env43104 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,8192,4144,8540,34,12669,10589,305,8541,4161,341,16,2,8192,64,10281,12296,4096,10589,8269,8572,257,8200,12361,512]

theorem envBound43104 : H12AffineFastState.Bounded env43104 := by
  intro p hp
  have h : env43104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43103_43104 : H12AffineEnvironment.transform 9 304 env43103 = env43104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env43103 == env43104) = true)

theorem identity43104 : scanCanonicalize (H12AffineFastState.compose env43104 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound43104 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env43105 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,300,4144,112,34,4177,2161,305,113,4161,341,16,2,300,64,2309,4388,4096,2161,353,80,257,292,4453,512]

theorem envBound43105 : H12AffineFastState.Bounded env43105 := by
  intro p hp
  have h : env43105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43104_43105 : H12AffineEnvironment.transform 12 300 env43104 = env43105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env43104 == env43105) = true)

theorem identity43105 : scanCanonicalize (H12AffineFastState.compose env43105 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43105 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43106 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,300,4144,33,34,4096,2080,305,32,4112,260,16,2,300,17,2309,4388,4096,2080,304,1,257,292,4404,512]

theorem envBound43106 : H12AffineFastState.Bounded env43106 := by
  intro p hp
  have h : env43106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43105_43106 : H12AffineEnvironment.transform 5 17 env43105 = env43106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43105 == env43106) = true)

theorem identity43106 : scanCanonicalize (H12AffineFastState.compose env43106 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43106 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env43107 : List Nat := [2,4,8,16,32,17,8,37,512,21,2048,4096,9,4144,33,34,4096,2080,20,32,4112,33,16,2,9,17,2080,4097,4096,2080,21,1,36,1,4113,512]

theorem envBound43107 : H12AffineFastState.Bounded env43107 := by
  intro p hp
  have h : env43107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43106_43107 : H12AffineEnvironment.transform 7 37 env43106 = env43107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43106 == env43107) = true)

theorem identity43107 : scanCanonicalize (H12AffineFastState.compose env43107 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43107 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43108 : List Nat := [2,4,8,16,11,17,8,14,512,21,2048,4096,9,4123,10,9,4096,2059,20,11,4112,10,16,2,9,17,2059,4097,4096,2059,21,1,15,1,4113,512]

theorem envBound43108 : H12AffineFastState.Bounded env43108 := by
  intro p hp
  have h : env43108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43107_43108 : H12AffineEnvironment.transform 4 11 env43107 = env43108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43107 == env43108) = true)

theorem identity43108 : scanCanonicalize (H12AffineFastState.compose env43108 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43108 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43109 : List Nat := [2,4,8,10,11,11,8,14,512,15,2048,4096,9,4097,10,9,4096,2059,14,11,4106,10,10,2,9,11,2059,4097,4096,2059,15,1,15,1,4107,512]

theorem envBound43109 : H12AffineFastState.Bounded env43109 := by
  intro p hp
  have h : env43109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43108_43109 : H12AffineEnvironment.transform 3 10 env43108 = env43109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43108 == env43109) = true)

theorem identity43109 : scanCanonicalize (H12AffineFastState.compose env43109 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound43109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43110 : List Nat := [2,4,8,10,11,11,8,14,512,15,2048,11,9,10,10,9,11,2059,14,11,1,10,10,2,9,11,2059,10,11,2059,15,1,15,1,0,512]

theorem envBound43110 : H12AffineFastState.Bounded env43110 := by
  intro p hp
  have h : env43110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43109_43110 : H12AffineEnvironment.transform 11 11 env43109 = env43110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env43109 == env43110) = true)

theorem identity43110 : scanCanonicalize (H12AffineFastState.compose env43110 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43110 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env43111 : List Nat := [2,4,1,3,2,2,1,7,512,6,2048,2,0,3,3,0,2,2050,7,2,1,3,3,2,0,2,2050,3,2,2050,6,1,6,1,0,512]

theorem envBound43111 : H12AffineFastState.Bounded env43111 := by
  intro p hp
  have h : env43111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43110_43111 : H12AffineEnvironment.transform 2 1 env43110 = env43111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43110 == env43111) = true)

theorem identity43111 : scanCanonicalize (H12AffineFastState.compose env43111 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound43111 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43112 : List Nat := [2,4,1,3,2,2,1,7,512,6,5,2,0,3,3,0,2,7,7,2,1,3,3,2,0,2,7,3,2,7,6,1,6,1,0,512]

theorem envBound43112 : H12AffineFastState.Bounded env43112 := by
  intro p hp
  have h : env43112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43111_43112 : H12AffineEnvironment.transform 10 5 env43111 = env43112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env43111 == env43112) = true)

theorem identity43112 : scanCanonicalize (H12AffineFastState.compose env43112 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43112 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env43113 : List Nat := [1,4,1,0,1,1,1,4,512,5,5,1,0,0,0,0,1,4,4,1,1,0,0,1,0,1,4,0,1,4,5,1,5,1,0,512]

theorem envBound43113 : H12AffineFastState.Bounded env43113 := by
  intro p hp
  have h : env43113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43112_43113 : H12AffineEnvironment.transform 0 1 env43112 = env43113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43112 == env43113) = true)

theorem identity43113 : scanCanonicalize (H12AffineFastState.compose env43113 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43113 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43114 : List Nat := [1,1,1,0,1,1,1,1,512,0,0,1,0,0,0,0,1,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,1,0,512]

theorem envBound43114 : H12AffineFastState.Bounded env43114 := by
  intro p hp
  have h : env43114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43113_43114 : H12AffineEnvironment.transform 1 1 env43113 = env43114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43113 == env43114) = true)

theorem identity43114 : scanCanonicalize (H12AffineFastState.compose env43114 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43114 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43115 : List Nat := [1,1,1,0,1,1,1,1,1,0,0,1,0,0,0,0,1,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,0,1,0,1]

theorem envBound43115 : H12AffineFastState.Bounded env43115 := by
  intro p hp
  have h : env43115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43114_43115 : H12AffineEnvironment.transform 8 1 env43114 = env43115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43114 == env43115) = true)

def env43116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,411972,155997,21762,8193,64,215366,79130,140365,283905,214035,485710,257,201831,196886,156493]

theorem envBound43116 : H12AffineFastState.Bounded env43116 := by
  intro p hp
  have h : env43116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43098_43116 : H12AffineEnvironment.transform 6 9 env43098 = env43116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43098 == env43116) = true)

theorem identity43116 : scanCanonicalize (H12AffineFastState.compose env43116 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43116 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env43117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,262144,1025,29788,4161,411972,155997,21762,8193,64,158029,5393,140365,283905,156696,411973,257,144492,139549,156493]

theorem envBound43117 : H12AffineFastState.Bounded env43117 := by
  intro p hp
  have h : env43117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43116_43117 : H12AffineEnvironment.transform 15 8203 env43116 = env43117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43116 == env43117) = true)

theorem identity43117 : scanCanonicalize (H12AffineFastState.compose env43117 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound43117 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,2340,1025,29788,4161,147552,155997,21762,8193,64,158029,5393,140365,23589,156696,147553,257,144492,139549,156493]

theorem envBound43118 : H12AffineFastState.Bounded env43118 := by
  intro p hp
  have h : env43118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43117_43118 : H12AffineEnvironment.transform 17 2340 env43117 = env43118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env43117 == env43118) = true)

theorem identity43118 : scanCanonicalize (H12AffineFastState.compose env43118 (packedSelected [1,7,8,12,14,15,16,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound43118 : packedSelected [1,7,8,12,14,15,16,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env43119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,292,8203,131072,2340,1025,293,4161,144665,136228,8315,8193,64,138292,5393,140365,10588,135521,144664,257,144492,139549,136756]

theorem envBound43119 : H12AffineFastState.Bounded env43119 := by
  intro p hp
  have h : env43119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43118_43119 : H12AffineEnvironment.transform 13 13689 env43118 = env43119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env43118 == env43119) = true)

theorem identity43119 : scanCanonicalize (H12AffineFastState.compose env43119 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(16+1) ^^^ 13641) := by decide +kernel

theorem selectedBound43119 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env43120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,292,8203,13641,2340,1025,293,4161,80,8557,8315,8193,64,10621,5393,4356,10588,9256,81,257,293,5204,9085]

theorem envBound43120 : H12AffineFastState.Bounded env43120 := by
  intro p hp
  have h : env43120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43119_43120 : H12AffineEnvironment.transform 16 13641 env43119 = env43120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13641 env43119 == env43120) = true)

theorem identity43120 : scanCanonicalize (H12AffineFastState.compose env43120 (packedSelected [0,1,3,4,5,6,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43120 : packedSelected [0,1,3,4,5,6,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env43121 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8192,13437,32,8203,13389,2080,1025,33,4161,80,8297,8315,8193,64,10361,5141,4096,10328,9256,81,5,33,5204,8825]

theorem envBound43121 : H12AffineFastState.Bounded env43121 := by
  intro p hp
  have h : env43121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43120_43121 : H12AffineEnvironment.transform 7 4 env43120 = env43121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43120 == env43121) = true)

theorem identity43121 : scanCanonicalize (H12AffineFastState.compose env43121 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43121 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43122 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8192,13357,32,8203,13341,2080,1025,33,4113,0,8249,8235,8193,16,10281,5141,4096,10248,9256,1,5,33,5124,8745]

theorem envBound43122 : H12AffineFastState.Bounded env43122 := by
  intro p hp
  have h : env43122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43121_43122 : H12AffineEnvironment.transform 5 16 env43121 = env43122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43121 == env43122) = true)

theorem identity43122 : scanCanonicalize (H12AffineFastState.compose env43122 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound43122 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43123 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,2088,7173,32,2083,7221,2080,1025,33,4113,0,2065,2051,2089,16,1,5141,4096,32,3072,1,5,33,5124,2561]

theorem envBound43123 : H12AffineFastState.Bounded env43123 := by
  intro p hp
  have h : env43123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43122_43123 : H12AffineEnvironment.transform 12 2088 env43122 = env43123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env43122 == env43123) = true)

theorem identity43123 : scanCanonicalize (H12AffineFastState.compose env43123 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound43123 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env43124 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,3109,2088,32,32,2083,16,2080,1025,33,3124,0,2065,2051,2089,16,1,2096,3109,32,3072,1,5,33,2081,2561]

theorem envBound43124 : H12AffineFastState.Bounded env43124 := by
  intro p hp
  have h : env43124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43123_43124 : H12AffineEnvironment.transform 11 3109 env43123 = env43124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env43123 == env43124) = true)

theorem identity43124 : scanCanonicalize (H12AffineFastState.compose env43124 (packedSelected [4,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43124 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43125 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,3076,2057,1,1,2050,16,2049,1025,0,3093,0,2065,2051,2056,16,1,2065,3076,1,3072,1,5,0,2048,2561]

theorem envBound43125 : H12AffineFastState.Bounded env43125 := by
  intro p hp
  have h : env43125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43124_43125 : H12AffineEnvironment.transform 4 1 env43124 = env43125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43124 == env43125) = true)

theorem identity43125 : scanCanonicalize (H12AffineFastState.compose env43125 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound43125 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env43126 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1044,16,1053,1,1,1046,16,1045,1025,0,1,0,1029,1047,1052,16,1,1029,16,1,20,1,5,0,1044,1557]

theorem envBound43126 : H12AffineFastState.Bounded env43126 := by
  intro p hp
  have h : env43126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43125_43126 : H12AffineEnvironment.transform 10 1044 env43125 = env43126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env43125 == env43126) = true)

def env43127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155997,2114883,8328,64,215367,115150,2241548,303452,2334735,2592218,257,254131,196886,2263000]

theorem envBound43127 : H12AffineFastState.Bounded env43127 := by
  intro p hp
  have h : env43127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43068_43127 : H12AffineEnvironment.transform 21 2534745 env43068 = env43127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env43068 == env43127) = true)

def env43128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,21763,8328,64,215367,115150,140364,303452,241743,499098,257,254131,196886,169880]

theorem envBound43128 : H12AffineFastState.Bounded env43128 := by
  intro p hp
  have h : env43128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43127_43128 : H12AffineEnvironment.transform 20 4160 env43127 = env43128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43127 == env43128) = true)

def env43129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169265,155997,21763,8328,64,215367,115150,140364,35188,241743,243122,257,254131,196886,169880]

theorem envBound43129 : H12AffineFastState.Bounded env43129 := by
  intro p hp
  have h : env43129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43128_43129 : H12AffineEnvironment.transform 17 10280 env43128 = env43129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43128 == env43129) = true)

def env43130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21793,41293,21763,8328,64,100695,115150,58460,35188,94303,95650,257,73891,114950,22408]

theorem envBound43130 : H12AffineFastState.Bounded env43130 := by
  intro p hp
  have h : env43130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43129_43130 : H12AffineEnvironment.transform 16 49168 env43129 = env43130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43129 == env43130) = true)

theorem identity43130 : scanCanonicalize (H12AffineFastState.compose env43130 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound43130 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10280,1025,8540,4160,21793,16,21763,8328,64,75786,90259,17665,10281,94303,95650,257,73891,90203,22408]

theorem envBound43131 : H12AffineFastState.Bounded env43131 := by
  intro p hp
  have h : env43131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43130_43131 : H12AffineEnvironment.transform 14 8541 env43130 = env43131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env43130 == env43131) = true)

theorem identity43131 : scanCanonicalize (H12AffineFastState.compose env43131 (packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 9447) := by decide +kernel

theorem selectedBound43131 : packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env43132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,9447,24909,10280,1025,8540,4160,21793,16,21763,8328,64,3309,17524,17665,10281,21688,20805,257,1092,17596,22408]

theorem envBound43132 : H12AffineFastState.Bounded env43132 := by
  intro p hp
  have h : env43132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43131_43132 : H12AffineEnvironment.transform 15 9447 env43131 = env43132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9447 env43131 == env43132) = true)

theorem identity43132 : scanCanonicalize (H12AffineFastState.compose env43132 (packedSelected [0,2,3,5,6,7,8,11,18,19,20,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound43132 : packedSelected [0,2,3,5,6,7,8,11,18,19,20,26,28] rootPS < 2^1333 := by decide +kernel

def env43133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8541,9447,13673,10280,1025,8540,4160,261,16,295,8328,64,3309,4176,4389,10281,156,1377,257,1092,4248,940]

theorem envBound43133 : H12AffineFastState.Bounded env43133 := by
  intro p hp
  have h : env43133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43132_43133 : H12AffineEnvironment.transform 13 5156 env43132 = env43133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env43132 == env43133) = true)

theorem identity43133 : scanCanonicalize (H12AffineFastState.compose env43133 (packedSelected [0,1,3,4,5,7,8,10,12,15,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound43133 : packedSelected [0,1,3,4,5,7,8,10,12,15,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env43134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5156,508,1094,5576,2185,1025,509,4160,261,16,295,41,64,3309,4176,4389,2184,156,1377,257,1092,4248,940]

theorem envBound43134 : H12AffineFastState.Bounded env43134 := by
  intro p hp
  have h : env43134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43133_43134 : H12AffineEnvironment.transform 12 161 env43133 = env43134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env43133 == env43134) = true)

theorem identity43134 : scanCanonicalize (H12AffineFastState.compose env43134 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound43134 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43135 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,161,4541,508,479,4177,2185,408,509,4160,261,16,295,41,64,2420,4176,4389,2184,156,248,257,477,4248,940]

theorem envBound43135 : H12AffineFastState.Bounded env43135 := by
  intro p hp
  have h : env43135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43134_43135 : H12AffineEnvironment.transform 9 409 env43134 = env43135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env43134 == env43135) = true)

theorem identity43135 : scanCanonicalize (H12AffineFastState.compose env43135 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43135 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43136 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,40,4404,373,342,4177,2048,273,372,4160,261,16,295,41,64,2420,4176,4389,2049,21,113,257,340,4113,805]

theorem envBound43136 : H12AffineFastState.Bounded env43136 := by
  intro p hp
  have h : env43136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43135_43136 : H12AffineEnvironment.transform 6 9 env43135 = env43136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43135 == env43136) = true)

theorem identity43136 : scanCanonicalize (H12AffineFastState.compose env43136 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43136 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43137 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,40,4161,0,35,4177,2048,100,1,4160,112,16,82,41,64,2049,4176,4176,2049,21,113,116,33,4113,592]

theorem envBound43137 : H12AffineFastState.Bounded env43137 := by
  intro p hp
  have h : env43137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43136_43137 : H12AffineEnvironment.transform 7 117 env43136 = env43137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43136 == env43137) = true)

theorem identity43137 : scanCanonicalize (H12AffineFastState.compose env43137 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43137 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43138 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4112,0,35,4096,2048,53,1,4113,33,16,3,41,17,2049,4097,4097,2049,21,32,37,33,4113,513]

theorem envBound43138 : H12AffineFastState.Bounded env43138 := by
  intro p hp
  have h : env43138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43137_43138 : H12AffineEnvironment.transform 5 17 env43137 = env43138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43137 == env43138) = true)

theorem identity43138 : scanCanonicalize (H12AffineFastState.compose env43138 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43138 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43139 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,1,40,17,0,35,1,2048,53,1,16,33,16,3,41,17,2049,0,0,2049,21,32,37,33,16,513]

theorem envBound43139 : H12AffineFastState.Bounded env43139 := by
  intro p hp
  have h : env43139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43138_43139 : H12AffineEnvironment.transform 11 1 env43138 = env43139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43138 == env43139) = true)

theorem identity43139 : scanCanonicalize (H12AffineFastState.compose env43139 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound43139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43140 : List Nat := [2,4,8,16,32,17,9,36,512,52,555,1,40,17,0,35,1,555,53,1,16,33,16,3,41,17,554,0,0,554,21,32,37,33,16,513]

theorem envBound43140 : H12AffineFastState.Bounded env43140 := by
  intro p hp
  have h : env43140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43139_43140 : H12AffineEnvironment.transform 10 555 env43139 = env43140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env43139 == env43140) = true)

def env43141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21792,41292,21763,8328,64,100694,115150,58461,35188,94302,95651,257,73890,114951,22409]

theorem envBound43141 : H12AffineFastState.Bounded env43141 := by
  intro p hp
  have h : env43141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43129_43141 : H12AffineEnvironment.transform 16 49169 env43129 = env43141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43129 == env43141) = true)

theorem identity43141 : scanCanonicalize (H12AffineFastState.compose env43141 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound43141 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1025,8661,4160,21792,152,21763,8328,64,75906,90138,17801,10400,94302,95651,257,73890,90323,22409]

theorem envBound43142 : H12AffineFastState.Bounded env43142 := by
  intro p hp
  have h : env43142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43141_43142 : H12AffineEnvironment.transform 14 8660 env43141 = env43142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env43141 == env43142) = true)

theorem identity43142 : scanCanonicalize (H12AffineFastState.compose env43142 (packedSelected [2,4,6,11,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound43142 : packedSelected [2,4,6,11,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env43143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8660,65536,13625,10280,1025,8661,4160,476,152,511,8328,64,75906,79078,4469,10400,74914,74079,257,73890,78895,885]

theorem envBound43143 : H12AffineFastState.Bounded env43143 := by
  intro p hp
  have h : env43143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43142_43143 : H12AffineEnvironment.transform 13 5372 env43142 = env43143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env43142 == env43143) = true)

theorem identity43143 : scanCanonicalize (H12AffineFastState.compose env43143 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43143 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43144 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,8192,4297,8660,65536,12556,10280,52,8661,4160,476,152,511,8328,64,75906,78035,4469,10400,73879,74079,257,73890,77850,885]

theorem envBound43144 : H12AffineFastState.Bounded env43144 := by
  intro p hp
  have h : env43144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43143_43144 : H12AffineEnvironment.transform 9 53 env43143 = env43144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43143 == env43144) = true)

theorem identity43144 : scanCanonicalize (H12AffineFastState.compose env43144 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound43144 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env43145 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,8192,4297,8660,478,12556,10280,52,8661,4160,476,152,511,8328,64,10588,12557,4469,10400,8521,8321,257,8572,12740,885]

theorem envBound43145 : H12AffineFastState.Bounded env43145 := by
  intro p hp
  have h : env43145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43144_43145 : H12AffineEnvironment.transform 15 478 env43144 = env43145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env43144 == env43145) = true)

theorem identity43145 : scanCanonicalize (H12AffineFastState.compose env43145 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound43145 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43146 : List Nat := [2,4,8,16,32,64,128,173,512,53,2048,4096,8192,4297,8313,115,12449,10280,52,8312,4160,113,152,82,8328,64,10481,12448,4312,10400,8420,8321,172,8401,12393,728]

theorem envBound43146 : H12AffineFastState.Bounded env43146 := by
  intro p hp
  have h : env43146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43145_43146 : H12AffineEnvironment.transform 7 173 env43145 = env43146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43145 == env43146) = true)

theorem identity43146 : scanCanonicalize (H12AffineFastState.compose env43146 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43146 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env43147 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,8192,4161,8313,115,12329,10280,52,8312,4160,113,16,82,8192,64,10361,12328,4176,10280,8300,8201,36,8281,12393,592]

theorem envBound43147 : H12AffineFastState.Bounded env43147 := by
  intro p hp
  have h : env43147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43146_43147 : H12AffineEnvironment.transform 6 8 env43146 = env43147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43146 == env43147) = true)

theorem identity43147 : scanCanonicalize (H12AffineFastState.compose env43147 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound43147 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env43148 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,65,8192,0,8313,115,8296,10280,52,8312,1,113,16,82,8192,64,10361,8297,17,10280,8300,8201,36,8281,8232,592]

theorem envBound43148 : H12AffineFastState.Bounded env43148 := by
  intro p hp
  have h : env43148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43147_43148 : H12AffineEnvironment.transform 11 65 env43147 = env43148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env43147 == env43148) = true)

theorem identity43148 : scanCanonicalize (H12AffineFastState.compose env43148 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43148 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env43149 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,65,40,0,81,115,64,2048,52,80,1,113,16,82,40,64,2129,65,17,2048,68,33,36,113,0,592]

theorem envBound43149 : H12AffineFastState.Bounded env43149 := by
  intro p hp
  have h : env43149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43148_43149 : H12AffineEnvironment.transform 12 40 env43148 = env43149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43148 == env43149) = true)

theorem identity43149 : scanCanonicalize (H12AffineFastState.compose env43149 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound43149 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43150 : List Nat := [2,4,8,16,32,64,8,37,512,53,112,65,40,0,81,115,64,112,52,80,1,113,16,82,40,64,33,65,17,112,68,33,36,113,0,592]

theorem envBound43150 : H12AffineFastState.Bounded env43150 := by
  intro p hp
  have h : env43150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43149_43150 : H12AffineEnvironment.transform 10 112 env43149 = env43150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env43149 == env43150) = true)

theorem identity43150 : scanCanonicalize (H12AffineFastState.compose env43150 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound43150 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43151 : List Nat := [2,4,8,16,32,64,8,37,97,53,112,65,40,0,81,115,64,112,52,80,1,113,16,82,40,64,33,65,17,112,68,33,36,113,0,49]

theorem envBound43151 : H12AffineFastState.Bounded env43151 := by
  intro p hp
  have h : env43151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43150_43151 : H12AffineEnvironment.transform 8 97 env43150 = env43151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env43150 == env43151) = true)

theorem identity43151 : scanCanonicalize (H12AffineFastState.compose env43151 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43151 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43152 : List Nat := [2,4,8,16,17,64,8,20,80,4,65,65,25,0,81,66,64,65,5,80,1,64,16,82,25,64,16,65,17,65,68,16,21,64,0,0]

theorem envBound43152 : H12AffineFastState.Bounded env43152 := by
  intro p hp
  have h : env43152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43151_43152 : H12AffineEnvironment.transform 4 17 env43151 = env43152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43151 == env43152) = true)

theorem identity43152 : scanCanonicalize (H12AffineFastState.compose env43152 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound43152 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43153 : List Nat := [2,4,8,16,17,0,8,20,16,4,1,1,25,0,17,2,0,1,5,16,1,0,16,18,25,0,16,1,17,1,4,16,21,0,0,0]

theorem envBound43153 : H12AffineFastState.Bounded env43153 := by
  intro p hp
  have h : env43153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43152_43153 : H12AffineEnvironment.transform 5 0 env43152 = env43153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43152 == env43153) = true)

theorem identity43153 : scanCanonicalize (H12AffineFastState.compose env43153 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43154 : List Nat := [2,4,8,0,1,0,8,4,0,4,1,1,9,0,1,2,0,1,5,0,1,0,0,2,9,0,0,1,1,1,4,0,5,0,0,0]

theorem envBound43154 : H12AffineFastState.Bounded env43154 := by
  intro p hp
  have h : env43154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43153_43154 : H12AffineEnvironment.transform 3 0 env43153 = env43154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43153 == env43154) = true)

theorem identity43154 : scanCanonicalize (H12AffineFastState.compose env43154 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43154 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43155 : List Nat := [2,0,8,0,1,0,8,0,0,0,1,1,9,0,1,2,0,1,1,0,1,0,0,2,9,0,0,1,1,1,0,0,1,0,0,0]

theorem envBound43155 : H12AffineFastState.Bounded env43155 := by
  intro p hp
  have h : env43155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43154_43155 : H12AffineEnvironment.transform 1 0 env43154 = env43155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43154 == env43155) = true)

theorem identity43155 : scanCanonicalize (H12AffineFastState.compose env43155 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound43155 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43156 : List Nat := [2,0,0,0,1,0,0,0,0,0,1,1,1,0,1,2,0,1,1,0,1,0,0,2,1,0,0,1,1,1,0,0,1,0,0,0]

theorem envBound43156 : H12AffineFastState.Bounded env43156 := by
  intro p hp
  have h : env43156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43155_43156 : H12AffineEnvironment.transform 2 0 env43155 = env43156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env43155 == env43156) = true)

theorem identity43156 : scanCanonicalize (H12AffineFastState.compose env43156 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43156 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43157 : List Nat := [0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,0,0,1,1,0,1,0,0,0,1,0,0,1,1,1,0,0,1,0,0,0]

theorem envBound43157 : H12AffineFastState.Bounded env43157 := by
  intro p hp
  have h : env43157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43156_43157 : H12AffineEnvironment.transform 0 0 env43156 = env43157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43156 == env43157) = true)

def env43158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169264,155997,21763,8328,64,215367,115150,140364,35189,241743,243123,257,254131,196886,169880]

theorem envBound43158 : H12AffineFastState.Bounded env43158 := by
  intro p hp
  have h : env43158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43128_43158 : H12AffineEnvironment.transform 17 10281 env43128 = env43158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43128 == env43158) = true)

def env43159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21792,41293,21763,8328,64,100695,115150,58460,35189,94303,95651,257,73891,114950,22408]

theorem envBound43159 : H12AffineFastState.Bounded env43159 := by
  intro p hp
  have h : env43159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43158_43159 : H12AffineEnvironment.transform 16 49168 env43158 = env43159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43158 == env43159) = true)

theorem identity43159 : scanCanonicalize (H12AffineFastState.compose env43159 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound43159 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21511,49168,10281,1025,32769,4160,21792,41293,21763,8328,64,56656,38345,58460,35189,9304,8612,257,29860,38145,22408]

theorem envBound43160 : H12AffineFastState.Bounded env43160 := by
  intro p hp
  have h : env43160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43159_43160 : H12AffineEnvironment.transform 15 21511 env43159 = env43160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env43159 == env43160) = true)

theorem identity43160 : scanCanonicalize (H12AffineFastState.compose env43160 (packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound43160 : packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS < 2^1333 := by decide +kernel

def env43161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,21511,16537,10281,1025,136,4160,21792,8644,21763,8328,64,24025,5440,25813,2556,9304,8612,257,29860,5512,22408]

theorem envBound43161 : H12AffineFastState.Bounded env43161 := by
  intro p hp
  have h : env43161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43160_43161 : H12AffineEnvironment.transform 14 137 env43160 = env43161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env43160 == env43161) = true)

theorem identity43161 : scanCanonicalize (H12AffineFastState.compose env43161 (packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound43161 : packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env43162 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,81,21511,16449,10281,1025,80,4160,21792,8476,21763,8272,64,23809,5440,25613,2340,9304,8572,257,29820,5456,22352]

theorem envBound43162 : H12AffineFastState.Bounded env43162 := by
  intro p hp
  have h : env43162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43161_43162 : H12AffineEnvironment.transform 6 88 env43161 = env43162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env43161 == env43162) = true)

theorem identity43162 : scanCanonicalize (H12AffineFastState.compose env43162 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43162 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env43163 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,81,21511,16449,2340,1025,80,4160,21792,17,21763,349,64,23809,5440,17664,2340,1365,113,257,21873,5456,22352]

theorem envBound43163 : H12AffineFastState.Bounded env43163 := by
  intro p hp
  have h : env43163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43162_43163 : H12AffineEnvironment.transform 12 269 env43162 = env43163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43162 == env43163) = true)

theorem identity43163 : scanCanonicalize (H12AffineFastState.compose env43163 (packedSelected [0,7,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound43163 : packedSelected [0,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env43164 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5157,81,34,5220,2340,1025,80,4160,261,17,294,349,64,2340,5440,4389,2340,1365,113,257,340,5456,885]

theorem envBound43164 : H12AffineFastState.Bounded env43164 := by
  intro p hp
  have h : env43164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43163_43164 : H12AffineEnvironment.transform 13 5157 env43163 = env43164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env43163 == env43164) = true)

theorem identity43164 : scanCanonicalize (H12AffineFastState.compose env43164 (packedSelected [2,3,4,5,6,9,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43164 : packedSelected [2,3,4,5,6,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env43165 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,41,5157,81,34,5220,2048,1025,80,4160,33,17,2,121,64,2048,5220,4097,2048,1137,113,37,112,5236,593]

theorem envBound43165 : H12AffineFastState.Bounded env43165 := by
  intro p hp
  have h : env43165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43164_43165 : H12AffineEnvironment.transform 7 36 env43164 = env43165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43164 == env43165) = true)

theorem identity43165 : scanCanonicalize (H12AffineFastState.compose env43165 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound43165 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env43166 : List Nat := [2,4,8,16,32,64,88,36,512,1024,522,4096,41,5157,81,34,5220,522,1025,80,4160,33,17,2,121,64,522,5220,4097,522,1137,113,37,112,5236,593]

theorem envBound43166 : H12AffineFastState.Bounded env43166 := by
  intro p hp
  have h : env43166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43165_43166 : H12AffineEnvironment.transform 10 522 env43165 = env43166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env43165 == env43166) = true)

theorem identity43166 : scanCanonicalize (H12AffineFastState.compose env43166 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43166 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43167 : List Nat := [2,4,8,16,32,16,8,36,512,1024,522,4096,41,5157,1,34,5172,522,1025,0,4112,33,17,2,41,16,522,5172,4097,522,1057,33,37,32,5156,513]

theorem envBound43167 : H12AffineFastState.Bounded env43167 := by
  intro p hp
  have h : env43167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43166_43167 : H12AffineEnvironment.transform 5 16 env43166 = env43167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43166 == env43167) = true)

def env43168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21793,41292,21763,8328,64,100694,115150,58461,35189,94302,95650,257,73890,114951,22409]

theorem envBound43168 : H12AffineFastState.Bounded env43168 := by
  intro p hp
  have h : env43168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43158_43168 : H12AffineEnvironment.transform 16 49169 env43158 = env43168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43158 == env43168) = true)

theorem identity43168 : scanCanonicalize (H12AffineFastState.compose env43168 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43168 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21793,41292,21763,8192,64,100694,115014,58461,35189,94302,95530,257,73770,114951,22273]

theorem envBound43169 : H12AffineFastState.Bounded env43169 := by
  intro p hp
  have h : env43169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43168_43169 : H12AffineEnvironment.transform 6 8 env43168 = env43169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43168 == env43169) = true)

theorem identity43169 : scanCanonicalize (H12AffineFastState.compose env43169 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43169 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env43170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10281,1025,8541,4160,21793,16,21763,8192,64,75786,90138,17665,10281,94302,95530,257,73770,90203,22273]

theorem envBound43170 : H12AffineFastState.Bounded env43170 := by
  intro p hp
  have h : env43170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43169_43170 : H12AffineEnvironment.transform 14 8540 env43169 = env43170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43169 == env43170) = true)

theorem identity43170 : scanCanonicalize (H12AffineFastState.compose env43170 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound43170 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env43171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,65536,5393,10281,1025,8541,4160,8573,16,8543,8192,64,75786,70726,12637,10281,66562,65910,257,73770,70663,9053]

theorem envBound43171 : H12AffineFastState.Bounded env43171 := by
  intro p hp
  have h : env43171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43170_43171 : H12AffineEnvironment.transform 13 13404 env43170 = env43171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env43170 == env43171) = true)

theorem identity43171 : scanCanonicalize (H12AffineFastState.compose env43171 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43171 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,65536,5393,2421,1025,1,4160,33,16,3,348,64,67926,70726,4097,2421,66562,65910,257,65910,70663,513]

theorem envBound43172 : H12AffineFastState.Bounded env43172 := by
  intro p hp
  have h : env43172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43171_43172 : H12AffineEnvironment.transform 12 348 env43171 = env43172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43171 == env43172) = true)

theorem identity43172 : scanCanonicalize (H12AffineFastState.compose env43172 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound43172 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env43173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,343,5393,2421,1025,1,4160,33,16,3,348,64,2049,5393,4097,2421,1365,33,257,33,5456,513]

theorem envBound43173 : H12AffineFastState.Bounded env43173 := by
  intro p hp
  have h : env43173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43172_43173 : H12AffineEnvironment.transform 15 343 env43172 = env43173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env43172 == env43173) = true)

theorem identity43173 : scanCanonicalize (H12AffineFastState.compose env43173 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound43173 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2367,348,3135,0,343,3118,2421,1025,1,2431,33,16,3,348,64,2049,3118,2366,2421,1365,33,257,33,3183,513]

theorem envBound43174 : H12AffineFastState.Bounded env43174 := by
  intro p hp
  have h : env43174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43173_43174 : H12AffineEnvironment.transform 11 2367 env43173 = env43174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env43173 == env43174) = true)

theorem identity43174 : scanCanonicalize (H12AffineFastState.compose env43174 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound43174 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43175 : List Nat := [2,4,8,16,32,64,8,256,512,127,2048,2367,348,2112,0,343,2129,2421,126,1,2431,33,16,3,348,64,2049,2129,2366,2421,298,33,257,33,2064,513]

theorem envBound43175 : H12AffineFastState.Bounded env43175 := by
  intro p hp
  have h : env43175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43174_43175 : H12AffineEnvironment.transform 9 127 env43174 = env43175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env43174 == env43175) = true)

theorem identity43175 : scanCanonicalize (H12AffineFastState.compose env43175 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43175 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env43176 : List Nat := [2,4,8,16,32,64,8,36,512,127,2048,2075,120,2112,0,115,2129,2129,126,1,2139,33,16,3,120,64,2049,2129,2074,2129,14,33,37,33,2064,513]

theorem envBound43176 : H12AffineFastState.Bounded env43176 := by
  intro p hp
  have h : env43176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43175_43176 : H12AffineEnvironment.transform 7 36 env43175 = env43176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43175 == env43176) = true)

theorem identity43176 : scanCanonicalize (H12AffineFastState.compose env43176 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound43176 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43177 : List Nat := [2,4,8,16,32,64,8,36,512,127,17,10,120,81,0,115,64,64,126,1,74,33,16,3,120,64,16,64,11,64,14,33,37,33,1,513]

theorem envBound43177 : H12AffineFastState.Bounded env43177 := by
  intro p hp
  have h : env43177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43176_43177 : H12AffineEnvironment.transform 10 17 env43176 = env43177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env43176 == env43177) = true)

theorem identity43177 : scanCanonicalize (H12AffineFastState.compose env43177 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound43177 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43178 : List Nat := [2,4,8,16,32,43,8,36,512,20,17,10,19,58,0,24,43,43,21,1,33,33,16,3,19,43,16,43,11,43,14,33,37,33,1,513]

theorem envBound43178 : H12AffineFastState.Bounded env43178 := by
  intro p hp
  have h : env43178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43177_43178 : H12AffineEnvironment.transform 5 43 env43177 = env43178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env43177 == env43178) = true)

def env43179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,21762,8328,64,215367,115150,140365,303452,241742,499099,257,254131,196886,169881]

theorem envBound43179 : H12AffineFastState.Bounded env43179 := by
  intro p hp
  have h : env43179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43127_43179 : H12AffineEnvironment.transform 20 4161 env43127 = env43179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43127 == env43179) = true)

theorem identity43179 : scanCanonicalize (H12AffineFastState.compose env43179 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound43179 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,272512,62661,21762,8328,64,122079,115150,45525,303452,75222,329731,257,95531,103566,513]

theorem envBound43180 : H12AffineFastState.Bounded env43180 := by
  intro p hp
  have h : env43180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43179_43180 : H12AffineEnvironment.transform 16 38296 env43179 = env43180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env43179 == env43180) = true)

def env43181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272392,62541,21762,8192,64,121943,115014,45405,303452,75102,329731,257,95531,103430,513]

theorem envBound43181 : H12AffineFastState.Bounded env43181 := by
  intro p hp
  have h : env43181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43180_43181 : H12AffineEnvironment.transform 6 8 env43180 = env43181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43180 == env43181) = true)

def env43182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,32,62541,21762,8192,64,121943,115014,45405,35188,75102,73771,257,95531,103430,513]

theorem envBound43182 : H12AffineFastState.Bounded env43182 := by
  intro p hp
  have h : env43182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43181_43182 : H12AffineEnvironment.transform 17 10280 env43181 = env43182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43181 == env43182) = true)

theorem identity43182 : scanCanonicalize (H12AffineFastState.compose env43182 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound43182 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,24909,10280,1025,29788,4161,32,16,21762,8192,64,75786,79131,17664,32041,75102,73771,257,95531,90203,513]

theorem envBound43183 : H12AffineFastState.Bounded env43183 := by
  intro p hp
  have h : env43183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43182_43183 : H12AffineEnvironment.transform 14 29789 env43182 = env43183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env43182 == env43183) = true)

theorem identity43183 : scanCanonicalize (H12AffineFastState.compose env43183 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 12363) := by decide +kernel

theorem selectedBound43183 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env43184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,12363,24909,10280,1025,29788,4161,32,16,21762,8192,64,6209,1360,17664,32041,5397,4192,257,17760,20496,513]

theorem envBound43184 : H12AffineFastState.Bounded env43184 := by
  intro p hp
  have h : env43184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43183_43184 : H12AffineEnvironment.transform 15 12363 env43183 = env43184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12363 env43183 == env43184) = true)

theorem identity43184 : scanCanonicalize (H12AffineFastState.compose env43184 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound43184 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,16384,17728,342,20560,6453,1025,17729,4161,32,16,21762,4381,64,6209,1360,17664,19508,5397,4192,257,17760,20496,513]

theorem envBound43185 : H12AffineFastState.Bounded env43185 := by
  intro p hp
  have h : env43185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43184_43185 : H12AffineEnvironment.transform 12 4381 env43184 = env43185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env43184 == env43185) = true)

theorem identity43185 : scanCanonicalize (H12AffineFastState.compose env43185 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43185 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,5376,4160,342,1360,6453,1025,4161,4161,32,16,2,4381,64,6209,1360,4096,6452,5397,4192,257,4192,1296,513]

theorem envBound43186 : H12AffineFastState.Bounded env43186 := by
  intro p hp
  have h : env43186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43185_43186 : H12AffineEnvironment.transform 13 5376 env43185 = env43186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43185 == env43186) = true)

theorem identity43186 : scanCanonicalize (H12AffineFastState.compose env43186 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound43186 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1360,1101,80,1296,342,1360,3173,1025,1297,1297,32,16,2,1101,64,3345,1360,1360,3172,69,1328,257,1328,1296,513]

theorem envBound43187 : H12AffineFastState.Bounded env43187 := by
  intro p hp
  have h : env43187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43186_43187 : H12AffineEnvironment.transform 11 1360 env43186 = env43187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env43186 == env43187) = true)

theorem identity43187 : scanCanonicalize (H12AffineFastState.compose env43187 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound43187 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env43188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,1360,1101,80,1296,342,1360,293,1025,1297,1297,32,16,2,1101,64,81,1360,1360,292,69,1328,257,1328,1296,513]

theorem envBound43188 : H12AffineFastState.Bounded env43188 := by
  intro p hp
  have h : env43188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43187_43188 : H12AffineEnvironment.transform 10 1344 env43187 = env43188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env43187 == env43188) = true)

theorem identity43188 : scanCanonicalize (H12AffineFastState.compose env43188 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound43188 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env43189 : List Nat := [2,4,8,16,32,64,8,256,512,321,1,17,268,80,81,342,17,293,320,80,80,32,16,2,268,64,81,17,17,292,69,113,257,113,81,513]

theorem envBound43189 : H12AffineFastState.Bounded env43189 := by
  intro p hp
  have h : env43189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43188_43189 : H12AffineEnvironment.transform 9 321 env43188 = env43189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43188 == env43189) = true)

theorem identity43189 : scanCanonicalize (H12AffineFastState.compose env43189 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43189 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43190 : List Nat := [2,4,8,16,32,16,8,256,512,273,1,17,268,0,1,262,17,293,272,0,0,32,16,2,268,16,1,17,17,292,21,33,257,33,1,513]

theorem envBound43190 : H12AffineFastState.Bounded env43190 := by
  intro p hp
  have h : env43190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43189_43190 : H12AffineEnvironment.transform 5 16 env43189 = env43190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43189 == env43190) = true)

theorem identity43190 : scanCanonicalize (H12AffineFastState.compose env43190 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound43190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43191 : List Nat := [2,4,8,16,32,16,8,20,512,5,1,17,24,0,1,18,17,49,4,0,0,32,16,2,24,16,1,17,17,48,21,33,21,33,1,513]

theorem envBound43191 : H12AffineFastState.Bounded env43191 := by
  intro p hp
  have h : env43191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43190_43191 : H12AffineEnvironment.transform 7 20 env43190 = env43191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env43190 == env43191) = true)

theorem identity43191 : scanCanonicalize (H12AffineFastState.compose env43191 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43191 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43192 : List Nat := [2,4,8,16,32,16,8,20,1,5,1,17,24,0,1,18,17,49,4,0,0,32,16,2,24,16,1,17,17,48,21,33,21,33,1,0]

theorem envBound43192 : H12AffineFastState.Bounded env43192 := by
  intro p hp
  have h : env43192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43191_43192 : H12AffineEnvironment.transform 8 1 env43191 = env43192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43191 == env43192) = true)

def env43193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,33,62541,21762,8192,64,121943,115014,45405,35189,75102,73770,257,95531,103430,513]

theorem envBound43193 : H12AffineFastState.Bounded env43193 := by
  intro p hp
  have h : env43193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43181_43193 : H12AffineEnvironment.transform 17 10281 env43181 = env43193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43181 == env43193) = true)

theorem identity43193 : scanCanonicalize (H12AffineFastState.compose env43193 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound43193 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env43194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,13341,10281,1025,8460,4161,33,21824,21762,8192,64,97626,90187,4176,10360,75102,73770,257,95531,79115,513]

theorem envBound43194 : H12AffineFastState.Bounded env43194 := by
  intro p hp
  have h : env43194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43193_43194 : H12AffineEnvironment.transform 14 8461 env43193 = env43194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env43193 == env43194) = true)

theorem identity43194 : scanCanonicalize (H12AffineFastState.compose env43194 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound43194 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30043,13341,10281,1025,8460,4161,33,21824,21762,8192,64,2049,5392,4176,10360,20485,21873,257,112,16464,513]

theorem envBound43195 : H12AffineFastState.Bounded env43195 := by
  intro p hp
  have h : env43195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43194_43195 : H12AffineEnvironment.transform 15 30043 env43194 = env43195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env43194 == env43195) = true)

theorem identity43195 : scanCanonicalize (H12AffineFastState.compose env43195 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43195 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,21590,5392,2340,1025,1,4161,33,21824,21762,269,64,2049,5392,4176,2421,20485,21873,257,112,16464,513]

theorem envBound43196 : H12AffineFastState.Bounded env43196 := by
  intro p hp
  have h : env43196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43195_43196 : H12AffineEnvironment.transform 12 269 env43195 = env43196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43195 == env43196) = true)

theorem identity43196 : scanCanonicalize (H12AffineFastState.compose env43196 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43196 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env43197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,0,343,5392,2340,1025,1,4161,33,65,3,269,64,2049,5392,4176,2421,1284,112,257,112,5457,513]

theorem envBound43197 : H12AffineFastState.Bounded env43197 := by
  intro p hp
  have h : env43197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43196_43197 : H12AffineEnvironment.transform 13 5377 env43196 = env43197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43196 == env43197) = true)

theorem identity43197 : scanCanonicalize (H12AffineFastState.compose env43197 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43197 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43198 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4112,33,16,3,269,17,2049,5392,4097,2340,1284,33,257,33,5376,513]

theorem envBound43198 : H12AffineFastState.Bounded env43198 := by
  intro p hp
  have h : env43198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43197_43198 : H12AffineEnvironment.transform 5 17 env43197 = env43198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43197 == env43198) = true)

theorem identity43198 : scanCanonicalize (H12AffineFastState.compose env43198 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43198 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43199 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1,269,1280,0,262,1297,2340,1025,1,17,33,16,3,269,17,2049,1297,0,2340,1284,33,257,33,1281,513]

theorem envBound43199 : H12AffineFastState.Bounded env43199 := by
  intro p hp
  have h : env43199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43198_43199 : H12AffineEnvironment.transform 11 1 env43198 = env43199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43198 == env43199) = true)

theorem identity43199 : scanCanonicalize (H12AffineFastState.compose env43199 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound43199 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43200 : List Nat := [2,4,8,16,32,17,8,256,512,1024,318,1,269,1280,0,262,1297,26,1025,1,17,33,16,3,269,17,319,1297,0,26,1284,33,257,33,1281,513]

theorem envBound43200 : H12AffineFastState.Bounded env43200 := by
  intro p hp
  have h : env43200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43199_43200 : H12AffineEnvironment.transform 10 318 env43199 = env43200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env43199 == env43200) = true)

theorem identity43200 : scanCanonicalize (H12AffineFastState.compose env43200 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43200 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43201 : List Nat := [2,4,8,16,32,17,8,256,512,21,318,1,269,277,0,262,260,26,20,1,17,33,16,3,269,17,319,260,0,26,273,33,257,33,276,513]

theorem envBound43201 : H12AffineFastState.Bounded env43201 := by
  intro p hp
  have h : env43201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43200_43201 : H12AffineEnvironment.transform 9 21 env43200 = env43201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43200 == env43201) = true)

theorem identity43201 : scanCanonicalize (H12AffineFastState.compose env43201 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound43201 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43202 : List Nat := [2,4,8,16,32,17,8,53,512,21,11,1,56,32,0,51,49,26,20,1,17,33,16,3,56,17,10,49,0,26,36,33,52,33,33,513]

theorem envBound43202 : H12AffineFastState.Bounded env43202 := by
  intro p hp
  have h : env43202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43201_43202 : H12AffineEnvironment.transform 7 53 env43201 = env43202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env43201 == env43202) = true)

theorem identity43202 : scanCanonicalize (H12AffineFastState.compose env43202 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound43202 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43203 : List Nat := [2,4,8,16,26,17,8,15,512,21,11,1,2,26,0,9,11,26,20,1,17,27,16,3,2,17,10,11,0,26,30,27,14,27,27,513]

theorem envBound43203 : H12AffineFastState.Bounded env43203 := by
  intro p hp
  have h : env43203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43202_43203 : H12AffineEnvironment.transform 4 26 env43202 = env43203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env43202 == env43203) = true)

theorem identity43203 : scanCanonicalize (H12AffineFastState.compose env43203 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43203 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43204 : List Nat := [2,4,2,16,16,17,2,5,512,21,1,1,2,16,0,3,1,16,20,1,17,17,16,3,2,17,0,1,0,16,20,17,4,17,17,513]

theorem envBound43204 : H12AffineFastState.Bounded env43204 := by
  intro p hp
  have h : env43204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43203_43204 : H12AffineEnvironment.transform 2 2 env43203 = env43204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43203 == env43204) = true)

theorem identity43204 : scanCanonicalize (H12AffineFastState.compose env43204 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound43204 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43205 : List Nat := [2,4,2,16,16,17,2,5,18,21,1,1,2,16,0,3,1,16,20,1,17,17,16,3,2,17,0,1,0,16,20,17,4,17,17,19]

theorem envBound43205 : H12AffineFastState.Bounded env43205 := by
  intro p hp
  have h : env43205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43204_43205 : H12AffineEnvironment.transform 8 18 env43204 = env43205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env43204 == env43205) = true)

theorem identity43205 : scanCanonicalize (H12AffineFastState.compose env43205 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43205 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env43206 : List Nat := [2,4,2,1,1,0,2,5,3,4,1,1,2,1,0,3,1,1,5,1,0,0,1,3,2,0,0,1,0,1,5,0,4,0,0,2]

theorem envBound43206 : H12AffineFastState.Bounded env43206 := by
  intro p hp
  have h : env43206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43205_43206 : H12AffineEnvironment.transform 3 1 env43205 = env43206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43205 == env43206) = true)

theorem identity43206 : scanCanonicalize (H12AffineFastState.compose env43206 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43206 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43207 : List Nat := [2,2,2,1,1,0,2,3,3,2,1,1,2,1,0,3,1,1,3,1,0,0,1,3,2,0,0,1,0,1,3,0,2,0,0,2]

theorem envBound43207 : H12AffineFastState.Bounded env43207 := by
  intro p hp
  have h : env43207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43206_43207 : H12AffineEnvironment.transform 1 2 env43206 = env43207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43206 == env43207) = true)

def env43208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272393,62540,21762,8193,64,121942,115015,45404,303452,75103,329731,257,95531,103431,513]

theorem envBound43208 : H12AffineFastState.Bounded env43208 := by
  intro p hp
  have h : env43208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43180_43208 : H12AffineEnvironment.transform 6 9 env43180 = env43208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43180 == env43208) = true)

theorem identity43208 : scanCanonicalize (H12AffineFastState.compose env43208 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound43208 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4161,272393,62540,21762,8193,64,10588,13389,45404,303452,53333,326921,257,32801,24845,513]

theorem envBound43209 : H12AffineFastState.Bounded env43209 := by
  intro p hp
  have h : env43209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43208_43209 : H12AffineEnvironment.transform 15 62730 env43208 = env43209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env43208 == env43209) = true)

theorem identity43209 : scanCanonicalize (H12AffineFastState.compose env43209 (packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound43209 : packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS < 2^1333 := by decide +kernel

def env43210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1124,29038,4469,262144,1025,1125,4161,272393,28712,21762,8193,64,10588,13389,13624,271672,21553,293229,257,1093,24845,513]

theorem envBound43210 : H12AffineFastState.Bounded env43210 := by
  intro p hp
  have h : env43210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43209_43210 : H12AffineEnvironment.transform 14 1124 env43209 = env43210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env43209 == env43210) = true)

theorem identity43210 : scanCanonicalize (H12AffineFastState.compose env43210 (packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound43210 : packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS < 2^1333 := by decide +kernel

def env43211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1124,29038,4469,22884,1025,1125,4161,29037,28712,21762,8193,64,10588,13389,13624,31836,21553,8201,257,1093,24845,513]

theorem envBound43211 : H12AffineFastState.Bounded env43211 := by
  intro p hp
  have h : env43211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43210_43211 : H12AffineEnvironment.transform 17 22884 env43210 = env43211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env43210 == env43211) = true)

theorem identity43211 : scanCanonicalize (H12AffineFastState.compose env43211 (packedSelected [2,4,6,9,11,14,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound43211 : packedSelected [2,4,6,9,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env43212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1124,20758,4469,22884,1025,1125,4161,20757,20560,21762,121,64,2340,5173,5440,23588,21553,113,257,1093,16757,513]

theorem envBound43212 : H12AffineFastState.Bounded env43212 := by
  intro p hp
  have h : env43212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43211_43212 : H12AffineEnvironment.transform 12 120 env43211 = env43212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env43211 == env43212) = true)

theorem identity43212 : scanCanonicalize (H12AffineFastState.compose env43212 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound43212 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env43213 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,120,16384,293,20758,4469,22884,320,292,4161,20757,20560,20547,121,64,2340,4468,4097,22885,20848,113,257,260,16757,513]

theorem envBound43213 : H12AffineFastState.Bounded env43213 := by
  intro p hp
  have h : env43213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43212_43213 : H12AffineEnvironment.transform 9 321 env43212 = env43213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43212 == env43213) = true)

theorem identity43213 : scanCanonicalize (H12AffineFastState.compose env43213 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound43213 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env43214 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,120,4452,293,114,4469,2048,320,292,4161,113,308,295,121,64,2340,4468,4097,2049,20,113,257,260,4113,513]

theorem envBound43214 : H12AffineFastState.Bounded env43214 := by
  intro p hp
  have h : env43214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43213_43214 : H12AffineEnvironment.transform 13 4452 env43213 = env43214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env43213 == env43214) = true)

theorem identity43214 : scanCanonicalize (H12AffineFastState.compose env43214 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound43214 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43215 : List Nat := [2,4,8,16,32,48,9,256,512,305,2048,4096,8,4372,293,2,4357,2048,304,292,4145,1,308,295,9,48,2340,4356,4097,2049,20,1,257,260,4113,513]

theorem envBound43215 : H12AffineFastState.Bounded env43215 := by
  intro p hp
  have h : env43215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43214_43215 : H12AffineEnvironment.transform 5 48 env43214 = env43215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env43214 == env43215) = true)

theorem identity43215 : scanCanonicalize (H12AffineFastState.compose env43215 (packedSelected [0,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound43215 : packedSelected [0,2,5,8] rootPS < 2^1333 := by decide +kernel

def env43216 : List Nat := [2,4,8,16,32,48,9,256,512,305,261,4096,8,4372,293,2,4357,261,304,292,4145,1,308,295,9,48,33,4356,4097,260,20,1,257,260,4113,513]

theorem envBound43216 : H12AffineFastState.Bounded env43216 := by
  intro p hp
  have h : env43216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43215_43216 : H12AffineEnvironment.transform 10 261 env43215 = env43216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env43215 == env43216) = true)

theorem identity43216 : scanCanonicalize (H12AffineFastState.compose env43216 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43216 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env43217 : List Nat := [2,4,8,16,17,1,9,256,512,256,261,4096,8,4372,276,2,4357,261,257,277,4096,1,261,278,9,1,16,4356,4097,260,20,1,257,260,4113,513]

theorem envBound43217 : H12AffineFastState.Bounded env43217 := by
  intro p hp
  have h : env43217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43216_43217 : H12AffineEnvironment.transform 4 17 env43216 = env43217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43216 == env43217) = true)

theorem identity43217 : scanCanonicalize (H12AffineFastState.compose env43217 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43217 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env43218 : List Nat := [2,4,8,16,17,1,9,256,512,256,261,0,8,276,276,2,261,261,257,277,0,1,261,278,9,1,16,260,1,260,20,1,257,260,17,513]

theorem envBound43218 : H12AffineFastState.Bounded env43218 := by
  intro p hp
  have h : env43218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43217_43218 : H12AffineEnvironment.transform 11 0 env43217 = env43218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43217 == env43218) = true)

theorem identity43218 : scanCanonicalize (H12AffineFastState.compose env43218 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound43218 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43219 : List Nat := [2,4,8,16,17,1,9,256,260,256,261,0,8,276,276,2,261,261,257,277,0,1,261,278,9,1,16,260,1,260,20,1,257,260,17,261]

theorem envBound43219 : H12AffineFastState.Bounded env43219 := by
  intro p hp
  have h : env43219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43218_43219 : H12AffineEnvironment.transform 8 260 env43218 = env43219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env43218 == env43219) = true)

theorem identity43219 : scanCanonicalize (H12AffineFastState.compose env43219 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43219 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43220 : List Nat := [2,4,8,0,1,1,9,256,260,256,261,0,8,260,260,2,261,261,257,261,0,1,261,262,9,1,0,260,1,260,4,1,257,260,1,261]

theorem envBound43220 : H12AffineFastState.Bounded env43220 := by
  intro p hp
  have h : env43220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43219_43220 : H12AffineEnvironment.transform 3 0 env43219 = env43220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43219 == env43220) = true)

def env43221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound43221 : H12AffineFastState.Bounded env43221 := by
  intro p hp
  have h : env43221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42396_43221 : H12AffineEnvironment.transform 25 65 env42396 = env43221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env42396 == env43221) = true)

def env43222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound43222 : H12AffineFastState.Bounded env43222 := by
  intro p hp
  have h : env43222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43221_43222 : H12AffineEnvironment.transform 26 30393344 env43221 = env43222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env43221 == env43222) = true)

def env43223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound43223 : H12AffineFastState.Bounded env43223 := by
  intro p hp
  have h : env43223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43222_43223 : H12AffineEnvironment.transform 18 1024 env43222 = env43223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env43222 == env43223) = true)

theorem identity43223 : scanCanonicalize (H12AffineFastState.compose env43223 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 485759) := by decide +kernel

theorem selectedBound43223 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,485759,16777216,8328,65,21014911,18973836,2571311,108926,17231215,23160257,256,19312082,19287159,17287864]

theorem envBound43224 : H12AffineFastState.Bounded env43224 := by
  intro p hp
  have h : env43224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43223_43224 : H12AffineEnvironment.transform 22 485759 env43223 = env43224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 485759 env43223 == env43224) = true)

def env43225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156132,485759,16777216,8328,65,16959643,18973836,2571311,108926,17231215,19072037,256,19312082,19287159,17287864]

theorem envBound43225 : H12AffineFastState.Bounded env43225 := by
  intro p hp
  have h : env43225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43224_43225 : H12AffineEnvironment.transform 21 156132 env43224 = env43225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env43224 == env43225) = true)

def env43226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,156132,485759,16777216,8328,65,16959643,17246588,102879,108926,17231215,17148373,256,16777250,16834951,17287864]

theorem envBound43226 : H12AffineFastState.Bounded env43226 := by
  intro p hp
  have h : env43226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43225_43226 : H12AffineEnvironment.transform 20 437744 env43225 = env43226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437744 env43225 == env43226) = true)

theorem identity43226 : scanCanonicalize (H12AffineFastState.compose env43226 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound43226 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env43227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115871,156132,16,16777216,8328,65,16959643,16793619,102879,108926,16876544,16957626,256,16777250,16834951,16819159]

theorem envBound43227 : H12AffineFastState.Bounded env43227 := by
  intro p hp
  have h : env43227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43226_43227 : H12AffineEnvironment.transform 17 223599 env43226 = env43227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env43226 == env43227) = true)

def env43228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115871,156132,16,95496,8328,65,245139,79131,102879,108926,61704,243122,256,95530,103567,120543]

theorem envBound43228 : H12AffineFastState.Bounded env43228 := by
  intro p hp
  have h : env43228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43227_43228 : H12AffineEnvironment.transform 23 95496 env43227 = env43228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env43227 == env43228) = true)

def env43229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115735,156012,16,95496,8192,65,245019,79131,102743,108926,61704,243002,256,95530,103431,120407]

theorem envBound43229 : H12AffineFastState.Bounded env43229 := by
  intro p hp
  have h : env43229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43228_43229 : H12AffineEnvironment.transform 6 8 env43228 = env43229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43228 == env43229) = true)

theorem identity43229 : scanCanonicalize (H12AffineFastState.compose env43229 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound43229 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1024,32769,115735,73770,16,95496,8192,65,64605,79131,102743,108926,61704,62588,256,95530,103431,120407]

theorem envBound43230 : H12AffineFastState.Bounded env43230 := by
  intro p hp
  have h : env43230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43229_43230 : H12AffineEnvironment.transform 16 82246 env43229 = env43230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env43229 == env43230) = true)

theorem identity43230 : scanCanonicalize (H12AffineFastState.compose env43230 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound43230 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env43231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,46157,10281,1024,32769,12572,54561,16,32771,8192,65,64605,49168,25692,23669,61704,62588,256,32801,24844,9052]

theorem envBound43231 : H12AffineFastState.Bounded env43231 := by
  intro p hp
  have h : env43231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43230_43231 : H12AffineEnvironment.transform 15 62731 env43230 = env43231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env43230 == env43231) = true)

theorem identity43231 : scanCanonicalize (H12AffineFastState.compose env43231 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound43231 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,24909,10281,1024,21761,12572,33,16,21763,8192,65,10589,5392,25692,23669,9224,8572,256,21793,24844,9052]

theorem envBound43232 : H12AffineFastState.Bounded env43232 := by
  intro p hp
  have h : env43232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43231_43232 : H12AffineEnvironment.transform 14 21760 env43231 = env43232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env43231 == env43232) = true)

theorem identity43232 : scanCanonicalize (H12AffineFastState.compose env43232 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound43232 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env43233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,81,8203,13340,10281,1024,80,12572,33,16,82,8192,65,10589,5392,12557,2340,9224,8572,256,112,13405,9052]

theorem envBound43233 : H12AffineFastState.Bounded env43233 := by
  intro p hp
  have h : env43233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43232_43233 : H12AffineEnvironment.transform 13 5457 env43232 = env43233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env43232 == env43233) = true)

theorem identity43233 : scanCanonicalize (H12AffineFastState.compose env43233 (packedSelected [0,2,3,5,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound43233 : packedSelected [0,2,3,5,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env43234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5457,81,115,5220,2129,1024,80,4452,33,16,82,120,65,2341,5392,4469,2340,1136,260,256,112,5157,804]

theorem envBound43234 : H12AffineFastState.Bounded env43234 := by
  intro p hp
  have h : env43234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43233_43234 : H12AffineEnvironment.transform 12 120 env43233 = env43234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env43233 == env43234) = true)

theorem identity43234 : scanCanonicalize (H12AffineFastState.compose env43234 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43235 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5237,81,115,5220,2129,1024,80,4160,33,16,82,120,65,2049,5172,4177,2048,1136,32,36,112,5157,512]

theorem envBound43235 : H12AffineFastState.Bounded env43235 := by
  intro p hp
  have h : env43235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43234_43235 : H12AffineEnvironment.transform 7 36 env43234 = env43235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43234 == env43235) = true)

theorem identity43235 : scanCanonicalize (H12AffineFastState.compose env43235 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound43235 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43236 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,8,5125,33,3,5140,2081,1024,32,4144,33,16,34,8,49,2049,5172,4129,2048,1024,32,36,0,5157,512]

theorem envBound43236 : H12AffineFastState.Bounded env43236 := by
  intro p hp
  have h : env43236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43235_43236 : H12AffineEnvironment.transform 5 48 env43235 = env43236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env43235 == env43236) = true)

theorem identity43236 : scanCanonicalize (H12AffineFastState.compose env43236 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3599) := by decide +kernel

theorem selectedBound43236 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43237 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,3599,8,2570,33,3,2587,2081,1024,32,3647,33,16,34,8,49,2049,2619,3630,2048,1024,32,36,0,2602,512]

theorem envBound43237 : H12AffineFastState.Bounded env43237 := by
  intro p hp
  have h : env43237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43236_43237 : H12AffineEnvironment.transform 11 3599 env43236 = env43237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3599 env43236 == env43237) = true)

theorem identity43237 : scanCanonicalize (H12AffineFastState.compose env43237 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound43237 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env43238 : List Nat := [2,4,8,16,32,48,8,36,512,542,2048,2065,8,2570,33,3,2587,2081,542,32,2081,33,16,34,8,49,2049,2619,2096,2048,542,32,36,0,2602,512]

theorem envBound43238 : H12AffineFastState.Bounded env43238 := by
  intro p hp
  have h : env43238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43237_43238 : H12AffineEnvironment.transform 9 542 env43237 = env43238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env43237 == env43238) = true)

theorem identity43238 : scanCanonicalize (H12AffineFastState.compose env43238 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound43238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43239 : List Nat := [2,4,8,16,32,48,8,36,13,19,2048,2065,8,2055,33,3,2070,2081,19,32,2081,33,16,34,8,49,2049,2102,2096,2048,19,32,36,0,2087,13]

theorem envBound43239 : H12AffineFastState.Bounded env43239 := by
  intro p hp
  have h : env43239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43238_43239 : H12AffineEnvironment.transform 8 13 env43238 = env43239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env43238 == env43239) = true)

theorem identity43239 : scanCanonicalize (H12AffineFastState.compose env43239 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound43239 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43240 : List Nat := [2,4,8,16,32,48,8,36,13,19,38,55,8,33,33,3,48,7,19,32,7,33,16,34,8,49,39,16,22,38,19,32,36,0,1,13]

theorem envBound43240 : H12AffineFastState.Bounded env43240 := by
  intro p hp
  have h : env43240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43239_43240 : H12AffineEnvironment.transform 10 38 env43239 = env43240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env43239 == env43240) = true)

theorem identity43240 : scanCanonicalize (H12AffineFastState.compose env43240 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43240 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43241 : List Nat := [2,3,8,16,32,48,8,35,10,19,33,48,8,33,33,3,48,0,19,32,0,33,16,34,8,49,32,16,17,33,19,32,35,0,1,10]

theorem envBound43241 : H12AffineFastState.Bounded env43241 := by
  intro p hp
  have h : env43241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43240_43241 : H12AffineEnvironment.transform 1 3 env43240 = env43241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43240 == env43241) = true)

def env43242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115734,156013,16,95496,8193,65,245018,79131,102742,108926,61704,243003,256,95530,103430,120406]

theorem envBound43242 : H12AffineFastState.Bounded env43242 := by
  intro p hp
  have h : env43242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43228_43242 : H12AffineEnvironment.transform 6 9 env43228 = env43242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43228 == env43242) = true)

theorem identity43242 : scanCanonicalize (H12AffineFastState.compose env43242 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound43242 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35189,1024,32769,115734,98679,16,95496,8193,65,23808,79131,102742,108926,61704,21793,256,95530,103430,120406]

theorem envBound43243 : H12AffineFastState.Bounded env43243 := by
  intro p hp
  have h : env43243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43242_43243 : H12AffineEnvironment.transform 16 122906 env43242 = env43243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env43242 == env43243) = true)

theorem identity43243 : scanCanonicalize (H12AffineFastState.compose env43243 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound43243 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,46157,35189,1024,32769,36929,54560,16,8543,8193,65,23808,24908,50433,64809,61704,21793,256,8573,49233,33281]

theorem envBound43244 : H12AffineFastState.Bounded env43244 := by
  intro p hp
  have h : env43244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43243_43244 : H12AffineEnvironment.transform 15 21591 env43243 = env43244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env43243 == env43244) = true)

theorem identity43244 : scanCanonicalize (H12AffineFastState.compose env43244 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43244 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,342,46157,35189,1024,32769,36929,32801,16,8543,8193,65,2049,13389,36864,43048,41993,32,256,8573,38224,33281]

theorem envBound43245 : H12AffineFastState.Bounded env43245 := by
  intro p hp
  have h : env43245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43244_43245 : H12AffineEnvironment.transform 13 5377 env43244 = env43245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43244 == env43245) = true)

theorem identity43245 : scanCanonicalize (H12AffineFastState.compose env43245 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43245 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env43246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,342,13389,2421,1024,1,4161,33,16,8543,8193,65,2049,13389,4096,10280,9225,32,256,8573,5456,513]

theorem envBound43246 : H12AffineFastState.Bounded env43246 := by
  intro p hp
  have h : env43246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43245_43246 : H12AffineEnvironment.transform 14 0 env43245 = env43246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43245 == env43246) = true)

def env43247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115871,156132,16,95497,8328,65,245138,79130,102879,108926,61705,243123,256,95531,103566,120542]

theorem envBound43247 : H12AffineFastState.Bounded env43247 := by
  intro p hp
  have h : env43247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43227_43247 : H12AffineEnvironment.transform 23 95497 env43227 = env43247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env43227 == env43247) = true)

theorem identity43247 : scanCanonicalize (H12AffineFastState.compose env43247 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound43247 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179632,1024,32769,4160,156132,16,41430,8328,65,158029,57797,17664,32161,61705,156012,256,41460,16465,513]

theorem envBound43248 : H12AffineFastState.Bounded env43248 := by
  intro p hp
  have h : env43248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43247_43248 : H12AffineEnvironment.transform 15 54495 env43247 = env43248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env43247 == env43248) = true)

def env43249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4160,156012,16,41310,8192,65,158029,57677,17664,32041,61705,156012,256,41340,16465,513]

theorem envBound43249 : H12AffineFastState.Bounded env43249 := by
  intro p hp
  have h : env43249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43248_43249 : H12AffineEnvironment.transform 6 8 env43248 = env43249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43248 == env43249) = true)

theorem identity43249 : scanCanonicalize (H12AffineFastState.compose env43249 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound43249 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10281,1024,32769,4160,62589,16,41310,8192,65,64604,57677,17664,32041,61705,62589,256,41340,16465,513]

theorem envBound43250 : H12AffineFastState.Bounded env43250 := by
  intro p hp
  have h : env43250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43249_43250 : H12AffineEnvironment.transform 16 38161 env43249 = env43250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env43249 == env43250) = true)

theorem identity43250 : scanCanonicalize (H12AffineFastState.compose env43250 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43250 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env43251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38161,10281,1024,32769,4160,41340,16,41310,8192,65,43357,46156,4097,10280,41992,41340,256,41340,5456,513]

theorem envBound43251 : H12AffineFastState.Bounded env43251 := by
  intro p hp
  have h : env43251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43250_43251 : H12AffineEnvironment.transform 13 5377 env43250 = env43251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43250 == env43251) = true)

theorem identity43251 : scanCanonicalize (H12AffineFastState.compose env43251 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43251 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,32768,33110,38161,2049,1024,32769,4160,33108,16,33142,40,65,35189,37988,4097,2048,33824,33108,256,33108,5456,513]

theorem envBound43252 : H12AffineFastState.Bounded env43252 := by
  intro p hp
  have h : env43252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43251_43252 : H12AffineEnvironment.transform 12 40 env43251 = env43252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43251 == env43252) = true)

theorem identity43252 : scanCanonicalize (H12AffineFastState.compose env43252 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound43252 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env43253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,81,263,5440,2049,1024,80,4160,261,16,295,40,65,2340,5173,4097,2048,1137,261,256,261,5456,513]

theorem envBound43253 : H12AffineFastState.Bounded env43253 := by
  intro p hp
  have h : env43253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43252_43253 : H12AffineEnvironment.transform 14 81 env43252 = env43253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env43252 == env43253) = true)

theorem identity43253 : scanCanonicalize (H12AffineFastState.compose env43253 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43253 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43254 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,40,5156,81,34,5221,2049,1024,80,4160,32,16,2,40,65,2049,5173,4097,2048,1137,32,37,32,5237,513]

theorem envBound43254 : H12AffineFastState.Bounded env43254 := by
  intro p hp
  have h : env43254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43253_43254 : H12AffineEnvironment.transform 7 37 env43253 = env43254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43253 == env43254) = true)

theorem identity43254 : scanCanonicalize (H12AffineFastState.compose env43254 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound43254 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43255 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1140,40,80,81,34,17,2049,1024,80,1076,32,16,2,40,65,2049,65,1141,2048,1137,32,37,32,1,513]

theorem envBound43255 : H12AffineFastState.Bounded env43255 := by
  intro p hp
  have h : env43255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43254_43255 : H12AffineEnvironment.transform 11 1140 env43254 = env43255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env43254 == env43255) = true)

theorem identity43255 : scanCanonicalize (H12AffineFastState.compose env43255 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43255 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43256 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1060,40,0,1,34,17,2049,1024,0,1076,32,16,2,40,17,2049,17,1061,2048,1057,32,37,32,1,513]

theorem envBound43256 : H12AffineFastState.Bounded env43256 := by
  intro p hp
  have h : env43256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43255_43256 : H12AffineEnvironment.transform 5 16 env43255 = env43256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43255 == env43256) = true)

theorem identity43256 : scanCanonicalize (H12AffineFastState.compose env43256 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound43256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43257 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,1,40,0,1,34,17,2049,37,0,17,32,16,2,40,17,2049,17,0,2048,4,32,37,32,1,513]

theorem envBound43257 : H12AffineFastState.Bounded env43257 := by
  intro p hp
  have h : env43257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43256_43257 : H12AffineEnvironment.transform 9 37 env43256 = env43257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env43256 == env43257) = true)

theorem identity43257 : scanCanonicalize (H12AffineFastState.compose env43257 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound43257 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43258 : List Nat := [2,4,8,16,32,16,8,37,512,37,10,1,40,0,1,34,17,11,37,0,17,32,16,2,40,17,11,17,0,10,4,32,37,32,1,513]

theorem envBound43258 : H12AffineFastState.Bounded env43258 := by
  intro p hp
  have h : env43258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43257_43258 : H12AffineEnvironment.transform 10 10 env43257 = env43258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env43257 == env43258) = true)

theorem identity43258 : scanCanonicalize (H12AffineFastState.compose env43258 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound43258 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43259 : List Nat := [2,4,8,16,26,16,8,31,512,31,10,1,18,0,1,24,17,11,31,0,17,26,16,2,18,17,11,17,0,10,4,26,31,26,1,513]

theorem envBound43259 : H12AffineFastState.Bounded env43259 := by
  intro p hp
  have h : env43259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43258_43259 : H12AffineEnvironment.transform 4 26 env43258 = env43259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env43258 == env43259) = true)

theorem identity43259 : scanCanonicalize (H12AffineFastState.compose env43259 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43259 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43260 : List Nat := [2,4,8,11,1,11,8,4,512,4,10,1,9,0,1,3,10,11,4,0,10,1,11,2,9,10,11,10,0,10,4,1,4,1,1,513]

theorem envBound43260 : H12AffineFastState.Bounded env43260 := by
  intro p hp
  have h : env43260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43259_43260 : H12AffineEnvironment.transform 3 11 env43259 = env43260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43259 == env43260) = true)

theorem identity43260 : scanCanonicalize (H12AffineFastState.compose env43260 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43260 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43261 : List Nat := [2,0,8,11,1,11,8,0,512,0,10,1,9,0,1,3,10,11,0,0,10,1,11,2,9,10,11,10,0,10,0,1,0,1,1,513]

theorem envBound43261 : H12AffineFastState.Bounded env43261 := by
  intro p hp
  have h : env43261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43260_43261 : H12AffineEnvironment.transform 1 0 env43260 = env43261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43260 == env43261) = true)

def env43262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4160,156013,16,41311,8193,65,158029,57676,17664,32040,61705,156012,256,41341,16465,513]

theorem envBound43262 : H12AffineFastState.Bounded env43262 := by
  intro p hp
  have h : env43262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43248_43262 : H12AffineEnvironment.transform 6 9 env43248 = env43262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43248 == env43262) = true)

theorem identity43262 : scanCanonicalize (H12AffineFastState.compose env43262 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound43262 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,35189,1024,32769,4160,21793,16,41311,8193,65,23809,57676,17664,32040,61705,21792,256,41341,16465,513]

theorem envBound43263 : H12AffineFastState.Bounded env43263 := by
  intro p hp
  have h : env43263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43262_43263 : H12AffineEnvironment.transform 16 13388 env43262 = env43263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env43262 == env43263) = true)

theorem identity43263 : scanCanonicalize (H12AffineFastState.compose env43263 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound43263 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env43264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28698,13388,11577,1024,9293,4160,21793,16,1299,8193,65,23809,17664,17664,32040,21829,21792,256,1329,16465,513]

theorem envBound43264 : H12AffineFastState.Bounded env43264 := by
  intro p hp
  have h : env43264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43263_43264 : H12AffineEnvironment.transform 14 9292 env43263 = env43264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env43263 == env43264) = true)

theorem identity43264 : scanCanonicalize (H12AffineFastState.compose env43264 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound43264 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env43265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,0,21590,4096,2421,1024,1,4160,21793,16,1299,1101,65,23809,17664,17664,22884,21829,21792,256,1329,16465,513]

theorem envBound43265 : H12AffineFastState.Bounded env43265 := by
  intro p hp
  have h : env43265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43264_43265 : H12AffineEnvironment.transform 12 1100 env43264 = env43265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env43264 == env43265) = true)

theorem identity43265 : scanCanonicalize (H12AffineFastState.compose env43265 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43265 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5376,0,342,4096,2421,1024,1,4160,33,16,1299,1101,65,2049,4096,4096,3172,69,32,256,1329,5457,513]

theorem envBound43266 : H12AffineFastState.Bounded env43266 := by
  intro p hp
  have h : env43266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43265_43266 : H12AffineEnvironment.transform 13 5376 env43265 = env43266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43265 == env43266) = true)

def env43267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156132,485759,16777216,8328,65,16959643,17246589,102878,108926,17231215,17148372,256,16777251,16834950,17287864]

theorem envBound43267 : H12AffineFastState.Bounded env43267 := by
  intro p hp
  have h : env43267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43225_43267 : H12AffineEnvironment.transform 20 437745 env43225 = env43267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env43225 == env43267) = true)

theorem identity43267 : scanCanonicalize (H12AffineFastState.compose env43267 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362665) := by decide +kernel

theorem selectedBound43267 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env43268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156132,485759,362665,8328,65,475186,172500,102878,108926,222662,8573,256,362634,354607,147985]

theorem envBound43268 : H12AffineFastState.Bounded env43268 := by
  intro p hp
  have h : env43268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43267_43268 : H12AffineEnvironment.transform 23 362665 env43267 = env43268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362665 env43267 == env43268) = true)

def env43269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,64928,1024,32769,151633,156132,234719,95497,8328,65,245138,172500,102878,108926,222662,8573,256,95530,103567,147985]

theorem envBound43269 : H12AffineFastState.Bounded env43269 := by
  intro p hp
  have h : env43269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43268_43269 : H12AffineEnvironment.transform 17 64928 env43268 = env43269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64928 env43268 == env43269) = true)

theorem identity43269 : scanCanonicalize (H12AffineFastState.compose env43269 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound43269 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,64928,1024,32769,77899,66046,62661,95497,8328,65,56712,115150,102878,108926,1500,8573,256,95530,103567,74251]

theorem envBound43270 : H12AffineFastState.Bounded env43270 := by
  intro p hp
  have h : env43270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43269_43270 : H12AffineEnvironment.transform 16 90138 env43269 = env43270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env43269 == env43270) = true)

theorem identity43270 : scanCanonicalize (H12AffineFastState.compose env43270 (packedSelected [1,3,4,5,7,8,9,10,15,16,17,20,26,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound43270 : packedSelected [1,3,4,5,7,8,9,10,15,16,17,20,26,27,38] rootPS < 2^1333 := by decide +kernel

def env43271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30043,5441,64928,1024,32769,17680,29861,62661,82,8328,65,56712,46229,58501,56357,1500,8573,256,113,57812,22352]

theorem envBound43271 : H12AffineFastState.Bounded env43271 := by
  intro p hp
  have h : env43271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43270_43271 : H12AffineEnvironment.transform 15 30043 env43270 = env43271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env43270 == env43271) = true)

theorem identity43271 : scanCanonicalize (H12AffineFastState.compose env43271 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound43271 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env43272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,30043,5441,2476,1024,29709,17680,29861,201,82,8328,65,10628,16537,4233,10281,1500,8573,256,113,5592,22352]

theorem envBound43272 : H12AffineFastState.Bounded env43272 := by
  intro p hp
  have h : env43272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43271_43272 : H12AffineEnvironment.transform 14 29708 env43271 = env43272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env43271 == env43272) = true)

theorem identity43272 : scanCanonicalize (H12AffineFastState.compose env43272 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43272 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env43273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21761,21590,5441,2476,1024,21760,17680,21928,201,82,389,65,2185,16537,4233,2340,1500,112,256,113,5592,22352]

theorem envBound43273 : H12AffineFastState.Bounded env43273 := by
  intro p hp
  have h : env43273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43272_43273 : H12AffineEnvironment.transform 12 269 env43272 = env43273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43272 == env43273) = true)

theorem identity43273 : scanCanonicalize (H12AffineFastState.compose env43273 (packedSelected [2,6,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound43273 : packedSelected [2,6,11,15,17] rootPS < 2^1333 := by decide +kernel

def env43274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5592,217,398,5441,2476,1024,216,4296,112,201,82,389,65,2185,5441,4233,2340,1500,112,256,113,5592,648]

theorem envBound43274 : H12AffineFastState.Bounded env43274 := by
  intro p hp
  have h : env43274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43273_43274 : H12AffineEnvironment.transform 13 5592 env43273 = env43274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env43273 == env43274) = true)

theorem identity43274 : scanCanonicalize (H12AffineFastState.compose env43274 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43274 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env43275 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,269,4297,217,398,4176,2476,273,216,4296,112,201,82,389,65,2185,4176,4233,2340,205,112,256,113,4297,648]

theorem envBound43275 : H12AffineFastState.Bounded env43275 := by
  intro p hp
  have h : env43275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43274_43275 : H12AffineEnvironment.transform 9 273 env43274 = env43275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43274 == env43275) = true)

theorem identity43275 : scanCanonicalize (H12AffineFastState.compose env43275 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43275 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env43276 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,269,4160,80,263,4176,2341,273,81,4161,112,64,82,268,65,2048,4176,4096,2340,68,112,256,113,4160,513]

theorem envBound43276 : H12AffineFastState.Bounded env43276 := by
  intro p hp
  have h : env43276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43275_43276 : H12AffineEnvironment.transform 6 9 env43275 = env43276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43275 == env43276) = true)

theorem identity43276 : scanCanonicalize (H12AffineFastState.compose env43276 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43277 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,269,4112,0,263,4096,2341,273,1,4113,32,16,2,268,17,2048,4096,4096,2340,20,32,256,33,4112,513]

theorem envBound43277 : H12AffineFastState.Bounded env43277 := by
  intro p hp
  have h : env43277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43276_43277 : H12AffineEnvironment.transform 5 16 env43276 = env43277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43276 == env43277) = true)

theorem identity43277 : scanCanonicalize (H12AffineFastState.compose env43277 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound43277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43278 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,16,269,0,0,263,16,2341,273,1,1,32,16,2,268,17,2048,16,16,2340,20,32,256,33,0,513]

theorem envBound43278 : H12AffineFastState.Bounded env43278 := by
  intro p hp
  have h : env43278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43277_43278 : H12AffineEnvironment.transform 11 16 env43277 = env43278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env43277 == env43278) = true)

theorem identity43278 : scanCanonicalize (H12AffineFastState.compose env43278 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43279 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,16,40,0,0,34,16,2048,52,1,1,32,16,2,41,17,2048,16,16,2049,20,32,37,33,0,513]

theorem envBound43279 : H12AffineFastState.Bounded env43279 := by
  intro p hp
  have h : env43279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43278_43279 : H12AffineEnvironment.transform 7 37 env43278 = env43279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43278 == env43279) = true)

theorem identity43279 : scanCanonicalize (H12AffineFastState.compose env43279 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound43279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43280 : List Nat := [2,4,8,16,32,16,9,37,32,52,2048,16,40,0,0,34,16,2048,52,1,1,32,16,2,41,17,2048,16,16,2049,20,32,37,33,0,33]

theorem envBound43280 : H12AffineFastState.Bounded env43280 := by
  intro p hp
  have h : env43280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43279_43280 : H12AffineEnvironment.transform 8 32 env43279 = env43280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env43279 == env43280) = true)

theorem identity43280 : scanCanonicalize (H12AffineFastState.compose env43280 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43281 : List Nat := [2,4,8,16,32,16,9,37,32,52,0,16,40,0,0,34,16,0,52,1,1,32,16,2,41,17,0,16,16,1,20,32,37,33,0,33]

theorem envBound43281 : H12AffineFastState.Bounded env43281 := by
  intro p hp
  have h : env43281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43280_43281 : H12AffineEnvironment.transform 10 0 env43280 = env43281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43280 == env43281) = true)

def env43282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,64929,1024,32769,151632,156132,234718,95496,8328,65,245139,172500,102878,108926,222662,8573,256,95531,103566,147985]

theorem envBound43282 : H12AffineFastState.Bounded env43282 := by
  intro p hp
  have h : env43282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43268_43282 : H12AffineEnvironment.transform 17 64929 env43268 = env43282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64929 env43268 == env43282) = true)

theorem identity43282 : scanCanonicalize (H12AffineFastState.compose env43282 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43282 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,64929,1024,32769,151632,156132,177364,21762,8328,65,171417,172500,45524,35188,148940,8573,256,21793,46212,147985]

theorem envBound43283 : H12AffineFastState.Bounded env43283 := by
  intro p hp
  have h : env43283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43282_43283 : H12AffineEnvironment.transform 15 8202 env43282 = env43283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43282 == env43283) = true)

theorem identity43283 : scanCanonicalize (H12AffineFastState.compose env43283 (packedSelected [0,1,5,8,9,15,17,22,24,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound43283 : packedSelected [0,1,5,8,9,15,17,22,24,27,38] rootPS < 2^1333 := by decide +kernel

def env43284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,8202,131072,43249,1024,32769,132352,144564,177364,82,8328,65,171417,172500,45524,35188,135324,8573,256,113,46212,137025]

theorem envBound43284 : H12AffineFastState.Bounded env43284 := by
  intro p hp
  have h : env43284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43283_43284 : H12AffineEnvironment.transform 13 5456 env43283 = env43284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env43283 == env43284) = true)

theorem identity43284 : scanCanonicalize (H12AffineFastState.compose env43284 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound43284 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env43285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,8202,46109,43249,1024,32769,45341,32937,201,82,8328,65,10628,5577,45524,35188,42113,8573,256,113,46212,41820]

theorem envBound43285 : H12AffineFastState.Bounded env43285 := by
  intro p hp
  have h : env43285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43284_43285 : H12AffineEnvironment.transform 16 46109 env43284 = env43285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env43284 == env43285) = true)

theorem identity43285 : scanCanonicalize (H12AffineFastState.compose env43285 (packedSelected [0,1,3,5,7,8,9,11,12,15,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43285 : packedSelected [0,1,3,5,7,8,9,11,12,15,17,18,22] rootPS < 2^1333 := by decide +kernel

def env43286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,32768,262,38161,35325,1024,32769,36881,32937,201,82,388,65,2184,5577,37080,35188,34189,113,256,113,38280,33360]

theorem envBound43286 : H12AffineFastState.Bounded env43286 := by
  intro p hp
  have h : env43286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43285_43286 : H12AffineEnvironment.transform 12 268 env43285 = env43286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43285 == env43286) = true)

theorem identity43286 : scanCanonicalize (H12AffineFastState.compose env43286 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound43286 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43287 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,268,4541,32768,262,37372,35325,237,32769,36881,32937,201,82,388,65,2184,4388,37080,35188,33120,113,256,113,37221,33360]

theorem envBound43287 : H12AffineFastState.Bounded env43287 := by
  intro p hp
  have h : env43287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43286_43287 : H12AffineEnvironment.transform 9 237 env43286 = env43287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env43286 == env43287) = true)

theorem identity43287 : scanCanonicalize (H12AffineFastState.compose env43287 (packedSelected [0,7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43287 : packedSelected [0,7,10,12] rootPS < 2^1333 := by decide +kernel

def env43288 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,4096,41,4248,32768,35,37081,35032,237,32769,36881,32937,201,82,161,65,2184,4097,37080,34897,32837,113,37,113,36928,33360]

theorem envBound43288 : H12AffineFastState.Bounded env43288 := by
  intro p hp
  have h : env43288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43287_43288 : H12AffineEnvironment.transform 7 37 env43287 = env43288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43287 == env43288) = true)

theorem identity43288 : scanCanonicalize (H12AffineFastState.compose env43288 (packedSelected [1,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound43288 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env43289 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,2248,41,2128,32768,35,34833,35032,237,32769,35033,32937,201,82,161,65,2184,2249,34832,34897,32837,113,37,113,34952,33360]

theorem envBound43289 : H12AffineFastState.Bounded env43289 := by
  intro p hp
  have h : env43289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43288_43289 : H12AffineEnvironment.transform 11 2248 env43288 = env43289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env43288 == env43289) = true)

theorem identity43289 : scanCanonicalize (H12AffineFastState.compose env43289 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound43289 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env43290 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,2248,41,2128,2049,35,16,217,237,2048,216,2216,201,82,161,65,2184,2249,17,80,2116,113,37,113,137,2641]

theorem envBound43290 : H12AffineFastState.Bounded env43290 := by
  intro p hp
  have h : env43290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43289_43290 : H12AffineEnvironment.transform 14 2049 env43289 = env43290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env43289 == env43290) = true)

theorem identity43290 : scanCanonicalize (H12AffineFastState.compose env43290 (packedSelected [0,2,6,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43290 : packedSelected [0,2,6,7,14] rootPS < 2^1333 := by decide +kernel

def env43291 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2113,41,2128,2049,35,16,80,100,2048,81,2081,64,82,40,65,2049,2112,17,80,2116,113,37,113,0,2641]

theorem envBound43291 : H12AffineFastState.Bounded env43291 := by
  intro p hp
  have h : env43291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43290_43291 : H12AffineEnvironment.transform 6 9 env43290 = env43291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43290 == env43291) = true)

def env43292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156133,485759,16777216,8328,65,16959642,18973836,2571311,108926,17231215,19072036,256,19312082,19287159,17287864]

theorem envBound43292 : H12AffineFastState.Bounded env43292 := by
  intro p hp
  have h : env43292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43224_43292 : H12AffineEnvironment.transform 21 156133 env43224 = env43292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env43224 == env43292) = true)

def env43293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,156133,485759,16777216,8328,65,16959642,17246588,102879,108926,17231215,17148372,256,16777250,16834951,17287864]

theorem envBound43293 : H12AffineFastState.Bounded env43293 := by
  intro p hp
  have h : env43293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43292_43293 : H12AffineEnvironment.transform 20 437744 env43292 = env43293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437744 env43292 == env43293) = true)

def env43294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,156133,120015,16777216,8328,65,16959642,16880844,102879,108926,16797919,16979044,256,16777250,16834951,16873224]

theorem envBound43294 : H12AffineFastState.Bounded env43294 := by
  intro p hp
  have h : env43294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43293_43294 : H12AffineEnvironment.transform 17 179632 env43293 = env43294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env43293 == env43294) = true)

def env43295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13744,34816,1024,32769,4160,21589,120015,16777216,8328,65,16842026,16880844,102879,108926,16797919,16851412,256,16777250,16834951,16873224]

theorem envBound43295 : H12AffineFastState.Bounded env43295 := by
  intro p hp
  have h : env43295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43294_43295 : H12AffineEnvironment.transform 16 13744 env43294 = env43295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13744 env43294 == env43295) = true)

theorem identity43295 : scanCanonicalize (H12AffineFastState.compose env43295 (packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound43295 : packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS < 2^1333 := by decide +kernel

def env43296 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,13388,34816,1024,32769,4160,21589,120015,16777216,8328,65,16841942,16880844,102435,108674,16797919,16850984,252,16777250,16834683,16873204]

theorem envBound43296 : H12AffineFastState.Bounded env43296 := by
  intro p hp
  have h : env43296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43295_43296 : H12AffineEnvironment.transform 7 252 env43295 = env43296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env43295 == env43296) = true)

def env43297 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,13388,10400,1024,8353,4160,21589,95343,16777216,8328,65,16800886,16856172,77955,67618,16797919,16850984,252,16777250,16793819,16873204]

theorem envBound43297 : H12AffineFastState.Bounded env43297 := by
  intro p hp
  have h : env43297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43296_43297 : H12AffineEnvironment.transform 14 8352 env43296 = env43297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env43296 == env43297) = true)

theorem identity43297 : scanCanonicalize (H12AffineFastState.compose env43297 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29942) := by decide +kernel

theorem selectedBound43297 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43298 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,29942,13388,10400,1024,8353,4160,21589,153,16777216,8328,65,16800886,16793754,17525,31956,16797919,16798942,252,16777250,16793819,16777730]

theorem envBound43298 : H12AffineFastState.Bounded env43298 := by
  intro p hp
  have h : env43298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43297_43298 : H12AffineEnvironment.transform 15 29942 env43297 = env43298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29942 env43297 == env43298) = true)

theorem identity43298 : scanCanonicalize (H12AffineFastState.compose env43298 (packedSelected [2,4,5,6,11,12,15,18,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound43298 : packedSelected [2,4,5,6,11,12,15,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env43299 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8352,8322,13388,10400,1024,8353,4160,33,153,16777216,8328,65,16779266,16782574,4097,10400,16778411,16777386,252,16777250,16782511,16777730]

theorem envBound43299 : H12AffineFastState.Bounded env43299 := by
  intro p hp
  have h : env43299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43298_43299 : H12AffineEnvironment.transform 13 5236 env43298 = env43299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env43298 == env43299) = true)

def env43300 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,13388,10401,1024,8352,4160,21589,95342,16777216,8328,65,16800887,16856173,77954,67619,16797919,16850984,252,16777250,16793818,16873204]

theorem envBound43300 : H12AffineFastState.Bounded env43300 := by
  intro p hp
  have h : env43300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43296_43300 : H12AffineEnvironment.transform 14 8353 env43296 = env43300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env43296 == env43300) = true)

theorem identity43300 : scanCanonicalize (H12AffineFastState.compose env43300 (packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS)) = affineNative (2^(23+1) ^^^ 8355) := by decide +kernel

theorem selectedBound43300 : packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env43301 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,13388,10401,1024,8352,4160,21589,95342,8355,8328,65,31956,70862,77954,67619,28796,65675,252,8321,24697,87639]

theorem envBound43301 : H12AffineFastState.Bounded env43301 := by
  intro p hp
  have h : env43301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43300_43301 : H12AffineEnvironment.transform 23 8355 env43300 = env43301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8355 env43300 == env43301) = true)

theorem identity43301 : scanCanonicalize (H12AffineFastState.compose env43301 (packedSelected [2,3,4,5,6,10,11,12,15,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound43301 : packedSelected [2,3,4,5,6,10,11,12,15,20,22,23] rootPS < 2^1333 := by decide +kernel

def env43302 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,34,13388,10401,1024,8352,4160,21589,29772,8355,8328,65,31956,5356,12448,2049,28796,169,252,8321,24697,22133]

theorem envBound43302 : H12AffineFastState.Bounded env43302 := by
  intro p hp
  have h : env43302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43301_43302 : H12AffineEnvironment.transform 15 34 env43301 = env43302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env43301 == env43302) = true)

theorem identity43302 : scanCanonicalize (H12AffineFastState.compose env43302 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound43302 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env43303 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8353,34,13388,10401,1024,8352,4160,33,8248,8355,8328,65,10400,5356,12448,2049,9224,169,252,8321,13325,513]

theorem envBound43303 : H12AffineFastState.Bounded env43303 := by
  intro p hp
  have h : env43303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43302_43303 : H12AffineEnvironment.transform 13 5236 env43302 = env43303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env43302 == env43303) = true)

theorem identity43303 : scanCanonicalize (H12AffineFastState.compose env43303 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43303 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43304 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,137,34,5220,2185,1024,136,4160,33,16,139,160,65,2184,5356,4232,2049,1056,169,252,169,5157,513]

theorem envBound43304 : H12AffineFastState.Bounded env43304 := by
  intro p hp
  have h : env43304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43303_43304 : H12AffineEnvironment.transform 12 40 env43303 = env43304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43303 == env43304) = true)

theorem identity43304 : scanCanonicalize (H12AffineFastState.compose env43304 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound43304 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43305 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,4096,40,4249,137,34,4233,2185,237,136,4160,33,16,139,160,65,2184,4097,4232,2049,205,169,252,169,4296,513]

theorem envBound43305 : H12AffineFastState.Bounded env43305 := by
  intro p hp
  have h : env43305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43304_43305 : H12AffineEnvironment.transform 9 237 env43304 = env43305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env43304 == env43305) = true)

theorem identity43305 : scanCanonicalize (H12AffineFastState.compose env43305 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound43305 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43306 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,97,40,248,137,34,232,2185,237,136,33,33,16,139,160,65,2184,96,233,2049,205,169,252,169,169,513]

theorem envBound43306 : H12AffineFastState.Bounded env43306 := by
  intro p hp
  have h : env43306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43305_43306 : H12AffineEnvironment.transform 11 97 env43305 = env43306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env43305 == env43306) = true)

theorem identity43306 : scanCanonicalize (H12AffineFastState.compose env43306 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound43306 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43307 : List Nat := [2,4,8,16,32,64,128,252,512,237,80,97,40,248,137,34,232,217,237,136,33,33,16,139,160,65,216,96,233,81,205,169,252,169,169,513]

theorem envBound43307 : H12AffineFastState.Bounded env43307 := by
  intro p hp
  have h : env43307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43306_43307 : H12AffineEnvironment.transform 10 80 env43306 = env43307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env43306 == env43307) = true)

theorem identity43307 : scanCanonicalize (H12AffineFastState.compose env43307 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43307 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env43308 : List Nat := [2,4,8,16,1,64,128,221,512,204,80,64,9,217,137,3,201,217,204,136,0,0,16,139,129,65,216,65,200,81,205,136,221,136,136,513]

theorem envBound43308 : H12AffineFastState.Bounded env43308 := by
  intro p hp
  have h : env43308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43307_43308 : H12AffineEnvironment.transform 4 1 env43307 = env43308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43307 == env43308) = true)

theorem identity43308 : scanCanonicalize (H12AffineFastState.compose env43308 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound43308 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43309 : List Nat := [2,4,8,16,1,64,128,221,217,204,80,64,9,217,137,3,201,217,204,136,0,0,16,139,129,65,216,65,200,81,205,136,221,136,136,216]

theorem envBound43309 : H12AffineFastState.Bounded env43309 := by
  intro p hp
  have h : env43309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43308_43309 : H12AffineEnvironment.transform 8 217 env43308 = env43309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env43308 == env43309) = true)

theorem identity43309 : scanCanonicalize (H12AffineFastState.compose env43309 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound43309 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env43310 : List Nat := [2,4,8,16,1,0,128,157,153,140,16,0,9,153,137,3,137,153,140,136,0,0,16,139,129,1,152,1,136,17,141,136,157,136,136,152]

theorem envBound43310 : H12AffineFastState.Bounded env43310 := by
  intro p hp
  have h : env43310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43309_43310 : H12AffineEnvironment.transform 5 0 env43309 = env43310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43309 == env43310) = true)

theorem identity43310 : scanCanonicalize (H12AffineFastState.compose env43310 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43310 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43311 : List Nat := [2,4,8,16,1,0,8,21,17,4,16,0,9,17,1,3,1,17,4,0,0,0,16,3,9,1,16,1,0,17,5,0,21,0,0,16]

theorem envBound43311 : H12AffineFastState.Bounded env43311 := by
  intro p hp
  have h : env43311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43310_43311 : H12AffineEnvironment.transform 6 8 env43310 = env43311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43310 == env43311) = true)

theorem identity43311 : scanCanonicalize (H12AffineFastState.compose env43311 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43311 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43312 : List Nat := [2,4,3,16,1,0,3,21,17,4,16,0,2,17,1,3,1,17,4,0,0,0,16,3,2,1,16,1,0,17,5,0,21,0,0,16]

theorem envBound43312 : H12AffineFastState.Bounded env43312 := by
  intro p hp
  have h : env43312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43311_43312 : H12AffineEnvironment.transform 2 3 env43311 = env43312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43311 == env43312) = true)

def env43313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13745,34817,1024,32769,4160,21588,120015,16777216,8328,65,16842027,16880844,102879,108926,16797919,16851413,256,16777250,16834951,16873224]

theorem envBound43313 : H12AffineFastState.Bounded env43313 := by
  intro p hp
  have h : env43313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43294_43313 : H12AffineEnvironment.transform 16 13745 env43294 = env43313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env43294 == env43313) = true)

theorem identity43313 : scanCanonicalize (H12AffineFastState.compose env43313 (packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43313 : packedSelected [1,3,7,8,10,12,17,19,20,24,26,27,35,38] rootPS < 2^1333 := by decide +kernel

def env43314 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,13508,34817,1024,32769,4160,21588,120015,16777216,8328,65,16841822,16880844,102570,108555,16797919,16851104,117,16777250,16834802,16873085]

theorem envBound43314 : H12AffineFastState.Bounded env43314 := by
  intro p hp
  have h : env43314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43313_43314 : H12AffineEnvironment.transform 7 117 env43313 = env43314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43313 == env43314) = true)

def env43315 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8352,65536,13508,10401,1024,8353,4160,21588,95343,16777216,8328,65,16801022,16856172,77834,67755,16797919,16851104,117,16777250,16793682,16873085]

theorem envBound43315 : H12AffineFastState.Bounded env43315 := by
  intro p hp
  have h : env43315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43314_43315 : H12AffineEnvironment.transform 14 8352 env43314 = env43315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env43314 == env43315) = true)

theorem identity43315 : scanCanonicalize (H12AffineFastState.compose env43315 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43315 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43316 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,13388,10281,1024,8233,4160,21588,95343,16777216,8192,65,16800886,16856172,77834,67619,16797783,16850984,117,16777250,16793682,16873085]

theorem envBound43316 : H12AffineFastState.Bounded env43316 := by
  intro p hp
  have h : env43316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43315_43316 : H12AffineEnvironment.transform 6 8 env43315 = env43316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43315 == env43316) = true)

theorem identity43316 : scanCanonicalize (H12AffineFastState.compose env43316 (packedSelected [2,4,6,11,12,15,20,22,23] rootPS)) = affineNative (2^(23+1) ^^^ 21622) := by decide +kernel

theorem selectedBound43316 : packedSelected [2,4,6,11,12,15,20,22,23] rootPS < 2^1333 := by decide +kernel

def env43317 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,13388,10281,1024,8233,4160,21588,95343,21622,8192,65,2048,90138,77834,67619,1057,95326,117,21588,5156,74251]

theorem envBound43317 : H12AffineFastState.Bounded env43317 := by
  intro p hp
  have h : env43317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43316_43317 : H12AffineEnvironment.transform 23 21622 env43316 = env43317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 21622 env43316 == env43317) = true)

theorem identity43317 : scanCanonicalize (H12AffineFastState.compose env43317 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43317 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env43318 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8232,65536,13388,10281,1024,8233,4160,33,73754,3,8192,65,2048,78959,77834,67619,1057,73771,117,33,5156,74251]

theorem envBound43318 : H12AffineFastState.Bounded env43318 := by
  intro p hp
  have h : env43318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43317_43318 : H12AffineEnvironment.transform 13 5237 env43317 = env43318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43317 == env43318) = true)

theorem identity43318 : scanCanonicalize (H12AffineFastState.compose env43318 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound43318 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env43319 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,9,5237,33,65536,5189,2080,1024,32,4160,33,65555,3,9,65,2048,70758,69635,67619,1057,65570,117,33,5156,66050]

theorem envBound43319 : H12AffineFastState.Bounded env43319 := by
  intro p hp
  have h : env43319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43318_43319 : H12AffineEnvironment.transform 12 9 env43318 = env43319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env43318 == env43319) = true)

theorem identity43319 : scanCanonicalize (H12AffineFastState.compose env43319 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43319 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43320 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5204,0,65536,5189,2049,1024,1,4160,0,65555,3,9,65,2048,70727,69635,67586,1024,65539,84,0,5125,66050]

theorem envBound43320 : H12AffineFastState.Bounded env43320 := by
  intro p hp
  have h : env43320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43319_43320 : H12AffineEnvironment.transform 4 1 env43319 = env43320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43319 == env43320) = true)

theorem identity43320 : scanCanonicalize (H12AffineFastState.compose env43320 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 6226) := by decide +kernel

theorem selectedBound43320 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env43321 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5204,0,6226,5189,2049,1024,1,4160,0,6209,3,9,65,2048,3093,2129,4176,1024,6225,84,0,5125,6736]

theorem envBound43321 : H12AffineFastState.Bounded env43321 := by
  intro p hp
  have h : env43321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43320_43321 : H12AffineEnvironment.transform 15 6226 env43320 = env43321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6226 env43320 == env43321) = true)

theorem identity43321 : scanCanonicalize (H12AffineFastState.compose env43321 (packedSelected [1,3,12] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound43321 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env43322 : List Nat := [2,4,8,16,1,26,8,14,512,1024,2048,4096,9,5134,0,6152,5151,2049,1024,1,4122,0,6171,3,9,27,2048,3093,2059,4106,1024,6155,14,0,5125,6666]

theorem envBound43322 : H12AffineFastState.Bounded env43322 := by
  intro p hp
  have h : env43322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43321_43322 : H12AffineEnvironment.transform 5 26 env43321 = env43322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env43321 == env43322) = true)

theorem identity43322 : scanCanonicalize (H12AffineFastState.compose env43322 (packedSelected [4,5,8,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound43322 : packedSelected [4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env43323 : List Nat := [2,4,8,16,1,26,8,14,512,1024,2048,1054,9,16,0,3094,1,2049,1024,1,1028,0,3077,3,9,27,2048,3093,2059,1044,1024,3093,14,0,27,3604]

theorem envBound43323 : H12AffineFastState.Bounded env43323 := by
  intro p hp
  have h : env43323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43322_43323 : H12AffineEnvironment.transform 11 1054 env43322 = env43323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env43322 == env43323) = true)

def env43324 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8353,65536,13508,10400,1024,8352,4160,21588,95342,16777216,8328,65,16801023,16856173,77835,67754,16797919,16851104,117,16777250,16793683,16873085]

theorem envBound43324 : H12AffineFastState.Bounded env43324 := by
  intro p hp
  have h : env43324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43314_43324 : H12AffineEnvironment.transform 14 8353 env43314 = env43324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env43314 == env43324) = true)

theorem identity43324 : scanCanonicalize (H12AffineFastState.compose env43324 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound43324 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43325 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8353,29823,13508,10400,1024,8352,4160,21588,17,16777216,8328,65,16801023,16793618,17524,31957,16797919,16798943,117,16777250,16793683,16777730]

theorem envBound43325 : H12AffineFastState.Bounded env43325 := by
  intro p hp
  have h : env43325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43324_43325 : H12AffineEnvironment.transform 15 29823 env43324 = env43325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env43324 == env43325) = true)

theorem identity43325 : scanCanonicalize (H12AffineFastState.compose env43325 (packedSelected [4,5,6,12,14,15,16,19,22,24] rootPS)) = affineNative (2^(23+1) ^^^ 29911) := by decide +kernel

theorem selectedBound43325 : packedSelected [4,5,6,12,14,15,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env43326 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8353,29823,13508,10400,1024,8352,4160,21588,17,29911,8328,65,10280,13509,17524,31957,9224,8200,117,29941,13444,30421]

theorem envBound43326 : H12AffineFastState.Bounded env43326 := by
  intro p hp
  have h : env43326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43325_43326 : H12AffineEnvironment.transform 23 29911 env43325 = env43326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 29911 env43325 == env43326) = true)

theorem identity43326 : scanCanonicalize (H12AffineFastState.compose env43326 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43326 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43327 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5237,8353,8202,13508,10400,1024,8352,4160,33,17,8354,8328,65,10280,13509,4097,10400,9224,8200,117,8320,13444,8864]

theorem envBound43327 : H12AffineFastState.Bounded env43327 := by
  intro p hp
  have h : env43327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43326_43327 : H12AffineEnvironment.transform 13 5237 env43326 = env43327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43326 == env43327) = true)

theorem identity43327 : scanCanonicalize (H12AffineFastState.compose env43327 (packedSelected [2,3,6,8,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound43327 : packedSelected [2,3,6,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43328 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,2601,5237,2696,2595,7917,649,1024,2697,4160,33,17,2699,2721,65,513,7916,4097,649,3617,2593,117,2729,7853,2185]

theorem envBound43328 : H12AffineFastState.Bounded env43328 := by
  intro p hp
  have h : env43328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43327_43328 : H12AffineEnvironment.transform 12 2601 env43327 = env43328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env43327 == env43328) = true)

theorem identity43328 : scanCanonicalize (H12AffineFastState.compose env43328 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound43328 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43329 : List Nat := [2,4,8,16,32,64,128,117,512,1024,649,4096,160,5237,1,170,5220,649,1024,0,4160,33,17,2,40,65,513,5221,4097,649,1192,168,117,32,5156,512]

theorem envBound43329 : H12AffineFastState.Bounded env43329 := by
  intro p hp
  have h : env43329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43328_43329 : H12AffineEnvironment.transform 10 649 env43328 = env43329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env43328 == env43329) = true)

theorem identity43329 : scanCanonicalize (H12AffineFastState.compose env43329 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound43329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43330 : List Nat := [2,4,8,16,32,64,121,117,512,1024,624,4096,89,5237,1,83,5220,624,1024,0,4160,33,17,2,40,65,513,5221,4097,624,1105,81,117,32,5156,512]

theorem envBound43330 : H12AffineFastState.Bounded env43330 := by
  intro p hp
  have h : env43330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0