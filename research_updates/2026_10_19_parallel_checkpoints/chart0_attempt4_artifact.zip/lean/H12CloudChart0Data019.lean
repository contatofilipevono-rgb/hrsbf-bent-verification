import H12CloudChart0Data018

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound4690 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4691 : List Nat := [2,4,8,16,32,16,128,5,512,1024,690,1693,19,1692,179,144,1588,570,1025,179,1692,32,184,139,154,185,539,1692,1588,658,1192,0,4,1,1589,512]

theorem envBound4691 : H12AffineFastState.Bounded env4691 := by
  intro p hp
  have h : env4691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4690_4691 : H12AffineEnvironment.transform 10 690 env4690 = env4691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 690 env4690 == env4691) = true)

theorem identity4691 : scanCanonicalize (H12AffineFastState.compose env4691 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound4691 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4692 : List Nat := [2,4,8,16,32,16,18,5,512,1024,544,1551,19,1550,33,2,1588,570,1025,33,1550,32,42,25,8,43,539,1550,1588,512,1082,0,4,1,1589,512]

theorem envBound4692 : H12AffineFastState.Bounded env4692 := by
  intro p hp
  have h : env4692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4691_4692 : H12AffineEnvironment.transform 6 18 env4691 = env4692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env4691 == env4692) = true)

theorem identity4692 : scanCanonicalize (H12AffineFastState.compose env4692 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4692 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env4693 : List Nat := [2,4,8,10,32,10,8,5,512,1024,544,1551,9,1550,33,2,1582,544,1025,33,1550,32,42,3,8,43,513,1550,1582,512,1056,0,4,1,1583,512]

theorem envBound4693 : H12AffineFastState.Bounded env4693 := by
  intro p hp
  have h : env4693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4692_4693 : H12AffineEnvironment.transform 3 10 env4692 = env4693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4692 == env4693) = true)

theorem identity4693 : scanCanonicalize (H12AffineFastState.compose env4693 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4693 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4694 : List Nat := [2,4,8,10,32,10,8,5,32,1024,0,1071,9,1070,33,2,1038,0,1025,33,1070,32,42,3,8,43,33,1070,1038,32,1056,0,4,1,1039,32]

theorem envBound4694 : H12AffineFastState.Bounded env4694 := by
  intro p hp
  have h : env4694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4693_4694 : H12AffineEnvironment.transform 8 32 env4693 = env4694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4693 == env4694) = true)

theorem identity4694 : scanCanonicalize (H12AffineFastState.compose env4694 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4694 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env4695 : List Nat := [2,4,8,10,1,10,8,5,1,1024,0,1038,9,1039,0,2,1038,0,1025,0,1039,1,11,3,8,10,0,1039,1038,1,1025,0,4,1,1039,1]

theorem envBound4695 : H12AffineFastState.Bounded env4695 := by
  intro p hp
  have h : env4695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4694_4695 : H12AffineEnvironment.transform 4 1 env4694 = env4695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4694 == env4695) = true)

theorem identity4695 : scanCanonicalize (H12AffineFastState.compose env4695 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4695 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4696 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1029,2,1028,0,2,1029,0,1025,0,1028,1,0,3,3,1,0,1028,1029,1,1025,0,4,1,1028,1]

theorem envBound4696 : H12AffineFastState.Bounded env4696 := by
  intro p hp
  have h : env4696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4695_4696 : H12AffineEnvironment.transform 2 3 env4695 = env4696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4695 == env4696) = true)

def leafEnv4696 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1029,2,1028,0,2,1029,0,1025,0,1028,1,0,3,1024,3,1,1,0,1028,1029,1,1025,0,4,1,5,2,1028,1,1,1029,0]

def active4696 : List Nat := [0,1,9]

def tree4696 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4696 : H12WitnessSearch.Good tree4696 := H12GlobalWitnessIndex.good

theorem leafIdentity4696 : H12AffineFastState.composeSystem env4696 rootObs = leafEnv4696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4696 rootObs == leafEnv4696) = true)

theorem terminalChecked4696 : H12PackedTerminal.terminalCheckFast leafEnv4696 active4696 tree4696 = true := by decide +kernel

def env4697 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4097,4194304,8388608,41003,8329,8388608,323713,16384,16812,22560,1452,12644668,257,20481,8405008,8389564]

theorem envBound4697 : H12AffineFastState.Bounded env4697 := by
  intro p hp
  have h : env4697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4681_4697 : H12AffineEnvironment.transform 5 17 env4681 = env4697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4681 == env4697) = true)

def env4698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2080,1025,32768,4097,4194304,8388608,41003,8329,8388608,63649,16384,16812,22560,1452,12644668,257,20481,8405008,8389564]

theorem envBound4698 : H12AffineFastState.Bounded env4698 := by
  intro p hp
  have h : env4698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4697_4698 : H12AffineEnvironment.transform 17 2080 env4697 = env4698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4697 == env4698) = true)

theorem identity4698 : scanCanonicalize (H12AffineFastState.compose env4698 (packedSelected [0,4,5,7,8,10,11,13,17,22,24,26,28,32] rootPS)) = affineNative (2^(22+1) ^^^ 4214833) := by decide +kernel

theorem selectedBound4698 : packedSelected [0,4,5,7,8,10,11,13,17,22,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env4699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2080,1025,32768,4097,4194304,4214833,41003,8329,4214833,63649,16384,16812,22560,1452,41229,257,20481,4198433,4215693]

theorem envBound4699 : H12AffineFastState.Bounded env4699 := by
  intro p hp
  have h : env4699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4698_4699 : H12AffineEnvironment.transform 22 4214833 env4698 = env4699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4214833 env4698 == env4699) = true)

theorem identity4699 : scanCanonicalize (H12AffineFastState.compose env4699 (packedSelected [0,2,3,5,6,11,12,20,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4699 : packedSelected [0,2,3,5,6,11,12,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4700 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,8234,4096,2080,1025,32768,4097,4194304,4214833,41003,8329,4214833,63649,16384,16385,22560,1025,41120,172,20481,4198433,4215328]

theorem envBound4700 : H12AffineFastState.Bounded env4700 := by
  intro p hp
  have h : env4700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4699_4700 : H12AffineEnvironment.transform 7 173 env4699 = env4700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4699 == env4700) = true)

theorem identity4700 : scanCanonicalize (H12AffineFastState.compose env4700 (packedSelected [2,4,5,6,7,15,21,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound4700 : packedSelected [2,4,5,6,7,15,21,23,24] rootPS < 2^1333 := by decide +kernel

def env4701 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,32768,8234,4096,2080,1025,32768,4097,4194304,4194353,41003,8329,4194353,43169,4096,4097,2080,1025,41120,172,1,4198433,4194848]

theorem envBound4701 : H12AffineFastState.Bounded env4701 := by
  intro p hp
  have h : env4701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4700_4701 : H12AffineEnvironment.transform 13 4096 env4700 = env4701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4700 == env4701) = true)

theorem identity4701 : scanCanonicalize (H12AffineFastState.compose env4701 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4701 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env4702 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,8200,8234,4096,2080,1025,8200,4097,4194304,4194353,35,8329,4194353,2217,4096,4097,2080,1025,168,172,1,4198433,4194848]

theorem envBound4702 : H12AffineFastState.Bounded env4702 := by
  intro p hp
  have h : env4702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4701_4702 : H12AffineEnvironment.transform 14 8200 env4701 = env4702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4701 == env4702) = true)

theorem identity4702 : scanCanonicalize (H12AffineFastState.compose env4702 (packedSelected [3,4,5,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound4702 : packedSelected [3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4703 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,2601,4096,2593,2563,4096,2080,1025,2593,4097,4194304,4194353,35,2720,4194353,2217,4096,4097,2080,1025,168,172,1,4198433,4194848]

theorem envBound4703 : H12AffineFastState.Bounded env4703 := by
  intro p hp
  have h : env4703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4702_4703 : H12AffineEnvironment.transform 12 2601 env4702 = env4703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env4702 == env4703) = true)

theorem identity4703 : scanCanonicalize (H12AffineFastState.compose env4703 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4703 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4704 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1588,2601,1588,2593,2563,1588,2080,1025,2593,1589,4194304,4194353,35,2720,4194353,2217,1588,1589,2080,1025,168,172,1,4195861,4194848]

theorem envBound4704 : H12AffineFastState.Bounded env4704 := by
  intro p hp
  have h : env4704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4703_4704 : H12AffineEnvironment.transform 11 1588 env4703 = env4704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env4703 == env4704) = true)

def env4705 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1588,2601,1588,2593,2563,1588,2080,1025,2593,1589,4194304,4194353,35,2568,4194353,2049,1588,1589,2080,1025,0,4,1,4195861,4194848]

theorem envBound4705 : H12AffineFastState.Bounded env4705 := by
  intro p hp
  have h : env4705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4704_4705 : H12AffineEnvironment.transform 6 40 env4704 = env4705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4704 == env4705) = true)

theorem identity4705 : scanCanonicalize (H12AffineFastState.compose env4705 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound4705 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4706 : List Nat := [2,4,8,16,17,17,25,5,512,1024,2048,1541,2584,1541,2576,2563,1541,2065,1025,2576,1540,4194304,4194304,18,2568,4194304,2049,1541,1540,2065,1025,0,4,1,4195861,4194833]

theorem envBound4706 : H12AffineFastState.Bounded env4706 := by
  intro p hp
  have h : env4706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4705_4706 : H12AffineEnvironment.transform 4 17 env4705 = env4706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env4705 == env4706) = true)

theorem identity4706 : scanCanonicalize (H12AffineFastState.compose env4706 (packedSelected [0,4] rootPS)) = affineNative (2^(21+1) ^^^ 2586) := by decide +kernel

theorem selectedBound4706 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4707 : List Nat := [2,4,8,16,17,17,25,5,512,1024,2048,1541,2584,1541,2576,2563,1541,2065,1025,2576,1540,2586,2586,18,2568,2586,2049,1541,1540,2065,1025,0,4,1,3087,2059]

theorem envBound4707 : H12AffineFastState.Bounded env4707 := by
  intro p hp
  have h : env4707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4706_4707 : H12AffineEnvironment.transform 21 2586 env4706 = env4707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2586 env4706 == env4707) = true)

theorem identity4707 : scanCanonicalize (H12AffineFastState.compose env4707 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound4707 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4708 : List Nat := [2,4,8,16,17,17,25,5,512,1024,512,1541,24,1541,16,3,1541,529,1025,16,1540,26,26,18,8,26,513,1541,1540,529,1025,0,4,1,1551,523]

theorem envBound4708 : H12AffineFastState.Bounded env4708 := by
  intro p hp
  have h : env4708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4707_4708 : H12AffineEnvironment.transform 10 512 env4707 = env4708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env4707 == env4708) = true)

theorem identity4708 : scanCanonicalize (H12AffineFastState.compose env4708 (packedSelected [0,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4708 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4709 : List Nat := [2,4,8,11,10,10,2,5,512,1024,512,1541,3,1541,11,3,1541,522,1025,11,1540,1,1,9,8,1,513,1541,1540,522,1025,0,4,1,1551,523]

theorem envBound4709 : H12AffineFastState.Bounded env4709 := by
  intro p hp
  have h : env4709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4708_4709 : H12AffineEnvironment.transform 3 11 env4708 = env4709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4708 == env4709) = true)

theorem identity4709 : scanCanonicalize (H12AffineFastState.compose env4709 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4710 : List Nat := [2,4,3,0,1,1,2,5,512,1024,512,1541,3,1541,0,3,1541,513,1025,0,1540,1,1,2,3,1,513,1541,1540,513,1025,0,4,1,1540,512]

theorem envBound4710 : H12AffineFastState.Bounded env4710 := by
  intro p hp
  have h : env4710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4709_4710 : H12AffineEnvironment.transform 2 3 env4709 = env4710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4709 == env4710) = true)

theorem identity4710 : scanCanonicalize (H12AffineFastState.compose env4710 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4711 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1028,3,1028,0,3,1028,0,1025,0,1029,1,1,2,3,1,0,1028,1029,0,1025,0,4,1,1029,1]

theorem envBound4711 : H12AffineFastState.Bounded env4711 := by
  intro p hp
  have h : env4711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4710_4711 : H12AffineEnvironment.transform 8 1 env4710 = env4711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4710 == env4711) = true)

def leafEnv4711 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1028,3,1028,0,3,1028,0,1025,0,1029,1,1,2,1024,3,1,1,0,1028,1029,0,1025,0,4,1,5,2,1029,1,1,1029,0]

def active4711 : List Nat := [0,1,9]

def tree4711 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4711 : H12WitnessSearch.Good tree4711 := H12GlobalWitnessIndex.good

theorem leafIdentity4711 : H12AffineFastState.composeSystem env4711 rootObs = leafEnv4711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4711 rootObs == leafEnv4711) = true)

theorem terminalChecked4711 : H12PackedTerminal.terminalCheckFast leafEnv4711 active4711 tree4711 = true := by decide +kernel

def env4712 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1588,2601,1588,2593,2563,1588,2080,1025,2593,1589,4194304,4194353,35,2569,4194353,2048,1588,1589,2080,1025,1,5,1,4195861,4194848]

theorem envBound4712 : H12AffineFastState.Bounded env4712 := by
  intro p hp
  have h : env4712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4704_4712 : H12AffineEnvironment.transform 6 41 env4704 = env4712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4704 == env4712) = true)

theorem identity4712 : scanCanonicalize (H12AffineFastState.compose env4712 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4712 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4713 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1588,1063,1588,1071,1037,1588,1582,1025,1071,1589,4194304,4194353,35,1031,4194353,1550,1588,1589,1582,1025,1,5,1,4195861,4194848]

theorem envBound4713 : H12AffineFastState.Bounded env4713 := by
  intro p hp
  have h : env4713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4712_4713 : H12AffineEnvironment.transform 10 1550 env4712 = env4713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4712 == env4713) = true)

theorem identity4713 : scanCanonicalize (H12AffineFastState.compose env4713 (packedSelected [2,11] rootPS)) = affineNative (2^(21+1) ^^^ 545) := by decide +kernel

theorem selectedBound4713 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env4714 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1588,1063,1588,1071,1037,1588,1582,1025,1071,1589,545,528,35,1031,528,1550,1588,1589,1582,1025,1,5,1,1076,1]

theorem envBound4714 : H12AffineFastState.Bounded env4714 := by
  intro p hp
  have h : env4714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4713_4714 : H12AffineEnvironment.transform 21 545 env4713 = env4714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 545 env4713 == env4714) = true)

theorem identity4714 : scanCanonicalize (H12AffineFastState.compose env4714 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound4714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4715 : List Nat := [2,4,8,16,32,17,41,4,512,53,571,513,18,513,26,56,513,539,52,26,512,545,528,35,50,528,571,513,512,539,52,1,5,1,1,1]

theorem envBound4715 : H12AffineFastState.Bounded env4715 := by
  intro p hp
  have h : env4715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4714_4715 : H12AffineEnvironment.transform 9 53 env4714 = env4715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env4714 == env4715) = true)

def env4716 : List Nat := [2,4,8,16,32,17,41,4,0,53,59,1,18,1,26,56,1,27,52,26,0,33,16,35,50,16,59,1,0,27,52,1,5,1,1,1]

theorem envBound4716 : H12AffineFastState.Bounded env4716 := by
  intro p hp
  have h : env4716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4715_4716 : H12AffineEnvironment.transform 8 0 env4715 = env4716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4715 == env4716) = true)

theorem identity4716 : scanCanonicalize (H12AffineFastState.compose env4716 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound4716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4717 : List Nat := [2,4,8,16,15,17,6,4,0,26,20,1,18,1,26,23,1,27,27,26,0,14,16,12,29,16,20,1,0,27,27,1,5,1,1,1]

theorem envBound4717 : H12AffineFastState.Bounded env4717 := by
  intro p hp
  have h : env4717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4716_4717 : H12AffineEnvironment.transform 4 15 env4716 = env4717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env4716 == env4717) = true)

theorem identity4717 : scanCanonicalize (H12AffineFastState.compose env4717 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound4717 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4718 : List Nat := [2,4,8,5,15,4,6,4,0,15,1,1,7,1,15,2,1,14,14,15,0,14,5,12,8,5,1,1,0,14,14,1,5,1,1,1]

theorem envBound4718 : H12AffineFastState.Bounded env4718 := by
  intro p hp
  have h : env4718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4717_4718 : H12AffineEnvironment.transform 3 5 env4717 = env4718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env4717 == env4718) = true)

theorem identity4718 : scanCanonicalize (H12AffineFastState.compose env4718 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4718 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4719 : List Nat := [2,1,8,0,10,1,3,1,0,10,1,1,2,1,10,2,1,11,11,10,0,11,0,9,8,0,1,1,0,11,11,1,0,1,1,1]

theorem envBound4719 : H12AffineFastState.Bounded env4719 := by
  intro p hp
  have h : env4719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4718_4719 : H12AffineEnvironment.transform 1 1 env4718 = env4719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4718 == env4719) = true)

def leafEnv4719 : List Nat := [2,1,8,0,10,1,3,1,0,10,1,1,2,1,10,2,1,11,11,10,0,11,0,9,10,8,1,0,1,1,0,11,11,1,0,1,0,8,1,1,1,0,0]

def active4719 : List Nat := [0,2]

def tree4719 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4719 : H12WitnessSearch.Good tree4719 := H12GlobalWitnessIndex.good

theorem leafIdentity4719 : H12AffineFastState.composeSystem env4719 rootObs = leafEnv4719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4719 rootObs == leafEnv4719) = true)

theorem terminalChecked4719 : H12PackedTerminal.terminalCheckFast leafEnv4719 active4719 tree4719 = true := by decide +kernel

def env4720 : List Nat := [2,4,8,16,32,17,41,4,1,53,58,0,18,0,26,56,0,26,52,26,1,32,17,35,50,17,58,0,1,26,52,1,5,1,1,1]

theorem envBound4720 : H12AffineFastState.Bounded env4720 := by
  intro p hp
  have h : env4720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4715_4720 : H12AffineEnvironment.transform 8 1 env4715 = env4720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4715 == env4720) = true)

theorem identity4720 : scanCanonicalize (H12AffineFastState.compose env4720 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4720 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4721 : List Nat := [2,4,8,10,32,11,41,4,1,47,32,0,8,0,0,34,0,0,46,0,1,32,11,35,40,11,32,0,1,0,46,1,5,1,1,1]

theorem envBound4721 : H12AffineFastState.Bounded env4721 := by
  intro p hp
  have h : env4721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4720_4721 : H12AffineEnvironment.transform 3 10 env4720 = env4721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4720 == env4721) = true)

def env4722 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2081,1025,32768,4097,4194304,8388608,41003,8329,8388608,63648,16384,16812,22560,1452,12644668,257,20481,8405008,8389564]

theorem envBound4722 : H12AffineFastState.Bounded env4722 := by
  intro p hp
  have h : env4722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4697_4722 : H12AffineEnvironment.transform 17 2081 env4697 = env4722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4697 == env4722) = true)

theorem identity4722 : scanCanonicalize (H12AffineFastState.compose env4722 (packedSelected [1,5,7,8,18,20,23,24,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235669) := by decide +kernel

theorem selectedBound4722 : packedSelected [1,5,7,8,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env4723 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2081,1025,32768,4097,4194304,4235669,41003,8329,4235669,63648,16384,16812,22560,1452,20649,257,20481,4252037,4235817]

theorem envBound4723 : H12AffineFastState.Bounded env4723 := by
  intro p hp
  have h : env4723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4722_4723 : H12AffineEnvironment.transform 22 4235669 env4722 = env4723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235669 env4722 == env4723) = true)

theorem identity4723 : scanCanonicalize (H12AffineFastState.compose env4723 (packedSelected [0,4,7,17,18,21,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound4723 : packedSelected [0,4,7,17,18,21,22,23] rootPS < 2^1333 := by decide +kernel

def env4724 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2081,1025,32768,4097,293,41136,41003,8329,41136,63648,16384,16812,22560,1452,20649,257,20481,57504,41740]

theorem envBound4724 : H12AffineFastState.Bounded env4724 := by
  intro p hp
  have h : env4724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4723_4724 : H12AffineEnvironment.transform 21 293 env4723 = env4724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env4723 == env4724) = true)

theorem identity4724 : scanCanonicalize (H12AffineFastState.compose env4724 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4724 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4725 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13884,8583,4525,2081,1025,13884,4097,293,5772,5655,8329,5772,20124,16384,16812,22560,1452,20649,257,20481,22172,5424]

theorem envBound4725 : H12AffineFastState.Bounded env4725 := by
  intro p hp
  have h : env4725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4724_4725 : H12AffineEnvironment.transform 14 13884 env4724 = env4725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4724 == env4725) = true)

theorem identity4725 : scanCanonicalize (H12AffineFastState.compose env4725 (packedSelected [0,1,3,4,7,9,13,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4725 : packedSelected [0,1,3,4,7,9,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env4726 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,13884,8495,4357,2081,1025,13884,4097,293,5668,5655,8225,5668,20020,16384,16644,22560,1284,20481,257,20481,22068,5424]

theorem envBound4726 : H12AffineFastState.Bounded env4726 := by
  intro p hp
  have h : env4726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4725_4726 : H12AffineEnvironment.transform 6 40 env4725 = env4726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4725 == env4726) = true)

theorem identity4726 : scanCanonicalize (H12AffineFastState.compose env4726 (packedSelected [1,2,3,4,6,9,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 778) := by decide +kernel

theorem selectedBound4726 : packedSelected [1,2,3,4,6,9,12,13] rootPS < 2^1333 := by decide +kernel

def env4727 : List Nat := [2,4,8,16,32,17,40,256,512,778,2048,4096,8192,16384,12598,8495,4357,2081,779,12598,4097,293,4398,4381,8225,4398,18750,16384,16644,22560,526,20481,257,20481,20798,4666]

theorem envBound4727 : H12AffineFastState.Bounded env4727 := by
  intro p hp
  have h : env4727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4726_4727 : H12AffineEnvironment.transform 9 778 env4726 = env4727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 778 env4726 == env4727) = true)

theorem identity4727 : scanCanonicalize (H12AffineFastState.compose env4727 (packedSelected [0,1,2,3,6,7,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 319) := by decide +kernel

theorem selectedBound4727 : packedSelected [0,1,2,3,6,7,12,17] rootPS < 2^1333 := by decide +kernel

def env4728 : List Nat := [2,4,8,16,32,17,40,256,512,778,2048,319,8192,16384,8201,8495,58,2081,779,8201,318,293,17,34,8225,17,18750,16384,16644,18719,526,16702,257,16702,16385,773]

theorem envBound4728 : H12AffineFastState.Bounded env4728 := by
  intro p hp
  have h : env4728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4727_4728 : H12AffineEnvironment.transform 11 319 env4727 = env4728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 319 env4727 == env4728) = true)

theorem identity4728 : scanCanonicalize (H12AffineFastState.compose env4728 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4728 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4729 : List Nat := [2,4,8,16,26,17,18,256,512,778,2048,261,8192,16384,8201,8469,0,2075,779,8201,260,287,17,24,8219,17,18692,16384,16644,18719,526,16644,257,16644,16385,773]

theorem envBound4729 : H12AffineFastState.Bounded env4729 := by
  intro p hp
  have h : env4729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4728_4729 : H12AffineEnvironment.transform 4 26 env4728 = env4729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4728 == env4729) = true)

theorem identity4729 : scanCanonicalize (H12AffineFastState.compose env4729 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound4729 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4730 : List Nat := [2,4,8,16,26,17,18,256,512,778,2048,261,8192,2048,8201,8469,0,2075,779,8201,260,287,17,24,8219,17,260,2048,2308,287,526,2308,257,2308,2049,773]

theorem envBound4730 : H12AffineFastState.Bounded env4730 := by
  intro p hp
  have h : env4730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4729_4730 : H12AffineEnvironment.transform 13 2048 env4729 = env4730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env4729 == env4730) = true)

theorem identity4730 : scanCanonicalize (H12AffineFastState.compose env4730 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound4730 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env4731 : List Nat := [2,4,8,16,26,17,18,256,512,778,2048,261,521,2048,512,796,0,2075,779,512,260,287,17,24,530,17,260,2048,2308,287,526,2308,257,2308,2049,773]

theorem envBound4731 : H12AffineFastState.Bounded env4731 := by
  intro p hp
  have h : env4731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4730_4731 : H12AffineEnvironment.transform 12 521 env4730 = env4731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env4730 == env4731) = true)

theorem identity4731 : scanCanonicalize (H12AffineFastState.compose env4731 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound4731 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4732 : List Nat := [2,4,8,16,26,17,18,256,512,778,0,261,521,0,512,796,0,27,779,512,260,287,17,24,530,17,260,0,260,287,526,260,257,260,1,773]

theorem envBound4732 : H12AffineFastState.Bounded env4732 := by
  intro p hp
  have h : env4732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4731_4732 : H12AffineEnvironment.transform 10 0 env4731 = env4732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env4731 == env4732) = true)

theorem identity4732 : scanCanonicalize (H12AffineFastState.compose env4732 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4733 : List Nat := [2,4,8,16,26,17,18,4,512,526,0,1,521,0,512,536,0,27,527,512,0,27,17,24,530,17,0,0,0,27,526,0,5,0,1,513]

theorem envBound4733 : H12AffineFastState.Bounded env4733 := by
  intro p hp
  have h : env4733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4732_4733 : H12AffineEnvironment.transform 7 4 env4732 = env4733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4732 == env4733) = true)

theorem identity4733 : scanCanonicalize (H12AffineFastState.compose env4733 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4733 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4734 : List Nat := [2,4,7,16,21,17,18,4,512,513,0,1,518,0,512,535,0,20,512,512,0,20,17,23,530,17,0,0,0,20,513,0,5,0,1,513]

theorem envBound4734 : H12AffineFastState.Bounded env4734 := by
  intro p hp
  have h : env4734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4733_4734 : H12AffineEnvironment.transform 2 7 env4733 = env4734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4733 == env4734) = true)

theorem identity4734 : scanCanonicalize (H12AffineFastState.compose env4734 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound4734 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4735 : List Nat := [2,4,7,5,0,4,7,4,512,513,0,1,518,0,512,514,0,1,512,512,0,1,4,2,519,4,0,0,0,1,513,0,5,0,1,513]

theorem envBound4735 : H12AffineFastState.Bounded env4735 := by
  intro p hp
  have h : env4735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4734_4735 : H12AffineEnvironment.transform 3 5 env4734 = env4735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env4734 == env4735) = true)

theorem identity4735 : scanCanonicalize (H12AffineFastState.compose env4735 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4736 : List Nat := [2,4,7,5,0,4,7,4,0,1,0,1,6,0,0,2,0,1,0,0,0,1,4,2,7,4,0,0,0,1,1,0,5,0,1,1]

theorem envBound4736 : H12AffineFastState.Bounded env4736 := by
  intro p hp
  have h : env4736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4735_4736 : H12AffineEnvironment.transform 8 0 env4735 = env4736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4735 == env4736) = true)

def env4737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849105,16385,16892,547952,598058,12644668,525568,545873,8479127,8914924]

theorem envBound4737 : H12AffineFastState.Bounded env4737 := by
  intro p hp
  have h : env4737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4621_4737 : H12AffineEnvironment.transform 27 16385 env4621 = env4737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env4621 == env4737) = true)

def env4738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323793,16385,16892,22640,74794,12644668,256,20561,8479127,8389612]

theorem envBound4738 : H12AffineFastState.Bounded env4738 := by
  intro p hp
  have h : env4738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4737_4738 : H12AffineEnvironment.transform 18 1024 env4737 = env4738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4737 == env4738) = true)

theorem identity4738 : scanCanonicalize (H12AffineFastState.compose env4738 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115783) := by decide +kernel

theorem selectedBound4738 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,115783,8388608,41003,8329,8388688,323793,16385,16892,22640,74794,8467835,256,20561,8479127,8389612]

theorem envBound4739 : H12AffineFastState.Bounded env4739 := by
  intro p hp
  have h : env4739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4738_4739 : H12AffineEnvironment.transform 21 115783 env4738 = env4739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115783 env4738 == env4739) = true)

def env4740 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115735,8388608,41003,8329,8388608,323713,16385,16812,22560,74794,8467755,256,20481,8479127,8389564]

theorem envBound4740 : H12AffineFastState.Bounded env4740 := by
  intro p hp
  have h : env4740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4739_4740 : H12AffineEnvironment.transform 5 16 env4739 = env4740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4739 == env4740) = true)

theorem identity4740 : scanCanonicalize (H12AffineFastState.compose env4740 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4740 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4741 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115735,444,41003,8329,444,323713,16385,16812,22560,74794,78999,256,20481,90155,512]

theorem envBound4741 : H12AffineFastState.Bounded env4741 := by
  intro p hp
  have h : env4741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4740_4741 : H12AffineEnvironment.transform 22 444 env4740 = env4741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4740 == env4741) = true)

theorem identity4741 : scanCanonicalize (H12AffineFastState.compose env4741 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound4741 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4742 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1024,32768,4097,41349,444,41003,8329,444,323713,16385,16812,22560,16824,20741,256,20481,1465,512]

theorem envBound4742 : H12AffineFastState.Bounded env4742 := by
  intro p hp
  have h : env4742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4741_4742 : H12AffineEnvironment.transform 15 26002 env4741 = env4742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env4741 == env4742) = true)

theorem identity4742 : scanCanonicalize (H12AffineFastState.compose env4742 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4742 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4743 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26002,4524,262144,1024,29225,4097,21420,444,20994,8329,444,262824,16385,16812,22560,16824,20741,256,20481,1465,512]

theorem envBound4743 : H12AffineFastState.Bounded env4743 := by
  intro p hp
  have h : env4743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4742_4743 : H12AffineEnvironment.transform 14 29225 env4742 = env4743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4742 == env4743) = true)

theorem identity4743 : scanCanonicalize (H12AffineFastState.compose env4743 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4743 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4744 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26002,1213,262144,1024,26424,1296,18109,444,18195,8329,444,262824,16385,16812,19761,16824,17428,256,17680,1465,512]

theorem envBound4744 : H12AffineFastState.Bounded env4744 := by
  intro p hp
  have h : env4744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4743_4744 : H12AffineEnvironment.transform 11 1297 env4743 = env4744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4743 == env4744) = true)

theorem identity4744 : scanCanonicalize (H12AffineFastState.compose env4744 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4744 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4745 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,26424,25914,1045,262144,1024,26424,1296,17941,276,18195,8225,276,262656,16385,16644,19761,16656,17428,256,17680,1297,512]

theorem envBound4745 : H12AffineFastState.Bounded env4745 := by
  intro p hp
  have h : env4745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4744_4745 : H12AffineEnvironment.transform 6 40 env4744 = env4745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4744 == env4745) = true)

def env4746 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115734,8388608,41003,8329,8388609,323712,16385,16813,22561,74794,8467754,256,20480,8479127,8389565]

theorem envBound4746 : H12AffineFastState.Bounded env4746 := by
  intro p hp
  have h : env4746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4739_4746 : H12AffineEnvironment.transform 5 17 env4739 = env4746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4739 == env4746) = true)

def env4747 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115734,5376,41003,8329,5377,323712,16385,16813,22561,74794,73770,256,20480,95383,5821]

theorem envBound4747 : H12AffineFastState.Bounded env4747 := by
  intro p hp
  have h : env4747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4746_4747 : H12AffineEnvironment.transform 22 5376 env4746 = env4747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5376 env4746 == env4747) = true)

theorem identity4747 : scanCanonicalize (H12AffineFastState.compose env4747 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound4747 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4748 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,28681,65536,4525,262144,1024,28681,4097,78879,5376,20514,8329,5377,262281,16385,16813,22561,74794,73770,256,20480,95383,5821]

theorem envBound4748 : H12AffineFastState.Bounded env4748 := by
  intro p hp
  have h : env4748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4747_4748 : H12AffineEnvironment.transform 14 28681 env4747 = env4748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env4747 == env4748) = true)

theorem identity4748 : scanCanonicalize (H12AffineFastState.compose env4748 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound4748 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env4749 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,25780,65536,1296,262144,1024,25780,1212,73890,445,17567,8329,444,262281,16385,16813,19612,74794,73770,256,17597,90154,512]

theorem envBound4749 : H12AffineFastState.Bounded env4749 := by
  intro p hp
  have h : env4749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4748_4749 : H12AffineEnvironment.transform 11 1213 env4748 = env4749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env4748 == env4749) = true)

theorem identity4749 : scanCanonicalize (H12AffineFastState.compose env4749 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4749 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4750 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,16384,25780,65536,1213,262144,1024,25780,1212,73890,16,17567,8329,17,262281,16385,16384,19612,74794,73770,173,17597,90154,512]

theorem envBound4750 : H12AffineFastState.Bounded env4750 := by
  intro p hp
  have h : env4750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4749_4750 : H12AffineEnvironment.transform 7 173 env4749 = env4750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4749 == env4750) = true)

theorem identity4750 : scanCanonicalize (H12AffineFastState.compose env4750 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 3222) := by decide +kernel

theorem selectedBound4750 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4751 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,3222,10274,65536,1213,262144,1024,10274,1212,73890,16,2057,8329,17,262281,3223,3222,10,74794,73770,173,2091,76988,512]

theorem envBound4751 : H12AffineFastState.Bounded env4751 := by
  intro p hp
  have h : env4751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4750_4751 : H12AffineEnvironment.transform 13 3222 env4750 = env4751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3222 env4750 == env4751) = true)

theorem identity4751 : scanCanonicalize (H12AffineFastState.compose env4751 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 178) := by decide +kernel

theorem selectedBound4751 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4752 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,3222,10274,65536,1213,178,1024,10274,1212,73890,16,2057,8329,17,59,3223,3222,10,74794,73770,173,2091,76988,512]

theorem envBound4752 : H12AffineFastState.Bounded env4752 := by
  intro p hp
  have h : env4752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4751_4752 : H12AffineEnvironment.transform 17 178 env4751 = env4752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 178 env4751 == env4752) = true)

theorem identity4752 : scanCanonicalize (H12AffineFastState.compose env4752 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4752 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4753 : List Nat := [2,4,8,16,32,17,128,173,33,1024,2048,1213,8192,3222,10274,65536,1213,178,1024,10274,1212,73890,16,2057,8329,17,59,3223,3222,10,74794,73770,173,2091,76988,33]

theorem envBound4753 : H12AffineFastState.Bounded env4753 := by
  intro p hp
  have h : env4753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4752_4753 : H12AffineEnvironment.transform 8 33 env4752 = env4753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4752 == env4753) = true)

theorem identity4753 : scanCanonicalize (H12AffineFastState.compose env4753 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 10408) := by decide +kernel

theorem selectedBound4753 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4754 : List Nat := [2,4,8,16,32,17,128,173,33,1024,2048,1213,8192,3222,10274,10408,1213,178,1024,10274,1212,2058,16,2057,8329,17,59,3223,3222,10,3202,2178,173,2091,1044,33]

theorem envBound4754 : H12AffineFastState.Bounded env4754 := by
  intro p hp
  have h : env4754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4753_4754 : H12AffineEnvironment.transform 15 10408 env4753 = env4754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10408 env4753 == env4754) = true)

theorem identity4754 : scanCanonicalize (H12AffineFastState.compose env4754 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound4754 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4755 : List Nat := [2,4,8,16,32,17,128,173,33,1024,59,1213,8192,1197,8217,8339,1213,178,1024,8217,1212,49,16,50,8329,17,59,1196,1197,10,1209,185,173,16,1044,33]

theorem envBound4755 : H12AffineFastState.Bounded env4755 := by
  intro p hp
  have h : env4755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4754_4755 : H12AffineEnvironment.transform 10 59 env4754 = env4755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env4754 == env4755) = true)

def env4756 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115734,5377,41003,8329,5376,323712,16385,16813,22561,74794,73771,256,20480,95382,5820]

theorem envBound4756 : H12AffineFastState.Bounded env4756 := by
  intro p hp
  have h : env4756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4746_4756 : H12AffineEnvironment.transform 22 5377 env4746 = env4756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5377 env4746 == env4756) = true)

theorem identity4756 : scanCanonicalize (H12AffineFastState.compose env4756 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4756 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env4757 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4097,115734,5377,41003,8225,5376,323624,16385,16645,22561,74794,73771,256,20480,95294,5652]

theorem envBound4757 : H12AffineFastState.Bounded env4757 := by
  intro p hp
  have h : env4757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4756_4757 : H12AffineEnvironment.transform 6 40 env4756 = env4757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4756 == env4757) = true)

theorem identity4757 : scanCanonicalize (H12AffineFastState.compose env4757 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4757 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env4758 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8200,65536,4357,262144,1024,8200,4097,91166,5377,35,8225,5376,282656,16385,16645,22561,74794,73771,256,20480,95294,5652]

theorem envBound4758 : H12AffineFastState.Bounded env4758 := by
  intro p hp
  have h : env4758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4757_4758 : H12AffineEnvironment.transform 14 8200 env4757 = env4758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4757 == env4758) = true)

theorem identity4758 : scanCanonicalize (H12AffineFastState.compose env4758 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4758 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4759 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8200,65536,4357,2080,1024,8200,4097,91166,5377,35,8225,5376,22528,16385,16645,22561,74794,73771,256,20480,95294,5652]

theorem envBound4759 : H12AffineFastState.Bounded env4759 := by
  intro p hp
  have h : env4759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4758_4759 : H12AffineEnvironment.transform 17 2080 env4758 = env4759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4758 == env4759) = true)

theorem identity4759 : scanCanonicalize (H12AffineFastState.compose env4759 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4128) := by decide +kernel

theorem selectedBound4759 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env4760 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4128,8200,65536,4357,2080,1024,8200,4097,78910,5377,35,8225,5376,2080,4129,4389,2049,74794,73771,256,32,74782,5652]

theorem envBound4760 : H12AffineFastState.Bounded env4760 := by
  intro p hp
  have h : env4760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4759_4760 : H12AffineEnvironment.transform 13 4128 env4759 = env4760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4128 env4759 == env4760) = true)

theorem identity4760 : scanCanonicalize (H12AffineFastState.compose env4760 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound4760 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env4761 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4128,8200,2342,4357,2080,1024,8200,4097,15640,5377,35,8225,5376,2080,4129,4389,2049,11532,10509,256,32,11576,5652]

theorem envBound4761 : H12AffineFastState.Bounded env4761 := by
  intro p hp
  have h : env4761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4760_4761 : H12AffineEnvironment.transform 15 2342 env4760 = env4761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env4760 == env4761) = true)

theorem identity4761 : scanCanonicalize (H12AffineFastState.compose env4761 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4761 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4762 : List Nat := [2,4,8,16,32,17,40,256,512,1024,1841,4096,8192,4128,8200,1559,4357,1809,1024,8200,4097,12841,5377,35,8225,5376,1809,4129,4389,1840,8765,9788,256,32,8713,5652]

theorem envBound4762 : H12AffineFastState.Bounded env4762 := by
  intro p hp
  have h : env4762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4761_4762 : H12AffineEnvironment.transform 10 1841 env4761 = env4762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1841 env4761 == env4762) = true)

theorem identity4762 : scanCanonicalize (H12AffineFastState.compose env4762 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4762 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env4763 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1588,4096,8192,4128,8200,1559,4096,1556,1024,8200,4097,12841,5124,35,8225,5125,1556,4129,4128,1589,8765,9788,5,32,8713,5652]

theorem envBound4763 : H12AffineFastState.Bounded env4763 := by
  intro p hp
  have h : env4763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4762_4763 : H12AffineEnvironment.transform 7 5 env4762 = env4763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4762 == env4763) = true)

theorem identity4763 : scanCanonicalize (H12AffineFastState.compose env4763 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4763 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4764 : List Nat := [2,4,8,10,32,11,40,5,512,1024,1582,4096,8192,4128,8200,1549,4096,1550,1024,8200,4097,12841,5124,35,8225,5125,1550,4129,4128,1583,8743,9766,5,32,8713,5646]

theorem envBound4764 : H12AffineFastState.Bounded env4764 := by
  intro p hp
  have h : env4764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4763_4764 : H12AffineEnvironment.transform 3 10 env4763 = env4764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4763 == env4764) = true)

theorem identity4764 : scanCanonicalize (H12AffineFastState.compose env4764 (packedSelected [10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound4764 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env4765 : List Nat := [2,4,8,10,32,11,40,5,512,1024,1582,4096,1542,4128,1550,1549,4096,1550,1024,1550,4097,5167,5124,35,1575,5125,1550,4129,4128,1583,1057,32,5,32,1039,5646]

theorem envBound4765 : H12AffineFastState.Bounded env4765 := by
  intro p hp
  have h : env4765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4764_4765 : H12AffineEnvironment.transform 12 1542 env4764 = env4765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env4764 == env4765) = true)

def env4766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323792,16385,16892,22641,74795,12644668,257,20560,8479127,8389613]

theorem envBound4766 : H12AffineFastState.Bounded env4766 := by
  intro p hp
  have h : env4766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4737_4766 : H12AffineEnvironment.transform 18 1025 env4737 = env4766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4737 == env4766) = true)

theorem identity4766 : scanCanonicalize (H12AffineFastState.compose env4766 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4292935) := by decide +kernel

theorem selectedBound4766 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,4292935,41003,8329,4292886,323792,16385,16892,22641,74795,94331,257,20560,4251856,4293290]

theorem envBound4767 : H12AffineFastState.Bounded env4767 := by
  intro p hp
  have h : env4767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4766_4767 : H12AffineEnvironment.transform 22 4292935 env4766 = env4767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292935 env4766 == env4767) = true)

def env4768 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4292887,41003,8329,4292886,323712,16385,16812,22561,74795,94251,257,20480,4251776,4293290]

theorem envBound4768 : H12AffineFastState.Bounded env4768 := by
  intro p hp
  have h : env4768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4767_4768 : H12AffineEnvironment.transform 5 16 env4767 = env4768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4767 == env4768) = true)

def env4769 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4097,4194304,4292887,41003,8329,4292886,303232,4097,4524,2081,74795,73771,257,0,4239488,4293290]

theorem envBound4769 : H12AffineFastState.Bounded env4769 := by
  intro p hp
  have h : env4769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4768_4769 : H12AffineEnvironment.transform 13 4096 env4768 = env4769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4768 == env4769) = true)

theorem identity4769 : scanCanonicalize (H12AffineFastState.compose env4769 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33062) := by decide +kernel

theorem selectedBound4769 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env4770 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33062,4524,262144,1025,32768,4097,4194304,4194353,41003,8329,4194352,303232,4097,4524,2081,42253,41229,257,0,4239488,4195212]

theorem envBound4770 : H12AffineFastState.Bounded env4770 := by
  intro p hp
  have h : env4770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4769_4770 : H12AffineEnvironment.transform 15 33062 env4769 = env4770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33062 env4769 == env4770) = true)

def env4771 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8494,4524,262144,1025,8200,4097,4194304,4194353,35,8329,4194352,262280,4097,4524,2081,1285,261,257,0,4198536,4195212]

theorem envBound4771 : H12AffineFastState.Bounded env4771 := by
  intro p hp
  have h : env4771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4770_4771 : H12AffineEnvironment.transform 14 8200 env4770 = env4771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4770 == env4771) = true)

theorem identity4771 : scanCanonicalize (H12AffineFastState.compose env4771 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266386) := by decide +kernel

theorem selectedBound4771 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4772 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8494,4524,262144,1025,8200,4097,266386,266403,35,8329,266402,262280,4097,4524,2081,1285,261,257,0,262170,267038]

theorem envBound4772 : H12AffineFastState.Bounded env4772 := by
  intro p hp
  have h : env4772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4771_4772 : H12AffineEnvironment.transform 21 266386 env4771 = env4772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266386 env4771 == env4772) = true)

theorem identity4772 : scanCanonicalize (H12AffineFastState.compose env4772 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1923) := by decide +kernel

theorem selectedBound4772 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4773 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8494,4524,1923,1025,8200,4097,5905,5920,35,8329,5921,1803,4097,4524,2081,1285,261,257,0,1945,5277]

theorem envBound4773 : H12AffineFastState.Bounded env4773 := by
  intro p hp
  have h : env4773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4772_4773 : H12AffineEnvironment.transform 17 1923 env4772 = env4773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1923 env4772 == env4773) = true)

theorem identity4773 : scanCanonicalize (H12AffineFastState.compose env4773 (packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS)) = affineNative (2^(10+1) ^^^ 1954) := by decide +kernel

theorem selectedBound4773 : packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS < 2^1333 := by decide +kernel

def env4774 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1954,4096,8192,4096,8200,8494,4524,1923,1025,8200,4097,5905,5920,35,8329,5921,1803,4097,4524,1923,1285,261,257,0,1945,5277]

theorem envBound4774 : H12AffineFastState.Bounded env4774 := by
  intro p hp
  have h : env4774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4773_4774 : H12AffineEnvironment.transform 10 1954 env4773 = env4774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1954 env4773 == env4774) = true)

theorem identity4774 : scanCanonicalize (H12AffineFastState.compose env4774 (packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4762) := by decide +kernel

theorem selectedBound4774 : packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4775 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1954,4096,4762,4096,4754,5044,4524,1923,1025,4754,4097,5905,5920,35,4627,5921,1803,4097,4524,1923,1285,261,257,0,1945,5277]

theorem envBound4775 : H12AffineFastState.Bounded env4775 := by
  intro p hp
  have h : env4775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4774_4775 : H12AffineEnvironment.transform 12 4762 env4774 = env4775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4762 env4774 == env4775) = true)

theorem identity4775 : scanCanonicalize (H12AffineFastState.compose env4775 (packedSelected [1,4,7,8,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound4775 : packedSelected [1,4,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env4776 : List Nat := [2,4,8,16,32,16,128,256,168,1024,1290,4096,4146,4096,4154,4380,4524,1323,1025,4154,4097,5561,5512,35,4283,5513,1443,4097,4524,1323,1285,261,257,0,1329,5277]

theorem envBound4776 : H12AffineFastState.Bounded env4776 := by
  intro p hp
  have h : env4776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4775_4776 : H12AffineEnvironment.transform 8 168 env4775 = env4776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env4775 == env4776) = true)

theorem identity4776 : scanCanonicalize (H12AffineFastState.compose env4776 (packedSelected [0,1,2,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound4776 : packedSelected [0,1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env4777 : List Nat := [2,4,8,16,32,16,128,256,168,1024,1290,260,310,260,318,24,168,1323,1025,318,261,1213,1164,35,447,1165,1443,261,168,1323,1285,261,257,0,1329,1433]

theorem envBound4777 : H12AffineFastState.Bounded env4777 := by
  intro p hp
  have h : env4777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4776_4777 : H12AffineEnvironment.transform 11 260 env4776 = env4777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env4776 == env4777) = true)

theorem identity4777 : scanCanonicalize (H12AffineFastState.compose env4777 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4777 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env4778 : List Nat := [2,4,8,16,32,16,128,5,168,1024,1039,1,51,1,59,24,168,1070,1025,59,0,1213,1164,35,186,1165,1190,0,168,1070,1024,0,4,0,1076,1180]

theorem envBound4778 : H12AffineFastState.Bounded env4778 := by
  intro p hp
  have h : env4778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4777_4778 : H12AffineEnvironment.transform 7 5 env4777 = env4778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4777 == env4778) = true)

theorem identity4778 : scanCanonicalize (H12AffineFastState.compose env4778 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4778 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env4779 : List Nat := [2,4,8,16,32,16,41,5,1,1024,1039,1,51,1,59,24,1,1070,1025,59,0,1044,1061,35,19,1060,1039,0,1,1070,1024,0,4,0,1076,1077]

theorem envBound4779 : H12AffineFastState.Bounded env4779 := by
  intro p hp
  have h : env4779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4778_4779 : H12AffineEnvironment.transform 6 41 env4778 = env4779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4778 == env4779) = true)

def env4780 : List Nat := [2,4,8,16,32,16,41,5,1,32,47,1,51,1,59,24,1,14,33,59,0,52,5,35,19,4,47,0,1,14,32,0,4,0,20,21]

theorem envBound4780 : H12AffineFastState.Bounded env4780 := by
  intro p hp
  have h : env4780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4779_4780 : H12AffineEnvironment.transform 9 32 env4779 = env4780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4779 == env4780) = true)

def env4781 : List Nat := [2,4,8,16,0,16,9,5,1,0,15,1,19,1,27,24,1,14,1,27,0,20,5,3,19,4,15,0,1,14,0,0,4,0,20,21]

theorem envBound4781 : H12AffineFastState.Bounded env4781 := by
  intro p hp
  have h : env4781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4780_4781 : H12AffineEnvironment.transform 4 0 env4780 = env4781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4780 == env4781) = true)

theorem identity4781 : scanCanonicalize (H12AffineFastState.compose env4781 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4781 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4782 : List Nat := [2,4,8,11,0,11,9,5,1,0,15,1,8,1,0,3,1,14,1,0,0,15,5,3,8,4,15,0,1,14,0,0,4,0,15,14]

theorem envBound4782 : H12AffineFastState.Bounded env4782 := by
  intro p hp
  have h : env4782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4781_4782 : H12AffineEnvironment.transform 3 11 env4781 = env4782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4781 == env4782) = true)

def env4783 : List Nat := [2,0,8,11,0,11,9,1,1,0,11,1,8,1,0,3,1,10,1,0,0,11,1,3,8,0,11,0,1,10,0,0,0,0,11,10]

theorem envBound4783 : H12AffineFastState.Bounded env4783 := by
  intro p hp
  have h : env4783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4782_4783 : H12AffineEnvironment.transform 1 0 env4782 = env4783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4782 == env4783) = true)

theorem identity4783 : scanCanonicalize (H12AffineFastState.compose env4783 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4783 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4784 : List Nat := [2,0,2,1,0,1,3,1,1,0,1,1,2,1,0,3,1,0,1,0,0,1,1,3,2,0,1,0,1,0,0,0,0,0,1,0]

theorem envBound4784 : H12AffineFastState.Bounded env4784 := by
  intro p hp
  have h : env4784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4783_4784 : H12AffineEnvironment.transform 2 2 env4783 = env4784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4783 == env4784) = true)

def leafEnv4784 : List Nat := [2,0,2,1,0,1,3,1,1,0,1,1,2,1,0,3,1,0,1,0,0,1,1,3,1,2,1,0,1,0,1,0,0,0,0,0,1,3,1,0,1,0,0]

def active4784 : List Nat := [0]

def tree4784 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4784 : H12WitnessSearch.Good tree4784 := H12GlobalWitnessIndex.good

theorem leafIdentity4784 : H12AffineFastState.composeSystem env4784 rootObs = leafEnv4784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4784 rootObs == leafEnv4784) = true)

theorem terminalChecked4784 : H12PackedTerminal.terminalCheckFast leafEnv4784 active4784 tree4784 = true := by decide +kernel

def env4785 : List Nat := [2,1,8,11,0,11,9,0,1,0,10,1,8,1,0,3,1,11,1,0,0,10,0,3,8,1,10,0,1,11,0,0,1,0,10,11]

theorem envBound4785 : H12AffineFastState.Bounded env4785 := by
  intro p hp
  have h : env4785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4782_4785 : H12AffineEnvironment.transform 1 1 env4782 = env4785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4782 == env4785) = true)

def env4786 : List Nat := [2,4,8,16,1,16,8,5,1,1,14,1,18,1,26,24,1,14,0,26,0,21,5,2,19,4,14,0,1,14,1,0,4,0,20,21]

theorem envBound4786 : H12AffineFastState.Bounded env4786 := by
  intro p hp
  have h : env4786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4780_4786 : H12AffineEnvironment.transform 4 1 env4780 = env4786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4780 == env4786) = true)

theorem identity4786 : scanCanonicalize (H12AffineFastState.compose env4786 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4786 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4787 : List Nat := [2,4,6,16,1,16,6,5,1,1,0,1,18,1,20,22,1,0,0,20,0,21,5,2,19,4,0,0,1,0,1,0,4,0,20,21]

theorem envBound4787 : H12AffineFastState.Bounded env4787 := by
  intro p hp
  have h : env4787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4786_4787 : H12AffineEnvironment.transform 2 6 env4786 = env4787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4786 == env4787) = true)

def env4788 : List Nat := [2,4,6,0,1,0,6,5,1,1,0,1,2,1,4,6,1,0,0,4,0,5,5,2,3,4,0,0,1,0,1,0,4,0,4,5]

theorem envBound4788 : H12AffineFastState.Bounded env4788 := by
  intro p hp
  have h : env4788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4787_4788 : H12AffineEnvironment.transform 3 0 env4787 = env4788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4787 == env4788) = true)

def env4789 : List Nat := [2,4,6,1,1,1,6,5,1,1,0,1,3,1,5,7,1,0,0,5,0,4,5,2,2,4,0,0,1,0,1,0,4,0,5,4]

theorem envBound4789 : H12AffineFastState.Bounded env4789 := by
  intro p hp
  have h : env4789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4787_4789 : H12AffineEnvironment.transform 3 1 env4787 = env4789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4787 == env4789) = true)

theorem identity4789 : scanCanonicalize (H12AffineFastState.compose env4789 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4789 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4790 : List Nat := [2,0,2,1,1,1,2,1,1,1,0,1,3,1,1,3,1,0,0,1,0,0,1,2,2,0,0,0,1,0,1,0,0,0,1,0]

theorem envBound4790 : H12AffineFastState.Bounded env4790 := by
  intro p hp
  have h : env4790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4789_4790 : H12AffineEnvironment.transform 1 0 env4789 = env4790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4789 == env4790) = true)

def leafEnv4790 : List Nat := [2,0,2,1,1,1,2,1,1,1,0,1,3,1,1,3,1,0,0,1,0,0,1,2,0,2,1,0,0,0,1,0,1,0,0,0,1,2,1,0,1,0,0]

def active4790 : List Nat := [0]

def tree4790 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4790 : H12WitnessSearch.Good tree4790 := H12GlobalWitnessIndex.good

theorem leafIdentity4790 : H12AffineFastState.composeSystem env4790 rootObs = leafEnv4790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4790 rootObs == leafEnv4790) = true)

theorem terminalChecked4790 : H12PackedTerminal.terminalCheckFast leafEnv4790 active4790 tree4790 = true := by decide +kernel

def env4791 : List Nat := [2,4,8,16,32,16,41,5,1,33,46,1,51,1,59,24,1,15,32,59,0,53,4,35,19,5,46,0,1,15,33,0,4,0,21,20]

theorem envBound4791 : H12AffineFastState.Bounded env4791 := by
  intro p hp
  have h : env4791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4779_4791 : H12AffineEnvironment.transform 9 33 env4779 = env4791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env4779 == env4791) = true)

theorem identity4791 : scanCanonicalize (H12AffineFastState.compose env4791 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound4791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4792 : List Nat := [2,4,8,5,32,5,41,5,1,33,46,1,38,1,46,13,1,15,32,46,0,32,4,35,6,5,46,0,1,15,33,0,4,0,0,1]

theorem envBound4792 : H12AffineFastState.Bounded env4792 := by
  intro p hp
  have h : env4792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4791_4792 : H12AffineEnvironment.transform 3 5 env4791 = env4792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env4791 == env4792) = true)

theorem identity4792 : scanCanonicalize (H12AffineFastState.compose env4792 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4793 : List Nat := [2,4,8,5,14,5,7,5,1,15,0,1,8,1,0,13,1,15,14,0,0,14,4,13,6,5,0,0,1,15,15,0,4,0,0,1]

theorem envBound4793 : H12AffineFastState.Bounded env4793 := by
  intro p hp
  have h : env4793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4792_4793 : H12AffineEnvironment.transform 4 14 env4792 = env4793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4792 == env4793) = true)

def env4794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8495,4524,262144,1025,8201,4097,4194304,4194353,34,8329,4194352,262281,4097,4524,2081,1284,260,257,0,4198537,4195212]

theorem envBound4794 : H12AffineFastState.Bounded env4794 := by
  intro p hp
  have h : env4794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4770_4794 : H12AffineEnvironment.transform 14 8201 env4770 = env4794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4770 == env4794) = true)

theorem identity4794 : scanCanonicalize (H12AffineFastState.compose env4794 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound4794 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8495,4524,4383,1025,8201,4097,4194304,4194353,34,8329,4194352,4502,4097,4524,2081,1284,260,257,0,4198537,4195212]

theorem envBound4795 : H12AffineFastState.Bounded env4795 := by
  intro p hp
  have h : env4795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4794_4795 : H12AffineEnvironment.transform 17 4383 env4794 = env4795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env4794 == env4795) = true)

theorem identity4795 : scanCanonicalize (H12AffineFastState.compose env4795 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4795 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1841,8201,8495,1693,1582,1025,8201,1840,4194304,4194353,34,8329,4194352,1703,1840,1693,2081,1284,260,257,0,4196280,4195212]

theorem envBound4796 : H12AffineFastState.Bounded env4796 := by
  intro p hp
  have h : env4796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4795_4796 : H12AffineEnvironment.transform 11 1841 env4795 = env4796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env4795 == env4796) = true)

theorem identity4796 : scanCanonicalize (H12AffineFastState.compose env4796 (packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound4796 : packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS < 2^1333 := by decide +kernel

def env4797 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1703,1841,8192,1841,8201,8495,1693,1582,1025,8201,1840,4194304,4194353,34,8329,4194352,1703,1840,1693,1670,1284,260,257,0,4196280,4195212]

theorem envBound4797 : H12AffineFastState.Bounded env4797 := by
  intro p hp
  have h : env4797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4796_4797 : H12AffineEnvironment.transform 10 1703 env4796 = env4797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env4796 == env4797) = true)

theorem identity4797 : scanCanonicalize (H12AffineFastState.compose env4797 (packedSelected [3,4,5,7,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 1418) := by decide +kernel

theorem selectedBound4797 : packedSelected [3,4,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4798 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1703,1841,1418,1841,1411,1189,1693,1582,1025,1411,1840,4194304,4194353,34,1283,4194352,1703,1840,1693,1670,1284,260,257,0,4196280,4195212]

theorem envBound4798 : H12AffineFastState.Bounded env4798 := by
  intro p hp
  have h : env4798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4797_4798 : H12AffineEnvironment.transform 12 1418 env4797 = env4798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1418 env4797 == env4798) = true)

theorem identity4798 : scanCanonicalize (H12AffineFastState.compose env4798 (packedSelected [4,7,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4798 : packedSelected [4,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env4799 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1703,1693,1062,1693,1071,1189,1693,1582,1025,1071,1692,4194304,4194353,34,1199,4194352,1703,1692,1693,1670,1192,168,173,0,4195860,4194848]

theorem envBound4799 : H12AffineFastState.Bounded env4799 := by
  intro p hp
  have h : env4799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4798_4799 : H12AffineEnvironment.transform 7 172 env4798 = env4799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4798 == env4799) = true)

theorem identity4799 : scanCanonicalize (H12AffineFastState.compose env4799 (packedSelected [0,3,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4799 : packedSelected [0,3,8,9] rootPS < 2^1333 := by decide +kernel

def env4800 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1551,1589,1062,1589,1071,1037,1589,1582,1025,1071,1588,4194304,4194353,34,1031,4194352,1551,1588,1589,1582,1024,0,5,0,4195860,4194848]

theorem envBound4800 : H12AffineFastState.Bounded env4800 := by
  intro p hp
  have h : env4800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4799_4800 : H12AffineEnvironment.transform 6 40 env4799 = env4800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4799 == env4800) = true)

def env4801 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4097,4194304,4292887,41003,8329,4292886,303233,4096,4525,2080,74795,73770,257,1,4239489,4293290]

theorem envBound4801 : H12AffineFastState.Bounded env4801 := by
  intro p hp
  have h : env4801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4768_4801 : H12AffineEnvironment.transform 13 4097 env4768 = env4801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env4768 == env4801) = true)

theorem identity4801 : scanCanonicalize (H12AffineFastState.compose env4801 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4801 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4802 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,8200,65536,4524,262144,1025,8200,4097,4194304,4268319,35,8329,4268318,262281,4096,4525,2080,74795,73770,257,1,4198537,4268706]

theorem envBound4802 : H12AffineFastState.Bounded env4802 := by
  intro p hp
  have h : env4802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4801_4802 : H12AffineEnvironment.transform 14 8200 env4801 = env4802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4801 == env4802) = true)

theorem identity4802 : scanCanonicalize (H12AffineFastState.compose env4802 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound4802 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env4803 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,8200,65536,4524,262144,1025,8200,4097,73890,445,35,8329,444,262281,4096,4525,2080,74795,73770,257,1,77867,512]

theorem envBound4803 : H12AffineFastState.Bounded env4803 := by
  intro p hp
  have h : env4803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4802_4803 : H12AffineEnvironment.transform 21 73890 env4802 = env4803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env4802 == env4803) = true)

theorem identity4803 : scanCanonicalize (H12AffineFastState.compose env4803 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4803 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4804 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8200,65536,4096,262144,1025,8200,4097,73890,17,35,8329,16,262281,4096,4097,2080,74795,73770,173,1,77867,512]

theorem envBound4804 : H12AffineFastState.Bounded env4804 := by
  intro p hp
  have h : env4804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4803_4804 : H12AffineEnvironment.transform 7 172 env4803 = env4804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4803 == env4804) = true)

theorem identity4804 : scanCanonicalize (H12AffineFastState.compose env4804 (packedSelected [6,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 15548) := by decide +kernel

theorem selectedBound4804 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4805 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8200,15548,4096,262144,1025,8200,4097,7198,17,35,8329,16,262281,4096,4097,2080,6295,7318,173,1,3223,512]

theorem envBound4805 : H12AffineFastState.Bounded env4805 := by
  intro p hp
  have h : env4805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4804_4805 : H12AffineEnvironment.transform 15 15548 env4804 = env4805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15548 env4804 == env4805) = true)

theorem identity4805 : scanCanonicalize (H12AffineFastState.compose env4805 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 5286) := by decide +kernel

theorem selectedBound4805 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4806 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8200,15548,4096,5286,1025,8200,4097,7198,17,35,8329,16,5167,4096,4097,2080,6295,7318,173,1,3223,512]

theorem envBound4806 : H12AffineFastState.Bounded env4806 := by
  intro p hp
  have h : env4806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4805_4806 : H12AffineEnvironment.transform 17 5286 env4805 = env4806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5286 env4805 == env4806) = true)

theorem identity4806 : scanCanonicalize (H12AffineFastState.compose env4806 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4806 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4807 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1693,8192,1692,8200,10785,1693,571,1025,8200,1692,2691,17,35,8329,16,690,1693,1692,2080,3594,2571,173,1,3223,512]

theorem envBound4807 : H12AffineFastState.Bounded env4807 := by
  intro p hp
  have h : env4807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4806_4807 : H12AffineEnvironment.transform 11 1693 env4806 = env4807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env4806 == env4807) = true)

theorem identity4807 : scanCanonicalize (H12AffineFastState.compose env4807 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound4807 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4808 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,1693,8192,1692,8200,8322,1693,571,1025,8200,1692,32,17,35,8329,16,690,1693,1692,643,1193,168,173,1,1588,512]

theorem envBound4808 : H12AffineFastState.Bounded env4808 := by
  intro p hp
  have h : env4808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4807_4808 : H12AffineEnvironment.transform 10 675 env4807 = env4808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env4807 == env4808) = true)

theorem identity4808 : scanCanonicalize (H12AffineFastState.compose env4808 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4808 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4809 : List Nat := [2,4,8,1,32,1,128,172,512,1024,675,1676,8192,1677,8200,8322,1676,554,1025,8200,1677,32,0,35,8329,1,675,1676,1677,643,1193,168,173,1,1573,512]

theorem envBound4809 : H12AffineFastState.Bounded env4809 := by
  intro p hp
  have h : env4809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4808_4809 : H12AffineEnvironment.transform 3 1 env4808 = env4809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4808 == env4809) = true)

theorem identity4809 : scanCanonicalize (H12AffineFastState.compose env4809 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound4809 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4810 : List Nat := [2,4,8,1,32,1,128,172,512,47,675,675,8192,674,8200,8322,675,554,46,8200,674,32,0,35,8329,1,675,675,674,643,134,168,173,1,522,512]

theorem envBound4810 : H12AffineFastState.Bounded env4810 := by
  intro p hp
  have h : env4810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4809_4810 : H12AffineEnvironment.transform 9 47 env4809 = env4810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env4809 == env4810) = true)

theorem identity4810 : scanCanonicalize (H12AffineFastState.compose env4810 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4810 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env4811 : List Nat := [2,4,8,1,32,1,41,5,512,47,522,522,8192,523,8200,8235,522,554,46,8200,523,32,0,35,8224,1,522,522,523,554,47,1,4,1,522,512]

theorem envBound4811 : H12AffineFastState.Bounded env4811 := by
  intro p hp
  have h : env4811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4810_4811 : H12AffineEnvironment.transform 6 41 env4810 = env4811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4810 == env4811) = true)

theorem identity4811 : scanCanonicalize (H12AffineFastState.compose env4811 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4812 : List Nat := [2,4,8,1,10,1,3,5,512,5,522,522,8192,523,8200,8193,522,512,4,8200,523,10,0,9,8202,1,522,522,523,512,5,1,4,1,522,512]

theorem envBound4812 : H12AffineFastState.Bounded env4812 := by
  intro p hp
  have h : env4812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4811_4812 : H12AffineEnvironment.transform 4 10 env4811 = env4812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4811 == env4812) = true)

theorem identity4812 : scanCanonicalize (H12AffineFastState.compose env4812 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound4812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4813 : List Nat := [2,4,8,1,10,1,3,5,512,5,522,522,521,523,513,520,522,512,4,513,523,10,0,9,515,1,522,522,523,512,5,1,4,1,522,512]

theorem envBound4813 : H12AffineFastState.Bounded env4813 := by
  intro p hp
  have h : env4813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4812_4813 : H12AffineEnvironment.transform 12 521 env4812 = env4813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env4812 == env4813) = true)

theorem identity4813 : scanCanonicalize (H12AffineFastState.compose env4813 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4814 : List Nat := [2,4,8,1,10,1,3,5,0,5,10,10,9,11,1,8,10,0,4,1,11,10,0,9,3,1,10,10,11,0,5,1,4,1,10,0]

theorem envBound4814 : H12AffineFastState.Bounded env4814 := by
  intro p hp
  have h : env4814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4813_4814 : H12AffineEnvironment.transform 8 0 env4813 = env4814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4813 == env4814) = true)

theorem identity4814 : scanCanonicalize (H12AffineFastState.compose env4814 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4814 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4815 : List Nat := [2,4,2,1,0,1,3,5,0,5,0,0,3,1,1,2,0,0,4,1,1,0,0,3,3,1,0,0,1,0,5,1,4,1,0,0]

theorem envBound4815 : H12AffineFastState.Bounded env4815 := by
  intro p hp
  have h : env4815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4814_4815 : H12AffineEnvironment.transform 2 2 env4814 = env4815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4814 == env4815) = true)

def env4816 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4292886,41003,8329,4292886,323713,16385,16813,22560,74795,94250,257,20481,4251777,4293290]

theorem envBound4816 : H12AffineFastState.Bounded env4816 := by
  intro p hp
  have h : env4816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4767_4816 : H12AffineEnvironment.transform 5 17 env4767 = env4816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4767 == env4816) = true)

theorem identity4816 : scanCanonicalize (H12AffineFastState.compose env4816 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98474) := by decide +kernel

theorem selectedBound4816 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4817 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98474,444,41003,8329,444,323713,16385,16813,22560,74795,94250,257,20481,90155,512]

theorem envBound4817 : H12AffineFastState.Bounded env4817 := by
  intro p hp
  have h : env4817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4816_4817 : H12AffineEnvironment.transform 21 98474 env4816 = env4817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98474 env4816 == env4817) = true)

theorem identity4817 : scanCanonicalize (H12AffineFastState.compose env4817 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4817 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4818 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1025,32768,4097,41348,444,41003,8329,444,323713,16385,16813,22560,1285,20740,257,20481,16645,512]

theorem envBound4818 : H12AffineFastState.Bounded env4818 := by
  intro p hp
  have h : env4818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4817_4818 : H12AffineEnvironment.transform 15 8494 env4817 = env4818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4817 == env4818) = true)

theorem identity4818 : scanCanonicalize (H12AffineFastState.compose env4818 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4818 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4819 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13973,8494,4525,262144,1025,13973,4097,5905,444,5822,8329,444,280084,16385,16813,22560,1285,20740,257,20481,16645,512]

theorem envBound4819 : H12AffineFastState.Bounded env4819 := by
  intro p hp
  have h : env4819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4818_4819 : H12AffineEnvironment.transform 14 13973 env4818 = env4819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4818 == env4819) = true)

theorem identity4819 : scanCanonicalize (H12AffineFastState.compose env4819 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound4819 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4820 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,262144,1025,13973,4097,5905,444,5822,8329,444,268217,4524,4096,2445,1285,169,257,428,4264,512]

theorem envBound4820 : H12AffineFastState.Bounded env4820 := by
  intro p hp
  have h : env4820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4819_4820 : H12AffineEnvironment.transform 13 4525 env4819 = env4820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env4819 == env4820) = true)

theorem identity4820 : scanCanonicalize (H12AffineFastState.compose env4820 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound4820 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4821 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,7868,1025,13973,4097,5905,444,5822,8329,444,2309,4524,4096,2445,1285,169,257,428,4264,512]

theorem envBound4821 : H12AffineFastState.Bounded env4821 := by
  intro p hp
  have h : env4821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4820_4821 : H12AffineEnvironment.transform 17 7868 env4820 = env4821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env4820 == env4821) = true)

theorem identity4821 : scanCanonicalize (H12AffineFastState.compose env4821 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4821 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4822 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1840,8192,1693,8613,8494,1693,2444,1025,8613,1841,33,444,398,8329,444,2309,1692,1840,2445,1285,169,257,428,1944,512]

theorem envBound4822 : H12AffineFastState.Bounded env4822 := by
  intro p hp
  have h : env4822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4821_4822 : H12AffineEnvironment.transform 11 1840 env4821 = env4822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env4821 == env4822) = true)

theorem identity4822 : scanCanonicalize (H12AffineFastState.compose env4822 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4822 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4823 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1589,8192,1693,8352,8235,1693,2185,1025,8352,1588,33,185,139,8329,185,2048,1692,1589,2184,1024,169,4,169,1693,512]

theorem envBound4823 : H12AffineFastState.Bounded env4823 := by
  intro p hp
  have h : env4823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4822_4823 : H12AffineEnvironment.transform 7 5 env4822 = env4823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4822 == env4823) = true)

theorem identity4823 : scanCanonicalize (H12AffineFastState.compose env4823 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2747) := by decide +kernel

theorem selectedBound4823 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env4824 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1589,2747,1693,2587,2704,1693,2185,1025,2587,1588,33,185,139,2610,185,2048,1692,1589,2184,1024,169,4,169,1693,512]

theorem envBound4824 : H12AffineFastState.Bounded env4824 := by
  intro p hp
  have h : env4824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4823_4824 : H12AffineEnvironment.transform 12 2747 env4823 = env4824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2747 env4823 == env4824) = true)

theorem identity4824 : scanCanonicalize (H12AffineFastState.compose env4824 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound4824 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env4825 : List Nat := [2,4,8,16,32,17,128,5,512,20,2048,545,2747,649,2587,2704,649,2185,21,2587,544,33,185,139,2610,185,2048,648,545,2184,20,169,4,169,649,512]

theorem envBound4825 : H12AffineFastState.Bounded env4825 := by
  intro p hp
  have h : env4825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4824_4825 : H12AffineEnvironment.transform 9 20 env4824 = env4825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env4824 == env4825) = true)

def env4826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,134217728,268435456,268435964,134523040,75572347,147588588,525568,134520961,34359738368,8914925]

theorem envBound4826 : H12AffineFastState.Bounded env4826 := by
  intro p hp
  have h : env4826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2952_4826 : H12AffineEnvironment.transform 16 4605 env2952 = env4826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4605 env2952 == env4826) = true)

theorem identity4826 : scanCanonicalize (H12AffineFastState.compose env4826 (packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 82355408) := by decide +kernel

theorem selectedBound4826 : packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env4827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,134217728,268435456,268435964,134523040,75572347,147588588,525568,134520961,82355408,8914925]

theorem envBound4827 : H12AffineFastState.Bounded env4827 := by
  intro p hp
  have h : env4827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4826_4827 : H12AffineEnvironment.transform 34 82355408 env4826 = env4827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 82355408 env4826 == env4827) = true)

def env4828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,134217728,76039248,76039596,134523040,75572347,147588588,525568,134520961,82355408,8914925]

theorem envBound4828 : H12AffineFastState.Bounded env4828 := by
  intro p hp
  have h : env4828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4827_4828 : H12AffineEnvironment.transform 27 76039248 env4827 = env4828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 76039248 env4827 == env4828) = true)

def env4829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,77914240,76039248,76039596,77613088,75572347,73983340,525568,77611009,82355408,8914925]

theorem envBound4829 : H12AffineFastState.Bounded env4829 := by
  intro p hp
  have h : env4829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4828_4829 : H12AffineEnvironment.transform 26 77914240 env4828 = env4829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914240 env4828 == env4829) = true)

def env4830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914000,2942160,16384,16892,2641008,598059,14737724,525568,2638929,6332544,8914925]

theorem envBound4830 : H12AffineFastState.Bounded env4830 := by
  intro p hp
  have h : env4830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4829_4830 : H12AffineEnvironment.transform 25 8914000 env4829 = env4830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env4829 == env4830) = true)

def env4831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849104,16384,16892,547952,598059,12644668,525568,545873,4239488,8914925]

theorem envBound4831 : H12AffineFastState.Bounded env4831 := by
  intro p hp
  have h : env4831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4830_4831 : H12AffineEnvironment.transform 20 4096 env4830 = env4831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env4830 == env4831) = true)

def env4832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323792,16384,16892,22640,74795,12644668,256,20561,4239488,8389613]

theorem envBound4832 : H12AffineFastState.Bounded env4832 := by
  intro p hp
  have h : env4832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4831_4832 : H12AffineEnvironment.transform 18 1024 env4831 = env4832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4831 == env4832) = true)

theorem identity4832 : scanCanonicalize (H12AffineFastState.compose env4832 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound4832 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1213,8192,16384,32768,65536,1344,262144,1024,32768,1213,4194304,8388608,41002,8329,8388688,320621,16384,16892,19661,74795,12641665,256,17644,4236349,8389613]

theorem envBound4833 : H12AffineFastState.Bounded env4833 := by
  intro p hp
  have h : env4833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4832_4833 : H12AffineEnvironment.transform 11 1213 env4832 = env4833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env4832 == env4833) = true)

def env4834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,4194304,8388608,41002,8329,8388608,320573,16384,16812,19613,74795,12641665,256,17596,4236349,8389565]

theorem envBound4834 : H12AffineFastState.Bounded env4834 := by
  intro p hp
  have h : env4834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4833_4834 : H12AffineEnvironment.transform 5 16 env4833 = env4834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4833 == env4834) = true)

theorem identity4834 : scanCanonicalize (H12AffineFastState.compose env4834 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4834 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4835 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,4194304,445,41002,8329,445,320573,16384,16812,19613,74795,4252732,256,17596,4236349,512]

theorem envBound4835 : H12AffineFastState.Bounded env4835 := by
  intro p hp
  have h : env4835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4834_4835 : H12AffineEnvironment.transform 22 445 env4834 = env4835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4834 == env4835) = true)

theorem identity4835 : scanCanonicalize (H12AffineFastState.compose env4835 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4835 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4836 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,41349,445,41002,8329,445,320573,16384,16812,19613,74795,17849,256,17596,1464,512]

theorem envBound4836 : H12AffineFastState.Bounded env4836 := by
  intro p hp
  have h : env4836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4835_4836 : H12AffineEnvironment.transform 21 41349 env4835 = env4836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4835 == env4836) = true)

theorem identity4836 : scanCanonicalize (H12AffineFastState.compose env4836 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound4836 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4837 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1024,26261,1213,18192,445,18111,8329,445,262824,16384,16812,19613,74795,17849,256,17596,1464,512]

theorem envBound4837 : H12AffineFastState.Bounded env4837 := by
  intro p hp
  have h : env4837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4836_4837 : H12AffineEnvironment.transform 14 26261 env4836 = env4837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env4836 == env4837) = true)

theorem identity4837 : scanCanonicalize (H12AffineFastState.compose env4837 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound4837 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4838 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25662,1296,262144,1024,26261,1213,18192,445,18111,8329,445,262824,16384,16812,19613,16405,17849,256,17596,1464,512]

theorem envBound4838 : H12AffineFastState.Bounded env4838 := by
  intro p hp
  have h : env4838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4837_4838 : H12AffineEnvironment.transform 15 25662 env4837 = env4838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env4837 == env4838) = true)

theorem identity4838 : scanCanonicalize (H12AffineFastState.compose env4838 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4838 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4839 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,1840,8613,8974,1296,262144,1024,8613,1213,32,445,399,8329,445,262824,1840,1692,2989,1829,649,256,908,1464,512]

theorem envBound4839 : H12AffineFastState.Bounded env4839 := by
  intro p hp
  have h : env4839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4838_4839 : H12AffineEnvironment.transform 13 1840 env4838 = env4839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env4838 == env4839) = true)

theorem identity4839 : scanCanonicalize (H12AffineFastState.compose env4839 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4839 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4840 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8200,8867,1213,262144,1024,8200,1213,32,16,34,8329,16,262824,1693,1692,2560,1672,649,173,545,1045,512]

theorem envBound4840 : H12AffineFastState.Bounded env4840 := by
  intro p hp
  have h : env4840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4839_4840 : H12AffineEnvironment.transform 7 173 env4839 = env4840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4839 == env4840) = true)

theorem identity4840 : scanCanonicalize (H12AffineFastState.compose env4840 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4840 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4841 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8200,8867,1213,1583,1024,8200,1213,32,16,34,8329,16,1159,1693,1692,2560,1672,649,173,545,1045,512]

theorem envBound4841 : H12AffineFastState.Bounded env4841 := by
  intro p hp
  have h : env4841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4840_4841 : H12AffineEnvironment.transform 17 1583 env4840 = env4841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env4840 == env4841) = true)

def env4842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,32768,65536,1297,262144,1024,32768,1213,4194304,8388608,41002,8329,8388609,320572,16384,16813,19612,74795,12641665,256,17597,4236349,8389564]

theorem envBound4842 : H12AffineFastState.Bounded env4842 := by
  intro p hp
  have h : env4842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4833_4842 : H12AffineEnvironment.transform 5 17 env4833 = env4842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4833 == env4842) = true)

def env4843 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1213,8192,16384,32768,65536,1197,262144,1024,32768,1213,4194304,8388608,41002,8329,8388609,320572,16384,16401,19612,74795,12641341,188,17597,4236349,8389120]

theorem envBound4843 : H12AffineFastState.Bounded env4843 := by
  intro p hp
  have h : env4843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4842_4843 : H12AffineEnvironment.transform 7 188 env4842 = env4843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env4842 == env4843) = true)

theorem identity4843 : scanCanonicalize (H12AffineFastState.compose env4843 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound4843 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env4844 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1213,8192,16384,32768,65536,1197,262144,1024,32768,1213,4194304,4194352,41002,8329,4194353,320572,16384,16401,19612,74795,58381,188,17597,4236349,4194864]

theorem envBound4844 : H12AffineFastState.Bounded env4844 := by
  intro p hp
  have h : env4844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4843_4844 : H12AffineEnvironment.transform 22 4194352 env4843 = env4844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env4843 == env4844) = true)

def env4845 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1197,8192,16384,32768,65536,1197,262144,1024,32768,1197,4194304,4194336,41002,8329,4194337,320556,16384,16385,19596,74795,58381,172,17581,4236333,4194848]

theorem envBound4845 : H12AffineFastState.Bounded env4845 := by
  intro p hp
  have h : env4845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4844_4845 : H12AffineEnvironment.transform 3 0 env4844 = env4845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4844 == env4845) = true)

theorem identity4845 : scanCanonicalize (H12AffineFastState.compose env4845 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4845 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env4846 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,65536,1029,262144,1024,32768,1029,4194304,4194336,41002,8225,4194337,320556,16384,16385,19492,74795,58381,4,17413,4236333,4194848]

theorem envBound4846 : H12AffineFastState.Bounded env4846 := by
  intro p hp
  have h : env4846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4845_4846 : H12AffineEnvironment.transform 6 40 env4845 = env4846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4845 == env4846) = true)

theorem identity4846 : scanCanonicalize (H12AffineFastState.compose env4846 (packedSelected [2,3,5,7,10,11,18,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 117766) := by decide +kernel

theorem selectedBound4846 : packedSelected [2,3,5,7,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env4847 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,65536,1029,117766,1024,32768,1029,4194304,4194336,41002,8225,4194337,75818,16384,16385,19492,74795,58381,4,17413,4236333,4194848]

theorem envBound4847 : H12AffineFastState.Bounded env4847 := by
  intro p hp
  have h : env4847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4846_4847 : H12AffineEnvironment.transform 17 117766 env4846 = env4847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 117766 env4846 == env4847) = true)

theorem identity4847 : scanCanonicalize (H12AffineFastState.compose env4847 (packedSelected [0,4,7,9,11,12,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 19463) := by decide +kernel

theorem selectedBound4847 : packedSelected [0,4,7,9,11,12,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4848 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,19463,1029,32769,1024,32768,1029,4194304,4194336,41002,8225,4194337,25645,16384,16385,19492,26668,58381,4,17413,4236333,4194848]

theorem envBound4848 : H12AffineFastState.Bounded env4848 := by
  intro p hp
  have h : env4848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4847_4848 : H12AffineEnvironment.transform 15 19463 env4847 = env4848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19463 env4847 == env4848) = true)

theorem identity4848 : scanCanonicalize (H12AffineFastState.compose env4848 (packedSelected [0,1,2,3,5,7,8,10,12,15,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 17413) := by decide +kernel

theorem selectedBound4848 : packedSelected [0,1,2,3,5,7,8,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env4849 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,19463,1029,32769,1024,32768,1029,17413,17445,41002,8225,17444,25645,16384,16385,19492,26668,58381,4,17413,57384,17957]

theorem envBound4849 : H12AffineFastState.Bounded env4849 := by
  intro p hp
  have h : env4849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4848_4849 : H12AffineEnvironment.transform 21 17413 env4848 = env4849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17413 env4848 == env4849) = true)

theorem identity4849 : scanCanonicalize (H12AffineFastState.compose env4849 (packedSelected [2,3,5,11,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 11789) := by decide +kernel

theorem selectedBound4849 : packedSelected [2,3,5,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4850 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,11789,19463,1029,11788,1024,11789,1029,17413,17445,3623,8225,17444,25645,16384,16385,19492,26668,18944,4,17413,20005,17957]

theorem envBound4850 : H12AffineFastState.Bounded env4850 := by
  intro p hp
  have h : env4850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4849_4850 : H12AffineEnvironment.transform 14 11789 env4849 = env4850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11789 env4849 == env4850) = true)

theorem identity4850 : scanCanonicalize (H12AffineFastState.compose env4850 (packedSelected [1,3,4,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4850 : packedSelected [1,3,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env4851 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,1071,11789,2088,1029,11788,1024,11789,1029,42,10,3623,8225,11,8194,1071,1070,2059,11267,3631,4,42,2570,522]

theorem envBound4851 : H12AffineFastState.Bounded env4851 := by
  intro p hp
  have h : env4851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4850_4851 : H12AffineEnvironment.transform 13 1071 env4850 = env4851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1071 env4850 == env4851) = true)

theorem identity4851 : scanCanonicalize (H12AffineFastState.compose env4851 (packedSelected [1,8,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound4851 : packedSelected [1,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4852 : List Nat := [2,4,8,0,32,1,40,4,512,1024,1541,1029,8192,1071,8200,1581,1029,8201,1024,8200,1029,42,10,34,8225,11,8194,1071,1070,1550,8710,42,4,42,1039,522]

theorem envBound4852 : H12AffineFastState.Bounded env4852 := by
  intro p hp
  have h : env4852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4851_4852 : H12AffineEnvironment.transform 10 1541 env4851 = env4852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env4851 == env4852) = true)

theorem identity4852 : scanCanonicalize (H12AffineFastState.compose env4852 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound4852 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env4853 : List Nat := [2,4,8,0,32,1,40,4,512,36,545,33,8192,11,8200,521,33,8201,36,8200,33,42,10,34,8225,11,8194,11,10,554,8710,42,4,42,43,522]

theorem envBound4853 : H12AffineFastState.Bounded env4853 := by
  intro p hp
  have h : env4853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4852_4853 : H12AffineEnvironment.transform 9 36 env4852 = env4853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env4852 == env4853) = true)

theorem identity4853 : scanCanonicalize (H12AffineFastState.compose env4853 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound4853 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env4854 : List Nat := [2,4,8,0,32,1,40,4,512,36,545,33,8,11,0,521,33,1,36,0,33,42,10,34,41,11,10,11,10,554,526,42,4,42,43,522]

theorem envBound4854 : H12AffineFastState.Bounded env4854 := by
  intro p hp
  have h : env4854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4853_4854 : H12AffineEnvironment.transform 12 8 env4853 = env4854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env4853 == env4854) = true)

theorem identity4854 : scanCanonicalize (H12AffineFastState.compose env4854 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4854 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env4855 : List Nat := [2,4,8,0,32,1,40,4,32,36,1,33,8,11,0,41,33,1,36,0,33,42,10,34,41,11,10,11,10,10,46,42,4,42,43,42]

theorem envBound4855 : H12AffineFastState.Bounded env4855 := by
  intro p hp
  have h : env4855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4854_4855 : H12AffineEnvironment.transform 8 32 env4854 = env4855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4854 == env4855) = true)

theorem identity4855 : scanCanonicalize (H12AffineFastState.compose env4855 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4855 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4856 : List Nat := [2,4,8,0,10,1,2,4,10,14,1,11,8,11,0,3,11,1,14,0,11,0,10,8,3,11,10,11,10,10,4,0,4,0,1,0]

theorem envBound4856 : H12AffineFastState.Bounded env4856 := by
  intro p hp
  have h : env4856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4855_4856 : H12AffineEnvironment.transform 4 10 env4855 = env4856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4855 == env4856) = true)

def env4857 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,65536,1197,262144,1024,32768,1196,4194304,4194337,41002,8329,4194336,320557,16384,16384,19597,74795,58381,173,17580,4236332,4194849]

theorem envBound4857 : H12AffineFastState.Bounded env4857 := by
  intro p hp
  have h : env4857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4844_4857 : H12AffineEnvironment.transform 3 1 env4844 = env4857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4844 == env4857) = true)

theorem identity4857 : scanCanonicalize (H12AffineFastState.compose env4857 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25646) := by decide +kernel

theorem selectedBound4857 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env4858 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1197,262144,1024,32768,1196,4194304,4194337,41002,8329,4194336,320557,16384,16384,19597,16389,58381,173,17580,4236332,4194849]

theorem envBound4858 : H12AffineFastState.Bounded env4858 := by
  intro p hp
  have h : env4858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4857_4858 : H12AffineEnvironment.transform 15 25646 env4857 = env4858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25646 env4857 == env4858) = true)

theorem identity4858 : scanCanonicalize (H12AffineFastState.compose env4858 (packedSelected [1,5,8,13,18,21,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4858 : packedSelected [1,5,8,13,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env4859 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1197,2081,1024,32768,1196,4194304,4194337,41002,8329,4194336,60428,16384,16384,19597,16389,58381,173,17580,4236332,4194849]

theorem envBound4859 : H12AffineFastState.Bounded env4859 := by
  intro p hp
  have h : env4859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4858_4859 : H12AffineEnvironment.transform 17 2081 env4858 = env4859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4858 == env4859) = true)

theorem identity4859 : scanCanonicalize (H12AffineFastState.compose env4859 (packedSelected [1,2,6,8,11,17,21] rootPS)) = affineNative (2^(21+1) ^^^ 34351) := by decide +kernel

theorem selectedBound4859 : packedSelected [1,2,6,8,11,17,21] rootPS < 2^1333 := by decide +kernel

def env4860 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1197,2081,1024,32768,1196,34351,34318,41002,8329,34319,60428,16384,16384,19597,16389,58381,173,17580,8707,33806]

theorem envBound4860 : H12AffineFastState.Bounded env4860 := by
  intro p hp
  have h : env4860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4859_4860 : H12AffineEnvironment.transform 21 34351 env4859 = env4860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34351 env4859 == env4860) = true)

theorem identity4860 : scanCanonicalize (H12AffineFastState.compose env4860 (packedSelected [3,4,5,7,9,10,13,17,27] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound4860 : packedSelected [3,4,5,7,9,10,13,17,27] rootPS < 2^1333 := by decide +kernel

def env4861 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,1542,16384,32768,16936,1197,2081,1024,32768,1196,34351,34318,34348,1679,34319,51722,16384,16384,19597,16389,49675,173,17580,1029,33806]

theorem envBound4861 : H12AffineFastState.Bounded env4861 := by
  intro p hp
  have h : env4861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4860_4861 : H12AffineEnvironment.transform 12 1542 env4860 = env4861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env4860 == env4861) = true)

theorem identity4861 : scanCanonicalize (H12AffineFastState.compose env4861 (packedSelected [0,1,2,4,6,7,8,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound4861 : packedSelected [0,1,2,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env4862 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,1542,16384,1070,16936,1197,2081,1024,1070,1196,513,544,514,1679,545,20004,16384,16384,19597,16389,17957,173,17580,1029,32]

theorem envBound4862 : H12AffineFastState.Bounded env4862 := by
  intro p hp
  have h : env4862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4861_4862 : H12AffineEnvironment.transform 14 1070 env4861 = env4862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env4861 == env4862) = true)

theorem identity4862 : scanCanonicalize (H12AffineFastState.compose env4862 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4862 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4863 : List Nat := [2,4,8,1,32,0,128,173,33,1024,2048,1196,1063,16384,1070,16393,1197,2081,1024,1070,1196,32,1,35,1198,0,19461,16384,16384,19597,16389,17412,173,17580,1029,32]

theorem envBound4863 : H12AffineFastState.Bounded env4863 := by
  intro p hp
  have h : env4863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4862_4863 : H12AffineEnvironment.transform 8 33 env4862 = env4863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4862 == env4863) = true)

theorem identity4863 : scanCanonicalize (H12AffineFastState.compose env4863 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound4863 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4864 : List Nat := [2,4,8,1,32,0,128,173,33,1024,2048,1196,1063,2090,1070,2083,1197,2081,1024,1070,1196,32,1,35,1198,0,1071,2090,2090,1191,2095,3118,173,3206,1029,32]

theorem envBound4864 : H12AffineFastState.Bounded env4864 := by
  intro p hp
  have h : env4864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4863_4864 : H12AffineEnvironment.transform 13 2090 env4863 = env4864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env4863 == env4864) = true)

theorem identity4864 : scanCanonicalize (H12AffineFastState.compose env4864 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound4864 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env4865 : List Nat := [2,4,8,1,32,0,6,43,33,1024,2048,1066,1063,2090,1070,2083,1067,2081,1024,1070,1066,32,1,35,1064,0,1071,2090,2090,1057,2095,3118,43,3072,1029,32]

theorem envBound4865 : H12AffineFastState.Bounded env4865 := by
  intro p hp
  have h : env4865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4864_4865 : H12AffineEnvironment.transform 6 6 env4864 = env4865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env4864 == env4865) = true)

theorem identity4865 : scanCanonicalize (H12AffineFastState.compose env4865 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound4865 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4866 : List Nat := [2,4,8,1,32,0,6,43,33,1024,1039,1066,1063,1061,1070,1068,1067,1070,1024,1070,1066,32,1,35,1064,0,1071,1061,1061,1057,1056,33,43,15,1029,32]

theorem envBound4866 : H12AffineFastState.Bounded env4866 := by
  intro p hp
  have h : env4866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4865_4866 : H12AffineEnvironment.transform 10 1039 env4865 = env4866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env4865 == env4866) = true)

theorem identity4866 : scanCanonicalize (H12AffineFastState.compose env4866 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound4866 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env4867 : List Nat := [2,4,8,1,32,0,6,43,33,37,42,15,2,0,11,9,14,11,37,11,15,32,1,35,13,0,10,0,0,4,5,33,43,15,32,32]

theorem envBound4867 : H12AffineFastState.Bounded env4867 := by
  intro p hp
  have h : env4867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4866_4867 : H12AffineEnvironment.transform 9 37 env4866 = env4867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env4866 == env4867) = true)

theorem identity4867 : scanCanonicalize (H12AffineFastState.compose env4867 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4867 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4868 : List Nat := [2,4,8,1,14,0,6,5,15,11,4,15,2,0,11,9,14,11,11,11,15,14,1,13,13,0,10,0,0,4,5,15,5,15,14,14]

theorem envBound4868 : H12AffineFastState.Bounded env4868 := by
  intro p hp
  have h : env4868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4867_4868 : H12AffineEnvironment.transform 4 14 env4867 = env4868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4867 == env4868) = true)

theorem identity4868 : scanCanonicalize (H12AffineFastState.compose env4868 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4868 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4869 : List Nat := [2,4,3,1,5,0,6,5,4,0,4,4,2,0,0,2,5,0,0,0,4,5,1,6,6,0,1,0,0,4,5,4,5,4,5,5]

theorem envBound4869 : H12AffineFastState.Bounded env4869 := by
  intro p hp
  have h : env4869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4868_4869 : H12AffineEnvironment.transform 2 3 env4868 = env4869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4868 == env4869) = true)

def leafEnv4869 : List Nat := [2,4,3,1,5,0,6,5,4,0,4,4,2,0,0,2,5,0,0,0,4,5,1,6,4,6,1,0,1,0,0,4,5,4,5,4,5,7,5,5,1,0,0]

def active4869 : List Nat := [0,1]

def tree4869 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4869 : H12WitnessSearch.Good tree4869 := H12GlobalWitnessIndex.good

theorem leafIdentity4869 : H12AffineFastState.composeSystem env4869 rootObs = leafEnv4869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4869 rootObs == leafEnv4869) = true)

theorem terminalChecked4869 : H12PackedTerminal.terminalCheckFast leafEnv4869 active4869 tree4869 = true := by decide +kernel

def env4870 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,65536,1196,262144,1024,32768,1213,4194304,8388608,41002,8329,8388609,320572,16384,16400,19612,74795,12641340,189,17597,4236349,8389121]

theorem envBound4870 : H12AffineFastState.Bounded env4870 := by
  intro p hp
  have h : env4870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4842_4870 : H12AffineEnvironment.transform 7 189 env4842 = env4870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env4842 == env4870) = true)

theorem identity4870 : scanCanonicalize (H12AffineFastState.compose env4870 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50214) := by decide +kernel

theorem selectedBound4870 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env4871 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,50214,1196,262144,1024,32768,1213,4194304,8388608,41002,8329,8388609,320572,16384,16400,19612,57357,12641340,189,17597,4236349,8389121]

theorem envBound4871 : H12AffineFastState.Bounded env4871 := by
  intro p hp
  have h : env4871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4870_4871 : H12AffineEnvironment.transform 15 50214 env4870 = env4871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50214 env4870 == env4871) = true)

def env4872 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,50214,1196,262144,1024,32768,1213,4194304,4235392,41002,8329,4235393,320572,16384,16400,19612,57357,17596,189,17597,4236349,4235905]

theorem envBound4872 : H12AffineFastState.Bounded env4872 := by
  intro p hp
  have h : env4872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4871_4872 : H12AffineEnvironment.transform 22 4235392 env4871 = env4872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env4871 == env4872) = true)

theorem identity4872 : scanCanonicalize (H12AffineFastState.compose env4872 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4872 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4873 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,32768,50214,1196,262144,1024,32768,1196,4194304,4235392,41002,8329,4235393,320557,16384,16385,19597,57357,17581,172,17580,4236332,4235905]

theorem envBound4873 : H12AffineFastState.Bounded env4873 := by
  intro p hp
  have h : env4873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4872_4873 : H12AffineEnvironment.transform 3 1 env4872 = env4873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4872 == env4873) = true)

theorem identity4873 : scanCanonicalize (H12AffineFastState.compose env4873 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound4873 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4874 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,32768,50214,1196,262144,1024,32768,1196,41001,169,41002,8329,168,320557,16384,16385,19597,57357,17581,172,17580,1029,680]

theorem envBound4874 : H12AffineFastState.Bounded env4874 := by
  intro p hp
  have h : env4874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4873_4874 : H12AffineEnvironment.transform 21 41001 env4873 = env4874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env4873 == env4874) = true)

theorem identity4874 : scanCanonicalize (H12AffineFastState.compose env4874 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound4874 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4875 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,1676,32768,33450,1196,262144,1024,32768,1196,41001,169,41002,8329,168,303777,1676,1677,2561,42625,545,172,544,1029,680]

theorem envBound4875 : H12AffineFastState.Bounded env4875 := by
  intro p hp
  have h : env4875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4874_4875 : H12AffineEnvironment.transform 13 1676 env4874 = env4875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env4874 == env4875) = true)

theorem identity4875 : scanCanonicalize (H12AffineFastState.compose env4875 (packedSelected [1,3,4,9,11,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 43561) := by decide +kernel

theorem selectedBound4875 : packedSelected [1,3,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env4876 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,1676,32768,33450,1196,43561,1024,32768,1196,41001,169,41002,8329,168,2184,1676,1677,2561,42625,545,172,544,1029,680]

theorem envBound4876 : H12AffineFastState.Bounded env4876 := by
  intro p hp
  have h : env4876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4875_4876 : H12AffineEnvironment.transform 17 43561 env4875 = env4876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43561 env4875 == env4876) = true)

theorem identity4876 : scanCanonicalize (H12AffineFastState.compose env4876 (packedSelected [0,2,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 1158) := by decide +kernel

theorem selectedBound4876 : packedSelected [0,2,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4877 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,1676,1158,1580,1196,11951,1024,1158,1196,9391,169,9388,8329,168,2184,1676,1677,2561,8711,545,172,544,1029,680]

theorem envBound4877 : H12AffineFastState.Bounded env4877 := by
  intro p hp
  have h : env4877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4876_4877 : H12AffineEnvironment.transform 14 1158 env4876 = env4877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1158 env4876 == env4877) = true)

theorem identity4877 : scanCanonicalize (H12AffineFastState.compose env4877 (packedSelected [2,5,6,8,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound4877 : packedSelected [2,5,6,8,9,11,17] rootPS < 2^1333 := by decide +kernel

def env4878 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,161,1676,1158,1580,1196,3598,1024,1158,1196,1038,169,1037,40,168,2184,1676,1677,2561,678,545,172,544,1029,680]

theorem envBound4878 : H12AffineFastState.Bounded env4878 := by
  intro p hp
  have h : env4878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4877_4878 : H12AffineEnvironment.transform 12 161 env4877 = env4878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env4877 == env4878) = true)

theorem identity4878 : scanCanonicalize (H12AffineFastState.compose env4878 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound4878 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env4879 : List Nat := [2,4,8,1,32,0,128,172,512,559,2048,643,161,163,681,3,643,2081,559,681,643,545,169,546,40,168,2184,163,162,2561,678,545,172,544,554,680]

theorem envBound4879 : H12AffineFastState.Bounded env4879 := by
  intro p hp
  have h : env4879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4878_4879 : H12AffineEnvironment.transform 9 559 env4878 = env4879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env4878 == env4879) = true)

def env4880 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,50214,1196,262144,1024,32768,1213,4194304,4235393,41002,8329,4235392,320572,16384,16400,19612,57357,17597,189,17597,4236349,4235904]

theorem envBound4880 : H12AffineFastState.Bounded env4880 := by
  intro p hp
  have h : env4880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4871_4880 : H12AffineEnvironment.transform 22 4235393 env4871 = env4880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env4871 == env4880) = true)

theorem identity4880 : scanCanonicalize (H12AffineFastState.compose env4880 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound4880 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4881 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1029,8192,16384,32768,50214,1044,262144,1024,32768,1029,4194304,4235321,41002,8241,4235320,320572,16384,16400,19492,57357,17413,5,17413,4236349,4235832]

theorem envBound4881 : H12AffineFastState.Bounded env4881 := by
  intro p hp
  have h : env4881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4880_4881 : H12AffineEnvironment.transform 6 56 env4880 = env4881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env4880 == env4881) = true)

theorem identity4881 : scanCanonicalize (H12AffineFastState.compose env4881 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound4881 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4882 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1029,8192,16384,8216,25662,1044,262144,1024,8216,1029,4194304,4194337,50,8241,4194336,279588,16384,16400,19492,16405,17413,5,17413,4195365,4194848]

theorem envBound4882 : H12AffineFastState.Bounded env4882 := by
  intro p hp
  have h : env4882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4881_4882 : H12AffineEnvironment.transform 14 8216 env4881 = env4882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env4881 == env4882) = true)

theorem identity4882 : scanCanonicalize (H12AffineFastState.compose env4882 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4882 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4883 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,16384,8201,25647,1029,262144,1024,8201,1029,4194304,4194337,35,8224,4194336,279588,16384,16385,19492,16388,17413,5,17413,4195365,4194848]

theorem envBound4883 : H12AffineFastState.Bounded env4883 := by
  intro p hp
  have h : env4883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4882_4883 : H12AffineEnvironment.transform 3 1 env4882 = env4883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4882 == env4883) = true)

theorem identity4883 : scanCanonicalize (H12AffineFastState.compose env4883 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 281605) := by decide +kernel

theorem selectedBound4883 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4884 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,16384,8201,25647,1029,262144,1024,8201,1029,281605,281636,35,8224,281637,279588,16384,16385,19492,16388,17413,5,17413,280608,282149]

theorem envBound4884 : H12AffineFastState.Bounded env4884 := by
  intro p hp
  have h : env4884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4883_4884 : H12AffineEnvironment.transform 21 281605 env4883 = env4884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281605 env4883 == env4884) = true)

theorem identity4884 : scanCanonicalize (H12AffineFastState.compose env4884 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(17+1) ^^^ 25638) := by decide +kernel

theorem selectedBound4884 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env4885 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,16384,8201,25647,1029,25638,1024,8201,1029,10275,10242,35,8224,10243,8194,16384,16385,19492,16388,17413,5,17413,11270,10755]

theorem envBound4885 : H12AffineFastState.Bounded env4885 := by
  intro p hp
  have h : env4885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4884_4885 : H12AffineEnvironment.transform 17 25638 env4884 = env4885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25638 env4884 == env4885) = true)

theorem identity4885 : scanCanonicalize (H12AffineFastState.compose env4885 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 10755) := by decide +kernel

theorem selectedBound4885 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env4886 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,10755,8201,3628,1029,3621,1024,8201,1029,10275,10242,35,8224,10243,8194,10755,10754,9767,10759,11782,5,11782,11270,10755]

theorem envBound4886 : H12AffineFastState.Bounded env4886 := by
  intro p hp
  have h : env4886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4885_4886 : H12AffineEnvironment.transform 13 10755 env4885 = env4886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10755 env4885 == env4886) = true)

theorem identity4886 : scanCanonicalize (H12AffineFastState.compose env4886 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound4886 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env4887 : List Nat := [2,4,8,1,32,0,41,5,512,1024,10,1029,8192,8713,8201,1574,1029,1583,1024,8201,1029,8233,8200,35,8224,8201,8194,8713,8712,9767,8717,9740,5,9740,9228,8713]

theorem envBound4887 : H12AffineFastState.Bounded env4887 := by
  intro p hp
  have h : env4887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4886_4887 : H12AffineEnvironment.transform 10 10 env4886 = env4887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env4886 == env4887) = true)

theorem identity4887 : scanCanonicalize (H12AffineFastState.compose env4887 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound4887 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env4888 : List Nat := [2,4,8,1,32,0,41,5,512,517,10,512,8192,8713,8201,35,512,42,517,8201,512,8233,8200,35,8224,8201,8194,8713,8712,8226,8717,8201,5,8201,8713,8713]

theorem envBound4888 : H12AffineFastState.Bounded env4888 := by
  intro p hp
  have h : env4888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4887_4888 : H12AffineEnvironment.transform 9 517 env4887 = env4888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env4887 == env4888) = true)

theorem identity4888 : scanCanonicalize (H12AffineFastState.compose env4888 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4889 : List Nat := [2,4,8,1,11,0,2,5,512,517,10,512,8192,8713,8201,8,512,1,517,8201,512,8194,8200,8,8203,8201,8194,8713,8712,8201,8717,8201,5,8201,8713,8713]

theorem envBound4889 : H12AffineFastState.Bounded env4889 := by
  intro p hp
  have h : env4889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4888_4889 : H12AffineEnvironment.transform 4 11 env4888 = env4889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4888 == env4889) = true)

theorem identity4889 : scanCanonicalize (H12AffineFastState.compose env4889 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound4889 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4890 : List Nat := [2,4,8,1,11,0,2,5,512,517,10,512,515,10,522,8,512,1,517,522,512,513,523,8,520,522,513,10,11,522,14,522,5,522,10,10]

theorem envBound4890 : H12AffineFastState.Bounded env4890 := by
  intro p hp
  have h : env4890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4889_4890 : H12AffineEnvironment.transform 12 515 env4889 = env4890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env4889 == env4890) = true)

def env4891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323793,16384,16892,22641,74794,12644668,257,20560,4239488,8389612]

theorem envBound4891 : H12AffineFastState.Bounded env4891 := by
  intro p hp
  have h : env4891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4831_4891 : H12AffineEnvironment.transform 18 1025 env4831 = env4891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4831 == env4891) = true)

theorem identity4891 : scanCanonicalize (H12AffineFastState.compose env4891 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20924) := by decide +kernel

theorem selectedBound4891 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,20924,41002,8329,20973,323793,16384,16892,22641,74794,4235392,257,20560,4239488,21072]

theorem envBound4892 : H12AffineFastState.Bounded env4892 := by
  intro p hp
  have h : env4892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4891_4892 : H12AffineEnvironment.transform 22 20924 env4891 = env4892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20924 env4891 == env4892) = true)

def env4893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4605,262144,1025,32768,4096,4194304,444,41002,8329,493,303313,4096,4604,2161,74794,4235392,257,80,4239488,592]

theorem envBound4893 : H12AffineFastState.Bounded env4893 := by
  intro p hp
  have h : env4893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4892_4893 : H12AffineEnvironment.transform 13 4096 env4892 = env4893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4892 == env4893) = true)

theorem identity4893 : scanCanonicalize (H12AffineFastState.compose env4893 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound4893 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4894 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4096,4194304,444,41002,8329,445,303233,4096,4524,2081,74794,4235392,257,0,4239488,512]

theorem envBound4894 : H12AffineFastState.Bounded env4894 := by
  intro p hp
  have h : env4894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4893_4894 : H12AffineEnvironment.transform 5 16 env4893 = env4894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4893 == env4894) = true)

theorem identity4894 : scanCanonicalize (H12AffineFastState.compose env4894 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4894 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4895 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4096,41348,444,41002,8329,445,303233,4096,4524,2081,74794,260,257,0,4356,512]

theorem envBound4895 : H12AffineFastState.Bounded env4895 := by
  intro p hp
  have h : env4895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4894_4895 : H12AffineEnvironment.transform 21 41348 env4894 = env4895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4894 == env4895) = true)

theorem identity4895 : scanCanonicalize (H12AffineFastState.compose env4895 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4895 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4896 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13973,65536,4525,262144,1025,13973,4096,5905,444,5823,8329,445,267796,4096,4524,2081,74794,260,257,0,4356,512]

theorem envBound4896 : H12AffineFastState.Bounded env4896 := by
  intro p hp
  have h : env4896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4895_4896 : H12AffineEnvironment.transform 14 13973 env4895 = env4896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4895 == env4896) = true)

theorem identity4896 : scanCanonicalize (H12AffineFastState.compose env4896 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound4896 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4897 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13973,8323,4525,262144,1025,13973,4096,5905,444,5823,8329,445,267796,4096,4524,2081,1193,260,257,0,4356,512]

theorem envBound4897 : H12AffineFastState.Bounded env4897 := by
  intro p hp
  have h : env4897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4896_4897 : H12AffineEnvironment.transform 15 8323 env4896 = env4897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env4896 == env4897) = true)

theorem identity4897 : scanCanonicalize (H12AffineFastState.compose env4897 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4897 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4898 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,4096,13973,8323,4096,262144,1025,13973,4096,5820,17,5823,8329,16,267796,4096,4097,2081,1193,169,172,0,4265,512]

theorem envBound4898 : H12AffineFastState.Bounded env4898 := by
  intro p hp
  have h : env4898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4897_4898 : H12AffineEnvironment.transform 7 173 env4897 = env4898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4897 == env4898) = true)

def env4899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4605,262144,1025,32768,4096,4194304,445,41002,8329,492,303312,4097,4605,2160,74794,4235392,257,81,4239488,593]

theorem envBound4899 : H12AffineFastState.Bounded env4899 := by
  intro p hp
  have h : env4899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4892_4899 : H12AffineEnvironment.transform 13 4097 env4892 = env4899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env4892 == env4899) = true)

def env4900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4605,262144,1025,32768,4096,41088,445,41002,8329,492,303312,4097,4605,2160,74794,0,257,81,4096,593]

theorem envBound4900 : H12AffineFastState.Bounded env4900 := by
  intro p hp
  have h : env4900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4899_4900 : H12AffineEnvironment.transform 21 41088 env4899 = env4900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4899 == env4900) = true)

theorem identity4900 : scanCanonicalize (H12AffineFastState.compose env4900 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4900 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4901 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,32768,65536,4345,262144,1025,32768,4096,41088,185,41002,8329,232,303312,4097,4345,2160,74794,0,5,81,4096,593]

theorem envBound4901 : H12AffineFastState.Bounded env4901 := by
  intro p hp
  have h : env4901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4900_4901 : H12AffineEnvironment.transform 7 4 env4900 = env4901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4900 == env4901) = true)

theorem identity4901 : scanCanonicalize (H12AffineFastState.compose env4901 (packedSelected [0,7,11,13,17,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 14020) := by decide +kernel

theorem selectedBound4901 : packedSelected [0,7,11,13,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env4902 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,14020,65536,4345,262144,1025,14020,4096,5700,185,5870,8329,232,267796,4097,4345,2160,74794,0,5,81,4096,593]

theorem envBound4902 : H12AffineFastState.Bounded env4902 := by
  intro p hp
  have h : env4902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4901_4902 : H12AffineEnvironment.transform 14 14020 env4901 = env4902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14020 env4901 == env4902) = true)

def env4903 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13884,65536,4097,262144,1025,13884,4096,5700,65,5654,8305,16,267796,4097,4097,2160,74794,0,5,81,4096,593]

theorem envBound4903 : H12AffineFastState.Bounded env4903 := by
  intro p hp
  have h : env4903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4902_4903 : H12AffineEnvironment.transform 6 120 env4902 = env4903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env4902 == env4903) = true)

theorem identity4903 : scanCanonicalize (H12AffineFastState.compose env4903 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 75787) := by decide +kernel

theorem selectedBound4903 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env4904 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13884,65536,4097,75787,1025,13884,4096,5700,65,5654,8305,16,81439,4097,4097,2160,74794,0,5,81,4096,593]

theorem envBound4904 : H12AffineFastState.Bounded env4904 := by
  intro p hp
  have h : env4904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4903_4904 : H12AffineEnvironment.transform 17 75787 env4903 = env4904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75787 env4903 == env4904) = true)

theorem identity4904 : scanCanonicalize (H12AffineFastState.compose env4904 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 13902) := by decide +kernel

theorem selectedBound4904 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4905 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13884,13902,4097,7749,1025,13884,4096,5700,65,5654,8305,16,2129,4097,4097,2160,4708,0,5,81,4096,593]

theorem envBound4905 : H12AffineFastState.Bounded env4905 := by
  intro p hp
  have h : env4905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4904_4905 : H12AffineEnvironment.transform 15 13902 env4904 = env4905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13902 env4904 == env4905) = true)

theorem identity4905 : scanCanonicalize (H12AffineFastState.compose env4905 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound4905 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4906 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,13884,13855,4097,7700,1025,13884,4096,5653,16,5654,8224,16,2048,4097,4097,2081,4661,0,5,0,4096,512]

theorem envBound4906 : H12AffineFastState.Bounded env4906 := by
  intro p hp
  have h : env4906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4905_4906 : H12AffineEnvironment.transform 5 17 env4905 = env4906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4905 == env4906) = true)

theorem identity4906 : scanCanonicalize (H12AffineFastState.compose env4906 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4906 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4907 : List Nat := [2,4,8,10,32,11,41,4,512,1024,2048,4096,8192,4097,13862,13829,4097,7694,1025,13862,4096,5647,10,5644,8224,10,2048,4097,4097,2081,4655,0,5,0,4096,512]

theorem envBound4907 : H12AffineFastState.Bounded env4907 := by
  intro p hp
  have h : env4907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4906_4907 : H12AffineEnvironment.transform 3 10 env4906 = env4907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4906 == env4907) = true)

theorem identity4907 : scanCanonicalize (H12AffineFastState.compose env4907 (packedSelected [0,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4907 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env4908 : List Nat := [2,4,8,10,32,11,41,4,512,1024,2048,1583,8192,1582,8201,8234,1582,2081,1025,8201,1583,32,10,35,8224,10,2048,1582,1582,2081,1024,0,5,0,1583,512]

theorem envBound4908 : H12AffineFastState.Bounded env4908 := by
  intro p hp
  have h : env4908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4907_4908 : H12AffineEnvironment.transform 11 1583 env4907 = env4908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env4907 == env4908) = true)

theorem identity4908 : scanCanonicalize (H12AffineFastState.compose env4908 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4908 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4909 : List Nat := [2,4,8,10,32,11,41,4,512,1024,1550,1583,8192,1582,8201,8234,1582,1583,1025,8201,1583,32,10,35,8224,10,1550,1582,1582,1583,1024,0,5,0,1583,512]

theorem envBound4909 : H12AffineFastState.Bounded env4909 := by
  intro p hp
  have h : env4909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4908_4909 : H12AffineEnvironment.transform 10 1550 env4908 = env4909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4908 == env4909) = true)

def env4910 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13885,65536,4096,262144,1025,13885,4096,5700,64,5655,8304,17,267796,4097,4096,2160,74794,0,5,81,4096,593]

theorem envBound4910 : H12AffineFastState.Bounded env4910 := by
  intro p hp
  have h : env4910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4902_4910 : H12AffineEnvironment.transform 6 121 env4902 = env4910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env4902 == env4910) = true)

theorem identity4910 : scanCanonicalize (H12AffineFastState.compose env4910 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 81470) := by decide +kernel

theorem selectedBound4910 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env4911 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13885,65536,4096,81470,1025,13885,4096,5700,64,5655,8304,17,75818,4097,4096,2160,74794,0,5,81,4096,593]

theorem envBound4911 : H12AffineFastState.Bounded env4911 := by
  intro p hp
  have h : env4911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4910_4911 : H12AffineEnvironment.transform 17 81470 env4910 = env4911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81470 env4910 == env4911) = true)

theorem identity4911 : scanCanonicalize (H12AffineFastState.compose env4911 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 13902) := by decide +kernel

theorem selectedBound4911 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env4912 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13885,13902,4096,2160,1025,13885,4096,5700,64,5655,8304,17,7780,4097,4096,2160,4708,0,5,81,4096,593]

theorem envBound4912 : H12AffineFastState.Bounded env4912 := by
  intro p hp
  have h : env4912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4911_4912 : H12AffineEnvironment.transform 15 13902 env4911 = env4912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13902 env4911 == env4912) = true)

theorem identity4912 : scanCanonicalize (H12AffineFastState.compose env4912 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4912 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4913 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,1589,8192,1588,8200,8315,1589,2160,1025,8200,1589,113,64,34,8304,17,2129,1588,1589,2160,1105,0,5,81,1589,593]

theorem envBound4913 : H12AffineFastState.Bounded env4913 := by
  intro p hp
  have h : env4913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4912_4913 : H12AffineEnvironment.transform 11 1589 env4912 = env4913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4912 == env4913) = true)

theorem identity4913 : scanCanonicalize (H12AffineFastState.compose env4913 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1631) := by decide +kernel

theorem selectedBound4913 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4914 : List Nat := [2,4,8,16,32,64,121,4,512,1024,1631,1589,8192,1588,8200,8315,1589,1583,1025,8200,1589,113,64,34,8304,17,1550,1588,1589,1583,1105,0,5,81,1589,593]

theorem envBound4914 : H12AffineFastState.Bounded env4914 := by
  intro p hp
  have h : env4914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4913_4914 : H12AffineEnvironment.transform 10 1631 env4913 = env4914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1631 env4913 == env4914) = true)

def env4915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4605,262144,1025,32768,4096,41089,445,41002,8329,492,303312,4097,4605,2160,74794,1,257,81,4097,593]

theorem envBound4915 : H12AffineFastState.Bounded env4915 := by
  intro p hp
  have h : env4915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4899_4915 : H12AffineEnvironment.transform 21 41089 env4899 = env4915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4899 == env4915) = true)

theorem identity4915 : scanCanonicalize (H12AffineFastState.compose env4915 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound4915 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4916 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4265,262144,1025,32768,4096,41089,233,41002,8329,184,303312,4097,4265,2160,74794,1,85,81,4097,593]

theorem envBound4916 : H12AffineFastState.Bounded env4916 := by
  intro p hp
  have h : env4916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4915_4916 : H12AffineEnvironment.transform 7 84 env4915 = env4916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env4915 == env4916) = true)

theorem identity4916 : scanCanonicalize (H12AffineFastState.compose env4916 (packedSelected [0,1,3,7,10,11,13,17,18,20,23,24,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound4916 : packedSelected [0,1,3,7,10,11,13,17,18,20,23,24,28,31,32] rootPS < 2^1333 := by decide +kernel

def env4917 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4265,7868,1025,32768,4096,41089,233,41002,8329,184,48748,4097,4265,2160,74794,1,85,81,4097,593]

theorem envBound4917 : H12AffineFastState.Bounded env4917 := by
  intro p hp
  have h : env4917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4916_4917 : H12AffineEnvironment.transform 17 7868 env4916 = env4917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env4916 == env4917) = true)

def env4918 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,32768,65536,4097,7700,1025,32768,4096,41001,65,41002,8225,16,48748,4097,4097,2160,74794,1,85,81,4097,593]

theorem envBound4918 : H12AffineFastState.Bounded env4918 := by
  intro p hp
  have h : env4918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4917_4918 : H12AffineEnvironment.transform 6 40 env4917 = env4918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4917 == env4918) = true)

theorem identity4918 : scanCanonicalize (H12AffineFastState.compose env4918 (packedSelected [0,1,5,7,8,17,20,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 13932) := by decide +kernel

theorem selectedBound4918 : packedSelected [0,1,5,7,8,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env4919 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,13932,65536,4097,7700,1025,13932,4096,5701,65,5702,8225,16,2048,4097,4097,2160,74794,1,85,81,4097,593]

theorem envBound4919 : H12AffineFastState.Bounded env4919 := by
  intro p hp
  have h : env4919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4918_4919 : H12AffineEnvironment.transform 14 13932 env4918 = env4919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13932 env4918 == env4919) = true)

theorem identity4919 : scanCanonicalize (H12AffineFastState.compose env4919 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 13855) := by decide +kernel

theorem selectedBound4919 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4920 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,13932,13855,4097,7700,1025,13932,4096,5701,65,5702,8225,16,2048,4097,4097,2160,4661,1,85,81,4097,593]

theorem envBound4920 : H12AffineFastState.Bounded env4920 := by
  intro p hp
  have h : env4920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4919_4920 : H12AffineEnvironment.transform 15 13855 env4919 = env4920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13855 env4919 == env4920) = true)

theorem identity4920 : scanCanonicalize (H12AffineFastState.compose env4920 (packedSelected [1,2,6,8,10,11,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2115) := by decide +kernel

theorem selectedBound4920 : packedSelected [1,2,6,8,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env4921 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,2115,4097,7727,7772,4097,7700,1025,7727,4096,5701,65,5702,2146,16,2048,4097,4097,2160,4661,1,85,81,4097,593]

theorem envBound4921 : H12AffineFastState.Bounded env4921 := by
  intro p hp
  have h : env4921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4920_4921 : H12AffineEnvironment.transform 12 2115 env4920 = env4921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2115 env4920 == env4921) = true)

theorem identity4921 : scanCanonicalize (H12AffineFastState.compose env4921 (packedSelected [0,1,7,8,10,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4921 : packedSelected [0,1,7,8,10,12,18] rootPS < 2^1333 := by decide +kernel

def env4922 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1588,2115,1589,2075,2152,1589,2080,1025,2075,1588,113,65,114,2146,16,2048,1589,1589,2160,1025,1,85,81,1589,593]

theorem envBound4922 : H12AffineFastState.Bounded env4922 := by
  intro p hp
  have h : env4922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4921_4922 : H12AffineEnvironment.transform 11 1588 env4921 = env4922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env4921 == env4922) = true)

theorem identity4922 : scanCanonicalize (H12AffineFastState.compose env4922 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1631) := by decide +kernel

theorem selectedBound4922 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4923 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1631,1588,1564,1589,1604,1591,1589,1663,1025,1604,1588,113,65,114,1597,16,1631,1589,1589,1583,1025,1,85,81,1589,593]

theorem envBound4923 : H12AffineFastState.Bounded env4923 := by
  intro p hp
  have h : env4923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4922_4923 : H12AffineEnvironment.transform 10 1631 env4922 = env4923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1631 env4922 == env4923) = true)

theorem identity4923 : scanCanonicalize (H12AffineFastState.compose env4923 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4923 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4924 : List Nat := [2,4,8,16,26,64,18,84,512,1024,1631,1550,1564,1551,1604,1549,1551,1605,1025,1604,1550,75,65,72,1543,16,1631,1551,1551,1557,1025,1,85,81,1551,593]

theorem envBound4924 : H12AffineFastState.Bounded env4924 := by
  intro p hp
  have h : env4924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4923_4924 : H12AffineEnvironment.transform 4 26 env4923 = env4924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4923 == env4924) = true)

theorem identity4924 : scanCanonicalize (H12AffineFastState.compose env4924 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound4924 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env4925 : List Nat := [2,4,8,16,26,64,18,84,512,526,81,0,18,1,74,3,1,75,527,74,0,75,65,72,9,16,81,1,1,27,527,1,85,81,1,593]

theorem envBound4925 : H12AffineFastState.Bounded env4925 := by
  intro p hp
  have h : env4925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4924_4925 : H12AffineEnvironment.transform 9 526 env4924 = env4925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env4924 == env4925) = true)

theorem identity4925 : scanCanonicalize (H12AffineFastState.compose env4925 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound4925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4926 : List Nat := [2,4,8,16,26,16,18,4,512,526,1,0,18,1,26,3,1,27,527,26,0,27,17,24,9,16,1,1,1,27,527,1,5,1,1,513]

theorem envBound4926 : H12AffineFastState.Bounded env4926 := by
  intro p hp
  have h : env4926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4925_4926 : H12AffineEnvironment.transform 5 16 env4925 = env4926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4925 == env4926) = true)

theorem identity4926 : scanCanonicalize (H12AffineFastState.compose env4926 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4926 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env4927 : List Nat := [2,4,8,16,26,16,18,4,1,15,1,0,18,1,26,3,1,27,14,26,0,27,17,24,9,16,1,1,1,27,14,1,5,1,1,0]

theorem envBound4927 : H12AffineFastState.Bounded env4927 := by
  intro p hp
  have h : env4927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4926_4927 : H12AffineEnvironment.transform 8 1 env4926 = env4927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4926 == env4927) = true)

theorem identity4927 : scanCanonicalize (H12AffineFastState.compose env4927 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound4927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4928 : List Nat := [2,4,8,4,14,4,6,4,1,15,1,0,6,1,14,3,1,15,14,14,0,15,5,12,9,4,1,1,1,15,14,1,5,1,1,0]

theorem envBound4928 : H12AffineFastState.Bounded env4928 := by
  intro p hp
  have h : env4928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4927_4928 : H12AffineEnvironment.transform 3 4 env4927 = env4928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4927 == env4928) = true)

theorem identity4928 : scanCanonicalize (H12AffineFastState.compose env4928 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4928 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4929 : List Nat := [2,0,8,0,10,0,2,0,1,11,1,0,2,1,10,3,1,11,10,10,0,11,1,8,9,0,1,1,1,11,10,1,1,1,1,0]

theorem envBound4929 : H12AffineFastState.Bounded env4929 := by
  intro p hp
  have h : env4929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4928_4929 : H12AffineEnvironment.transform 1 0 env4928 = env4929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4928 == env4929) = true)

def leafEnv4929 : List Nat := [2,0,8,0,10,0,2,0,1,11,1,0,2,1,10,3,1,11,10,10,0,11,1,8,11,9,1,0,1,1,1,11,10,1,1,1,1,8,1,0,1,0,0]

def active4929 : List Nat := [0,2]

def tree4929 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4929 : H12WitnessSearch.Good tree4929 := H12GlobalWitnessIndex.good

theorem leafIdentity4929 : H12AffineFastState.composeSystem env4929 rootObs = leafEnv4929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4929 rootObs == leafEnv4929) = true)

theorem terminalChecked4929 : H12PackedTerminal.terminalCheckFast leafEnv4929 active4929 tree4929 = true := by decide +kernel

def env4930 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,4097,32768,65536,4096,7701,1025,32768,4096,41000,64,41002,8224,17,48748,4097,4096,2160,74794,1,85,81,4097,593]

theorem envBound4930 : H12AffineFastState.Bounded env4930 := by
  intro p hp
  have h : env4930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4917_4930 : H12AffineEnvironment.transform 6 41 env4917 = env4930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4917 == env4930) = true)

theorem identity4930 : scanCanonicalize (H12AffineFastState.compose env4930 (packedSelected [0,1,5,7,8,17,20,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound4930 : packedSelected [0,1,5,7,8,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env4931 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1637,8192,1636,32768,65536,1637,2160,1025,32768,1637,41000,64,41002,8224,17,43017,1636,1637,2160,74794,1,85,81,1636,593]

theorem envBound4931 : H12AffineFastState.Bounded env4931 := by
  intro p hp
  have h : env4931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4930_4931 : H12AffineEnvironment.transform 11 1637 env4930 = env4931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env4930 == env4931) = true)

theorem identity4931 : scanCanonicalize (H12AffineFastState.compose env4931 (packedSelected [3,5,8,13,21,28] rootPS)) = affineNative (2^(14+1) ^^^ 8281) := by decide +kernel

theorem selectedBound4931 : packedSelected [3,5,8,13,21,28] rootPS < 2^1333 := by decide +kernel

def env4932 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1637,8192,1636,8281,65536,1637,2160,1025,8281,1637,113,64,115,8224,17,2128,1636,1637,2160,74794,1,85,81,1636,593]

theorem envBound4932 : H12AffineFastState.Bounded env4932 := by
  intro p hp
  have h : env4932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4931_4932 : H12AffineEnvironment.transform 14 8281 env4931 = env4932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8281 env4931 == env4932) = true)

theorem identity4932 : scanCanonicalize (H12AffineFastState.compose env4932 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound4932 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4933 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1637,8192,1636,8281,8235,1637,2160,1025,8281,1637,113,64,115,8224,17,2128,1636,1637,2160,1025,1,85,81,1636,593]

theorem envBound4933 : H12AffineFastState.Bounded env4933 := by
  intro p hp
  have h : env4933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4932_4933 : H12AffineEnvironment.transform 15 8235 env4932 = env4933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env4932 == env4933) = true)

theorem identity4933 : scanCanonicalize (H12AffineFastState.compose env4933 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound4933 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env4934 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1637,1101,1636,1044,1126,1637,2160,1025,1044,1637,113,64,115,1133,17,2128,1636,1637,2160,1025,1,85,81,1636,593]

theorem envBound4934 : H12AffineFastState.Bounded env4934 := by
  intro p hp
  have h : env4934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4933_4934 : H12AffineEnvironment.transform 12 1101 env4933 = env4934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env4933 == env4934) = true)

theorem identity4934 : scanCanonicalize (H12AffineFastState.compose env4934 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1630) := by decide +kernel

theorem selectedBound4934 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4935 : List Nat := [2,4,8,16,32,64,41,84,512,1024,1630,1637,1101,1636,1044,1126,1637,1582,1025,1044,1637,113,64,115,1133,17,1550,1636,1637,1582,1025,1,85,81,1636,593]

theorem envBound4935 : H12AffineFastState.Bounded env4935 := by
  intro p hp
  have h : env4935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4934_4935 : H12AffineEnvironment.transform 10 1630 env4934 = env4935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1630 env4934 == env4935) = true)

theorem identity4935 : scanCanonicalize (H12AffineFastState.compose env4935 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound4935 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env4936 : List Nat := [2,4,8,16,32,10,41,30,512,1024,1556,1583,1031,1582,1044,1068,1583,1582,1025,1044,1583,59,10,57,1063,17,1550,1582,1583,1582,1025,1,31,27,1582,539]

theorem envBound4936 : H12AffineFastState.Bounded env4936 := by
  intro p hp
  have h : env4936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4935_4936 : H12AffineEnvironment.transform 5 10 env4935 = env4936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env4935 == env4936) = true)

theorem identity4936 : scanCanonicalize (H12AffineFastState.compose env4936 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4936 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env4937 : List Nat := [2,4,8,10,32,10,41,4,512,1024,1550,1583,1031,1582,1038,1068,1583,1582,1025,1038,1583,33,10,35,1063,11,1550,1582,1583,1582,1025,1,5,1,1582,513]

theorem envBound4937 : H12AffineFastState.Bounded env4937 := by
  intro p hp
  have h : env4937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4936_4937 : H12AffineEnvironment.transform 3 10 env4936 = env4937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4936 == env4937) = true)

theorem identity4937 : scanCanonicalize (H12AffineFastState.compose env4937 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound4937 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4938 : List Nat := [2,4,8,10,32,10,41,4,47,1024,1057,1024,1031,1025,1038,1068,1024,1025,1025,1038,1024,33,10,35,1063,11,1057,1025,1024,1025,1025,1,5,1,1025,46]

theorem envBound4938 : H12AffineFastState.Bounded env4938 := by
  intro p hp
  have h : env4938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4937_4938 : H12AffineEnvironment.transform 8 47 env4937 = env4938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env4937 == env4938) = true)

def env4939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849105,16384,16892,547953,598059,12644669,525568,545872,4239489,8914925]

theorem envBound4939 : H12AffineFastState.Bounded env4939 := by
  intro p hp
  have h : env4939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4830_4939 : H12AffineEnvironment.transform 20 4097 env4830 = env4939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env4830 == env4939) = true)

def env4940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323793,16384,16892,22641,74795,12644669,256,20560,4239489,8389613]

theorem envBound4940 : H12AffineFastState.Bounded env4940 := by
  intro p hp
  have h : env4940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4939_4940 : H12AffineEnvironment.transform 18 1024 env4939 = env4940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4939 == env4940) = true)

theorem identity4940 : scanCanonicalize (H12AffineFastState.compose env4940 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240428) := by decide +kernel

theorem selectedBound4940 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4240428,41002,8329,4240508,323793,16384,16892,22641,74795,17681,256,20560,4239489,4241345]

theorem envBound4941 : H12AffineFastState.Bounded env4941 := by
  intro p hp
  have h : env4941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4940_4941 : H12AffineEnvironment.transform 22 4240428 env4940 = env4941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240428 env4940 == env4941) = true)

def env4942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,46528,492,41002,8329,444,323793,16384,16892,22641,74795,17681,256,20560,1345,513]

theorem envBound4942 : H12AffineFastState.Bounded env4942 := by
  intro p hp
  have h : env4942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4941_4942 : H12AffineEnvironment.transform 21 46528 env4941 = env4942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46528 env4941 == env4942) = true)

theorem identity4942 : scanCanonicalize (H12AffineFastState.compose env4942 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound4942 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4943 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,46480,444,41002,8329,444,323713,16384,16812,22561,74795,17681,256,20480,1297,513]

theorem envBound4943 : H12AffineFastState.Bounded env4943 := by
  intro p hp
  have h : env4943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4942_4943 : H12AffineEnvironment.transform 5 16 env4942 = env4943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4942 == env4943) = true)

theorem identity4943 : scanCanonicalize (H12AffineFastState.compose env4943 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4943 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0