import H12CloudChart0Data050

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity12779 : scanCanonicalize (H12AffineFastState.compose env12779 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound12779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12780 : List Nat := [2,4,8,16,32,16,8,256,512,36,2048,4096,269,4389,0,263,4405,2341,36,1,4112,32,16,3,269,16,2048,4404,4097,2340,289,32,256,33,4389,513]

theorem envBound12780 : H12AffineFastState.Bounded env12780 := by
  intro p hp
  have h : env12780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12779_12780 : H12AffineEnvironment.transform 9 36 env12779 = env12780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env12779 == env12780) = true)

theorem identity12780 : scanCanonicalize (H12AffineFastState.compose env12780 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound12780 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12781 : List Nat := [2,4,8,16,32,16,8,256,512,36,2048,821,269,528,0,263,512,2341,36,1,805,32,16,3,269,16,2048,513,820,2340,289,32,256,33,528,513]

theorem envBound12781 : H12AffineFastState.Bounded env12781 := by
  intro p hp
  have h : env12781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12780_12781 : H12AffineEnvironment.transform 11 821 env12780 = env12781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env12780 == env12781) = true)

theorem identity12781 : scanCanonicalize (H12AffineFastState.compose env12781 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound12781 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12782 : List Nat := [2,4,8,16,32,16,8,256,512,36,309,821,269,528,0,263,512,16,36,1,805,32,16,3,269,16,309,513,820,17,289,32,256,33,528,513]

theorem envBound12782 : H12AffineFastState.Bounded env12782 := by
  intro p hp
  have h : env12782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12781_12782 : H12AffineEnvironment.transform 10 309 env12781 = env12782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env12781 == env12782) = true)

def env12783 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,62509,16,41231,8192,17,409908,57629,17664,442385,61705,62509,256,41261,16385,513]

theorem envBound12783 : H12AffineFastState.Bounded env12783 := by
  intro p hp
  have h : env12783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12773_12783 : H12AffineEnvironment.transform 5 17 env12773 = env12783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12773 == env12783) = true)

theorem identity12783 : scanCanonicalize (H12AffineFastState.compose env12783 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12783 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env12784 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10280,1024,32769,4113,62509,16,41231,8192,17,157980,57629,17664,190521,61705,62509,256,41261,16385,513]

theorem envBound12784 : H12AffineFastState.Bounded env12784 := by
  intro p hp
  have h : env12784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12783_12784 : H12AffineEnvironment.transform 17 10280 env12783 = env12784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12783 == env12784) = true)

theorem identity12784 : scanCanonicalize (H12AffineFastState.compose env12784 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound12784 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12785 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,24860,10280,1024,32769,4113,62509,16,41231,8192,17,2048,57629,17664,35109,61705,62509,256,41261,16385,513]

theorem envBound12785 : H12AffineFastState.Bounded env12785 := by
  intro p hp
  have h : env12785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12784_12785 : H12AffineEnvironment.transform 16 24860 env12784 = env12785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env12784 == env12785) = true)

theorem identity12785 : scanCanonicalize (H12AffineFastState.compose env12785 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12785 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12786 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,29963,24860,10280,1024,8461,4113,21793,16,3,8192,17,2048,16401,17664,10281,20485,21793,256,33,16385,513]

theorem envBound12786 : H12AffineFastState.Bounded env12786 := by
  intro p hp
  have h : env12786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12785_12786 : H12AffineEnvironment.transform 14 8460 env12785 = env12786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12785 == env12786) = true)

theorem identity12786 : scanCanonicalize (H12AffineFastState.compose env12786 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12786 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12787 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,21511,16400,2340,1024,1,4113,21793,16,3,268,17,2048,16401,17664,2341,20485,21793,256,33,16385,513]

theorem envBound12787 : H12AffineFastState.Bounded env12787 := by
  intro p hp
  have h : env12787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12786_12787 : H12AffineEnvironment.transform 12 268 env12786 = env12787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12786 == env12787) = true)

theorem identity12787 : scanCanonicalize (H12AffineFastState.compose env12787 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12788 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5393,2340,1024,1,4113,32,16,3,268,17,2048,5392,4097,2341,1284,32,256,33,5376,513]

theorem envBound12788 : H12AffineFastState.Bounded env12788 := by
  intro p hp
  have h : env12788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12787_12788 : H12AffineEnvironment.transform 13 5377 env12787 = env12788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12787 == env12788) = true)

theorem identity12788 : scanCanonicalize (H12AffineFastState.compose env12788 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound12788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12789 : List Nat := [2,4,8,16,32,17,8,53,512,1024,2048,4096,57,5172,0,51,5156,2065,1024,1,4113,32,16,3,57,17,2048,5157,4097,2064,1073,32,53,33,5173,513]

theorem envBound12789 : H12AffineFastState.Bounded env12789 := by
  intro p hp
  have h : env12789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12788_12789 : H12AffineEnvironment.transform 7 53 env12788 = env12789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env12788 == env12789) = true)

theorem identity12789 : scanCanonicalize (H12AffineFastState.compose env12789 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound12789 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12790 : List Nat := [2,4,8,16,32,17,8,53,512,1024,2048,513,57,1589,0,51,1573,2065,1024,1,528,32,16,3,57,17,2048,1572,512,2064,1073,32,53,33,1588,513]

theorem envBound12790 : H12AffineFastState.Bounded env12790 := by
  intro p hp
  have h : env12790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12789_12790 : H12AffineEnvironment.transform 11 513 env12789 = env12790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env12789 == env12790) = true)

theorem identity12790 : scanCanonicalize (H12AffineFastState.compose env12790 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound12790 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12791 : List Nat := [2,4,8,16,32,17,8,53,512,1024,528,513,57,1589,0,51,1573,513,1024,1,528,32,16,3,57,17,528,1572,512,512,1073,32,53,33,1588,513]

theorem envBound12791 : H12AffineFastState.Bounded env12791 := by
  intro p hp
  have h : env12791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12790_12791 : H12AffineEnvironment.transform 10 528 env12790 = env12791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env12790 == env12791) = true)

theorem identity12791 : scanCanonicalize (H12AffineFastState.compose env12791 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound12791 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12792 : List Nat := [2,4,8,16,32,17,8,53,512,36,528,513,57,529,0,51,513,513,36,1,528,32,16,3,57,17,528,512,512,512,21,32,53,33,528,513]

theorem envBound12792 : H12AffineFastState.Bounded env12792 := by
  intro p hp
  have h : env12792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12791_12792 : H12AffineEnvironment.transform 9 36 env12791 = env12792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env12791 == env12792) = true)

theorem identity12792 : scanCanonicalize (H12AffineFastState.compose env12792 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound12792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12793 : List Nat := [2,4,8,16,17,17,8,4,512,21,528,513,8,529,0,2,513,513,21,1,528,17,16,3,8,17,528,512,512,512,21,17,4,16,528,513]

theorem envBound12793 : H12AffineFastState.Bounded env12793 := by
  intro p hp
  have h : env12793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12792_12793 : H12AffineEnvironment.transform 4 17 env12792 = env12793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env12792 == env12793) = true)

def env12794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62589,119879,41310,8192,64,409957,79131,102742,463942,61704,73770,256,41340,16464,120406]

theorem envBound12794 : H12AffineFastState.Bounded env12794 := by
  intro p hp
  have h : env12794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12771_12794 : H12AffineEnvironment.transform 20 4161 env12771 = env12794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12771 == env12794) = true)

def env12795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119879,41310,8192,64,158029,79131,102742,212078,61704,73770,256,41340,16464,120406]

theorem envBound12795 : H12AffineFastState.Bounded env12795 := by
  intro p hp
  have h : env12795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12794_12795 : H12AffineEnvironment.transform 17 10280 env12794 = env12795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12794 == env12795) = true)

theorem identity12795 : scanCanonicalize (H12AffineFastState.compose env12795 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound12795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,4161,62589,16,41310,8192,64,158029,57676,17665,190521,61704,62589,256,41340,16464,513]

theorem envBound12796 : H12AffineFastState.Bounded env12796 := by
  intro p hp
  have h : env12796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12795_12796 : H12AffineEnvironment.transform 15 54359 env12795 = env12796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env12795 == env12796) = true)

theorem identity12796 : scanCanonicalize (H12AffineFastState.compose env12796 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound12796 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env12797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,10280,1024,29788,4161,32,16,21763,8192,64,158029,5393,17665,138340,1365,32,256,21793,16464,513]

theorem envBound12797 : H12AffineFastState.Bounded env12797 := by
  intro p hp
  have h : env12797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12796_12797 : H12AffineEnvironment.transform 14 29789 env12796 = env12797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env12796 == env12797) = true)

theorem identity12797 : scanCanonicalize (H12AffineFastState.compose env12797 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound12797 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env12798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,13389,10280,1024,29788,4161,32,16,21763,8192,64,23808,5393,17665,10281,1365,32,256,21793,16464,513]

theorem envBound12798 : H12AffineFastState.Bounded env12798 := by
  intro p hp
  have h : env12798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12797_12798 : H12AffineEnvironment.transform 16 13389 env12797 = env12798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env12797 == env12798) = true)

theorem identity12798 : scanCanonicalize (H12AffineFastState.compose env12798 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12798 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13389,10280,1024,1,4161,32,16,8542,8192,64,10589,5393,12636,10281,1365,32,256,8572,13325,513]

theorem envBound12799 : H12AffineFastState.Bounded env12799 := by
  intro p hp
  have h : env12799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12798_12799 : H12AffineEnvironment.transform 13 13405 env12798 = env12799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12798 == env12799) = true)

theorem identity12799 : scanCanonicalize (H12AffineFastState.compose env12799 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12799 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1024,1,4161,32,16,3,349,64,2048,5393,4097,2420,1365,32,256,33,5456,513]

theorem envBound12800 : H12AffineFastState.Bounded env12800 := by
  intro p hp
  have h : env12800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12799_12800 : H12AffineEnvironment.transform 12 349 env12799 = env12800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12799 == env12800) = true)

theorem identity12800 : scanCanonicalize (H12AffineFastState.compose env12800 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound12800 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,868,349,1636,0,343,1652,2421,1024,1,805,32,16,3,349,64,2048,1653,869,2420,1365,32,256,33,1588,513]

theorem envBound12801 : H12AffineFastState.Bounded env12801 := by
  intro p hp
  have h : env12801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12800_12801 : H12AffineEnvironment.transform 11 868 env12800 = env12801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env12800 == env12801) = true)

theorem identity12801 : scanCanonicalize (H12AffineFastState.compose env12801 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound12801 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,528,868,349,1636,0,343,1652,869,1024,1,805,32,16,3,349,64,528,1653,869,868,1365,32,256,33,1588,513]

theorem envBound12802 : H12AffineFastState.Bounded env12802 := by
  intro p hp
  have h : env12802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12801_12802 : H12AffineEnvironment.transform 10 528 env12801 = env12802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env12801 == env12802) = true)

def env12803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62589,119879,41310,8192,64,158028,79131,102742,212079,61704,73770,256,41340,16464,120406]

theorem envBound12803 : H12AffineFastState.Bounded env12803 := by
  intro p hp
  have h : env12803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12794_12803 : H12AffineEnvironment.transform 17 10281 env12794 = env12803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12794 == env12803) = true)

theorem identity12803 : scanCanonicalize (H12AffineFastState.compose env12803 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound12803 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,46157,10281,1024,32769,4161,62589,119879,41310,8192,64,56577,79131,102742,100386,61704,73770,256,41340,16464,120406]

theorem envBound12804 : H12AffineFastState.Bounded env12804 := by
  intro p hp
  have h : env12804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12803_12804 : H12AffineEnvironment.transform 16 46157 env12803 = env12804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env12803 == env12804) = true)

theorem identity12804 : scanCanonicalize (H12AffineFastState.compose env12804 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound12804 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,46157,10281,1024,32769,4161,62589,42077,41310,8192,64,56577,17665,57676,63544,61704,20528,256,41340,16464,42572]

theorem envBound12805 : H12AffineFastState.Bounded env12805 := by
  intro p hp
  have h : env12805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12804_12805 : H12AffineEnvironment.transform 15 28698 env12804 = env12805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env12804 == env12805) = true)

theorem identity12805 : scanCanonicalize (H12AffineFastState.compose env12805 (packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12805 : packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env12806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,5392,10281,1024,8540,4161,21792,1280,3,8192,64,31836,17665,16401,22885,20565,20528,256,33,16464,1809]

theorem envBound12806 : H12AffineFastState.Bounded env12806 := by
  intro p hp
  have h : env12806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12805_12806 : H12AffineEnvironment.transform 14 8541 env12805 = env12806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12805 == env12806) = true)

theorem identity12806 : scanCanonicalize (H12AffineFastState.compose env12806 (packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound12806 : packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env12807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8541,1378,5392,10281,1024,8540,4161,8280,1280,3,8192,64,2340,12409,13673,11293,9517,9544,256,33,13608,1809]

theorem envBound12807 : H12AffineFastState.Bounded env12807 := by
  intro p hp
  have h : env12807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12806_12807 : H12AffineEnvironment.transform 13 13688 env12806 = env12807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env12806 == env12807) = true)

theorem identity12807 : scanCanonicalize (H12AffineFastState.compose env12807 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound12807 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env12808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4453,1344,1378,5392,3124,1024,1345,4161,1093,1280,3,1053,64,2340,5220,4468,2048,304,341,256,33,4405,1809]

theorem envBound12808 : H12AffineFastState.Bounded env12808 := by
  intro p hp
  have h : env12808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12807_12808 : H12AffineEnvironment.transform 12 1053 env12807 = env12808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env12807 == env12808) = true)

theorem identity12808 : scanCanonicalize (H12AffineFastState.compose env12808 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound12808 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env12809 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,301,4453,112,82,4128,2308,304,113,4161,373,48,3,301,64,2340,4436,4468,2048,304,341,256,33,4405,545]

theorem envBound12809 : H12AffineFastState.Bounded env12809 := by
  intro p hp
  have h : env12809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12808_12809 : H12AffineEnvironment.transform 9 304 env12808 = env12809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env12808 == env12809) = true)

theorem identity12809 : scanCanonicalize (H12AffineFastState.compose env12809 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12809 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12810 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,269,4421,80,82,4096,2308,272,81,4161,341,16,3,269,64,2308,4436,4436,2048,272,341,256,1,4373,513]

theorem envBound12810 : H12AffineFastState.Bounded env12810 := by
  intro p hp
  have h : env12810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12809_12810 : H12AffineEnvironment.transform 4 0 env12809 = env12810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12809 == env12810) = true)

theorem identity12810 : scanCanonicalize (H12AffineFastState.compose env12810 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12810 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env12811 : List Nat := [2,4,8,16,0,64,8,256,81,272,2048,4096,269,4421,80,82,4096,2308,272,81,4161,341,16,3,269,64,2308,4436,4436,2048,272,341,256,1,4373,80]

theorem envBound12811 : H12AffineFastState.Bounded env12811 := by
  intro p hp
  have h : env12811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12810_12811 : H12AffineEnvironment.transform 8 81 env12810 = env12811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12810 == env12811) = true)

theorem identity12811 : scanCanonicalize (H12AffineFastState.compose env12811 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12811 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12812 : List Nat := [2,4,8,16,0,16,8,256,1,272,2048,4096,269,4373,0,2,4096,2308,272,1,4113,261,16,3,269,16,2308,4356,4356,2048,272,261,256,1,4373,0]

theorem envBound12812 : H12AffineFastState.Bounded env12812 := by
  intro p hp
  have h : env12812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12811_12812 : H12AffineEnvironment.transform 5 16 env12811 = env12812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12811 == env12812) = true)

theorem identity12812 : scanCanonicalize (H12AffineFastState.compose env12812 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound12812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12813 : List Nat := [2,4,8,16,0,16,8,256,1,272,2048,2064,269,2309,0,2,2064,2308,272,1,2049,261,16,3,269,16,2308,2324,2324,2048,272,261,256,1,2309,0]

theorem envBound12813 : H12AffineFastState.Bounded env12813 := by
  intro p hp
  have h : env12813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12812_12813 : H12AffineEnvironment.transform 11 2064 env12812 = env12813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env12812 == env12813) = true)

def env12814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212870,16777216,8193,64,17227835,18973701,102742,2556935,18890775,16875893,256,16777251,16834830,18966344]

theorem envBound12814 : H12AffineFastState.Bounded env12814 := by
  intro p hp
  have h : env12814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12769_12814 : H12AffineEnvironment.transform 6 9 env12769 = env12814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12769 == env12814) = true)

theorem identity12814 : scanCanonicalize (H12AffineFastState.compose env12814 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound12814 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,2155580,2212870,16777216,8193,64,17039734,18973701,102742,2483530,18890775,16875893,256,16777251,16834830,18966344]

theorem envBound12815 : H12AffineFastState.Bounded env12815 := by
  intro p hp
  have h : env12815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12814_12815 : H12AffineEnvironment.transform 16 57677 env12814 = env12815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env12814 == env12815) = true)

theorem identity12815 : scanCanonicalize (H12AffineFastState.compose env12815 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound12815 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,262144,1024,32769,2097152,2155580,2114897,16777216,8193,64,17039734,18875730,4097,2384925,18890775,16777250,256,16777251,16834830,18933279]

theorem envBound12816 : H12AffineFastState.Bounded env12816 := by
  intro p hp
  have h : env12816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12815_12816 : H12AffineEnvironment.transform 15 33111 env12815 = env12816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env12815 == env12816) = true)

theorem identity12816 : scanCanonicalize (H12AffineFastState.compose env12816 (packedSelected [1,3,4,5,7,8,9,10,11,14,15,16,17,19,20,27,32,35,38] rootPS)) = affineNative (2^(23+1) ^^^ 2122831) := by decide +kernel

theorem selectedBound12816 : packedSelected [1,3,4,5,7,8,9,10,11,14,15,16,17,19,20,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env12817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,262144,1024,32769,2097152,2155580,2114897,2122831,8193,64,2385209,24861,4097,2384925,9304,2122861,256,2122860,2131265,33360]

theorem envBound12817 : H12AffineFastState.Bounded env12817 := by
  intro p hp
  have h : env12817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12816_12817 : H12AffineEnvironment.transform 23 2122831 env12816 = env12817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2122831 env12816 == env12817) = true)

theorem identity12817 : scanCanonicalize (H12AffineFastState.compose env12817 (packedSelected [3,10,17,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound12817 : packedSelected [3,10,17,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,43128,1024,32769,2097152,2155580,2114897,2122831,8193,64,2149697,24861,4097,2149477,9304,2122861,256,2122860,2131265,33360]

theorem envBound12818 : H12AffineFastState.Bounded env12818 := by
  intro p hp
  have h : env12818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12817_12818 : H12AffineEnvironment.transform 17 43128 env12817 = env12818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env12817 == env12818) = true)

theorem identity12818 : scanCanonicalize (H12AffineFastState.compose env12818 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12818 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env12819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8283,16449,2420,1024,8461,2097152,2114864,2114897,2122831,8193,64,2124877,24861,4097,2125161,9304,2122861,256,2122860,2106445,9052]

theorem envBound12819 : H12AffineFastState.Bounded env12819 := by
  intro p hp
  have h : env12819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12818_12819 : H12AffineEnvironment.transform 14 8460 env12818 = env12819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12818 == env12819) = true)

theorem identity12819 : scanCanonicalize (H12AffineFastState.compose env12819 (packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound12819 : packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env12820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8283,16449,2420,1024,8461,4405,21509,21604,30074,8193,64,32120,24861,4097,31836,9304,30040,256,30041,13688,9052]

theorem envBound12820 : H12AffineFastState.Bounded env12820 := by
  intro p hp
  have h : env12820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12819_12820 : H12AffineEnvironment.transform 20 4405 env12819 = env12820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env12819 == env12820) = true)

theorem identity12820 : scanCanonicalize (H12AffineFastState.compose env12820 (packedSelected [0,1,4,7,8,9,10,11,15,16,21] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound12820 : packedSelected [0,1,4,7,8,9,10,11,15,16,21] rootPS < 2^1333 := by decide +kernel

def env12821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8460,8283,13672,2420,1024,8461,4405,8492,8525,83,8193,64,2129,5172,4097,2421,9304,113,256,112,13688,9052]

theorem envBound12821 : H12AffineFastState.Bounded env12821 := by
  intro p hp
  have h : env12821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12820_12821 : H12AffineEnvironment.transform 13 13609 env12820 = env12821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env12820 == env12821) = true)

theorem identity12821 : scanCanonicalize (H12AffineFastState.compose env12821 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12821 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12822 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13609,8460,8203,13624,2340,1024,8461,4405,8492,8477,3,8193,16,2049,5172,4097,2341,9224,33,256,32,13608,8972]

theorem envBound12822 : H12AffineFastState.Bounded env12822 := by
  intro p hp
  have h : env12822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12821_12822 : H12AffineEnvironment.transform 5 16 env12821 = env12822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12821 == env12822) = true)

theorem identity12822 : scanCanonicalize (H12AffineFastState.compose env12822 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound12822 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12823 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5376,293,34,5393,2340,1024,292,4405,261,308,3,40,16,2049,5172,4097,2341,1057,33,256,32,5377,805]

theorem envBound12823 : H12AffineFastState.Bounded env12823 := by
  intro p hp
  have h : env12823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12822_12823 : H12AffineEnvironment.transform 12 41 env12822 = env12823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env12822 == env12823) = true)

theorem identity12823 : scanCanonicalize (H12AffineFastState.compose env12823 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12823 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env12824 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4113,33,16,3,40,16,2049,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound12824 : H12AffineFastState.Bounded env12824 := by
  intro p hp
  have h : env12824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12823_12824 : H12AffineEnvironment.transform 7 36 env12823 = env12824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12823 == env12824) = true)

def env12825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,16777216,8328,64,17227834,18973836,102742,2556935,18890775,16876029,256,16777386,16834830,18966465]

theorem envBound12825 : H12AffineFastState.Bounded env12825 := by
  intro p hp
  have h : env12825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12768_12825 : H12AffineEnvironment.transform 21 2155581 env12768 = env12825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env12768 == env12825) = true)

def env12826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,16777216,8192,64,17227834,18973700,102742,2556935,18890775,16875893,256,16777250,16834830,18966345]

theorem envBound12826 : H12AffineFastState.Bounded env12826 := by
  intro p hp
  have h : env12826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12825_12826 : H12AffineEnvironment.transform 6 8 env12825 = env12826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12825 == env12826) = true)

theorem identity12826 : scanCanonicalize (H12AffineFastState.compose env12826 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound12826 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,2188616,8192,64,2590066,57676,102742,2556935,75103,2155581,256,2188650,2196550,513]

theorem envBound12827 : H12AffineFastState.Bounded env12827 := by
  intro p hp
  have h : env12827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12826_12827 : H12AffineEnvironment.transform 23 2188616 env12826 = env12827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env12826 == env12827) = true)

def env12828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,2155581,2212870,2188616,8192,64,2338138,57676,102742,2305071,75103,2155581,256,2188650,2196550,513]

theorem envBound12828 : H12AffineFastState.Bounded env12828 := by
  intro p hp
  have h : env12828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12827_12828 : H12AffineEnvironment.transform 17 10280 env12827 = env12828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12827 == env12828) = true)

theorem identity12828 : scanCanonicalize (H12AffineFastState.compose env12828 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound12828 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env12829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,2155581,2212870,2188616,8192,64,2182167,57676,102742,2215266,75103,2155581,256,2188650,2196550,513]

theorem envBound12829 : H12AffineFastState.Bounded env12829 := by
  intro p hp
  have h : env12829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12828_12829 : H12AffineEnvironment.transform 16 57677 env12828 = env12829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env12828 == env12829) = true)

theorem identity12829 : scanCanonicalize (H12AffineFastState.compose env12829 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 124187) := by decide +kernel

theorem selectedBound12829 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env12830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,124187,65830,8477,32851,8192,64,43276,57676,102742,10361,75103,65830,256,32881,24925,513]

theorem envBound12830 : H12AffineFastState.Bounded env12830 := by
  intro p hp
  have h : env12830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12829_12830 : H12AffineEnvironment.transform 20 124187 env12829 = env12830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124187 env12829 == env12830) = true)

theorem identity12830 : scanCanonicalize (H12AffineFastState.compose env12830 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound12830 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env12831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,57677,10280,1024,32769,58444,113,8477,32851,8192,64,43276,57676,36865,10361,9224,113,256,32881,24925,513]

theorem envBound12831 : H12AffineFastState.Bounded env12831 := by
  intro p hp
  have h : env12831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12830_12831 : H12AffineEnvironment.transform 15 343 env12830 = env12831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env12830 == env12831) = true)

theorem identity12831 : scanCanonicalize (H12AffineFastState.compose env12831 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12831 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,343,49217,2340,1024,32769,50496,113,17,32851,268,64,34816,49216,36865,2421,1284,113,256,32881,16465,513]

theorem envBound12832 : H12AffineFastState.Bounded env12832 := by
  intro p hp
  have h : env12832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12831_12832 : H12AffineEnvironment.transform 12 268 env12831 = env12832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12831 == env12832) = true)

def env12833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,2155581,2212870,2188616,8192,64,2338139,57676,102742,2305070,75103,2155581,256,2188650,2196550,513]

theorem envBound12833 : H12AffineFastState.Bounded env12833 := by
  intro p hp
  have h : env12833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12827_12833 : H12AffineEnvironment.transform 17 10281 env12827 = env12833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12827 == env12833) = true)

theorem identity12833 : scanCanonicalize (H12AffineFastState.compose env12833 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12833 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,2097152,2155581,2212870,2188616,8192,64,2149697,57676,102742,2116660,75103,2155581,256,2188650,2196550,513]

theorem envBound12834 : H12AffineFastState.Bounded env12834 := by
  intro p hp
  have h : env12834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12833_12834 : H12AffineEnvironment.transform 16 90138 env12833 = env12834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12833 == env12834) = true)

theorem identity12834 : scanCanonicalize (H12AffineFastState.compose env12834 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 46092) := by decide +kernel

theorem selectedBound12834 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,46092,20529,94218,119108,8192,64,31053,57676,102742,63544,75103,20529,256,119142,77898,513]

theorem envBound12835 : H12AffineFastState.Bounded env12835 := by
  intro p hp
  have h : env12835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12834_12835 : H12AffineEnvironment.transform 20 46092 env12834 = env12835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46092 env12834 == env12835) = true)

theorem identity12835 : scanCanonicalize (H12AffineFastState.compose env12835 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound12835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,46092,20529,16,41310,8192,64,31053,57676,57676,63544,21829,20529,256,41340,16464,513]

theorem envBound12836 : H12AffineFastState.Bounded env12836 := by
  intro p hp
  have h : env12836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12835_12836 : H12AffineEnvironment.transform 15 28698 env12835 = env12836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env12835 == env12836) = true)

theorem identity12836 : scanCanonicalize (H12AffineFastState.compose env12836 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound12836 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,16384,32768,17430,4096,7205,1024,32769,32768,20529,16,38226,5132,64,19777,54592,54592,52276,21829,20529,256,38256,16464,513]

theorem envBound12837 : H12AffineFastState.Bounded env12837 := by
  intro p hp
  have h : env12837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12836_12837 : H12AffineEnvironment.transform 12 5132 env12836 = env12837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env12836 == env12837) = true)

theorem identity12837 : scanCanonicalize (H12AffineFastState.compose env12837 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound12837 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env12838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,1077,32768,35,4096,7205,1024,32769,32768,5124,16,38226,5132,64,2420,37237,37237,34817,4464,5124,256,38256,1125,513]

theorem envBound12838 : H12AffineFastState.Bounded env12838 := by
  intro p hp
  have h : env12838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12837_12838 : H12AffineEnvironment.transform 13 1077 env12837 = env12838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env12837 == env12838) = true)

theorem identity12838 : scanCanonicalize (H12AffineFastState.compose env12838 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 5157) := by decide +kernel

theorem selectedBound12838 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env12839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,1077,5157,35,4096,7205,1024,5156,5157,5124,16,375,5132,64,2420,1360,1360,7204,4464,5124,256,341,1125,513]

theorem envBound12839 : H12AffineFastState.Bounded env12839 := by
  intro p hp
  have h : env12839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12838_12839 : H12AffineEnvironment.transform 14 5157 env12838 = env12839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5157 env12838 == env12839) = true)

theorem identity12839 : scanCanonicalize (H12AffineFastState.compose env12839 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12839 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env12840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,5132,1077,5157,35,4096,4404,1024,5156,5157,5124,16,375,5132,64,1125,1360,1360,4405,4464,5124,256,341,1125,513]

theorem envBound12840 : H12AffineFastState.Bounded env12840 := by
  intro p hp
  have h : env12840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12839_12840 : H12AffineEnvironment.transform 10 1297 env12839 = env12840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env12839 == env12840) = true)

theorem identity12840 : scanCanonicalize (H12AffineFastState.compose env12840 (packedSelected [0,1,2,4,8,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12840 : packedSelected [0,1,2,4,8,11,14] rootPS < 2^1333 := by decide +kernel

def env12841 : List Nat := [2,4,8,16,32,64,8,256,512,52,293,4096,4152,1,4113,35,4096,4404,52,4112,4113,4144,16,375,4152,64,81,356,356,4405,4464,4144,256,341,81,513]

theorem envBound12841 : H12AffineFastState.Bounded env12841 := by
  intro p hp
  have h : env12841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12840_12841 : H12AffineEnvironment.transform 9 52 env12840 = env12841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12840 == env12841) = true)

theorem identity12841 : scanCanonicalize (H12AffineFastState.compose env12841 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12841 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env12842 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,4096,4152,1,4113,35,4096,4112,52,4112,4113,4144,16,83,4152,64,81,64,64,4113,4180,4144,36,113,81,513]

theorem envBound12842 : H12AffineFastState.Bounded env12842 := by
  intro p hp
  have h : env12842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12841_12842 : H12AffineEnvironment.transform 7 36 env12841 = env12842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12841 == env12842) = true)

theorem identity12842 : scanCanonicalize (H12AffineFastState.compose env12842 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound12842 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12843 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,64,120,1,81,35,64,80,52,80,81,112,16,83,120,64,81,64,64,81,20,112,36,113,81,513]

theorem envBound12843 : H12AffineFastState.Bounded env12843 := by
  intro p hp
  have h : env12843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12842_12843 : H12AffineEnvironment.transform 11 64 env12842 = env12843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env12842 == env12843) = true)

theorem identity12843 : scanCanonicalize (H12AffineFastState.compose env12843 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound12843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12844 : List Nat := [2,4,8,16,32,64,8,36,113,52,1,64,120,1,81,35,64,80,52,80,81,112,16,83,120,64,81,64,64,81,20,112,36,113,81,112]

theorem envBound12844 : H12AffineFastState.Bounded env12844 := by
  intro p hp
  have h : env12844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12843_12844 : H12AffineEnvironment.transform 8 113 env12843 = env12844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env12843 == env12844) = true)

theorem identity12844 : scanCanonicalize (H12AffineFastState.compose env12844 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12844 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12845 : List Nat := [2,4,8,16,32,16,8,36,33,52,1,16,40,1,1,35,16,0,52,0,1,32,16,3,40,16,1,16,16,1,20,32,36,33,1,32]

theorem envBound12845 : H12AffineFastState.Bounded env12845 := by
  intro p hp
  have h : env12845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12844_12845 : H12AffineEnvironment.transform 5 16 env12844 = env12845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12844 == env12845) = true)

def env12846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212870,16777216,8193,64,17227834,18973701,102742,2556935,18890775,16875892,256,16777251,16834830,18966344]

theorem envBound12846 : H12AffineFastState.Bounded env12846 := by
  intro p hp
  have h : env12846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12825_12846 : H12AffineEnvironment.transform 6 9 env12825 = env12846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12825 == env12846) = true)

theorem identity12846 : scanCanonicalize (H12AffineFastState.compose env12846 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 206171) := by decide +kernel

theorem selectedBound12846 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,206171,246118,188765,16777216,8193,64,17227834,16949598,102742,270684,16999756,16875892,256,16777251,16834830,16925203]

theorem envBound12847 : H12AffineFastState.Bounded env12847 := by
  intro p hp
  have h : env12847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12846_12847 : H12AffineEnvironment.transform 20 206171 env12846 = env12847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206171 env12846 == env12847) = true)

def env12848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,206171,246118,188765,95496,8193,64,496946,250966,102742,270684,135236,62588,256,95531,103430,210715]

theorem envBound12848 : H12AffineFastState.Bounded env12848 := by
  intro p hp
  have h : env12848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12847_12848 : H12AffineEnvironment.transform 23 95496 env12847 = env12848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env12847 == env12848) = true)

theorem identity12848 : scanCanonicalize (H12AffineFastState.compose env12848 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12848 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,206171,234598,177245,73736,8193,64,496946,229718,102742,270684,135236,41340,256,73771,103430,210715]

theorem envBound12849 : H12AffineFastState.Bounded env12849 := by
  intro p hp
  have h : env12849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12848_12849 : H12AffineEnvironment.transform 13 5376 env12848 = env12849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12848 == env12849) = true)

theorem identity12849 : scanCanonicalize (H12AffineFastState.compose env12849 (packedSelected [0,1,3,5,8,9,10,11,12,14,15,18,19,21,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound12849 : packedSelected [0,1,3,5,8,9,10,11,12,14,15,18,19,21,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103494,262144,1024,32769,45341,32,73755,73736,8193,64,262516,5392,102742,270684,99330,41340,256,73771,103430,41821]

theorem envBound12850 : H12AffineFastState.Bounded env12850 := by
  intro p hp
  have h : env12850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12849_12850 : H12AffineEnvironment.transform 16 103494 env12849 = env12850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env12849 == env12850) = true)

theorem identity12850 : scanCanonicalize (H12AffineFastState.compose env12850 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound12850 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env12851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103494,67619,1024,32769,45341,32,73755,73736,8193,64,67927,5392,102742,76159,99330,41340,256,73771,103430,41821]

theorem envBound12851 : H12AffineFastState.Bounded env12851 := by
  intro p hp
  have h : env12851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12850_12851 : H12AffineEnvironment.transform 17 67619 env12850 = env12851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env12850 == env12851) = true)

theorem identity12851 : scanCanonicalize (H12AffineFastState.compose env12851 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound12851 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env12852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,32803,5221,34816,1024,32769,45341,32,41016,41003,8193,64,35188,5392,4469,43356,1057,41340,256,40968,5157,41821]

theorem envBound12852 : H12AffineFastState.Bounded env12852 := by
  intro p hp
  have h : env12852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12851_12852 : H12AffineEnvironment.transform 15 32803 env12851 = env12852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env12851 == env12852) = true)

theorem identity12852 : scanCanonicalize (H12AffineFastState.compose env12852 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12852 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env12853 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,32768,32803,5221,34816,1024,32769,45161,32,41016,41003,8193,64,34816,5220,4097,43048,1057,40968,116,40968,5157,41513]

theorem envBound12853 : H12AffineFastState.Bounded env12853 := by
  intro p hp
  have h : env12853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12852_12853 : H12AffineEnvironment.transform 7 116 env12852 = env12853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12852 == env12853) = true)

theorem identity12853 : scanCanonicalize (H12AffineFastState.compose env12853 (packedSelected [0,2,3,6,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound12853 : packedSelected [0,2,3,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env12854 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,32768,32803,5221,34816,1024,32769,36880,32,32833,32850,120,64,34816,5220,4097,34897,1057,32881,116,32881,5157,33360]

theorem envBound12854 : H12AffineFastState.Bounded env12854 := by
  intro p hp
  have h : env12854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12853_12854 : H12AffineEnvironment.transform 12 121 env12853 = env12854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env12853 == env12854) = true)

theorem identity12854 : scanCanonicalize (H12AffineFastState.compose env12854 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound12854 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env12855 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,1125,1094,5221,3173,1024,1124,5237,32,1060,1079,120,64,3173,5220,4097,3124,1057,1044,116,1044,5157,1589]

theorem envBound12855 : H12AffineFastState.Bounded env12855 := by
  intro p hp
  have h : env12855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12854_12855 : H12AffineEnvironment.transform 14 1125 env12854 = env12855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env12854 == env12855) = true)

def env12856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,206171,246118,188765,95497,8193,64,496947,250967,102742,270684,135237,62589,256,95530,103431,210714]

theorem envBound12856 : H12AffineFastState.Bounded env12856 := by
  intro p hp
  have h : env12856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12847_12856 : H12AffineEnvironment.transform 23 95497 env12847 = env12856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env12847 == env12856) = true)

theorem identity12856 : scanCanonicalize (H12AffineFastState.compose env12856 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12856 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,17729,41340,98631,95497,8193,64,324905,46157,102742,270684,94303,62589,256,95530,103431,22272]

theorem envBound12857 : H12AffineFastState.Bounded env12857 := by
  intro p hp
  have h : env12857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12856_12857 : H12AffineEnvironment.transform 16 90138 env12856 = env12857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12856 == env12857) = true)

theorem identity12857 : scanCanonicalize (H12AffineFastState.compose env12857 (packedSelected [0,3,4,7,10,11,12,15,16,18,20,21,22,23,24,26,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12857 : packedSelected [0,3,4,7,10,11,12,15,16,18,20,21,22,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env12858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,262144,1024,8541,17729,32,73755,95497,8193,64,283765,5393,77834,270684,94303,21793,256,95530,79195,22272]

theorem envBound12858 : H12AffineFastState.Bounded env12858 := by
  intro p hp
  have h : env12858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12857_12858 : H12AffineEnvironment.transform 14 8540 env12857 = env12858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12857 == env12858) = true)

theorem identity12858 : scanCanonicalize (H12AffineFastState.compose env12858 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12858 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env12859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79131,262144,1024,8541,4160,32,73755,73736,8193,64,262516,5393,77834,270684,75102,32,256,73771,79195,513]

theorem envBound12859 : H12AffineFastState.Bounded env12859 := by
  intro p hp
  have h : env12859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12858_12859 : H12AffineEnvironment.transform 13 5377 env12858 = env12859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12858 == env12859) = true)

theorem identity12859 : scanCanonicalize (H12AffineFastState.compose env12859 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 75867) := by decide +kernel

theorem selectedBound12859 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79131,75867,1024,8541,4160,32,73755,73736,8193,64,76079,5393,77834,67847,75102,32,256,73771,79195,513]

theorem envBound12860 : H12AffineFastState.Bounded env12860 := by
  intro p hp
  have h : env12860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12859_12860 : H12AffineEnvironment.transform 17 75867 env12859 = env12860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75867 env12859 == env12860) = true)

theorem identity12860 : scanCanonicalize (H12AffineFastState.compose env12860 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12860 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12861 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4112,8540,65536,77834,75867,273,8541,4160,32,73755,73736,8193,64,76079,4096,77834,67847,73807,32,256,73771,77898,513]

theorem envBound12861 : H12AffineFastState.Bounded env12861 := by
  intro p hp
  have h : env12861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12860_12861 : H12AffineEnvironment.transform 9 273 env12860 = env12861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12860 == env12861) = true)

theorem identity12861 : scanCanonicalize (H12AffineFastState.compose env12861 (packedSelected [0,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound12861 : packedSelected [0,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env12862 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2405,8192,2421,8540,65536,76143,75867,273,8541,2341,32,73755,73736,8193,64,76079,2405,76143,67847,73807,32,256,73771,76079,513]

theorem envBound12862 : H12AffineFastState.Bounded env12862 := by
  intro p hp
  have h : env12862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12861_12862 : H12AffineEnvironment.transform 11 2405 env12861 = env12862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env12861 == env12862) = true)

theorem identity12862 : scanCanonicalize (H12AffineFastState.compose env12862 (packedSelected [0,1,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound12862 : packedSelected [0,1,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env12863 : List Nat := [2,4,8,16,32,64,9,256,512,273,81,308,8192,292,8540,65536,74046,73738,273,8541,372,32,73755,73736,8193,64,74110,308,74046,65878,73807,32,256,73771,74110,513]

theorem envBound12863 : H12AffineFastState.Bounded env12863 := by
  intro p hp
  have h : env12863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12862_12863 : H12AffineEnvironment.transform 10 81 env12862 = env12863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env12862 == env12863) = true)

theorem identity12863 : scanCanonicalize (H12AffineFastState.compose env12863 (packedSelected [0,2,3,6,7,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound12863 : packedSelected [0,2,3,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env12864 : List Nat := [2,4,8,16,32,64,9,256,512,273,81,308,8192,292,8540,262,8248,8460,273,8541,372,32,8477,8462,8193,64,8312,308,8248,80,8521,32,256,8493,8312,513]

theorem envBound12864 : H12AffineFastState.Bounded env12864 := by
  intro p hp
  have h : env12864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12863_12864 : H12AffineEnvironment.transform 15 262 env12863 = env12864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env12863 == env12864) = true)

theorem identity12864 : scanCanonicalize (H12AffineFastState.compose env12864 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12864 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env12865 : List Nat := [2,4,8,16,32,64,9,256,512,273,81,308,348,292,0,262,356,80,273,1,372,32,65,82,349,64,292,308,356,80,21,32,256,113,292,513]

theorem envBound12865 : H12AffineFastState.Bounded env12865 := by
  intro p hp
  have h : env12865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12864_12865 : H12AffineEnvironment.transform 12 348 env12864 = env12865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12864 == env12865) = true)

theorem identity12865 : scanCanonicalize (H12AffineFastState.compose env12865 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12865 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12866 : List Nat := [2,4,8,16,32,64,9,37,512,52,81,17,121,1,0,35,65,80,52,1,81,32,65,82,120,64,1,17,65,80,21,32,37,113,1,513]

theorem envBound12866 : H12AffineFastState.Bounded env12866 := by
  intro p hp
  have h : env12866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12865_12866 : H12AffineEnvironment.transform 7 37 env12865 = env12866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12865 == env12866) = true)

theorem identity12866 : scanCanonicalize (H12AffineFastState.compose env12866 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound12866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12867 : List Nat := [2,4,8,16,32,48,9,37,512,52,33,17,9,1,0,35,49,32,52,1,33,32,49,34,8,48,1,17,49,32,21,32,37,1,1,513]

theorem envBound12867 : H12AffineFastState.Bounded env12867 := by
  intro p hp
  have h : env12867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12866_12867 : H12AffineEnvironment.transform 5 48 env12866 = env12867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12866 == env12867) = true)

theorem identity12867 : scanCanonicalize (H12AffineFastState.compose env12867 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12867 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12868 : List Nat := [2,4,8,16,1,17,9,4,512,21,0,17,9,1,0,2,16,1,21,1,0,1,16,3,8,17,1,17,16,1,21,1,4,1,1,513]

theorem envBound12868 : H12AffineFastState.Bounded env12868 := by
  intro p hp
  have h : env12868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12867_12868 : H12AffineEnvironment.transform 4 1 env12867 = env12868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12867 == env12868) = true)

theorem identity12868 : scanCanonicalize (H12AffineFastState.compose env12868 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12868 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12869 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,17,9,1,0,2,16,1,21,1,0,1,16,3,8,17,1,17,16,1,21,1,4,1,1,0]

theorem envBound12869 : H12AffineFastState.Bounded env12869 := by
  intro p hp
  have h : env12869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12868_12869 : H12AffineEnvironment.transform 8 1 env12868 = env12869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12868 == env12869) = true)

theorem identity12869 : scanCanonicalize (H12AffineFastState.compose env12869 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound12869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12870 : List Nat := [2,4,8,11,1,10,9,4,1,14,0,10,9,1,0,2,11,1,14,1,0,1,11,3,8,10,1,10,11,1,14,1,4,1,1,0]

theorem envBound12870 : H12AffineFastState.Bounded env12870 := by
  intro p hp
  have h : env12870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12869_12870 : H12AffineEnvironment.transform 3 11 env12869 = env12870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env12869 == env12870) = true)

def env12871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound12871 : H12AffineFastState.Bounded env12871 := by
  intro p hp
  have h : env12871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12766_12871 : H12AffineEnvironment.transform 18 1025 env12766 = env12871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12766 == env12871) = true)

theorem identity12871 : scanCanonicalize (H12AffineFastState.compose env12871 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237575) := by decide +kernel

theorem selectedBound12871 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237575,8328,64,15066247,237578,10507600,8830976,10723478,4407623,257,8642602,8585615,10651457]

theorem envBound12872 : H12AffineFastState.Bounded env12872 := by
  intro p hp
  have h : env12872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12871_12872 : H12AffineEnvironment.transform 23 2237575 env12871 = env12872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237575 env12871 == env12872) = true)

def env12873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066247,115150,10507600,8692164,10600786,4268163,257,8487406,8478795,10544773]

theorem envBound12873 : H12AffineFastState.Bounded env12873 := by
  intro p hp
  have h : env12873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12872_12873 : H12AffineEnvironment.transform 16 25028 env12872 = env12873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env12872 == env12873) = true)

def env12874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4584663,115150,17664,2404756,119042,4268163,257,2199998,2191387,63189]

theorem envBound12874 : H12AffineFastState.Bounded env12874 := by
  intro p hp
  have h : env12874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12873_12874 : H12AffineEnvironment.transform 22 2101328 env12873 = env12874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env12873 == env12874) = true)

def env12875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,121943,115150,17664,2404756,119042,329731,257,2199998,2191387,63189]

theorem envBound12875 : H12AffineFastState.Bounded env12875 := by
  intro p hp
  have h : env12875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12874_12875 : H12AffineEnvironment.transform 21 272512 env12874 = env12875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12874 == env12875) = true)

theorem identity12875 : scanCanonicalize (H12AffineFastState.compose env12875 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound12875 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,77898,272512,73754,95497,8328,64,121943,115150,17664,360926,119042,329731,257,41460,16465,63189]

theorem envBound12876 : H12AffineFastState.Bounded env12876 := by
  intro p hp
  have h : env12876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12875_12876 : H12AffineEnvironment.transform 20 77898 env12875 = env12876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env12875 == env12876) = true)

def env12877 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,77850,272512,73754,95497,8328,16,121863,115102,17664,360846,119042,329731,257,41380,16385,63109]

theorem envBound12877 : H12AffineFastState.Bounded env12877 := by
  intro p hp
  have h : env12877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12876_12877 : H12AffineEnvironment.transform 5 16 env12876 = env12877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12876 == env12877) = true)

theorem identity12877 : scanCanonicalize (H12AffineFastState.compose env12877 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound12877 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env12878 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,100386,1025,32769,77850,106658,73754,95497,8328,16,121863,115102,17664,2476,119042,32801,257,41380,16385,63109]

theorem envBound12878 : H12AffineFastState.Bounded env12878 := by
  intro p hp
  have h : env12878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12877_12878 : H12AffineEnvironment.transform 17 100386 env12877 = env12878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env12877 == env12878) = true)

theorem identity12878 : scanCanonicalize (H12AffineFastState.compose env12878 (packedSelected [0,4,5,7,8,17,19,22,24,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12878 : packedSelected [0,4,5,7,8,17,19,22,24,28,31] rootPS < 2^1333 := by decide +kernel

def env12879 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,24980,76079,1025,8460,77850,65967,73754,95497,8328,16,97546,90259,17664,2476,94223,8492,257,169,16385,22408]

theorem envBound12879 : H12AffineFastState.Bounded env12879 := by
  intro p hp
  have h : env12879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12878_12879 : H12AffineEnvironment.transform 14 8461 env12878 = env12879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12878 == env12879) = true)

theorem identity12879 : scanCanonicalize (H12AffineFastState.compose env12879 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound12879 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env12880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,29963,24980,23588,1025,8460,17681,29860,21777,2,8328,16,2049,5528,17664,2476,1284,8492,257,169,16385,22408]

theorem envBound12880 : H12AffineFastState.Bounded env12880 := by
  intro p hp
  have h : env12880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12879_12880 : H12AffineEnvironment.transform 15 29963 env12879 = env12880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env12879 == env12880) = true)

theorem identity12880 : scanCanonicalize (H12AffineFastState.compose env12880 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound12880 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env12881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,8461,398,5393,10401,1025,8460,12692,33,8596,2,8328,16,2049,5528,12677,2476,1284,8492,257,169,13444,8973]

theorem envBound12881 : H12AffineFastState.Bounded env12881 := by
  intro p hp
  have h : env12881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12880_12881 : H12AffineEnvironment.transform 13 13445 env12880 = env12881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env12880 == env12881) = true)

theorem identity12881 : scanCanonicalize (H12AffineFastState.compose env12881 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12881 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12882 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,1,398,5393,2477,1025,0,4248,33,152,2,388,16,2049,5528,4233,2476,1284,32,257,169,5512,513]

theorem envBound12882 : H12AffineFastState.Bounded env12882 := by
  intro p hp
  have h : env12882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12881_12882 : H12AffineEnvironment.transform 12 268 env12881 = env12882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12881 == env12882) = true)

theorem identity12882 : scanCanonicalize (H12AffineFastState.compose env12882 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12882 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12883 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,40,5293,1,170,5173,2185,1025,0,4248,33,152,2,160,16,2049,5308,4233,2184,1056,32,37,169,5292,513]

theorem envBound12883 : H12AffineFastState.Bounded env12883 := by
  intro p hp
  have h : env12883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12882_12883 : H12AffineEnvironment.transform 7 36 env12882 = env12883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12882 == env12883) = true)

def env12884 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,77851,272512,73754,95497,8328,17,121862,115103,17664,360847,119042,329731,257,41381,16384,63108]

theorem envBound12884 : H12AffineFastState.Bounded env12884 := by
  intro p hp
  have h : env12884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12876_12884 : H12AffineEnvironment.transform 5 17 env12876 = env12884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12876 == env12884) = true)

theorem identity12884 : scanCanonicalize (H12AffineFastState.compose env12884 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound12884 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env12885 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,2340,1025,32769,77851,8612,73754,95497,8328,17,121862,115103,17664,100523,119042,65831,257,41381,16384,63108]

theorem envBound12885 : H12AffineFastState.Bounded env12885 := by
  intro p hp
  have h : env12885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12884_12885 : H12AffineEnvironment.transform 17 2340 env12884 = env12885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env12884 == env12885) = true)

theorem identity12885 : scanCanonicalize (H12AffineFastState.compose env12885 (packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound12885 : packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env12886 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,65536,24981,2340,1025,29709,77851,8612,73754,95497,8328,17,75786,79251,17664,97447,75022,65831,257,21929,16384,648]

theorem envBound12886 : H12AffineFastState.Bounded env12886 := by
  intro p hp
  have h : env12886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12885_12886 : H12AffineEnvironment.transform 14 29708 env12885 = env12886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env12885 == env12886) = true)

theorem identity12886 : scanCanonicalize (H12AffineFastState.compose env12886 (packedSelected [1,8,12,15,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12886 : packedSelected [1,8,12,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env12887 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8322,24981,2340,1025,29709,4249,8612,152,21899,8328,17,2184,5393,17664,23589,1420,8613,257,21929,16384,648]

theorem envBound12887 : H12AffineFastState.Bounded env12887 := by
  intro p hp
  have h : env12887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12886_12887 : H12AffineEnvironment.transform 15 8322 env12886 = env12887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12886 == env12887) = true)

theorem identity12887 : scanCanonicalize (H12AffineFastState.compose env12887 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12887 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12888 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21760,398,16537,2340,1025,21761,4249,168,152,21899,388,17,2184,5393,17664,23589,1420,169,257,21929,16384,648]

theorem envBound12888 : H12AffineFastState.Bounded env12888 := by
  intro p hp
  have h : env12888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12887_12888 : H12AffineEnvironment.transform 12 268 env12887 = env12888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12887 == env12888) = true)

theorem identity12888 : scanCanonicalize (H12AffineFastState.compose env12888 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12888 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12889 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,263,16400,2340,1025,21761,4112,33,17,21762,269,17,2049,5393,17664,23589,1285,32,257,21792,16384,513]

theorem envBound12889 : H12AffineFastState.Bounded env12889 := by
  intro p hp
  have h : env12889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12888_12889 : H12AffineEnvironment.transform 6 9 env12888 = env12889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12888 == env12889) = true)

theorem identity12889 : scanCanonicalize (H12AffineFastState.compose env12889 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12889 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12890 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1025,0,4112,33,17,3,269,17,2049,5393,4097,2340,1285,32,257,33,5377,513]

theorem envBound12890 : H12AffineFastState.Bounded env12890 := by
  intro p hp
  have h : env12890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12889_12890 : H12AffineEnvironment.transform 13 5377 env12889 = env12890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12889 == env12890) = true)

theorem identity12890 : scanCanonicalize (H12AffineFastState.compose env12890 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound12890 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12891 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,4096,268,4357,1,263,4373,2340,5,0,4112,33,17,3,269,17,2049,4373,4097,2340,257,32,257,33,4357,513]

theorem envBound12891 : H12AffineFastState.Bounded env12891 := by
  intro p hp
  have h : env12891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12890_12891 : H12AffineEnvironment.transform 9 4 env12890 = env12891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env12890 == env12891) = true)

theorem identity12891 : scanCanonicalize (H12AffineFastState.compose env12891 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2318) := by decide +kernel

theorem selectedBound12891 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12892 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,2318,268,2059,1,263,2075,2340,5,0,2334,33,17,3,269,17,2049,2075,2319,2340,257,32,257,33,2059,513]

theorem envBound12892 : H12AffineFastState.Bounded env12892 := by
  intro p hp
  have h : env12892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12891_12892 : H12AffineEnvironment.transform 11 2318 env12891 = env12892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2318 env12891 == env12892) = true)

theorem identity12892 : scanCanonicalize (H12AffineFastState.compose env12892 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound12892 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12893 : List Nat := [2,4,8,16,32,17,9,256,512,4,783,513,268,772,1,263,788,555,5,0,529,33,17,3,269,17,782,788,512,555,257,32,257,33,772,513]

theorem envBound12893 : H12AffineFastState.Bounded env12893 := by
  intro p hp
  have h : env12893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12892_12893 : H12AffineEnvironment.transform 10 783 env12892 = env12893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env12892 == env12893) = true)

theorem identity12893 : scanCanonicalize (H12AffineFastState.compose env12893 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12893 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12894 : List Nat := [2,4,8,16,32,17,9,37,512,4,554,513,41,545,1,34,561,555,5,0,529,33,17,3,40,17,555,561,512,555,36,32,36,33,545,513]

theorem envBound12894 : H12AffineFastState.Bounded env12894 := by
  intro p hp
  have h : env12894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12893_12894 : H12AffineEnvironment.transform 7 37 env12893 = env12894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12893 == env12894) = true)

theorem identity12894 : scanCanonicalize (H12AffineFastState.compose env12894 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12894 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12895 : List Nat := [2,4,8,10,32,11,9,37,512,4,554,513,41,545,1,34,555,555,5,0,523,33,11,3,40,11,555,555,512,555,36,32,36,33,545,513]

theorem envBound12895 : H12AffineFastState.Bounded env12895 := by
  intro p hp
  have h : env12895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12894_12895 : H12AffineEnvironment.transform 3 10 env12894 = env12895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12894 == env12895) = true)

theorem identity12895 : scanCanonicalize (H12AffineFastState.compose env12895 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound12895 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12896 : List Nat := [2,4,4,6,32,7,5,37,512,4,550,513,37,545,1,34,551,551,5,0,519,33,7,3,36,7,551,551,512,551,36,32,36,33,545,513]

theorem envBound12896 : H12AffineFastState.Bounded env12896 := by
  intro p hp
  have h : env12896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12895_12896 : H12AffineEnvironment.transform 2 4 env12895 = env12896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env12895 == env12896) = true)

theorem identity12896 : scanCanonicalize (H12AffineFastState.compose env12896 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12896 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env12897 : List Nat := [2,4,4,6,1,7,5,4,512,4,519,513,4,512,1,3,518,518,5,0,519,0,7,3,5,7,518,518,512,518,5,1,5,0,512,513]

theorem envBound12897 : H12AffineFastState.Bounded env12897 := by
  intro p hp
  have h : env12897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12896_12897 : H12AffineEnvironment.transform 4 1 env12896 = env12897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12896 == env12897) = true)

def env12898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,121942,115150,17664,2404756,119042,329730,257,2199998,2191387,63189]

theorem envBound12898 : H12AffineFastState.Bounded env12898 := by
  intro p hp
  have h : env12898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12874_12898 : H12AffineEnvironment.transform 21 272513 env12874 = env12898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12874 == env12898) = true)

theorem identity12898 : scanCanonicalize (H12AffineFastState.compose env12898 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12898 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,64605,57797,17664,2404756,61705,272393,257,2142645,2117648,63189]

theorem envBound12899 : H12AffineFastState.Bounded env12899 := by
  intro p hp
  have h : env12899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12898_12899 : H12AffineEnvironment.transform 15 8203 env12898 = env12899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12898 == env12899) = true)

def env12900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24908,262144,1025,32769,2097152,272393,2101328,2114883,8192,64,64605,57677,17664,2404636,61705,272393,257,2142525,2117648,63069]

theorem envBound12900 : H12AffineFastState.Bounded env12900 := by
  intro p hp
  have h : env12900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12899_12900 : H12AffineEnvironment.transform 6 8 env12899 = env12900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12899 == env12900) = true)

theorem identity12900 : scanCanonicalize (H12AffineFastState.compose env12900 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound12900 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env12901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21620,8203,24908,262144,1025,21621,2097152,272393,2101328,2114883,8192,64,10281,13625,17664,2385256,9597,272393,257,2123081,2117648,8745]

theorem envBound12901 : H12AffineFastState.Bounded env12901 := by
  intro p hp
  have h : env12901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12900_12901 : H12AffineEnvironment.transform 14 21620 env12900 = env12901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env12900 == env12901) = true)

theorem identity12901 : scanCanonicalize (H12AffineFastState.compose env12901 (packedSelected [0,1,2,4,11,16,18,19,22,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound12901 : packedSelected [0,1,2,4,11,16,18,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8541,8203,5221,262144,1025,8540,2097152,272393,2101328,2109546,8192,64,10281,13625,12329,2363457,9597,272393,257,2101344,2106681,8745]

theorem envBound12902 : H12AffineFastState.Bounded env12902 := by
  intro p hp
  have h : env12902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12901_12902 : H12AffineEnvironment.transform 13 13609 env12901 = env12902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env12901 == env12902) = true)

theorem identity12902 : scanCanonicalize (H12AffineFastState.compose env12902 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12902 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env12903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,1,343,5221,262144,1025,0,2097152,264533,2101328,2101558,348,64,2421,5221,4469,2363457,1057,264533,257,2101344,2098277,885]

theorem envBound12903 : H12AffineFastState.Bounded env12903 := by
  intro p hp
  have h : env12903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12902_12903 : H12AffineEnvironment.transform 12 348 env12902 = env12903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12902 == env12903) = true)

theorem identity12903 : scanCanonicalize (H12AffineFastState.compose env12903 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound12903 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env12904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,1,343,5221,262144,1025,0,4405,264533,357,3,348,64,2421,5221,4469,262516,1057,264533,257,341,5456,885]

theorem envBound12904 : H12AffineFastState.Bounded env12904 := by
  intro p hp
  have h : env12904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12903_12904 : H12AffineEnvironment.transform 20 4405 env12903 = env12904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env12903 == env12904) = true)

theorem identity12904 : scanCanonicalize (H12AffineFastState.compose env12904 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound12904 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env12905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3173,348,2064,1,343,2048,262144,1025,0,3408,264533,357,3,348,64,2421,2048,3344,262516,1057,264533,257,341,2357,885]

theorem envBound12905 : H12AffineFastState.Bounded env12905 := by
  intro p hp
  have h : env12905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12904_12905 : H12AffineEnvironment.transform 11 3173 env12904 = env12905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env12904 == env12905) = true)

theorem identity12905 : scanCanonicalize (H12AffineFastState.compose env12905 (packedSelected [1,8,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2064) := by decide +kernel

theorem selectedBound12905 : packedSelected [1,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3173,348,2064,1,343,2048,2064,1025,0,3408,325,357,3,348,64,2421,2048,3344,2404,1057,325,257,341,2357,885]

theorem envBound12906 : H12AffineFastState.Bounded env12906 := by
  intro p hp
  have h : env12906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12905_12906 : H12AffineEnvironment.transform 17 2064 env12905 = env12906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2064 env12905 == env12906) = true)

theorem identity12906 : scanCanonicalize (H12AffineFastState.compose env12906 (packedSelected [0,1,2,3,5,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound12906 : packedSelected [0,1,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12907 : List Nat := [2,4,8,16,32,64,8,256,512,117,2048,2064,348,2064,1,343,2048,2064,116,0,2341,325,357,3,348,64,2421,2048,2405,2404,84,325,257,341,2357,885]

theorem envBound12907 : H12AffineFastState.Bounded env12907 := by
  intro p hp
  have h : env12907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12906_12907 : H12AffineEnvironment.transform 9 117 env12906 = env12907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env12906 == env12907) = true)

theorem identity12907 : scanCanonicalize (H12AffineFastState.compose env12907 (packedSelected [1,2,4,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound12907 : packedSelected [1,2,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12908 : List Nat := [2,4,8,16,32,64,8,101,512,117,2048,2064,57,2064,1,50,2048,2064,116,0,2112,32,0,3,57,64,2064,2048,2048,2049,84,32,100,48,2128,528]

theorem envBound12908 : H12AffineFastState.Bounded env12908 := by
  intro p hp
  have h : env12908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12907_12908 : H12AffineEnvironment.transform 7 101 env12907 = env12908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env12907 == env12908) = true)

def env12909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,2097152,272392,2101328,2114883,8193,64,64605,57676,17664,2404637,61705,272393,257,2142524,2117648,63068]

theorem envBound12909 : H12AffineFastState.Bounded env12909 := by
  intro p hp
  have h : env12909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12899_12909 : H12AffineEnvironment.transform 6 9 env12899 = env12909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12899 == env12909) = true)

theorem identity12909 : scanCanonicalize (H12AffineFastState.compose env12909 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(20+1) ^^^ 314421) := by decide +kernel

theorem selectedBound12909 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env12910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,314421,272392,318565,297334,8193,64,64605,57676,17664,32040,61705,272393,257,294153,302117,63068]

theorem envBound12910 : H12AffineFastState.Bounded env12910 := by
  intro p hp
  have h : env12910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12909_12910 : H12AffineEnvironment.transform 20 314421 env12909 = env12910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314421 env12909 == env12910) = true)

theorem identity12910 : scanCanonicalize (H12AffineFastState.compose env12910 (packedSelected [0,3,5,8,9,10,16,17,20,22,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound12910 : packedSelected [0,3,5,8,9,10,16,17,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,32041,1025,32769,45340,21793,41292,62559,8193,64,64605,57676,17664,32040,61705,21792,257,32,57612,63068]

theorem envBound12911 : H12AffineFastState.Bounded env12911 := by
  intro p hp
  have h : env12911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12910_12911 : H12AffineEnvironment.transform 17 32041 env12910 = env12911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env12910 == env12911) = true)

theorem identity12911 : scanCanonicalize (H12AffineFastState.compose env12911 (packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12911 : packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8203,5392,2420,1025,32769,45340,8572,41292,32770,8193,64,34816,38161,12637,2421,34132,8573,257,32,38225,33281]

theorem envBound12912 : H12AffineFastState.Bounded env12912 := by
  intro p hp
  have h : env12912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12911_12912 : H12AffineEnvironment.transform 13 13405 env12911 = env12912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12911 == env12912) = true)

theorem identity12912 : scanCanonicalize (H12AffineFastState.compose env12912 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12912 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,5392,2420,1025,1,12572,8572,8524,2,8193,64,2048,5393,12637,2421,1364,8573,257,32,5457,513]

theorem envBound12913 : H12AffineFastState.Bounded env12913 := by
  intro p hp
  have h : env12913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12912_12913 : H12AffineEnvironment.transform 14 0 env12912 = env12913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12912 == env12913) = true)

theorem identity12913 : scanCanonicalize (H12AffineFastState.compose env12913 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 6185) := by decide +kernel

theorem selectedBound12913 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env12914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6185,3188,0,6178,5392,2420,1025,1,2357,6485,6501,2,6184,64,2048,5393,2420,2421,1364,6484,257,32,5457,513]

theorem envBound12914 : H12AffineFastState.Bounded env12914 := by
  intro p hp
  have h : env12914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12913_12914 : H12AffineEnvironment.transform 12 6185 env12913 = env12914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6185 env12913 == env12914) = true)

def env12915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4584662,115150,17665,2404757,119043,4268163,257,2199999,2191386,63188]

theorem envBound12915 : H12AffineFastState.Bounded env12915 := by
  intro p hp
  have h : env12915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12873_12915 : H12AffineEnvironment.transform 22 2101329 env12873 = env12915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env12873 == env12915) = true)

def env12916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,121942,115150,17665,2404757,119043,329731,257,2199999,2191386,63188]

theorem envBound12916 : H12AffineFastState.Bounded env12916 := by
  intro p hp
  have h : env12916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12915_12916 : H12AffineEnvironment.transform 21 272512 env12915 = env12916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12915 == env12916) = true)

theorem identity12916 : scanCanonicalize (H12AffineFastState.compose env12916 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound12916 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,115870,272512,120015,98781,8328,64,121942,115150,17665,357643,119043,329731,257,21793,46212,63188]

theorem envBound12917 : H12AffineFastState.Bounded env12917 := by
  intro p hp
  have h : env12917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12916_12917 : H12AffineEnvironment.transform 20 115870 env12916 = env12917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env12916 == env12917) = true)

def env12918 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,115870,272512,119967,98701,8328,16,121862,115102,17665,357643,119043,329731,257,21793,46212,63108]

theorem envBound12918 : H12AffineFastState.Bounded env12918 := by
  intro p hp
  have h : env12918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12917_12918 : H12AffineEnvironment.transform 5 16 env12917 = env12918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12917 == env12918) = true)

theorem identity12918 : scanCanonicalize (H12AffineFastState.compose env12918 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound12918 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12919 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,23589,1025,32769,115870,29861,119967,98701,8328,16,121862,115102,17665,76078,119043,87078,257,21793,46212,63108]

theorem envBound12919 : H12AffineFastState.Bounded env12919 := by
  intro p hp
  have h : env12919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12918_12919 : H12AffineEnvironment.transform 17 23589 env12918 = env12919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env12918 == env12919) = true)

theorem identity12919 : scanCanonicalize (H12AffineFastState.compose env12919 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound12919 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env12920 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,65536,24980,23589,1025,21896,69911,29861,65814,87044,8328,16,67983,70679,17665,76078,66698,87078,257,21793,24845,8973]

theorem envBound12920 : H12AffineFastState.Bounded env12920 := by
  intro p hp
  have h : env12920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12919_12920 : H12AffineEnvironment.transform 14 21897 env12919 = env12920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env12919 == env12920) = true)

theorem identity12920 : scanCanonicalize (H12AffineFastState.compose env12920 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound12920 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12921 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,29962,24980,23589,1025,21896,25629,29861,29724,8462,8328,16,31877,24861,17665,23588,29056,8492,257,21793,24845,8973]

theorem envBound12921 : H12AffineFastState.Bounded env12921 := by
  intro p hp
  have h : env12921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12920_12921 : H12AffineEnvironment.transform 15 29962 env12920 = env12921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env12920 == env12921) = true)

theorem identity12921 : scanCanonicalize (H12AffineFastState.compose env12921 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12921 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12922 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21897,21510,16536,23589,1025,21896,17681,21929,21776,2,388,16,23945,16401,17665,23588,20620,32,257,21793,16385,513]

theorem envBound12922 : H12AffineFastState.Bounded env12922 := by
  intro p hp
  have h : env12922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12921_12922 : H12AffineEnvironment.transform 12 268 env12921 = env12922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12921 == env12922) = true)

theorem identity12922 : scanCanonicalize (H12AffineFastState.compose env12922 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound12922 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12923 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,0,399,5393,2476,1025,1,4248,32,153,2,388,16,2048,5528,4232,2477,1285,32,257,168,5512,513]

theorem envBound12923 : H12AffineFastState.Bounded env12923 := by
  intro p hp
  have h : env12923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12922_12923 : H12AffineEnvironment.transform 13 5513 env12922 = env12923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env12922 == env12923) = true)

theorem identity12923 : scanCanonicalize (H12AffineFastState.compose env12923 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3239) := by decide +kernel

theorem selectedBound12923 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12924 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3239,268,2350,0,399,2486,2476,1025,1,3135,32,153,2,388,16,2048,2367,3119,2477,1285,32,257,168,2351,513]

theorem envBound12924 : H12AffineFastState.Bounded env12924 := by
  intro p hp
  have h : env12924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12923_12924 : H12AffineEnvironment.transform 11 3239 env12923 = env12924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3239 env12923 == env12924) = true)

theorem identity12924 : scanCanonicalize (H12AffineFastState.compose env12924 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12924 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12925 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3119,268,2350,0,263,2366,2340,1025,1,3135,32,17,2,268,16,2048,2367,3119,2341,1285,32,257,32,2351,513]

theorem envBound12925 : H12AffineFastState.Bounded env12925 := by
  intro p hp
  have h : env12925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12924_12925 : H12AffineEnvironment.transform 6 8 env12924 = env12925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12924 == env12925) = true)

theorem identity12925 : scanCanonicalize (H12AffineFastState.compose env12925 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound12925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12926 : List Nat := [2,4,8,16,17,16,8,256,512,1024,2048,3102,268,2335,0,263,2319,2325,1025,1,3086,17,17,2,268,16,2048,2318,3102,2324,1285,17,257,17,2334,513]

theorem envBound12926 : H12AffineFastState.Bounded env12926 := by
  intro p hp
  have h : env12926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12925_12926 : H12AffineEnvironment.transform 4 17 env12925 = env12926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env12925 == env12926) = true)

theorem identity12926 : scanCanonicalize (H12AffineFastState.compose env12926 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound12926 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12927 : List Nat := [2,4,8,16,17,16,8,256,512,1024,1556,522,268,1803,0,263,1819,1793,1025,1,538,17,17,2,268,16,1556,1818,522,1792,1285,17,257,17,1802,513]

theorem envBound12927 : H12AffineFastState.Bounded env12927 := by
  intro p hp
  have h : env12927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12926_12927 : H12AffineEnvironment.transform 10 1556 env12926 = env12927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env12926 == env12927) = true)

theorem identity12927 : scanCanonicalize (H12AffineFastState.compose env12927 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound12927 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12928 : List Nat := [2,4,8,16,17,16,8,31,512,1024,1556,522,19,1556,0,24,1540,1566,1025,1,538,17,17,2,19,16,1556,1541,522,1567,1050,17,30,17,1557,513]

theorem envBound12928 : H12AffineFastState.Bounded env12928 := by
  intro p hp
  have h : env12928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12927_12928 : H12AffineEnvironment.transform 7 31 env12927 = env12928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env12927 == env12928) = true)

theorem identity12928 : scanCanonicalize (H12AffineFastState.compose env12928 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound12928 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12929 : List Nat := [2,4,8,11,10,11,8,4,512,1024,1551,522,8,1551,0,3,1540,1541,1025,1,513,10,10,2,8,11,1551,1541,522,1540,1025,10,5,10,1550,513]

theorem envBound12929 : H12AffineFastState.Bounded env12929 := by
  intro p hp
  have h : env12929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12928_12929 : H12AffineEnvironment.transform 3 11 env12928 = env12929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env12928 == env12929) = true)

theorem identity12929 : scanCanonicalize (H12AffineFastState.compose env12929 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12929 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12930 : List Nat := [2,4,2,1,0,1,2,4,512,1024,1541,512,2,1541,0,3,1540,1541,1025,1,513,0,0,2,2,1,1541,1541,512,1540,1025,0,5,0,1540,513]

theorem envBound12930 : H12AffineFastState.Bounded env12930 := by
  intro p hp
  have h : env12930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12929_12930 : H12AffineEnvironment.transform 2 2 env12929 = env12930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12929 == env12930) = true)

theorem identity12930 : scanCanonicalize (H12AffineFastState.compose env12930 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound12930 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12931 : List Nat := [2,4,2,1,0,1,2,4,512,2,519,512,2,519,0,3,518,519,3,1,513,0,0,2,2,1,519,519,512,518,3,0,5,0,518,513]

theorem envBound12931 : H12AffineFastState.Bounded env12931 := by
  intro p hp
  have h : env12931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12930_12931 : H12AffineEnvironment.transform 9 2 env12930 = env12931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env12930 == env12931) = true)

theorem identity12931 : scanCanonicalize (H12AffineFastState.compose env12931 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound12931 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12932 : List Nat := [2,4,2,1,0,1,2,4,7,2,0,7,2,0,0,3,1,0,3,1,6,0,0,2,2,1,0,0,7,1,3,0,5,0,1,6]

theorem envBound12932 : H12AffineFastState.Bounded env12932 := by
  intro p hp
  have h : env12932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12931_12932 : H12AffineEnvironment.transform 8 7 env12931 = env12932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env12931 == env12932) = true)

theorem identity12932 : scanCanonicalize (H12AffineFastState.compose env12932 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound12932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12933 : List Nat := [1,4,1,1,0,1,1,4,4,1,0,4,1,0,0,0,1,0,0,1,5,0,0,1,1,1,0,0,4,1,0,0,5,0,1,5]

theorem envBound12933 : H12AffineFastState.Bounded env12933 := by
  intro p hp
  have h : env12933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12932_12933 : H12AffineEnvironment.transform 0 1 env12932 = env12933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env12932 == env12933) = true)

theorem identity12933 : scanCanonicalize (H12AffineFastState.compose env12933 (packedSelected [14] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound12933 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12934 : List Nat := [1,0,1,1,0,1,1,0,0,1,0,0,1,0,0,0,1,0,0,1,1,0,0,1,1,1,0,0,0,1,0,0,1,0,1,1]

theorem envBound12934 : H12AffineFastState.Bounded env12934 := by
  intro p hp
  have h : env12934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12933_12934 : H12AffineEnvironment.transform 1 0 env12933 = env12934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env12933 == env12934) = true)

def env12935 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,115870,272512,119966,98700,8328,17,121863,115103,17665,357643,119043,329731,257,21793,46212,63109]

theorem envBound12935 : H12AffineFastState.Bounded env12935 := by
  intro p hp
  have h : env12935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12917_12935 : H12AffineEnvironment.transform 5 17 env12917 = env12935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12917 == env12935) = true)

theorem identity12935 : scanCanonicalize (H12AffineFastState.compose env12935 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound12935 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env12936 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,2477,1025,32769,115870,8493,119966,98700,8328,17,121863,115103,17665,97446,119043,65966,257,21793,46212,63109]

theorem envBound12936 : H12AffineFastState.Bounded env12936 := by
  intro p hp
  have h : env12936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12935_12936 : H12AffineEnvironment.transform 17 2477 env12935 = env12936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env12935 == env12936) = true)

theorem identity12936 : scanCanonicalize (H12AffineFastState.compose env12936 (packedSelected [0,3,9,10,17,19,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound12936 : packedSelected [0,3,9,10,17,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env12937 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,65536,24981,2477,1025,29708,77971,8493,73875,95617,8328,17,75786,79250,17665,97446,75022,65966,257,21793,16521,648]

theorem envBound12937 : H12AffineFastState.Bounded env12937 := by
  intro p hp
  have h : env12937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12936_12937 : H12AffineEnvironment.transform 14 29709 env12936 = env12937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env12936 == env12937) = true)

theorem identity12937 : scanCanonicalize (H12AffineFastState.compose env12937 (packedSelected [1,2,3,4,5,6,8,10,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12937 : packedSelected [1,2,3,4,5,6,8,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env12938 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,24860,2340,1025,29708,77850,8493,73754,95496,8193,17,75786,79131,17665,97327,75022,65831,257,21793,16384,513]

theorem envBound12938 : H12AffineFastState.Bounded env12938 := by
  intro p hp
  have h : env12938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12937_12938 : H12AffineEnvironment.transform 6 9 env12937 = env12938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12937 == env12938) = true)

theorem identity12938 : scanCanonicalize (H12AffineFastState.compose env12938 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12938 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env12939 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,65536,16400,2340,1025,21760,69910,33,65814,87044,269,17,67846,70679,17665,89379,66562,65831,257,21793,16384,513]

theorem envBound12939 : H12AffineFastState.Bounded env12939 := by
  intro p hp
  have h : env12939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12938_12939 : H12AffineEnvironment.transform 12 268 env12938 = env12939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12938 == env12939) = true)

theorem identity12939 : scanCanonicalize (H12AffineFastState.compose env12939 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound12939 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12940 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,21511,16400,2340,1025,21760,17681,33,21777,3,269,17,23809,16400,17665,2340,20485,21792,257,21793,16384,513]

theorem envBound12940 : H12AffineFastState.Bounded env12940 := by
  intro p hp
  have h : env12940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12939_12940 : H12AffineEnvironment.transform 15 21511 env12939 = env12940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env12939 == env12940) = true)

theorem identity12940 : scanCanonicalize (H12AffineFastState.compose env12940 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12940 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12941 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2340,1025,0,4113,33,17,3,269,17,2049,5392,4097,2340,1285,32,257,33,5376,513]

theorem envBound12941 : H12AffineFastState.Bounded env12941 := by
  intro p hp
  have h : env12941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12940_12941 : H12AffineEnvironment.transform 13 5376 env12940 = env12941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12940 == env12941) = true)

theorem identity12941 : scanCanonicalize (H12AffineFastState.compose env12941 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound12941 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12942 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,4096,268,4356,1,263,4372,2340,5,0,4113,33,17,3,269,17,2049,4372,4097,2340,257,32,257,33,4356,513]

theorem envBound12942 : H12AffineFastState.Bounded env12942 := by
  intro p hp
  have h : env12942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12941_12942 : H12AffineEnvironment.transform 9 4 env12941 = env12942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env12941 == env12942) = true)

theorem identity12942 : scanCanonicalize (H12AffineFastState.compose env12942 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2319) := by decide +kernel

theorem selectedBound12942 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12943 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,2319,268,2059,1,263,2075,2340,5,0,2334,33,17,3,269,17,2049,2075,2318,2340,257,32,257,33,2059,513]

theorem envBound12943 : H12AffineFastState.Bounded env12943 := by
  intro p hp
  have h : env12943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12942_12943 : H12AffineEnvironment.transform 11 2319 env12942 = env12943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2319 env12942 == env12943) = true)

theorem identity12943 : scanCanonicalize (H12AffineFastState.compose env12943 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound12943 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12944 : List Nat := [2,4,8,16,32,17,9,256,512,4,782,513,268,773,1,263,789,554,5,0,528,33,17,3,269,17,783,789,512,554,257,32,257,33,773,513]

theorem envBound12944 : H12AffineFastState.Bounded env12944 := by
  intro p hp
  have h : env12944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12943_12944 : H12AffineEnvironment.transform 10 782 env12943 = env12944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env12943 == env12944) = true)

theorem identity12944 : scanCanonicalize (H12AffineFastState.compose env12944 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12944 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12945 : List Nat := [2,4,8,16,32,17,9,37,512,4,555,513,41,544,1,34,560,554,5,0,528,33,17,3,40,17,554,560,512,554,36,32,36,33,544,513]

theorem envBound12945 : H12AffineFastState.Bounded env12945 := by
  intro p hp
  have h : env12945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12944_12945 : H12AffineEnvironment.transform 7 37 env12944 = env12945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12944 == env12945) = true)

theorem identity12945 : scanCanonicalize (H12AffineFastState.compose env12945 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound12945 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12946 : List Nat := [2,4,8,11,32,10,9,37,512,4,555,513,41,544,1,34,555,554,5,0,523,33,10,3,40,10,554,555,512,554,36,32,36,33,544,513]

theorem envBound12946 : H12AffineFastState.Bounded env12946 := by
  intro p hp
  have h : env12946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12945_12946 : H12AffineEnvironment.transform 3 11 env12945 = env12946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env12945 == env12946) = true)

theorem identity12946 : scanCanonicalize (H12AffineFastState.compose env12946 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound12946 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12947 : List Nat := [2,3,8,11,32,10,9,34,512,3,555,513,41,544,1,34,555,554,2,0,523,33,10,3,40,10,554,555,512,554,35,32,35,33,544,513]

theorem envBound12947 : H12AffineFastState.Bounded env12947 := by
  intro p hp
  have h : env12947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12946_12947 : H12AffineEnvironment.transform 1 3 env12946 = env12947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env12946 == env12947) = true)

theorem identity12947 : scanCanonicalize (H12AffineFastState.compose env12947 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12947 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env12948 : List Nat := [2,3,8,11,0,10,9,2,512,3,523,513,9,512,1,2,523,522,2,0,523,1,10,3,8,10,522,523,512,522,3,0,3,1,512,513]

theorem envBound12948 : H12AffineFastState.Bounded env12948 := by
  intro p hp
  have h : env12948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12947_12948 : H12AffineEnvironment.transform 4 0 env12947 = env12948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12947 == env12948) = true)

def env12949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,121943,115150,17665,2404757,119043,329730,257,2199999,2191386,63188]

theorem envBound12949 : H12AffineFastState.Bounded env12949 := by
  intro p hp
  have h : env12949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12915_12949 : H12AffineEnvironment.transform 21 272513 env12915 = env12949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12915 == env12949) = true)

theorem identity12949 : scanCanonicalize (H12AffineFastState.compose env12949 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound12949 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,25028,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,2185,5392,17665,2404757,1501,318684,257,2114913,2139332,63188]

theorem envBound12950 : H12AffineFastState.Bounded env12950 := by
  intro p hp
  have h : env12950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12949_12950 : H12AffineEnvironment.transform 15 54494 env12949 = env12950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env12949 == env12950) = true)

theorem identity12950 : scanCanonicalize (H12AffineFastState.compose env12950 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound12950 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env12951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25028,262144,1025,29908,2097152,272513,2101329,2114883,8328,64,2185,5392,17665,2377024,1501,272393,257,2114913,2117649,513]

theorem envBound12951 : H12AffineFastState.Bounded env12951 := by
  intro p hp
  have h : env12951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12950_12951 : H12AffineEnvironment.transform 14 29909 env12950 = env12951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env12950 == env12951) = true)

theorem identity12951 : scanCanonicalize (H12AffineFastState.compose env12951 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound12951 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env12952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25028,262144,1025,29908,25629,272513,29772,8542,8328,64,2185,5392,17665,270685,1501,272393,257,8572,13324,513]

theorem envBound12952 : H12AffineFastState.Bounded env12952 := by
  intro p hp
  have h : env12952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12951_12952 : H12AffineEnvironment.transform 20 25629 env12951 = env12952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env12951 == env12952) = true)

theorem identity12952 : scanCanonicalize (H12AffineFastState.compose env12952 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 23805) := by decide +kernel

theorem selectedBound12952 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env12953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25028,23805,1025,29908,25629,29820,29772,8542,8328,64,2185,5392,17665,32160,1501,29940,257,8572,13324,513]

theorem envBound12953 : H12AffineFastState.Bounded env12953 := by
  intro p hp
  have h : env12953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12952_12953 : H12AffineEnvironment.transform 17 23805 env12952 = env12953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23805 env12952 == env12953) = true)

theorem identity12953 : scanCanonicalize (H12AffineFastState.compose env12953 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound12953 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env12954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,478,16401,23805,1025,21761,17864,21929,21913,139,349,64,2185,5392,17665,23669,1501,21793,257,169,5593,513]

theorem envBound12954 : H12AffineFastState.Bounded env12954 := by
  intro p hp
  have h : env12954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12953_12954 : H12AffineEnvironment.transform 12 469 env12953 = env12954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env12953 == env12954) = true)

theorem identity12954 : scanCanonicalize (H12AffineFastState.compose env12954 (packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound12954 : packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env12955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,136,478,5529,2421,1025,137,4160,33,17,139,349,64,2185,5392,4233,2557,1501,169,257,169,5593,513]

theorem envBound12955 : H12AffineFastState.Bounded env12955 := by
  intro p hp
  have h : env12955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12954_12955 : H12AffineEnvironment.transform 13 5512 env12954 = env12955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env12954 == env12955) = true)

def env12956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066247,115151,10507600,8692165,10600787,4268162,257,8487407,8478794,10544772]

theorem envBound12956 : H12AffineFastState.Bounded env12956 := by
  intro p hp
  have h : env12956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12872_12956 : H12AffineEnvironment.transform 16 25029 env12872 = env12956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env12872 == env12956) = true)

def env12957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4584663,115151,17664,2404757,119043,4268162,257,2199999,2191386,63188]

theorem envBound12957 : H12AffineFastState.Bounded env12957 := by
  intro p hp
  have h : env12957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12956_12957 : H12AffineEnvironment.transform 22 2101328 env12956 = env12957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env12956 == env12957) = true)

def env12958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,121943,115151,17664,2404757,119043,329730,257,2199999,2191386,63188]

theorem envBound12958 : H12AffineFastState.Bounded env12958 := by
  intro p hp
  have h : env12958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12957_12958 : H12AffineEnvironment.transform 21 272512 env12957 = env12958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12957 == env12958) = true)

theorem identity12958 : scanCanonicalize (H12AffineFastState.compose env12958 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound12958 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,262144,1025,29908,2097152,272512,2101328,2114882,8328,64,75906,79130,17664,2377024,75222,329730,257,2188650,2191386,513]

theorem envBound12959 : H12AffineFastState.Bounded env12959 := by
  intro p hp
  have h : env12959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12958_12959 : H12AffineEnvironment.transform 14 29909 env12958 = env12959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env12958 == env12959) = true)

def env12960 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,262144,1025,29828,2097152,272512,2101248,2114834,8328,16,75906,79130,17664,2376976,75142,329730,257,2188602,2191386,513]

theorem envBound12960 : H12AffineFastState.Bounded env12960 := by
  intro p hp
  have h : env12960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12959_12960 : H12AffineEnvironment.transform 5 16 env12959 = env12960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12959 == env12960) = true)

def env12961 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,24861,262144,1025,29708,2097152,272392,2101248,2114834,8192,16,75786,79130,17664,2376976,75022,329730,257,2188602,2191386,513]

theorem envBound12961 : H12AffineFastState.Bounded env12961 := by
  intro p hp
  have h : env12961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12960_12961 : H12AffineEnvironment.transform 6 8 env12960 = env12961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12960 == env12961) = true)

theorem identity12961 : scanCanonicalize (H12AffineFastState.compose env12961 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12961 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env12962 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,29709,65536,24633,262144,1025,29708,2097152,272392,2101248,2114614,8192,16,75786,78910,17444,2376756,74794,329730,37,2188318,2191386,513]

theorem envBound12962 : H12AffineFastState.Bounded env12962 := by
  intro p hp
  have h : env12962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12961_12962 : H12AffineEnvironment.transform 7 36 env12961 = env12962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12961 == env12962) = true)

theorem identity12962 : scanCanonicalize (H12AffineFastState.compose env12962 (packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound12962 : packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env12963 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,29709,35,24633,262144,1025,29708,2097152,272392,2101248,2114614,8192,16,10281,13341,17444,2376756,9225,264225,37,2122813,2125881,513]

theorem envBound12963 : H12AffineFastState.Bounded env12963 := by
  intro p hp
  have h : env12963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12962_12963 : H12AffineEnvironment.transform 15 35 env12962 = env12963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env12962 == env12963) = true)

theorem identity12963 : scanCanonicalize (H12AffineFastState.compose env12963 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 288808) := by decide +kernel

theorem selectedBound12963 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12964 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,29709,35,24633,262144,1025,29708,288808,272392,292904,273438,8192,16,10281,13341,17444,11292,9225,264225,37,265237,268305,513]

theorem envBound12964 : H12AffineFastState.Bounded env12964 := by
  intro p hp
  have h : env12964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12963_12964 : H12AffineEnvironment.transform 20 288808 env12963 = env12964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 288808 env12963 == env12964) = true)

theorem identity12964 : scanCanonicalize (H12AffineFastState.compose env12964 (packedSelected [3,5,10,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound12964 : packedSelected [3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env12965 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,16384,20497,35,17445,262144,1025,20496,281652,265236,285748,264194,1052,16,3125,4097,17444,2048,21,264225,37,265237,268305,513]

theorem envBound12965 : H12AffineFastState.Bounded env12965 := by
  intro p hp
  have h : env12965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12964_12965 : H12AffineEnvironment.transform 12 1052 env12964 = env12965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env12964 == env12965) = true)

theorem identity12965 : scanCanonicalize (H12AffineFastState.compose env12965 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 22544) := by decide +kernel

theorem selectedBound12965 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12966 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,16384,20497,35,17445,22544,1025,20496,5156,21508,1060,20498,1052,16,3125,4097,17444,2048,21,20529,37,21509,16385,513]

theorem envBound12966 : H12AffineFastState.Bounded env12966 := by
  intro p hp
  have h : env12966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12965_12966 : H12AffineEnvironment.transform 17 22544 env12965 = env12966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22544 env12965 == env12966) = true)

theorem identity12966 : scanCanonicalize (H12AffineFastState.compose env12966 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 7220) := by decide +kernel

theorem selectedBound12966 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env12967 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,7220,3109,35,6161,1060,1025,3108,5156,2096,1060,3110,1052,16,3125,4097,6160,2048,21,3077,37,2097,7221,513]

theorem envBound12967 : H12AffineFastState.Bounded env12967 := by
  intro p hp
  have h : env12967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12966_12967 : H12AffineEnvironment.transform 13 7220 env12966 = env12967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7220 env12966 == env12967) = true)

theorem identity12967 : scanCanonicalize (H12AffineFastState.compose env12967 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12967 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12968 : List Nat := [2,4,8,0,32,0,8,36,512,1024,2048,4096,1036,7204,3109,35,6145,1060,1025,3108,5156,2080,1060,3110,1036,0,3109,4097,6144,2048,5,3077,37,2081,7205,513]

theorem envBound12968 : H12AffineFastState.Bounded env12968 := by
  intro p hp
  have h : env12968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12967_12968 : H12AffineEnvironment.transform 3 0 env12967 = env12968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12967 == env12968) = true)

theorem identity12968 : scanCanonicalize (H12AffineFastState.compose env12968 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound12968 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12969 : List Nat := [2,4,8,0,32,0,8,36,512,1024,2048,3108,1036,0,3109,35,1061,1060,1025,3108,2048,2080,1060,3110,1036,0,3109,3109,1060,2048,5,3077,37,2081,1,513]

theorem envBound12969 : H12AffineFastState.Bounded env12969 := by
  intro p hp
  have h : env12969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12968_12969 : H12AffineEnvironment.transform 11 3108 env12968 = env12969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env12968 == env12969) = true)

theorem identity12969 : scanCanonicalize (H12AffineFastState.compose env12969 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound12969 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env12970 : List Nat := [2,4,8,0,32,0,8,36,512,1024,512,1572,1036,0,1573,35,1061,1060,1025,1572,512,544,1060,1574,1036,0,1573,1573,1060,512,5,1541,37,545,1,513]

theorem envBound12970 : H12AffineFastState.Bounded env12970 := by
  intro p hp
  have h : env12970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12969_12970 : H12AffineEnvironment.transform 10 512 env12969 = env12970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env12969 == env12970) = true)

def env12971 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24860,262144,1025,29709,2097152,272393,2101248,2114834,8193,16,75787,79130,17664,2376976,75023,329730,257,2188602,2191386,513]

theorem envBound12971 : H12AffineFastState.Bounded env12971 := by
  intro p hp
  have h : env12971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12960_12971 : H12AffineEnvironment.transform 6 9 env12960 = env12971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12960 == env12971) = true)

theorem identity12971 : scanCanonicalize (H12AffineFastState.compose env12971 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound12971 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env12972 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,29963,24860,262144,1025,29709,2097152,272393,2101248,2114834,8193,16,23808,16401,17664,2376976,20484,294153,257,2101297,2098449,513]

theorem envBound12972 : H12AffineFastState.Bounded env12972 := by
  intro p hp
  have h : env12972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12971_12972 : H12AffineEnvironment.transform 15 29963 env12971 = env12972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env12971 == env12972) = true)

theorem identity12972 : scanCanonicalize (H12AffineFastState.compose env12972 (packedSelected [0,3,4,5,7,9,10,12,14,15,17,18,23] rootPS)) = affineNative (2^(20+1) ^^^ 290104) := by decide +kernel

theorem selectedBound12972 : packedSelected [0,3,4,5,7,9,10,12,14,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env12973 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,29963,24860,262144,1025,29709,290104,272393,294200,272426,8193,16,23808,16401,17664,10280,20484,294153,257,294153,288809,513]

theorem envBound12973 : H12AffineFastState.Bounded env12973 := by
  intro p hp
  have h : env12973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12972_12973 : H12AffineEnvironment.transform 20 290104 env12972 = env12973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290104 env12972 == env12973) = true)

theorem identity12973 : scanCanonicalize (H12AffineFastState.compose env12973 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound12973 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12974 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,29963,24860,2341,1025,29709,25629,8492,29725,8463,8193,16,23808,16401,17664,10280,20484,29740,257,29740,24844,513]

theorem envBound12974 : H12AffineFastState.Bounded env12974 := by
  intro p hp
  have h : env12974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12973_12974 : H12AffineEnvironment.transform 17 2341 env12973 = env12974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env12973 == env12974) = true)

theorem identity12974 : scanCanonicalize (H12AffineFastState.compose env12974 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound12974 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12975 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,0,263,5392,2341,1025,1,4113,8492,17,8463,8193,16,10508,13341,12556,10280,9224,32,257,32,5376,513]

theorem envBound12975 : H12AffineFastState.Bounded env12975 := by
  intro p hp
  have h : env12975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12974_12975 : H12AffineEnvironment.transform 13 13324 env12974 = env12975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env12974 == env12975) = true)

def env12976 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,2097152,272512,2101249,2114835,8328,17,75906,79130,17664,2376977,75143,329730,257,2188603,2191386,513]

theorem envBound12976 : H12AffineFastState.Bounded env12976 := by
  intro p hp
  have h : env12976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12959_12976 : H12AffineEnvironment.transform 5 17 env12959 = env12976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12959 == env12976) = true)

theorem identity12976 : scanCanonicalize (H12AffineFastState.compose env12976 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12976 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env12977 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,10280,1025,29829,2097152,168,2101249,2114835,8328,17,75906,79130,17664,2125113,75143,73770,257,2188603,2191386,513]

theorem envBound12977 : H12AffineFastState.Bounded env12977 := by
  intro p hp
  have h : env12977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12976_12977 : H12AffineEnvironment.transform 17 10280 env12976 = env12977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12976 == env12977) = true)

theorem identity12977 : scanCanonicalize (H12AffineFastState.compose env12977 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound12977 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env12978 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21761,65536,16401,2477,1025,21760,2097152,168,2101249,2114835,269,17,67847,70815,17664,2116796,66562,65967,257,2180286,2183583,513]

theorem envBound12978 : H12AffineFastState.Bounded env12978 := by
  intro p hp
  have h : env12978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12977_12978 : H12AffineEnvironment.transform 12 389 env12977 = env12978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env12977 == env12978) = true)

theorem identity12978 : scanCanonicalize (H12AffineFastState.compose env12978 (packedSelected [2,6,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12978 : packedSelected [2,6,16,17,20] rootPS < 2^1333 := by decide +kernel

def env12979 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,65536,5393,2477,1025,0,2097152,168,2101249,2101267,269,17,67847,70815,4096,2103740,66562,65967,257,2167230,2163871,513]

theorem envBound12979 : H12AffineFastState.Bounded env12979 := by
  intro p hp
  have h : env12979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12978_12979 : H12AffineEnvironment.transform 13 5376 env12978 = env12979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12978 == env12979) = true)

theorem identity12979 : scanCanonicalize (H12AffineFastState.compose env12979 (packedSelected [2,6,17] rootPS)) = affineNative (2^(20+1) ^^^ 4249) := by decide +kernel

theorem selectedBound12979 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env12980 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,65536,5393,2477,1025,0,4249,168,152,138,269,17,67847,70815,4096,2341,66562,65967,257,65831,70662,513]

theorem envBound12980 : H12AffineFastState.Bounded env12980 := by
  intro p hp
  have h : env12980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12979_12980 : H12AffineEnvironment.transform 20 4249 env12979 = env12980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4249 env12979 == env12980) = true)

theorem identity12980 : scanCanonicalize (H12AffineFastState.compose env12980 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound12980 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,262,5393,2477,1025,0,4249,168,152,138,269,17,2049,5529,4096,2341,1284,169,257,33,5376,513]

theorem envBound12981 : H12AffineFastState.Bounded env12981 := by
  intro p hp
  have h : env12981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12980_12981 : H12AffineEnvironment.transform 15 262 env12980 = env12981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env12980 == env12981) = true)

theorem identity12981 : scanCanonicalize (H12AffineFastState.compose env12981 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound12981 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env12982 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2325,389,3093,1,262,3076,2477,1025,0,2444,168,152,138,269,17,2049,3212,2325,2341,1284,169,257,33,3093,513]

theorem envBound12982 : H12AffineFastState.Bounded env12982 := by
  intro p hp
  have h : env12982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12981_12982 : H12AffineEnvironment.transform 11 2325 env12981 = env12982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env12981 == env12982) = true)

theorem identity12982 : scanCanonicalize (H12AffineFastState.compose env12982 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12982 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env12983 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,2325,389,2081,1,262,2096,2477,53,0,2444,168,152,138,269,17,2049,2232,2325,2341,304,169,257,33,2081,513]

theorem envBound12983 : H12AffineFastState.Bounded env12983 := by
  intro p hp
  have h : env12983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12982_12983 : H12AffineEnvironment.transform 9 52 env12982 = env12983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12982 == env12983) = true)

def env12984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,121942,115151,17664,2404757,119043,329731,257,2199999,2191386,63188]

theorem envBound12984 : H12AffineFastState.Bounded env12984 := by
  intro p hp
  have h : env12984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12957_12984 : H12AffineEnvironment.transform 21 272513 env12957 = env12984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env12957 == env12984) = true)

theorem identity12984 : scanCanonicalize (H12AffineFastState.compose env12984 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound12984 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,58516,272513,62660,41430,8328,64,121942,115151,17664,283905,119043,329731,257,95531,103566,63188]

theorem envBound12985 : H12AffineFastState.Bounded env12985 := by
  intro p hp
  have h : env12985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12984_12985 : H12AffineEnvironment.transform 20 58516 env12984 = env12985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env12984 == env12985) = true)

def env12986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4584662,115151,17665,2404756,119042,4268162,257,2199998,2191387,63189]

theorem envBound12986 : H12AffineFastState.Bounded env12986 := by
  intro p hp
  have h : env12986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12956_12986 : H12AffineEnvironment.transform 22 2101329 env12956 = env12986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env12956 == env12986) = true)

def env12987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,121942,115151,17665,2404756,119042,329730,257,2199998,2191387,63189]

theorem envBound12987 : H12AffineFastState.Bounded env12987 := by
  intro p hp
  have h : env12987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12986_12987 : H12AffineEnvironment.transform 21 272512 env12986 = env12987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12986 == env12987) = true)

def env12988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,272392,2101329,2114882,8192,64,121942,115015,17665,2404636,119042,329730,257,2199862,2191387,63069]

theorem envBound12988 : H12AffineFastState.Bounded env12988 := by
  intro p hp
  have h : env12988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12987_12988 : H12AffineEnvironment.transform 6 8 env12987 = env12988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12987 == env12988) = true)

def env12989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,272392,17,21762,8192,64,121942,115015,17665,303452,119042,329730,257,98678,90203,63069]

theorem envBound12989 : H12AffineFastState.Bounded env12989 := by
  intro p hp
  have h : env12989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12988_12989 : H12AffineEnvironment.transform 20 4160 env12988 = env12989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12988 == env12989) = true)

theorem identity12989 : scanCanonicalize (H12AffineFastState.compose env12989 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound12989 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32040,1025,32769,4160,21792,17,21762,8192,64,121942,115015,17665,56436,119042,95530,257,98678,90203,63069]

theorem envBound12990 : H12AffineFastState.Bounded env12990 := by
  intro p hp
  have h : env12990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12989_12990 : H12AffineEnvironment.transform 17 32040 env12989 = env12990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env12989 == env12990) = true)

theorem identity12990 : scanCanonicalize (H12AffineFastState.compose env12990 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound12990 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,24909,32040,1025,32769,4160,21792,17,21762,8192,64,31836,24909,17665,56436,28936,54560,257,8572,49233,63069]

theorem envBound12991 : H12AffineFastState.Bounded env12991 := by
  intro p hp
  have h : env12991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12990_12991 : H12AffineEnvironment.transform 15 40970 env12990 = env12991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env12990 == env12991) = true)

theorem identity12991 : scanCanonicalize (H12AffineFastState.compose env12991 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12991 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env12992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,24909,32040,1025,8540,4160,21792,17,21762,8192,64,31836,24909,17665,32041,28936,29821,257,8572,24844,22272]

theorem envBound12992 : H12AffineFastState.Bounded env12992 := by
  intro p hp
  have h : env12992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12991_12992 : H12AffineEnvironment.transform 14 8541 env12991 = env12992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12991 == env12992) = true)

theorem identity12992 : scanCanonicalize (H12AffineFastState.compose env12992 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12992 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env12993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,343,5392,2421,1025,8540,4160,8573,17,8543,8192,64,2049,5392,12636,2420,1365,32,257,8572,5457,9053]

theorem envBound12993 : H12AffineFastState.Bounded env12993 := by
  intro p hp
  have h : env12993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12992_12993 : H12AffineEnvironment.transform 13 13405 env12992 = env12993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12992 == env12993) = true)

theorem identity12993 : scanCanonicalize (H12AffineFastState.compose env12993 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12993 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1025,1,4160,32,17,2,349,64,2049,5392,4097,2420,1365,32,257,33,5457,512]

theorem envBound12994 : H12AffineFastState.Bounded env12994 := by
  intro p hp
  have h : env12994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12993_12994 : H12AffineEnvironment.transform 12 349 env12993 = env12994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12993 == env12994) = true)

theorem identity12994 : scanCanonicalize (H12AffineFastState.compose env12994 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 862) := by decide +kernel

theorem selectedBound12994 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,862,4096,349,5376,0,343,5392,555,1025,1,4160,32,17,2,349,64,863,5392,4097,554,1365,32,257,33,5457,512]

theorem envBound12995 : H12AffineFastState.Bounded env12995 := by
  intro p hp
  have h : env12995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12994_12995 : H12AffineEnvironment.transform 10 862 env12994 = env12995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 862 env12994 == env12995) = true)

theorem identity12995 : scanCanonicalize (H12AffineFastState.compose env12995 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound12995 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12996 : List Nat := [2,4,8,16,32,49,8,256,512,1024,815,4096,300,5376,0,294,5392,555,1025,1,4145,32,17,2,300,49,814,5392,4097,554,1316,32,257,33,5408,512]

theorem envBound12996 : H12AffineFastState.Bounded env12996 := by
  intro p hp
  have h : env12996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12995_12996 : H12AffineEnvironment.transform 5 49 env12995 = env12996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env12995 == env12996) = true)

theorem identity12996 : scanCanonicalize (H12AffineFastState.compose env12996 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12996 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env12997 : List Nat := [2,4,8,16,0,17,8,256,512,1024,783,4096,268,5376,0,262,5392,523,1025,1,4113,0,17,2,268,17,782,5392,4097,522,1284,0,257,1,5376,512]

theorem envBound12997 : H12AffineFastState.Bounded env12997 := by
  intro p hp
  have h : env12997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12996_12997 : H12AffineEnvironment.transform 4 0 env12996 = env12997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12996 == env12997) = true)

theorem identity12997 : scanCanonicalize (H12AffineFastState.compose env12997 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12998 : List Nat := [2,4,8,16,0,17,8,256,512,273,783,4096,268,4113,0,262,4097,523,272,1,4113,0,17,2,268,17,782,4097,4097,522,21,0,257,1,4113,512]

theorem envBound12998 : H12AffineFastState.Bounded env12998 := by
  intro p hp
  have h : env12998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12997_12998 : H12AffineEnvironment.transform 9 273 env12997 = env12998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12997 == env12998) = true)

theorem identity12998 : scanCanonicalize (H12AffineFastState.compose env12998 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound12998 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12999 : List Nat := [2,4,8,16,0,17,8,256,512,273,783,17,268,0,0,262,16,523,272,1,0,0,17,2,268,17,782,16,16,522,21,0,257,1,0,512]

theorem envBound12999 : H12AffineFastState.Bounded env12999 := by
  intro p hp
  have h : env12999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12998_12999 : H12AffineEnvironment.transform 11 17 env12998 = env12999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12998 == env12999) = true)

theorem identity12999 : scanCanonicalize (H12AffineFastState.compose env12999 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound12999 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13000 : List Nat := [2,4,8,16,0,17,8,256,11,273,260,17,268,0,0,262,16,0,272,1,0,0,17,2,268,17,261,16,16,1,21,0,257,1,0,11]

theorem envBound13000 : H12AffineFastState.Bounded env13000 := by
  intro p hp
  have h : env13000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12999_13000 : H12AffineEnvironment.transform 8 11 env12999 = env13000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env12999 == env13000) = true)

def env13001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272392,16,21763,8192,64,121942,115015,17665,303453,119042,329730,257,98679,90202,63069]

theorem envBound13001 : H12AffineFastState.Bounded env13001 := by
  intro p hp
  have h : env13001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12988_13001 : H12AffineEnvironment.transform 20 4161 env12988 = env13001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12988 == env13001) = true)

theorem identity13001 : scanCanonicalize (H12AffineFastState.compose env13001 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13001 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13388,262144,1025,32769,4161,272392,16,2,8192,64,100695,103494,4096,303453,99331,329730,257,98679,79195,41820]

theorem envBound13002 : H12AffineFastState.Bounded env13002 := by
  intro p hp
  have h : env13002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13001_13002 : H12AffineEnvironment.transform 13 5377 env13001 = env13002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13001 == env13002) = true)

theorem identity13002 : scanCanonicalize (H12AffineFastState.compose env13002 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound13002 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env13003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13388,35108,1025,32769,4161,41260,16,2,8192,64,100695,103494,4096,10361,99331,98598,257,98679,79195,41820]

theorem envBound13003 : H12AffineFastState.Bounded env13003 := by
  intro p hp
  have h : env13003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13002_13003 : H12AffineEnvironment.transform 17 35108 env13002 = env13003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env13002 == env13003) = true)

theorem identity13003 : scanCanonicalize (H12AffineFastState.compose env13003 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 41342) := by decide +kernel

theorem selectedBound13003 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env13004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,41342,13388,35108,1025,32769,4161,41260,16,2,8192,64,10281,13624,4096,10361,9597,8280,257,8201,37925,41820]

theorem envBound13004 : H12AffineFastState.Bounded env13004 := by
  intro p hp
  have h : env13004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13003_13004 : H12AffineEnvironment.transform 15 41342 env13003 = env13004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41342 env13003 == env13004) = true)

theorem identity13004 : scanCanonicalize (H12AffineFastState.compose env13004 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13004 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env13005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8574,13388,2340,1025,1,4161,8492,16,2,8192,64,10281,13624,4096,10361,9597,8280,257,8201,5157,9052]

theorem envBound13005 : H12AffineFastState.Bounded env13005 := by
  intro p hp
  have h : env13005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13004_13005 : H12AffineEnvironment.transform 14 0 env13004 = env13005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13004 == env13005) = true)

theorem identity13005 : scanCanonicalize (H12AffineFastState.compose env13005 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound13005 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env13006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,0,262,5172,2340,1025,1,4161,340,16,2,120,64,2129,5440,4096,2049,1285,32,257,113,5157,804]

theorem envBound13006 : H12AffineFastState.Bounded env13006 := by
  intro p hp
  have h : env13006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13005_13006 : H12AffineEnvironment.transform 12 120 env13005 = env13006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env13005 == env13006) = true)

theorem identity13006 : scanCanonicalize (H12AffineFastState.compose env13006 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound13006 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env13007 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5237,0,114,5172,2128,1025,1,4161,32,16,2,120,64,2129,5172,4096,2049,1137,32,117,113,5157,592]

theorem envBound13007 : H12AffineFastState.Bounded env13007 := by
  intro p hp
  have h : env13007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13006_13007 : H12AffineEnvironment.transform 7 116 env13006 = env13007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env13006 == env13007) = true)

theorem identity13007 : scanCanonicalize (H12AffineFastState.compose env13007 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13007 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13008 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,34,5172,2048,1025,1,4113,32,16,2,40,16,2049,5172,4096,2049,1057,32,37,33,5157,512]

theorem envBound13008 : H12AffineFastState.Bounded env13008 := by
  intro p hp
  have h : env13008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13007_13008 : H12AffineEnvironment.transform 5 16 env13007 = env13008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13007 == env13008) = true)

theorem identity13008 : scanCanonicalize (H12AffineFastState.compose env13008 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13008 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13009 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5124,0,3,5141,2048,1025,1,4113,1,16,2,9,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound13009 : H12AffineFastState.Bounded env13009 := by
  intro p hp
  have h : env13009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13008_13009 : H12AffineEnvironment.transform 4 1 env13008 = env13009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13008 == env13009) = true)

def env13010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,272393,2101329,2114882,8193,64,121942,115014,17665,2404637,119042,329730,257,2199863,2191387,63068]

theorem envBound13010 : H12AffineFastState.Bounded env13010 := by
  intro p hp
  have h : env13010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12987_13010 : H12AffineEnvironment.transform 6 9 env12987 = env13010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12987 == env13010) = true)

def env13011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272393,17,21762,8193,64,121942,115014,17665,303453,119042,329730,257,98679,90203,63068]

theorem envBound13011 : H12AffineFastState.Bounded env13011 := by
  intro p hp
  have h : env13011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13010_13011 : H12AffineEnvironment.transform 20 4160 env13010 = env13011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13010 == env13011) = true)

theorem identity13011 : scanCanonicalize (H12AffineFastState.compose env13011 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound13011 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,56437,1025,32769,4160,62588,17,21762,8193,64,121942,115014,17665,32040,119042,119927,257,98679,90203,63068]

theorem envBound13012 : H12AffineFastState.Bounded env13012 := by
  intro p hp
  have h : env13012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13011_13012 : H12AffineEnvironment.transform 17 56437 env13011 = env13012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env13011 == env13012) = true)

theorem identity13012 : scanCanonicalize (H12AffineFastState.compose env13012 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13012 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env13013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13389,35188,1025,32769,4160,41341,17,3,8193,64,100695,103495,4096,10281,99331,98678,257,98679,79194,41821]

theorem envBound13013 : H12AffineFastState.Bounded env13013 := by
  intro p hp
  have h : env13013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13012_13013 : H12AffineEnvironment.transform 13 5377 env13012 = env13013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13012 == env13013) = true)

theorem identity13013 : scanCanonicalize (H12AffineFastState.compose env13013 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound13013 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40971,13389,35188,1025,32769,4160,41341,17,3,8193,64,10588,13388,4096,10281,9224,8573,257,8572,38225,41821]

theorem envBound13014 : H12AffineFastState.Bounded env13014 := by
  intro p hp
  have h : env13014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13013_13014 : H12AffineEnvironment.transform 15 40971 env13013 = env13014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env13013 == env13014) = true)

theorem identity13014 : scanCanonicalize (H12AffineFastState.compose env13014 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13014 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env13015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,8202,13389,2421,1025,0,4160,8572,17,3,8193,64,10588,13388,4096,10281,9224,8573,257,8572,5456,9052]

theorem envBound13015 : H12AffineFastState.Bounded env13015 := by
  intro p hp
  have h : env13015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13014_13015 : H12AffineEnvironment.transform 14 1 env13014 = env13015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13014 == env13015) = true)

theorem identity13015 : scanCanonicalize (H12AffineFastState.compose env13015 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 894) := by decide +kernel

theorem selectedBound13015 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env13016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,894,4096,8192,5377,1,8202,13389,523,1025,0,4160,8572,17,3,8193,64,8738,13388,4096,9047,9224,8573,257,8572,5456,9052]

theorem envBound13016 : H12AffineFastState.Bounded env13016 := by
  intro p hp
  have h : env13016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13015_13016 : H12AffineEnvironment.transform 10 894 env13015 = env13016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 894 env13015 == env13016) = true)

theorem identity13016 : scanCanonicalize (H12AffineFastState.compose env13016 (packedSelected [3,4,5,6,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound13016 : packedSelected [3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env13017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,894,4096,1052,5377,1,1046,4177,523,1025,0,4160,1376,17,3,1053,64,1598,4176,4096,1867,20,1377,257,1376,5456,1856]

theorem envBound13017 : H12AffineFastState.Bounded env13017 := by
  intro p hp
  have h : env13017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13016_13017 : H12AffineEnvironment.transform 12 1052 env13016 = env13017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env13016 == env13017) = true)

theorem identity13017 : scanCanonicalize (H12AffineFastState.compose env13017 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13017 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13018 : List Nat := [2,4,8,16,32,64,9,256,512,101,894,4096,121,4452,1,115,4177,523,100,0,4160,261,17,3,120,64,603,4176,4096,814,20,260,257,261,4405,805]

theorem envBound13018 : H12AffineFastState.Bounded env13018 := by
  intro p hp
  have h : env13018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13017_13018 : H12AffineEnvironment.transform 9 101 env13017 = env13018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13017 == env13018) = true)

theorem identity13018 : scanCanonicalize (H12AffineFastState.compose env13018 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13018 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13019 : List Nat := [2,4,8,16,32,17,9,256,512,52,815,4096,40,4405,1,34,4096,523,53,0,4113,261,17,3,41,17,522,4097,4096,814,20,260,257,261,4405,805]

theorem envBound13019 : H12AffineFastState.Bounded env13019 := by
  intro p hp
  have h : env13019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13018_13019 : H12AffineEnvironment.transform 5 17 env13018 = env13019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13018 == env13019) = true)

theorem identity13019 : scanCanonicalize (H12AffineFastState.compose env13019 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 798) := by decide +kernel

theorem selectedBound13019 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13020 : List Nat := [2,4,8,16,32,17,9,256,512,52,815,798,40,555,1,34,798,523,53,0,783,261,17,3,41,17,522,799,798,814,20,260,257,261,555,805]

theorem envBound13020 : H12AffineFastState.Bounded env13020 := by
  intro p hp
  have h : env13020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13019_13020 : H12AffineEnvironment.transform 11 798 env13019 = env13020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 798 env13019 == env13020) = true)

theorem identity13020 : scanCanonicalize (H12AffineFastState.compose env13020 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13020 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env13021 : List Nat := [2,4,8,16,32,17,9,36,512,52,523,570,40,555,1,34,570,523,53,0,555,33,17,3,41,17,522,571,570,522,20,32,37,33,555,513]

theorem envBound13021 : H12AffineFastState.Bounded env13021 := by
  intro p hp
  have h : env13021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13020_13021 : H12AffineEnvironment.transform 7 36 env13020 = env13021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13020 == env13021) = true)

theorem identity13021 : scanCanonicalize (H12AffineFastState.compose env13021 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound13021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13022 : List Nat := [2,4,8,16,32,17,9,36,15,52,4,53,40,36,1,34,53,4,53,0,36,33,17,3,41,17,5,52,53,5,20,32,37,33,36,14]

theorem envBound13022 : H12AffineFastState.Bounded env13022 := by
  intro p hp
  have h : env13022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13021_13022 : H12AffineEnvironment.transform 8 15 env13021 = env13022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env13021 == env13022) = true)

theorem identity13022 : scanCanonicalize (H12AffineFastState.compose env13022 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13023 : List Nat := [2,2,8,16,32,17,9,34,9,50,2,51,40,34,1,34,51,2,51,0,34,33,17,3,41,17,3,50,51,3,18,32,35,33,34,8]

theorem envBound13023 : H12AffineFastState.Bounded env13023 := by
  intro p hp
  have h : env13023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13022_13023 : H12AffineEnvironment.transform 1 2 env13022 = env13023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13022 == env13023) = true)

def env13024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,272393,16,21763,8193,64,121942,115014,17665,303452,119042,329730,257,98678,90202,63068]

theorem envBound13024 : H12AffineFastState.Bounded env13024 := by
  intro p hp
  have h : env13024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13010_13024 : H12AffineEnvironment.transform 20 4161 env13010 = env13024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13010 == env13024) = true)

theorem identity13024 : scanCanonicalize (H12AffineFastState.compose env13024 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound13024 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,24908,262144,1025,29788,4161,272393,16,21763,8193,64,75787,79131,17665,283905,75103,329730,257,95531,90202,513]

theorem envBound13025 : H12AffineFastState.Bounded env13025 := by
  intro p hp
  have h : env13025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13024_13025 : H12AffineEnvironment.transform 14 29789 env13024 = env13025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13024 == env13025) = true)

theorem identity13025 : scanCanonicalize (H12AffineFastState.compose env13025 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound13025 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,24908,262144,1025,29788,4161,272393,16,21763,8193,64,10589,13389,17665,283905,9225,264532,257,29821,24844,513]

theorem envBound13026 : H12AffineFastState.Bounded env13026 := by
  intro p hp
  have h : env13026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13025_13026 : H12AffineEnvironment.transform 15 342 env13025 = env13026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env13025 == env13026) = true)

theorem identity13026 : scanCanonicalize (H12AffineFastState.compose env13026 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound13026 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,24908,23668,1025,29788,4161,29821,16,21763,8193,64,10589,13389,17665,2421,9225,21792,257,29821,24844,513]

theorem envBound13027 : H12AffineFastState.Bounded env13027 := by
  intro p hp
  have h : env13027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13026_13027 : H12AffineEnvironment.transform 17 23668 env13026 = env13027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env13026 == env13027) = true)

theorem identity13027 : scanCanonicalize (H12AffineFastState.compose env13027 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13027 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,342,13388,2420,1025,8540,4161,8573,16,3,8193,64,10589,13389,4097,2421,9225,32,257,8573,13324,513]

theorem envBound13028 : H12AffineFastState.Bounded env13028 := by
  intro p hp
  have h : env13028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13027_13028 : H12AffineEnvironment.transform 13 5376 env13027 = env13028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13027 == env13028) = true)

theorem identity13028 : scanCanonicalize (H12AffineFastState.compose env13028 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13028 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5393,2420,1025,1,4161,32,16,3,348,64,2048,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound13029 : H12AffineFastState.Bounded env13029 := by
  intro p hp
  have h : env13029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13028_13029 : H12AffineEnvironment.transform 12 349 env13028 = env13029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13028 == env13029) = true)

theorem identity13029 : scanCanonicalize (H12AffineFastState.compose env13029 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound13029 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,868,349,1636,0,342,1653,2420,1025,1,805,32,16,3,348,64,2048,1652,869,2421,1364,32,257,32,1589,513]

theorem envBound13030 : H12AffineFastState.Bounded env13030 := by
  intro p hp
  have h : env13030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13029_13030 : H12AffineEnvironment.transform 11 868 env13029 = env13030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env13029 == env13030) = true)

theorem identity13030 : scanCanonicalize (H12AffineFastState.compose env13030 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13030 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13031 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,820,269,1588,0,262,1573,2340,1025,1,805,32,16,3,268,16,2048,1572,821,2341,1284,32,257,32,1589,513]

theorem envBound13031 : H12AffineFastState.Bounded env13031 := by
  intro p hp
  have h : env13031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13030_13031 : H12AffineEnvironment.transform 5 16 env13030 = env13031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13030 == env13031) = true)

theorem identity13031 : scanCanonicalize (H12AffineFastState.compose env13031 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound13031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13032 : List Nat := [2,4,8,16,32,16,9,256,512,4,2048,820,269,560,0,262,545,2340,5,1,805,32,16,3,268,16,2048,544,821,2341,256,32,257,32,561,513]

theorem envBound13032 : H12AffineFastState.Bounded env13032 := by
  intro p hp
  have h : env13032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13031_13032 : H12AffineEnvironment.transform 9 4 env13031 = env13032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env13031 == env13032) = true)

theorem identity13032 : scanCanonicalize (H12AffineFastState.compose env13032 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound13032 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13033 : List Nat := [2,4,8,16,32,16,9,256,512,4,277,820,269,560,0,262,545,49,5,1,805,32,16,3,268,16,277,544,821,48,256,32,257,32,561,513]

theorem envBound13033 : H12AffineFastState.Bounded env13033 := by
  intro p hp
  have h : env13033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13032_13033 : H12AffineEnvironment.transform 10 277 env13032 = env13033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env13032 == env13033) = true)

theorem identity13033 : scanCanonicalize (H12AffineFastState.compose env13033 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13033 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13034 : List Nat := [2,4,8,16,32,16,9,256,32,4,277,276,269,16,0,262,1,49,5,1,261,32,16,3,268,16,277,0,277,48,256,32,257,32,17,33]

theorem envBound13034 : H12AffineFastState.Bounded env13034 := by
  intro p hp
  have h : env13034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13033_13034 : H12AffineEnvironment.transform 8 32 env13033 = env13034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13033 == env13034) = true)

theorem identity13034 : scanCanonicalize (H12AffineFastState.compose env13034 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13034 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13035 : List Nat := [2,4,8,16,16,16,9,256,16,4,277,276,269,16,0,262,1,1,5,1,261,16,16,3,268,16,277,0,277,0,256,16,257,16,17,17]

theorem envBound13035 : H12AffineFastState.Bounded env13035 := by
  intro p hp
  have h : env13035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13034_13035 : H12AffineEnvironment.transform 4 16 env13034 = env13035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13034 == env13035) = true)

theorem identity13035 : scanCanonicalize (H12AffineFastState.compose env13035 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13035 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13036 : List Nat := [2,4,8,1,1,1,9,256,1,4,260,261,269,1,0,262,1,1,5,1,261,1,1,3,268,1,260,0,260,0,256,1,257,1,0,0]

theorem envBound13036 : H12AffineFastState.Bounded env13036 := by
  intro p hp
  have h : env13036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0