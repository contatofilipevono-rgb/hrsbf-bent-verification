import H12CloudChart0Data102

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env26076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,58397,4194304,272440,41311,8193,65,4262262,115015,301428,43048,331127,4268042,257,371039,346226,272936]

theorem envBound26076 : H12AffineFastState.Bounded env26076 := by
  intro p hp
  have h : env26076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26046_26076 : H12AffineEnvironment.transform 20 58397 env26046 = env26076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env26046 == env26076) = true)

def env26077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,4194304,16,41311,8193,65,4262262,115015,45404,43048,75103,4268042,257,98679,90202,512]

theorem envBound26077 : H12AffineFastState.Bounded env26077 := by
  intro p hp
  have h : env26077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26076_26077 : H12AffineEnvironment.transform 17 10280 env26076 = env26077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26076 == env26077) = true)

theorem identity26077 : scanCanonicalize (H12AffineFastState.compose env26077 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26077 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26078 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,4194304,16,41003,8193,65,4261890,114739,45096,43048,74795,4268042,117,98307,90202,512]

theorem envBound26078 : H12AffineFastState.Bounded env26078 := by
  intro p hp
  have h : env26078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26077_26078 : H12AffineEnvironment.transform 7 116 env26077 = env26078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26077 == env26078) = true)

theorem identity26078 : scanCanonicalize (H12AffineFastState.compose env26078 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound26078 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26079 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,62588,16,41003,8193,65,130174,114739,45096,43048,74795,119926,117,98307,90202,512]

theorem envBound26079 : H12AffineFastState.Bounded env26079 := by
  intro p hp
  have h : env26079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26078_26079 : H12AffineEnvironment.transform 21 62588 env26078 = env26079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env26078 == env26079) = true)

theorem identity26079 : scanCanonicalize (H12AffineFastState.compose env26079 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound26079 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26080 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,32768,65536,5220,10280,1025,32769,45161,40968,16,41003,8193,65,108554,103495,45096,43048,74795,98306,117,98307,78894,512]

theorem envBound26080 : H12AffineFastState.Bounded env26080 := by
  intro p hp
  have h : env26080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26079_26080 : H12AffineEnvironment.transform 13 5236 env26079 = env26080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env26079 == env26080) = true)

theorem identity26080 : scanCanonicalize (H12AffineFastState.compose env26080 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound26080 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26081 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,8201,65536,5220,10280,1025,8200,4192,1,16,34,8193,65,67587,78926,4129,2081,74795,73739,117,73738,78894,512]

theorem envBound26081 : H12AffineFastState.Bounded env26081 := by
  intro p hp
  have h : env26081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26080_26081 : H12AffineEnvironment.transform 14 8201 env26080 = env26081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env26080 == env26081) = true)

theorem identity26081 : scanCanonicalize (H12AffineFastState.compose env26081 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1127) := by decide +kernel

theorem selectedBound26081 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env26082 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,8201,1127,5220,10280,1025,8200,4192,1,16,34,8193,65,3172,12329,4129,2081,8268,9324,117,9325,12361,512]

theorem envBound26082 : H12AffineFastState.Bounded env26082 := by
  intro p hp
  have h : env26082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26081_26082 : H12AffineEnvironment.transform 15 1127 env26081 = env26082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1127 env26081 == env26082) = true)

theorem identity26082 : scanCanonicalize (H12AffineFastState.compose env26082 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound26082 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env26083 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1101,5236,1092,1127,5220,3173,1025,1093,4192,1,16,34,1100,65,3172,5220,4129,2081,1025,33,117,32,5124,512]

theorem envBound26083 : H12AffineFastState.Bounded env26083 := by
  intro p hp
  have h : env26083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26082_26083 : H12AffineEnvironment.transform 12 1101 env26082 = env26083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env26082 == env26083) = true)

theorem identity26083 : scanCanonicalize (H12AffineFastState.compose env26083 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound26083 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26084 : List Nat := [2,4,8,16,32,64,9,116,512,20,2048,4096,89,4192,80,115,4208,2161,21,81,4192,1,16,34,88,65,2160,4208,4129,2081,21,33,117,32,4112,512]

theorem envBound26084 : H12AffineFastState.Bounded env26084 := by
  intro p hp
  have h : env26084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26083_26084 : H12AffineEnvironment.transform 9 20 env26083 = env26084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26083 == env26084) = true)

theorem identity26084 : scanCanonicalize (H12AffineFastState.compose env26084 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound26084 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26085 : List Nat := [2,4,8,16,32,48,9,4,512,20,2048,4096,41,4112,32,3,4096,2049,21,33,4112,1,16,34,40,49,2048,4096,4129,2081,21,33,5,32,4112,512]

theorem envBound26085 : H12AffineFastState.Bounded env26085 := by
  intro p hp
  have h : env26085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26084_26085 : H12AffineEnvironment.transform 5 48 env26084 = env26085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env26084 == env26085) = true)

theorem identity26085 : scanCanonicalize (H12AffineFastState.compose env26085 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound26085 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26086 : List Nat := [2,4,8,16,32,48,9,4,512,20,17,4096,41,4112,32,3,4096,16,21,33,4112,1,16,34,40,49,17,4096,4129,48,21,33,5,32,4112,512]

theorem envBound26086 : H12AffineFastState.Bounded env26086 := by
  intro p hp
  have h : env26086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26085_26086 : H12AffineEnvironment.transform 10 17 env26085 = env26086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env26085 == env26086) = true)

theorem identity26086 : scanCanonicalize (H12AffineFastState.compose env26086 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound26086 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env26087 : List Nat := [2,4,8,16,32,48,9,4,512,20,17,545,41,561,32,3,545,16,21,33,561,1,16,34,40,49,17,545,512,48,21,33,5,32,561,512]

theorem envBound26087 : H12AffineFastState.Bounded env26087 := by
  intro p hp
  have h : env26087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26086_26087 : H12AffineEnvironment.transform 11 545 env26086 = env26087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env26086 == env26087) = true)

theorem identity26087 : scanCanonicalize (H12AffineFastState.compose env26087 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26087 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26088 : List Nat := [2,4,8,16,0,16,9,4,512,20,17,513,9,529,0,3,513,16,21,1,529,1,16,2,8,17,17,513,512,16,21,1,5,0,529,512]

theorem envBound26088 : H12AffineFastState.Bounded env26088 := by
  intro p hp
  have h : env26088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26087_26088 : H12AffineEnvironment.transform 4 0 env26087 = env26088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26087 == env26088) = true)

theorem identity26088 : scanCanonicalize (H12AffineFastState.compose env26088 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound26088 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26089 : List Nat := [2,4,8,16,0,16,9,4,21,20,17,20,9,4,0,3,20,16,21,1,4,1,16,2,8,17,17,20,21,16,21,1,5,0,4,21]

theorem envBound26089 : H12AffineFastState.Bounded env26089 := by
  intro p hp
  have h : env26089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26088_26089 : H12AffineEnvironment.transform 8 21 env26088 = env26089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env26088 == env26089) = true)

theorem identity26089 : scanCanonicalize (H12AffineFastState.compose env26089 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound26089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26090 : List Nat := [2,4,8,6,0,6,9,4,3,2,7,2,9,4,0,3,2,6,3,1,4,1,6,2,8,7,7,2,3,6,3,1,5,0,4,3]

theorem envBound26090 : H12AffineFastState.Bounded env26090 := by
  intro p hp
  have h : env26090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26089_26090 : H12AffineEnvironment.transform 3 6 env26089 = env26090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env26089 == env26090) = true)

def env26091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,4194304,17,41311,8193,65,4262262,115015,45405,43048,75102,4268042,257,98678,90203,513]

theorem envBound26091 : H12AffineFastState.Bounded env26091 := by
  intro p hp
  have h : env26091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26076_26091 : H12AffineEnvironment.transform 17 10281 env26076 = env26091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26076 == env26091) = true)

theorem identity26091 : scanCanonicalize (H12AffineFastState.compose env26091 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26091 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env26092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,17729,4194304,17,3,8193,65,4262262,90139,4097,2420,75102,4268042,257,73770,90203,513]

theorem envBound26092 : H12AffineFastState.Bounded env26092 := by
  intro p hp
  have h : env26092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26091_26092 : H12AffineEnvironment.transform 14 8540 env26091 = env26092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26091 == env26092) = true)

theorem identity26092 : scanCanonicalize (H12AffineFastState.compose env26092 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound26092 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env26093 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,262,16400,10281,1025,8541,17729,4194304,17,3,8193,65,4196464,24861,4097,2420,9304,4202764,257,8492,24925,513]

theorem envBound26093 : H12AffineFastState.Bounded env26093 := by
  intro p hp
  have h : env26093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26092_26093 : H12AffineEnvironment.transform 15 262 env26092 = env26093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env26092 == env26093) = true)

theorem identity26093 : scanCanonicalize (H12AffineFastState.compose env26093 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound26093 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,262,16400,10281,1025,8541,17729,113,17,3,8193,65,2049,24861,4097,2420,9304,8573,257,8492,24925,513]

theorem envBound26094 : H12AffineFastState.Bounded env26094 := by
  intro p hp
  have h : env26094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26093_26094 : H12AffineEnvironment.transform 21 113 env26093 = env26094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env26093 == env26094) = true)

theorem identity26094 : scanCanonicalize (H12AffineFastState.compose env26094 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26094 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env26095 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,262,16400,10281,1025,8461,17681,33,17,3,8193,17,2049,24861,4097,2340,9224,8493,257,8492,24845,513]

theorem envBound26095 : H12AffineFastState.Bounded env26095 := by
  intro p hp
  have h : env26095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26094_26095 : H12AffineEnvironment.transform 5 16 env26094 = env26095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26094 == env26095) = true)

def env26096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,272440,41311,8193,65,4262263,2172250,2391401,43049,331127,6407191,257,2444610,2468975,272936]

theorem envBound26096 : H12AffineFastState.Bounded env26096 := by
  intro p hp
  have h : env26096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26045_26096 : H12AffineEnvironment.transform 16 16401 env26045 = env26096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env26045 == env26096) = true)

theorem identity26096 : scanCanonicalize (H12AffineFastState.compose env26096 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound26096 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41311,8193,65,4262263,2172250,2118976,43049,75102,6407191,257,2188651,2196550,513]

theorem envBound26097 : H12AffineFastState.Bounded env26097 := by
  intro p hp
  have h : env26097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26096_26097 : H12AffineEnvironment.transform 17 10281 env26096 = env26097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26096 == env26097) = true)

theorem identity26097 : scanCanonicalize (H12AffineFastState.compose env26097 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound26097 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env26098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115734,4194304,17,41311,8193,65,4262263,57676,102742,43049,75102,4194305,257,41341,16464,513]

theorem envBound26098 : H12AffineFastState.Bounded env26098 := by
  intro p hp
  have h : env26098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26097_26098 : H12AffineEnvironment.transform 20 115734 env26097 = env26098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env26097 == env26098) = true)

theorem identity26098 : scanCanonicalize (H12AffineFastState.compose env26098 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound26098 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env26099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16401,10281,1025,32769,50496,4194304,17,41311,8193,65,4196385,57676,36864,43049,9224,4194305,257,41341,16464,513]

theorem envBound26099 : H12AffineFastState.Bounded env26099 := by
  intro p hp
  have h : env26099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26098_26099 : H12AffineEnvironment.transform 15 342 env26098 = env26099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env26098 == env26099) = true)

theorem identity26099 : scanCanonicalize (H12AffineFastState.compose env26099 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26099 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env26100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16401,10281,1025,8540,25629,4194304,17,2,8193,65,4196385,16401,12637,2420,9224,4194305,257,32,16464,513]

theorem envBound26100 : H12AffineFastState.Bounded env26100 := by
  intro p hp
  have h : env26100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26099_26100 : H12AffineEnvironment.transform 14 8541 env26099 = env26100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26099 == env26100) = true)

theorem identity26100 : scanCanonicalize (H12AffineFastState.compose env26100 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound26100 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env26101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16401,10281,1025,8540,25629,8572,17,2,8193,65,10589,16401,12637,2420,9224,8573,257,32,16464,513]

theorem envBound26101 : H12AffineFastState.Bounded env26101 := by
  intro p hp
  have h : env26101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26100_26101 : H12AffineEnvironment.transform 21 8572 env26100 = env26101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env26100 == env26101) = true)

theorem identity26101 : scanCanonicalize (H12AffineFastState.compose env26101 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 9341) := by decide +kernel

theorem selectedBound26101 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env26102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,9341,8541,342,9324,10281,1025,8540,96,8572,17,2,8193,65,10589,9324,12637,2420,9224,8573,257,32,9261,513]

theorem envBound26102 : H12AffineFastState.Bounded env26102 := by
  intro p hp
  have h : env26102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26101_26102 : H12AffineEnvironment.transform 13 9341 env26101 = env26102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9341 env26101 == env26102) = true)

theorem identity26102 : scanCanonicalize (H12AffineFastState.compose env26102 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26102 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env26103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,1312,0,342,1329,2420,1025,1,96,33,17,2,348,65,2048,1329,4096,2420,1365,32,257,32,1392,513]

theorem envBound26103 : H12AffineFastState.Bounded env26103 := by
  intro p hp
  have h : env26103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26102_26103 : H12AffineEnvironment.transform 12 349 env26102 = env26103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26102 == env26103) = true)

theorem identity26103 : scanCanonicalize (H12AffineFastState.compose env26103 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound26103 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26104 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,4096,349,561,0,342,544,2420,784,1,96,33,17,2,348,65,2048,544,4096,2420,580,32,257,32,609,513]

theorem envBound26104 : H12AffineFastState.Bounded env26104 := by
  intro p hp
  have h : env26104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26103_26104 : H12AffineEnvironment.transform 9 785 env26103 = env26104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env26103 == env26104) = true)

def env26105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound26105 : H12AffineFastState.Bounded env26105 := by
  intro p hp
  have h : env26105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25778_26105 : H12AffineEnvironment.transform 26 30393345 env25778 = env26105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env25778 == env26105) = true)

def env26106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound26106 : H12AffineFastState.Bounded env26106 := by
  intro p hp
  have h : env26106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26105_26106 : H12AffineEnvironment.transform 18 1024 env26105 = env26106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26105 == env26106) = true)

theorem identity26106 : scanCanonicalize (H12AffineFastState.compose env26106 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437624) := by decide +kernel

theorem selectedBound26106 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,8388608,16777216,8328,65,29868033,17246709,8845353,8830976,25265168,21481656,256,25651668,25659504,25207751]

theorem envBound26107 : H12AffineFastState.Bounded env26107 := by
  intro p hp
  have h : env26107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26106_26107 : H12AffineEnvironment.transform 20 437624 env26106 = env26107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env26106 == env26107) = true)

def env26108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,8388608,8862964,8328,65,4259061,8393985,8845353,8830976,440548,12645452,256,21792,46212,499507]

theorem envBound26108 : H12AffineFastState.Bounded env26108 := by
  intro p hp
  have h : env26108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26107_26108 : H12AffineEnvironment.transform 23 8862964 env26107 = env26108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862964 env26107 == env26108) = true)

def env26109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441640,98780,8328,65,4259061,436265,17665,32040,440548,4606308,256,21792,46212,499507]

theorem envBound26109 : H12AffineFastState.Bounded env26109 := by
  intro p hp
  have h : env26109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26108_26109 : H12AffineEnvironment.transform 22 441640 env26108 = env26109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env26108 == env26109) = true)

def env26110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441640,98780,8328,65,316533,436265,17665,32040,440548,156132,256,21792,46212,499507]

theorem envBound26110 : H12AffineFastState.Bounded env26110 := by
  intro p hp
  have h : env26110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26109_26110 : H12AffineEnvironment.transform 21 272512 env26109 = env26110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26109 == env26110) = true)

theorem identity26110 : scanCanonicalize (H12AffineFastState.compose env26110 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound26110 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,437624,272512,441640,21762,8328,65,316533,436265,17665,32040,440548,156132,256,21792,46212,412653]

theorem envBound26111 : H12AffineFastState.Bounded env26111 := by
  intro p hp
  have h : env26111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26110_26111 : H12AffineEnvironment.transform 15 54494 env26110 = env26111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env26110 == env26111) = true)

def env26112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437624,272392,441640,21762,8192,65,316533,436265,17665,32040,440428,156012,256,21792,46092,412517]

theorem envBound26112 : H12AffineFastState.Bounded env26112 := by
  intro p hp
  have h : env26112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26111_26112 : H12AffineEnvironment.transform 6 8 env26111 = env26112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26111 == env26112) = true)

theorem identity26112 : scanCanonicalize (H12AffineFastState.compose env26112 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound26112 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env26113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157752,1024,32769,50496,147504,54544,21762,8192,65,179277,49169,17665,32040,53332,156012,256,21792,46092,9053]

theorem envBound26113 : H12AffineFastState.Bounded env26113 := by
  intro p hp
  have h : env26113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26112_26113 : H12AffineEnvironment.transform 17 157752 env26112 = env26113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env26112 == env26113) = true)

theorem identity26113 : scanCanonicalize (H12AffineFastState.compose env26113 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26113 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,131072,157752,1024,0,17729,147504,21777,21762,8192,65,146508,16400,17665,32040,20565,156012,256,21792,13325,9053]

theorem envBound26114 : H12AffineFastState.Bounded env26114 := by
  intro p hp
  have h : env26114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26113_26114 : H12AffineEnvironment.transform 14 1 env26113 = env26114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26113 == env26114) = true)

theorem identity26114 : scanCanonicalize (H12AffineFastState.compose env26114 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound26114 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env26115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,13389,23669,1024,0,17729,29821,21777,21762,8192,65,2049,16400,17665,32040,20565,21793,256,21792,13325,9053]

theorem envBound26115 : H12AffineFastState.Bounded env26115 := by
  intro p hp
  have h : env26115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26114_26115 : H12AffineEnvironment.transform 16 13389 env26114 = env26115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env26114 == env26115) = true)

theorem identity26115 : scanCanonicalize (H12AffineFastState.compose env26115 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26115 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env26116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8203,13389,10281,1024,0,12573,33,8525,8542,8192,65,2049,13388,12637,2420,9225,8573,256,8572,13325,9053]

theorem envBound26116 : H12AffineFastState.Bounded env26116 := by
  intro p hp
  have h : env26116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26115_26116 : H12AffineEnvironment.transform 13 13404 env26115 = env26116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26115 == env26116) = true)

theorem identity26116 : scanCanonicalize (H12AffineFastState.compose env26116 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26116 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2420,1024,0,4160,33,16,3,349,65,2049,5393,4096,2420,1364,32,256,33,5456,512]

theorem envBound26117 : H12AffineFastState.Bounded env26117 := by
  intro p hp
  have h : env26117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26116_26117 : H12AffineEnvironment.transform 12 349 env26116 = env26117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26116 == env26117) = true)

theorem identity26117 : scanCanonicalize (H12AffineFastState.compose env26117 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound26117 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2107,349,3386,1,342,3371,2420,1024,0,2171,33,16,3,349,65,2049,3370,2107,2420,1364,32,256,33,3435,512]

theorem envBound26118 : H12AffineFastState.Bounded env26118 := by
  intro p hp
  have h : env26118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26117_26118 : H12AffineEnvironment.transform 11 2107 env26117 = env26118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env26117 == env26118) = true)

theorem identity26118 : scanCanonicalize (H12AffineFastState.compose env26118 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26118 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26119 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,2074,349,3355,1,342,3338,2389,1024,0,2138,0,16,3,349,65,2049,3339,2074,2389,1364,1,256,0,3402,512]

theorem envBound26119 : H12AffineFastState.Bounded env26119 := by
  intro p hp
  have h : env26119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26118_26119 : H12AffineEnvironment.transform 4 1 env26118 = env26119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26118 == env26119) = true)

theorem identity26119 : scanCanonicalize (H12AffineFastState.compose env26119 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound26119 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26120 : List Nat := [2,4,8,16,1,64,8,256,512,267,2048,2074,349,2064,1,342,2049,2389,267,0,2138,0,16,3,349,65,2049,2048,2074,2389,95,1,256,0,2113,512]

theorem envBound26120 : H12AffineFastState.Bounded env26120 := by
  intro p hp
  have h : env26120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26119_26120 : H12AffineEnvironment.transform 9 267 env26119 = env26120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env26119 == env26120) = true)

theorem identity26120 : scanCanonicalize (H12AffineFastState.compose env26120 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26120 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env26121 : List Nat := [2,4,8,16,1,16,8,256,512,267,2048,2074,269,2064,1,262,2049,2309,267,0,2058,0,16,3,269,17,2049,2048,2074,2309,15,1,256,0,2065,512]

theorem envBound26121 : H12AffineFastState.Bounded env26121 := by
  intro p hp
  have h : env26121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26120_26121 : H12AffineEnvironment.transform 5 16 env26120 = env26121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26120 == env26121) = true)

theorem identity26121 : scanCanonicalize (H12AffineFastState.compose env26121 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26121 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26122 : List Nat := [2,4,8,1,1,1,8,256,512,267,2048,2059,269,2049,1,262,2049,2309,267,0,2058,0,1,3,269,0,2049,2048,2059,2309,15,1,256,0,2048,512]

theorem envBound26122 : H12AffineFastState.Bounded env26122 := by
  intro p hp
  have h : env26122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26121_26122 : H12AffineEnvironment.transform 3 1 env26121 = env26122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26121 == env26122) = true)

theorem identity26122 : scanCanonicalize (H12AffineFastState.compose env26122 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound26122 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26123 : List Nat := [2,4,8,1,1,1,8,256,512,267,260,271,269,261,1,262,261,1,267,0,270,0,1,3,269,0,261,260,271,1,15,1,256,0,260,512]

theorem envBound26123 : H12AffineFastState.Bounded env26123 := by
  intro p hp
  have h : env26123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26122_26123 : H12AffineEnvironment.transform 10 260 env26122 = env26123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env26122 == env26123) = true)

theorem identity26123 : scanCanonicalize (H12AffineFastState.compose env26123 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26123 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26124 : List Nat := [2,4,2,1,1,1,2,256,512,257,260,261,263,261,1,262,261,1,257,0,260,0,1,3,263,0,261,260,261,1,5,1,256,0,260,512]

theorem envBound26124 : H12AffineFastState.Bounded env26124 := by
  intro p hp
  have h : env26124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26123_26124 : H12AffineEnvironment.transform 2 2 env26123 = env26124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26123 == env26124) = true)

theorem identity26124 : scanCanonicalize (H12AffineFastState.compose env26124 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 259) := by decide +kernel

theorem selectedBound26124 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26125 : List Nat := [2,4,2,1,1,1,2,256,259,257,260,261,263,261,1,262,261,1,257,0,260,0,1,3,263,0,261,260,261,1,5,1,256,0,260,259]

theorem envBound26125 : H12AffineFastState.Bounded env26125 := by
  intro p hp
  have h : env26125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26124_26125 : H12AffineEnvironment.transform 8 259 env26124 = env26125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 259 env26124 == env26125) = true)

theorem identity26125 : scanCanonicalize (H12AffineFastState.compose env26125 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26125 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env26126 : List Nat := [2,4,2,1,1,1,2,5,6,4,1,0,2,0,1,3,0,1,4,0,1,0,1,3,2,0,0,1,0,1,5,1,5,0,1,6]

theorem envBound26126 : H12AffineFastState.Bounded env26126 := by
  intro p hp
  have h : env26126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26125_26126 : H12AffineEnvironment.transform 7 5 env26125 = env26126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26125 == env26126) = true)

theorem identity26126 : scanCanonicalize (H12AffineFastState.compose env26126 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26127 : List Nat := [0,4,0,1,1,1,0,5,4,4,1,0,0,0,1,1,0,1,4,0,1,0,1,1,0,0,0,1,0,1,5,1,5,0,1,4]

theorem envBound26127 : H12AffineFastState.Bounded env26127 := by
  intro p hp
  have h : env26127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26126_26127 : H12AffineEnvironment.transform 0 0 env26126 = env26127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26126 == env26127) = true)

def env26128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437624,272393,441640,21762,8193,65,316533,436265,17665,32040,440429,156013,256,21792,46093,412516]

theorem envBound26128 : H12AffineFastState.Bounded env26128 := by
  intro p hp
  have h : env26128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26111_26128 : H12AffineEnvironment.transform 6 9 env26111 = env26128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26111 == env26128) = true)

theorem identity26128 : scanCanonicalize (H12AffineFastState.compose env26128 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound26128 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env26129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24908,262144,1024,32769,314420,272393,318564,21762,8193,65,316533,313701,17665,32040,317729,33,256,21792,46093,272936]

theorem envBound26129 : H12AffineFastState.Bounded env26129 := by
  intro p hp
  have h : env26129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26128_26129 : H12AffineEnvironment.transform 16 24908 env26128 = env26129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env26128 == env26129) = true)

theorem identity26129 : scanCanonicalize (H12AffineFastState.compose env26129 (packedSelected [2,3,4,6,9,12,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound26129 : packedSelected [2,3,4,6,9,12,23,24] rootPS < 2^1333 := by decide +kernel

def env26130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24908,56356,1024,32769,4112,62509,64,21762,8193,65,2129,5441,17665,32040,1285,33,256,21792,46093,62988]

theorem envBound26130 : H12AffineFastState.Bounded env26130 := by
  intro p hp
  have h : env26130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26129_26130 : H12AffineEnvironment.transform 17 56356 env26129 = env26130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env26129 == env26130) = true)

theorem identity26130 : scanCanonicalize (H12AffineFastState.compose env26130 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26130 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env26131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,16400,56356,1024,32769,4112,54641,64,21762,349,65,2129,5441,17665,23668,1285,33,256,21792,38225,55120]

theorem envBound26131 : H12AffineFastState.Bounded env26131 := by
  intro p hp
  have h : env26131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26130_26131 : H12AffineEnvironment.transform 12 348 env26130 = env26131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26130 == env26131) = true)

theorem identity26131 : scanCanonicalize (H12AffineFastState.compose env26131 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26131 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26132 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,54279,16400,56356,1024,32769,4112,54561,16,21762,269,17,2049,5393,17665,23588,1285,33,256,21792,38145,55040]

theorem envBound26132 : H12AffineFastState.Bounded env26132 := by
  intro p hp
  have h : env26132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26131_26132 : H12AffineEnvironment.transform 5 16 env26131 = env26132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26131 == env26132) = true)

theorem identity26132 : scanCanonicalize (H12AffineFastState.compose env26132 (packedSelected [0,3,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 23809) := by decide +kernel

theorem selectedBound26132 : packedSelected [0,3,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26133 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,23809,2310,16400,293,1024,23808,4112,2080,16,21762,269,17,2049,5393,17665,23588,1285,33,256,21792,18432,2561]

theorem envBound26133 : H12AffineFastState.Bounded env26133 := by
  intro p hp
  have h : env26133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26132_26133 : H12AffineEnvironment.transform 14 23809 env26132 = env26133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23809 env26132 == env26133) = true)

theorem identity26133 : scanCanonicalize (H12AffineFastState.compose env26133 (packedSelected [0,2,3,6,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound26133 : packedSelected [0,2,3,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26134 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,20788,1331,16400,293,1024,20789,4112,1045,16,21762,269,17,1076,5393,17665,20497,1285,33,256,21792,17461,1588]

theorem envBound26134 : H12AffineFastState.Bounded env26134 := by
  intro p hp
  have h : env26134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26133_26134 : H12AffineEnvironment.transform 10 1077 env26133 = env26134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env26133 == env26134) = true)

theorem identity26134 : scanCanonicalize (H12AffineFastState.compose env26134 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound26134 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26135 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,17,268,16384,16677,1331,16400,293,1024,16676,1,1045,16,17683,269,17,1076,1280,17665,16384,1285,33,256,17713,17461,1588]

theorem envBound26135 : H12AffineFastState.Bounded env26135 := by
  intro p hp
  have h : env26135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26134_26135 : H12AffineEnvironment.transform 11 17 env26134 = env26135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26134 == env26135) = true)

def env26136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441640,98780,8328,65,316532,436265,17665,32040,440548,156133,256,21792,46212,499507]

theorem envBound26136 : H12AffineFastState.Bounded env26136 := by
  intro p hp
  have h : env26136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26109_26136 : H12AffineEnvironment.transform 21 272513 env26109 = env26136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26109 == env26136) = true)

theorem identity26136 : scanCanonicalize (H12AffineFastState.compose env26136 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound26136 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115870,213351,120014,98780,8328,65,245138,115151,17665,32040,119042,156133,256,21792,46212,63189]

theorem envBound26137 : H12AffineFastState.Bounded env26137 := by
  intro p hp
  have h : env26137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26136_26137 : H12AffineEnvironment.transform 17 223718 env26136 = env26137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env26136 == env26137) = true)

def env26138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223670,1024,32769,115870,213303,119966,98700,8328,17,245138,115103,17665,32040,119042,156085,256,21792,46212,63109]

theorem envBound26138 : H12AffineFastState.Bounded env26138 := by
  intro p hp
  have h : env26138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26137_26138 : H12AffineEnvironment.transform 5 16 env26137 = env26138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26137 == env26138) = true)

theorem identity26138 : scanCanonicalize (H12AffineFastState.compose env26138 (packedSelected [1,3,10,18,23,24,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound26138 : packedSelected [1,3,10,18,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env26139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,89379,1024,32769,115870,95650,119966,98700,8328,17,100615,115103,17665,32040,119042,21792,256,21792,46212,63109]

theorem envBound26139 : H12AffineFastState.Bounded env26139 := by
  intro p hp
  have h : env26139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26138_26139 : H12AffineEnvironment.transform 16 13461 env26138 = env26139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env26138 == env26139) = true)

theorem identity26139 : scanCanonicalize (H12AffineFastState.compose env26139 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound26139 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env26140 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,65536,13461,89379,1024,21761,70046,95650,65950,87180,8328,17,89095,70815,17665,32040,66562,21792,256,21792,24964,9093]

theorem envBound26140 : H12AffineFastState.Bounded env26140 := by
  intro p hp
  have h : env26140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26139_26140 : H12AffineEnvironment.transform 14 21760 env26139 = env26140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env26139 == env26140) = true)

theorem identity26140 : scanCanonicalize (H12AffineFastState.compose env26140 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26140 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env26141 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,8322,13461,32161,1024,21761,12572,21792,8476,29710,8328,17,31877,13341,17665,32040,9344,21792,256,21792,24964,9093]

theorem envBound26141 : H12AffineFastState.Bounded env26141 := by
  intro p hp
  have h : env26141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26140_26141 : H12AffineEnvironment.transform 15 8322 env26140 = env26141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26140 == env26141) = true)

theorem identity26141 : scanCanonicalize (H12AffineFastState.compose env26141 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound26141 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env26142 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,8461,8322,13461,2476,1024,8460,12572,8493,8476,3,8328,17,2184,13341,12556,2341,9344,8493,256,8493,5513,9093]

theorem envBound26142 : H12AffineFastState.Bounded env26142 := by
  intro p hp
  have h : env26142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26141_26142 : H12AffineEnvironment.transform 13 13325 env26141 = env26142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env26141 == env26142) = true)

theorem identity26142 : scanCanonicalize (H12AffineFastState.compose env26142 (packedSelected [0,2,6,7,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound26142 : packedSelected [0,2,6,7,11,15] rootPS < 2^1333 := by decide +kernel

def env26143 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,12449,8461,8322,12345,2476,172,8460,12572,8493,8476,3,8328,17,2184,12465,12556,2341,8236,8493,256,8493,4389,9093]

theorem envBound26143 : H12AffineFastState.Bounded env26143 := by
  intro p hp
  have h : env26143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26142_26143 : H12AffineEnvironment.transform 9 172 env26142 = env26143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env26142 == env26143) = true)

theorem identity26143 : scanCanonicalize (H12AffineFastState.compose env26143 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound26143 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26144 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,388,4389,137,262,4541,2476,172,136,4248,169,152,3,268,17,2184,4405,4232,2341,424,169,256,169,4389,513]

theorem envBound26144 : H12AffineFastState.Bounded env26144 := by
  intro p hp
  have h : env26144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26143_26144 : H12AffineEnvironment.transform 12 388 env26143 = env26144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env26143 == env26144) = true)

def env26145 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223671,1024,32769,115870,213302,119967,98701,8328,16,245138,115102,17665,32040,119042,156084,256,21792,46212,63108]

theorem envBound26145 : H12AffineFastState.Bounded env26145 := by
  intro p hp
  have h : env26145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26137_26145 : H12AffineEnvironment.transform 5 17 env26137 = env26145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26137 == env26145) = true)

theorem identity26145 : scanCanonicalize (H12AffineFastState.compose env26145 (packedSelected [1,3,10,18,23,24,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26145 : packedSelected [1,3,10,18,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env26146 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,115735,213302,119830,98564,8193,16,245019,114967,17665,32040,119042,155965,256,21792,46093,62989]

theorem envBound26146 : H12AffineFastState.Bounded env26146 := by
  intro p hp
  have h : env26146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26145_26146 : H12AffineEnvironment.transform 6 9 env26145 = env26146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26145 == env26146) = true)

theorem identity26146 : scanCanonicalize (H12AffineFastState.compose env26146 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound26146 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26147 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,114966,43048,1024,32769,115735,32800,119830,98564,8193,16,31757,114967,17665,32040,119042,106539,256,21792,46093,62989]

theorem envBound26147 : H12AffineFastState.Bounded env26147 := by
  intro p hp
  have h : env26147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26146_26147 : H12AffineEnvironment.transform 16 114966 env26146 = env26147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env26146 == env26147) = true)

theorem identity26147 : scanCanonicalize (H12AffineFastState.compose env26147 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound26147 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env26148 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,29962,46108,43048,1024,32769,45341,32800,41244,62478,8193,16,31757,46109,17665,32040,41992,54561,256,21792,46093,62989]

theorem envBound26148 : H12AffineFastState.Bounded env26148 := by
  intro p hp
  have h : env26148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26147_26148 : H12AffineEnvironment.transform 15 29962 env26147 = env26148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env26147 == env26148) = true)

theorem identity26148 : scanCanonicalize (H12AffineFastState.compose env26148 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26148 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env26149 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,21511,38161,35109,1024,32769,36880,32800,32785,54531,268,16,23808,38160,17665,23589,34053,54561,256,21792,38144,55040]

theorem envBound26149 : H12AffineFastState.Bounded env26149 := by
  intro p hp
  have h : env26149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26148_26149 : H12AffineEnvironment.transform 12 269 env26148 = env26149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26148 == env26149) = true)

theorem identity26149 : scanCanonicalize (H12AffineFastState.compose env26149 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound26149 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26150 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,21511,16400,23588,1024,21760,17681,21793,21776,2,268,16,23808,16401,17665,23589,20484,32,256,21792,16385,513]

theorem envBound26150 : H12AffineFastState.Bounded env26150 := by
  intro p hp
  have h : env26150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26149_26150 : H12AffineEnvironment.transform 14 21761 env26149 = env26150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env26149 == env26150) = true)

theorem identity26150 : scanCanonicalize (H12AffineFastState.compose env26150 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound26150 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env26151 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2048,269,16384,19713,19463,16400,17444,1024,19712,17681,19745,19728,2,268,16,17664,16401,17665,17445,18436,32,256,19744,16385,513]

theorem envBound26151 : H12AffineFastState.Bounded env26151 := by
  intro p hp
  have h : env26151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26150_26151 : H12AffineEnvironment.transform 11 2048 env26150 = env26151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env26150 == env26151) = true)

theorem identity26151 : scanCanonicalize (H12AffineFastState.compose env26151 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 3328) := by decide +kernel

theorem selectedBound26151 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26152 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2048,269,3328,1,263,3344,2340,1024,0,2065,33,16,2,268,16,2048,3345,2049,2341,1284,32,256,32,3329,513]

theorem envBound26152 : H12AffineFastState.Bounded env26152 := by
  intro p hp
  have h : env26152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26151_26152 : H12AffineEnvironment.transform 13 3328 env26151 = env26152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3328 env26151 == env26152) = true)

theorem identity26152 : scanCanonicalize (H12AffineFastState.compose env26152 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26153 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1,269,1281,1,263,1297,293,1024,0,16,33,16,2,268,16,1,1296,0,292,1284,32,256,32,1280,513]

theorem envBound26153 : H12AffineFastState.Bounded env26153 := by
  intro p hp
  have h : env26153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26152_26153 : H12AffineEnvironment.transform 10 1 env26152 = env26153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26152 == env26153) = true)

theorem identity26153 : scanCanonicalize (H12AffineFastState.compose env26153 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound26153 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26154 : List Nat := [2,4,8,16,32,17,9,256,512,768,1,1,269,513,1,263,529,293,768,0,16,33,16,2,268,16,1,528,0,292,516,32,256,32,512,513]

theorem envBound26154 : H12AffineFastState.Bounded env26154 := by
  intro p hp
  have h : env26154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26153_26154 : H12AffineEnvironment.transform 9 768 env26153 = env26154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env26153 == env26154) = true)

theorem identity26154 : scanCanonicalize (H12AffineFastState.compose env26154 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26154 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26155 : List Nat := [2,4,8,16,32,17,9,256,1,257,1,1,269,0,1,263,16,293,257,0,16,33,16,2,268,16,1,17,0,292,5,32,256,32,1,0]

theorem envBound26155 : H12AffineFastState.Bounded env26155 := by
  intro p hp
  have h : env26155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26154_26155 : H12AffineEnvironment.transform 8 1 env26154 = env26155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26154 == env26155) = true)

theorem identity26155 : scanCanonicalize (H12AffineFastState.compose env26155 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26155 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26156 : List Nat := [2,4,8,16,32,17,9,36,1,37,1,1,41,0,1,35,16,1,37,0,16,33,16,2,40,16,1,17,0,0,5,32,36,32,1,0]

theorem envBound26156 : H12AffineFastState.Bounded env26156 := by
  intro p hp
  have h : env26156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26155_26156 : H12AffineEnvironment.transform 7 36 env26155 = env26156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26155 == env26156) = true)

theorem identity26156 : scanCanonicalize (H12AffineFastState.compose env26156 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26156 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26157 : List Nat := [2,4,8,1,32,0,9,36,1,37,1,1,41,0,1,35,1,1,37,0,1,33,1,2,40,1,1,0,0,0,5,32,36,32,1,0]

theorem envBound26157 : H12AffineFastState.Bounded env26157 := by
  intro p hp
  have h : env26157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26156_26157 : H12AffineEnvironment.transform 3 1 env26156 = env26157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26156 == env26157) = true)

theorem identity26157 : scanCanonicalize (H12AffineFastState.compose env26157 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26158 : List Nat := [2,4,8,1,0,0,9,4,1,5,1,1,9,0,1,3,1,1,5,0,1,1,1,2,8,1,1,0,0,0,5,0,4,0,1,0]

theorem envBound26158 : H12AffineFastState.Bounded env26158 := by
  intro p hp
  have h : env26158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26157_26158 : H12AffineEnvironment.transform 4 0 env26157 = env26158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26157 == env26158) = true)

def env26159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441641,98781,8328,65,4259061,436264,17664,32041,440548,4606309,256,21792,46212,499507]

theorem envBound26159 : H12AffineFastState.Bounded env26159 := by
  intro p hp
  have h : env26159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26108_26159 : H12AffineEnvironment.transform 22 441641 env26108 = env26159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env26108 == env26159) = true)

def env26160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441641,98781,8328,65,316533,436264,17664,32041,440548,156133,256,21792,46212,499507]

theorem envBound26160 : H12AffineFastState.Bounded env26160 := by
  intro p hp
  have h : env26160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26159_26160 : H12AffineEnvironment.transform 21 272512 env26159 = env26160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26159 == env26160) = true)

theorem identity26160 : scanCanonicalize (H12AffineFastState.compose env26160 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26160 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437624,272512,441641,41430,8328,65,316533,436264,17664,32041,440548,156133,256,21792,46212,442168]

theorem envBound26161 : H12AffineFastState.Bounded env26161 := by
  intro p hp
  have h : env26161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26160_26161 : H12AffineEnvironment.transform 15 8203 env26160 = env26161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26160 == env26161) = true)

def env26162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437624,272392,441641,41310,8192,65,316533,436264,17664,32041,440428,156013,256,21792,46092,442168]

theorem envBound26162 : H12AffineFastState.Bounded env26162 := by
  intro p hp
  have h : env26162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26161_26162 : H12AffineEnvironment.transform 6 8 env26161 = env26162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26161 == env26162) = true)

theorem identity26162 : scanCanonicalize (H12AffineFastState.compose env26162 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound26162 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13389,262144,1024,32769,301365,272392,297316,41310,8192,65,316533,302181,17664,32041,298017,21792,256,21792,46092,297845]

theorem envBound26163 : H12AffineFastState.Bounded env26163 := by
  intro p hp
  have h : env26163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26162_26163 : H12AffineEnvironment.transform 16 13389 env26162 = env26163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env26162 == env26163) = true)

theorem identity26163 : scanCanonicalize (H12AffineFastState.compose env26163 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound26163 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,373,8203,13389,262144,1024,372,268352,272392,264209,8235,8192,65,283904,269584,17664,32041,265556,21792,256,21792,13689,264704]

theorem envBound26164 : H12AffineFastState.Bounded env26164 := by
  intro p hp
  have h : env26164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26163_26164 : H12AffineEnvironment.transform 14 373 env26163 = env26164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env26163 == env26164) = true)

theorem identity26164 : scanCanonicalize (H12AffineFastState.compose env26164 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound26164 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env26165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,373,8203,13389,262144,1024,372,268352,272392,264209,8235,8192,65,270685,269584,12637,2420,265556,8573,256,8573,13689,264704]

theorem envBound26165 : H12AffineFastState.Bounded env26165 := by
  intro p hp
  have h : env26165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26164_26165 : H12AffineEnvironment.transform 13 13405 env26164 = env26165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env26164 == env26165) = true)

theorem identity26165 : scanCanonicalize (H12AffineFastState.compose env26165 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound26165 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env26166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,373,8203,13389,2048,1024,372,4160,8200,17,8235,8192,65,10589,5392,12637,2420,1364,8573,256,8573,13689,512]

theorem envBound26166 : H12AffineFastState.Bounded env26166 := by
  intro p hp
  have h : env26166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26165_26166 : H12AffineEnvironment.transform 17 2048 env26165 = env26166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env26165 == env26166) = true)

theorem identity26166 : scanCanonicalize (H12AffineFastState.compose env26166 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound26166 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,5125,373,83,5141,2048,1024,372,4160,80,17,115,88,65,2309,5392,4357,2420,1364,293,256,293,5409,512]

theorem envBound26167 : H12AffineFastState.Bounded env26167 := by
  intro p hp
  have h : env26167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26166_26167 : H12AffineEnvironment.transform 12 88 env26166 = env26167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env26166 == env26167) = true)

theorem identity26167 : scanCanonicalize (H12AffineFastState.compose env26167 (packedSelected [6,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26167 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env26168 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,88,5125,81,83,5141,2048,1024,80,4160,80,17,115,88,65,2081,5172,4129,2128,1136,1,36,1,5125,512]

theorem envBound26168 : H12AffineFastState.Bounded env26168 := by
  intro p hp
  have h : env26168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26167_26168 : H12AffineEnvironment.transform 7 36 env26167 = env26168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26167 == env26168) = true)

theorem identity26168 : scanCanonicalize (H12AffineFastState.compose env26168 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound26168 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env26169 : List Nat := [2,4,8,16,32,64,8,36,512,1024,560,4096,88,5125,81,83,5141,560,1024,80,4160,80,17,115,88,65,529,5172,4129,608,1136,1,36,1,5125,512]

theorem envBound26169 : H12AffineFastState.Bounded env26169 := by
  intro p hp
  have h : env26169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26168_26169 : H12AffineEnvironment.transform 10 560 env26168 = env26169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env26168 == env26169) = true)

theorem identity26169 : scanCanonicalize (H12AffineFastState.compose env26169 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26169 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26170 : List Nat := [2,4,8,16,32,64,8,36,512,4,560,4096,88,4097,81,83,4113,560,4,80,4160,80,17,115,88,65,529,4144,4129,608,116,1,36,1,4097,512]

theorem envBound26170 : H12AffineFastState.Bounded env26170 := by
  intro p hp
  have h : env26170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26169_26170 : H12AffineEnvironment.transform 9 4 env26169 = env26170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26169 == env26170) = true)

theorem identity26170 : scanCanonicalize (H12AffineFastState.compose env26170 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound26170 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env26171 : List Nat := [2,4,8,16,32,64,8,36,512,4,560,113,88,112,81,83,96,560,4,80,49,80,17,115,88,65,529,65,80,608,116,1,36,1,112,512]

theorem envBound26171 : H12AffineFastState.Bounded env26171 := by
  intro p hp
  have h : env26171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26170_26171 : H12AffineEnvironment.transform 11 113 env26170 = env26171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env26170 == env26171) = true)

theorem identity26171 : scanCanonicalize (H12AffineFastState.compose env26171 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound26171 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env26172 : List Nat := [2,4,8,16,32,64,8,36,112,4,64,113,88,112,81,83,96,64,4,80,49,80,17,115,88,65,97,65,80,16,116,1,36,1,112,112]

theorem envBound26172 : H12AffineFastState.Bounded env26172 := by
  intro p hp
  have h : env26172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26171_26172 : H12AffineEnvironment.transform 8 112 env26171 = env26172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env26171 == env26172) = true)

def env26173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437624,272393,441641,41311,8193,65,316533,436264,17664,32041,440429,156012,256,21792,46093,442168]

theorem envBound26173 : H12AffineFastState.Bounded env26173 := by
  intro p hp
  have h : env26173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26161_26173 : H12AffineEnvironment.transform 6 9 env26161 = env26173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26161 == env26173) = true)

theorem identity26173 : scanCanonicalize (H12AffineFastState.compose env26173 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound26173 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1024,32769,276585,272393,272440,41311,8193,65,316533,277817,17664,32041,273788,62589,256,21792,46093,272937]

theorem envBound26174 : H12AffineFastState.Bounded env26174 := by
  intro p hp
  have h : env26174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26173_26174 : H12AffineEnvironment.transform 16 38161 env26173 = env26174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env26173 == env26174) = true)

def env26175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441641,98781,8328,65,316532,436264,17664,32041,440548,156132,256,21792,46212,499507]

theorem envBound26175 : H12AffineFastState.Bounded env26175 := by
  intro p hp
  have h : env26175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26159_26175 : H12AffineEnvironment.transform 21 272513 env26159 = env26175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26159 == env26175) = true)

theorem identity26175 : scanCanonicalize (H12AffineFastState.compose env26175 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound26175 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77898,243123,73755,98781,8328,65,215366,79130,17664,32041,75222,156132,256,21792,46212,513]

theorem envBound26176 : H12AffineFastState.Bounded env26176 := by
  intro p hp
  have h : env26176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26175_26176 : H12AffineEnvironment.transform 17 236850 env26175 = env26176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env26175 == env26176) = true)

def env26177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77898,243003,73755,98645,8192,65,215366,79130,17664,32041,75102,156012,256,21792,46092,513]

theorem envBound26177 : H12AffineFastState.Bounded env26177 := by
  intro p hp
  have h : env26177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26176_26177 : H12AffineEnvironment.transform 6 8 env26176 = env26177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26176 == env26177) = true)

theorem identity26177 : scanCanonicalize (H12AffineFastState.compose env26177 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound26177 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,64808,1024,32769,77898,54561,73755,98645,8192,65,10588,79130,17664,32041,75102,65910,256,21792,46092,513]

theorem envBound26178 : H12AffineFastState.Bounded env26178 := by
  intro p hp
  have h : env26178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26177_26178 : H12AffineEnvironment.transform 16 90138 env26177 = env26178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env26177 == env26178) = true)

theorem identity26178 : scanCanonicalize (H12AffineFastState.compose env26178 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 42314) := by decide +kernel

theorem selectedBound26178 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env26179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,42314,50512,64808,1024,32769,38144,54561,34129,9247,8192,65,10588,36944,17664,32041,32788,42044,256,21792,46092,513]

theorem envBound26179 : H12AffineFastState.Bounded env26179 := by
  intro p hp
  have h : env26179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26178_26179 : H12AffineEnvironment.transform 15 42314 env26178 = env26179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 42314 env26178 == env26179) = true)

theorem identity26179 : scanCanonicalize (H12AffineFastState.compose env26179 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound26179 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env26180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,32768,34147,50512,56577,1024,32769,38144,54561,34129,1078,41,65,2421,36944,17664,23808,32788,33813,256,21792,37925,513]

theorem envBound26180 : H12AffineFastState.Bounded env26180 := by
  intro p hp
  have h : env26180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26179_26180 : H12AffineEnvironment.transform 12 41 env26179 = env26180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env26179 == env26180) = true)

theorem identity26180 : scanCanonicalize (H12AffineFastState.compose env26180 (packedSelected [0,1,3,7,11,12,15,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound26180 : packedSelected [0,1,3,7,11,12,15,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env26181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,1296,115,16448,22545,1024,1297,4112,20529,65,1078,41,65,2421,5440,17664,23808,1284,261,256,21792,4405,513]

theorem envBound26181 : H12AffineFastState.Bounded env26181 := by
  intro p hp
  have h : env26181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26180_26181 : H12AffineEnvironment.transform 14 1296 env26180 = env26181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env26180 == env26181) = true)

theorem identity26181 : scanCanonicalize (H12AffineFastState.compose env26181 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound26181 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env26182 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,16384,0,115,16448,22545,272,1,4112,20529,65,294,41,65,2421,4176,16400,22544,20,261,256,20528,4405,513]

theorem envBound26182 : H12AffineFastState.Bounded env26182 := by
  intro p hp
  have h : env26182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26181_26182 : H12AffineEnvironment.transform 9 272 env26181 = env26182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env26181 == env26182) = true)

theorem identity26182 : scanCanonicalize (H12AffineFastState.compose env26182 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26182 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26183 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,41,16384,0,115,16448,22545,100,1,4112,20529,65,82,41,65,2049,4176,16400,22544,20,113,116,20528,4161,513]

theorem envBound26183 : H12AffineFastState.Bounded env26183 := by
  intro p hp
  have h : env26183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26182_26183 : H12AffineEnvironment.transform 7 116 env26182 = env26183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26182 == env26183) = true)

theorem identity26183 : scanCanonicalize (H12AffineFastState.compose env26183 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound26183 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env26184 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,41,4112,0,115,4176,2049,100,1,4112,33,65,82,41,65,2049,4176,4096,2048,20,113,116,32,4161,513]

theorem envBound26184 : H12AffineFastState.Bounded env26184 := by
  intro p hp
  have h : env26184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26183_26184 : H12AffineEnvironment.transform 13 4112 env26183 = env26184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env26183 == env26184) = true)

theorem identity26184 : scanCanonicalize (H12AffineFastState.compose env26184 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26185 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,0,35,4096,2049,52,1,4112,33,17,2,41,17,2049,4096,4096,2048,20,33,36,32,4113,513]

theorem envBound26185 : H12AffineFastState.Bounded env26185 := by
  intro p hp
  have h : env26185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26184_26185 : H12AffineEnvironment.transform 5 16 env26184 = env26185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26184 == env26185) = true)

theorem identity26185 : scanCanonicalize (H12AffineFastState.compose env26185 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26185 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26186 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,41,2049,0,35,2065,2049,52,1,2049,33,17,2,41,17,2049,2065,2065,2048,20,33,36,32,2048,513]

theorem envBound26186 : H12AffineFastState.Bounded env26186 := by
  intro p hp
  have h : env26186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26185_26186 : H12AffineEnvironment.transform 11 2065 env26185 = env26186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env26185 == env26186) = true)

theorem identity26186 : scanCanonicalize (H12AffineFastState.compose env26186 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound26186 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26187 : List Nat := [2,4,8,16,32,16,8,36,26,52,2048,2065,41,2049,0,35,2065,2049,52,1,2049,33,17,2,41,17,2049,2065,2065,2048,20,33,36,32,2048,27]

theorem envBound26187 : H12AffineFastState.Bounded env26187 := by
  intro p hp
  have h : env26187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26186_26187 : H12AffineEnvironment.transform 8 26 env26186 = env26187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env26186 == env26187) = true)

def env26188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77898,243002,73755,98644,8193,65,215366,79130,17664,32041,75103,156013,256,21792,46093,513]

theorem envBound26188 : H12AffineFastState.Bounded env26188 := by
  intro p hp
  have h : env26188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26176_26188 : H12AffineEnvironment.transform 6 9 env26176 = env26188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26176 == env26188) = true)

theorem identity26188 : scanCanonicalize (H12AffineFastState.compose env26188 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound26188 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,67619,1024,32769,77898,73771,73755,98644,8193,65,121943,79130,17664,32041,75103,62588,256,21792,46093,513]

theorem envBound26189 : H12AffineFastState.Bounded env26189 := by
  intro p hp
  have h : env26189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26188_26189 : H12AffineEnvironment.transform 16 38161 env26188 = env26189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env26188 == env26189) = true)

theorem identity26189 : scanCanonicalize (H12AffineFastState.compose env26189 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26189 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1024,32769,4160,33,17,41310,8193,65,64605,5392,17664,32041,1365,62588,256,21792,46093,513]

theorem envBound26190 : H12AffineFastState.Bounded env26190 := by
  intro p hp
  have h : env26190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26189_26190 : H12AffineEnvironment.transform 15 8202 env26189 = env26190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26189 == env26190) = true)

theorem identity26190 : scanCanonicalize (H12AffineFastState.compose env26190 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound26190 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,8202,5440,10281,1024,80,4160,33,17,8463,8193,65,31756,5392,17664,32041,1365,29741,256,21792,13404,513]

theorem envBound26191 : H12AffineFastState.Bounded env26191 := by
  intro p hp
  have h : env26191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26190_26191 : H12AffineEnvironment.transform 14 81 env26190 = env26191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env26190 == env26191) = true)

def env26192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,8388608,8862965,8328,65,4259060,8393984,8845353,8830976,440549,12645453,256,21793,46213,499506]

theorem envBound26192 : H12AffineFastState.Bounded env26192 := by
  intro p hp
  have h : env26192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26107_26192 : H12AffineEnvironment.transform 23 8862965 env26107 = env26192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862965 env26107 == env26192) = true)

def env26193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441640,98781,8328,65,4259060,436264,17665,32040,440549,4606309,256,21793,46213,499506]

theorem envBound26193 : H12AffineFastState.Bounded env26193 := by
  intro p hp
  have h : env26193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26192_26193 : H12AffineEnvironment.transform 22 441640 env26192 = env26193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env26192 == env26193) = true)

def env26194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441640,98781,8328,65,316532,436264,17665,32040,440549,156133,256,21793,46213,499506]

theorem envBound26194 : H12AffineFastState.Bounded env26194 := by
  intro p hp
  have h : env26194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26193_26194 : H12AffineEnvironment.transform 21 272512 env26193 = env26194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26193 == env26194) = true)

theorem identity26194 : scanCanonicalize (H12AffineFastState.compose env26194 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound26194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169400,16,98781,8328,65,158028,5392,17665,32040,1501,156133,256,21793,46213,74250]

theorem envBound26195 : H12AffineFastState.Bounded env26195 := by
  intro p hp
  have h : env26195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26194_26195 : H12AffineEnvironment.transform 17 179512 env26194 = env26195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env26194 == env26195) = true)

theorem identity26195 : scanCanonicalize (H12AffineFastState.compose env26195 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26195 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env26196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,169400,16,41430,8328,65,158028,5392,17665,32040,1501,156133,256,21793,46213,513]

theorem envBound26196 : H12AffineFastState.Bounded env26196 := by
  intro p hp
  have h : env26196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26195_26196 : H12AffineEnvironment.transform 15 8203 env26195 = env26196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26195 == env26196) = true)

def env26197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441640,98781,8328,65,316533,436264,17665,32040,440549,156132,256,21793,46213,499506]

theorem envBound26197 : H12AffineFastState.Bounded env26197 := by
  intro p hp
  have h : env26197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26193_26197 : H12AffineEnvironment.transform 21 272513 env26193 = env26197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26193 == env26197) = true)

def env26198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272393,441640,98645,8192,65,316533,436264,17665,32040,440429,156012,256,21793,46093,499506]

theorem envBound26198 : H12AffineFastState.Bounded env26198 := by
  intro p hp
  have h : env26198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26197_26198 : H12AffineEnvironment.transform 6 8 env26197 = env26198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26197 == env26198) = true)

theorem identity26198 : scanCanonicalize (H12AffineFastState.compose env26198 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound26198 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,322920,272393,326968,98645,8192,65,316533,321592,17665,32040,325757,8572,256,21793,46093,384802]

theorem envBound26199 : H12AffineFastState.Bounded env26199 := by
  intro p hp
  have h : env26199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26198_26199 : H12AffineEnvironment.transform 16 16400 env26198 = env26199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env26198 == env26199) = true)

def env26200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1024,21761,276584,272393,272440,87125,8192,65,262517,277816,17665,32040,273789,8572,256,21793,24845,330274]

theorem envBound26200 : H12AffineFastState.Bounded env26200 := by
  intro p hp
  have h : env26200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26199_26200 : H12AffineEnvironment.transform 14 21760 env26199 = env26200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env26199 == env26200) = true)

theorem identity26200 : scanCanonicalize (H12AffineFastState.compose env26200 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound26200 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16400,97406,1024,21761,82966,87159,87110,87125,8192,65,97547,82246,17665,32040,86275,8572,256,21793,24845,30300]

theorem envBound26201 : H12AffineFastState.Bounded env26201 := by
  intro p hp
  have h : env26201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26200_26201 : H12AffineEnvironment.transform 17 97406 env26200 = env26201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env26200 == env26201) = true)

theorem identity26201 : scanCanonicalize (H12AffineFastState.compose env26201 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26201 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,16400,23668,1024,21761,25628,29821,29772,29791,8192,65,23809,24908,17665,32040,28937,8572,256,21793,24845,30300]

theorem envBound26202 : H12AffineFastState.Bounded env26202 := by
  intro p hp
  have h : env26202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26201_26202 : H12AffineEnvironment.transform 15 8202 env26201 = env26202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26201 == env26202) = true)

theorem identity26202 : scanCanonicalize (H12AffineFastState.compose env26202 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound26202 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8460,8202,13340,10360,1024,8461,4112,113,64,83,8192,65,10509,5440,12557,2340,1285,8572,256,8493,5377,592]

theorem envBound26203 : H12AffineFastState.Bounded env26203 := by
  intro p hp
  have h : env26203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26202_26203 : H12AffineEnvironment.transform 13 13324 env26202 = env26203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env26202 == env26203) = true)

theorem identity26203 : scanCanonicalize (H12AffineFastState.compose env26203 (packedSelected [0,6,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26203 : packedSelected [0,6,7,12] rootPS < 2^1333 := by decide +kernel

def env26204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,13324,8460,8202,13340,8313,1024,8461,4112,113,64,83,8192,65,8460,5440,12557,293,1285,8572,256,8493,5377,592]

theorem envBound26204 : H12AffineFastState.Bounded env26204 := by
  intro p hp
  have h : env26204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26203_26204 : H12AffineEnvironment.transform 10 1 env26203 = env26204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26203 == env26204) = true)

theorem identity26204 : scanCanonicalize (H12AffineFastState.compose env26204 (packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound26204 : packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env26205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,65,8192,9293,8460,8202,9309,8313,1024,8461,81,113,64,83,8192,65,8460,1281,8524,293,1285,8572,256,8493,1344,592]

theorem envBound26205 : H12AffineFastState.Bounded env26205 := by
  intro p hp
  have h : env26205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26204_26205 : H12AffineEnvironment.transform 11 65 env26204 = env26205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env26204 == env26205) = true)

theorem identity26205 : scanCanonicalize (H12AffineFastState.compose env26205 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound26205 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,65,1100,1,1344,1094,17,1077,1024,1345,81,113,64,83,1100,65,1344,1281,1280,293,1285,1328,256,1377,1344,592]

theorem envBound26206 : H12AffineFastState.Bounded env26206 := by
  intro p hp
  have h : env26206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26205_26206 : H12AffineEnvironment.transform 12 1100 env26205 = env26206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env26205 == env26206) = true)

theorem identity26206 : scanCanonicalize (H12AffineFastState.compose env26206 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26206 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env26207 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1,65,1100,1,1077,1094,17,1077,1024,1076,81,113,64,83,1100,65,1077,1140,1141,80,1136,1093,117,1044,1077,592]

theorem envBound26207 : H12AffineFastState.Bounded env26207 := by
  intro p hp
  have h : env26207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26206_26207 : H12AffineEnvironment.transform 7 117 env26206 = env26207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26206 == env26207) = true)

theorem identity26207 : scanCanonicalize (H12AffineFastState.compose env26207 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26207 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env26208 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1,16,1053,1,1077,1047,17,1077,1024,1076,0,32,17,2,1053,16,1077,1061,1060,1,1057,1044,36,1044,1077,513]

theorem envBound26208 : H12AffineFastState.Bounded env26208 := by
  intro p hp
  have h : env26208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26207_26208 : H12AffineEnvironment.transform 5 17 env26207 = env26208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26207 == env26208) = true)

theorem identity26208 : scanCanonicalize (H12AffineFastState.compose env26208 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26208 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26209 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,16,41,1,1,35,17,1,52,0,0,32,17,2,41,16,1,17,16,1,21,32,36,32,1,513]

theorem envBound26209 : H12AffineFastState.Bounded env26209 := by
  intro p hp
  have h : env26209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26208_26209 : H12AffineEnvironment.transform 9 52 env26208 = env26209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26208 == env26209) = true)

theorem identity26209 : scanCanonicalize (H12AffineFastState.compose env26209 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26210 : List Nat := [2,4,8,16,16,17,8,20,512,4,1,16,25,1,1,19,17,1,4,0,0,16,17,2,25,16,1,17,16,1,21,16,20,16,1,513]

theorem envBound26210 : H12AffineFastState.Bounded env26210 := by
  intro p hp
  have h : env26210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26209_26210 : H12AffineEnvironment.transform 4 16 env26209 = env26210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26209 == env26210) = true)

theorem identity26210 : scanCanonicalize (H12AffineFastState.compose env26210 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26211 : List Nat := [2,4,8,16,16,17,8,20,0,4,1,16,25,1,1,19,17,1,4,0,0,16,17,2,25,16,1,17,16,1,21,16,20,16,1,1]

theorem envBound26211 : H12AffineFastState.Bounded env26211 := by
  intro p hp
  have h : env26211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26210_26211 : H12AffineEnvironment.transform 8 0 env26210 = env26211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26210 == env26211) = true)

def env26212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1024,21760,276585,272393,272441,87124,8192,65,262516,277817,17665,32040,273788,8572,256,21793,24844,330275]

theorem envBound26212 : H12AffineFastState.Bounded env26212 := by
  intro p hp
  have h : env26212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26199_26212 : H12AffineEnvironment.transform 14 21761 env26199 = env26212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env26199 == env26212) = true)

theorem identity26212 : scanCanonicalize (H12AffineFastState.compose env26212 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound26212 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21590,16400,262144,1024,21760,276585,272393,272441,2,8192,65,262516,277817,17665,32040,273788,8572,256,21793,24844,286325]

theorem envBound26213 : H12AffineFastState.Bounded env26213 := by
  intro p hp
  have h : env26213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26212_26213 : H12AffineEnvironment.transform 15 21590 env26212 = env26213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env26212 == env26213) = true)

theorem identity26213 : scanCanonicalize (H12AffineFastState.compose env26213 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound26213 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env26214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21590,16400,2421,1024,21760,12572,8572,8524,2,8192,65,2049,13388,17665,32040,9225,8572,256,21793,24844,22272]

theorem envBound26214 : H12AffineFastState.Bounded env26214 := by
  intro p hp
  have h : env26214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26213_26214 : H12AffineEnvironment.transform 17 2421 env26213 = env26214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env26213 == env26214) = true)

theorem identity26214 : scanCanonicalize (H12AffineFastState.compose env26214 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26214 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env26215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,8202,13388,2421,1024,8540,12572,8572,8524,2,8192,65,2049,13388,12637,2420,9225,8572,256,8573,5456,9052]

theorem envBound26215 : H12AffineFastState.Bounded env26215 := by
  intro p hp
  have h : env26215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26214_26215 : H12AffineEnvironment.transform 13 13404 env26214 = env26215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26214 == env26215) = true)

theorem identity26215 : scanCanonicalize (H12AffineFastState.compose env26215 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26215 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env26216 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13404,8232,8202,13388,2048,1024,8233,12393,8201,8249,2,8192,65,2049,13388,12328,2049,9225,8201,117,8200,5157,8745]

theorem envBound26216 : H12AffineFastState.Bounded env26216 := by
  intro p hp
  have h : env26216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26215_26216 : H12AffineEnvironment.transform 7 117 env26215 = env26216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26215 == env26216) = true)

theorem identity26216 : scanCanonicalize (H12AffineFastState.compose env26216 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26216 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26217 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,13324,8232,8202,13340,2048,1024,8233,12345,8201,8249,2,8192,17,2049,13340,12328,2049,9225,8201,37,8200,5157,8745]

theorem envBound26217 : H12AffineFastState.Bounded env26217 := by
  intro p hp
  have h : env26217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26216_26217 : H12AffineEnvironment.transform 5 16 env26216 = env26217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26216 == env26217) = true)

theorem identity26217 : scanCanonicalize (H12AffineFastState.compose env26217 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound26217 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env26218 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,1052,4112,1076,1046,4096,2048,1024,1077,5157,1045,1061,2,1052,17,2049,4096,5172,2049,21,1045,37,1044,5157,1589]

theorem envBound26218 : H12AffineFastState.Bounded env26218 := by
  intro p hp
  have h : env26218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26217_26218 : H12AffineEnvironment.transform 12 1052 env26217 = env26218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env26217 == env26218) = true)

theorem identity26218 : scanCanonicalize (H12AffineFastState.compose env26218 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26218 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26219 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4112,0,34,4096,2048,52,1,4113,33,17,2,40,17,2049,4096,4096,2049,21,33,37,32,4113,513]

theorem envBound26219 : H12AffineFastState.Bounded env26219 := by
  intro p hp
  have h : env26219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26218_26219 : H12AffineEnvironment.transform 9 52 env26218 = env26219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26218 == env26219) = true)

theorem identity26219 : scanCanonicalize (H12AffineFastState.compose env26219 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound26219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26220 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,513,40,529,0,34,513,2048,52,1,528,33,17,2,40,17,2049,513,513,2049,21,33,37,32,528,513]

theorem envBound26220 : H12AffineFastState.Bounded env26220 := by
  intro p hp
  have h : env26220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26219_26220 : H12AffineEnvironment.transform 11 513 env26219 = env26220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env26219 == env26220) = true)

theorem identity26220 : scanCanonicalize (H12AffineFastState.compose env26220 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound26220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26221 : List Nat := [2,4,8,16,32,16,8,37,512,52,11,513,40,529,0,34,513,11,52,1,528,33,17,2,40,17,10,513,513,10,21,33,37,32,528,513]

theorem envBound26221 : H12AffineFastState.Bounded env26221 := by
  intro p hp
  have h : env26221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26220_26221 : H12AffineEnvironment.transform 10 11 env26220 = env26221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env26220 == env26221) = true)

theorem identity26221 : scanCanonicalize (H12AffineFastState.compose env26221 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26221 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26222 : List Nat := [2,4,8,16,32,16,8,37,27,52,11,26,40,10,0,34,26,11,52,1,11,33,17,2,40,17,10,26,26,10,21,33,37,32,11,26]

theorem envBound26222 : H12AffineFastState.Bounded env26222 := by
  intro p hp
  have h : env26222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26221_26222 : H12AffineEnvironment.transform 8 27 env26221 = env26222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26221 == env26222) = true)

def env26223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272392,441640,98644,8193,65,316533,436264,17665,32040,440428,156013,256,21793,46092,499506]

theorem envBound26223 : H12AffineFastState.Bounded env26223 := by
  intro p hp
  have h : env26223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26197_26223 : H12AffineEnvironment.transform 6 9 env26197 = env26223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26197 == env26223) = true)

theorem identity26223 : scanCanonicalize (H12AffineFastState.compose env26223 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound26223 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243003,73755,98644,8193,65,215366,79131,17665,32040,75103,156013,256,21793,46092,513]

theorem envBound26224 : H12AffineFastState.Bounded env26224 := by
  intro p hp
  have h : env26224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26223_26224 : H12AffineEnvironment.transform 17 236851 env26223 = env26224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env26223 == env26224) = true)

theorem identity26224 : scanCanonicalize (H12AffineFastState.compose env26224 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound26224 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,67619,1024,32769,77899,73771,73755,98644,8193,65,121942,79131,17665,32040,75103,62589,256,21793,46092,513]

theorem envBound26225 : H12AffineFastState.Bounded env26225 := by
  intro p hp
  have h : env26225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26224_26225 : H12AffineEnvironment.transform 16 38160 env26224 = env26225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env26224 == env26225) = true)

theorem identity26225 : scanCanonicalize (H12AffineFastState.compose env26225 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26225 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1024,32769,4161,33,17,41310,8193,65,64604,5393,17665,32040,1365,62589,256,21793,46092,513]

theorem envBound26226 : H12AffineFastState.Bounded env26226 := by
  intro p hp
  have h : env26226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26225_26226 : H12AffineEnvironment.transform 15 8202 env26225 = env26226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26225 == env26226) = true)

theorem identity26226 : scanCanonicalize (H12AffineFastState.compose env26226 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound26226 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,8202,5441,10281,1024,80,4161,33,17,8463,8193,65,31757,5393,17665,32040,1365,29740,256,21793,13405,513]

theorem envBound26227 : H12AffineFastState.Bounded env26227 := by
  intro p hp
  have h : env26227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26226_26227 : H12AffineEnvironment.transform 14 81 env26226 = env26227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env26226 == env26227) = true)

def env26228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441641,98780,8328,65,4259060,436265,17664,32041,440549,4606308,256,21793,46213,499506]

theorem envBound26228 : H12AffineFastState.Bounded env26228 := by
  intro p hp
  have h : env26228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26192_26228 : H12AffineEnvironment.transform 22 441641 env26192 = env26228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env26192 == env26228) = true)

def env26229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441641,98780,8328,65,316532,436265,17664,32041,440549,156132,256,21793,46213,499506]

theorem envBound26229 : H12AffineFastState.Bounded env26229 := by
  intro p hp
  have h : env26229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26228_26229 : H12AffineEnvironment.transform 21 272512 env26228 = env26229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26228 == env26229) = true)

theorem identity26229 : scanCanonicalize (H12AffineFastState.compose env26229 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound26229 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,58516,156012,62661,98780,8328,65,171416,57797,17664,32041,61705,156132,256,21793,46213,120542]

theorem envBound26230 : H12AffineFastState.Bounded env26230 := by
  intro p hp
  have h : env26230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26229_26230 : H12AffineEnvironment.transform 17 149996 env26229 = env26230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env26229 == env26230) = true)

def env26231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56572,1024,32769,58516,62588,62661,98780,8328,65,2184,57797,17664,32041,61705,62708,256,21793,46213,120542]

theorem envBound26231 : H12AffineFastState.Bounded env26231 := by
  intro p hp
  have h : env26231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26230_26231 : H12AffineEnvironment.transform 16 38160 env26230 = env26231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env26230 == env26231) = true)

def env26232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35324,1024,32769,45460,41340,41413,98780,8328,65,2184,46277,4096,10281,41993,41460,256,33,46213,99294]

theorem envBound26232 : H12AffineFastState.Bounded env26232 := by
  intro p hp
  have h : env26232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26231_26232 : H12AffineEnvironment.transform 13 5376 env26231 = env26232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26231 == env26232) = true)

theorem identity26232 : scanCanonicalize (H12AffineFastState.compose env26232 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound26232 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33110,38160,35324,1024,32769,45460,41340,41413,138,8328,65,2184,46277,4096,10281,41993,41460,256,33,46213,648]

theorem envBound26233 : H12AffineFastState.Bounded env26233 := by
  intro p hp
  have h : env26233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26232_26233 : H12AffineEnvironment.transform 15 33110 env26232 = env26233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env26232 == env26233) = true)

theorem identity26233 : scanCanonicalize (H12AffineFastState.compose env26233 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26233 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env26234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10401,1024,8540,4297,33,152,138,8328,65,2184,5528,4096,10281,1364,169,256,33,5592,648]

theorem envBound26234 : H12AffineFastState.Bounded env26234 := by
  intro p hp
  have h : env26234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26233_26234 : H12AffineEnvironment.transform 14 8541 env26233 = env26234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26233 == env26234) = true)

theorem identity26234 : scanCanonicalize (H12AffineFastState.compose env26234 (packedSelected [2,3,4,5,9,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound26234 : packedSelected [2,3,4,5,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env26235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5376,509,171,5357,2049,1024,508,4297,33,152,138,40,65,2184,5528,4096,2185,1364,169,256,33,5592,648]

theorem envBound26235 : H12AffineFastState.Bounded env26235 := by
  intro p hp
  have h : env26235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26234_26235 : H12AffineEnvironment.transform 12 160 env26234 = env26235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env26234 == env26235) = true)

theorem identity26235 : scanCanonicalize (H12AffineFastState.compose env26235 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1261) := by decide +kernel

theorem selectedBound26235 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env26236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1261,4096,160,5376,509,171,5357,1260,1024,508,4297,33,152,138,40,65,1125,5528,4096,1124,1364,169,256,33,5592,648]

theorem envBound26236 : H12AffineFastState.Bounded env26236 := by
  intro p hp
  have h : env26236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26235_26236 : H12AffineEnvironment.transform 10 1261 env26235 = env26236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1261 env26235 == env26236) = true)

theorem identity26236 : scanCanonicalize (H12AffineFastState.compose env26236 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26236 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26237 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1261,4096,160,5237,136,171,5357,1260,1024,137,4297,33,152,138,40,65,1125,5357,4096,1124,1057,169,117,33,5293,648]

theorem envBound26237 : H12AffineFastState.Bounded env26237 := by
  intro p hp
  have h : env26237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26236_26237 : H12AffineEnvironment.transform 7 117 env26236 = env26237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26236 == env26237) = true)

theorem identity26237 : scanCanonicalize (H12AffineFastState.compose env26237 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound26237 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env26238 : List Nat := [2,4,8,16,32,64,128,117,512,188,81,4096,160,4297,136,171,4177,80,188,137,4297,33,152,138,40,65,217,4177,4096,216,157,169,117,33,4113,648]

theorem envBound26238 : H12AffineFastState.Bounded env26238 := by
  intro p hp
  have h : env26238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26237_26238 : H12AffineEnvironment.transform 9 188 env26237 = env26238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env26237 == env26238) = true)

theorem identity26238 : scanCanonicalize (H12AffineFastState.compose env26238 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound26238 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26239 : List Nat := [2,4,8,16,32,64,128,117,512,188,81,152,160,81,136,171,201,80,188,137,81,33,152,138,40,65,217,201,152,216,157,169,117,33,137,648]

theorem envBound26239 : H12AffineFastState.Bounded env26239 := by
  intro p hp
  have h : env26239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26238_26239 : H12AffineEnvironment.transform 11 152 env26238 = env26239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env26238 == env26239) = true)

theorem identity26239 : scanCanonicalize (H12AffineFastState.compose env26239 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26239 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env26240 : List Nat := [2,4,8,16,32,64,9,117,512,53,81,17,41,81,1,34,64,80,53,0,81,33,17,3,40,65,80,64,17,81,20,32,117,33,0,513]

theorem envBound26240 : H12AffineFastState.Bounded env26240 := by
  intro p hp
  have h : env26240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26239_26240 : H12AffineEnvironment.transform 6 9 env26239 = env26240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26239 == env26240) = true)

theorem identity26240 : scanCanonicalize (H12AffineFastState.compose env26240 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26241 : List Nat := [2,4,8,1,32,64,9,100,512,36,64,0,41,64,1,34,64,65,36,0,64,33,0,3,40,65,65,64,0,64,5,32,100,33,0,513]

theorem envBound26241 : H12AffineFastState.Bounded env26241 := by
  intro p hp
  have h : env26241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26240_26241 : H12AffineEnvironment.transform 3 1 env26240 = env26241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26240 == env26241) = true)

theorem identity26241 : scanCanonicalize (H12AffineFastState.compose env26241 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound26241 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26242 : List Nat := [2,4,8,1,32,64,9,100,65,36,64,0,41,64,1,34,64,65,36,0,64,33,0,3,40,65,65,64,0,64,5,32,100,33,0,64]

theorem envBound26242 : H12AffineFastState.Bounded env26242 := by
  intro p hp
  have h : env26242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26241_26242 : H12AffineEnvironment.transform 8 65 env26241 = env26242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env26241 == env26242) = true)

theorem identity26242 : scanCanonicalize (H12AffineFastState.compose env26242 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound26242 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26243 : List Nat := [2,4,8,1,32,0,9,36,1,36,0,0,41,0,1,34,0,1,36,0,0,33,0,3,40,1,1,0,0,0,5,32,36,33,0,0]

theorem envBound26243 : H12AffineFastState.Bounded env26243 := by
  intro p hp
  have h : env26243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26242_26243 : H12AffineEnvironment.transform 5 0 env26242 = env26243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env26242 == env26243) = true)

def env26244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38160,35325,1024,32769,45461,41341,41412,98780,8328,65,2184,46276,4097,10280,41992,41461,256,32,46213,99295]

theorem envBound26244 : H12AffineFastState.Bounded env26244 := by
  intro p hp
  have h : env26244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26231_26244 : H12AffineEnvironment.transform 13 5377 env26231 = env26244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26231 == env26244) = true)

theorem identity26244 : scanCanonicalize (H12AffineFastState.compose env26244 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound26244 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,38160,35325,1024,32769,45461,41341,41412,2,8328,65,2184,46276,4097,10280,41992,41461,256,32,46213,513]

theorem envBound26245 : H12AffineFastState.Bounded env26245 := by
  intro p hp
  have h : env26245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26244_26245 : H12AffineEnvironment.transform 15 33246 env26244 = env26245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env26244 == env26245) = true)

theorem identity26245 : scanCanonicalize (H12AffineFastState.compose env26245 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26245 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env26246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8323,13389,10400,1024,8540,4296,32,153,2,8328,65,2184,5529,4097,10280,1365,168,256,32,5592,513]

theorem envBound26246 : H12AffineFastState.Bounded env26246 := by
  intro p hp
  have h : env26246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26245_26246 : H12AffineEnvironment.transform 14 8541 env26245 = env26246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26245 == env26246) = true)

theorem identity26246 : scanCanonicalize (H12AffineFastState.compose env26246 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26246 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,81,399,5441,2476,1024,80,4296,32,153,2,388,65,2184,5529,4097,2340,1365,168,256,32,5592,513]

theorem envBound26247 : H12AffineFastState.Bounded env26247 := by
  intro p hp
  have h : env26247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26246_26247 : H12AffineEnvironment.transform 12 268 env26246 = env26247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26246 == env26247) = true)

theorem identity26247 : scanCanonicalize (H12AffineFastState.compose env26247 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26247 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,262,5441,2341,1024,80,4161,32,16,2,269,65,2049,5392,4097,2340,1365,33,256,32,5457,513]

theorem envBound26248 : H12AffineFastState.Bounded env26248 := by
  intro p hp
  have h : env26248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26247_26248 : H12AffineEnvironment.transform 6 9 env26247 = env26248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26247 == env26248) = true)

theorem identity26248 : scanCanonicalize (H12AffineFastState.compose env26248 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound26248 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,821,4096,268,5377,81,262,5441,528,1024,80,4161,32,16,2,269,65,820,5392,4097,529,1365,33,256,32,5457,513]

theorem envBound26249 : H12AffineFastState.Bounded env26249 := by
  intro p hp
  have h : env26249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26248_26249 : H12AffineEnvironment.transform 10 821 env26248 = env26249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env26248 == env26249) = true)

theorem identity26249 : scanCanonicalize (H12AffineFastState.compose env26249 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26249 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26250 : List Nat := [2,4,8,16,0,64,9,256,512,1024,789,4096,268,5377,81,262,5441,528,1024,80,4161,0,16,2,269,65,788,5392,4097,529,1365,1,256,0,5457,513]

theorem envBound26250 : H12AffineFastState.Bounded env26250 := by
  intro p hp
  have h : env26250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26249_26250 : H12AffineEnvironment.transform 4 0 env26249 = env26250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26249 == env26250) = true)

theorem identity26250 : scanCanonicalize (H12AffineFastState.compose env26250 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26250 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26251 : List Nat := [2,4,8,16,0,1,9,256,512,1024,789,4096,268,5377,16,262,5376,528,1024,17,4096,0,16,2,269,0,788,5392,4097,529,1300,1,256,0,5392,513]

theorem envBound26251 : H12AffineFastState.Bounded env26251 := by
  intro p hp
  have h : env26251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26250_26251 : H12AffineEnvironment.transform 5 1 env26250 = env26251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26250 == env26251) = true)

def env26252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56573,1024,32769,58516,62589,62661,98780,8328,65,2185,57797,17664,32041,61705,62709,256,21793,46213,120542]

theorem envBound26252 : H12AffineFastState.Bounded env26252 := by
  intro p hp
  have h : env26252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26230_26252 : H12AffineEnvironment.transform 16 38161 env26230 = env26252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env26230 == env26252) = true)

def env26253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35325,1024,32769,45460,41341,41413,98780,8328,65,2185,46277,4096,10281,41993,41461,256,33,46213,99294]

theorem envBound26253 : H12AffineFastState.Bounded env26253 := by
  intro p hp
  have h : env26253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26252_26253 : H12AffineEnvironment.transform 13 5376 env26252 = env26253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26252 == env26253) = true)

theorem identity26253 : scanCanonicalize (H12AffineFastState.compose env26253 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26253 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,38161,35325,1024,32769,45460,41341,41413,41310,8328,65,2185,46277,4096,10281,41993,41461,256,33,46213,41820]

theorem envBound26254 : H12AffineFastState.Bounded env26254 := by
  intro p hp
  have h : env26254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26253_26254 : H12AffineEnvironment.transform 15 8322 env26253 = env26254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26253 == env26254) = true)

theorem identity26254 : scanCanonicalize (H12AffineFastState.compose env26254 (packedSelected [2,3,4,5,6,10,11,12,15,18,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26254 : packedSelected [2,3,4,5,6,10,11,12,15,18,20,22] rootPS < 2^1333 := by decide +kernel

def env26255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,13389,10401,1024,8541,4296,33,153,2,8328,65,2185,5529,4096,10281,1365,169,256,33,5593,512]

theorem envBound26255 : H12AffineFastState.Bounded env26255 := by
  intro p hp
  have h : env26255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26254_26255 : H12AffineEnvironment.transform 14 8540 env26254 = env26255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26254 == env26255) = true)

theorem identity26255 : scanCanonicalize (H12AffineFastState.compose env26255 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound26255 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26256 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5376,8540,8235,13389,10248,1024,8541,4193,33,48,2,8225,65,2080,5424,4096,10281,1365,0,256,33,5488,512]

theorem envBound26256 : H12AffineFastState.Bounded env26256 := by
  intro p hp
  have h : env26256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26255_26256 : H12AffineEnvironment.transform 6 41 env26255 = env26256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env26255 == env26256) = true)

theorem identity26256 : scanCanonicalize (H12AffineFastState.compose env26256 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound26256 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26257 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,40,5376,372,3,5221,2080,1024,373,4193,33,48,2,9,65,2080,5424,4096,2049,1365,0,256,33,5488,512]

theorem envBound26257 : H12AffineFastState.Bounded env26257 := by
  intro p hp
  have h : env26257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26256_26257 : H12AffineEnvironment.transform 12 40 env26256 = env26257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env26256 == env26257) = true)

theorem identity26257 : scanCanonicalize (H12AffineFastState.compose env26257 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26257 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26258 : List Nat := [2,4,8,16,32,64,41,117,512,1024,2048,4096,40,5237,1,3,5221,2080,1024,0,4193,33,48,2,9,65,2080,5189,4096,2049,1056,0,117,33,5125,512]

theorem envBound26258 : H12AffineFastState.Bounded env26258 := by
  intro p hp
  have h : env26258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26257_26258 : H12AffineEnvironment.transform 7 117 env26257 = env26258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26257 == env26258) = true)

theorem identity26258 : scanCanonicalize (H12AffineFastState.compose env26258 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26258 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env26259 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,1,3,5189,2048,1024,0,4161,1,16,2,9,65,2048,5189,4096,2049,1024,0,85,1,5125,512]

theorem envBound26259 : H12AffineFastState.Bounded env26259 := by
  intro p hp
  have h : env26259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26258_26259 : H12AffineEnvironment.transform 4 0 env26258 = env26259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26258 == env26259) = true)

theorem identity26259 : scanCanonicalize (H12AffineFastState.compose env26259 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound26259 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26260 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,65,8,1044,1,3,1028,2048,1024,0,0,1,16,2,9,65,2048,1028,65,2049,1024,0,85,1,1092,512]

theorem envBound26260 : H12AffineFastState.Bounded env26260 := by
  intro p hp
  have h : env26260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26259_26260 : H12AffineEnvironment.transform 11 65 env26259 = env26260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env26259 == env26260) = true)

theorem identity26260 : scanCanonicalize (H12AffineFastState.compose env26260 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26260 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26261 : List Nat := [2,4,8,16,0,64,9,85,1,1024,2048,65,8,1044,1,3,1028,2048,1024,0,0,1,16,2,9,65,2048,1028,65,2049,1024,0,85,1,1092,1]

theorem envBound26261 : H12AffineFastState.Bounded env26261 := by
  intro p hp
  have h : env26261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26260_26261 : H12AffineEnvironment.transform 8 1 env26260 = env26261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26260 == env26261) = true)

theorem identity26261 : scanCanonicalize (H12AffineFastState.compose env26261 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound26261 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env26262 : List Nat := [2,4,8,16,0,64,9,85,1,1024,1093,65,8,1044,1,3,1028,1093,1024,0,0,1,16,2,9,65,1093,1028,65,1092,1024,0,85,1,1092,1]

theorem envBound26262 : H12AffineFastState.Bounded env26262 := by
  intro p hp
  have h : env26262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26261_26262 : H12AffineEnvironment.transform 10 1093 env26261 = env26262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env26261 == env26262) = true)

theorem identity26262 : scanCanonicalize (H12AffineFastState.compose env26262 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26262 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26263 : List Nat := [2,4,8,16,0,17,9,4,1,1024,1044,16,8,1044,1,3,1028,1044,1024,0,0,1,16,2,9,16,1044,1028,16,1045,1024,0,4,1,1045,1]

theorem envBound26263 : H12AffineFastState.Bounded env26263 := by
  intro p hp
  have h : env26263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26262_26263 : H12AffineEnvironment.transform 5 17 env26262 = env26263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26262 == env26263) = true)

theorem identity26263 : scanCanonicalize (H12AffineFastState.compose env26263 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound26263 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26264 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,16,8,0,1,3,16,0,20,0,0,1,16,2,9,16,0,16,16,1,20,0,4,1,1,1]

theorem envBound26264 : H12AffineFastState.Bounded env26264 := by
  intro p hp
  have h : env26264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26263_26264 : H12AffineEnvironment.transform 9 20 env26263 = env26264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26263 == env26264) = true)

theorem identity26264 : scanCanonicalize (H12AffineFastState.compose env26264 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26265 : List Nat := [2,4,8,5,0,4,9,4,1,1,0,5,8,0,1,3,5,0,1,0,0,1,5,2,9,5,0,5,5,1,1,0,4,1,1,1]

theorem envBound26265 : H12AffineFastState.Bounded env26265 := by
  intro p hp
  have h : env26265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26264_26265 : H12AffineEnvironment.transform 3 5 env26264 = env26265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26264 == env26265) = true)

def env26266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38161,35324,1024,32769,45461,41340,41412,98780,8328,65,2185,46276,4097,10280,41992,41460,256,32,46213,99295]

theorem envBound26266 : H12AffineFastState.Bounded env26266 := by
  intro p hp
  have h : env26266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26252_26266 : H12AffineEnvironment.transform 13 5377 env26252 = env26266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26252 == env26266) = true)

theorem identity26266 : scanCanonicalize (H12AffineFastState.compose env26266 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26266 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,38161,35324,1024,32769,45461,41340,41412,41431,8328,65,2185,46276,4097,10280,41992,41460,256,32,46213,41940]

theorem envBound26267 : H12AffineFastState.Bounded env26267 := by
  intro p hp
  have h : env26267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26266_26267 : H12AffineEnvironment.transform 15 8203 env26266 = env26267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26266 == env26267) = true)

theorem identity26267 : scanCanonicalize (H12AffineFastState.compose env26267 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound26267 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13508,10281,1024,8660,4160,169,17,2,8328,65,2185,5393,4097,10280,1501,33,256,32,5456,513]

theorem envBound26268 : H12AffineFastState.Bounded env26268 := by
  intro p hp
  have h : env26268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26267_26268 : H12AffineEnvironment.transform 14 8661 env26267 = env26268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env26267 == env26268) = true)

theorem identity26268 : scanCanonicalize (H12AffineFastState.compose env26268 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound26268 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,81,399,5440,2477,1024,80,4160,169,17,2,268,65,2185,5393,4097,2476,1501,33,256,32,5456,513]

theorem envBound26269 : H12AffineFastState.Bounded env26269 := by
  intro p hp
  have h : env26269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26268_26269 : H12AffineEnvironment.transform 12 388 env26268 = env26269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env26268 == env26269) = true)

def env26270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441641,98780,8328,65,316533,436265,17664,32041,440549,156133,256,21793,46213,499506]

theorem envBound26270 : H12AffineFastState.Bounded env26270 := by
  intro p hp
  have h : env26270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26228_26270 : H12AffineEnvironment.transform 21 272513 env26228 = env26270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26228 == env26270) = true)

theorem identity26270 : scanCanonicalize (H12AffineFastState.compose env26270 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound26270 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416173,272513,412156,95497,8328,65,270496,417020,17664,32041,412720,156133,256,21793,16464,486375]

theorem envBound26271 : H12AffineFastState.Bounded env26271 := by
  intro p hp
  have h : env26271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26270_26271 : H12AffineEnvironment.transform 14 29909 env26270 = env26271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env26270 == env26271) = true)

def env26272 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272513,412076,95497,8328,17,270496,416940,17664,32041,412720,156085,256,21793,16384,486327]

theorem envBound26272 : H12AffineFastState.Bounded env26272 := by
  intro p hp
  have h : env26272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26271_26272 : H12AffineEnvironment.transform 5 16 env26271 = env26272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26271 == env26272) = true)

theorem identity26272 : scanCanonicalize (H12AffineFastState.compose env26272 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound26272 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env26273 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,89378,1024,29828,197775,95651,201870,95497,8328,17,97666,197006,17664,32041,200978,156085,256,21793,16384,145045]

theorem envBound26273 : H12AffineFastState.Bounded env26273 := by
  intro p hp
  have h : env26273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26272_26273 : H12AffineEnvironment.transform 17 89378 env26272 = env26273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env26272 == env26273) = true)

theorem identity26273 : scanCanonicalize (H12AffineFastState.compose env26273 (packedSelected [0,3,5,8,9,16,20,22,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 90259) := by decide +kernel

theorem selectedBound26273 : packedSelected [0,3,5,8,9,16,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env26274 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,90259,89378,1024,29828,25628,95651,29725,95497,8328,17,97666,24861,17664,32041,29057,65830,256,21793,16384,87558]

theorem envBound26274 : H12AffineFastState.Bounded env26274 := by
  intro p hp
  have h : env26274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26273_26274 : H12AffineEnvironment.transform 16 90259 env26273 = env26274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90259 env26273 == env26274) = true)

theorem identity26274 : scanCanonicalize (H12AffineFastState.compose env26274 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound26274 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26275 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,21646,13341,2476,1024,29828,25628,8493,29725,8583,8328,17,10508,24861,17664,32041,29057,21928,256,21793,16384,648]

theorem envBound26275 : H12AffineFastState.Bounded env26275 := by
  intro p hp
  have h : env26275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26274_26275 : H12AffineEnvironment.transform 15 21646 env26274 = env26275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env26274 == env26275) = true)

theorem identity26275 : scanCanonicalize (H12AffineFastState.compose env26275 (packedSelected [0,2,6,7,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26275 : packedSelected [0,2,6,7,17,20] rootPS < 2^1333 := by decide +kernel

def env26276 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,21510,13341,2340,1024,29708,25628,8493,29725,8463,8192,17,10508,24861,17664,32041,28937,21792,256,21793,16384,512]

theorem envBound26276 : H12AffineFastState.Bounded env26276 := by
  intro p hp
  have h : env26276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26275_26276 : H12AffineEnvironment.transform 6 8 env26275 = env26276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26275 == env26276) = true)

theorem identity26276 : scanCanonicalize (H12AffineFastState.compose env26276 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound26276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26277 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,16384,21793,21510,5425,2340,1024,21792,17712,1,21809,35,300,17,2080,16433,17664,23557,20517,21792,256,21793,16384,512]

theorem envBound26277 : H12AffineFastState.Bounded env26277 := by
  intro p hp
  have h : env26277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26276_26277 : H12AffineEnvironment.transform 12 300 env26276 = env26277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env26276 == env26277) = true)

theorem identity26277 : scanCanonicalize (H12AffineFastState.compose env26277 (packedSelected [2,3,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26277 : packedSelected [2,3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26278 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,5377,32,263,5425,2340,1024,33,4145,1,48,35,300,17,2080,5424,4097,2308,1316,33,256,32,5377,512]

theorem envBound26278 : H12AffineFastState.Bounded env26278 := by
  intro p hp
  have h : env26278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26277_26278 : H12AffineEnvironment.transform 13 5377 env26277 = env26278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26277 == env26278) = true)

def env26279 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272513,412077,95497,8328,16,270496,416941,17664,32041,412720,156084,256,21793,16385,486326]

theorem envBound26279 : H12AffineFastState.Bounded env26279 := by
  intro p hp
  have h : env26279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26271_26279 : H12AffineEnvironment.transform 5 17 env26271 = env26279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26271 == env26279) = true)

theorem identity26279 : scanCanonicalize (H12AffineFastState.compose env26279 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26279 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env26280 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,131072,262144,1024,29708,416036,272392,411940,95497,8193,16,270377,416804,17664,32041,412720,155965,256,21793,16385,486207]

theorem envBound26280 : H12AffineFastState.Bounded env26280 := by
  intro p hp
  have h : env26280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26279_26280 : H12AffineEnvironment.transform 6 9 env26279 = env26280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26279 == env26280) = true)

theorem identity26280 : scanCanonicalize (H12AffineFastState.compose env26280 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound26280 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env26281 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,79131,262144,1024,29708,355391,272392,359487,95497,8193,16,270377,354623,17664,32041,358699,87078,256,21793,16385,286244]

theorem envBound26281 : H12AffineFastState.Bounded env26281 := by
  intro p hp
  have h : env26281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26280_26281 : H12AffineEnvironment.transform 16 79131 env26280 = env26281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env26280 == env26281) = true)

theorem identity26281 : scanCanonicalize (H12AffineFastState.compose env26281 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound26281 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env26282 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,79131,89378,1024,29708,12573,95530,8477,95497,8193,16,97547,13341,17664,32041,9225,87078,256,21793,16385,66310]

theorem envBound26282 : H12AffineFastState.Bounded env26282 := by
  intro p hp
  have h : env26282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26281_26282 : H12AffineEnvironment.transform 17 89378 env26281 = env26282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env26281 == env26282) = true)

theorem identity26282 : scanCanonicalize (H12AffineFastState.compose env26282 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound26282 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env26283 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,29962,16401,10280,1024,29708,12573,32,8477,3,8193,16,2049,13341,17664,32041,9225,8492,256,21793,16385,30220]

theorem envBound26283 : H12AffineFastState.Bounded env26283 := by
  intro p hp
  have h : env26283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26282_26283 : H12AffineEnvironment.transform 15 29962 env26282 = env26283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env26282 == env26283) = true)

theorem identity26283 : scanCanonicalize (H12AffineFastState.compose env26283 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound26283 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26284 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1053,16384,20496,20759,16401,3125,1024,20497,5376,32,1280,3,1052,16,2049,4096,17664,22836,20,1329,256,21793,16385,21009]

theorem envBound26284 : H12AffineFastState.Bounded env26284 := by
  intro p hp
  have h : env26284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26283_26284 : H12AffineEnvironment.transform 12 1053 env26283 = env26284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env26283 == env26284) = true)

theorem identity26284 : scanCanonicalize (H12AffineFastState.compose env26284 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26284 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env26285 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1053,5377,1297,1046,5392,3125,1024,1296,5376,32,1280,3,1052,16,2049,4096,4097,3125,20,1329,256,32,5376,1808]

theorem envBound26285 : H12AffineFastState.Bounded env26285 := by
  intro p hp
  have h : env26285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26284_26285 : H12AffineEnvironment.transform 13 5377 env26284 = env26285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26284 == env26285) = true)

theorem identity26285 : scanCanonicalize (H12AffineFastState.compose env26285 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1824) := by decide +kernel

theorem selectedBound26285 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26286 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1824,1053,545,1297,1046,560,3125,1024,1296,544,32,1280,3,1052,16,2049,1824,1825,3125,20,1329,256,32,544,1808]

theorem envBound26286 : H12AffineFastState.Bounded env26286 := by
  intro p hp
  have h : env26286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26285_26286 : H12AffineEnvironment.transform 11 1824 env26285 = env26286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1824 env26285 == env26286) = true)

theorem identity26286 : scanCanonicalize (H12AffineFastState.compose env26286 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26286 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26287 : List Nat := [2,4,8,16,32,17,9,256,512,5,2048,805,24,545,276,19,560,2096,5,277,544,32,261,3,25,16,2049,805,804,2096,20,308,256,32,544,789]

theorem envBound26287 : H12AffineFastState.Bounded env26287 := by
  intro p hp
  have h : env26287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26286_26287 : H12AffineEnvironment.transform 9 5 env26286 = env26287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26286 == env26287) = true)

theorem identity26287 : scanCanonicalize (H12AffineFastState.compose env26287 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound26287 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26288 : List Nat := [2,4,8,16,32,17,9,256,512,5,561,805,24,545,276,19,560,513,5,277,544,32,261,3,25,16,560,805,804,513,20,308,256,32,544,789]

theorem envBound26288 : H12AffineFastState.Bounded env26288 := by
  intro p hp
  have h : env26288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26287_26288 : H12AffineEnvironment.transform 10 561 env26287 = env26288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env26287 == env26288) = true)

theorem identity26288 : scanCanonicalize (H12AffineFastState.compose env26288 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26288 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26289 : List Nat := [2,4,8,16,32,17,9,5,512,5,561,544,24,545,17,19,560,513,5,16,544,32,0,3,25,16,560,544,545,513,20,49,5,32,544,528]

theorem envBound26289 : H12AffineFastState.Bounded env26289 := by
  intro p hp
  have h : env26289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26288_26289 : H12AffineEnvironment.transform 7 5 env26288 = env26289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26288 == env26289) = true)

theorem identity26289 : scanCanonicalize (H12AffineFastState.compose env26289 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26289 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26290 : List Nat := [2,4,8,16,17,17,9,5,512,5,512,529,24,528,17,19,513,513,5,16,529,17,0,3,25,16,513,529,528,513,20,0,5,17,529,528]

theorem envBound26290 : H12AffineFastState.Bounded env26290 := by
  intro p hp
  have h : env26290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26289_26290 : H12AffineEnvironment.transform 4 17 env26289 = env26290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26289 == env26290) = true)

theorem identity26290 : scanCanonicalize (H12AffineFastState.compose env26290 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26290 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26291 : List Nat := [2,4,8,1,0,0,9,5,512,5,512,512,9,513,0,2,513,513,5,1,512,0,0,3,8,1,513,512,513,513,5,0,5,0,512,513]

theorem envBound26291 : H12AffineFastState.Bounded env26291 := by
  intro p hp
  have h : env26291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26290_26291 : H12AffineEnvironment.transform 3 1 env26290 = env26291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26290 == env26291) = true)

theorem identity26291 : scanCanonicalize (H12AffineFastState.compose env26291 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26292 : List Nat := [2,4,8,1,0,0,9,5,0,5,0,0,9,1,0,2,1,1,5,1,0,0,0,3,8,1,1,0,1,1,5,0,5,0,0,1]

theorem envBound26292 : H12AffineFastState.Bounded env26292 := by
  intro p hp
  have h : env26292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26291_26292 : H12AffineEnvironment.transform 8 0 env26291 = env26292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26291 == env26292) = true)

def env26293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound26293 : H12AffineFastState.Bounded env26293 := by
  intro p hp
  have h : env26293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26105_26293 : H12AffineEnvironment.transform 18 1025 env26105 = env26293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26105 == env26293) = true)

theorem identity26293 : scanCanonicalize (H12AffineFastState.compose env26293 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833400) := by decide +kernel

theorem selectedBound26293 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833400,8328,65,6458872,8702324,10507601,8830977,2410984,12855352,257,297301,289008,2485822]

theorem envBound26294 : H12AffineFastState.Bounded env26294 := by
  intro p hp
  have h : env26294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26293_26294 : H12AffineEnvironment.transform 23 10833400 env26293 = env26294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833400 env26293 == env26294) = true)

def env26295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458872,8393984,10507601,8526965,2102684,12645452,257,21793,46212,2175562]

theorem envBound26295 : H12AffineFastState.Bounded env26295 := by
  intro p hp
  have h : env26295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26294_26295 : H12AffineEnvironment.transform 17 56436 env26294 = env26295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env26294 == env26295) = true)

def env26296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,4194304,8388608,8487372,8328,65,4365752,8393984,8406289,8526965,1500,12645452,257,21793,46212,74250]

theorem envBound26296 : H12AffineFastState.Bounded env26296 := by
  intro p hp
  have h : env26296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26295_26296 : H12AffineEnvironment.transform 20 4160 env26295 = env26296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26295 == env26296) = true)

def env26297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,32,8388608,8487372,8328,65,171416,8393984,8406289,8526965,1500,8451180,257,21793,46212,74250]

theorem envBound26297 : H12AffineFastState.Bounded env26297 := by
  intro p hp
  have h : env26297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26296_26297 : H12AffineEnvironment.transform 21 32 env26296 = env26297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26296 == env26297) = true)

theorem identity26297 : scanCanonicalize (H12AffineFastState.compose env26297 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26297 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4160,32,8388608,8430023,8328,65,171416,8393984,8406289,8526965,1500,8451180,257,21793,46212,513]

theorem envBound26298 : H12AffineFastState.Bounded env26298 := by
  intro p hp
  have h : env26298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26297_26298 : H12AffineEnvironment.transform 15 8203 env26297 = env26298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26297 == env26298) = true)

def env26299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1025,32769,4160,32,8388608,8430023,8328,65,56712,8393984,8406289,8412261,1500,8451180,257,21793,46212,513]

theorem envBound26299 : H12AffineFastState.Bounded env26299 := by
  intro p hp
  have h : env26299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26298_26299 : H12AffineEnvironment.transform 16 16400 env26298 = env26299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env26298 == env26299) = true)

theorem identity26299 : scanCanonicalize (H12AffineFastState.compose env26299 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound26299 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1025,32769,4160,32,17,41430,8328,65,56712,5393,17664,23668,1500,62589,257,21793,46212,513]

theorem envBound26300 : H12AffineFastState.Bounded env26300 := by
  intro p hp
  have h : env26300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26299_26300 : H12AffineEnvironment.transform 22 17 env26299 = env26300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env26299 == env26300) = true)

theorem identity26300 : scanCanonicalize (H12AffineFastState.compose env26300 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26300 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1025,32769,4160,32,17,41310,8192,65,56576,5393,17664,23668,1364,62589,257,21793,46092,513]

theorem envBound26301 : H12AffineFastState.Bounded env26301 := by
  intro p hp
  have h : env26301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26300_26301 : H12AffineEnvironment.transform 6 8 env26300 = env26301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26300 == env26301) = true)

theorem identity26301 : scanCanonicalize (H12AffineFastState.compose env26301 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26301 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,5392,35188,1025,32769,4160,32,17,41310,8192,65,34816,5393,4096,2420,1364,41341,257,33,46092,513]

theorem envBound26302 : H12AffineFastState.Bounded env26302 := by
  intro p hp
  have h : env26302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26301_26302 : H12AffineEnvironment.transform 13 5376 env26301 = env26302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26301 == env26302) = true)

theorem identity26302 : scanCanonicalize (H12AffineFastState.compose env26302 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26302 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,343,5392,35188,1025,32769,4160,32,17,32770,348,65,34816,5393,4096,2420,1364,32801,257,33,38224,513]

theorem envBound26303 : H12AffineFastState.Bounded env26303 := by
  intro p hp
  have h : env26303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26302_26303 : H12AffineEnvironment.transform 12 348 env26302 = env26303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26302 == env26303) = true)

theorem identity26303 : scanCanonicalize (H12AffineFastState.compose env26303 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound26303 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,80,343,5392,2340,1025,81,4160,32,17,82,348,65,2128,5393,4096,2420,1364,113,257,33,5376,513]

theorem envBound26304 : H12AffineFastState.Bounded env26304 := by
  intro p hp
  have h : env26304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26303_26304 : H12AffineEnvironment.transform 14 80 env26303 = env26304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env26303 == env26304) = true)

theorem identity26304 : scanCanonicalize (H12AffineFastState.compose env26304 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26304 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26305 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4113,32,17,3,269,16,2049,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound26305 : H12AffineFastState.Bounded env26305 := by
  intro p hp
  have h : env26305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26304_26305 : H12AffineEnvironment.transform 5 17 env26304 = env26305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26304 == env26305) = true)

theorem identity26305 : scanCanonicalize (H12AffineFastState.compose env26305 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound26305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26306 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,261,269,1029,1,262,1045,2340,1025,0,276,32,17,3,269,16,2049,1044,261,2341,1285,32,257,33,1029,513]

theorem envBound26306 : H12AffineFastState.Bounded env26306 := by
  intro p hp
  have h : env26306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26305_26306 : H12AffineEnvironment.transform 11 261 env26305 = env26306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env26305 == env26306) = true)

theorem identity26306 : scanCanonicalize (H12AffineFastState.compose env26306 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1307) := by decide +kernel

theorem selectedBound26306 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26307 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1307,261,269,1029,1,262,1045,1087,1025,0,276,32,17,3,269,16,1306,1044,261,1086,1285,32,257,33,1029,513]

theorem envBound26307 : H12AffineFastState.Bounded env26307 := by
  intro p hp
  have h : env26307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26306_26307 : H12AffineEnvironment.transform 10 1307 env26306 = env26307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1307 env26306 == env26307) = true)

theorem identity26307 : scanCanonicalize (H12AffineFastState.compose env26307 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound26307 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26308 : List Nat := [2,4,8,16,32,17,8,256,319,1024,1307,261,269,1029,1,262,1045,1087,1025,0,276,32,17,3,269,16,1306,1044,261,1086,1285,32,257,33,1029,318]

theorem envBound26308 : H12AffineFastState.Bounded env26308 := by
  intro p hp
  have h : env26308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26307_26308 : H12AffineEnvironment.transform 8 319 env26307 = env26308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env26307 == env26308) = true)

theorem identity26308 : scanCanonicalize (H12AffineFastState.compose env26308 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound26308 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26309 : List Nat := [2,4,8,16,32,17,8,256,319,14,277,261,269,11,1,262,27,49,15,0,276,32,17,3,269,16,276,26,261,48,267,32,257,33,11,318]

theorem envBound26309 : H12AffineFastState.Bounded env26309 := by
  intro p hp
  have h : env26309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26308_26309 : H12AffineEnvironment.transform 9 14 env26308 = env26309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env26308 == env26309) = true)

theorem identity26309 : scanCanonicalize (H12AffineFastState.compose env26309 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26309 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26310 : List Nat := [2,4,8,16,32,17,8,4,59,14,17,1,9,11,1,2,27,49,15,0,16,32,17,3,9,16,16,26,1,48,15,32,5,33,11,58]

theorem envBound26310 : H12AffineFastState.Bounded env26310 := by
  intro p hp
  have h : env26310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26309_26310 : H12AffineEnvironment.transform 7 4 env26309 = env26310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26309 == env26310) = true)

theorem identity26310 : scanCanonicalize (H12AffineFastState.compose env26310 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26310 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env26311 : List Nat := [2,4,8,16,0,17,8,4,27,14,17,1,9,11,1,2,27,17,15,0,16,0,17,3,9,16,16,26,1,16,15,0,5,1,11,26]

theorem envBound26311 : H12AffineFastState.Bounded env26311 := by
  intro p hp
  have h : env26311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26310_26311 : H12AffineEnvironment.transform 4 0 env26310 = env26311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26310 == env26311) = true)

theorem identity26311 : scanCanonicalize (H12AffineFastState.compose env26311 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound26311 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26312 : List Nat := [2,4,8,13,0,12,8,4,6,14,12,1,9,11,1,2,6,12,15,0,13,0,12,3,9,13,13,7,1,13,15,0,5,1,11,7]

theorem envBound26312 : H12AffineFastState.Bounded env26312 := by
  intro p hp
  have h : env26312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26311_26312 : H12AffineEnvironment.transform 3 13 env26311 = env26312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env26311 == env26312) = true)

def env26313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56436,1025,32769,4160,32,8388608,8430023,8328,65,56713,8393984,8406289,8412260,1500,8451180,257,21793,46212,513]

theorem envBound26313 : H12AffineFastState.Bounded env26313 := by
  intro p hp
  have h : env26313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26298_26313 : H12AffineEnvironment.transform 16 16401 env26298 = env26313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env26298 == env26313) = true)

def env26314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56436,1025,32769,4160,32,20480,61895,8328,65,56713,17664,5393,3172,1500,42092,257,21793,46212,513]

theorem envBound26314 : H12AffineFastState.Bounded env26314 := by
  intro p hp
  have h : env26314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26313_26314 : H12AffineEnvironment.transform 22 20480 env26313 = env26314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env26313 == env26314) = true)

theorem identity26314 : scanCanonicalize (H12AffineFastState.compose env26314 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound26314 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env26315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9244,8203,16401,30824,1025,9245,4160,32,20480,21979,8328,65,31125,17664,5393,3172,1500,112,257,21793,4248,513]

theorem envBound26315 : H12AffineFastState.Bounded env26315 := by
  intro p hp
  have h : env26315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26314_26315 : H12AffineEnvironment.transform 14 9244 env26314 = env26315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env26314 == env26315) = true)

theorem identity26315 : scanCanonicalize (H12AffineFastState.compose env26315 (packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26315 : packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS < 2^1333 := by decide +kernel

def env26316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,9244,8203,5441,11576,1025,9245,4160,32,1360,139,8328,65,11461,4176,5393,3172,1500,112,257,113,4248,513]

theorem envBound26316 : H12AffineFastState.Bounded env26316 := by
  intro p hp
  have h : env26316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26315_26316 : H12AffineEnvironment.transform 13 5456 env26315 = env26316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env26315 == env26316) = true)

theorem identity26316 : scanCanonicalize (H12AffineFastState.compose env26316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound26316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26317 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,4297,8581,8203,4312,10401,408,8580,4160,32,201,139,8328,65,10588,4176,4232,2557,69,112,257,113,4248,513]

theorem envBound26317 : H12AffineFastState.Bounded env26317 := by
  intro p hp
  have h : env26317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26316_26317 : H12AffineEnvironment.transform 9 409 env26316 = env26317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env26316 == env26317) = true)

theorem identity26317 : scanCanonicalize (H12AffineFastState.compose env26317 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26317 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26318 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,269,4297,136,262,4312,2476,408,137,4160,32,201,139,389,65,2129,4176,4232,2557,69,112,257,113,4248,513]

theorem envBound26318 : H12AffineFastState.Bounded env26318 := by
  intro p hp
  have h : env26318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26317_26318 : H12AffineEnvironment.transform 12 269 env26317 = env26318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26317 == env26318) = true)

theorem identity26318 : scanCanonicalize (H12AffineFastState.compose env26318 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound26318 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env26319 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,648,269,577,136,262,592,2476,408,137,712,32,201,139,389,65,2129,728,512,2557,69,112,257,113,528,513]

theorem envBound26319 : H12AffineFastState.Bounded env26319 := by
  intro p hp
  have h : env26319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26318_26319 : H12AffineEnvironment.transform 11 648 env26318 = env26319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env26318 == env26319) = true)

def env26320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56436,1025,32769,4160,32,20481,61894,8328,65,56713,17665,5392,3173,1500,42093,257,21793,46212,513]

theorem envBound26320 : H12AffineFastState.Bounded env26320 := by
  intro p hp
  have h : env26320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26313_26320 : H12AffineEnvironment.transform 22 20481 env26313 = env26320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env26313 == env26320) = true)

theorem identity26320 : scanCanonicalize (H12AffineFastState.compose env26320 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9365) := by decide +kernel

theorem selectedBound26320 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env26321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9365,8203,16401,30945,1025,9364,4160,32,20481,21843,8328,65,31004,17665,5392,3173,1500,248,257,21793,4113,513]

theorem envBound26321 : H12AffineFastState.Bounded env26321 := by
  intro p hp
  have h : env26321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26320_26321 : H12AffineEnvironment.transform 14 9365 env26320 = env26321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9365 env26320 == env26321) = true)

theorem identity26321 : scanCanonicalize (H12AffineFastState.compose env26321 (packedSelected [0,1,3,7,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26321 : packedSelected [0,1,3,7,20,24,28] rootPS < 2^1333 := by decide +kernel

def env26322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,9365,8203,5441,11697,1025,9364,4160,32,1361,3,8328,65,11340,4177,5392,3173,1500,248,257,113,4113,513]

theorem envBound26322 : H12AffineFastState.Bounded env26322 := by
  intro p hp
  have h : env26322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26321_26322 : H12AffineEnvironment.transform 13 5456 env26321 = env26322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env26321 == env26322) = true)

theorem identity26322 : scanCanonicalize (H12AffineFastState.compose env26322 (packedSelected [0,7,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound26322 : packedSelected [0,7,17,20] rootPS < 2^1333 := by decide +kernel

def env26323 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4296,8461,8203,4313,10281,409,8460,4160,32,201,3,8328,65,10708,4177,4232,2557,68,248,257,113,4113,513]

theorem envBound26323 : H12AffineFastState.Bounded env26323 := by
  intro p hp
  have h : env26323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26322_26323 : H12AffineEnvironment.transform 9 408 env26322 = env26323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env26322 == env26323) = true)

theorem identity26323 : scanCanonicalize (H12AffineFastState.compose env26323 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound26323 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26324 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,389,4296,136,398,4313,2476,409,137,4160,32,201,3,269,65,2129,4177,4232,2557,68,248,257,113,4113,513]

theorem envBound26324 : H12AffineFastState.Bounded env26324 := by
  intro p hp
  have h : env26324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26323_26324 : H12AffineEnvironment.transform 12 389 env26323 = env26324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env26323 == env26324) = true)

def env26325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,8388608,8487372,8328,65,171417,8393984,8406289,8526965,1500,8451181,257,21793,46212,74250]

theorem envBound26325 : H12AffineFastState.Bounded env26325 := by
  intro p hp
  have h : env26325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26296_26325 : H12AffineEnvironment.transform 21 33 env26296 = env26325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26296 == env26325) = true)

theorem identity26325 : scanCanonicalize (H12AffineFastState.compose env26325 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound26325 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,73754,41430,8328,65,171417,79130,91403,212079,1500,119927,257,21793,46212,74250]

theorem envBound26326 : H12AffineFastState.Bounded env26326 := by
  intro p hp
  have h : env26326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26325_26326 : H12AffineEnvironment.transform 22 73754 env26325 = env26326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env26325 == env26326) = true)

def env26327 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,73754,41122,8328,65,171245,78958,91263,212079,1192,119927,117,21589,46212,74250]

theorem envBound26327 : H12AffineFastState.Bounded env26327 := by
  intro p hp
  have h : env26327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26326_26327 : H12AffineEnvironment.transform 7 116 env26326 = env26327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26326 == env26327) = true)

theorem identity26327 : scanCanonicalize (H12AffineFastState.compose env26327 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26327 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26328 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4160,33,17,41122,8328,65,171245,5221,17524,138340,1192,62588,117,21589,46212,513]

theorem envBound26328 : H12AffineFastState.Bounded env26328 := by
  intro p hp
  have h : env26328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26327_26328 : H12AffineEnvironment.transform 15 8203 env26327 = env26328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26327 == env26328) = true)

theorem identity26328 : scanCanonicalize (H12AffineFastState.compose env26328 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound26328 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26329 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4160,33,17,41083,8273,65,171060,5221,17524,138340,1137,62588,117,21589,46173,513]

theorem envBound26329 : H12AffineFastState.Bounded env26329 := by
  intro p hp
  have h : env26329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26328_26329 : H12AffineEnvironment.transform 6 89 env26328 = env26329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env26328 == env26329) = true)

theorem identity26329 : scanCanonicalize (H12AffineFastState.compose env26329 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound26329 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env26330 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,32768,8203,49169,56436,1025,32769,4160,33,17,41083,8273,65,23589,5221,17524,56437,1137,62588,117,21589,46173,513]

theorem envBound26330 : H12AffineFastState.Bounded env26330 := by
  intro p hp
  have h : env26330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26329_26330 : H12AffineEnvironment.transform 16 49169 env26329 = env26330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26329 == env26330) = true)

theorem identity26330 : scanCanonicalize (H12AffineFastState.compose env26330 (packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26330 : packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env26331 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,8203,49169,56356,1025,32769,4112,33,17,41003,8193,17,23589,5173,17444,56357,1057,62508,37,21509,46093,513]

theorem envBound26331 : H12AffineFastState.Bounded env26331 := by
  intro p hp
  have h : env26331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26330_26331 : H12AffineEnvironment.transform 5 16 env26330 = env26331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26330 == env26331) = true)

theorem identity26331 : scanCanonicalize (H12AffineFastState.compose env26331 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 28728) := by decide +kernel

theorem selectedBound26331 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26332 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,28728,8203,12329,11292,1025,28729,4112,33,17,20499,8193,17,23589,5173,17444,11293,1057,1044,37,21509,17461,513]

theorem envBound26332 : H12AffineFastState.Bounded env26332 := by
  intro p hp
  have h : env26332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26331_26332 : H12AffineEnvironment.transform 14 28728 env26331 = env26332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28728 env26331 == env26332) = true)

theorem identity26332 : scanCanonicalize (H12AffineFastState.compose env26332 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound26332 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26333 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,4112,8232,8203,12329,11292,1025,8233,4112,33,17,3,8193,17,3125,5173,5172,11293,1057,1044,37,1045,5157,513]

theorem envBound26333 : H12AffineFastState.Bounded env26333 := by
  intro p hp
  have h : env26333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26332_26333 : H12AffineEnvironment.transform 13 4112 env26332 = env26333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env26332 == env26333) = true)

theorem identity26333 : scanCanonicalize (H12AffineFastState.compose env26333 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26333 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26334 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,4112,8232,8203,12329,10281,52,8233,4112,33,17,3,8193,17,2048,4096,4097,10280,20,33,37,32,4112,513]

theorem envBound26334 : H12AffineFastState.Bounded env26334 := by
  intro p hp
  have h : env26334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26333_26334 : H12AffineEnvironment.transform 9 53 env26333 = env26334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26333 == env26334) = true)

theorem identity26334 : scanCanonicalize (H12AffineFastState.compose env26334 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound26334 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26335 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,40,4112,0,35,4097,2049,52,1,4112,33,17,3,41,17,2048,4096,4097,2048,20,33,37,32,4112,513]

theorem envBound26335 : H12AffineFastState.Bounded env26335 := by
  intro p hp
  have h : env26335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26334_26335 : H12AffineEnvironment.transform 12 40 env26334 = env26335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env26334 == env26335) = true)

end H12CloudChart0