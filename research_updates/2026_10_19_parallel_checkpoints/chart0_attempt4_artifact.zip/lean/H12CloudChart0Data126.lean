import H12CloudChart0Data125

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env31974 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2561,41,2577,1,35,2561,2048,52,0,2576,32,16,3,40,17,2049,2560,2560,2049,20,33,37,33,2577,513]

theorem envBound31974 : H12AffineFastState.Bounded env31974 := by
  intro p hp
  have h : env31974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31973_31974 : H12AffineEnvironment.transform 7 37 env31973 = env31974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31973 == env31974) = true)

theorem identity31974 : scanCanonicalize (H12AffineFastState.compose env31974 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound31974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31975 : List Nat := [2,4,8,16,32,17,9,37,512,52,545,32,41,48,1,35,32,545,52,0,49,32,16,3,40,17,544,33,33,544,20,33,37,33,48,513]

theorem envBound31975 : H12AffineFastState.Bounded env31975 := by
  intro p hp
  have h : env31975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31974_31975 : H12AffineEnvironment.transform 10 545 env31974 = env31975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env31974 == env31975) = true)

theorem identity31975 : scanCanonicalize (H12AffineFastState.compose env31975 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound31975 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31976 : List Nat := [2,4,8,16,32,17,9,37,33,52,0,32,41,48,1,35,32,0,52,0,49,32,16,3,40,17,1,33,33,1,20,33,37,33,48,32]

theorem envBound31976 : H12AffineFastState.Bounded env31976 := by
  intro p hp
  have h : env31976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31975_31976 : H12AffineEnvironment.transform 8 33 env31975 = env31976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env31975 == env31976) = true)

theorem identity31976 : scanCanonicalize (H12AffineFastState.compose env31976 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31976 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31977 : List Nat := [2,4,8,16,17,17,9,20,16,5,0,17,24,1,1,18,17,0,5,0,0,17,16,3,25,17,1,16,16,1,20,16,20,16,1,17]

theorem envBound31977 : H12AffineFastState.Bounded env31977 := by
  intro p hp
  have h : env31977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31976_31977 : H12AffineEnvironment.transform 4 17 env31976 = env31977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31976 == env31977) = true)

def env31978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,138,8328,64,4450482,2196486,2233817,190520,246802,6382922,256,2327727,2319626,189380]

theorem envBound31978 : H12AffineFastState.Bounded env31978 := by
  intro p hp
  have h : env31978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31947_31978 : H12AffineEnvironment.transform 17 157873 env31947 = env31978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env31947 == env31978) = true)

theorem identity31978 : scanCanonicalize (H12AffineFastState.compose env31978 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31978 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157873,1024,8541,2097152,4194304,147593,138,8328,64,4409838,2172250,2233817,149860,222542,6382922,256,2303475,2319626,148120]

theorem envBound31979 : H12AffineFastState.Bounded env31979 := by
  intro p hp
  have h : env31979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31978_31979 : H12AffineEnvironment.transform 14 8540 env31978 = env31979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31978 == env31979) = true)

theorem identity31979 : scanCanonicalize (H12AffineFastState.compose env31979 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31979 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157752,1024,8541,2097152,4194304,147456,3,8193,64,4409703,2172250,2233680,149860,222542,6382922,256,2303354,2319626,147985]

theorem envBound31980 : H12AffineFastState.Bounded env31980 := by
  intro p hp
  have h : env31980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31979_31980 : H12AffineEnvironment.transform 6 9 env31979 = env31980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31979 == env31980) = true)

theorem identity31980 : scanCanonicalize (H12AffineFastState.compose env31980 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31980 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,3,8193,64,4262263,2172250,2118976,2420,75102,6382922,256,2188650,2172186,513]

theorem envBound31981 : H12AffineFastState.Bounded env31981 := by
  intro p hp
  have h : env31981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31980_31981 : H12AffineEnvironment.transform 16 16400 env31980 = env31981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31980 == env31981) = true)

theorem identity31981 : scanCanonicalize (H12AffineFastState.compose env31981 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound31981 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91467,4194304,16,3,8193,64,4262263,16401,77835,2420,75102,4194305,256,33,16465,513]

theorem envBound31982 : H12AffineFastState.Bounded env31982 := by
  intro p hp
  have h : env31982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31981_31982 : H12AffineEnvironment.transform 20 91467 env31981 = env31982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env31981 == env31982) = true)

theorem identity31982 : scanCanonicalize (H12AffineFastState.compose env31982 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31982 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16400,10280,1024,8541,25629,4194304,16,3,8193,64,4196385,16401,12637,2420,9224,4194305,256,33,16465,513]

theorem envBound31983 : H12AffineFastState.Bounded env31983 := by
  intro p hp
  have h : env31983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31982_31983 : H12AffineEnvironment.transform 15 342 env31982 = env31983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31982 == env31983) = true)

theorem identity31983 : scanCanonicalize (H12AffineFastState.compose env31983 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31983 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,342,16400,2420,1024,1,17729,4194304,16,3,349,64,4196385,16401,4097,2420,1364,4194305,256,33,16465,513]

theorem envBound31984 : H12AffineFastState.Bounded env31984 := by
  intro p hp
  have h : env31984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31983_31984 : H12AffineEnvironment.transform 12 348 env31983 = env31984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31983 == env31984) = true)

theorem identity31984 : scanCanonicalize (H12AffineFastState.compose env31984 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31985 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16400,2341,1024,1,17680,4194304,16,3,268,17,4196385,16401,4097,2341,1285,4194305,256,33,16384,513]

theorem envBound31985 : H12AffineFastState.Bounded env31985 := by
  intro p hp
  have h : env31985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31984_31985 : H12AffineEnvironment.transform 5 17 env31984 = env31985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31984 == env31985) = true)

theorem identity31985 : scanCanonicalize (H12AffineFastState.compose env31985 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound31985 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31986 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16400,2341,1024,1,17680,21509,16,3,268,17,23588,16401,4097,2341,1285,21508,256,33,16384,513]

theorem envBound31986 : H12AffineFastState.Bounded env31986 := by
  intro p hp
  have h : env31986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31985_31986 : H12AffineEnvironment.transform 21 21509 env31985 = env31986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env31985 == env31986) = true)

theorem identity31986 : scanCanonicalize (H12AffineFastState.compose env31986 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound31986 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31987 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,0,263,5172,2341,1024,1,4404,33,16,3,268,17,2048,5173,4097,2341,1285,32,256,33,5156,513]

theorem envBound31987 : H12AffineFastState.Bounded env31987 := by
  intro p hp
  have h : env31987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31986_31987 : H12AffineEnvironment.transform 13 5156 env31986 = env31987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env31986 == env31987) = true)

def env31988 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,269,2836,0,263,2820,2341,1024,1,3588,33,16,3,268,17,2048,2821,3889,2341,1285,32,256,33,2836,513]

theorem envBound31988 : H12AffineFastState.Bounded env31988 := by
  intro p hp
  have h : env31988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31987_31988 : H12AffineEnvironment.transform 11 3888 env31987 = env31988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env31987 == env31988) = true)

def env31989 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,269,1044,0,263,1028,1573,1024,1,260,33,16,3,268,17,1792,1029,49,1573,1285,32,256,33,1044,513]

theorem envBound31989 : H12AffineFastState.Bounded env31989 := by
  intro p hp
  have h : env31989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31988_31989 : H12AffineEnvironment.transform 10 1792 env31988 = env31989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env31988 == env31989) = true)

theorem identity31989 : scanCanonicalize (H12AffineFastState.compose env31989 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31990 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,48,269,32,0,263,48,529,52,1,260,33,16,3,268,17,820,49,49,529,305,32,256,33,32,513]

theorem envBound31990 : H12AffineFastState.Bounded env31990 := by
  intro p hp
  have h : env31990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31989_31990 : H12AffineEnvironment.transform 9 52 env31989 = env31990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31989 == env31990) = true)

def env31991 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,269,1045,0,263,1029,1572,1024,1,261,33,16,3,268,17,1793,1028,48,1572,1285,32,256,33,1045,513]

theorem envBound31991 : H12AffineFastState.Bounded env31991 := by
  intro p hp
  have h : env31991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31988_31991 : H12AffineEnvironment.transform 10 1793 env31988 = env31991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env31988 == env31991) = true)

theorem identity31991 : scanCanonicalize (H12AffineFastState.compose env31991 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31992 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,49,40,1045,0,34,1029,1572,1024,1,32,33,16,3,41,17,1572,1028,48,1572,1056,32,37,33,1045,513]

theorem envBound31992 : H12AffineFastState.Bounded env31992 := by
  intro p hp
  have h : env31992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31991_31992 : H12AffineEnvironment.transform 7 37 env31991 = env31992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31991 == env31992) = true)

def env31993 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,49,40,33,0,34,49,528,52,1,32,33,16,3,41,17,528,48,48,528,20,32,37,33,33,513]

theorem envBound31993 : H12AffineFastState.Bounded env31993 := by
  intro p hp
  have h : env31993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31992_31993 : H12AffineEnvironment.transform 9 52 env31992 = env31993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31992 == env31993) = true)

def env31994 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,49,40,32,0,34,48,529,53,1,32,33,16,3,41,17,529,49,48,529,21,32,37,33,32,513]

theorem envBound31994 : H12AffineFastState.Bounded env31994 := by
  intro p hp
  have h : env31994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31992_31994 : H12AffineEnvironment.transform 9 53 env31992 = env31994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31992 == env31994) = true)

theorem identity31994 : scanCanonicalize (H12AffineFastState.compose env31994 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound31994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31995 : List Nat := [2,4,8,16,32,17,9,37,42,53,59,49,40,32,0,34,48,59,53,1,32,33,16,3,41,17,59,49,48,59,21,32,37,33,32,43]

theorem envBound31995 : H12AffineFastState.Bounded env31995 := by
  intro p hp
  have h : env31995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31994_31995 : H12AffineEnvironment.transform 8 42 env31994 = env31995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env31994 == env31995) = true)

def leafEnv31995 : List Nat := [2,4,8,16,32,17,9,37,42,53,59,49,40,32,0,34,48,59,53,1,32,33,16,3,21,41,1,17,59,49,48,59,21,32,37,33,4,35,32,43,1,32,0]

def active31995 : List Nat := [0,1,2,3,4]

def tree31995 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31995 : H12WitnessSearch.Good tree31995 := H12GlobalWitnessIndex.good

theorem leafIdentity31995 : H12AffineFastState.composeSystem env31995 rootObs = leafEnv31995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31995 rootObs == leafEnv31995) = true)

theorem terminalChecked31995 : H12PackedTerminal.terminalCheckFast leafEnv31995 active31995 tree31995 = true := by decide +kernel

def env31996 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,269,2837,0,263,2821,2341,1024,1,3589,33,16,3,268,17,2048,2820,3888,2341,1285,32,256,33,2837,513]

theorem envBound31996 : H12AffineFastState.Bounded env31996 := by
  intro p hp
  have h : env31996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31987_31996 : H12AffineEnvironment.transform 11 3889 env31987 = env31996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env31987 == env31996) = true)

def env31997 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,269,1045,0,263,1029,1573,1024,1,261,33,16,3,268,17,1792,1028,48,1573,1285,32,256,33,1045,513]

theorem envBound31997 : H12AffineFastState.Bounded env31997 := by
  intro p hp
  have h : env31997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31996_31997 : H12AffineEnvironment.transform 10 1792 env31996 = env31997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env31996 == env31997) = true)

def env31998 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,269,1044,0,263,1028,1572,1024,1,260,33,16,3,268,17,1793,1029,49,1572,1285,32,256,33,1044,513]

theorem envBound31998 : H12AffineFastState.Bounded env31998 := by
  intro p hp
  have h : env31998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31996_31998 : H12AffineEnvironment.transform 10 1793 env31996 = env31998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env31996 == env31998) = true)

theorem identity31998 : scanCanonicalize (H12AffineFastState.compose env31998 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31999 : List Nat := [2,4,8,16,32,17,9,256,512,272,529,48,269,260,0,263,276,820,272,1,260,33,16,3,268,17,529,277,49,820,21,32,256,33,260,513]

theorem envBound31999 : H12AffineFastState.Bounded env31999 := by
  intro p hp
  have h : env31999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31998_31999 : H12AffineEnvironment.transform 9 272 env31998 = env31999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31998 == env31999) = true)

def env32000 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,41,32,0,35,48,528,52,1,32,33,16,3,40,17,529,49,49,528,21,32,36,33,32,513]

theorem envBound32000 : H12AffineFastState.Bounded env32000 := by
  intro p hp
  have h : env32000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31999_32000 : H12AffineEnvironment.transform 7 36 env31999 = env32000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31999 == env32000) = true)

def env32001 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,48,40,33,0,34,49,529,53,1,33,33,16,3,41,17,529,48,49,529,21,32,37,33,33,513]

theorem envBound32001 : H12AffineFastState.Bounded env32001 := by
  intro p hp
  have h : env32001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31999_32001 : H12AffineEnvironment.transform 7 37 env31999 = env32001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31999 == env32001) = true)

theorem identity32001 : scanCanonicalize (H12AffineFastState.compose env32001 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32002 : List Nat := [2,4,8,16,32,17,9,37,43,53,58,48,40,33,0,34,49,58,53,1,33,33,16,3,41,17,58,48,49,58,21,32,37,33,33,42]

theorem envBound32002 : H12AffineFastState.Bounded env32002 := by
  intro p hp
  have h : env32002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32001_32002 : H12AffineEnvironment.transform 8 43 env32001 = env32002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32001 == env32002) = true)

def leafEnv32002 : List Nat := [2,4,8,16,32,17,9,37,43,53,58,48,40,33,0,34,49,58,53,1,33,33,16,3,21,41,1,17,58,48,49,58,21,32,37,33,4,35,33,42,1,33,0]

def active32002 : List Nat := [0,1,2,3,4]

def tree32002 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32002 : H12WitnessSearch.Good tree32002 := H12GlobalWitnessIndex.good

theorem leafIdentity32002 : H12AffineFastState.composeSystem env32002 rootObs = leafEnv32002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32002 rootObs == leafEnv32002) = true)

theorem terminalChecked32002 : H12PackedTerminal.terminalCheckFast leafEnv32002 active32002 tree32002 = true := by decide +kernel

def env32003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound32003 : H12AffineFastState.Bounded env32003 := by
  intro p hp
  have h : env32003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31851_32003 : H12AffineEnvironment.transform 18 1025 env31851 = env32003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31851 == env32003) = true)

theorem identity32003 : scanCanonicalize (H12AffineFastState.compose env32003 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 253963) := by decide +kernel

theorem selectedBound32003 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,253963,16777216,8328,64,21241866,18973837,2340187,335882,16933914,23160256,257,19014822,19055874,16991181]

theorem envBound32004 : H12AffineFastState.Bounded env32004 := by
  intro p hp
  have h : env32004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32003_32004 : H12AffineEnvironment.transform 22 253963 env32003 = env32004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 253963 env32003 == env32004) = true)

def env32005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253963,16777216,8328,64,16959642,18973837,2340187,335882,16933914,19369296,257,19014822,19055874,16991181]

theorem envBound32005 : H12AffineFastState.Bounded env32005 := by
  intro p hp
  have h : env32005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32004_32005 : H12AffineEnvironment.transform 21 452752 env32004 = env32005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env32004 == env32005) = true)

def env32006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253963,242968,8328,64,97666,2240917,2340187,335882,119042,2373704,257,2199998,2191386,63189]

theorem envBound32006 : H12AffineFastState.Bounded env32006 := by
  intro p hp
  have h : env32006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32005_32006 : H12AffineEnvironment.transform 23 242968 env32005 = env32006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env32005 == env32006) = true)

def env32007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253963,242968,8328,64,97666,139733,238875,335882,119042,272392,257,98814,90202,63189]

theorem envBound32007 : H12AffineFastState.Bounded env32007 := by
  intro p hp
  have h : env32007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32006_32007 : H12AffineEnvironment.transform 20 4160 env32006 = env32007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32006 == env32007) = true)

theorem identity32007 : scanCanonicalize (H12AffineFastState.compose env32007 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound32007 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,452752,144597,156102,8328,64,43356,139733,160197,324820,1500,272392,257,21792,46212,63189]

theorem envBound32008 : H12AffineFastState.Bounded env32008 := by
  intro p hp
  have h : env32008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32007_32008 : H12AffineEnvironment.transform 15 54494 env32007 = env32008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env32007 == env32008) = true)

def env32009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,262144,1025,32769,4160,305360,29845,8582,8328,64,43356,24981,12677,324820,1500,272392,257,21792,46212,63189]

theorem envBound32009 : H12AffineFastState.Bounded env32009 := by
  intro p hp
  have h : env32009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32008_32009 : H12AffineEnvironment.transform 16 16448 env32008 = env32009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env32008 == env32009) = true)

theorem identity32009 : scanCanonicalize (H12AffineFastState.compose env32009 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound32009 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33167,5393,262144,1025,32769,4160,305360,8644,8582,8328,64,43356,13508,12677,303493,1500,272392,257,113,46212,41860]

theorem envBound32010 : H12AffineFastState.Bounded env32010 := by
  intro p hp
  have h : env32010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32009_32010 : H12AffineEnvironment.transform 13 5457 env32009 = env32010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env32009 == env32010) = true)

theorem identity32010 : scanCanonicalize (H12AffineFastState.compose env32010 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32010 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env32011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33167,5393,10280,1025,32769,4160,33016,8644,8582,8328,64,43356,13508,12677,35245,1500,32,257,113,46212,41860]

theorem envBound32011 : H12AffineFastState.Bounded env32011 := by
  intro p hp
  have h : env32011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32010_32011 : H12AffineEnvironment.transform 17 10280 env32010 = env32011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32010 == env32011) = true)

theorem identity32011 : scanCanonicalize (H12AffineFastState.compose env32011 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32011 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env32012 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,33167,5393,10280,1025,32769,4113,32937,8597,8582,8328,17,43277,13461,12677,35245,1421,32,257,32,46212,41860]

theorem envBound32012 : H12AffineFastState.Bounded env32012 := by
  intro p hp
  have h : env32012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32011_32012 : H12AffineEnvironment.transform 5 17 env32011 = env32012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32011 == env32012) = true)

theorem identity32012 : scanCanonicalize (H12AffineFastState.compose env32012 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound32012 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32013 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,32768,33167,5393,2476,1025,32769,4113,32937,17,2,268,17,34953,5393,4097,35245,1421,32,257,32,38144,33280]

theorem envBound32013 : H12AffineFastState.Bounded env32013 := by
  intro p hp
  have h : env32013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32012_32013 : H12AffineEnvironment.transform 12 388 env32012 = env32013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env32012 == env32013) = true)

theorem identity32013 : scanCanonicalize (H12AffineFastState.compose env32013 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound32013 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32014 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,428,35,5393,2476,1025,429,4113,261,17,2,268,17,2341,5393,4097,2049,1421,32,257,32,5292,940]

theorem envBound32014 : H12AffineFastState.Bounded env32014 := by
  intro p hp
  have h : env32014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32013_32014 : H12AffineEnvironment.transform 14 428 env32013 = env32014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env32013 == env32014) = true)

theorem identity32014 : scanCanonicalize (H12AffineFastState.compose env32014 (packedSelected [2,3,4,5,6,7,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound32014 : packedSelected [2,3,4,5,6,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32015 : List Nat := [2,4,8,16,32,17,128,256,512,1024,429,4096,388,5376,428,35,5393,1,1025,429,4113,261,17,2,268,17,136,5393,4097,428,1421,32,257,32,5292,940]

theorem envBound32015 : H12AffineFastState.Bounded env32015 := by
  intro p hp
  have h : env32015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32014_32015 : H12AffineEnvironment.transform 10 429 env32014 = env32015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env32014 == env32015) = true)

theorem identity32015 : scanCanonicalize (H12AffineFastState.compose env32015 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound32015 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32016 : List Nat := [2,4,8,16,32,17,128,256,512,1024,429,48,388,1328,428,35,1313,1,1025,429,33,261,17,2,268,17,136,1313,49,428,1421,32,257,32,1180,940]

theorem envBound32016 : H12AffineFastState.Bounded env32016 := by
  intro p hp
  have h : env32016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32015_32016 : H12AffineEnvironment.transform 11 48 env32015 = env32016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32015 == env32016) = true)

theorem identity32016 : scanCanonicalize (H12AffineFastState.compose env32016 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound32016 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32017 : List Nat := [2,4,8,16,32,17,128,256,512,305,429,48,388,1,428,35,16,1,304,429,33,261,17,2,268,17,136,16,49,428,188,32,257,32,429,940]

theorem envBound32017 : H12AffineFastState.Bounded env32017 := by
  intro p hp
  have h : env32017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32016_32017 : H12AffineEnvironment.transform 9 305 env32016 = env32017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env32016 == env32017) = true)

theorem identity32017 : scanCanonicalize (H12AffineFastState.compose env32017 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32017 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32018 : List Nat := [2,4,8,16,32,17,128,37,512,20,136,48,161,1,137,35,16,1,21,136,33,32,17,2,41,17,136,16,49,137,188,32,36,32,136,649]

theorem envBound32018 : H12AffineFastState.Bounded env32018 := by
  intro p hp
  have h : env32018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32017_32018 : H12AffineEnvironment.transform 7 37 env32017 = env32018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32017 == env32018) = true)

theorem identity32018 : scanCanonicalize (H12AffineFastState.compose env32018 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 157) := by decide +kernel

theorem selectedBound32018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32019 : List Nat := [2,4,8,16,32,17,128,37,157,20,136,48,161,1,137,35,16,1,21,136,33,32,17,2,41,17,136,16,49,137,188,32,36,32,136,20]

theorem envBound32019 : H12AffineFastState.Bounded env32019 := by
  intro p hp
  have h : env32019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32018_32019 : H12AffineEnvironment.transform 8 157 env32018 = env32019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 157 env32018 == env32019) = true)

def env32020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,262144,1025,32769,4160,305361,29844,8583,8328,64,43356,24980,12676,324820,1500,272392,257,21792,46212,63189]

theorem envBound32020 : H12AffineFastState.Bounded env32020 := by
  intro p hp
  have h : env32020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32008_32020 : H12AffineEnvironment.transform 16 16449 env32008 = env32020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env32008 == env32020) = true)

theorem identity32020 : scanCanonicalize (H12AffineFastState.compose env32020 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound32020 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,32768,33030,5529,262144,1025,32769,4160,305361,8524,8583,8328,64,43356,13388,12676,303372,1500,272392,257,248,46212,41741]

theorem envBound32021 : H12AffineFastState.Bounded env32021 := by
  intro p hp
  have h : env32021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32020_32021 : H12AffineEnvironment.transform 13 5592 env32020 = env32021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env32020 == env32021) = true)

theorem identity32021 : scanCanonicalize (H12AffineFastState.compose env32021 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound32021 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env32022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,32768,33030,5529,35244,1025,32769,4160,8573,8524,8583,8328,64,43356,13388,12676,10400,1500,41380,257,248,46212,41741]

theorem envBound32022 : H12AffineFastState.Bounded env32022 := by
  intro p hp
  have h : env32022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32021_32022 : H12AffineEnvironment.transform 17 35244 env32021 = env32022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env32021 == env32022) = true)

theorem identity32022 : scanCanonicalize (H12AffineFastState.compose env32022 (packedSelected [0,1,2,6,7,8,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound32022 : packedSelected [0,1,2,6,7,8,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8661,8403,5529,10361,1025,8660,4160,8573,8524,8583,8328,64,2185,13388,12676,10400,1500,113,257,248,5457,728]

theorem envBound32023 : H12AffineFastState.Bounded env32023 := by
  intro p hp
  have h : env32023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32022_32023 : H12AffineEnvironment.transform 14 8661 env32022 = env32023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env32022 == env32023) = true)

theorem identity32023 : scanCanonicalize (H12AffineFastState.compose env32023 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32023 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env32024 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8461,8203,5441,10361,1025,8460,4160,8573,8524,8543,8272,64,2129,13388,12636,10360,1284,113,257,32,5457,512]

theorem envBound32024 : H12AffineFastState.Bounded env32024 := by
  intro p hp
  have h : env32024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32023_32024 : H12AffineEnvironment.transform 6 88 env32023 = env32024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32023 == env32024) = true)

theorem identity32024 : scanCanonicalize (H12AffineFastState.compose env32024 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2373) := by decide +kernel

theorem selectedBound32024 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32025 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2373,8192,3141,8461,8203,3076,10361,1025,8460,2309,8573,8524,8543,8272,64,2129,11529,10265,10360,1284,113,257,32,3092,512]

theorem envBound32025 : H12AffineFastState.Bounded env32025 := by
  intro p hp
  have h : env32025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32024_32025 : H12AffineEnvironment.transform 11 2373 env32024 = env32025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2373 env32024 == env32025) = true)

theorem identity32025 : scanCanonicalize (H12AffineFastState.compose env32025 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32025 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32026 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,2144,8192,3141,8232,8203,3076,10361,1025,8233,2080,8280,8297,8314,8272,64,2129,11308,10265,10360,1057,113,36,32,3092,512]

theorem envBound32026 : H12AffineFastState.Bounded env32026 := by
  intro p hp
  have h : env32026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32025_32026 : H12AffineEnvironment.transform 7 37 env32025 = env32026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32025 == env32026) = true)

theorem identity32026 : scanCanonicalize (H12AffineFastState.compose env32026 (packedSelected [4,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound32026 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env32027 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,2144,8,3141,32,3,3076,2161,1025,33,2080,80,97,114,88,64,2129,3108,2065,2160,1057,113,36,32,3092,512]

theorem envBound32027 : H12AffineFastState.Bounded env32027 := by
  intro p hp
  have h : env32027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32026_32027 : H12AffineEnvironment.transform 12 8 env32026 = env32027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env32026 == env32027) = true)

theorem identity32027 : scanCanonicalize (H12AffineFastState.compose env32027 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32027 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env32028 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2096,8,3093,32,3,3076,2081,1025,33,2080,0,49,34,8,16,2049,3108,2065,2080,1057,33,36,32,3092,512]

theorem envBound32028 : H12AffineFastState.Bounded env32028 := by
  intro p hp
  have h : env32028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32027_32028 : H12AffineEnvironment.transform 5 16 env32027 = env32028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32027 == env32028) = true)

theorem identity32028 : scanCanonicalize (H12AffineFastState.compose env32028 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound32028 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env32029 : List Nat := [2,4,8,16,32,16,8,37,512,1024,554,538,8,1599,32,3,1582,523,1025,33,522,0,49,34,8,16,555,1550,571,522,1057,33,36,32,1598,512]

theorem envBound32029 : H12AffineFastState.Bounded env32029 := by
  intro p hp
  have h : env32029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32028_32029 : H12AffineEnvironment.transform 10 554 env32028 = env32029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env32028 == env32029) = true)

theorem identity32029 : scanCanonicalize (H12AffineFastState.compose env32029 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound32029 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32030 : List Nat := [2,4,8,2,32,2,8,37,512,1024,554,520,8,1581,32,3,1582,523,1025,33,522,0,35,34,8,2,555,1550,553,522,1057,33,36,32,1580,512]

theorem envBound32030 : H12AffineFastState.Bounded env32030 := by
  intro p hp
  have h : env32030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32029_32030 : H12AffineEnvironment.transform 3 2 env32029 = env32030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env32029 == env32030) = true)

theorem identity32030 : scanCanonicalize (H12AffineFastState.compose env32030 (packedSelected [0,1,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32030 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env32031 : List Nat := [2,4,8,2,0,2,8,5,512,1024,522,520,8,1549,0,3,1550,523,1025,1,522,0,3,2,8,2,523,1550,521,522,1025,1,4,0,1548,512]

theorem envBound32031 : H12AffineFastState.Bounded env32031 := by
  intro p hp
  have h : env32031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32030_32031 : H12AffineEnvironment.transform 4 0 env32030 = env32031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32030 == env32031) = true)

theorem identity32031 : scanCanonicalize (H12AffineFastState.compose env32031 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound32031 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32032 : List Nat := [2,4,8,2,0,2,8,5,512,6,522,520,8,523,0,3,520,523,7,1,522,0,3,2,8,2,523,520,521,522,7,1,4,0,522,512]

theorem envBound32032 : H12AffineFastState.Bounded env32032 := by
  intro p hp
  have h : env32032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32031_32032 : H12AffineEnvironment.transform 9 6 env32031 = env32032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env32031 == env32032) = true)

theorem identity32032 : scanCanonicalize (H12AffineFastState.compose env32032 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound32032 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32033 : List Nat := [2,4,8,2,0,2,8,5,12,6,6,4,8,7,0,3,4,7,7,1,6,0,3,2,8,2,7,4,5,6,7,1,4,0,6,12]

theorem envBound32033 : H12AffineFastState.Bounded env32033 := by
  intro p hp
  have h : env32033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32032_32033 : H12AffineEnvironment.transform 8 12 env32032 = env32033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env32032 == env32033) = true)

def env32034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253963,242968,8328,64,97666,139732,238874,335882,119042,272393,257,98815,90203,63189]

theorem envBound32034 : H12AffineFastState.Bounded env32034 := by
  intro p hp
  have h : env32034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32006_32034 : H12AffineEnvironment.transform 20 4161 env32006 = env32034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32006 == env32034) = true)

theorem identity32034 : scanCanonicalize (H12AffineFastState.compose env32034 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound32034 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,4161,392286,62661,41430,8328,64,97666,79130,45524,335882,119042,272393,257,98815,90203,63189]

theorem envBound32035 : H12AffineFastState.Bounded env32035 := by
  intro p hp
  have h : env32035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32034_32035 : H12AffineEnvironment.transform 16 70862 env32034 = env32035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env32034 == env32035) = true)

theorem identity32035 : scanCanonicalize (H12AffineFastState.compose env32035 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32035 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env32036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70862,262144,1025,29909,4161,329866,17,21762,8328,64,97666,79130,17664,335882,75222,272393,257,95531,90203,513]

theorem envBound32036 : H12AffineFastState.Bounded env32036 := by
  intro p hp
  have h : env32036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32035_32036 : H12AffineEnvironment.transform 14 29908 env32035 = env32036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32035 == env32036) = true)

theorem identity32036 : scanCanonicalize (H12AffineFastState.compose env32036 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32036 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env32037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,262144,1025,29789,4161,329730,17,21762,8192,64,97546,79130,17664,335882,75102,272393,257,95531,90203,513]

theorem envBound32037 : H12AffineFastState.Bounded env32037 := by
  intro p hp
  have h : env32037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32036_32037 : H12AffineEnvironment.transform 6 8 env32036 = env32037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32036 == env32037) = true)

theorem identity32037 : scanCanonicalize (H12AffineFastState.compose env32037 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32037 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,10280,1025,29789,4161,73770,17,21762,8192,64,97546,79130,17664,67618,75102,33,257,95531,90203,513]

theorem envBound32038 : H12AffineFastState.Bounded env32038 := by
  intro p hp
  have h : env32038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32037_32038 : H12AffineEnvironment.transform 17 10280 env32037 = env32038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32037 == env32038) = true)

theorem identity32038 : scanCanonicalize (H12AffineFastState.compose env32038 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32038 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env32039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,65536,70726,10280,1025,80,4161,73770,17,8463,8192,64,67847,79130,12557,67618,75102,33,257,65830,70742,513]

theorem envBound32039 : H12AffineFastState.Bounded env32039 := by
  intro p hp
  have h : env32039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32038_32039 : H12AffineEnvironment.transform 13 13325 env32038 = env32039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32038 == env32039) = true)

theorem identity32039 : scanCanonicalize (H12AffineFastState.compose env32039 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32039 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env32040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,81,65536,70726,2420,1025,80,4161,65910,17,83,348,64,67847,70726,4177,67618,66562,33,257,65830,70742,513]

theorem envBound32040 : H12AffineFastState.Bounded env32040 := by
  intro p hp
  have h : env32040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32039_32040 : H12AffineEnvironment.transform 12 348 env32039 = env32040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32039 == env32040) = true)

theorem identity32040 : scanCanonicalize (H12AffineFastState.compose env32040 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound32040 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env32041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,81,262,5440,2420,1025,80,4161,112,17,83,348,64,2049,5440,4177,2340,1284,33,257,32,5456,513]

theorem envBound32041 : H12AffineFastState.Bounded env32041 := by
  intro p hp
  have h : env32041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32040_32041 : H12AffineEnvironment.transform 15 262 env32040 = env32041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env32040 == env32041) = true)

def env32042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253963,242969,8328,64,97667,2240916,2340187,335882,119043,2373705,257,2199999,2191387,63188]

theorem envBound32042 : H12AffineFastState.Bounded env32042 := by
  intro p hp
  have h : env32042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32005_32042 : H12AffineEnvironment.transform 23 242969 env32005 = env32042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env32005 == env32042) = true)

def env32043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253963,242969,8328,64,97667,139732,238875,335882,119043,272393,257,98815,90203,63188]

theorem envBound32043 : H12AffineFastState.Bounded env32043 := by
  intro p hp
  have h : env32043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32042_32043 : H12AffineEnvironment.transform 20 4160 env32042 = env32043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32042 == env32043) = true)

theorem identity32043 : scanCanonicalize (H12AffineFastState.compose env32043 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound32043 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,329866,17,21763,8328,64,97667,115150,17665,335882,119043,272393,257,98815,90203,63188]

theorem envBound32044 : H12AffineFastState.Bounded env32044 := by
  intro p hp
  have h : env32044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32043_32044 : H12AffineEnvironment.transform 16 122906 env32043 = env32044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env32043 == env32044) = true)

def env32045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,329730,17,21763,8192,64,97547,115014,17665,335882,119043,272393,257,98679,90203,63068]

theorem envBound32045 : H12AffineFastState.Bounded env32045 := by
  intro p hp
  have h : env32045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32044_32045 : H12AffineEnvironment.transform 6 8 env32044 = env32045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32044 == env32045) = true)

theorem identity32045 : scanCanonicalize (H12AffineFastState.compose env32045 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32045 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,4160,73770,17,21763,8192,64,97547,115014,17665,67618,119043,33,257,98679,90203,63068]

theorem envBound32046 : H12AffineFastState.Bounded env32046 := by
  intro p hp
  have h : env32046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32045_32046 : H12AffineEnvironment.transform 17 10280 env32045 = env32046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32045 == env32046) = true)

theorem identity32046 : scanCanonicalize (H12AffineFastState.compose env32046 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound32046 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,46156,10280,1025,32769,4160,29820,17,21763,8192,64,10589,38160,17665,23668,34133,33,257,54561,13325,63068]

theorem envBound32047 : H12AffineFastState.Bounded env32047 := by
  intro p hp
  have h : env32047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32046_32047 : H12AffineEnvironment.transform 15 21590 env32046 = env32047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env32046 == env32047) = true)

theorem identity32047 : scanCanonicalize (H12AffineFastState.compose env32047 (packedSelected [0,3,4,5,7,10,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32047 : packedSelected [0,3,4,5,7,10,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8203,46156,10280,1025,32769,4160,33,17,8542,8192,64,10589,38160,12636,10281,34133,33,257,41340,13325,33281]

theorem envBound32048 : H12AffineFastState.Bounded env32048 := by
  intro p hp
  have h : env32048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32047_32048 : H12AffineEnvironment.transform 13 13405 env32047 = env32048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32047 == env32048) = true)

theorem identity32048 : scanCanonicalize (H12AffineFastState.compose env32048 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32048 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32049 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,32768,8203,46109,10280,1025,32769,4113,33,17,8463,8192,17,10508,38160,12557,10281,34052,33,257,41261,13325,33281]

theorem envBound32049 : H12AffineFastState.Bounded env32049 := by
  intro p hp
  have h : env32049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32048_32049 : H12AffineEnvironment.transform 5 17 env32048 = env32049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32048 == env32049) = true)

theorem identity32049 : scanCanonicalize (H12AffineFastState.compose env32049 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound32049 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32050 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,8192,11293,32768,8203,44044,10280,1025,32769,2048,33,17,8463,8192,17,10508,36097,10524,10281,34052,33,257,41261,11292,33281]

theorem envBound32050 : H12AffineFastState.Bounded env32050 := by
  intro p hp
  have h : env32050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32049_32050 : H12AffineEnvironment.transform 11 2065 env32049 = env32050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env32049 == env32050) = true)

theorem identity32050 : scanCanonicalize (H12AffineFastState.compose env32050 (packedSelected [1,2,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound32050 : packedSelected [1,2,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32051 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1281,1296,8192,8476,32768,8203,41229,9513,1025,32769,1281,33,17,8463,8192,17,9229,32768,9245,9512,34052,33,257,41261,8477,33281]

theorem envBound32051 : H12AffineFastState.Bounded env32051 := by
  intro p hp
  have h : env32051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32050_32051 : H12AffineEnvironment.transform 10 1281 env32050 = env32051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env32050 == env32051) = true)

theorem identity32051 : scanCanonicalize (H12AffineFastState.compose env32051 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1565) := by decide +kernel

theorem selectedBound32051 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env32052 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1281,1296,1565,1793,32768,1558,34576,820,1025,32769,1281,33,17,1810,1565,17,528,32768,512,821,34052,33,257,34608,1792,33281]

theorem envBound32052 : H12AffineFastState.Bounded env32052 := by
  intro p hp
  have h : env32052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32051_32052 : H12AffineEnvironment.transform 12 1565 env32051 = env32052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1565 env32051 == env32052) = true)

theorem identity32052 : scanCanonicalize (H12AffineFastState.compose env32052 (packedSelected [2,3,5,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound32052 : packedSelected [2,3,5,12,14] rootPS < 2^1333 := by decide +kernel

def env32053 : List Nat := [2,4,8,16,32,17,8,256,512,784,529,512,269,17,32768,262,32768,820,785,32769,529,33,17,2,269,17,528,32768,512,821,33300,33,257,32800,16,33281]

theorem envBound32053 : H12AffineFastState.Bounded env32053 := by
  intro p hp
  have h : env32053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32052_32053 : H12AffineEnvironment.transform 9 784 env32052 = env32053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env32052 == env32053) = true)

theorem identity32053 : scanCanonicalize (H12AffineFastState.compose env32053 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32053 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32054 : List Nat := [2,4,8,16,32,17,8,37,512,565,529,512,40,17,32768,35,32768,529,564,32769,529,33,17,2,40,17,528,32768,512,528,33300,33,36,32800,16,33281]

theorem envBound32054 : H12AffineFastState.Bounded env32054 := by
  intro p hp
  have h : env32054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32053_32054 : H12AffineEnvironment.transform 7 37 env32053 = env32054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32053 == env32054) = true)

def env32055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,329731,17,21763,8193,64,97546,115015,17665,335882,119043,272393,257,98678,90203,63069]

theorem envBound32055 : H12AffineFastState.Bounded env32055 := by
  intro p hp
  have h : env32055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32044_32055 : H12AffineEnvironment.transform 6 9 env32044 = env32055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32044 == env32055) = true)

theorem identity32055 : scanCanonicalize (H12AffineFastState.compose env32055 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound32055 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35188,1025,32769,4160,98679,17,21763,8193,64,97546,115015,17665,108926,119043,41341,257,98678,90203,63069]

theorem envBound32056 : H12AffineFastState.Bounded env32056 := by
  intro p hp
  have h : env32056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32055_32056 : H12AffineEnvironment.transform 17 35188 env32055 = env32056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env32055 == env32056) = true)

theorem identity32056 : scanCanonicalize (H12AffineFastState.compose env32056 (packedSelected [16,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound32056 : packedSelected [16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env32057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,90186,2340,1025,81,4160,65831,17,21763,8193,64,97546,82199,17665,76078,86355,8493,257,65830,90203,30221]

theorem envBound32057 : H12AffineFastState.Bounded env32057 := by
  intro p hp
  have h : env32057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32056_32057 : H12AffineEnvironment.transform 14 80 env32056 = env32057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env32056 == env32057) = true)

theorem identity32057 : scanCanonicalize (H12AffineFastState.compose env32057 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32057 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env32058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,65536,79179,2340,1025,81,4160,65831,17,2,8193,64,75787,70678,4096,76078,66642,8493,257,65830,79194,8972]

theorem envBound32058 : H12AffineFastState.Bounded env32058 := by
  intro p hp
  have h : env32058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32057_32058 : H12AffineEnvironment.transform 13 5377 env32057 = env32058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32057 == env32058) = true)

theorem identity32058 : scanCanonicalize (H12AffineFastState.compose env32058 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32058 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32059 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5157,80,65536,78959,2048,1025,81,4160,65539,17,2,8193,64,75787,70678,4096,75786,66642,8201,37,65538,78974,8744]

theorem envBound32059 : H12AffineFastState.Bounded env32059 := by
  intro p hp
  have h : env32059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32058_32059 : H12AffineEnvironment.transform 7 36 env32058 = env32059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32058 == env32059) = true)

theorem identity32059 : scanCanonicalize (H12AffineFastState.compose env32059 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32059 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env32060 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5157,80,8202,5221,2048,1025,81,4160,8201,17,2,8193,64,2049,13340,4096,2048,9304,8201,37,8200,5236,8744]

theorem envBound32060 : H12AffineFastState.Bounded env32060 := by
  intro p hp
  have h : env32060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32059_32060 : H12AffineEnvironment.transform 15 8202 env32059 = env32060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32059 == env32060) = true)

theorem identity32060 : scanCanonicalize (H12AffineFastState.compose env32060 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound32060 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32061 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,80,115,5221,2048,1025,81,4160,112,17,2,120,64,2049,5221,4096,2048,1057,112,37,113,5236,593]

theorem envBound32061 : H12AffineFastState.Bounded env32061 := by
  intro p hp
  have h : env32061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32060_32061 : H12AffineEnvironment.transform 12 121 env32060 = env32061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env32060 == env32061) = true)

theorem identity32061 : scanCanonicalize (H12AffineFastState.compose env32061 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound32061 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32062 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,64,121,1125,80,115,1061,2048,1025,81,0,112,17,2,120,64,2049,1061,64,2048,1057,112,37,113,1076,593]

theorem envBound32062 : H12AffineFastState.Bounded env32062 := by
  intro p hp
  have h : env32062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32061_32062 : H12AffineEnvironment.transform 11 64 env32061 = env32062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env32061 == env32062) = true)

theorem identity32062 : scanCanonicalize (H12AffineFastState.compose env32062 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound32062 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env32063 : List Nat := [2,4,8,16,32,64,9,36,512,1024,81,64,121,1125,80,115,1061,81,1025,81,0,112,17,2,120,64,80,1061,64,81,1057,112,37,113,1076,593]

theorem envBound32063 : H12AffineFastState.Bounded env32063 := by
  intro p hp
  have h : env32063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32062_32063 : H12AffineEnvironment.transform 10 81 env32062 = env32063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env32062 == env32063) = true)

theorem identity32063 : scanCanonicalize (H12AffineFastState.compose env32063 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32063 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32064 : List Nat := [2,4,8,16,32,64,9,36,512,53,81,64,121,80,80,115,16,81,52,81,0,112,17,2,120,64,80,16,64,81,20,112,37,113,1,593]

theorem envBound32064 : H12AffineFastState.Bounded env32064 := by
  intro p hp
  have h : env32064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32063_32064 : H12AffineEnvironment.transform 9 53 env32063 = env32064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32063 == env32064) = true)

theorem identity32064 : scanCanonicalize (H12AffineFastState.compose env32064 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32064 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env32065 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,16,41,0,0,35,16,1,52,1,0,32,17,2,40,16,0,16,16,1,20,32,37,33,1,513]

theorem envBound32065 : H12AffineFastState.Bounded env32065 := by
  intro p hp
  have h : env32065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32064_32065 : H12AffineEnvironment.transform 5 16 env32064 = env32065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32064 == env32065) = true)

theorem identity32065 : scanCanonicalize (H12AffineFastState.compose env32065 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32066 : List Nat := [2,4,8,16,17,16,9,21,512,4,1,16,24,0,0,18,16,1,5,1,0,17,17,2,25,16,0,16,16,1,20,17,20,16,1,513]

theorem envBound32066 : H12AffineFastState.Bounded env32066 := by
  intro p hp
  have h : env32066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32065_32066 : H12AffineEnvironment.transform 4 17 env32065 = env32066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32065 == env32066) = true)

theorem identity32066 : scanCanonicalize (H12AffineFastState.compose env32066 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound32066 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32067 : List Nat := [2,4,8,16,17,16,9,21,16,4,1,16,24,0,0,18,16,1,5,1,0,17,17,2,25,16,0,16,16,1,20,17,20,16,1,17]

theorem envBound32067 : H12AffineFastState.Bounded env32067 := by
  intro p hp
  have h : env32067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32066_32067 : H12AffineEnvironment.transform 8 16 env32066 = env32067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env32066 == env32067) = true)

def env32068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253963,242969,8328,64,97667,139733,238874,335882,119043,272392,257,98814,90202,63188]

theorem envBound32068 : H12AffineFastState.Bounded env32068 := by
  intro p hp
  have h : env32068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32042_32068 : H12AffineEnvironment.transform 20 4161 env32042 = env32068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32042 == env32068) = true)

theorem identity32068 : scanCanonicalize (H12AffineFastState.compose env32068 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32068 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452752,180225,169235,8328,64,23945,139733,165136,262144,61705,272392,257,41460,16464,63188]

theorem envBound32069 : H12AffineFastState.Bounded env32069 := by
  intro p hp
  have h : env32069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32068_32069 : H12AffineEnvironment.transform 15 8202 env32068 = env32069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32068 == env32069) = true)

def env32070 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452680,180225,169235,8272,64,23889,139533,165136,262144,61705,272392,257,41260,16464,62988]

theorem envBound32070 : H12AffineFastState.Bounded env32070 := by
  intro p hp
  have h : env32070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32069_32070 : H12AffineEnvironment.transform 6 88 env32069 = env32070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32069 == env32070) = true)

theorem identity32070 : scanCanonicalize (H12AffineFastState.compose env32070 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound32070 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32071 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57677,262144,1025,32769,4161,264453,8524,29790,8272,64,23889,49216,25693,262144,61705,272392,257,41260,16464,62988]

theorem envBound32071 : H12AffineFastState.Bounded env32071 := by
  intro p hp
  have h : env32071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32070_32071 : H12AffineEnvironment.transform 16 57677 env32070 = env32071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env32070 == env32071) = true)

theorem identity32071 : scanCanonicalize (H12AffineFastState.compose env32071 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32071 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env32072 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57677,10280,1025,32769,4161,8493,8524,29790,8272,64,23889,49216,25693,10280,61705,32,257,41260,16464,62988]

theorem envBound32072 : H12AffineFastState.Bounded env32072 := by
  intro p hp
  have h : env32072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32071_32072 : H12AffineEnvironment.transform 17 10280 env32071 = env32072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32071 == env32072) = true)

theorem identity32072 : scanCanonicalize (H12AffineFastState.compose env32072 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound32072 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32073 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21841,8202,13340,10280,1025,21840,4161,8493,8524,29790,8272,64,23889,5393,25693,10280,9304,32,257,29821,16464,9053]

theorem envBound32073 : H12AffineFastState.Bounded env32073 := by
  intro p hp
  have h : env32073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32072_32073 : H12AffineEnvironment.transform 14 21841 env32072 = env32073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env32072 == env32073) = true)

theorem identity32073 : scanCanonicalize (H12AffineFastState.compose env32073 (packedSelected [1,8,16,17,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32073 : packedSelected [1,8,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32074 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,8202,13340,10280,1025,21761,4112,8493,8477,29711,8193,17,23808,5393,25612,10280,9225,32,257,29740,16385,8972]

theorem envBound32074 : H12AffineFastState.Bounded env32074 := by
  intro p hp
  have h : env32074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32073_32074 : H12AffineEnvironment.transform 5 17 env32073 = env32074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32073 == env32074) = true)

theorem identity32074 : scanCanonicalize (H12AffineFastState.compose env32074 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound32074 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env32075 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13609,8233,8202,13340,10280,1025,8232,4112,8493,8477,294,8193,17,10281,5393,4389,10280,9225,32,257,261,13608,8972]

theorem envBound32075 : H12AffineFastState.Bounded env32075 := by
  intro p hp
  have h : env32075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32074_32075 : H12AffineEnvironment.transform 13 13609 env32074 = env32075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env32074 == env32075) = true)

theorem identity32075 : scanCanonicalize (H12AffineFastState.compose env32075 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32075 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32076 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,8192,13576,8200,8202,13340,10249,1025,8201,4112,8460,8477,263,8193,17,10248,5393,4356,10249,9225,1,257,261,13577,8972]

theorem envBound32076 : H12AffineFastState.Bounded env32076 := by
  intro p hp
  have h : env32076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32075_32076 : H12AffineEnvironment.transform 4 1 env32075 = env32076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32075 == env32076) = true)

theorem identity32076 : scanCanonicalize (H12AffineFastState.compose env32076 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32077 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8192,13324,8200,8202,13340,10249,1025,8201,4112,8200,8217,3,8193,17,10248,5141,4096,10249,9225,1,5,1,13325,8712]

theorem envBound32077 : H12AffineFastState.Bounded env32077 := by
  intro p hp
  have h : env32077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32076_32077 : H12AffineEnvironment.transform 7 4 env32076 = env32077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32076 == env32077) = true)

theorem identity32077 : scanCanonicalize (H12AffineFastState.compose env32077 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound32077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32078 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,25,5141,17,19,5125,2064,1025,16,4112,17,0,3,24,17,2065,5141,4096,2064,1040,1,5,1,5140,529]

theorem envBound32078 : H12AffineFastState.Bounded env32078 := by
  intro p hp
  have h : env32078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32077_32078 : H12AffineEnvironment.transform 12 25 env32077 = env32078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env32077 == env32078) = true)

theorem identity32078 : scanCanonicalize (H12AffineFastState.compose env32078 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32078 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env32079 : List Nat := [2,4,8,0,1,1,9,4,512,1024,2048,4096,9,5125,1,3,5125,2048,1025,0,4096,1,0,3,8,1,2049,5125,4096,2048,1024,1,5,1,5124,513]

theorem envBound32079 : H12AffineFastState.Bounded env32079 := by
  intro p hp
  have h : env32079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32078_32079 : H12AffineEnvironment.transform 3 0 env32078 = env32079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32078 == env32079) = true)

theorem identity32079 : scanCanonicalize (H12AffineFastState.compose env32079 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound32079 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32080 : List Nat := [2,4,8,0,1,1,9,4,512,1024,2048,513,9,1540,1,3,1540,2048,1025,0,513,1,0,3,8,1,2049,1540,513,2048,1024,1,5,1,1541,513]

theorem envBound32080 : H12AffineFastState.Bounded env32080 := by
  intro p hp
  have h : env32080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32079_32080 : H12AffineEnvironment.transform 11 513 env32079 = env32080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env32079 == env32080) = true)

theorem identity32080 : scanCanonicalize (H12AffineFastState.compose env32080 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32080 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32081 : List Nat := [2,4,8,0,1,1,9,4,512,4,2048,513,9,512,1,3,512,2048,5,0,513,1,0,3,8,1,2049,512,513,2048,4,1,5,1,513,513]

theorem envBound32081 : H12AffineFastState.Bounded env32081 := by
  intro p hp
  have h : env32081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32080_32081 : H12AffineEnvironment.transform 9 4 env32080 = env32081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32080 == env32081) = true)

theorem identity32081 : scanCanonicalize (H12AffineFastState.compose env32081 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32082 : List Nat := [2,4,8,0,1,1,9,4,512,4,0,513,9,512,1,3,512,0,5,0,513,1,0,3,8,1,1,512,513,0,4,1,5,1,513,513]

theorem envBound32082 : H12AffineFastState.Bounded env32082 := by
  intro p hp
  have h : env32082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32081_32082 : H12AffineEnvironment.transform 10 0 env32081 = env32082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32081 == env32082) = true)

theorem identity32082 : scanCanonicalize (H12AffineFastState.compose env32082 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32083 : List Nat := [2,4,8,0,1,1,9,4,1,4,0,0,9,1,1,3,1,0,5,0,0,1,0,3,8,1,1,1,0,0,4,1,5,1,0,0]

theorem envBound32083 : H12AffineFastState.Bounded env32083 := by
  intro p hp
  have h : env32083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32082_32083 : H12AffineEnvironment.transform 8 1 env32082 = env32083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32082 == env32083) = true)

def env32084 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452681,180225,169235,8273,64,23888,139532,165136,262144,61705,272392,257,41261,16464,62989]

theorem envBound32084 : H12AffineFastState.Bounded env32084 := by
  intro p hp
  have h : env32084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32069_32084 : H12AffineEnvironment.transform 6 89 env32069 = env32084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env32069 == env32084) = true)

theorem identity32084 : scanCanonicalize (H12AffineFastState.compose env32084 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound32084 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32085 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,262144,1025,32769,4161,327001,54545,32771,8273,64,23888,13340,36864,262144,61705,272392,257,41261,16464,62989]

theorem envBound32085 : H12AffineFastState.Bounded env32085 := by
  intro p hp
  have h : env32085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32084_32085 : H12AffineEnvironment.transform 16 5392 env32084 = env32085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env32084 == env32085) = true)

theorem identity32085 : scanCanonicalize (H12AffineFastState.compose env32085 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32085 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32086 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,10280,1025,32769,4161,54641,54545,32771,8273,64,23888,13340,36864,10280,61705,32,257,41261,16464,62989]

theorem envBound32086 : H12AffineFastState.Bounded env32086 := by
  intro p hp
  have h : env32086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32085_32086 : H12AffineEnvironment.transform 17 10280 env32085 = env32086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32085 == env32086) = true)

theorem identity32086 : scanCanonicalize (H12AffineFastState.compose env32086 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound32086 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32087 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21840,8202,5392,10280,1025,21841,4161,33,65,21843,8273,64,23888,13340,17744,10280,9305,32,257,29821,16464,9053]

theorem envBound32087 : H12AffineFastState.Bounded env32087 := by
  intro p hp
  have h : env32087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32086_32087 : H12AffineEnvironment.transform 14 21840 env32086 = env32087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env32086 == env32087) = true)

theorem identity32087 : scanCanonicalize (H12AffineFastState.compose env32087 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32087 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32088 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,16384,21840,342,5392,2420,1025,21841,4161,33,65,21843,269,64,23888,5440,17744,2420,1285,32,257,21793,16464,513]

theorem envBound32088 : H12AffineFastState.Bounded env32088 := by
  intro p hp
  have h : env32088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32087_32088 : H12AffineEnvironment.transform 12 348 env32087 = env32088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32087 == env32088) = true)

theorem identity32088 : scanCanonicalize (H12AffineFastState.compose env32088 (packedSelected [2,6,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32088 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env32089 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5376,80,342,5392,2420,1025,81,4161,33,65,83,269,64,2128,5440,4176,2420,1285,32,257,33,5456,513]

theorem envBound32089 : H12AffineFastState.Bounded env32089 := by
  intro p hp
  have h : env32089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32088_32089 : H12AffineEnvironment.transform 13 5376 env32088 = env32089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32088 == env32089) = true)

def env32090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253963,16777216,8328,64,16959643,18973837,2340187,335882,16933914,19369297,257,19014822,19055874,16991181]

theorem envBound32090 : H12AffineFastState.Bounded env32090 := by
  intro p hp
  have h : env32090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32004_32090 : H12AffineEnvironment.transform 21 452753 env32004 = env32090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env32004 == env32090) = true)

def env32091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253963,242968,8328,64,97667,2240917,2340187,335882,119042,2373705,257,2199998,2191386,63189]

theorem envBound32091 : H12AffineFastState.Bounded env32091 := by
  intro p hp
  have h : env32091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32090_32091 : H12AffineEnvironment.transform 23 242968 env32090 = env32091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env32090 == env32091) = true)

def env32092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253963,242968,8328,64,97667,139733,238875,335882,119042,272393,257,98814,90202,63189]

theorem envBound32092 : H12AffineFastState.Bounded env32092 := by
  intro p hp
  have h : env32092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32091_32092 : H12AffineEnvironment.transform 20 4160 env32091 = env32092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32091 == env32092) = true)

theorem identity32092 : scanCanonicalize (H12AffineFastState.compose env32092 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound32092 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4160,318549,120015,98780,8328,64,97667,5393,102879,335882,119042,272393,257,98814,90202,63189]

theorem envBound32093 : H12AffineFastState.Bounded env32093 := by
  intro p hp
  have h : env32093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32092_32093 : H12AffineEnvironment.transform 16 13508 env32092 = env32093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env32092 == env32093) = true)

def env32094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318549,119879,98644,8192,64,97547,5393,102743,335882,119042,272393,257,98678,90202,63069]

theorem envBound32094 : H12AffineFastState.Bounded env32094 := by
  intro p hp
  have h : env32094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32093_32094 : H12AffineEnvironment.transform 6 8 env32093 = env32094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32093 == env32094) = true)

theorem identity32094 : scanCanonicalize (H12AffineFastState.compose env32094 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound32094 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env32095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35189,1025,32769,4160,21792,119879,98644,8192,64,97547,5393,102743,108927,119042,41340,257,98678,90202,63069]

theorem envBound32095 : H12AffineFastState.Bounded env32095 := by
  intro p hp
  have h : env32095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32094_32095 : H12AffineEnvironment.transform 17 35189 env32094 = env32095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env32094 == env32095) = true)

theorem identity32095 : scanCanonicalize (H12AffineFastState.compose env32095 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32095 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env32096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,13388,2420,1025,0,4160,21792,87110,65877,8192,64,97547,5393,69974,76158,86275,8573,257,65911,90202,30300]

theorem envBound32096 : H12AffineFastState.Bounded env32096 := by
  intro p hp
  have h : env32096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32095_32096 : H12AffineEnvironment.transform 14 1 env32095 = env32096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32095 == env32096) = true)

theorem identity32096 : scanCanonicalize (H12AffineFastState.compose env32096 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32096 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,65536,13388,2420,1025,0,4160,8573,73755,65877,8192,64,67926,5393,69974,76158,75102,8573,257,65911,70663,513]

theorem envBound32097 : H12AffineFastState.Bounded env32097 := by
  intro p hp
  have h : env32097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32096_32097 : H12AffineEnvironment.transform 13 13405 env32096 = env32097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32096 == env32097) = true)

theorem identity32097 : scanCanonicalize (H12AffineFastState.compose env32097 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32097 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,13388,2420,1025,0,4160,8573,17,8543,8192,64,10588,5393,12636,2420,1364,8573,257,8573,13325,513]

theorem envBound32098 : H12AffineFastState.Bounded env32098 := by
  intro p hp
  have h : env32098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32097_32098 : H12AffineEnvironment.transform 15 8202 env32097 = env32098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32097 == env32098) = true)

theorem identity32098 : scanCanonicalize (H12AffineFastState.compose env32098 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32098 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1025,0,4160,33,17,3,348,64,2048,5393,4096,2420,1364,33,257,33,5457,513]

theorem envBound32099 : H12AffineFastState.Bounded env32099 := by
  intro p hp
  have h : env32099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32098_32099 : H12AffineEnvironment.transform 12 348 env32098 = env32099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32098 == env32099) = true)

theorem identity32099 : scanCanonicalize (H12AffineFastState.compose env32099 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound32099 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1134,4096,348,5377,1,342,5392,1306,1025,0,4160,33,17,3,348,64,1134,5393,4096,1306,1364,33,257,33,5457,513]

theorem envBound32100 : H12AffineFastState.Bounded env32100 := by
  intro p hp
  have h : env32100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32099_32100 : H12AffineEnvironment.transform 10 1134 env32099 = env32100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env32099 == env32100) = true)

theorem identity32100 : scanCanonicalize (H12AffineFastState.compose env32100 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound32100 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1134,1125,348,356,1,342,373,1306,1025,0,1061,33,17,3,348,64,1134,372,1125,1306,1364,33,257,33,308,513]

theorem envBound32101 : H12AffineFastState.Bounded env32101 := by
  intro p hp
  have h : env32101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32100_32101 : H12AffineEnvironment.transform 11 1125 env32100 = env32101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env32100 == env32101) = true)

theorem identity32101 : scanCanonicalize (H12AffineFastState.compose env32101 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound32101 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32102 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1134,1125,8,48,1,2,33,1102,1025,0,1061,33,17,3,8,64,1134,32,1125,1102,1024,33,85,33,96,513]

theorem envBound32102 : H12AffineFastState.Bounded env32102 := by
  intro p hp
  have h : env32102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32101_32102 : H12AffineEnvironment.transform 7 84 env32101 = env32102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env32101 == env32102) = true)

def env32103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4160,318549,119878,98645,8193,64,97546,5393,102742,335882,119042,272393,257,98679,90202,63068]

theorem envBound32103 : H12AffineFastState.Bounded env32103 := by
  intro p hp
  have h : env32103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32093_32103 : H12AffineEnvironment.transform 6 9 env32093 = env32103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32093 == env32103) = true)

theorem identity32103 : scanCanonicalize (H12AffineFastState.compose env32103 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 130394) := by decide +kernel

theorem selectedBound32103 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env32104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130394,1025,32769,4160,73999,119878,98645,8193,64,97546,5393,102742,56656,119042,120147,257,98679,90202,63068]

theorem envBound32104 : H12AffineFastState.Bounded env32104 := by
  intro p hp
  have h : env32104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32103_32104 : H12AffineEnvironment.transform 17 130394 env32103 = env32104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130394 env32103 == env32104) = true)

theorem identity32104 : scanCanonicalize (H12AffineFastState.compose env32104 (packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,18,19,20,24,26,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound32104 : packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,18,19,20,24,26,28,32,35] rootPS < 2^1333 := by decide +kernel

def env32105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21874,13389,43048,1025,32769,4160,29821,33076,54311,8193,64,10360,5393,50212,56656,33904,32801,257,54277,13608,63068]

theorem envBound32105 : H12AffineFastState.Bounded env32105 := by
  intro p hp
  have h : env32105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32104_32105 : H12AffineEnvironment.transform 15 21874 env32104 = env32105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env32104 == env32105) = true)

theorem identity32105 : scanCanonicalize (H12AffineFastState.compose env32105 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32105 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21874,5393,35188,1025,32769,4160,21793,33076,54311,349,64,2340,5393,50212,56656,33904,32801,257,54277,5236,55040]

theorem envBound32106 : H12AffineFastState.Bounded env32106 := by
  intro p hp
  have h : env32106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32105_32106 : H12AffineEnvironment.transform 12 348 env32105 = env32106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32105 == env32106) = true)

theorem identity32106 : scanCanonicalize (H12AffineFastState.compose env32106 (packedSelected [1,8,12,15,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound32106 : packedSelected [1,8,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env32107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,292,21874,5393,2128,1025,293,4160,21793,16,21763,349,64,2340,5393,17664,23668,1364,261,257,21793,5236,22052]

theorem envBound32107 : H12AffineFastState.Bounded env32107 := by
  intro p hp
  have h : env32107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32106_32107 : H12AffineEnvironment.transform 14 292 env32106 = env32107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env32106 == env32107) = true)

theorem identity32107 : scanCanonicalize (H12AffineFastState.compose env32107 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32107 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,292,114,5393,2128,1025,293,4160,33,16,3,349,64,2340,5393,4096,2420,1364,261,257,33,5236,804]

theorem envBound32108 : H12AffineFastState.Bounded env32108 := by
  intro p hp
  have h : env32108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32107_32108 : H12AffineEnvironment.transform 13 5376 env32107 = env32108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32107 == env32108) = true)

theorem identity32108 : scanCanonicalize (H12AffineFastState.compose env32108 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32108 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32109 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,81,114,5220,2128,1025,80,4160,33,16,3,40,64,2129,5220,4096,2049,1057,112,116,33,5236,593]

theorem envBound32109 : H12AffineFastState.Bounded env32109 := by
  intro p hp
  have h : env32109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32108_32109 : H12AffineEnvironment.transform 7 117 env32108 = env32109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32108 == env32109) = true)

theorem identity32109 : scanCanonicalize (H12AffineFastState.compose env32109 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32109 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32110 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4113,33,16,3,40,17,2048,5173,4096,2049,1057,33,37,33,5157,512]

theorem envBound32110 : H12AffineFastState.Bounded env32110 := by
  intro p hp
  have h : env32110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32109_32110 : H12AffineEnvironment.transform 5 17 env32109 = env32110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32109 == env32110) = true)

theorem identity32110 : scanCanonicalize (H12AffineFastState.compose env32110 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32110 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32111 : List Nat := [2,4,8,16,32,17,9,36,512,4,2048,4096,41,4128,0,35,4145,2049,5,1,4113,33,16,3,40,17,2048,4145,4096,2049,37,33,37,33,4129,512]

theorem envBound32111 : H12AffineFastState.Bounded env32111 := by
  intro p hp
  have h : env32111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32110_32111 : H12AffineEnvironment.transform 9 4 env32110 = env32111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32110 == env32111) = true)

theorem identity32111 : scanCanonicalize (H12AffineFastState.compose env32111 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound32111 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32112 : List Nat := [2,4,8,16,32,17,9,36,32,4,2048,4096,41,4128,0,35,4145,2049,5,1,4113,33,16,3,40,17,2048,4145,4096,2049,37,33,37,33,4129,32]

theorem envBound32112 : H12AffineFastState.Bounded env32112 := by
  intro p hp
  have h : env32112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32111_32112 : H12AffineEnvironment.transform 8 32 env32111 = env32112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env32111 == env32112) = true)

theorem identity32112 : scanCanonicalize (H12AffineFastState.compose env32112 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32112 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32113 : List Nat := [2,4,8,16,32,17,9,36,32,4,2048,2048,41,2080,0,35,2097,2049,5,1,2065,33,16,3,40,17,2048,2097,2048,2049,37,33,37,33,2081,32]

theorem envBound32113 : H12AffineFastState.Bounded env32113 := by
  intro p hp
  have h : env32113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32112_32113 : H12AffineEnvironment.transform 11 2048 env32112 = env32113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env32112 == env32113) = true)

theorem identity32113 : scanCanonicalize (H12AffineFastState.compose env32113 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound32113 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32114 : List Nat := [2,4,8,16,32,17,9,36,32,4,16,16,41,48,0,35,33,17,5,1,1,33,16,3,40,17,16,33,16,17,37,33,37,33,49,32]

theorem envBound32114 : H12AffineFastState.Bounded env32114 := by
  intro p hp
  have h : env32114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32113_32114 : H12AffineEnvironment.transform 10 16 env32113 = env32114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env32113 == env32114) = true)

theorem identity32114 : scanCanonicalize (H12AffineFastState.compose env32114 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32114 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32115 : List Nat := [2,4,8,16,0,17,9,4,0,4,16,16,9,16,0,3,1,17,5,1,1,1,16,3,8,17,16,1,16,17,5,1,5,1,17,0]

theorem envBound32115 : H12AffineFastState.Bounded env32115 := by
  intro p hp
  have h : env32115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32114_32115 : H12AffineEnvironment.transform 4 0 env32114 = env32115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32114 == env32115) = true)

def env32116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253963,242968,8328,64,97667,139732,238874,335882,119042,272392,257,98815,90203,63189]

theorem envBound32116 : H12AffineFastState.Bounded env32116 := by
  intro p hp
  have h : env32116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32091_32116 : H12AffineEnvironment.transform 20 4161 env32091 = env32116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32091 == env32116) = true)

theorem identity32116 : scanCanonicalize (H12AffineFastState.compose env32116 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32116 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,400453,201951,213452,8328,64,97667,139732,217550,335882,75222,272392,257,95531,90203,513]

theorem envBound32117 : H12AffineFastState.Bounded env32117 := by
  intro p hp
  have h : env32117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32116_32117 : H12AffineEnvironment.transform 14 29908 env32116 = env32117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32116 == env32117) = true)

def env32118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,400453,201815,213316,8192,64,97547,139612,217414,335882,75102,272392,257,95531,90203,513]

theorem envBound32118 : H12AffineFastState.Bounded env32118 := by
  intro p hp
  have h : env32118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32117_32118 : H12AffineEnvironment.transform 6 8 env32117 = env32118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32117 == env32118) = true)

theorem identity32118 : scanCanonicalize (H12AffineFastState.compose env32118 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound32118 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1025,29789,4161,156012,201815,213316,8192,64,97547,139612,217414,89379,75102,21793,257,95531,90203,513]

theorem envBound32119 : H12AffineFastState.Bounded env32119 := by
  intro p hp
  have h : env32119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32118_32119 : H12AffineEnvironment.transform 17 32041 env32118 = env32119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env32118 == env32119) = true)

theorem identity32119 : scanCanonicalize (H12AffineFastState.compose env32119 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound32119 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,131072,32041,1025,29789,4161,156012,136449,147474,8192,64,31837,139612,151568,23669,9224,21793,257,29821,24845,513]

theorem envBound32120 : H12AffineFastState.Bounded env32120 := by
  intro p hp
  have h : env32120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32119_32120 : H12AffineEnvironment.transform 15 342 env32119 = env32120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env32119 == env32120) = true)

theorem identity32120 : scanCanonicalize (H12AffineFastState.compose env32120 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound32120 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env32121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,342,131072,2421,1025,1,4161,136496,136449,144462,8192,64,2049,139612,140364,10281,9224,8573,257,33,5457,513]

theorem envBound32121 : H12AffineFastState.Bounded env32121 := by
  intro p hp
  have h : env32121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32120_32121 : H12AffineEnvironment.transform 13 13404 env32120 = env32121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env32120 == env32121) = true)

theorem identity32121 : scanCanonicalize (H12AffineFastState.compose env32121 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32121 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,131072,2421,1025,1,4161,136496,136449,136467,349,64,2049,131073,132369,2420,1365,32,257,33,5457,513]

theorem envBound32122 : H12AffineFastState.Bounded env32122 := by
  intro p hp
  have h : env32122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32121_32122 : H12AffineEnvironment.transform 12 349 env32121 = env32122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32121 == env32122) = true)

theorem identity32122 : scanCanonicalize (H12AffineFastState.compose env32122 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound32122 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1025,1,4161,32,17,3,349,64,2049,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound32123 : H12AffineFastState.Bounded env32123 := by
  intro p hp
  have h : env32123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32122_32123 : H12AffineEnvironment.transform 16 5392 env32122 = env32123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env32122 == env32123) = true)

theorem identity32123 : scanCanonicalize (H12AffineFastState.compose env32123 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 832) := by decide +kernel

theorem selectedBound32123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32124 : List Nat := [2,4,8,16,32,64,8,256,512,832,2048,4096,349,4673,0,342,4688,2421,833,1,4161,32,17,3,349,64,2049,4689,4097,2420,533,32,257,33,4625,513]

theorem envBound32124 : H12AffineFastState.Bounded env32124 := by
  intro p hp
  have h : env32124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32123_32124 : H12AffineEnvironment.transform 9 832 env32123 = env32124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env32123 == env32124) = true)

theorem identity32124 : scanCanonicalize (H12AffineFastState.compose env32124 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32124 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32125 : List Nat := [2,4,8,16,32,16,8,256,512,784,2048,4096,269,4625,0,262,4608,2341,785,1,4113,32,17,3,269,16,2049,4609,4097,2340,533,32,257,33,4625,513]

theorem envBound32125 : H12AffineFastState.Bounded env32125 := by
  intro p hp
  have h : env32125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32124_32125 : H12AffineEnvironment.transform 5 16 env32124 = env32125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32124 == env32125) = true)

theorem identity32125 : scanCanonicalize (H12AffineFastState.compose env32125 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound32125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32126 : List Nat := [2,4,8,16,32,16,8,256,512,784,2048,260,269,789,0,262,772,2341,785,1,277,32,17,3,269,16,2049,773,261,2340,533,32,257,33,789,513]

theorem envBound32126 : H12AffineFastState.Bounded env32126 := by
  intro p hp
  have h : env32126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32125_32126 : H12AffineEnvironment.transform 11 260 env32125 = env32126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env32125 == env32126) = true)

theorem identity32126 : scanCanonicalize (H12AffineFastState.compose env32126 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound32126 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32127 : List Nat := [2,4,8,16,32,16,8,256,512,784,292,260,269,789,0,262,772,1,785,1,277,32,17,3,269,16,293,773,261,0,533,32,257,33,789,513]

theorem envBound32127 : H12AffineFastState.Bounded env32127 := by
  intro p hp
  have h : env32127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32126_32127 : H12AffineEnvironment.transform 10 292 env32126 = env32127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env32126 == env32127) = true)

theorem identity32127 : scanCanonicalize (H12AffineFastState.compose env32127 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32127 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32128 : List Nat := [2,4,8,1,32,1,8,256,512,769,292,260,269,772,0,262,772,1,768,1,260,32,0,3,269,1,293,773,261,0,516,32,257,33,772,513]

theorem envBound32128 : H12AffineFastState.Bounded env32128 := by
  intro p hp
  have h : env32128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32127_32128 : H12AffineEnvironment.transform 3 1 env32127 = env32128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32127 == env32128) = true)

theorem identity32128 : scanCanonicalize (H12AffineFastState.compose env32128 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound32128 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32129 : List Nat := [2,4,8,1,32,1,8,256,260,5,292,260,269,0,0,262,0,1,4,1,260,32,0,3,269,1,293,1,261,0,256,32,257,33,0,261]

theorem envBound32129 : H12AffineFastState.Bounded env32129 := by
  intro p hp
  have h : env32129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32128_32129 : H12AffineEnvironment.transform 8 260 env32128 = env32129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env32128 == env32129) = true)

def env32130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,400453,201814,213317,8193,64,97546,139613,217415,335882,75103,272392,257,95531,90203,513]

theorem envBound32130 : H12AffineFastState.Bounded env32130 := by
  intro p hp
  have h : env32130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32117_32130 : H12AffineEnvironment.transform 6 9 env32117 = env32130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32117 == env32130) = true)

theorem identity32130 : scanCanonicalize (H12AffineFastState.compose env32130 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound32130 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1025,29788,4161,359519,29772,8543,8193,64,97546,82247,12637,335882,75103,272392,257,95531,90203,513]

theorem envBound32131 : H12AffineFastState.Bounded env32131 := by
  intro p hp
  have h : env32131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32130_32131 : H12AffineEnvironment.transform 16 90138 env32130 = env32131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env32130 == env32131) = true)

theorem identity32131 : scanCanonicalize (H12AffineFastState.compose env32131 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound32131 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,22884,1025,29788,4161,75067,29772,8543,8193,64,97546,82247,12637,96622,75103,29036,257,95531,90203,513]

theorem envBound32132 : H12AffineFastState.Bounded env32132 := by
  intro p hp
  have h : env32132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32131_32132 : H12AffineEnvironment.transform 17 22884 env32131 = env32132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env32131 == env32132) = true)

theorem identity32132 : scanCanonicalize (H12AffineFastState.compose env32132 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound32132 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,20759,12557,22884,1025,29788,4161,29740,29772,8543,8193,64,11293,4176,12637,10361,29768,29036,257,9276,12620,513]

theorem envBound32133 : H12AffineFastState.Bounded env32133 := by
  intro p hp
  have h : env32133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32132_32133 : H12AffineEnvironment.transform 15 20759 env32132 = env32133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env32132 == env32133) = true)

theorem identity32133 : scanCanonicalize (H12AffineFastState.compose env32133 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32133 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env32134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,20759,4096,22884,1025,21841,4161,21793,21825,82,268,64,3344,4176,4176,2420,21829,20577,257,1329,4161,513]

theorem envBound32134 : H12AffineFastState.Bounded env32134 := by
  intro p hp
  have h : env32134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32133_32134 : H12AffineEnvironment.transform 12 269 env32133 = env32134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32133 == env32134) = true)

theorem identity32134 : scanCanonicalize (H12AffineFastState.compose env32134 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound32134 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,4452,1076,115,4096,2048,1025,1077,4161,1093,1061,82,268,64,3344,4176,4176,2420,1057,261,257,1329,4161,513]

theorem envBound32135 : H12AffineFastState.Bounded env32135 := by
  intro p hp
  have h : env32135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32134_32135 : H12AffineEnvironment.transform 13 4452 env32134 = env32135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env32134 == env32135) = true)

theorem identity32135 : scanCanonicalize (H12AffineFastState.compose env32135 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32135 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env32136 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,4452,80,115,4096,2048,101,81,4161,33,65,82,268,64,2420,4176,4176,2420,69,261,257,341,4161,513]

theorem envBound32136 : H12AffineFastState.Bounded env32136 := by
  intro p hp
  have h : env32136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32135_32136 : H12AffineEnvironment.transform 9 100 env32135 = env32136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32135 == env32136) = true)

theorem identity32136 : scanCanonicalize (H12AffineFastState.compose env32136 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32136 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32137 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,41,4160,80,115,4096,2048,101,81,4161,33,65,82,40,64,2128,4176,4176,2128,69,33,37,113,4161,513]

theorem envBound32137 : H12AffineFastState.Bounded env32137 := by
  intro p hp
  have h : env32137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32136_32137 : H12AffineEnvironment.transform 7 36 env32136 = env32137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32136 == env32137) = true)

theorem identity32137 : scanCanonicalize (H12AffineFastState.compose env32137 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32137 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32138 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4113,1,34,4096,2048,52,0,4112,33,16,3,40,17,2049,4097,4097,2049,20,33,37,32,4112,513]

theorem envBound32138 : H12AffineFastState.Bounded env32138 := by
  intro p hp
  have h : env32138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32137_32138 : H12AffineEnvironment.transform 5 17 env32137 = env32138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32137 == env32138) = true)

theorem identity32138 : scanCanonicalize (H12AffineFastState.compose env32138 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound32138 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32139 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,1,41,16,1,34,1,2048,52,0,17,33,16,3,40,17,2049,0,0,2049,20,33,37,32,17,513]

theorem envBound32139 : H12AffineFastState.Bounded env32139 := by
  intro p hp
  have h : env32139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32138_32139 : H12AffineEnvironment.transform 11 1 env32138 = env32139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32138 == env32139) = true)

theorem identity32139 : scanCanonicalize (H12AffineFastState.compose env32139 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound32139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32140 : List Nat := [2,4,8,16,32,17,9,36,512,53,554,1,41,16,1,34,1,554,52,0,17,33,16,3,40,17,555,0,0,555,20,33,37,32,17,513]

theorem envBound32140 : H12AffineFastState.Bounded env32140 := by
  intro p hp
  have h : env32140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32139_32140 : H12AffineEnvironment.transform 10 554 env32139 = env32140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env32139 == env32140) = true)

def env32141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253963,242969,8328,64,97666,2240916,2340187,335882,119043,2373704,257,2199999,2191387,63188]

theorem envBound32141 : H12AffineFastState.Bounded env32141 := by
  intro p hp
  have h : env32141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32090_32141 : H12AffineEnvironment.transform 23 242969 env32090 = env32141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env32090 == env32141) = true)

def env32142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253963,242969,8328,64,97666,139732,238875,335882,119043,272392,257,98815,90203,63188]

theorem envBound32142 : H12AffineFastState.Bounded env32142 := by
  intro p hp
  have h : env32142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32141_32142 : H12AffineEnvironment.transform 20 4160 env32141 = env32142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32141 == env32142) = true)

def env32143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,180273,253963,242969,8328,64,97666,139732,238875,67754,119043,168,257,98815,90203,63188]

theorem envBound32143 : H12AffineFastState.Bounded env32143 := by
  intro p hp
  have h : env32143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32142_32143 : H12AffineEnvironment.transform 17 10400 env32142 = env32143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32142 == env32143) = true)

def env32144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180273,253963,242969,8192,64,97546,139612,238875,67618,119043,32,257,98679,90203,63068]

theorem envBound32144 : H12AffineFastState.Bounded env32144 := by
  intro p hp
  have h : env32144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32143_32144 : H12AffineEnvironment.transform 6 8 env32143 = env32144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32143 == env32144) = true)

theorem identity32144 : scanCanonicalize (H12AffineFastState.compose env32144 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound32144 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,4160,144492,201814,213316,8192,64,97546,139612,217414,67618,75102,32,257,95530,90203,513]

theorem envBound32145 : H12AffineFastState.Bounded env32145 := by
  intro p hp
  have h : env32145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32144_32145 : H12AffineEnvironment.transform 14 29789 env32144 = env32145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env32144 == env32145) = true)

theorem identity32145 : scanCanonicalize (H12AffineFastState.compose env32145 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound32145 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env32146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,82247,10280,1025,29788,4160,95531,21777,3,8192,64,97546,90139,4097,67618,75102,32,257,95530,90203,513]

theorem envBound32146 : H12AffineFastState.Bounded env32146 := by
  intro p hp
  have h : env32146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32145_32146 : H12AffineEnvironment.transform 16 82247 env32145 = env32146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env32145 == env32146) = true)

theorem identity32146 : scanCanonicalize (H12AffineFastState.compose env32146 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound32146 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,262,16449,10280,1025,29788,4160,29741,21777,3,8192,64,31756,24861,4097,2340,9304,32,257,29740,24925,513]

theorem envBound32147 : H12AffineFastState.Bounded env32147 := by
  intro p hp
  have h : env32147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32146_32147 : H12AffineEnvironment.transform 15 262 env32146 = env32147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env32146 == env32147) = true)

theorem identity32147 : scanCanonicalize (H12AffineFastState.compose env32147 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32147 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,262,5441,10280,1025,8540,4160,8493,17,3,8192,64,10508,13341,4097,2340,9304,32,257,8492,13405,513]

theorem envBound32148 : H12AffineFastState.Bounded env32148 := by
  intro p hp
  have h : env32148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32147_32148 : H12AffineEnvironment.transform 13 5376 env32147 = env32148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32147 == env32148) = true)

theorem identity32148 : scanCanonicalize (H12AffineFastState.compose env32148 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32148 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,262,5441,2421,1025,1,4160,112,17,3,349,64,2129,5440,4097,2340,1285,32,257,113,5376,513]

theorem envBound32149 : H12AffineFastState.Bounded env32149 := by
  intro p hp
  have h : env32149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32148_32149 : H12AffineEnvironment.transform 12 349 env32148 = env32149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32148 == env32149) = true)

theorem identity32149 : scanCanonicalize (H12AffineFastState.compose env32149 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound32149 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env32150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1589,4096,349,5376,0,262,5441,1856,1025,1,4160,112,17,3,349,64,1636,5440,4097,1809,1285,32,257,113,5376,513]

theorem envBound32150 : H12AffineFastState.Bounded env32150 := by
  intro p hp
  have h : env32150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32149_32150 : H12AffineEnvironment.transform 10 1589 env32149 = env32150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env32149 == env32150) = true)

theorem identity32150 : scanCanonicalize (H12AffineFastState.compose env32150 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound32150 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env32151 : List Nat := [2,4,8,16,32,64,8,256,277,1024,1312,4096,349,5376,0,262,5441,1109,1025,1,4160,112,17,3,349,64,1393,5440,4097,1028,1285,32,257,113,5376,276]

theorem envBound32151 : H12AffineFastState.Bounded env32151 := by
  intro p hp
  have h : env32151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32150_32151 : H12AffineEnvironment.transform 8 277 env32150 = env32151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env32150 == env32151) = true)

theorem identity32151 : scanCanonicalize (H12AffineFastState.compose env32151 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound32151 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env32152 : List Nat := [2,4,8,16,32,64,8,256,277,116,340,4096,349,4468,0,262,4405,33,117,1,4160,112,17,3,349,64,261,4404,4097,112,369,32,257,113,4468,276]

theorem envBound32152 : H12AffineFastState.Bounded env32152 := by
  intro p hp
  have h : env32152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32151_32152 : H12AffineEnvironment.transform 9 116 env32151 = env32152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env32151 == env32152) = true)

theorem identity32152 : scanCanonicalize (H12AffineFastState.compose env32152 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound32152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32153 : List Nat := [2,4,8,16,32,64,8,256,277,116,340,260,349,112,0,262,49,33,117,1,324,112,17,3,349,64,261,48,261,112,369,32,257,113,112,276]

theorem envBound32153 : H12AffineFastState.Bounded env32153 := by
  intro p hp
  have h : env32153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32152_32153 : H12AffineEnvironment.transform 11 260 env32152 = env32153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env32152 == env32153) = true)

theorem identity32153 : scanCanonicalize (H12AffineFastState.compose env32153 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound32153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32154 : List Nat := [2,4,8,16,32,64,8,84,65,116,0,80,9,112,0,82,49,33,117,1,16,112,17,3,9,64,81,48,81,112,37,32,85,113,112,64]

theorem envBound32154 : H12AffineFastState.Bounded env32154 := by
  intro p hp
  have h : env32154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32153_32154 : H12AffineEnvironment.transform 7 84 env32153 = env32154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env32153 == env32154) = true)

theorem identity32154 : scanCanonicalize (H12AffineFastState.compose env32154 (packedSelected [3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound32154 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env32155 : List Nat := [2,4,8,16,32,1,8,21,0,53,0,17,9,49,0,19,49,33,52,1,16,49,17,3,9,1,16,48,16,49,37,32,20,48,49,1]

theorem envBound32155 : H12AffineFastState.Bounded env32155 := by
  intro p hp
  have h : env32155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32154_32155 : H12AffineEnvironment.transform 5 1 env32154 = env32155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env32154 == env32155) = true)

theorem identity32155 : scanCanonicalize (H12AffineFastState.compose env32155 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32155 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32156 : List Nat := [2,4,8,16,0,1,8,21,0,21,0,17,9,17,0,19,17,1,20,1,16,17,17,3,9,1,16,16,16,17,5,0,20,16,17,1]

theorem envBound32156 : H12AffineFastState.Bounded env32156 := by
  intro p hp
  have h : env32156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32155_32156 : H12AffineEnvironment.transform 4 0 env32155 = env32156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32155 == env32156) = true)

theorem identity32156 : scanCanonicalize (H12AffineFastState.compose env32156 (packedSelected [18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32156 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env32157 : List Nat := [2,4,8,1,0,1,8,4,0,4,0,0,9,0,0,2,0,1,5,1,1,0,0,3,9,1,1,1,1,0,5,0,5,1,0,1]

theorem envBound32157 : H12AffineFastState.Bounded env32157 := by
  intro p hp
  have h : env32157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32156_32157 : H12AffineEnvironment.transform 3 1 env32156 = env32157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32156 == env32157) = true)

def env32158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180273,253963,242969,8193,64,97547,139613,238875,67619,119043,33,257,98678,90203,63069]

theorem envBound32158 : H12AffineFastState.Bounded env32158 := by
  intro p hp
  have h : env32158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32143_32158 : H12AffineEnvironment.transform 6 9 env32143 = env32158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32143 == env32158) = true)

theorem identity32158 : scanCanonicalize (H12AffineFastState.compose env32158 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,4160,156012,213334,201796,8193,64,97547,139613,197702,67619,94302,33,257,73771,90203,22272]

theorem envBound32159 : H12AffineFastState.Bounded env32159 := by
  intro p hp
  have h : env32159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32158_32159 : H12AffineEnvironment.transform 14 8541 env32158 = env32159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32158 == env32159) = true)

theorem identity32159 : scanCanonicalize (H12AffineFastState.compose env32159 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound32159 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env32160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,131072,10281,1025,8540,4160,156012,136448,147474,8193,64,10589,139613,151568,23669,9224,33,257,29821,13325,22272]

theorem envBound32160 : H12AffineFastState.Bounded env32160 := by
  intro p hp
  have h : env32160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32159_32160 : H12AffineEnvironment.transform 15 21590 env32159 = env32160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env32159 == env32160) = true)

theorem identity32160 : scanCanonicalize (H12AffineFastState.compose env32160 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32160 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env32161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,8282,131072,10281,1025,8540,4160,136544,136448,144414,8193,64,10589,139613,140316,10361,9224,33,257,113,13325,8972]

theorem envBound32161 : H12AffineFastState.Bounded env32161 := by
  intro p hp
  have h : env32161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32160_32161 : H12AffineEnvironment.transform 13 13324 env32160 = env32161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32160 == env32161) = true)

theorem identity32161 : scanCanonicalize (H12AffineFastState.compose env32161 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 12409) := by decide +kernel

theorem selectedBound32161 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,8282,12409,10281,1025,8540,4160,9497,9593,1127,8193,64,10589,4388,5221,10361,9224,33,257,113,13325,8972]

theorem envBound32162 : H12AffineFastState.Bounded env32162 := by
  intro p hp
  have h : env32162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32161_32162 : H12AffineEnvironment.transform 16 12409 env32161 = env32162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12409 env32161 == env32162) = true)

theorem identity32162 : scanCanonicalize (H12AffineFastState.compose env32162 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound32162 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4160,1297,1046,5173,3173,1025,1296,4160,341,309,1127,1101,64,3345,4388,5221,3125,68,33,257,113,4161,1856]

theorem envBound32163 : H12AffineFastState.Bounded env32163 := by
  intro p hp
  have h : env32163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32162_32163 : H12AffineEnvironment.transform 12 1100 env32162 = env32163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env32162 == env32163) = true)

theorem identity32163 : scanCanonicalize (H12AffineFastState.compose env32163 (packedSelected [1,2,3,5,6,8,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound32163 : packedSelected [1,2,3,5,6,8,12,16] rootPS < 2^1333 := by decide +kernel

def env32164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1100,2420,1297,1046,3329,3173,1025,1296,2420,341,309,1127,1101,64,3345,2064,3409,3125,68,33,257,113,2421,1856]

theorem envBound32164 : H12AffineFastState.Bounded env32164 := by
  intro p hp
  have h : env32164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32163_32164 : H12AffineEnvironment.transform 11 2356 env32163 = env32164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env32163 == env32164) = true)

theorem identity32164 : scanCanonicalize (H12AffineFastState.compose env32164 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32164 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32165 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,121,2420,292,35,2356,2128,52,293,2420,341,309,82,120,64,2340,2064,2404,2048,68,33,257,113,2421,885]

theorem envBound32165 : H12AffineFastState.Bounded env32165 := by
  intro p hp
  have h : env32165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32164_32165 : H12AffineEnvironment.transform 9 53 env32164 = env32165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32164 == env32165) = true)

theorem identity32165 : scanCanonicalize (H12AffineFastState.compose env32165 (packedSelected [0,1,3,5,7,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32165 : packedSelected [0,1,3,5,7,8,15] rootPS < 2^1333 := by decide +kernel

def env32166 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,121,2129,1,35,2065,2128,52,0,2129,112,16,82,120,64,2049,2064,2113,2048,68,33,36,113,2128,592]

theorem envBound32166 : H12AffineFastState.Bounded env32166 := by
  intro p hp
  have h : env32166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32165_32166 : H12AffineEnvironment.transform 7 37 env32165 = env32166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32165 == env32166) = true)

def env32167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,180272,253963,242969,8328,64,97666,139732,238875,67755,119043,169,257,98815,90203,63188]

theorem envBound32167 : H12AffineFastState.Bounded env32167 := by
  intro p hp
  have h : env32167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32142_32167 : H12AffineEnvironment.transform 17 10401 env32142 = env32167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32142 == env32167) = true)

def env32168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180272,253963,242969,8192,64,97546,139612,238875,67619,119043,33,257,98679,90203,63068]

theorem envBound32168 : H12AffineFastState.Bounded env32168 := by
  intro p hp
  have h : env32168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32167_32168 : H12AffineEnvironment.transform 6 8 env32167 = env32168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32167 == env32168) = true)

theorem identity32168 : scanCanonicalize (H12AffineFastState.compose env32168 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound32168 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4160,73771,16,21762,8192,64,97546,115015,17664,67619,119043,33,257,98679,90203,63068]

theorem envBound32169 : H12AffineFastState.Bounded env32169 := by
  intro p hp
  have h : env32169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32168_32169 : H12AffineEnvironment.transform 16 122907 env32168 = env32169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env32168 == env32169) = true)

theorem identity32169 : scanCanonicalize (H12AffineFastState.compose env32169 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound32169 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,103495,10281,1025,32769,4160,73771,16,8542,8192,64,67926,111899,12636,67619,107871,33,257,98679,70663,33280]

theorem envBound32170 : H12AffineFastState.Bounded env32170 := by
  intro p hp
  have h : env32170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32169_32170 : H12AffineEnvironment.transform 13 13404 env32169 = env32170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env32169 == env32170) = true)

theorem identity32170 : scanCanonicalize (H12AffineFastState.compose env32170 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 34099) := by decide +kernel

theorem selectedBound32170 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env32171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,34099,4468,10281,1025,32769,4160,42264,16,8542,8192,64,35941,12328,12636,36112,8300,33,257,1092,37172,33280]

theorem envBound32171 : H12AffineFastState.Bounded env32171 := by
  intro p hp
  have h : env32171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32170_32171 : H12AffineEnvironment.transform 15 34099 env32170 = env32171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34099 env32170 == env32171) = true)

theorem identity32171 : scanCanonicalize (H12AffineFastState.compose env32171 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32171 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env32172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,32768,34099,4468,2341,1025,32769,4160,33812,16,82,268,64,35941,4388,4176,36112,352,33,257,1092,37172,33280]

theorem envBound32172 : H12AffineFastState.Bounded env32172 := by
  intro p hp
  have h : env32172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32171_32172 : H12AffineEnvironment.transform 12 268 env32171 = env32172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32171 == env32172) = true)

theorem identity32172 : scanCanonicalize (H12AffineFastState.compose env32172 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32172 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env32173 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4405,32768,33110,4468,2341,100,32769,4160,32881,16,82,268,64,34816,4388,4176,35189,352,33,257,33,37172,33280]

theorem envBound32173 : H12AffineFastState.Bounded env32173 := by
  intro p hp
  have h : env32173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32172_32173 : H12AffineEnvironment.transform 9 101 env32172 = env32173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32172 == env32173) = true)

theorem identity32173 : scanCanonicalize (H12AffineFastState.compose env32173 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32173 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32174 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4405,0,342,4468,2341,100,1,4160,113,16,82,268,64,2048,4388,4176,2421,352,33,257,33,4404,512]

theorem envBound32174 : H12AffineFastState.Bounded env32174 := by
  intro p hp
  have h : env32174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32173_32174 : H12AffineEnvironment.transform 14 0 env32173 = env32174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32173 == env32174) = true)

theorem identity32174 : scanCanonicalize (H12AffineFastState.compose env32174 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound32174 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32175 : List Nat := [2,4,8,16,32,64,8,256,512,101,33,4096,268,4405,0,342,4468,260,100,1,4160,113,16,82,268,64,33,4388,4176,340,352,33,257,33,4404,512]

theorem envBound32175 : H12AffineFastState.Bounded env32175 := by
  intro p hp
  have h : env32175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32174_32175 : H12AffineEnvironment.transform 10 33 env32174 = env32175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env32174 == env32175) = true)

theorem identity32175 : scanCanonicalize (H12AffineFastState.compose env32175 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32175 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32176 : List Nat := [2,4,8,16,32,48,8,256,512,21,33,4096,268,4405,0,294,4356,260,20,1,4144,1,16,34,268,48,33,4388,4128,292,272,33,257,33,4404,512]

theorem envBound32176 : H12AffineFastState.Bounded env32176 := by
  intro p hp
  have h : env32176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32175_32176 : H12AffineEnvironment.transform 5 48 env32175 = env32176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32175 == env32176) = true)

theorem identity32176 : scanCanonicalize (H12AffineFastState.compose env32176 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32176 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env32177 : List Nat := [2,4,8,16,32,48,8,5,512,21,33,4096,9,4144,0,35,4097,1,20,1,4144,1,16,34,9,48,33,4129,4128,33,21,33,4,33,4145,512]

theorem envBound32177 : H12AffineFastState.Bounded env32177 := by
  intro p hp
  have h : env32177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32176_32177 : H12AffineEnvironment.transform 7 5 env32176 = env32177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32176 == env32177) = true)

theorem identity32177 : scanCanonicalize (H12AffineFastState.compose env32177 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound32177 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env32178 : List Nat := [2,4,8,16,32,48,8,5,512,21,33,512,9,560,0,35,513,1,20,1,560,1,16,34,9,48,33,545,544,33,21,33,4,33,561,512]

theorem envBound32178 : H12AffineFastState.Bounded env32178 := by
  intro p hp
  have h : env32178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32177_32178 : H12AffineEnvironment.transform 11 512 env32177 = env32178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env32177 == env32178) = true)

theorem identity32178 : scanCanonicalize (H12AffineFastState.compose env32178 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32178 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env32179 : List Nat := [2,4,8,16,32,48,8,5,48,21,33,48,9,0,0,35,49,1,20,1,0,1,16,34,9,48,33,17,16,33,21,33,4,33,1,48]

theorem envBound32179 : H12AffineFastState.Bounded env32179 := by
  intro p hp
  have h : env32179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32178_32179 : H12AffineEnvironment.transform 8 48 env32178 = env32179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32178 == env32179) = true)

theorem identity32179 : scanCanonicalize (H12AffineFastState.compose env32179 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound32179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32180 : List Nat := [2,4,8,16,4,20,8,5,20,21,5,20,9,0,0,7,21,1,20,1,0,1,16,6,9,20,5,17,16,5,21,5,4,5,1,20]

theorem envBound32180 : H12AffineFastState.Bounded env32180 := by
  intro p hp
  have h : env32180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32179_32180 : H12AffineEnvironment.transform 4 4 env32179 = env32180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env32179 == env32180) = true)

theorem identity32180 : scanCanonicalize (H12AffineFastState.compose env32180 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32180 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32181 : List Nat := [2,0,8,16,0,16,8,1,16,17,1,16,9,0,0,3,17,1,16,1,0,1,16,2,9,16,1,17,16,1,17,1,0,1,1,16]

theorem envBound32181 : H12AffineFastState.Bounded env32181 := by
  intro p hp
  have h : env32181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32180_32181 : H12AffineEnvironment.transform 1 0 env32180 = env32181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32180 == env32181) = true)

theorem identity32181 : scanCanonicalize (H12AffineFastState.compose env32181 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32182 : List Nat := [2,0,8,1,0,1,8,1,1,0,1,1,9,0,0,3,0,1,1,1,0,1,1,2,9,1,1,0,1,1,0,1,0,1,1,1]

theorem envBound32182 : H12AffineFastState.Bounded env32182 := by
  intro p hp
  have h : env32182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32181_32182 : H12AffineEnvironment.transform 3 1 env32181 = env32182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32181 == env32182) = true)

def env32183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180272,253963,242969,8193,64,97547,139613,238875,67618,119043,32,257,98678,90203,63069]

theorem envBound32183 : H12AffineFastState.Bounded env32183 := by
  intro p hp
  have h : env32183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32167_32183 : H12AffineEnvironment.transform 6 9 env32167 = env32183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32167 == env32183) = true)

theorem identity32183 : scanCanonicalize (H12AffineFastState.compose env32183 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound32183 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,4160,98678,41293,62559,8193,64,97547,90139,58461,67618,119043,32,257,98678,90203,63069]

theorem envBound32184 : H12AffineFastState.Bounded env32184 := by
  intro p hp
  have h : env32184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32183_32184 : H12AffineEnvironment.transform 16 82246 env32183 = env32184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env32183 == env32184) = true)

theorem identity32184 : scanCanonicalize (H12AffineFastState.compose env32184 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32184 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,2420,1025,32769,4160,98678,32785,54531,349,64,89175,82247,50433,67618,119043,32,257,98678,82183,55041]

theorem envBound32185 : H12AffineFastState.Bounded env32185 := by
  intro p hp
  have h : env32185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32184_32185 : H12AffineEnvironment.transform 12 348 env32184 = env32185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32184 == env32185) = true)

theorem identity32185 : scanCanonicalize (H12AffineFastState.compose env32185 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound32185 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env32186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54278,38208,2420,1025,32769,4160,21872,32785,54531,349,64,34897,38209,50433,56356,1285,32,257,21872,38145,55041]

theorem envBound32186 : H12AffineFastState.Bounded env32186 := by
  intro p hp
  have h : env32186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32185_32186 : H12AffineEnvironment.transform 15 54278 env32185 = env32186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env32185 == env32186) = true)

theorem identity32186 : scanCanonicalize (H12AffineFastState.compose env32186 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound32186 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,263,16449,2420,1025,21760,4160,21872,21776,2,349,64,23888,16448,4096,2341,1285,32,257,21872,16384,512]

theorem envBound32187 : H12AffineFastState.Bounded env32187 := by
  intro p hp
  have h : env32187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32186_32187 : H12AffineEnvironment.transform 14 21761 env32186 = env32187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env32186 == env32187) = true)

theorem identity32187 : scanCanonicalize (H12AffineFastState.compose env32187 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5488) := by decide +kernel

theorem selectedBound32187 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,113,263,5425,2420,1025,112,4160,0,96,2,349,64,2080,5424,4096,2341,1285,32,257,0,5488,512]

theorem envBound32188 : H12AffineFastState.Bounded env32188 := by
  intro p hp
  have h : env32188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32187_32188 : H12AffineEnvironment.transform 13 5488 env32187 = env32188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5488 env32187 == env32188) = true)

theorem identity32188 : scanCanonicalize (H12AffineFastState.compose env32188 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32188 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env32189 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5409,32,263,5425,2341,1025,33,4113,0,49,2,268,17,2080,5424,4096,2341,1285,32,257,0,5409,512]

theorem envBound32189 : H12AffineFastState.Bounded env32189 := by
  intro p hp
  have h : env32189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32188_32189 : H12AffineEnvironment.transform 5 17 env32188 = env32189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32188 == env32189) = true)

theorem identity32189 : scanCanonicalize (H12AffineFastState.compose env32189 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound32189 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env32190 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2586,269,3899,32,263,3883,2341,1025,33,2571,0,49,2,268,17,2080,3882,2586,2341,1285,32,257,0,3899,512]

theorem envBound32190 : H12AffineFastState.Bounded env32190 := by
  intro p hp
  have h : env32190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32189_32190 : H12AffineEnvironment.transform 11 2586 env32189 = env32190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env32189 == env32190) = true)

theorem identity32190 : scanCanonicalize (H12AffineFastState.compose env32190 (packedSelected [0,1,3,4,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32190 : packedSelected [0,1,3,4,12] rootPS < 2^1333 := by decide +kernel

def env32191 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,2586,269,3867,0,263,3851,2309,1025,1,2571,0,17,2,268,17,2048,3850,2586,2309,1285,0,257,0,3867,512]

theorem envBound32191 : H12AffineFastState.Bounded env32191 := by
  intro p hp
  have h : env32191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32190_32191 : H12AffineEnvironment.transform 4 0 env32190 = env32191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32190 == env32191) = true)

theorem identity32191 : scanCanonicalize (H12AffineFastState.compose env32191 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32192 : List Nat := [2,4,8,16,0,17,9,21,512,1024,2048,2586,24,3598,0,18,3614,2064,1025,1,2571,0,17,2,25,17,2048,3615,2586,2064,1040,0,20,0,3598,512]

theorem envBound32192 : H12AffineFastState.Bounded env32192 := by
  intro p hp
  have h : env32192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32191_32192 : H12AffineEnvironment.transform 7 21 env32191 = env32192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32191 == env32192) = true)

theorem identity32192 : scanCanonicalize (H12AffineFastState.compose env32192 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound32192 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32193 : List Nat := [2,4,8,16,0,17,9,21,512,1024,11,529,24,1541,0,18,1557,27,1025,1,512,0,17,2,25,17,11,1556,529,27,1040,0,20,0,1541,512]

theorem envBound32193 : H12AffineFastState.Bounded env32193 := by
  intro p hp
  have h : env32193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32192_32193 : H12AffineEnvironment.transform 10 11 env32192 = env32193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env32192 == env32193) = true)

theorem identity32193 : scanCanonicalize (H12AffineFastState.compose env32193 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32193 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32194 : List Nat := [2,4,3,16,0,17,2,21,512,1024,0,529,19,1541,0,18,1557,16,1025,1,512,0,17,2,18,17,0,1556,529,16,1040,0,20,0,1541,512]

theorem envBound32194 : H12AffineFastState.Bounded env32194 := by
  intro p hp
  have h : env32194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32193_32194 : H12AffineEnvironment.transform 2 3 env32193 = env32194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32193 == env32194) = true)

theorem identity32194 : scanCanonicalize (H12AffineFastState.compose env32194 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32194 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32195 : List Nat := [2,4,3,16,0,17,2,21,512,5,0,529,19,512,0,18,528,16,4,1,512,0,17,2,18,17,0,529,529,16,21,0,20,0,512,512]

theorem envBound32195 : H12AffineFastState.Bounded env32195 := by
  intro p hp
  have h : env32195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32194_32195 : H12AffineEnvironment.transform 9 5 env32194 = env32195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32194 == env32195) = true)

theorem identity32195 : scanCanonicalize (H12AffineFastState.compose env32195 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound32195 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32196 : List Nat := [2,4,3,16,0,17,2,21,22,5,0,7,19,22,0,18,6,16,4,1,22,0,17,2,18,17,0,7,7,16,21,0,20,0,22,22]

theorem envBound32196 : H12AffineFastState.Bounded env32196 := by
  intro p hp
  have h : env32196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32195_32196 : H12AffineEnvironment.transform 8 22 env32195 = env32196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env32195 == env32196) = true)

theorem identity32196 : scanCanonicalize (H12AffineFastState.compose env32196 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound32196 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32197 : List Nat := [2,4,3,7,0,6,2,2,1,5,0,7,4,1,0,5,6,7,4,1,1,0,6,2,5,6,0,7,7,7,2,0,3,0,1,1]

theorem envBound32197 : H12AffineFastState.Bounded env32197 := by
  intro p hp
  have h : env32197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32196_32197 : H12AffineEnvironment.transform 3 7 env32196 = env32197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env32196 == env32197) = true)

theorem identity32197 : scanCanonicalize (H12AffineFastState.compose env32197 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32198 : List Nat := [2,0,3,3,0,2,2,2,1,1,0,3,0,1,0,1,2,3,0,1,1,0,2,2,1,2,0,3,3,3,2,0,3,0,1,1]

theorem envBound32198 : H12AffineFastState.Bounded env32198 := by
  intro p hp
  have h : env32198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32197_32198 : H12AffineEnvironment.transform 1 0 env32197 = env32198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32197 == env32198) = true)

theorem identity32198 : scanCanonicalize (H12AffineFastState.compose env32198 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32198 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env32199 : List Nat := [1,0,0,0,0,1,1,1,1,1,0,0,0,1,0,1,1,0,0,1,1,0,1,1,1,1,0,0,0,0,1,0,0,0,1,1]

theorem envBound32199 : H12AffineFastState.Bounded env32199 := by
  intro p hp
  have h : env32199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32198_32199 : H12AffineEnvironment.transform 0 1 env32198 = env32199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32198 == env32199) = true)

def env32200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253963,242969,8328,64,97666,139733,238874,335882,119043,272393,257,98814,90202,63188]

theorem envBound32200 : H12AffineFastState.Bounded env32200 := by
  intro p hp
  have h : env32200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32141_32200 : H12AffineEnvironment.transform 20 4161 env32141 = env32200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32141 == env32200) = true)

theorem identity32200 : scanCanonicalize (H12AffineFastState.compose env32200 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound32200 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272513,73755,95497,8328,64,97666,57797,91402,335882,119043,272393,257,98814,90202,63188]

theorem envBound32201 : H12AffineFastState.Bounded env32201 := by
  intro p hp
  have h : env32201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32200_32201 : H12AffineEnvironment.transform 16 49168 env32200 = env32201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32200 == env32201) = true)

def env32202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10400,1025,32769,4161,33,73755,95497,8328,64,97666,57797,91402,67754,119043,169,257,98814,90202,63188]

theorem envBound32202 : H12AffineFastState.Bounded env32202 := by
  intro p hp
  have h : env32202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32201_32202 : H12AffineEnvironment.transform 17 10400 env32201 = env32202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32201 == env32202) = true)

theorem identity32202 : scanCanonicalize (H12AffineFastState.compose env32202 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound32202 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env32203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10400,1025,32769,4161,33,153,21899,8328,64,23808,57797,17800,10280,61825,169,257,41340,16600,63188]

theorem envBound32203 : H12AffineFastState.Bounded env32203 := by
  intro p hp
  have h : env32203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32202_32203 : H12AffineEnvironment.transform 15 8322 env32202 = env32203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env32202 == env32203) = true)

theorem identity32203 : scanCanonicalize (H12AffineFastState.compose env32203 (packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound32203 : packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env32204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8322,13509,10400,1025,29908,4161,33,153,21899,8328,64,23808,5392,17800,10280,1364,169,257,21929,16600,513]

theorem envBound32204 : H12AffineFastState.Bounded env32204 := by
  intro p hp
  have h : env32204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32203_32204 : H12AffineEnvironment.transform 14 29909 env32203 = env32204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env32203 == env32204) = true)

theorem identity32204 : scanCanonicalize (H12AffineFastState.compose env32204 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32204 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,13509,10400,1025,8661,4161,33,153,138,8328,64,2049,5392,4233,10280,1364,169,257,168,5593,513]

theorem envBound32205 : H12AffineFastState.Bounded env32205 := by
  intro p hp
  have h : env32205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32204_32205 : H12AffineEnvironment.transform 13 5377 env32204 = env32205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32204 == env32205) = true)

theorem identity32205 : scanCanonicalize (H12AffineFastState.compose env32205 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound32205 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,343,5392,2421,1025,0,4161,33,153,138,349,64,2049,5392,4233,2557,1364,169,257,168,5593,513]

theorem envBound32206 : H12AffineFastState.Bounded env32206 := by
  intro p hp
  have h : env32206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32205_32206 : H12AffineEnvironment.transform 12 469 env32205 = env32206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env32205 == env32206) = true)

theorem identity32206 : scanCanonicalize (H12AffineFastState.compose env32206 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32206 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env32207 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,1,263,5392,2341,1025,0,4113,33,153,138,269,16,2049,5392,4233,2477,1284,169,257,168,5513,513]

theorem envBound32207 : H12AffineFastState.Bounded env32207 := by
  intro p hp
  have h : env32207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32206_32207 : H12AffineEnvironment.transform 5 16 env32206 = env32207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32206 == env32207) = true)

theorem identity32207 : scanCanonicalize (H12AffineFastState.compose env32207 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound32207 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3329,389,2048,1,263,2065,2341,1025,0,3344,33,153,138,269,16,2049,2065,3464,2477,1284,169,257,168,2184,513]

theorem envBound32208 : H12AffineFastState.Bounded env32208 := by
  intro p hp
  have h : env32208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32207_32208 : H12AffineEnvironment.transform 11 3329 env32207 = env32208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env32207 == env32208) = true)

theorem identity32208 : scanCanonicalize (H12AffineFastState.compose env32208 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32208 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32209 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,2357,389,2048,1,263,2065,2341,53,0,2340,33,153,138,269,16,2049,2065,2492,2477,304,169,257,168,2184,513]

theorem envBound32209 : H12AffineFastState.Bounded env32209 := by
  intro p hp
  have h : env32209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32208_32209 : H12AffineEnvironment.transform 9 52 env32208 = env32209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32208 == env32209) = true)

theorem identity32209 : scanCanonicalize (H12AffineFastState.compose env32209 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound32209 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env32210 : List Nat := [2,4,8,16,32,16,128,173,512,52,2048,2200,40,2048,1,170,2065,2184,53,0,2185,33,153,138,160,16,2049,2065,2065,2048,157,169,172,168,2184,513]

theorem envBound32210 : H12AffineFastState.Bounded env32210 := by
  intro p hp
  have h : env32210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32209_32210 : H12AffineEnvironment.transform 7 173 env32209 = env32210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32209 == env32210) = true)

theorem identity32210 : scanCanonicalize (H12AffineFastState.compose env32210 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32210 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env32211 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,40,2048,1,35,2065,2049,53,0,2048,33,16,3,41,16,2049,2065,2065,2048,20,32,37,33,2049,513]

theorem envBound32211 : H12AffineFastState.Bounded env32211 := by
  intro p hp
  have h : env32211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32210_32211 : H12AffineEnvironment.transform 6 9 env32210 = env32211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32210 == env32211) = true)

theorem identity32211 : scanCanonicalize (H12AffineFastState.compose env32211 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32212 : List Nat := [2,4,8,16,32,16,9,36,1,52,2048,2065,40,2048,1,35,2065,2049,53,0,2048,33,16,3,41,16,2049,2065,2065,2048,20,32,37,33,2049,0]

theorem envBound32212 : H12AffineFastState.Bounded env32212 := by
  intro p hp
  have h : env32212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32211_32212 : H12AffineEnvironment.transform 8 1 env32211 = env32212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32211 == env32212) = true)

theorem identity32212 : scanCanonicalize (H12AffineFastState.compose env32212 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound32212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32213 : List Nat := [2,4,8,16,32,16,9,36,1,52,10,27,40,10,1,35,27,11,53,0,10,33,16,3,41,16,11,27,27,10,20,32,37,33,11,0]

theorem envBound32213 : H12AffineFastState.Bounded env32213 := by
  intro p hp
  have h : env32213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32212_32213 : H12AffineEnvironment.transform 10 10 env32212 = env32213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env32212 == env32213) = true)

def env32214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1025,32769,4161,32,73755,95497,8328,64,97666,57797,91402,67755,119043,168,257,98814,90202,63188]

theorem envBound32214 : H12AffineFastState.Bounded env32214 := by
  intro p hp
  have h : env32214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32201_32214 : H12AffineEnvironment.transform 17 10401 env32201 = env32214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32201 == env32214) = true)

theorem identity32214 : scanCanonicalize (H12AffineFastState.compose env32214 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32214 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env32215 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1025,32769,4161,32,73755,95277,8328,64,97446,57569,91182,67755,118823,168,37,98522,90202,63188]

theorem envBound32215 : H12AffineFastState.Bounded env32215 := by
  intro p hp
  have h : env32215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32214_32215 : H12AffineEnvironment.transform 7 36 env32214 = env32215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32214 == env32215) = true)

def env32216 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8432,65536,24800,10401,1025,8433,4161,32,73755,95277,8328,64,97446,16401,91182,67755,94423,168,37,73770,90202,22052]

theorem envBound32216 : H12AffineFastState.Bounded env32216 := by
  intro p hp
  have h : env32216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32215_32216 : H12AffineEnvironment.transform 14 8432 env32215 = env32216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env32215 == env32216) = true)

theorem identity32216 : scanCanonicalize (H12AffineFastState.compose env32216 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32216 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32217 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8432,8203,24800,10401,1025,8433,4161,32,16,21542,8328,64,23725,16401,17445,10400,20700,168,37,33,16465,22052]

theorem envBound32217 : H12AffineFastState.Bounded env32217 := by
  intro p hp
  have h : env32217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32216_32217 : H12AffineEnvironment.transform 15 8203 env32216 = env32217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32216 == env32217) = true)

theorem identity32217 : scanCanonicalize (H12AffineFastState.compose env32217 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound32217 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32218 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,13404,8432,8203,5308,10401,1025,8433,4161,32,16,8314,8328,64,10481,13389,12409,10400,9344,168,37,33,13325,8824]

theorem envBound32218 : H12AffineFastState.Bounded env32218 := by
  intro p hp
  have h : env32218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32217_32218 : H12AffineEnvironment.transform 13 13404 env32217 = env32218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env32217 == env32218) = true)

theorem identity32218 : scanCanonicalize (H12AffineFastState.compose env32218 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32218 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env32219 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,13404,8313,8203,5173,10280,1025,8312,4161,32,16,8314,8193,64,10360,13389,12409,10281,9225,33,37,33,13325,8824]

theorem envBound32219 : H12AffineFastState.Bounded env32219 := by
  intro p hp
  have h : env32219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32218_32219 : H12AffineEnvironment.transform 6 9 env32218 = env32219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32218 == env32219) = true)

theorem identity32219 : scanCanonicalize (H12AffineFastState.compose env32219 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound32219 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32220 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,0,114,5173,2129,1025,1,4161,32,16,3,120,64,2049,5172,4096,2128,1136,33,37,33,5236,513]

theorem envBound32220 : H12AffineFastState.Bounded env32220 := by
  intro p hp
  have h : env32220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32219_32220 : H12AffineEnvironment.transform 12 121 env32219 = env32220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env32219 == env32220) = true)

theorem identity32220 : scanCanonicalize (H12AffineFastState.compose env32220 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound32220 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32221 : List Nat := [2,4,8,16,32,64,9,36,512,1024,90,4096,121,5157,0,114,5173,11,1025,1,4161,32,16,3,120,64,91,5172,4096,10,1136,33,37,33,5236,513]

theorem envBound32221 : H12AffineFastState.Bounded env32221 := by
  intro p hp
  have h : env32221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32220_32221 : H12AffineEnvironment.transform 10 90 env32220 = env32221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env32220 == env32221) = true)

theorem identity32221 : scanCanonicalize (H12AffineFastState.compose env32221 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound32221 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32222 : List Nat := [2,4,8,16,32,64,9,36,512,1024,90,81,121,1140,0,114,1124,11,1025,1,16,32,16,3,120,64,91,1125,81,10,1136,33,37,33,1061,513]

theorem envBound32222 : H12AffineFastState.Bounded env32222 := by
  intro p hp
  have h : env32222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32221_32222 : H12AffineEnvironment.transform 11 81 env32221 = env32222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env32221 == env32222) = true)

theorem identity32222 : scanCanonicalize (H12AffineFastState.compose env32222 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32222 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32223 : List Nat := [2,4,8,16,32,64,9,36,512,100,90,81,121,16,0,114,0,11,101,1,16,32,16,3,120,64,91,1,81,10,20,33,37,33,65,513]

theorem envBound32223 : H12AffineFastState.Bounded env32223 := by
  intro p hp
  have h : env32223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32222_32223 : H12AffineEnvironment.transform 9 100 env32222 = env32223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32222 == env32223) = true)

theorem identity32223 : scanCanonicalize (H12AffineFastState.compose env32223 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32224 : List Nat := [2,4,8,16,32,17,9,36,512,53,11,0,40,16,0,35,0,11,52,1,16,32,16,3,41,17,10,1,0,10,20,33,37,33,16,513]

theorem envBound32224 : H12AffineFastState.Bounded env32224 := by
  intro p hp
  have h : env32224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32223_32224 : H12AffineEnvironment.transform 5 17 env32223 = env32224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32223 == env32224) = true)

theorem identity32224 : scanCanonicalize (H12AffineFastState.compose env32224 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound32224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32225 : List Nat := [2,4,8,5,32,4,9,36,512,32,11,0,40,5,0,35,0,11,33,1,5,32,5,3,41,4,10,1,0,10,1,33,37,33,5,513]

theorem envBound32225 : H12AffineFastState.Bounded env32225 := by
  intro p hp
  have h : env32225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32224_32225 : H12AffineEnvironment.transform 3 5 env32224 = env32225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env32224 == env32225) = true)

theorem identity32225 : scanCanonicalize (H12AffineFastState.compose env32225 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound32225 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32226 : List Nat := [2,4,8,5,32,4,9,36,3,32,11,0,40,5,0,35,0,11,33,1,5,32,5,3,41,4,10,1,0,10,1,33,37,33,5,2]

theorem envBound32226 : H12AffineFastState.Bounded env32226 := by
  intro p hp
  have h : env32226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32225_32226 : H12AffineEnvironment.transform 8 3 env32225 = env32226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env32225 == env32226) = true)

theorem identity32226 : scanCanonicalize (H12AffineFastState.compose env32226 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound32226 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32227 : List Nat := [2,4,8,5,15,4,9,11,3,15,11,0,7,5,0,12,0,11,14,1,5,15,5,3,6,4,10,1,0,10,1,14,10,14,5,2]

theorem envBound32227 : H12AffineFastState.Bounded env32227 := by
  intro p hp
  have h : env32227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32226_32227 : H12AffineEnvironment.transform 4 15 env32226 = env32227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env32226 == env32227) = true)

theorem identity32227 : scanCanonicalize (H12AffineFastState.compose env32227 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32227 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env32228 : List Nat := [2,0,8,1,11,0,9,11,3,11,11,0,3,1,0,8,0,11,10,1,1,11,1,3,2,0,10,1,0,10,1,10,10,10,1,2]

theorem envBound32228 : H12AffineFastState.Bounded env32228 := by
  intro p hp
  have h : env32228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32227_32228 : H12AffineEnvironment.transform 1 0 env32227 = env32228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32227 == env32228) = true)

theorem identity32228 : scanCanonicalize (H12AffineFastState.compose env32228 (packedSelected [12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32228 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env32229 : List Nat := [2,0,3,1,0,0,2,0,3,0,0,0,3,1,0,3,0,0,1,1,1,0,1,3,2,0,1,1,0,1,1,1,1,1,1,2]

theorem envBound32229 : H12AffineFastState.Bounded env32229 := by
  intro p hp
  have h : env32229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32228_32229 : H12AffineEnvironment.transform 2 3 env32228 = env32229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32228 == env32229) = true)

end H12CloudChart0