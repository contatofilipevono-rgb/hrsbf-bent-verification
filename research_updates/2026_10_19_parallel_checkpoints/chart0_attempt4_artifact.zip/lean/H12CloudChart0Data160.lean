import H12CloudChart0Data159

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env40564 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21897,263,5393,23725,1024,21896,4112,21928,152,21763,269,16,23809,5393,17801,23724,1285,21928,256,21929,16385,513]

theorem envBound40564 : H12AffineFastState.Bounded env40564 := by
  intro p hp
  have h : env40564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40563_40564 : H12AffineEnvironment.transform 12 389 env40563 = env40564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env40563 == env40564) = true)

theorem identity40564 : scanCanonicalize (H12AffineFastState.compose env40564 (packedSelected [0,4,7,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2477) := by decide +kernel

theorem selectedBound40564 : packedSelected [0,4,7,9,14,15] rootPS < 2^1333 := by decide +kernel

def env40565 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,2477,7204,263,5393,5376,1024,7205,4112,7173,152,7342,269,16,5292,5393,3108,5377,1285,7173,256,7172,2476,513]

theorem envBound40565 : H12AffineFastState.Bounded env40565 := by
  intro p hp
  have h : env40565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40564_40565 : H12AffineEnvironment.transform 13 2477 env40564 = env40565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2477 env40564 == env40565) = true)

theorem identity40565 : scanCanonicalize (H12AffineFastState.compose env40565 (packedSelected [0,1,7,8,10,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound40565 : packedSelected [0,1,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env40566 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,389,2477,428,263,2201,2184,1024,429,3480,397,152,294,269,16,2340,2201,3108,2185,1285,397,256,396,2476,513]

theorem envBound40566 : H12AffineFastState.Bounded env40566 := by
  intro p hp
  have h : env40566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40565_40566 : H12AffineEnvironment.transform 11 3464 env40565 = env40566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env40565 == env40566) = true)

theorem identity40566 : scanCanonicalize (H12AffineFastState.compose env40566 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40566 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env40567 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3108,41,2049,0,171,2201,2184,1024,1,3124,33,152,138,161,16,2184,2201,3108,2185,1193,33,172,32,2048,513]

theorem envBound40567 : H12AffineFastState.Bounded env40567 := by
  intro p hp
  have h : env40567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40566_40567 : H12AffineEnvironment.transform 7 172 env40566 = env40567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40566 == env40567) = true)

theorem identity40567 : scanCanonicalize (H12AffineFastState.compose env40567 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40567 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40568 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,2065,41,2049,0,171,2201,2184,53,1,2049,33,152,138,161,16,2184,2201,2065,2185,156,33,172,32,2048,513]

theorem envBound40568 : H12AffineFastState.Bounded env40568 := by
  intro p hp
  have h : env40568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40567_40568 : H12AffineEnvironment.transform 9 53 env40567 = env40568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40567 == env40568) = true)

def env40569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound40569 : H12AffineFastState.Bounded env40569 := by
  intro p hp
  have h : env40569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40332_40569 : H12AffineEnvironment.transform 18 1025 env40332 = env40569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env40332 == env40569) = true)

theorem identity40569 : scanCanonicalize (H12AffineFastState.compose env40569 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388279) := by decide +kernel

theorem selectedBound40569 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,4194304,8388608,16777216,8328,65,29868033,17066042,8763879,8830976,25265168,21268855,257,25438234,25479615,25207750]

theorem envBound40570 : H12AffineFastState.Bounded env40570 := by
  intro p hp
  have h : env40570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40569_40570 : H12AffineEnvironment.transform 20 388279 env40569 = env40570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388279 env40569 == env40570) = true)

def env40571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,4194304,8388608,351520,8328,65,12754209,79130,8763879,8830976,8706352,4314199,257,8484154,8492191,8781542]

theorem envBound40571 : H12AffineFastState.Bounded env40571 := by
  intro p hp
  have h : env40571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40570_40571 : H12AffineEnvironment.transform 23 351520 env40570 = env40571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351520 env40570 == env40571) = true)

def env40572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,8388608,95496,8328,65,12754209,79130,8491471,8579112,8450328,4314199,257,8484154,8492191,8509134]

theorem envBound40572 : H12AffineFastState.Bounded env40572 := by
  intro p hp
  have h : env40572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40571_40572 : H12AffineEnvironment.transform 17 10280 env40571 = env40572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40571 == env40572) = true)

def env40573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,16,95496,8328,65,4365617,79130,102879,190520,61704,4314199,257,95530,103567,120542]

theorem envBound40573 : H12AffineFastState.Bounded env40573 := by
  intro p hp
  have h : env40573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40572_40573 : H12AffineEnvironment.transform 22 16 env40572 = env40573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40572 == env40573) = true)

theorem identity40573 : scanCanonicalize (H12AffineFastState.compose env40573 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound40573 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,62588,16,95496,8328,65,158029,79130,102879,190520,61704,73771,257,95530,103567,120542]

theorem envBound40574 : H12AffineFastState.Bounded env40574 := by
  intro p hp
  have h : env40574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40573_40574 : H12AffineEnvironment.transform 21 62588 env40573 = env40574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env40573 == env40574) = true)

theorem identity40574 : scanCanonicalize (H12AffineFastState.compose env40574 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound40574 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env40575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4160,62588,16,41431,8328,65,158029,57797,17664,190520,61704,62708,257,41461,16464,513]

theorem envBound40575 : H12AffineFastState.Bounded env40575 := by
  intro p hp
  have h : env40575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40574_40575 : H12AffineEnvironment.transform 15 54495 env40574 = env40575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env40574 == env40575) = true)

theorem identity40575 : scanCanonicalize (H12AffineFastState.compose env40575 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound40575 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46277,10280,1025,32769,4160,62588,16,41431,8328,65,56712,57797,17664,23805,61704,62708,257,41461,16464,513]

theorem envBound40576 : H12AffineFastState.Bounded env40576 := by
  intro p hp
  have h : env40576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40575_40576 : H12AffineEnvironment.transform 16 46277 env40575 = env40576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env40575 == env40576) = true)

theorem identity40576 : scanCanonicalize (H12AffineFastState.compose env40576 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9413) := by decide +kernel

theorem selectedBound40576 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9413,28698,4096,10280,1025,9412,4160,20665,16,1298,8328,65,31053,17664,17664,23805,21965,20529,257,1328,16464,513]

theorem envBound40577 : H12AffineFastState.Bounded env40577 := by
  intro p hp
  have h : env40577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40576_40577 : H12AffineEnvironment.transform 14 9413 env40576 = env40577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9413 env40576 == env40577) = true)

theorem identity40577 : scanCanonicalize (H12AffineFastState.compose env40577 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40577 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,9413,9499,4096,10280,1025,9412,4160,1464,16,1298,8328,65,11340,4097,4097,2556,204,1328,257,1328,5457,513]

theorem envBound40578 : H12AffineFastState.Bounded env40578 := by
  intro p hp
  have h : env40578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40577_40578 : H12AffineEnvironment.transform 13 5377 env40577 = env40578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40577 == env40578) = true)

theorem identity40578 : scanCanonicalize (H12AffineFastState.compose env40578 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound40578 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env40579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5377,216,262,4096,3125,1025,217,4160,1464,16,1298,1173,65,2129,4097,4097,2556,204,1328,257,1328,5457,513]

theorem envBound40579 : H12AffineFastState.Bounded env40579 := by
  intro p hp
  have h : env40579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40578_40579 : H12AffineEnvironment.transform 12 1053 env40578 = env40579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env40578 == env40579) = true)

theorem identity40579 : scanCanonicalize (H12AffineFastState.compose env40579 (packedSelected [1,7,8,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound40579 : packedSelected [1,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env40580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,1053,1212,216,262,445,3125,1025,217,509,1464,16,1298,1173,65,2129,444,444,2556,204,1328,257,1328,1260,513]

theorem envBound40580 : H12AffineFastState.Bounded env40580 := by
  intro p hp
  have h : env40580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40579_40580 : H12AffineEnvironment.transform 11 445 env40579 = env40580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env40579 == env40580) = true)

theorem identity40580 : scanCanonicalize (H12AffineFastState.compose env40580 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40580 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env40581 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,445,1053,1212,136,262,445,3125,1025,137,429,1464,16,1298,1173,17,2049,444,444,2476,156,1328,257,1328,1212,513]

theorem envBound40581 : H12AffineFastState.Bounded env40581 := by
  intro p hp
  have h : env40581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40580_40581 : H12AffineEnvironment.transform 5 16 env40580 = env40581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40580 == env40581) = true)

theorem identity40581 : scanCanonicalize (H12AffineFastState.compose env40581 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound40581 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40582 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,445,160,1,136,262,445,2184,188,137,429,261,16,431,40,17,2049,444,444,2476,156,397,257,397,1,513]

theorem envBound40582 : H12AffineFastState.Bounded env40582 := by
  intro p hp
  have h : env40582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40581_40582 : H12AffineEnvironment.transform 9 189 env40581 = env40582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env40581 == env40582) = true)

theorem identity40582 : scanCanonicalize (H12AffineFastState.compose env40582 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound40582 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env40583 : List Nat := [2,4,8,16,32,16,128,256,512,189,821,445,160,1,136,262,445,957,188,137,429,261,16,431,40,17,820,444,444,665,156,397,257,397,1,513]

theorem envBound40583 : H12AffineFastState.Bounded env40583 := by
  intro p hp
  have h : env40583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40582_40583 : H12AffineEnvironment.transform 10 821 env40582 = env40583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env40582 == env40583) = true)

theorem identity40583 : scanCanonicalize (H12AffineFastState.compose env40583 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 445) := by decide +kernel

theorem selectedBound40583 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env40584 : List Nat := [2,4,8,16,32,16,128,256,445,189,136,445,160,1,136,262,445,0,188,137,429,261,16,431,40,17,137,444,444,292,156,397,257,397,1,444]

theorem envBound40584 : H12AffineFastState.Bounded env40584 := by
  intro p hp
  have h : env40584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40583_40584 : H12AffineEnvironment.transform 8 445 env40583 = env40584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 445 env40583 == env40584) = true)

theorem identity40584 : scanCanonicalize (H12AffineFastState.compose env40584 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40584 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env40585 : List Nat := [2,4,8,16,32,16,128,37,152,189,136,152,160,1,136,35,152,0,188,137,136,32,16,138,40,17,137,153,153,1,156,168,36,168,1,153]

theorem envBound40585 : H12AffineFastState.Bounded env40585 := by
  intro p hp
  have h : env40585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40584_40585 : H12AffineEnvironment.transform 7 37 env40584 = env40585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40584 == env40585) = true)

theorem identity40585 : scanCanonicalize (H12AffineFastState.compose env40585 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound40585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40586 : List Nat := [2,4,8,16,32,16,2,37,26,63,10,26,34,1,10,35,26,0,62,11,10,32,16,8,40,17,11,27,27,1,30,42,36,42,1,27]

theorem envBound40586 : H12AffineFastState.Bounded env40586 := by
  intro p hp
  have h : env40586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40585_40586 : H12AffineEnvironment.transform 6 2 env40585 = env40586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env40585 == env40586) = true)

theorem identity40586 : scanCanonicalize (H12AffineFastState.compose env40586 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40586 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40587 : List Nat := [2,4,2,16,32,16,2,37,16,53,0,16,34,1,0,35,16,0,52,1,0,32,16,2,34,17,1,17,17,1,20,32,36,32,1,17]

theorem envBound40587 : H12AffineFastState.Bounded env40587 := by
  intro p hp
  have h : env40587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40586_40587 : H12AffineEnvironment.transform 2 2 env40586 = env40587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40586 == env40587) = true)

def env40588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,17,95496,8328,65,4365616,79130,102878,190521,61705,4314199,257,95531,103566,120543]

theorem envBound40588 : H12AffineFastState.Bounded env40588 := by
  intro p hp
  have h : env40588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40572_40588 : H12AffineEnvironment.transform 22 17 env40572 = env40588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40572 == env40588) = true)

theorem identity40588 : scanCanonicalize (H12AffineFastState.compose env40588 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40588 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10280,1025,29909,77899,4194304,17,95496,8328,65,4352484,79130,91402,138477,1501,4268163,257,95531,90202,74251]

theorem envBound40589 : H12AffineFastState.Bounded env40589 := by
  intro p hp
  have h : env40589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40588_40589 : H12AffineEnvironment.transform 14 29908 env40588 = env40589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40588 == env40589) = true)

theorem identity40589 : scanCanonicalize (H12AffineFastState.compose env40589 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40589 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env40590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,10280,1025,29909,77899,4194304,17,95496,8328,65,4262398,79130,91402,97527,1501,4268163,257,95531,90202,74251]

theorem envBound40590 : H12AffineFastState.Bounded env40590 := by
  intro p hp
  have h : env40590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40589_40590 : H12AffineEnvironment.transform 16 90138 env40589 = env40590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40589 == env40590) = true)

theorem identity40590 : scanCanonicalize (H12AffineFastState.compose env40590 (packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound40590 : packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env40591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,10280,1025,29909,77899,21793,17,95496,8328,65,89311,79130,91402,97527,1501,95650,257,95531,90202,74251]

theorem envBound40591 : H12AffineFastState.Bounded env40591 := by
  intro p hp
  have h : env40591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40590_40591 : H12AffineEnvironment.transform 21 21793 env40590 = env40591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env40590 == env40591) = true)

theorem identity40591 : scanCanonicalize (H12AffineFastState.compose env40591 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40591 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,65536,82246,2420,1025,21897,69911,21793,17,87124,468,65,89311,70726,83030,89515,1501,87294,257,87159,82182,66391]

theorem envBound40592 : H12AffineFastState.Bounded env40592 := by
  intro p hp
  have h : env40592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40591_40592 : H12AffineEnvironment.transform 12 348 env40591 = env40592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40591 == env40592) = true)

theorem identity40592 : scanCanonicalize (H12AffineFastState.compose env40592 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound40592 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env40593 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,348,16384,20972,65536,82246,2420,101,20973,69911,20805,17,86064,468,65,88251,69666,81970,88527,441,86170,257,86035,82182,66391]

theorem envBound40593 : H12AffineFastState.Bounded env40593 := by
  intro p hp
  have h : env40593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40592_40593 : H12AffineEnvironment.transform 9 100 env40592 = env40593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env40592 == env40593) = true)

theorem identity40593 : scanCanonicalize (H12AffineFastState.compose env40593 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound40593 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env40594 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,348,16384,20972,20759,4177,2420,101,20973,16384,20805,17,295,468,65,2476,16693,4389,2264,441,397,257,260,4113,21056]

theorem envBound40594 : H12AffineFastState.Bounded env40594 := by
  intro p hp
  have h : env40594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40593_40594 : H12AffineEnvironment.transform 15 20759 env40593 = env40594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env40593 == env40594) = true)

theorem identity40594 : scanCanonicalize (H12AffineFastState.compose env40594 (packedSelected [2,3,5,6,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4296) := by decide +kernel

theorem selectedBound40594 : packedSelected [2,3,5,6,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env40595 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,348,4296,292,479,4177,2420,101,293,4296,397,17,295,468,65,2476,4605,4389,2264,441,397,257,260,4113,648]

theorem envBound40595 : H12AffineFastState.Bounded env40595 := by
  intro p hp
  have h : env40595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40594_40595 : H12AffineEnvironment.transform 13 4296 env40594 = env40595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env40594 == env40595) = true)

theorem identity40595 : scanCanonicalize (H12AffineFastState.compose env40595 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40595 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40596 : List Nat := [2,4,8,16,32,64,128,116,512,100,2048,4096,40,4296,80,171,4177,2048,101,81,4296,249,17,83,160,65,2264,4233,4177,2264,205,249,117,112,4113,648]

theorem envBound40596 : H12AffineFastState.Bounded env40596 := by
  intro p hp
  have h : env40596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40595_40596 : H12AffineEnvironment.transform 7 116 env40595 = env40596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40595 == env40596) = true)

theorem identity40596 : scanCanonicalize (H12AffineFastState.compose env40596 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40596 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40597 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,4096,40,4249,1,171,4096,2048,52,0,4249,168,17,2,160,16,2185,4233,4096,2185,156,168,36,33,4113,648]

theorem envBound40597 : H12AffineFastState.Bounded env40597 := by
  intro p hp
  have h : env40597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40596_40597 : H12AffineEnvironment.transform 5 17 env40596 = env40597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40596 == env40597) = true)

theorem identity40597 : scanCanonicalize (H12AffineFastState.compose env40597 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound40597 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40598 : List Nat := [2,4,8,16,32,17,41,37,512,53,2048,4096,40,4144,1,2,4096,2048,52,0,4144,1,17,2,9,16,2080,4128,4096,2080,53,1,36,33,4113,545]

theorem envBound40598 : H12AffineFastState.Bounded env40598 := by
  intro p hp
  have h : env40598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40597_40598 : H12AffineEnvironment.transform 6 41 env40597 = env40598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env40597 == env40598) = true)

def env40599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,8388608,95497,8328,65,12754209,79130,8491470,8579113,8450329,4314199,257,8484154,8492191,8509135]

theorem envBound40599 : H12AffineFastState.Bounded env40599 := by
  intro p hp
  have h : env40599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40571_40599 : H12AffineEnvironment.transform 17 10281 env40571 = env40599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40571 == env40599) = true)

def env40600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,16,95497,8328,65,4365617,79130,102878,190521,61705,4314199,257,95530,103567,120543]

theorem envBound40600 : H12AffineFastState.Bounded env40600 := by
  intro p hp
  have h : env40600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40599_40600 : H12AffineEnvironment.transform 22 16 env40599 = env40600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40599 == env40600) = true)

theorem identity40600 : scanCanonicalize (H12AffineFastState.compose env40600 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound40600 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,169,16,95497,8328,65,171416,79130,102878,190521,61705,120062,257,95530,103567,120543]

theorem envBound40601 : H12AffineFastState.Bounded env40601 := by
  intro p hp
  have h : env40601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40600_40601 : H12AffineEnvironment.transform 21 169 env40600 = env40601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env40600 == env40601) = true)

theorem identity40601 : scanCanonicalize (H12AffineFastState.compose env40601 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound40601 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env40602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46276,10281,1025,32769,115870,169,16,95497,8328,65,10588,79130,102878,23805,61705,120062,257,95530,103567,120543]

theorem envBound40602 : H12AffineFastState.Bounded env40602 := by
  intro p hp
  have h : env40602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40601_40602 : H12AffineEnvironment.transform 16 46276 env40601 = env40602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env40601 == env40602) = true)

theorem identity40602 : scanCanonicalize (H12AffineFastState.compose env40602 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound40602 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,46276,10281,1025,32769,102679,169,16,73856,8328,65,10588,79130,102878,2420,42112,98679,257,73891,103567,99158]

theorem envBound40603 : H12AffineFastState.Bounded env40603 := by
  intro p hp
  have h : env40603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40602_40603 : H12AffineEnvironment.transform 13 5513 env40602 = env40603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env40602 == env40603) = true)

def env40604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,17,95497,8328,65,4365616,79130,102879,190520,61704,4314199,257,95531,103566,120542]

theorem envBound40604 : H12AffineFastState.Bounded env40604 := by
  intro p hp
  have h : env40604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40599_40604 : H12AffineEnvironment.transform 22 17 env40599 = env40604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40599 == env40604) = true)

def env40605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,4194304,17,95497,8192,65,4365616,79130,102743,190520,61704,4314199,257,95531,103430,120406]

theorem envBound40605 : H12AffineFastState.Bounded env40605 := by
  intro p hp
  have h : env40605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40604_40605 : H12AffineEnvironment.transform 6 8 env40604 = env40605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40604 == env40605) = true)

theorem identity40605 : scanCanonicalize (H12AffineFastState.compose env40605 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40605 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,91466,4194304,17,95497,8192,65,4340844,79130,77835,149860,20564,4289803,257,95531,79194,96010]

theorem envBound40606 : H12AffineFastState.Bounded env40606 := by
  intro p hp
  have h : env40606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40605_40606 : H12AffineEnvironment.transform 14 8540 env40605 = env40606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40605 == env40606) = true)

theorem identity40606 : scanCanonicalize (H12AffineFastState.compose env40606 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40606 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env40607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1025,8541,91466,4194304,17,95497,8192,65,4283510,79130,77835,76158,20564,4289803,257,95531,79194,96010]

theorem envBound40607 : H12AffineFastState.Bounded env40607 := by
  intro p hp
  have h : env40607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40606_40607 : H12AffineEnvironment.transform 16 90138 env40606 = env40607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40606 == env40607) = true)

theorem identity40607 : scanCanonicalize (H12AffineFastState.compose env40607 (packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound40607 : packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env40608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1025,8541,91466,65911,17,95497,8192,65,23809,79130,77835,76158,20564,29820,257,95531,79194,96010]

theorem envBound40608 : H12AffineFastState.Bounded env40608 := by
  intro p hp
  have h : env40608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40607_40608 : H12AffineEnvironment.transform 21 65911 env40607 = env40608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env40607 == env40608) = true)

theorem identity40608 : scanCanonicalize (H12AffineFastState.compose env40608 (packedSelected [1,2,5,6,8,9,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound40608 : packedSelected [1,2,5,6,8,9,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env40609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,115,24681,10281,1025,8541,25913,260,17,30074,8192,65,23809,13673,12408,10509,20564,29820,257,30040,13609,30585]

theorem envBound40609 : H12AffineFastState.Bounded env40609 := by
  intro p hp
  have h : env40609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40608_40609 : H12AffineEnvironment.transform 15 115 env40608 = env40609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env40608 == env40609) = true)

theorem identity40609 : scanCanonicalize (H12AffineFastState.compose env40609 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40609 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env40610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,373,115,16448,2048,1025,372,17680,260,17,21843,41,65,23809,5440,4177,2340,20564,21589,257,21873,5376,22352]

theorem envBound40610 : H12AffineFastState.Bounded env40610 := by
  intro p hp
  have h : env40610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40609_40610 : H12AffineEnvironment.transform 12 41 env40609 = env40610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40609 == env40610) = true)

theorem identity40610 : scanCanonicalize (H12AffineFastState.compose env40610 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40610 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40611 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,1,115,16448,2048,1025,0,17508,112,17,21543,41,65,23669,5172,4177,2128,20564,21589,117,21509,5236,22052]

theorem envBound40611 : H12AffineFastState.Bounded env40611 := by
  intro p hp
  have h : env40611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40610_40611 : H12AffineEnvironment.transform 7 116 env40610 = env40611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40610 == env40611) = true)

theorem identity40611 : scanCanonicalize (H12AffineFastState.compose env40611 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40611 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40612 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,1,34,16401,2048,1025,0,17461,33,17,21543,41,16,23588,5172,4096,2049,20485,21508,36,21509,5157,22052]

theorem envBound40612 : H12AffineFastState.Bounded env40612 := by
  intro p hp
  have h : env40612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40611_40612 : H12AffineEnvironment.transform 5 17 env40611 = env40612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40611 == env40612) = true)

theorem identity40612 : scanCanonicalize (H12AffineFastState.compose env40612 (packedSelected [4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound40612 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env40613 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,41,16384,1,34,16401,2048,1025,0,17461,33,17,18435,41,16,16384,2064,3108,2049,19489,18464,36,18465,2049,18944]

theorem envBound40613 : H12AffineFastState.Bounded env40613 := by
  intro p hp
  have h : env40613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40612_40613 : H12AffineEnvironment.transform 11 3108 env40612 = env40613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env40612 == env40613) = true)

theorem identity40613 : scanCanonicalize (H12AffineFastState.compose env40613 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40613 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40614 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2065,41,16384,1,34,16401,2048,52,0,16384,33,17,18435,41,16,16384,2064,2065,2049,18452,18464,36,18465,2049,18944]

theorem envBound40614 : H12AffineFastState.Bounded env40614 := by
  intro p hp
  have h : env40614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40613_40614 : H12AffineEnvironment.transform 9 53 env40613 = env40614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40613 == env40614) = true)

def env40615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,4194304,17,95497,8193,65,4365616,79130,102742,190520,61704,4314199,257,95531,103431,120407]

theorem envBound40615 : H12AffineFastState.Bounded env40615 := by
  intro p hp
  have h : env40615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40604_40615 : H12AffineEnvironment.transform 6 9 env40604 = env40615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40604 == env40615) = true)

theorem identity40615 : scanCanonicalize (H12AffineFastState.compose env40615 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound40615 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env40616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4161,4194304,17,41311,8193,65,4365616,57676,17664,190520,61704,4194305,257,41341,16465,513]

theorem envBound40616 : H12AffineFastState.Bounded env40616 := by
  intro p hp
  have h : env40616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40615_40616 : H12AffineEnvironment.transform 15 54358 env40615 = env40616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env40615 == env40616) = true)

def env40617 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,4194304,17,41231,8193,17,4365616,57628,17664,190520,61704,4194305,257,41261,16385,513]

theorem envBound40617 : H12AffineFastState.Bounded env40617 := by
  intro p hp
  have h : env40617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40616_40617 : H12AffineEnvironment.transform 5 16 env40616 = env40617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40616 == env40617) = true)

theorem identity40617 : scanCanonicalize (H12AffineFastState.compose env40617 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound40617 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env40618 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,8493,17,41231,8193,17,179229,57628,17664,190520,61704,8492,257,41261,16385,513]

theorem envBound40618 : H12AffineFastState.Bounded env40618 := by
  intro p hp
  have h : env40618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40617_40618 : H12AffineEnvironment.transform 21 8493 env40617 = env40618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env40617 == env40618) = true)

theorem identity40618 : scanCanonicalize (H12AffineFastState.compose env40618 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound40618 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env40619 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,10281,1025,29709,4113,8493,17,21763,8193,17,149521,5392,17664,138292,1284,8492,257,21793,16385,513]

theorem envBound40619 : H12AffineFastState.Bounded env40619 := by
  intro p hp
  have h : env40619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40618_40619 : H12AffineEnvironment.transform 14 29708 env40618 = env40619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env40618 == env40619) = true)

theorem identity40619 : scanCanonicalize (H12AffineFastState.compose env40619 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40619 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40620 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10281,1025,8460,4113,8493,17,2,8193,17,138512,5392,4097,138292,1284,8492,257,32,5376,513]

theorem envBound40620 : H12AffineFastState.Bounded env40620 := by
  intro p hp
  have h : env40620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40619_40620 : H12AffineEnvironment.transform 13 5377 env40619 = env40620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40619 == env40620) = true)

theorem identity40620 : scanCanonicalize (H12AffineFastState.compose env40620 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound40620 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40621 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,13340,10281,1025,8460,4113,8493,17,2,8193,17,10508,5392,4097,10280,1284,8492,257,32,5376,513]

theorem envBound40621 : H12AffineFastState.Bounded env40621 := by
  intro p hp
  have h : env40621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40620_40621 : H12AffineEnvironment.transform 16 13340 env40620 = env40621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env40620 == env40621) = true)

theorem identity40621 : scanCanonicalize (H12AffineFastState.compose env40621 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40621 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40622 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1025,1,4113,32,17,2,268,17,2049,5392,4097,2341,1284,33,257,32,5376,513]

theorem envBound40622 : H12AffineFastState.Bounded env40622 := by
  intro p hp
  have h : env40622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40621_40622 : H12AffineEnvironment.transform 12 269 env40621 = env40622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40621 == env40622) = true)

theorem identity40622 : scanCanonicalize (H12AffineFastState.compose env40622 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40623 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5124,0,2,5140,2081,1025,1,4113,32,17,2,9,17,2049,5141,4097,2080,1025,33,4,32,5125,513]

theorem envBound40623 : H12AffineFastState.Bounded env40623 := by
  intro p hp
  have h : env40623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40622_40623 : H12AffineEnvironment.transform 7 5 env40622 = env40623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40622 == env40623) = true)

theorem identity40623 : scanCanonicalize (H12AffineFastState.compose env40623 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40623 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40624 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,4096,8,4144,0,2,4128,2081,53,1,4113,32,17,2,9,17,2049,4129,4097,2080,53,33,4,32,4145,513]

theorem envBound40624 : H12AffineFastState.Bounded env40624 := by
  intro p hp
  have h : env40624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40623_40624 : H12AffineEnvironment.transform 9 52 env40623 = env40624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40623 == env40624) = true)

theorem identity40624 : scanCanonicalize (H12AffineFastState.compose env40624 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound40624 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40625 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,2608,8,2560,0,2,2576,2081,53,1,2593,32,17,2,9,17,2049,2577,2609,2080,53,33,4,32,2561,513]

theorem envBound40625 : H12AffineFastState.Bounded env40625 := by
  intro p hp
  have h : env40625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40624_40625 : H12AffineEnvironment.transform 11 2608 env40624 = env40625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env40624 == env40625) = true)

theorem identity40625 : scanCanonicalize (H12AffineFastState.compose env40625 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound40625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40626 : List Nat := [2,4,8,16,32,16,9,5,512,52,513,49,8,1,0,2,17,544,53,1,32,32,17,2,9,17,512,16,48,545,53,33,4,32,0,513]

theorem envBound40626 : H12AffineFastState.Bounded env40626 := by
  intro p hp
  have h : env40626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40625_40626 : H12AffineEnvironment.transform 10 513 env40625 = env40626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env40625 == env40626) = true)

theorem identity40626 : scanCanonicalize (H12AffineFastState.compose env40626 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound40626 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40627 : List Nat := [2,4,8,16,32,16,9,5,49,52,48,49,8,1,0,2,17,17,53,1,32,32,17,2,9,17,49,16,48,16,53,33,4,32,0,48]

theorem envBound40627 : H12AffineFastState.Bounded env40627 := by
  intro p hp
  have h : env40627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40626_40627 : H12AffineEnvironment.transform 8 49 env40626 = env40627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40626 == env40627) = true)

theorem identity40627 : scanCanonicalize (H12AffineFastState.compose env40627 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40627 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40628 : List Nat := [2,4,8,16,1,16,9,5,16,21,17,16,8,1,0,2,17,17,20,1,1,1,17,2,9,17,16,16,17,16,20,0,4,1,0,17]

theorem envBound40628 : H12AffineFastState.Bounded env40628 := by
  intro p hp
  have h : env40628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40627_40628 : H12AffineEnvironment.transform 4 1 env40627 = env40628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40627 == env40628) = true)

theorem identity40628 : scanCanonicalize (H12AffineFastState.compose env40628 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40629 : List Nat := [2,4,8,10,1,10,9,5,10,15,11,10,8,1,0,2,11,11,14,1,1,1,11,2,9,11,10,10,11,10,14,0,4,1,0,11]

theorem envBound40629 : H12AffineFastState.Bounded env40629 := by
  intro p hp
  have h : env40629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40628_40629 : H12AffineEnvironment.transform 3 10 env40628 = env40629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40628 == env40629) = true)

def env40630 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4112,4194304,17,41230,8193,16,4365616,57629,17664,190520,61704,4194305,257,41260,16384,513]

theorem envBound40630 : H12AffineFastState.Bounded env40630 := by
  intro p hp
  have h : env40630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40616_40630 : H12AffineEnvironment.transform 5 17 env40616 = env40630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40616 == env40630) = true)

theorem identity40630 : scanCanonicalize (H12AffineFastState.compose env40630 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40630 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env40631 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21510,131072,10281,1025,0,4112,4194304,17,8463,8193,16,4332849,24860,17664,157753,28937,4194305,257,8493,16384,513]

theorem envBound40631 : H12AffineFastState.Bounded env40631 := by
  intro p hp
  have h : env40631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40630_40631 : H12AffineEnvironment.transform 14 1 env40630 = env40631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40630 == env40631) = true)

theorem identity40631 : scanCanonicalize (H12AffineFastState.compose env40631 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound40631 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40632 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21510,131072,10281,1025,0,4112,136497,17,8463,8193,16,2048,24860,17664,157753,28937,136496,257,8493,16384,513]

theorem envBound40632 : H12AffineFastState.Bounded env40632 := by
  intro p hp
  have h : env40632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40631_40632 : H12AffineEnvironment.transform 21 136497 env40631 = env40632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env40631 == env40632) = true)

theorem identity40632 : scanCanonicalize (H12AffineFastState.compose env40632 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound40632 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40633 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21510,13340,10281,1025,0,4112,8493,17,8463,8193,16,2048,24860,17664,23589,28937,8492,257,8493,16384,513]

theorem envBound40633 : H12AffineFastState.Bounded env40633 := by
  intro p hp
  have h : env40633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40632_40633 : H12AffineEnvironment.transform 16 13340 env40632 = env40633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env40632 == env40633) = true)

theorem identity40633 : scanCanonicalize (H12AffineFastState.compose env40633 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40633 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40634 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,21510,5392,2341,1025,0,4112,33,17,3,269,16,2048,16400,17664,23589,20485,32,257,33,16384,513]

theorem envBound40634 : H12AffineFastState.Bounded env40634 := by
  intro p hp
  have h : env40634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40633_40634 : H12AffineEnvironment.transform 12 268 env40633 = env40634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40633 == env40634) = true)

theorem identity40634 : scanCanonicalize (H12AffineFastState.compose env40634 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40634 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env40635 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,16384,1,21510,5173,2048,1025,0,4112,33,17,3,40,16,2048,16400,17445,23589,20485,32,36,33,16384,513]

theorem envBound40635 : H12AffineFastState.Bounded env40635 := by
  intro p hp
  have h : env40635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40634_40635 : H12AffineEnvironment.transform 7 37 env40634 = env40635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40634 == env40635) = true)

theorem identity40635 : scanCanonicalize (H12AffineFastState.compose env40635 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound40635 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40636 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,35,5173,2048,1025,0,4112,33,17,3,40,16,2048,5173,4096,2048,1056,32,36,33,5157,513]

theorem envBound40636 : H12AffineFastState.Bounded env40636 := by
  intro p hp
  have h : env40636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40635_40636 : H12AffineEnvironment.transform 13 5157 env40635 = env40636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env40635 == env40636) = true)

def env40637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,4194304,8388608,351521,8328,65,12754208,79131,8763879,8830976,8706353,4314198,257,8484155,8492190,8781543]

theorem envBound40637 : H12AffineFastState.Bounded env40637 := by
  intro p hp
  have h : env40637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40570_40637 : H12AffineEnvironment.transform 23 351521 env40570 = env40637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351521 env40570 == env40637) = true)

def env40638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,8388608,95497,8328,65,12754208,79131,8491471,8579112,8450329,4314198,257,8484155,8492190,8509135]

theorem envBound40638 : H12AffineFastState.Bounded env40638 := by
  intro p hp
  have h : env40638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40637_40638 : H12AffineEnvironment.transform 17 10280 env40637 = env40638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40637 == env40638) = true)

def env40639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,16,95497,8328,65,4365616,79131,102879,190520,61705,4314198,257,95531,103566,120543]

theorem envBound40639 : H12AffineFastState.Bounded env40639 := by
  intro p hp
  have h : env40639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40638_40639 : H12AffineEnvironment.transform 22 16 env40638 = env40639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40638 == env40639) = true)

theorem identity40639 : scanCanonicalize (H12AffineFastState.compose env40639 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound40639 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,73891,16,95497,8328,65,245139,79131,102879,190520,61705,62709,257,95531,103566,120543]

theorem envBound40640 : H12AffineFastState.Bounded env40640 := by
  intro p hp
  have h : env40640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40639_40640 : H12AffineEnvironment.transform 21 73891 env40639 = env40640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env40639 == env40640) = true)

theorem identity40640 : scanCanonicalize (H12AffineFastState.compose env40640 (packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 103631) := by decide +kernel

theorem selectedBound40640 : packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env40641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103631,10280,1025,32769,115871,73891,16,95497,8328,65,10588,79131,102879,97527,61705,62709,257,95531,103566,120543]

theorem envBound40641 : H12AffineFastState.Bounded env40641 := by
  intro p hp
  have h : env40641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40640_40641 : H12AffineEnvironment.transform 16 103631 env40640 = env40641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103631 env40640 == env40641) = true)

def env40642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103495,10280,1025,32769,115735,73771,16,95497,8192,65,10588,79131,102743,97407,61705,62589,257,95531,103430,120407]

theorem envBound40642 : H12AffineFastState.Bounded env40642 := by
  intro p hp
  have h : env40642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40641_40642 : H12AffineEnvironment.transform 6 8 env40641 = env40642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40641 == env40642) = true)

theorem identity40642 : scanCanonicalize (H12AffineFastState.compose env40642 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40642 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,79131,10280,1025,8541,91467,73771,16,95497,8192,65,10588,79131,77835,97407,20565,21793,257,95531,79194,96011]

theorem envBound40643 : H12AffineFastState.Bounded env40643 := by
  intro p hp
  have h : env40643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40642_40643 : H12AffineEnvironment.transform 14 8540 env40642 = env40643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40642 == env40643) = true)

theorem identity40643 : scanCanonicalize (H12AffineFastState.compose env40643 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40643 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,10280,1025,8541,77898,73771,16,73736,8192,65,10588,79131,77835,76158,1364,32,257,73770,79194,74250]

theorem envBound40644 : H12AffineFastState.Bounded env40644 := by
  intro p hp
  have h : env40644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40643_40644 : H12AffineEnvironment.transform 13 5377 env40643 = env40644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40643 == env40644) = true)

theorem identity40644 : scanCanonicalize (H12AffineFastState.compose env40644 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40644 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env40645 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8540,65536,77835,10280,273,8541,77898,73771,16,73736,8192,65,10588,77835,77835,76158,68,32,257,73770,77898,74250]

theorem envBound40645 : H12AffineFastState.Bounded env40645 := by
  intro p hp
  have h : env40645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40644_40645 : H12AffineEnvironment.transform 9 272 env40644 = env40645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40644 == env40645) = true)

theorem identity40645 : scanCanonicalize (H12AffineFastState.compose env40645 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 10330) := by decide +kernel

theorem selectedBound40645 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env40646 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8540,10330,6225,10280,273,8541,6160,2161,16,2130,8192,65,10588,6225,6225,292,68,32,257,2160,6160,2640]

theorem envBound40646 : H12AffineFastState.Bounded env40646 := by
  intro p hp
  have h : env40646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40645_40646 : H12AffineEnvironment.transform 15 10330 env40645 = env40646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10330 env40645 == env40646) = true)

theorem identity40646 : scanCanonicalize (H12AffineFastState.compose env40646 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound40646 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env40647 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2112,8192,2129,8540,10330,17,10280,273,8541,80,2161,16,2130,8192,65,10588,17,17,292,68,32,257,2160,80,2640]

theorem envBound40647 : H12AffineFastState.Bounded env40647 := by
  intro p hp
  have h : env40647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40646_40647 : H12AffineEnvironment.transform 11 2112 env40646 = env40647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env40646 == env40647) = true)

theorem identity40647 : scanCanonicalize (H12AffineFastState.compose env40647 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound40647 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env40648 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,17,8192,0,8540,8203,17,8313,273,8541,80,32,16,3,8192,65,8461,17,17,292,68,32,257,33,80,513]

theorem envBound40648 : H12AffineFastState.Bounded env40648 := by
  intro p hp
  have h : env40648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40647_40648 : H12AffineEnvironment.transform 10 81 env40647 = env40648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env40647 == env40648) = true)

theorem identity40648 : scanCanonicalize (H12AffineFastState.compose env40648 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40649 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,17,268,0,80,263,17,373,273,81,80,32,16,3,268,65,1,17,17,292,68,32,257,33,80,513]

theorem envBound40649 : H12AffineFastState.Bounded env40649 := by
  intro p hp
  have h : env40649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40648_40649 : H12AffineEnvironment.transform 12 268 env40648 = env40649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40648 == env40649) = true)

theorem identity40649 : scanCanonicalize (H12AffineFastState.compose env40649 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40649 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40650 : List Nat := [2,4,8,16,32,64,8,117,512,101,81,17,121,0,80,114,17,0,100,81,80,32,16,3,121,65,1,17,17,81,68,32,116,33,80,513]

theorem envBound40650 : H12AffineFastState.Bounded env40650 := by
  intro p hp
  have h : env40650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40649_40650 : H12AffineEnvironment.transform 7 117 env40649 = env40650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40649 == env40650) = true)

theorem identity40650 : scanCanonicalize (H12AffineFastState.compose env40650 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound40650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40651 : List Nat := [2,4,8,16,32,64,8,117,16,101,81,17,121,0,80,114,17,0,100,81,80,32,16,3,121,65,1,17,17,81,68,32,116,33,80,17]

theorem envBound40651 : H12AffineFastState.Bounded env40651 := by
  intro p hp
  have h : env40651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40650_40651 : H12AffineEnvironment.transform 8 16 env40650 = env40651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env40650 == env40651) = true)

theorem identity40651 : scanCanonicalize (H12AffineFastState.compose env40651 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound40651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40652 : List Nat := [2,4,8,16,32,59,8,14,16,30,42,17,2,0,43,9,17,0,31,42,43,32,16,3,2,58,1,17,17,42,63,32,15,33,43,17]

theorem envBound40652 : H12AffineFastState.Bounded env40652 := by
  intro p hp
  have h : env40652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40651_40652 : H12AffineEnvironment.transform 5 59 env40651 = env40652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env40651 == env40652) = true)

def env40653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103494,10280,1025,32769,115734,73770,16,95497,8193,65,10588,79131,102742,97406,61705,62588,257,95531,103431,120406]

theorem envBound40653 : H12AffineFastState.Bounded env40653 := by
  intro p hp
  have h : env40653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40641_40653 : H12AffineEnvironment.transform 6 9 env40641 = env40653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40641 == env40653) = true)

def env40654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,17,95497,8328,65,4365617,79131,102878,190521,61704,4314198,257,95530,103567,120542]

theorem envBound40654 : H12AffineFastState.Bounded env40654 := by
  intro p hp
  have h : env40654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40638_40654 : H12AffineEnvironment.transform 22 17 env40638 = env40654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40638 == env40654) = true)

theorem identity40654 : scanCanonicalize (H12AffineFastState.compose env40654 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40654 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58517,4194304,17,21763,8328,65,4365617,5393,45524,190521,61704,4256860,257,21792,46213,63188]

theorem envBound40655 : H12AffineFastState.Bounded env40655 := by
  intro p hp
  have h : env40655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40654_40655 : H12AffineEnvironment.transform 15 8202 env40654 = env40655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40654 == env40655) = true)

theorem identity40655 : scanCanonicalize (H12AffineFastState.compose env40655 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound40655 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58517,112,17,21763,8328,65,171329,5393,45524,190521,61704,62508,257,21792,46213,63188]

theorem envBound40656 : H12AffineFastState.Bounded env40656 := by
  intro p hp
  have h : env40656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40655_40656 : H12AffineEnvironment.transform 21 112 env40655 = env40656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env40655 == env40656) = true)

theorem identity40656 : scanCanonicalize (H12AffineFastState.compose env40656 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound40656 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env40657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46277,10280,1025,32769,58517,112,17,21763,8328,65,10628,5393,45524,23804,61704,62508,257,21792,46213,63188]

theorem envBound40657 : H12AffineFastState.Bounded env40657 := by
  intro p hp
  have h : env40657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40656_40657 : H12AffineEnvironment.transform 16 46277 env40656 = env40657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env40656 == env40657) = true)

theorem identity40657 : scanCanonicalize (H12AffineFastState.compose env40657 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound40657 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29005,8202,17800,10280,1025,29004,5592,112,17,21763,8328,65,10628,5393,16537,23804,69,1377,257,21792,17864,1945]

theorem envBound40658 : H12AffineFastState.Bounded env40658 := by
  intro p hp
  have h : env40658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40657_40658 : H12AffineEnvironment.transform 14 29005 env40657 = env40658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env40657 == env40658) = true)

theorem identity40658 : scanCanonicalize (H12AffineFastState.compose env40658 (packedSelected [1,3,4,14,18,20,22,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound40658 : packedSelected [1,3,4,14,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env40659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,16384,21541,1378,17800,3392,1025,21540,5592,112,17,21763,1504,65,3308,5393,16537,23804,69,1377,257,21792,17864,1945]

theorem envBound40659 : H12AffineFastState.Bounded env40659 := by
  intro p hp
  have h : env40659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40658_40659 : H12AffineEnvironment.transform 12 1384 env40658 = env40659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env40658 == env40659) = true)

theorem identity40659 : scanCanonicalize (H12AffineFastState.compose env40659 (packedSelected [0,5,7,8,9,11,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4540) := by decide +kernel

theorem selectedBound40659 : packedSelected [0,5,7,8,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env40660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,4540,1433,1378,5172,3392,1025,1432,5592,112,17,1215,1504,65,3308,5393,4389,3392,69,1377,257,1180,5236,1945]

theorem envBound40660 : H12AffineFastState.Bounded env40660 := by
  intro p hp
  have h : env40660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40659_40660 : H12AffineEnvironment.transform 13 4540 env40659 = env40660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4540 env40659 == env40660) = true)

theorem identity40660 : scanCanonicalize (H12AffineFastState.compose env40660 (packedSelected [0,1,2,5,6,7,14,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound40660 : packedSelected [0,1,2,5,6,7,14,16,19] rootPS < 2^1333 := by decide +kernel

def env40661 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,40,4540,217,34,4468,2048,321,216,4248,112,17,511,160,65,2476,4177,4389,2048,69,33,257,476,4404,729]

theorem envBound40661 : H12AffineFastState.Bounded env40661 := by
  intro p hp
  have h : env40661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40660_40661 : H12AffineEnvironment.transform 9 320 env40660 = env40661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env40660 == env40661) = true)

theorem identity40661 : scanCanonicalize (H12AffineFastState.compose env40661 (packedSelected [5,6,8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound40661 : packedSelected [5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env40662 : List Nat := [2,4,8,16,32,64,128,84,512,20,2048,4096,40,4328,217,34,4128,2048,21,216,4248,112,17,171,160,65,2296,4177,4209,2048,69,33,85,136,4192,729]

theorem envBound40662 : H12AffineFastState.Bounded env40662 := by
  intro p hp
  have h : env40662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40661_40662 : H12AffineEnvironment.transform 7 84 env40661 = env40662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env40661 == env40662) = true)

theorem identity40662 : scanCanonicalize (H12AffineFastState.compose env40662 (packedSelected [0,2,5,6,7,8,16] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound40662 : packedSelected [0,2,5,6,7,8,16] rootPS < 2^1333 := by decide +kernel

def env40663 : List Nat := [2,4,8,16,32,49,128,37,512,20,2048,4096,40,4249,168,34,4128,2048,21,169,4248,1,17,171,160,48,2185,4128,4096,2048,52,33,36,136,4113,680]

theorem envBound40663 : H12AffineFastState.Bounded env40663 := by
  intro p hp
  have h : env40663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40662_40663 : H12AffineEnvironment.transform 5 49 env40662 = env40663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env40662 == env40663) = true)

theorem identity40663 : scanCanonicalize (H12AffineFastState.compose env40663 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound40663 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40664 : List Nat := [2,4,8,16,32,49,40,37,512,20,2048,4096,40,4145,0,34,4128,2048,21,1,4144,1,17,3,8,48,2081,4128,4096,2048,52,33,36,32,4113,512]

theorem envBound40664 : H12AffineFastState.Bounded env40664 := by
  intro p hp
  have h : env40664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40663_40664 : H12AffineEnvironment.transform 6 40 env40663 = env40664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env40663 == env40664) = true)

theorem identity40664 : scanCanonicalize (H12AffineFastState.compose env40664 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound40664 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env40665 : List Nat := [2,4,8,16,32,49,40,37,512,20,2048,2609,40,2560,0,34,2577,2048,21,1,2561,1,17,3,8,48,2081,2577,2609,2048,52,33,36,32,2592,512]

theorem envBound40665 : H12AffineFastState.Bounded env40665 := by
  intro p hp
  have h : env40665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40664_40665 : H12AffineEnvironment.transform 11 2609 env40664 = env40665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env40664 == env40665) = true)

theorem identity40665 : scanCanonicalize (H12AffineFastState.compose env40665 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound40665 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40666 : List Nat := [2,4,8,16,32,49,40,37,33,20,2048,2064,40,2081,0,34,2096,2048,21,1,2080,1,17,3,8,48,2081,2096,2064,2048,52,33,36,32,2049,33]

theorem envBound40666 : H12AffineFastState.Bounded env40666 := by
  intro p hp
  have h : env40666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40665_40666 : H12AffineEnvironment.transform 8 33 env40665 = env40666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env40665 == env40666) = true)

theorem identity40666 : scanCanonicalize (H12AffineFastState.compose env40666 (packedSelected [0,1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40666 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env40667 : List Nat := [2,4,8,16,1,16,9,4,0,20,2048,2064,9,2048,0,3,2065,2048,21,1,2049,1,17,3,8,17,2048,2065,2064,2048,21,0,5,1,2049,0]

theorem envBound40667 : H12AffineFastState.Bounded env40667 := by
  intro p hp
  have h : env40667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40666_40667 : H12AffineEnvironment.transform 4 1 env40666 = env40667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40666 == env40667) = true)

theorem identity40667 : scanCanonicalize (H12AffineFastState.compose env40667 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound40667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40668 : List Nat := [2,4,8,16,1,16,9,4,0,20,31,15,9,31,0,3,14,31,21,1,30,1,17,3,8,17,31,14,15,31,21,0,5,1,30,0]

theorem envBound40668 : H12AffineFastState.Bounded env40668 := by
  intro p hp
  have h : env40668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40667_40668 : H12AffineEnvironment.transform 10 31 env40667 = env40668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env40667 == env40668) = true)

def leafEnv40668 : List Nat := [2,4,8,16,1,16,9,4,0,20,31,15,9,31,0,3,14,31,21,1,30,1,17,3,20,8,1,17,31,14,15,31,21,0,5,1,5,2,30,0,1,31,0]

def active40668 : List Nat := [0,1,2,3]

def tree40668 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40668 : H12WitnessSearch.Good tree40668 := H12GlobalWitnessIndex.good

theorem leafIdentity40668 : H12AffineFastState.composeSystem env40668 rootObs = leafEnv40668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40668 rootObs == leafEnv40668) = true)

theorem terminalChecked40668 : H12PackedTerminal.terminalCheckFast leafEnv40668 active40668 tree40668 = true := by decide +kernel

def env40669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,8388608,95496,8328,65,12754208,79131,8491470,8579113,8450328,4314198,257,8484155,8492190,8509134]

theorem envBound40669 : H12AffineFastState.Bounded env40669 := by
  intro p hp
  have h : env40669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40637_40669 : H12AffineEnvironment.transform 17 10281 env40637 = env40669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40637 == env40669) = true)

def env40670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,16,95496,8328,65,4365616,79131,102878,190521,61704,4314198,257,95531,103566,120542]

theorem envBound40670 : H12AffineFastState.Bounded env40670 := by
  intro p hp
  have h : env40670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40669_40670 : H12AffineEnvironment.transform 22 16 env40669 = env40670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40669 == env40670) = true)

theorem identity40670 : scanCanonicalize (H12AffineFastState.compose env40670 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119926) := by decide +kernel

theorem selectedBound40670 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,119926,16,95496,8328,65,215366,79131,102878,190521,61704,32,257,95531,103566,120542]

theorem envBound40671 : H12AffineFastState.Bounded env40671 := by
  intro p hp
  have h : env40671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40670_40671 : H12AffineEnvironment.transform 21 119926 env40670 = env40671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119926 env40670 == env40671) = true)

theorem identity40671 : scanCanonicalize (H12AffineFastState.compose env40671 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40671 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env40672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,115870,119926,16,95496,8328,65,10588,79131,102878,100387,61704,32,257,95531,103566,120542]

theorem envBound40672 : H12AffineFastState.Bounded env40672 := by
  intro p hp
  have h : env40672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40671_40672 : H12AffineEnvironment.transform 16 90138 env40671 = env40672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40671 == env40672) = true)

theorem identity40672 : scanCanonicalize (H12AffineFastState.compose env40672 (packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40672 : packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env40673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,115735,119926,16,95496,8193,65,10588,79131,102743,100387,61704,32,257,95531,103431,120407]

theorem envBound40673 : H12AffineFastState.Bounded env40673 := by
  intro p hp
  have h : env40673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40672_40673 : H12AffineEnvironment.transform 6 9 env40672 = env40673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40672 == env40673) = true)

theorem identity40673 : scanCanonicalize (H12AffineFastState.compose env40673 (packedSelected [0,1,2,3,6,11,12,14,15,18,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound40673 : packedSelected [0,1,2,3,6,11,12,14,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10281,1025,32769,17729,21792,16,62558,8193,65,10588,46157,4097,2421,61704,32,257,62589,5457,22273]

theorem envBound40674 : H12AffineFastState.Bounded env40674 := by
  intro p hp
  have h : env40674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40673_40674 : H12AffineEnvironment.transform 15 33110 env40673 = env40674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env40673 == env40674) = true)

theorem identity40674 : scanCanonicalize (H12AffineFastState.compose env40674 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40674 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env40675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33110,49169,2420,1025,32769,17729,21792,16,54531,348,65,2049,38160,4097,2421,53333,32,257,54560,5457,22273]

theorem envBound40675 : H12AffineFastState.Bounded env40675 := by
  intro p hp
  have h : env40675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40674_40675 : H12AffineEnvironment.transform 12 349 env40674 = env40675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40674 == env40675) = true)

def env40676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,17,95496,8328,65,4365617,79131,102879,190520,61705,4314198,257,95530,103567,120543]

theorem envBound40676 : H12AffineFastState.Bounded env40676 := by
  intro p hp
  have h : env40676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40669_40676 : H12AffineEnvironment.transform 22 17 env40669 = env40676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40669 == env40676) = true)

theorem identity40676 : scanCanonicalize (H12AffineFastState.compose env40676 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound40676 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4160,4194304,17,41430,8328,65,4365617,57797,17665,190520,61705,4194440,257,41460,16465,513]

theorem envBound40677 : H12AffineFastState.Bounded env40677 := by
  intro p hp
  have h : env40677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40676_40677 : H12AffineEnvironment.transform 15 54494 env40676 = env40677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env40676 == env40677) = true)

def env40678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,4194304,17,41310,8192,65,4365617,57677,17665,190520,61705,4194304,257,41340,16465,513]

theorem envBound40678 : H12AffineFastState.Bounded env40678 := by
  intro p hp
  have h : env40678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40677_40678 : H12AffineEnvironment.transform 6 8 env40677 = env40678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40677 == env40678) = true)

theorem identity40678 : scanCanonicalize (H12AffineFastState.compose env40678 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40678 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10281,1025,8541,4160,4194304,17,2,8192,65,4340845,16401,17665,149860,20565,4194304,257,32,16465,513]

theorem envBound40679 : H12AffineFastState.Bounded env40679 := by
  intro p hp
  have h : env40679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40678_40679 : H12AffineEnvironment.transform 14 8540 env40678 = env40679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40678 == env40679) = true)

theorem identity40679 : scanCanonicalize (H12AffineFastState.compose env40679 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40679 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40680 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,131072,10281,273,8541,4160,4194304,17,2,8192,65,4340093,16401,16401,149860,20565,4194304,257,32,16465,513]

theorem envBound40680 : H12AffineFastState.Bounded env40680 := by
  intro p hp
  have h : env40680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40679_40680 : H12AffineEnvironment.transform 9 272 env40679 = env40680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40679 == env40680) = true)

theorem identity40680 : scanCanonicalize (H12AffineFastState.compose env40680 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound40680 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env40681 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,4096,10281,273,8541,4160,4194304,17,2,8192,65,4204925,16401,16401,22884,20565,4194304,257,32,16465,513]

theorem envBound40681 : H12AffineFastState.Bounded env40681 := by
  intro p hp
  have h : env40681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40680_40681 : H12AffineEnvironment.transform 16 4096 env40680 = env40681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env40680 == env40681) = true)

theorem identity40681 : scanCanonicalize (H12AffineFastState.compose env40681 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 2081) := by decide +kernel

theorem selectedBound40681 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40682 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,4096,10281,273,8541,4160,2081,17,2,8192,65,8540,16401,16401,22884,20565,2081,257,32,16465,513]

theorem envBound40682 : H12AffineFastState.Bounded env40682 := by
  intro p hp
  have h : env40682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40681_40682 : H12AffineEnvironment.transform 21 2081 env40681 = env40682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2081 env40681 == env40682) = true)

theorem identity40682 : scanCanonicalize (H12AffineFastState.compose env40682 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound40682 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env40683 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,2317,16384,2129,22807,4096,292,273,2128,4160,2081,17,2,2317,65,2129,16401,16401,22884,20565,2081,257,32,16465,513]

theorem envBound40683 : H12AffineFastState.Bounded env40683 := by
  intro p hp
  have h : env40683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40682_40683 : H12AffineEnvironment.transform 12 2317 env40682 = env40683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env40682 == env40683) = true)

theorem identity40683 : scanCanonicalize (H12AffineFastState.compose env40683 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound40683 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40684 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,2317,2048,2129,4375,4096,292,273,2128,4160,2081,17,2,2317,65,2129,2065,2065,4452,6229,2081,257,32,2129,513]

theorem envBound40684 : H12AffineFastState.Bounded env40684 := by
  intro p hp
  have h : env40684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40683_40684 : H12AffineEnvironment.transform 13 2048 env40683 = env40684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env40683 == env40684) = true)

theorem identity40684 : scanCanonicalize (H12AffineFastState.compose env40684 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40684 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env40685 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,269,0,81,4375,4096,292,273,80,4160,33,17,2,269,65,81,17,17,4452,4181,33,257,32,81,513]

theorem envBound40685 : H12AffineFastState.Bounded env40685 := by
  intro p hp
  have h : env40685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40684_40685 : H12AffineEnvironment.transform 10 0 env40684 = env40685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40684 == env40685) = true)

theorem identity40685 : scanCanonicalize (H12AffineFastState.compose env40685 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound40685 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env40686 : List Nat := [2,4,8,16,32,64,8,256,293,272,0,4096,269,0,81,4375,4096,292,273,80,4160,33,17,2,269,65,81,17,17,4452,4181,33,257,32,81,292]

theorem envBound40686 : H12AffineFastState.Bounded env40686 := by
  intro p hp
  have h : env40686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40685_40686 : H12AffineEnvironment.transform 8 293 env40685 = env40686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env40685 == env40686) = true)

theorem identity40686 : scanCanonicalize (H12AffineFastState.compose env40686 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40686 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env40687 : List Nat := [2,4,8,16,32,64,8,68,97,84,0,4096,73,0,81,4179,4096,96,85,80,4160,33,17,2,73,65,81,17,17,4128,4181,33,69,32,81,96]

theorem envBound40687 : H12AffineFastState.Bounded env40687 := by
  intro p hp
  have h : env40687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40686_40687 : H12AffineEnvironment.transform 7 68 env40686 = env40687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40686 == env40687) = true)

theorem identity40687 : scanCanonicalize (H12AffineFastState.compose env40687 (packedSelected [0,2,6] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound40687 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env40688 : List Nat := [2,4,8,16,32,33,8,37,0,53,0,4096,40,0,48,4146,4096,1,52,49,4129,33,17,2,40,32,48,17,17,4128,4148,33,36,32,48,1]

theorem envBound40688 : H12AffineFastState.Bounded env40688 := by
  intro p hp
  have h : env40688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40687_40688 : H12AffineEnvironment.transform 5 33 env40687 = env40688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env40687 == env40688) = true)

theorem identity40688 : scanCanonicalize (H12AffineFastState.compose env40688 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound40688 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40689 : List Nat := [2,4,8,16,32,33,8,37,0,53,0,1,40,0,48,51,1,1,52,49,32,33,17,2,40,32,48,17,17,33,53,33,36,32,48,1]

theorem envBound40689 : H12AffineFastState.Bounded env40689 := by
  intro p hp
  have h : env40689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40688_40689 : H12AffineEnvironment.transform 11 1 env40688 = env40689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env40688 == env40689) = true)

theorem identity40689 : scanCanonicalize (H12AffineFastState.compose env40689 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40689 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40690 : List Nat := [2,4,8,16,17,16,8,20,0,4,0,1,25,0,1,2,1,1,5,0,17,16,17,2,25,17,1,17,17,16,4,16,21,17,1,1]

theorem envBound40690 : H12AffineFastState.Bounded env40690 := by
  intro p hp
  have h : env40690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40689_40690 : H12AffineEnvironment.transform 4 17 env40689 = env40690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40689 == env40690) = true)

def env40691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4160,4194304,17,41311,8193,65,4365617,57676,17665,190520,61705,4194305,257,41341,16465,513]

theorem envBound40691 : H12AffineFastState.Bounded env40691 := by
  intro p hp
  have h : env40691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40677_40691 : H12AffineEnvironment.transform 6 9 env40677 = env40691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40677 == env40691) = true)

def env40692 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4112,4194304,17,41231,8193,17,4365617,57628,17665,190520,61705,4194305,257,41261,16385,513]

theorem envBound40692 : H12AffineFastState.Bounded env40692 := by
  intro p hp
  have h : env40692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40691_40692 : H12AffineEnvironment.transform 5 16 env40691 = env40692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40691 == env40692) = true)

theorem identity40692 : scanCanonicalize (H12AffineFastState.compose env40692 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound40692 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env40693 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4112,8493,17,41231,8193,17,179228,57628,17665,190520,61705,8492,257,41261,16385,513]

theorem envBound40693 : H12AffineFastState.Bounded env40693 := by
  intro p hp
  have h : env40693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40692_40693 : H12AffineEnvironment.transform 21 8493 env40692 = env40693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env40692 == env40693) = true)

theorem identity40693 : scanCanonicalize (H12AffineFastState.compose env40693 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound40693 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env40694 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,10281,1025,29708,4112,8493,17,21762,8193,17,149521,5393,17665,138293,1284,8492,257,21792,16385,513]

theorem envBound40694 : H12AffineFastState.Bounded env40694 := by
  intro p hp
  have h : env40694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40693_40694 : H12AffineEnvironment.transform 14 29709 env40693 = env40694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env40693 == env40694) = true)

theorem identity40694 : scanCanonicalize (H12AffineFastState.compose env40694 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40695 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10281,1025,8460,4112,8493,17,2,8193,17,138513,5393,4097,138293,1284,8492,257,32,5377,513]

theorem envBound40695 : H12AffineFastState.Bounded env40695 := by
  intro p hp
  have h : env40695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40694_40695 : H12AffineEnvironment.transform 13 5376 env40694 = env40695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40694 == env40695) = true)

theorem identity40695 : scanCanonicalize (H12AffineFastState.compose env40695 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound40695 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40696 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,13341,10281,1025,8460,4112,8493,17,2,8193,17,10508,5393,4097,10280,1284,8492,257,32,5377,513]

theorem envBound40696 : H12AffineFastState.Bounded env40696 := by
  intro p hp
  have h : env40696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40695_40696 : H12AffineEnvironment.transform 16 13341 env40695 = env40696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env40695 == env40696) = true)

theorem identity40696 : scanCanonicalize (H12AffineFastState.compose env40696 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40696 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40697 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,263,5392,2340,1025,1,4112,32,17,2,268,17,2049,5393,4097,2341,1284,33,257,32,5377,513]

theorem envBound40697 : H12AffineFastState.Bounded env40697 := by
  intro p hp
  have h : env40697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40696_40697 : H12AffineEnvironment.transform 12 269 env40696 = env40697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40696 == env40697) = true)

theorem identity40697 : scanCanonicalize (H12AffineFastState.compose env40697 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40697 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40698 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,9,5124,0,3,5140,2080,1025,1,4112,32,17,2,8,17,2049,5141,4097,2081,1024,33,5,32,5125,513]

theorem envBound40698 : H12AffineFastState.Bounded env40698 := by
  intro p hp
  have h : env40698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40697_40698 : H12AffineEnvironment.transform 7 4 env40697 = env40698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40697 == env40698) = true)

theorem identity40698 : scanCanonicalize (H12AffineFastState.compose env40698 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40698 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40699 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,4096,9,4145,0,3,4129,2080,52,1,4112,32,17,2,8,17,2049,4128,4097,2081,53,33,5,32,4144,513]

theorem envBound40699 : H12AffineFastState.Bounded env40699 := by
  intro p hp
  have h : env40699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40698_40699 : H12AffineEnvironment.transform 9 53 env40698 = env40699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40698 == env40699) = true)

theorem identity40699 : scanCanonicalize (H12AffineFastState.compose env40699 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound40699 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40700 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,2609,9,2560,0,3,2576,2080,52,1,2593,32,17,2,8,17,2049,2577,2608,2081,53,33,5,32,2561,513]

theorem envBound40700 : H12AffineFastState.Bounded env40700 := by
  intro p hp
  have h : env40700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40699_40700 : H12AffineEnvironment.transform 11 2609 env40699 = env40700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env40699 == env40700) = true)

theorem identity40700 : scanCanonicalize (H12AffineFastState.compose env40700 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound40700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40701 : List Nat := [2,4,8,16,32,16,9,4,512,53,560,1,9,48,0,3,32,528,52,1,17,32,17,2,8,17,561,33,0,529,53,33,5,32,49,513]

theorem envBound40701 : H12AffineFastState.Bounded env40701 := by
  intro p hp
  have h : env40701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40700_40701 : H12AffineEnvironment.transform 10 560 env40700 = env40701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env40700 == env40701) = true)

theorem identity40701 : scanCanonicalize (H12AffineFastState.compose env40701 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40701 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40702 : List Nat := [2,4,8,16,32,16,9,4,1,53,49,1,9,48,0,3,32,17,52,1,17,32,17,2,8,17,48,33,0,16,53,33,5,32,49,0]

theorem envBound40702 : H12AffineFastState.Bounded env40702 := by
  intro p hp
  have h : env40702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40701_40702 : H12AffineEnvironment.transform 8 1 env40701 = env40702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40701 == env40702) = true)

theorem identity40702 : scanCanonicalize (H12AffineFastState.compose env40702 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40702 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40703 : List Nat := [2,4,8,16,1,16,9,4,1,20,16,1,9,17,0,3,1,17,21,1,17,1,17,2,8,17,17,0,0,16,20,0,5,1,16,0]

theorem envBound40703 : H12AffineFastState.Bounded env40703 := by
  intro p hp
  have h : env40703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40702_40703 : H12AffineEnvironment.transform 4 1 env40702 = env40703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40702 == env40703) = true)

theorem identity40703 : scanCanonicalize (H12AffineFastState.compose env40703 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40704 : List Nat := [2,4,8,1,1,1,9,4,1,5,1,1,9,0,0,3,1,0,4,1,0,1,0,2,8,0,0,0,0,1,5,0,5,1,1,0]

theorem envBound40704 : H12AffineFastState.Bounded env40704 := by
  intro p hp
  have h : env40704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40703_40704 : H12AffineEnvironment.transform 3 1 env40703 = env40704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40703 == env40704) = true)

def env40705 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,4194304,17,41230,8193,16,4365617,57629,17665,190520,61705,4194305,257,41260,16384,513]

theorem envBound40705 : H12AffineFastState.Bounded env40705 := by
  intro p hp
  have h : env40705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40691_40705 : H12AffineEnvironment.transform 5 17 env40691 = env40705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40691 == env40705) = true)

theorem identity40705 : scanCanonicalize (H12AffineFastState.compose env40705 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40705 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env40706 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21511,131072,10281,1025,0,4113,4194304,17,8463,8193,16,4332848,24860,17665,157753,28936,4194305,257,8493,16384,513]

theorem envBound40706 : H12AffineFastState.Bounded env40706 := by
  intro p hp
  have h : env40706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40705_40706 : H12AffineEnvironment.transform 14 1 env40705 = env40706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40705 == env40706) = true)

theorem identity40706 : scanCanonicalize (H12AffineFastState.compose env40706 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound40706 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40707 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21511,131072,10281,1025,0,4113,136496,17,8463,8193,16,2048,24860,17665,157753,28936,136497,257,8493,16384,513]

theorem envBound40707 : H12AffineFastState.Bounded env40707 := by
  intro p hp
  have h : env40707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40706_40707 : H12AffineEnvironment.transform 21 136496 env40706 = env40707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env40706 == env40707) = true)

theorem identity40707 : scanCanonicalize (H12AffineFastState.compose env40707 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound40707 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40708 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21511,13341,10281,1025,0,4113,8493,17,8463,8193,16,2048,24860,17665,23588,28936,8492,257,8493,16384,513]

theorem envBound40708 : H12AffineFastState.Bounded env40708 := by
  intro p hp
  have h : env40708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40707_40708 : H12AffineEnvironment.transform 16 13341 env40707 = env40708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env40707 == env40708) = true)

theorem identity40708 : scanCanonicalize (H12AffineFastState.compose env40708 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40708 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40709 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,21511,5393,2341,1025,0,4113,33,17,3,269,16,2048,16400,17665,23588,20484,32,257,33,16384,513]

theorem envBound40709 : H12AffineFastState.Bounded env40709 := by
  intro p hp
  have h : env40709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40708_40709 : H12AffineEnvironment.transform 12 268 env40708 = env40709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40708 == env40709) = true)

theorem identity40709 : scanCanonicalize (H12AffineFastState.compose env40709 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40709 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env40710 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,16384,1,21511,5173,2049,1025,0,4113,33,17,3,41,16,2048,16400,17445,23588,20484,32,37,33,16384,513]

theorem envBound40710 : H12AffineFastState.Bounded env40710 := by
  intro p hp
  have h : env40710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40709_40710 : H12AffineEnvironment.transform 7 36 env40709 = env40710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40709 == env40710) = true)

theorem identity40710 : scanCanonicalize (H12AffineFastState.compose env40710 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound40710 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40711 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5173,2049,1025,0,4113,33,17,3,41,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound40711 : H12AffineFastState.Bounded env40711 := by
  intro p hp
  have h : env40711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40710_40711 : H12AffineEnvironment.transform 13 5157 env40710 = env40711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env40710 == env40711) = true)

def env40712 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,1,34,1029,2049,1025,0,33,33,17,3,41,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound40712 : H12AffineFastState.Bounded env40712 := by
  intro p hp
  have h : env40712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40711_40712 : H12AffineEnvironment.transform 11 48 env40711 = env40712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40711 == env40712) = true)

theorem identity40712 : scanCanonicalize (H12AffineFastState.compose env40712 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40713 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1045,1,3,1029,2049,1025,0,0,0,17,3,8,16,2048,1029,17,2049,1024,1,4,0,1045,513]

theorem envBound40713 : H12AffineFastState.Bounded env40713 := by
  intro p hp
  have h : env40713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40712_40713 : H12AffineEnvironment.transform 4 1 env40712 = env40713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40712 == env40713) = true)

def env40714 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,9,1,1,3,17,2049,21,0,0,0,17,3,8,16,2048,17,17,2049,20,1,4,0,1,513]

theorem envBound40714 : H12AffineFastState.Bounded env40714 := by
  intro p hp
  have h : env40714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40713_40714 : H12AffineEnvironment.transform 9 20 env40713 = env40714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40713 == env40714) = true)

theorem identity40714 : scanCanonicalize (H12AffineFastState.compose env40714 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40715 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,1,1,3,17,1,21,0,0,0,17,3,8,16,0,17,17,1,20,1,4,0,1,513]

theorem envBound40715 : H12AffineFastState.Bounded env40715 := by
  intro p hp
  have h : env40715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40714_40715 : H12AffineEnvironment.transform 10 0 env40714 = env40715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40714 == env40715) = true)

def leafEnv40715 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,1,1,3,17,1,21,0,0,0,17,3,21,8,1,16,0,17,17,1,20,1,4,0,5,2,1,513,1,0,0]

def active40715 : List Nat := [0,1,2,3,8]

def tree40715 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40715 : H12WitnessSearch.Good tree40715 := H12GlobalWitnessIndex.good

theorem leafIdentity40715 : H12AffineFastState.composeSystem env40715 rootObs = leafEnv40715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40715 rootObs == leafEnv40715) = true)

theorem terminalChecked40715 : H12PackedTerminal.terminalCheckFast leafEnv40715 active40715 tree40715 = true := by decide +kernel

def env40716 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,0,1,3,16,2049,20,0,0,0,17,3,8,16,2048,16,17,2049,21,1,4,0,0,513]

theorem envBound40716 : H12AffineFastState.Bounded env40716 := by
  intro p hp
  have h : env40716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40713_40716 : H12AffineEnvironment.transform 9 21 env40713 = env40716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env40713 == env40716) = true)

theorem identity40716 : scanCanonicalize (H12AffineFastState.compose env40716 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound40716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40717 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,17,9,0,1,3,16,522,20,0,0,0,17,3,8,16,523,16,17,522,21,1,4,0,0,513]

theorem envBound40717 : H12AffineFastState.Bounded env40717 := by
  intro p hp
  have h : env40717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40716_40717 : H12AffineEnvironment.transform 10 523 env40716 = env40717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env40716 == env40717) = true)

def leafEnv40717 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,17,9,0,1,3,16,522,20,0,0,0,17,3,20,8,1,16,523,16,17,522,21,1,4,0,5,2,0,513,1,0,0]

def active40717 : List Nat := [0,1,2,3,8]

def tree40717 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40717 : H12WitnessSearch.Good tree40717 := H12GlobalWitnessIndex.good

theorem leafIdentity40717 : H12AffineFastState.composeSystem env40717 rootObs = leafEnv40717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40717 rootObs == leafEnv40717) = true)

theorem terminalChecked40717 : H12PackedTerminal.terminalCheckFast leafEnv40717 active40717 tree40717 = true := by decide +kernel

def env40718 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,1,34,1028,2049,1025,0,32,33,17,3,41,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound40718 : H12AffineFastState.Bounded env40718 := by
  intro p hp
  have h : env40718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40711_40718 : H12AffineEnvironment.transform 11 49 env40711 = env40718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40711 == env40718) = true)

theorem identity40718 : scanCanonicalize (H12AffineFastState.compose env40718 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound40718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40719 : List Nat := [2,4,8,16,32,17,9,36,512,20,2048,49,40,0,1,34,16,2049,21,0,32,33,17,3,41,16,2048,16,49,2049,53,32,37,33,0,513]

theorem envBound40719 : H12AffineFastState.Bounded env40719 := by
  intro p hp
  have h : env40719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40718_40719 : H12AffineEnvironment.transform 9 20 env40718 = env40719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40718 == env40719) = true)

def env40720 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,8,0,1,2,16,2049,21,0,0,1,17,3,9,16,2048,16,17,2049,21,0,5,1,0,513]

theorem envBound40720 : H12AffineFastState.Bounded env40720 := by
  intro p hp
  have h : env40720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40719_40720 : H12AffineEnvironment.transform 4 0 env40719 = env40720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40719 == env40720) = true)

theorem identity40720 : scanCanonicalize (H12AffineFastState.compose env40720 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound40720 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40721 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,17,8,0,1,2,16,523,21,0,0,1,17,3,9,16,522,16,17,523,21,0,5,1,0,513]

theorem envBound40721 : H12AffineFastState.Bounded env40721 := by
  intro p hp
  have h : env40721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40720_40721 : H12AffineEnvironment.transform 10 522 env40720 = env40721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env40720 == env40721) = true)

def leafEnv40721 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,17,8,0,1,2,16,523,21,0,0,1,17,3,20,9,1,16,522,16,17,523,21,0,5,1,5,3,0,513,1,0,0]

def active40721 : List Nat := [0,1,2,3,8]

def tree40721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40721 : H12WitnessSearch.Good tree40721 := H12GlobalWitnessIndex.good

theorem leafIdentity40721 : H12AffineFastState.composeSystem env40721 rootObs = leafEnv40721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40721 rootObs == leafEnv40721) = true)

theorem terminalChecked40721 : H12PackedTerminal.terminalCheckFast leafEnv40721 active40721 tree40721 = true := by decide +kernel

def env40722 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,0,1,3,16,2049,21,0,1,0,17,3,8,16,2048,16,16,2049,20,1,4,0,0,513]

theorem envBound40722 : H12AffineFastState.Bounded env40722 := by
  intro p hp
  have h : env40722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40719_40722 : H12AffineEnvironment.transform 4 1 env40719 = env40722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40719 == env40722) = true)

theorem identity40722 : scanCanonicalize (H12AffineFastState.compose env40722 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40723 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,0,1,3,16,0,21,0,1,0,17,3,8,16,1,16,16,0,20,1,4,0,0,513]

theorem envBound40723 : H12AffineFastState.Bounded env40723 := by
  intro p hp
  have h : env40723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40722_40723 : H12AffineEnvironment.transform 10 1 env40722 = env40723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40722 == env40723) = true)

def leafEnv40723 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,0,1,3,16,0,21,0,1,0,17,3,21,8,1,16,1,16,16,0,20,1,4,0,5,2,0,513,1,1,0]

def active40723 : List Nat := [0,1,2,3,8]

def tree40723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40723 : H12WitnessSearch.Good tree40723 := H12GlobalWitnessIndex.good

theorem leafIdentity40723 : H12AffineFastState.composeSystem env40723 rootObs = leafEnv40723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40723 rootObs == leafEnv40723) = true)

theorem terminalChecked40723 : H12PackedTerminal.terminalCheckFast leafEnv40723 active40723 tree40723 = true := by decide +kernel

def env40724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound40724 : H12AffineFastState.Bounded env40724 := by
  intro p hp
  have h : env40724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40331_40724 : H12AffineEnvironment.transform 26 30393345 env40331 = env40724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env40331 == env40724) = true)

def env40725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound40725 : H12AffineFastState.Bounded env40725 := by
  intro p hp
  have h : env40725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40724_40725 : H12AffineEnvironment.transform 18 1024 env40724 = env40725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env40724 == env40725) = true)

theorem identity40725 : scanCanonicalize (H12AffineFastState.compose env40725 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 485878) := by decide +kernel

theorem selectedBound40725 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,485878,16777216,8328,65,21015031,18973836,2571430,109046,17231334,23160257,256,19311963,19287294,17287729]

theorem envBound40726 : H12AffineFastState.Bounded env40726 := by
  intro p hp
  have h : env40726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40725_40726 : H12AffineEnvironment.transform 22 485878 env40725 = env40726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 485878 env40725 == env40726) = true)

def env40727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156012,485878,16777216,8328,65,16959643,18973836,2571430,109046,17231334,19072173,256,19311963,19287294,17287729]

theorem envBound40727 : H12AffineFastState.Bounded env40727 := by
  intro p hp
  have h : env40727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40726_40727 : H12AffineEnvironment.transform 21 156012 env40726 = env40727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env40726 == env40727) = true)

def env40728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485878,16777216,8328,65,16959643,17246708,102878,109046,17231334,17148373,256,16777251,16834950,17287729]

theorem envBound40728 : H12AffineFastState.Bounded env40728 := by
  intro p hp
  have h : env40728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40727_40728 : H12AffineEnvironment.transform 20 437624 env40727 = env40728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env40727 == env40728) = true)

theorem identity40728 : scanCanonicalize (H12AffineFastState.compose env40728 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound40728 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env40729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485878,188871,8328,65,10588,378931,102878,109046,265249,477202,256,188900,131137,338934]

theorem envBound40729 : H12AffineFastState.Bounded env40729 := by
  intro p hp
  have h : env40729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40728_40729 : H12AffineEnvironment.transform 23 188871 env40728 = env40729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env40728 == env40729) = true)

def env40730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156012,120014,188871,8328,65,10588,226571,102878,109046,176409,128298,256,188900,131137,235214]

theorem envBound40730 : H12AffineFastState.Bounded env40730 := by
  intro p hp
  have h : env40730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40729_40730 : H12AffineEnvironment.transform 17 179512 env40729 = env40730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env40729 == env40730) = true)

theorem identity40730 : scanCanonicalize (H12AffineFastState.compose env40730 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound40730 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149997,1024,29908,4160,156012,73755,136466,8328,65,10588,226571,91403,89379,148940,66047,256,136497,131137,221723]

theorem envBound40731 : H12AffineFastState.Bounded env40731 := by
  intro p hp
  have h : env40731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40730_40731 : H12AffineEnvironment.transform 14 29909 env40730 = env40731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env40730 == env40731) = true)

def env40732 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149949,1024,29828,4112,155964,73755,136466,8328,17,10508,226571,91403,89379,148892,65967,256,136497,131089,221723]

theorem envBound40732 : H12AffineFastState.Bounded env40732 := by
  intro p hp
  have h : env40732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40731_40732 : H12AffineEnvironment.transform 5 16 env40731 = env40732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40731 == env40732) = true)

theorem identity40732 : scanCanonicalize (H12AffineFastState.compose env40732 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound40732 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env40733 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79130,97447,1024,29828,4112,87078,73755,73736,8328,17,10508,16401,91403,89379,94342,65967,256,73771,79115,22273]

theorem envBound40733 : H12AffineFastState.Bounded env40733 := by
  intro p hp
  have h : env40733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40732_40733 : H12AffineEnvironment.transform 16 79130 env40732 = env40733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env40732 == env40733) = true)

theorem identity40733 : scanCanonicalize (H12AffineFastState.compose env40733 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound40733 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env40734 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,23589,1024,29828,4112,29860,153,138,8328,17,10508,16401,17801,32161,20484,8493,256,169,5513,22273]

theorem envBound40734 : H12AffineFastState.Bounded env40734 := by
  intro p hp
  have h : env40734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40733_40734 : H12AffineEnvironment.transform 15 8322 env40733 = env40734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env40733 == env40734) = true)

theorem identity40734 : scanCanonicalize (H12AffineFastState.compose env40734 (packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound40734 : packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env40735 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1172,16384,20497,1046,5528,23589,1024,20496,4112,20528,153,138,1052,17,3480,16401,17801,22837,20484,1465,256,169,5513,22273]

theorem envBound40735 : H12AffineFastState.Bounded env40735 := by
  intro p hp
  have h : env40735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40734_40735 : H12AffineEnvironment.transform 12 1172 env40734 = env40735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env40734 == env40735) = true)

theorem identity40735 : scanCanonicalize (H12AffineFastState.compose env40735 (packedSelected [0,1,2,5,6,7,10,14,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40735 : packedSelected [0,1,2,5,6,7,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env40736 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,388,16384,20497,262,4232,22837,272,20496,4112,20528,153,138,268,17,2184,16401,16537,22837,20484,169,256,169,4249,21009]

theorem envBound40736 : H12AffineFastState.Bounded env40736 := by
  intro p hp
  have h : env40736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40735_40736 : H12AffineEnvironment.transform 9 272 env40735 = env40736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40735 == env40736) = true)

theorem identity40736 : scanCanonicalize (H12AffineFastState.compose env40736 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound40736 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env40737 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,388,4541,428,262,4232,2184,272,429,4112,397,153,138,268,17,2184,4524,4388,2184,441,169,256,169,4249,940]

theorem envBound40737 : H12AffineFastState.Bounded env40737 := by
  intro p hp
  have h : env40737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40736_40737 : H12AffineEnvironment.transform 13 4541 env40736 = env40737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env40736 == env40737) = true)

theorem identity40737 : scanCanonicalize (H12AffineFastState.compose env40737 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound40737 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40738 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,293,388,152,428,262,429,2184,272,429,309,397,153,138,268,17,2184,137,1,2184,441,169,256,169,444,940]

theorem envBound40738 : H12AffineFastState.Bounded env40738 := by
  intro p hp
  have h : env40738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40737_40738 : H12AffineEnvironment.transform 11 293 env40737 = env40738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env40737 == env40738) = true)

def env40739 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149948,1024,29829,4113,155965,73755,136466,8328,16,10509,226571,91403,89379,148893,65966,256,136497,131088,221723]

theorem envBound40739 : H12AffineFastState.Bounded env40739 := by
  intro p hp
  have h : env40739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40731_40739 : H12AffineEnvironment.transform 5 17 env40731 = env40739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40731 == env40739) = true)

theorem identity40739 : scanCanonicalize (H12AffineFastState.compose env40739 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40739 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env40740 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,131072,149812,1024,29709,4113,155965,73755,136466,8192,16,10509,226571,91403,89379,148757,65830,256,136497,131088,221723]

theorem envBound40740 : H12AffineFastState.Bounded env40740 := by
  intro p hp
  have h : env40740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40739_40740 : H12AffineEnvironment.transform 6 8 env40739 = env40740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40739 == env40740) = true)

theorem identity40740 : scanCanonicalize (H12AffineFastState.compose env40740 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound40740 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env40741 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,13624,31756,1024,29709,4113,21509,73755,8234,8192,16,10509,81971,91403,89379,28717,65830,256,8201,13608,87843]

theorem envBound40741 : H12AffineFastState.Bounded env40741 := by
  intro p hp
  have h : env40741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40740_40741 : H12AffineEnvironment.transform 16 13624 env40740 = env40741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env40740 == env40741) = true)

theorem identity40741 : scanCanonicalize (H12AffineFastState.compose env40741 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,18,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound40741 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,18,20,24] rootPS < 2^1333 := by decide +kernel

def env40742 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,29963,13624,31756,1024,29709,4113,21509,21776,8234,8192,16,10509,13624,4096,10280,28717,29741,256,8201,13608,8744]

theorem envBound40742 : H12AffineFastState.Bounded env40742 := by
  intro p hp
  have h : env40742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40741_40742 : H12AffineEnvironment.transform 15 29963 env40741 = env40742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env40741 == env40742) = true)

theorem identity40742 : scanCanonicalize (H12AffineFastState.compose env40742 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40742 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40743 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,16384,21541,21794,5393,23589,1024,21540,4113,21509,21776,3,41,16,2340,5393,4096,2049,20484,21508,256,32,5377,513]

theorem envBound40743 : H12AffineFastState.Bounded env40743 := by
  intro p hp
  have h : env40743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40742_40743 : H12AffineEnvironment.transform 12 41 env40742 = env40743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40742 == env40743) = true)

theorem identity40743 : scanCanonicalize (H12AffineFastState.compose env40743 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40743 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40744 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21541,21510,5173,23589,1024,21540,4113,21509,21556,3,41,16,2048,5173,4096,2049,20484,21508,36,32,5157,513]

theorem envBound40744 : H12AffineFastState.Bounded env40744 := by
  intro p hp
  have h : env40744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40743_40744 : H12AffineEnvironment.transform 7 36 env40743 = env40744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40743 == env40744) = true)

theorem identity40744 : scanCanonicalize (H12AffineFastState.compose env40744 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound40744 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env40745 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,3124,6161,6194,5173,4113,1024,6160,4113,6193,6144,3,41,16,2048,5173,4096,2049,7216,6192,36,32,5157,513]

theorem envBound40745 : H12AffineFastState.Bounded env40745 := by
  intro p hp
  have h : env40745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40744_40745 : H12AffineEnvironment.transform 13 3124 env40744 = env40745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env40744 == env40745) = true)

theorem identity40745 : scanCanonicalize (H12AffineFastState.compose env40745 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40745 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40746 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,2049,6161,6194,4096,4113,53,6160,4113,6193,6144,3,41,16,2048,4096,4096,2049,6149,6192,36,32,4112,513]

theorem envBound40746 : H12AffineFastState.Bounded env40746 := by
  intro p hp
  have h : env40746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40745_40746 : H12AffineEnvironment.transform 9 53 env40745 = env40746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40745 == env40746) = true)

theorem identity40746 : scanCanonicalize (H12AffineFastState.compose env40746 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound40746 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env40747 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,16,41,2049,2049,2082,16,1,53,2048,1,2081,2064,3,41,16,2048,16,16,2049,2069,2080,36,32,0,513]

theorem envBound40747 : H12AffineFastState.Bounded env40747 := by
  intro p hp
  have h : env40747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40746_40747 : H12AffineEnvironment.transform 11 16 env40746 = env40747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env40746 == env40747) = true)

theorem identity40747 : scanCanonicalize (H12AffineFastState.compose env40747 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40747 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40748 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,16,41,0,0,35,16,1,53,1,1,32,17,3,41,16,1,16,16,0,20,33,36,32,0,513]

theorem envBound40748 : H12AffineFastState.Bounded env40748 := by
  intro p hp
  have h : env40748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40747_40748 : H12AffineEnvironment.transform 10 1 env40747 = env40748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40747 == env40748) = true)

def env40749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156012,120015,188871,8328,65,10588,226570,102878,109046,176408,128299,256,188900,131137,235215]

theorem envBound40749 : H12AffineFastState.Bounded env40749 := by
  intro p hp
  have h : env40749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40729_40749 : H12AffineEnvironment.transform 17 179513 env40729 = env40749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env40729 == env40749) = true)

theorem identity40749 : scanCanonicalize (H12AffineFastState.compose env40749 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40749 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122147,1024,32769,4161,65910,120015,98781,8328,65,10588,5392,102878,109046,119042,128299,256,98814,90203,63189]

theorem envBound40750 : H12AffineFastState.Bounded env40750 := by
  intro p hp
  have h : env40750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40749_40750 : H12AffineEnvironment.transform 16 90138 env40749 = env40750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40749 == env40750) = true)

def env40751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122147,1024,32769,4161,65910,119879,98645,8192,65,10588,5392,102742,108926,119042,128299,256,98678,90203,63069]

theorem envBound40751 : H12AffineFastState.Bounded env40751 := by
  intro p hp
  have h : env40751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40750_40751 : H12AffineEnvironment.transform 6 8 env40750 = env40751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40750 == env40751) = true)

theorem identity40751 : scanCanonicalize (H12AffineFastState.compose env40751 (packedSelected [4,5,9,12,15,16,19,24,35] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound40751 : packedSelected [4,5,9,12,15,16,19,24,35] rootPS < 2^1333 := by decide +kernel

def env40752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,65536,71011,108634,1024,32769,4161,65910,106814,98645,8192,65,10588,5392,102742,108926,107643,98386,256,98678,70946,33572]

theorem envBound40752 : H12AffineFastState.Bounded env40752 := by
  intro p hp
  have h : env40752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40751_40752 : H12AffineEnvironment.transform 13 13689 env40751 = env40752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env40751 == env40752) = true)

theorem identity40752 : scanCanonicalize (H12AffineFastState.compose env40752 (packedSelected [5,11,12,15,16,17,19,20,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound40752 : packedSelected [5,11,12,15,16,17,19,20,24,32] rootPS < 2^1333 := by decide +kernel

def env40753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8461,65536,71011,67927,1024,8460,4161,65910,65587,73816,8192,65,10588,5392,77915,67699,66934,74079,256,73851,70946,8745]

theorem envBound40753 : H12AffineFastState.Bounded env40753 := by
  intro p hp
  have h : env40753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40752_40753 : H12AffineEnvironment.transform 14 8461 env40752 = env40753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env40752 == env40753) = true)

theorem identity40753 : scanCanonicalize (H12AffineFastState.compose env40753 (packedSelected [3,5,10,12,15,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40753 : packedSelected [3,5,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env40754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8461,8202,13673,10589,1024,8460,4161,8572,8249,82,8192,65,10588,5392,4177,10361,9596,341,256,113,13608,8745]

theorem envBound40754 : H12AffineFastState.Bounded env40754 := by
  intro p hp
  have h : env40754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40753_40754 : H12AffineEnvironment.transform 15 8202 env40753 = env40754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40753 == env40754) = true)

theorem identity40754 : scanCanonicalize (H12AffineFastState.compose env40754 (packedSelected [0,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound40754 : packedSelected [0,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4160,1076,1331,4176,3172,1024,1077,4161,1093,1280,82,1337,65,3173,5392,4177,3392,69,341,256,113,4113,1808]

theorem envBound40755 : H12AffineFastState.Bounded env40755 := by
  intro p hp
  have h : env40755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40754_40755 : H12AffineEnvironment.transform 12 1337 env40754 = env40755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env40754 == env40755) = true)

theorem identity40755 : scanCanonicalize (H12AffineFastState.compose env40755 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40755 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40756 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,269,4160,0,263,4176,2128,52,1,4161,113,308,82,269,65,2129,4388,4177,2420,69,341,256,113,4113,804]

theorem envBound40756 : H12AffineFastState.Bounded env40756 := by
  intro p hp
  have h : env40756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40755_40756 : H12AffineEnvironment.transform 9 52 env40755 = env40756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40755 == env40756) = true)

theorem identity40756 : scanCanonicalize (H12AffineFastState.compose env40756 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40756 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40757 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,121,4160,0,115,4176,2128,52,1,4161,113,64,82,121,65,2129,4176,4177,2048,69,33,116,113,4113,592]

theorem envBound40757 : H12AffineFastState.Bounded env40757 := by
  intro p hp
  have h : env40757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40756_40757 : H12AffineEnvironment.transform 7 116 env40756 = env40757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40756 == env40757) = true)

theorem identity40757 : scanCanonicalize (H12AffineFastState.compose env40757 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound40757 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40758 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,4096,121,4160,0,115,4176,0,52,1,4161,113,64,82,121,65,1,4176,4177,80,69,33,116,113,4113,592]

theorem envBound40758 : H12AffineFastState.Bounded env40758 := by
  intro p hp
  have h : env40758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40757_40758 : H12AffineEnvironment.transform 10 80 env40757 = env40758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env40757 == env40758) = true)

theorem identity40758 : scanCanonicalize (H12AffineFastState.compose env40758 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound40758 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40759 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,65,121,1,0,115,17,0,52,1,0,113,64,82,121,65,1,17,16,80,69,33,116,113,80,592]

theorem envBound40759 : H12AffineFastState.Bounded env40759 := by
  intro p hp
  have h : env40759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40758_40759 : H12AffineEnvironment.transform 11 65 env40758 = env40759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env40758 == env40759) = true)

theorem identity40759 : scanCanonicalize (H12AffineFastState.compose env40759 (packedSelected [6,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40759 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env40760 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,17,41,1,0,35,17,0,52,1,0,33,16,2,41,17,1,17,16,0,21,33,36,33,0,512]

theorem envBound40760 : H12AffineFastState.Bounded env40760 := by
  intro p hp
  have h : env40760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40759_40760 : H12AffineEnvironment.transform 5 16 env40759 = env40760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40759 == env40760) = true)

theorem identity40760 : scanCanonicalize (H12AffineFastState.compose env40760 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound40760 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40761 : List Nat := [2,4,8,16,32,16,8,36,52,52,0,17,41,1,0,35,17,0,52,1,0,33,16,2,41,17,1,17,16,0,21,33,36,33,0,52]

theorem envBound40761 : H12AffineFastState.Bounded env40761 := by
  intro p hp
  have h : env40761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40760_40761 : H12AffineEnvironment.transform 8 52 env40760 = env40761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env40760 == env40761) = true)

theorem identity40761 : scanCanonicalize (H12AffineFastState.compose env40761 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound40761 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40762 : List Nat := [2,4,8,13,32,13,8,36,41,41,0,12,41,1,0,35,12,0,41,1,0,33,13,2,41,12,1,12,13,0,8,33,36,33,0,41]

theorem envBound40762 : H12AffineFastState.Bounded env40762 := by
  intro p hp
  have h : env40762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40761_40762 : H12AffineEnvironment.transform 3 13 env40761 = env40762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env40761 == env40762) = true)

theorem identity40762 : scanCanonicalize (H12AffineFastState.compose env40762 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40762 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40763 : List Nat := [0,4,8,13,32,13,8,36,41,41,0,12,41,1,0,33,12,0,41,1,0,33,13,0,41,12,1,12,13,0,8,33,36,33,0,41]

theorem envBound40763 : H12AffineFastState.Bounded env40763 := by
  intro p hp
  have h : env40763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40762_40763 : H12AffineEnvironment.transform 0 0 env40762 = env40763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40762 == env40763) = true)

theorem identity40763 : scanCanonicalize (H12AffineFastState.compose env40763 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound40763 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40764 : List Nat := [0,4,8,13,8,13,8,12,1,1,0,12,1,1,0,9,12,0,1,1,0,9,13,0,1,12,1,12,13,0,8,9,12,9,0,1]

theorem envBound40764 : H12AffineFastState.Bounded env40764 := by
  intro p hp
  have h : env40764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40763_40764 : H12AffineEnvironment.transform 4 8 env40763 = env40764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env40763 == env40764) = true)

theorem identity40764 : scanCanonicalize (H12AffineFastState.compose env40764 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40764 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40765 : List Nat := [0,1,8,8,8,8,8,9,1,1,0,9,1,1,0,9,9,0,1,1,0,9,8,0,1,9,1,9,8,0,8,9,9,9,0,1]

theorem envBound40765 : H12AffineFastState.Bounded env40765 := by
  intro p hp
  have h : env40765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40764_40765 : H12AffineEnvironment.transform 1 1 env40764 = env40765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40764 == env40765) = true)

theorem identity40765 : scanCanonicalize (H12AffineFastState.compose env40765 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound40765 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40766 : List Nat := [0,1,1,1,1,1,1,0,1,1,0,0,1,1,0,0,0,0,1,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,1]

theorem envBound40766 : H12AffineFastState.Bounded env40766 := by
  intro p hp
  have h : env40766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40765_40766 : H12AffineEnvironment.transform 2 1 env40765 = env40766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env40765 == env40766) = true)

def env40767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122147,1024,32769,4161,65910,119878,98644,8193,65,10588,5392,102743,108927,119042,128299,256,98679,90203,63068]

theorem envBound40767 : H12AffineFastState.Bounded env40767 := by
  intro p hp
  have h : env40767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40750_40767 : H12AffineEnvironment.transform 6 9 env40750 = env40767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40750 == env40767) = true)

theorem identity40767 : scanCanonicalize (H12AffineFastState.compose env40767 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound40767 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,76158,1024,29788,4161,65910,73755,95497,8193,65,10588,5392,91402,89378,75103,65910,256,95530,90203,513]

theorem envBound40768 : H12AffineFastState.Bounded env40768 := by
  intro p hp
  have h : env40768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40767_40768 : H12AffineEnvironment.transform 14 29789 env40767 = env40768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env40767 == env40768) = true)

theorem identity40768 : scanCanonicalize (H12AffineFastState.compose env40768 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40768 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env40769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,65536,82247,67619,1024,21761,4161,65910,65862,87124,348,65,2049,5392,83031,89378,66562,65910,256,87159,82182,513]

theorem envBound40769 : H12AffineFastState.Bounded env40769 := by
  intro p hp
  have h : env40769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40768_40769 : H12AffineEnvironment.transform 12 349 env40768 = env40769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40768 == env40769) = true)

theorem identity40769 : scanCanonicalize (H12AffineFastState.compose env40769 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound40769 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,342,16401,2421,1024,21761,4161,32,16,21762,348,65,2049,5392,17665,23668,1364,32,256,21793,16464,513]

theorem envBound40770 : H12AffineFastState.Bounded env40770 := by
  intro p hp
  have h : env40770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40769_40770 : H12AffineEnvironment.transform 15 342 env40769 = env40770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env40769 == env40770) = true)

theorem identity40770 : scanCanonicalize (H12AffineFastState.compose env40770 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40770 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40771 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,16384,20497,342,16401,2421,273,20496,4161,32,16,20499,348,65,2049,4097,16400,22885,69,32,256,20528,16464,513]

theorem envBound40771 : H12AffineFastState.Bounded env40771 := by
  intro p hp
  have h : env40771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40770_40771 : H12AffineEnvironment.transform 9 273 env40770 = env40771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40770 == env40771) = true)

theorem identity40771 : scanCanonicalize (H12AffineFastState.compose env40771 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound40771 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env40772 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2356,349,16384,18725,342,16401,2421,273,18724,2421,32,16,18727,348,65,2049,2357,16400,16465,69,32,256,18692,16464,513]

theorem envBound40772 : H12AffineFastState.Bounded env40772 := by
  intro p hp
  have h : env40772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40771_40772 : H12AffineEnvironment.transform 11 2356 env40771 = env40772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env40771 == env40772) = true)

theorem identity40772 : scanCanonicalize (H12AffineFastState.compose env40772 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound40772 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env40773 : List Nat := [2,4,8,16,32,64,9,256,97,273,2048,2356,349,16384,18725,342,16401,2421,273,18724,2421,32,16,18727,348,65,2049,2357,16400,16465,69,32,256,18692,16464,96]

theorem envBound40773 : H12AffineFastState.Bounded env40773 := by
  intro p hp
  have h : env40773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40772_40773 : H12AffineEnvironment.transform 8 97 env40772 = env40773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env40772 == env40773) = true)

theorem identity40773 : scanCanonicalize (H12AffineFastState.compose env40773 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 373) := by decide +kernel

theorem selectedBound40773 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env40774 : List Nat := [2,4,8,16,32,64,9,256,97,273,2048,2356,349,373,2128,342,356,2421,273,2129,2421,32,16,2130,348,65,2049,2357,357,292,69,32,256,2161,293,96]

theorem envBound40774 : H12AffineFastState.Bounded env40774 := by
  intro p hp
  have h : env40774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40773_40774 : H12AffineEnvironment.transform 13 373 env40773 = env40774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 373 env40773 == env40774) = true)

theorem identity40774 : scanCanonicalize (H12AffineFastState.compose env40774 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40774 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40775 : List Nat := [2,4,8,16,32,16,9,256,49,273,2048,2356,269,293,2048,262,308,2341,273,2049,2341,32,16,2050,268,17,2049,2357,309,292,21,32,256,2081,293,48]

theorem envBound40775 : H12AffineFastState.Bounded env40775 := by
  intro p hp
  have h : env40775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40774_40775 : H12AffineEnvironment.transform 5 16 env40774 = env40775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40774 == env40775) = true)

theorem identity40775 : scanCanonicalize (H12AffineFastState.compose env40775 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound40775 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40776 : List Nat := [2,4,8,16,32,16,9,256,49,273,309,1,269,293,309,262,308,16,273,308,16,32,16,311,268,17,308,0,309,292,21,32,256,276,293,48]

theorem envBound40776 : H12AffineFastState.Bounded env40776 := by
  intro p hp
  have h : env40776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40775_40776 : H12AffineEnvironment.transform 10 309 env40775 = env40776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env40775 == env40776) = true)

theorem identity40776 : scanCanonicalize (H12AffineFastState.compose env40776 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40776 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40777 : List Nat := [2,4,8,16,32,16,9,4,49,21,49,1,9,33,49,2,48,16,21,48,16,32,16,51,8,17,48,0,49,32,21,32,4,16,33,48]

theorem envBound40777 : H12AffineFastState.Bounded env40777 := by
  intro p hp
  have h : env40777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40776_40777 : H12AffineEnvironment.transform 7 4 env40776 = env40777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40776 == env40777) = true)

theorem identity40777 : scanCanonicalize (H12AffineFastState.compose env40777 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40777 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40778 : List Nat := [2,4,8,16,16,16,9,4,1,21,1,1,9,17,1,2,0,16,21,0,16,16,16,3,8,17,0,0,1,16,21,16,4,16,17,0]

theorem envBound40778 : H12AffineFastState.Bounded env40778 := by
  intro p hp
  have h : env40778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40777_40778 : H12AffineEnvironment.transform 4 16 env40777 = env40778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40777 == env40778) = true)

theorem identity40778 : scanCanonicalize (H12AffineFastState.compose env40778 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40779 : List Nat := [2,4,2,16,16,16,3,4,1,21,1,1,3,17,1,2,0,16,21,0,16,16,16,3,2,17,0,0,1,16,21,16,4,16,17,0]

theorem envBound40779 : H12AffineFastState.Bounded env40779 := by
  intro p hp
  have h : env40779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40778_40779 : H12AffineEnvironment.transform 2 2 env40778 = env40779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40778 == env40779) = true)

theorem identity40779 : scanCanonicalize (H12AffineFastState.compose env40779 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40780 : List Nat := [2,4,2,1,1,1,3,4,1,4,1,1,3,0,1,2,0,1,4,0,1,1,1,3,2,0,0,0,1,1,4,1,4,1,0,0]

theorem envBound40780 : H12AffineFastState.Bounded env40780 := by
  intro p hp
  have h : env40780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40779_40780 : H12AffineEnvironment.transform 3 1 env40779 = env40780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40779 == env40780) = true)

def env40781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485878,16777216,8328,65,16959643,17246709,102879,109046,17231334,17148372,256,16777250,16834951,17287729]

theorem envBound40781 : H12AffineFastState.Bounded env40781 := by
  intro p hp
  have h : env40781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40727_40781 : H12AffineEnvironment.transform 20 437625 env40727 = env40781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env40727 == env40781) = true)

def env40782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485878,510000,8328,65,327851,57797,102879,109046,75222,156132,256,509970,469431,513]

theorem envBound40782 : H12AffineFastState.Bounded env40782 := by
  intro p hp
  have h : env40782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40781_40782 : H12AffineEnvironment.transform 23 510000 env40781 = env40782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510000 env40781 == env40782) = true)

def env40783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485758,510000,8192,65,327715,57677,102743,108926,75102,156012,256,509970,469311,513]

theorem envBound40783 : H12AffineFastState.Bounded env40783 := by
  intro p hp
  have h : env40783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40782_40783 : H12AffineEnvironment.transform 6 8 env40782 = env40783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40782 == env40783) = true)

theorem identity40783 : scanCanonicalize (H12AffineFastState.compose env40783 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40783 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,380259,65910,264548,305194,8192,65,327715,57677,102743,108926,75102,65910,256,305160,280869,513]

theorem envBound40784 : H12AffineFastState.Bounded env40784 := by
  intro p hp
  have h : env40784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40783_40784 : H12AffineEnvironment.transform 16 90138 env40783 = env40784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40783 == env40784) = true)

theorem identity40784 : scanCanonicalize (H12AffineFastState.compose env40784 (packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound40784 : packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env40785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,65536,77915,262144,1024,32769,367906,65910,264548,305194,8192,65,327715,45324,102743,108926,75102,65910,256,305160,268644,513]

theorem envBound40785 : H12AffineFastState.Bounded env40785 := by
  intro p hp
  have h : env40785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40784_40785 : H12AffineEnvironment.transform 13 4161 env40784 = env40785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env40784 == env40785) = true)

theorem identity40785 : scanCanonicalize (H12AffineFastState.compose env40785 (packedSelected [0,7,8,10,17,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound40785 : packedSelected [0,7,8,10,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env40786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,65536,77915,67699,1024,32769,38225,65910,65815,106585,8192,65,2128,45324,102743,108926,75102,65910,256,106619,69911,513]

theorem envBound40786 : H12AffineFastState.Bounded env40786 := by
  intro p hp
  have h : env40786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40785_40786 : H12AffineEnvironment.transform 17 67699 env40785 = env40786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env40785 == env40786) = true)

theorem identity40786 : scanCanonicalize (H12AffineFastState.compose env40786 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound40786 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env40787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,33030,45405,35189,1024,32769,38225,32880,32785,8543,8192,65,2128,45324,4177,10360,42072,32880,256,8573,36881,513]

theorem envBound40787 : H12AffineFastState.Bounded env40787 := by
  intro p hp
  have h : env40787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40786_40787 : H12AffineEnvironment.transform 15 33030 env40786 = env40787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env40786 == env40787) = true)

theorem identity40787 : scanCanonicalize (H12AffineFastState.compose env40787 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40787 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env40788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,0,262,12637,2421,1024,1,5457,112,17,8543,8192,65,2128,12556,4177,10360,9304,112,256,8573,4113,513]

theorem envBound40788 : H12AffineFastState.Bounded env40788 := by
  intro p hp
  have h : env40788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40787_40788 : H12AffineEnvironment.transform 14 0 env40787 = env40788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40787 == env40788) = true)

theorem identity40788 : scanCanonicalize (H12AffineFastState.compose env40788 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40788 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4161,0,262,4096,2421,1024,1,5457,112,17,2,349,65,2128,4177,4177,2341,1285,112,256,32,4113,513]

theorem envBound40789 : H12AffineFastState.Bounded env40789 := by
  intro p hp
  have h : env40789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40788_40789 : H12AffineEnvironment.transform 12 349 env40788 = env40789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40788 == env40789) = true)

theorem identity40789 : scanCanonicalize (H12AffineFastState.compose env40789 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40789 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40790 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4112,0,262,4096,2340,1024,1,5376,33,17,2,268,16,2049,4096,4096,2341,1285,33,256,32,4113,513]

theorem envBound40790 : H12AffineFastState.Bounded env40790 := by
  intro p hp
  have h : env40790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40789_40790 : H12AffineEnvironment.transform 5 17 env40789 = env40790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40789 == env40790) = true)

theorem identity40790 : scanCanonicalize (H12AffineFastState.compose env40790 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40790 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40791 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,4112,0,262,4096,2340,272,1,4112,33,17,2,268,16,2049,4096,4096,2341,21,33,256,32,4113,513]

theorem envBound40791 : H12AffineFastState.Bounded env40791 := by
  intro p hp
  have h : env40791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40790_40791 : H12AffineEnvironment.transform 9 272 env40790 = env40791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40790 == env40791) = true)

def env40792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485759,510000,8193,65,327714,57676,102742,108927,75103,156013,256,509970,469310,513]

theorem envBound40792 : H12AffineFastState.Bounded env40792 := by
  intro p hp
  have h : env40792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40782_40792 : H12AffineEnvironment.transform 6 9 env40782 = env40792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40782 == env40792) = true)

theorem identity40792 : scanCanonicalize (H12AffineFastState.compose env40792 (packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40792 : packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env40793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,396324,156012,485759,485741,8193,65,327714,16401,77835,67618,75103,156013,256,485711,469310,513]

theorem envBound40793 : H12AffineFastState.Bounded env40793 := by
  intro p hp
  have h : env40793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40792_40793 : H12AffineEnvironment.transform 14 8541 env40792 = env40793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40792 == env40793) = true)

theorem identity40793 : scanCanonicalize (H12AffineFastState.compose env40793 (packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound40793 : packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,215091,1024,8540,82967,156012,8524,8542,8193,65,149521,16401,77835,67618,75103,156013,256,8572,24845,513]

theorem envBound40794 : H12AffineFastState.Bounded env40794 := by
  intro p hp
  have h : env40794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40793_40794 : H12AffineEnvironment.transform 17 215091 env40793 = env40794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env40793 == env40794) = true)

theorem identity40794 : scanCanonicalize (H12AffineFastState.compose env40794 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound40794 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env40795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1024,8540,82967,65910,8524,8542,8193,65,75787,16401,77835,67618,75103,65911,256,8572,24845,513]

theorem envBound40795 : H12AffineFastState.Bounded env40795 := by
  intro p hp
  have h : env40795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40794_40795 : H12AffineEnvironment.transform 16 90138 env40794 = env40795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env40794 == env40795) = true)

theorem identity40795 : scanCanonicalize (H12AffineFastState.compose env40795 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40795 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,65536,82246,2421,1024,0,82967,65910,16,2,349,65,67927,16401,69975,67618,66563,65911,256,32,16465,513]

theorem envBound40796 : H12AffineFastState.Bounded env40796 := by
  intro p hp
  have h : env40796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40795_40796 : H12AffineEnvironment.transform 12 348 env40795 = env40796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40795 == env40796) = true)

def env40797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485878,510001,8328,65,327850,57796,102879,109046,75223,156133,256,509971,469430,512]

theorem envBound40797 : H12AffineFastState.Bounded env40797 := by
  intro p hp
  have h : env40797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40781_40797 : H12AffineEnvironment.transform 23 510001 env40781 = env40797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510001 env40781 == env40797) = true)

theorem identity40797 : scanCanonicalize (H12AffineFastState.compose env40797 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound40797 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,120014,95497,8328,65,245138,57796,102879,109046,75223,156133,256,95531,103566,512]

theorem envBound40798 : H12AffineFastState.Bounded env40798 := by
  intro p hp
  have h : env40798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40797_40798 : H12AffineEnvironment.transform 17 179512 env40797 = env40798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env40797 == env40798) = true)

theorem identity40798 : scanCanonicalize (H12AffineFastState.compose env40798 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103630) := by decide +kernel

theorem selectedBound40798 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103630,76278,1024,32769,4161,128418,120014,95497,8328,65,10588,57796,102879,109046,75223,128299,256,95531,103566,512]

theorem envBound40799 : H12AffineFastState.Bounded env40799 := by
  intro p hp
  have h : env40799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40798_40799 : H12AffineEnvironment.transform 16 103630 env40798 = env40799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103630 env40798 == env40799) = true)

theorem identity40799 : scanCanonicalize (H12AffineFastState.compose env40799 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound40799 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16401,64809,1024,32769,4161,8573,17,41430,8328,65,10588,57796,17664,32041,61704,8692,256,41460,16465,512]

theorem envBound40800 : H12AffineFastState.Bounded env40800 := by
  intro p hp
  have h : env40800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40799_40800 : H12AffineEnvironment.transform 15 54495 env40799 = env40800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env40799 == env40800) = true)

theorem identity40800 : scanCanonicalize (H12AffineFastState.compose env40800 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40800 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,32768,54495,16401,56577,1024,32769,4161,341,17,33278,160,65,2420,49644,17664,23809,53536,476,256,33244,16465,512]

theorem envBound40801 : H12AffineFastState.Bounded env40801 := by
  intro p hp
  have h : env40801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40800_40801 : H12AffineEnvironment.transform 12 40 env40800 = env40801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40800 == env40801) = true)

theorem identity40801 : scanCanonicalize (H12AffineFastState.compose env40801 (packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound40801 : packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env40802 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,40,16384,32768,54495,16401,56405,1024,32769,4161,1,17,32938,160,65,2080,49336,17492,23637,53364,136,84,32904,16465,512]

theorem envBound40802 : H12AffineFastState.Bounded env40802 := by
  intro p hp
  have h : env40802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40801_40802 : H12AffineEnvironment.transform 7 84 env40801 = env40802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env40801 == env40802) = true)

theorem identity40802 : scanCanonicalize (H12AffineFastState.compose env40802 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound40802 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env40803 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,40,16384,168,21623,16401,23805,1024,169,4161,1,17,2,160,65,2080,16400,17492,23637,20700,136,84,32,16465,512]

theorem envBound40803 : H12AffineFastState.Bounded env40803 := by
  intro p hp
  have h : env40803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40802_40803 : H12AffineEnvironment.transform 14 168 env40802 = env40803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env40802 == env40803) = true)

theorem identity40803 : scanCanonicalize (H12AffineFastState.compose env40803 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40803 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40804 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,40,16384,33,21623,16401,23668,1024,32,4161,1,17,2,41,65,2080,16400,17492,23637,20565,1,84,32,16465,512]

theorem envBound40804 : H12AffineFastState.Bounded env40804 := by
  intro p hp
  have h : env40804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40803_40804 : H12AffineEnvironment.transform 6 9 env40803 = env40804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40803 == env40804) = true)

theorem identity40804 : scanCanonicalize (H12AffineFastState.compose env40804 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40804 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40805 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,40,16384,33,21542,16401,23589,1024,32,4112,1,17,2,41,16,2080,16400,17413,23556,20484,1,5,32,16384,512]

theorem envBound40805 : H12AffineFastState.Bounded env40805 := by
  intro p hp
  have h : env40805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40804_40805 : H12AffineEnvironment.transform 5 17 env40804 = env40805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40804 == env40805) = true)

theorem identity40805 : scanCanonicalize (H12AffineFastState.compose env40805 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound40805 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40806 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,40,5125,33,35,5140,2080,1024,32,4112,1,17,2,41,16,2080,5141,4096,2049,1025,1,5,32,5125,512]

theorem envBound40806 : H12AffineFastState.Bounded env40806 := by
  intro p hp
  have h : env40806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40805_40806 : H12AffineEnvironment.transform 13 5125 env40805 = env40806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env40805 == env40806) = true)

theorem identity40806 : scanCanonicalize (H12AffineFastState.compose env40806 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound40806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40807 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,1061,40,32,33,35,49,2080,1024,32,1077,1,17,2,41,16,2080,48,1061,2049,1025,1,5,32,32,512]

theorem envBound40807 : H12AffineFastState.Bounded env40807 := by
  intro p hp
  have h : env40807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40806_40807 : H12AffineEnvironment.transform 11 1061 env40806 = env40807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env40806 == env40807) = true)

theorem identity40807 : scanCanonicalize (H12AffineFastState.compose env40807 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 46) := by decide +kernel

theorem selectedBound40807 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env40808 : List Nat := [2,4,8,16,32,17,9,5,512,1024,46,1061,40,32,33,35,49,14,1024,32,1077,1,17,2,41,16,14,48,1061,47,1025,1,5,32,32,512]

theorem envBound40808 : H12AffineFastState.Bounded env40808 := by
  intro p hp
  have h : env40808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40807_40808 : H12AffineEnvironment.transform 10 46 env40807 = env40808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 46 env40807 == env40808) = true)

theorem identity40808 : scanCanonicalize (H12AffineFastState.compose env40808 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound40808 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40809 : List Nat := [2,4,8,16,32,17,9,5,37,1024,46,1061,40,32,33,35,49,14,1024,32,1077,1,17,2,41,16,14,48,1061,47,1025,1,5,32,32,37]

theorem envBound40809 : H12AffineFastState.Bounded env40809 := by
  intro p hp
  have h : env40809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40808_40809 : H12AffineEnvironment.transform 8 37 env40808 = env40809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env40808 == env40809) = true)

theorem identity40809 : scanCanonicalize (H12AffineFastState.compose env40809 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound40809 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40810 : List Nat := [2,4,8,16,14,17,9,5,11,1024,0,1035,6,14,15,13,31,14,1024,14,1051,1,17,2,7,16,14,30,1035,1,1025,1,5,14,14,11]

theorem envBound40810 : H12AffineFastState.Bounded env40810 := by
  intro p hp
  have h : env40810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40809_40810 : H12AffineEnvironment.transform 4 14 env40809 = env40810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env40809 == env40810) = true)

theorem identity40810 : scanCanonicalize (H12AffineFastState.compose env40810 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 12) := by decide +kernel

theorem selectedBound40810 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40811 : List Nat := [2,4,8,16,14,17,9,5,11,12,0,7,6,14,15,13,31,14,12,14,23,1,17,2,7,16,14,30,7,1,13,1,5,14,14,11]

theorem envBound40811 : H12AffineFastState.Bounded env40811 := by
  intro p hp
  have h : env40811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40810_40811 : H12AffineEnvironment.transform 9 12 env40810 = env40811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env40810 == env40811) = true)

theorem identity40811 : scanCanonicalize (H12AffineFastState.compose env40811 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound40811 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env40812 : List Nat := [2,4,8,9,14,8,9,5,11,12,0,7,6,14,15,13,6,14,12,14,14,1,8,2,7,9,14,7,7,1,13,1,5,14,14,11]

theorem envBound40812 : H12AffineFastState.Bounded env40812 := by
  intro p hp
  have h : env40812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40811_40812 : H12AffineEnvironment.transform 3 9 env40811 = env40812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env40811 == env40812) = true)

theorem identity40812 : scanCanonicalize (H12AffineFastState.compose env40812 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound40812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40813 : List Nat := [2,4,7,6,1,7,6,5,4,3,0,7,6,1,0,2,6,1,3,1,1,1,7,2,7,6,1,7,7,1,2,1,5,1,1,4]

theorem envBound40813 : H12AffineFastState.Bounded env40813 := by
  intro p hp
  have h : env40813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40812_40813 : H12AffineEnvironment.transform 2 7 env40812 = env40813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env40812 == env40813) = true)

def env40814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156013,485878,16777216,8328,65,16959642,18973836,2571430,109046,17231334,19072172,256,19311963,19287294,17287729]

theorem envBound40814 : H12AffineFastState.Bounded env40814 := by
  intro p hp
  have h : env40814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40726_40814 : H12AffineEnvironment.transform 21 156013 env40726 = env40814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env40726 == env40814) = true)

def env40815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485878,16777216,8328,65,16959642,17246708,102878,109046,17231334,17148372,256,16777251,16834950,17287729]

theorem envBound40815 : H12AffineFastState.Bounded env40815 := by
  intro p hp
  have h : env40815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40814_40815 : H12AffineEnvironment.transform 20 437624 env40814 = env40815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env40814 == env40815) = true)

theorem identity40815 : scanCanonicalize (H12AffineFastState.compose env40815 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362529) := by decide +kernel

theorem selectedBound40815 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env40816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485878,362529,8328,65,475323,172501,102878,109046,222663,8693,256,362498,354727,147984]

theorem envBound40816 : H12AffineFastState.Bounded env40816 := by
  intro p hp
  have h : env40816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40815_40816 : H12AffineEnvironment.transform 23 362529 env40815 = env40816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362529 env40815 == env40816) = true)

def env40817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,322920,8573,338406,362529,8328,65,327851,57797,102878,109046,75223,8693,256,362498,354727,512]

theorem envBound40817 : H12AffineFastState.Bounded env40817 := by
  intro p hp
  have h : env40817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40816_40817 : H12AffineEnvironment.transform 16 16400 env40816 = env40817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40816 == env40817) = true)

end H12CloudChart0