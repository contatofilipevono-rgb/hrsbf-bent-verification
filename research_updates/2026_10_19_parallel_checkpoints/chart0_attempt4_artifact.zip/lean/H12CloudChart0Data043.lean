import H12CloudChart0Data042

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env10738 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,1,8,17,0,3,1,2048,21,1,16,0,17,3,8,16,2048,1,1,2048,21,0,5,1,17,1]

theorem envBound10738 : H12AffineFastState.Bounded env10738 := by
  intro p hp
  have h : env10738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10737_10738 : H12AffineEnvironment.transform 9 20 env10737 = env10738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10737 == env10738) = true)

theorem identity10738 : scanCanonicalize (H12AffineFastState.compose env10738 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound10738 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10739 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,8,17,0,3,1,1,21,1,16,0,17,3,8,16,1,1,1,1,21,0,5,1,17,1]

theorem envBound10739 : H12AffineFastState.Bounded env10739 := by
  intro p hp
  have h : env10739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10738_10739 : H12AffineEnvironment.transform 10 1 env10738 = env10739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10738 == env10739) = true)

def env10740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,2155581,2212870,2188617,8192,65,2223434,57676,102743,2190398,75103,2155580,257,2188650,2196551,513]

theorem envBound10740 : H12AffineFastState.Bounded env10740 := by
  intro p hp
  have h : env10740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10726_10740 : H12AffineEnvironment.transform 17 10281 env10726 = env10740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10726 == env10740) = true)

theorem identity10740 : scanCanonicalize (H12AffineFastState.compose env10740 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10740 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,2097152,2155581,2155533,2114882,8192,65,2149697,57676,45404,2116661,1364,2155580,257,2114913,2139212,513]

theorem envBound10741 : H12AffineFastState.Bounded env10741 := by
  intro p hp
  have h : env10741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10740_10741 : H12AffineEnvironment.transform 15 8203 env10740 = env10741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10740 == env10741) = true)

theorem identity10741 : scanCanonicalize (H12AffineFastState.compose env10741 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound10741 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16400,10281,1025,29005,2097152,2102641,2102593,2114882,8192,65,2112525,4096,16400,2116661,1364,2102640,257,2114913,2118912,513]

theorem envBound10742 : H12AffineFastState.Bounded env10742 := by
  intro p hp
  have h : env10742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10741_10742 : H12AffineEnvironment.transform 14 29004 env10741 = env10742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env10741 == env10742) = true)

theorem identity10742 : scanCanonicalize (H12AffineFastState.compose env10742 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 11625) := by decide +kernel

theorem selectedBound10742 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env10743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16400,10281,1025,29005,11625,14360,14376,26667,8192,65,4452,4096,16400,24924,1364,14361,257,26632,30825,513]

theorem envBound10743 : H12AffineFastState.Bounded env10743 := by
  intro p hp
  have h : env10743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10742_10743 : H12AffineEnvironment.transform 20 11625 env10742 = env10743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11625 env10742 == env10743) = true)

theorem identity10743 : scanCanonicalize (H12AffineFastState.compose env10743 (packedSelected [11,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound10743 : packedSelected [11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env10744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,23808,3143,16400,1125,1025,23809,293,5204,5220,17511,3148,65,4452,4096,16400,19728,1364,5205,257,17476,21541,513]

theorem envBound10744 : H12AffineFastState.Bounded env10744 := by
  intro p hp
  have h : env10744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10743_10744 : H12AffineEnvironment.transform 12 3148 env10743 = env10744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env10743 == env10744) = true)

theorem identity10744 : scanCanonicalize (H12AffineFastState.compose env10744 (packedSelected [21] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound10744 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,16384,18805,3143,16400,1125,1025,18804,293,33,17,17511,3148,65,1297,1141,16400,19728,1364,32,257,17476,16464,513]

theorem envBound10745 : H12AffineFastState.Bounded env10745 := by
  intro p hp
  have h : env10745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10744_10745 : H12AffineEnvironment.transform 11 1141 env10744 = env10745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env10744 == env10745) = true)

theorem identity10745 : scanCanonicalize (H12AffineFastState.compose env10745 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound10745 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,2129,292,3143,2113,1125,1025,293,293,33,17,3126,3148,65,1297,1141,2113,1345,1364,32,257,3093,2049,513]

theorem envBound10746 : H12AffineFastState.Bounded env10746 := by
  intro p hp
  have h : env10746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10745_10746 : H12AffineEnvironment.transform 13 2129 env10745 = env10746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env10745 == env10746) = true)

theorem identity10746 : scanCanonicalize (H12AffineFastState.compose env10746 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound10746 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env10747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,561,1141,1661,608,292,1654,624,1125,1025,293,293,33,17,1543,1661,65,1297,1141,624,1345,1364,32,257,1572,560,513]

theorem envBound10747 : H12AffineFastState.Bounded env10747 := by
  intro p hp
  have h : env10747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10746_10747 : H12AffineEnvironment.transform 10 561 env10746 = env10747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env10746 == env10747) = true)

theorem identity10747 : scanCanonicalize (H12AffineFastState.compose env10747 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound10747 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env10748 : List Nat := [2,4,8,16,32,64,8,256,512,336,561,293,813,608,292,806,624,309,337,293,293,33,17,855,813,65,65,293,624,17,4,32,257,884,560,513]

theorem envBound10748 : H12AffineFastState.Bounded env10748 := by
  intro p hp
  have h : env10748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10747_10748 : H12AffineEnvironment.transform 9 336 env10747 = env10748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env10747 == env10748) = true)

theorem identity10748 : scanCanonicalize (H12AffineFastState.compose env10748 (packedSelected [0,1,3,4,5,6,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound10748 : packedSelected [0,1,3,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env10749 : List Nat := [2,4,8,16,32,64,8,100,512,52,561,65,585,608,64,578,624,81,53,65,65,33,17,563,585,65,65,65,624,17,4,32,101,528,560,513]

theorem envBound10749 : H12AffineFastState.Bounded env10749 := by
  intro p hp
  have h : env10749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10748_10749 : H12AffineEnvironment.transform 7 100 env10748 = env10749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env10748 == env10749) = true)

theorem identity10749 : scanCanonicalize (H12AffineFastState.compose env10749 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10749 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env10750 : List Nat := [2,4,8,16,32,16,8,52,512,52,561,17,537,560,16,530,544,1,53,17,17,33,17,563,537,17,17,17,544,17,4,32,53,528,560,513]

theorem envBound10750 : H12AffineFastState.Bounded env10750 := by
  intro p hp
  have h : env10750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10749_10750 : H12AffineEnvironment.transform 5 16 env10749 = env10750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10749 == env10750) = true)

theorem identity10750 : scanCanonicalize (H12AffineFastState.compose env10750 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound10750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10751 : List Nat := [2,4,8,16,32,16,8,52,17,52,32,17,8,33,16,3,49,1,53,17,17,33,17,34,8,17,17,17,49,17,4,32,53,1,33,16]

theorem envBound10751 : H12AffineFastState.Bounded env10751 := by
  intro p hp
  have h : env10751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10750_10751 : H12AffineEnvironment.transform 8 17 env10750 = env10751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env10750 == env10751) = true)

theorem identity10751 : scanCanonicalize (H12AffineFastState.compose env10751 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10751 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env10752 : List Nat := [2,4,8,0,32,0,8,36,1,36,32,1,8,33,0,3,33,1,37,1,1,33,1,34,8,1,1,1,33,1,4,32,37,1,33,0]

theorem envBound10752 : H12AffineFastState.Bounded env10752 := by
  intro p hp
  have h : env10752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10751_10752 : H12AffineEnvironment.transform 3 0 env10751 = env10752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10751 == env10752) = true)

def env10753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485295,2559344,8193,65,2475362,428404,375166,2305070,222543,2526213,257,2303355,2344023,147984]

theorem envBound10753 : H12AffineFastState.Bounded env10753 := by
  intro p hp
  have h : env10753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10724_10753 : H12AffineEnvironment.transform 6 9 env10724 = env10753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10724 == env10753) = true)

theorem identity10753 : scanCanonicalize (H12AffineFastState.compose env10753 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182628) := by decide +kernel

theorem selectedBound10753 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env10754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182628,1025,32769,2097152,2155580,2303307,2212884,8193,65,2296838,16400,225306,2305070,222543,2114913,257,2303355,2344023,147984]

theorem envBound10754 : H12AffineFastState.Bounded env10754 := by
  intro p hp
  have h : env10754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10753_10754 : H12AffineEnvironment.transform 17 182628 env10753 = env10754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env10753 == env10754) = true)

theorem identity10754 : scanCanonicalize (H12AffineFastState.compose env10754 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound10754 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,108927,1025,32769,2097152,2155580,2114896,2212884,8193,65,2124829,16400,4097,2116661,1364,2114913,257,2114912,2139212,74251]

theorem envBound10755 : H12AffineFastState.Bounded env10755 := by
  intro p hp
  have h : env10755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10754_10755 : H12AffineEnvironment.transform 16 90139 env10754 = env10755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env10754 == env10755) = true)

theorem identity10755 : scanCanonicalize (H12AffineFastState.compose env10755 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound10755 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env10756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,90139,76078,1025,80,2097152,2122861,2114896,2180165,8193,65,2124829,16400,4097,2116661,1364,2114913,257,2114912,2106397,74251]

theorem envBound10756 : H12AffineFastState.Bounded env10756 := by
  intro p hp
  have h : env10756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10755_10756 : H12AffineEnvironment.transform 14 81 env10755 = env10756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env10755 == env10756) = true)

theorem identity10756 : scanCanonicalize (H12AffineFastState.compose env10756 (packedSelected [3,10,16,19,20,21,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10756 : packedSelected [3,10,16,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env10757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,65536,82198,67619,1025,80,2097152,2114912,2114896,2180165,268,65,2116880,16400,4097,2116661,1364,2114913,257,2114912,2098448,66310]

theorem envBound10757 : H12AffineFastState.Bounded env10757 := by
  intro p hp
  have h : env10757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10756_10757 : H12AffineEnvironment.transform 12 269 env10756 = env10757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10756 == env10757) = true)

theorem identity10757 : scanCanonicalize (H12AffineFastState.compose env10757 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(20+1) ^^^ 69682) := by decide +kernel

theorem selectedBound10757 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,65536,82198,67619,1025,80,69682,87378,87394,21623,268,65,89378,16400,4097,89095,1364,87379,257,87378,70946,66310]

theorem envBound10758 : H12AffineFastState.Bounded env10758 := by
  intro p hp
  have h : env10758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10757_10758 : H12AffineEnvironment.transform 20 69682 env10757 = env10758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69682 env10757 == env10758) = true)

theorem identity10758 : scanCanonicalize (H12AffineFastState.compose env10758 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound10758 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env10759 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,21874,5220,23889,1025,80,17728,32,16,21623,268,65,2128,16400,4097,2421,1364,33,257,32,16464,22132]

theorem envBound10759 : H12AffineFastState.Bounded env10759 := by
  intro p hp
  have h : env10759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10758_10759 : H12AffineEnvironment.transform 15 21874 env10758 = env10759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env10758 == env10759) = true)

theorem identity10759 : scanCanonicalize (H12AffineFastState.compose env10759 (packedSelected [1,2,8,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10759 : packedSelected [1,2,8,10,16] rootPS < 2^1333 := by decide +kernel

def env10760 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,81,21510,5220,23589,1025,80,17460,32,16,21623,120,65,2128,16400,4097,2049,1056,33,117,32,16464,22132]

theorem envBound10760 : H12AffineFastState.Bounded env10760 := by
  intro p hp
  have h : env10760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10759_10760 : H12AffineEnvironment.transform 7 116 env10759 = env10760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10759 == env10760) = true)

def env10761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485295,2559345,8328,65,2475498,428540,375166,2305070,222542,2526212,257,2303475,2344022,148120]

theorem envBound10761 : H12AffineFastState.Bounded env10761 := by
  intro p hp
  have h : env10761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10723_10761 : H12AffineEnvironment.transform 23 2559345 env10723 = env10761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env10723 == env10761) = true)

theorem identity10761 : scanCanonicalize (H12AffineFastState.compose env10761 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10761 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env10762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,2559345,8192,65,2475362,428404,375166,2305070,222542,2526212,257,2303355,2344022,147984]

theorem envBound10762 : H12AffineFastState.Bounded env10762 := by
  intro p hp
  have h : env10762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10761_10762 : H12AffineEnvironment.transform 6 8 env10761 = env10762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10761 == env10762) = true)

theorem identity10762 : scanCanonicalize (H12AffineFastState.compose env10762 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound10762 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env10763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1025,32769,2097152,2155581,2327574,2188616,8192,65,2338139,57677,250183,2305070,222542,2155581,257,2303355,2344022,147984]

theorem envBound10763 : H12AffineFastState.Bounded env10763 := by
  intro p hp
  have h : env10763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10762_10763 : H12AffineEnvironment.transform 17 157753 env10762 = env10763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env10762 == env10763) = true)

theorem identity10763 : scanCanonicalize (H12AffineFastState.compose env10763 (packedSelected [0,2,3,6,7,8,11,12,15,16,17,19,23,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound10763 : packedSelected [0,2,3,6,7,8,11,12,15,16,17,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env10764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1025,32769,115735,73770,147457,41311,8192,65,158028,57677,250183,190521,222542,73770,257,188780,131137,147984]

theorem envBound10764 : H12AffineFastState.Bounded env10764 := by
  intro p hp
  have h : env10764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10763_10764 : H12AffineEnvironment.transform 20 115735 env10763 = env10764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env10763 == env10764) = true)

theorem identity10764 : scanCanonicalize (H12AffineFastState.compose env10764 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10764 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115735,73770,16,41311,8192,65,10589,57677,102742,43048,75103,73770,257,41341,16464,513]

theorem envBound10765 : H12AffineFastState.Bounded env10765 := by
  intro p hp
  have h : env10765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10764_10765 : H12AffineEnvironment.transform 16 16401 env10764 = env10765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10764 == env10765) = true)

theorem identity10765 : scanCanonicalize (H12AffineFastState.compose env10765 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound10765 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8283,16401,10280,1025,32769,58444,113,16,41311,8192,65,10589,57677,45325,43048,1284,113,257,41341,16464,513]

theorem envBound10766 : H12AffineFastState.Bounded env10766 := by
  intro p hp
  have h : env10766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10765_10766 : H12AffineEnvironment.transform 15 8283 env10765 = env10766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env10765 == env10766) = true)

theorem identity10766 : scanCanonicalize (H12AffineFastState.compose env10766 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound10766 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8283,16401,10280,1025,80,25629,113,16,8462,8192,65,10589,24860,12636,10361,1284,113,257,8492,16464,513]

theorem envBound10767 : H12AffineFastState.Bounded env10767 := by
  intro p hp
  have h : env10767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10766_10767 : H12AffineEnvironment.transform 14 81 env10766 = env10767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env10766 == env10767) = true)

theorem identity10767 : scanCanonicalize (H12AffineFastState.compose env10767 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10767 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10768 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,8203,16401,10280,1025,0,25629,33,16,8462,8192,17,10509,24860,12556,10281,1284,33,257,8492,16384,513]

theorem envBound10768 : H12AffineFastState.Bounded env10768 := by
  intro p hp
  have h : env10768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10767_10768 : H12AffineEnvironment.transform 5 16 env10767 = env10768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10767 == env10768) = true)

theorem identity10768 : scanCanonicalize (H12AffineFastState.compose env10768 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10768 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10769 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1025,0,17680,33,16,3,269,17,2048,16401,4097,2340,1284,33,257,33,16384,513]

theorem envBound10769 : H12AffineFastState.Bounded env10769 := by
  intro p hp
  have h : env10769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10768_10769 : H12AffineEnvironment.transform 12 269 env10768 = env10769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10768 == env10769) = true)

theorem identity10769 : scanCanonicalize (H12AffineFastState.compose env10769 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10770 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,16384,1,262,16401,2341,273,0,16384,33,16,3,269,17,2048,16401,4097,2340,20,33,257,33,16384,513]

theorem envBound10770 : H12AffineFastState.Bounded env10770 := by
  intro p hp
  have h : env10770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10769_10770 : H12AffineEnvironment.transform 9 272 env10769 = env10770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10769 == env10770) = true)

theorem identity10770 : scanCanonicalize (H12AffineFastState.compose env10770 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound10770 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10771 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2586,269,16384,1,262,16401,2341,273,0,16384,33,16,3,269,17,2048,16401,2587,2340,20,33,257,33,16384,513]

theorem envBound10771 : H12AffineFastState.Bounded env10771 := by
  intro p hp
  have h : env10771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10770_10771 : H12AffineEnvironment.transform 11 2586 env10770 = env10771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env10770 == env10771) = true)

theorem identity10771 : scanCanonicalize (H12AffineFastState.compose env10771 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound10771 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10772 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2586,269,2308,1,262,2325,2341,273,0,2308,33,16,3,269,17,2048,2325,2587,2340,20,33,257,33,2308,513]

theorem envBound10772 : H12AffineFastState.Bounded env10772 := by
  intro p hp
  have h : env10772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10771_10772 : H12AffineEnvironment.transform 13 2308 env10771 = env10772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env10771 == env10772) = true)

theorem identity10772 : scanCanonicalize (H12AffineFastState.compose env10772 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound10772 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10773 : List Nat := [2,4,8,16,32,16,8,256,512,272,260,798,269,0,1,262,17,33,273,0,0,33,16,3,269,17,260,17,799,32,20,33,257,33,0,513]

theorem envBound10773 : H12AffineFastState.Bounded env10773 := by
  intro p hp
  have h : env10773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10772_10773 : H12AffineEnvironment.transform 10 260 env10772 = env10773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env10772 == env10773) = true)

theorem identity10773 : scanCanonicalize (H12AffineFastState.compose env10773 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound10773 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10774 : List Nat := [2,4,8,16,32,16,8,256,303,272,260,49,269,0,1,262,17,33,273,0,0,33,16,3,269,17,260,17,48,32,20,33,257,33,0,302]

theorem envBound10774 : H12AffineFastState.Bounded env10774 := by
  intro p hp
  have h : env10774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10773_10774 : H12AffineEnvironment.transform 8 303 env10773 = env10774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env10773 == env10774) = true)

theorem identity10774 : scanCanonicalize (H12AffineFastState.compose env10774 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10774 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10775 : List Nat := [2,4,8,16,0,16,8,256,271,272,260,17,269,0,1,262,17,1,273,0,0,1,16,3,269,17,260,17,16,0,20,1,257,1,0,270]

theorem envBound10775 : H12AffineFastState.Bounded env10775 := by
  intro p hp
  have h : env10775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10774_10775 : H12AffineEnvironment.transform 4 0 env10774 = env10775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10774 == env10775) = true)

theorem identity10775 : scanCanonicalize (H12AffineFastState.compose env10775 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10775 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env10776 : List Nat := [2,4,8,16,0,16,8,5,10,21,1,17,8,0,1,3,17,1,20,0,0,1,16,3,8,17,1,17,16,0,20,1,4,1,0,11]

theorem envBound10776 : H12AffineFastState.Bounded env10776 := by
  intro p hp
  have h : env10776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10775_10776 : H12AffineEnvironment.transform 7 5 env10775 = env10776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10775 == env10776) = true)

theorem identity10776 : scanCanonicalize (H12AffineFastState.compose env10776 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound10776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10777 : List Nat := [2,0,8,16,0,16,8,1,10,17,1,17,8,0,1,3,17,1,16,0,0,1,16,3,8,17,1,17,16,0,16,1,0,1,0,11]

theorem envBound10777 : H12AffineFastState.Bounded env10777 := by
  intro p hp
  have h : env10777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10776_10777 : H12AffineEnvironment.transform 1 0 env10776 = env10777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env10776 == env10777) = true)

theorem identity10777 : scanCanonicalize (H12AffineFastState.compose env10777 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound10777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10778 : List Nat := [2,0,8,9,0,9,8,1,10,8,1,8,8,0,1,3,8,1,9,0,0,1,9,3,8,8,1,8,9,0,9,1,0,1,0,11]

theorem envBound10778 : H12AffineFastState.Bounded env10778 := by
  intro p hp
  have h : env10778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10777_10778 : H12AffineEnvironment.transform 3 9 env10777 = env10778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env10777 == env10778) = true)

def env10779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound10779 : H12AffineFastState.Bounded env10779 := by
  intro p hp
  have h : env10779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10513_10779 : H12AffineEnvironment.transform 26 30393345 env10513 = env10779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env10513 == env10779) = true)

def env10780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound10780 : H12AffineFastState.Bounded env10780 := by
  intro p hp
  have h : env10780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10779_10780 : H12AffineEnvironment.transform 18 1024 env10779 = env10780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10779 == env10780) = true)

theorem identity10780 : scanCanonicalize (H12AffineFastState.compose env10780 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound10780 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403502,18973836,10507601,8497518,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound10781 : H12AffineFastState.Bounded env10781 := by
  intro p hp
  have h : env10781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10780_10781 : H12AffineEnvironment.transform 17 223599 env10780 = env10781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env10780 == env10781) = true)

def env10782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760178,5392,10507601,8497518,10491276,4256861,256,8410417,8434836,10564187]

theorem envBound10782 : H12AffineFastState.Bounded env10782 := by
  intro p hp
  have h : env10782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10781_10782 : H12AffineEnvironment.transform 23 2199964 env10781 = env10782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env10781 == env10782) = true)

def env10783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270242,5392,17665,2210110,1500,4256861,256,2114913,2139332,74251]

theorem envBound10783 : H12AffineFastState.Bounded env10783 := by
  intro p hp
  have h : env10783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10782_10783 : H12AffineEnvironment.transform 22 2101328 env10782 = env10783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env10782 == env10783) = true)

def env10784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,16,98780,8328,65,4270242,5392,17665,108926,1500,4256861,256,21793,46212,74251]

theorem envBound10784 : H12AffineFastState.Bounded env10784 := by
  intro p hp
  have h : env10784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10783_10784 : H12AffineEnvironment.transform 20 4160 env10783 = env10784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10783 == env10784) = true)

theorem identity10784 : scanCanonicalize (H12AffineFastState.compose env10784 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10784 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,4194304,16,41430,8328,65,4196520,5392,17665,35188,1500,4256861,256,21793,46212,513]

theorem envBound10785 : H12AffineFastState.Bounded env10785 := by
  intro p hp
  have h : env10785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10784_10785 : H12AffineEnvironment.transform 15 8202 env10784 = env10785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10784 == env10785) = true)

theorem identity10785 : scanCanonicalize (H12AffineFastState.compose env10785 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8693) := by decide +kernel

theorem selectedBound10785 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env10786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,8693,16,41430,8328,65,10589,5392,17665,35188,1500,54696,256,21793,46212,513]

theorem envBound10786 : H12AffineFastState.Bounded env10786 := by
  intro p hp
  have h : env10786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10785_10786 : H12AffineEnvironment.transform 21 8693 env10785 = env10786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8693 env10785 == env10786) = true)

theorem identity10786 : scanCanonicalize (H12AffineFastState.compose env10786 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10786 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env10787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,8573,16,41310,8192,65,10589,5392,17665,35188,1364,54560,256,21793,46092,513]

theorem envBound10787 : H12AffineFastState.Bounded env10787 := by
  intro p hp
  have h : env10787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10786_10787 : H12AffineEnvironment.transform 6 8 env10786 = env10787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10786 == env10787) = true)

theorem identity10787 : scanCanonicalize (H12AffineFastState.compose env10787 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound10787 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24909,10280,1024,32769,4160,8573,16,41310,8192,65,10589,5392,17665,35188,1364,54560,256,21793,46092,513]

theorem envBound10788 : H12AffineFastState.Bounded env10788 := by
  intro p hp
  have h : env10788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10787_10788 : H12AffineEnvironment.transform 16 24909 env10787 = env10788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env10787 == env10788) = true)

theorem identity10788 : scanCanonicalize (H12AffineFastState.compose env10788 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound10788 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,24909,10280,1024,21761,4160,8573,16,29790,8192,65,10589,5392,17665,23668,1364,32,256,21793,24844,513]

theorem envBound10789 : H12AffineFastState.Bounded env10789 := by
  intro p hp
  have h : env10789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10788_10789 : H12AffineEnvironment.transform 14 21760 env10788 = env10789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env10788 == env10789) = true)

theorem identity10789 : scanCanonicalize (H12AffineFastState.compose env10789 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10789 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16400,2421,1024,21761,4160,32,16,21763,349,65,2048,5392,17665,23668,1364,32,256,21793,16465,513]

theorem envBound10790 : H12AffineFastState.Bounded env10790 := by
  intro p hp
  have h : env10790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10789_10790 : H12AffineEnvironment.transform 12 349 env10789 = env10790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10789 == env10790) = true)

def env10791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,17,98781,8328,65,4270242,5392,17665,108927,1500,4256861,256,21792,46213,74251]

theorem envBound10791 : H12AffineFastState.Bounded env10791 := by
  intro p hp
  have h : env10791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10783_10791 : H12AffineEnvironment.transform 20 4161 env10783 = env10791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10783 == env10791) = true)

theorem identity10791 : scanCanonicalize (H12AffineFastState.compose env10791 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243002) := by decide +kernel

theorem selectedBound10791 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243002,17,98781,8328,65,171416,5392,17665,108927,1500,213351,256,21792,46213,74251]

theorem envBound10792 : H12AffineFastState.Bounded env10792 := by
  intro p hp
  have h : env10792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10791_10792 : H12AffineEnvironment.transform 21 243002 env10791 = env10792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243002 env10791 == env10792) = true)

def env10793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243002,17,98645,8192,65,171280,5392,17665,108927,1364,213351,256,21792,46093,74251]

theorem envBound10793 : H12AffineFastState.Bounded env10793 := by
  intro p hp
  have h : env10793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10792_10793 : H12AffineEnvironment.transform 6 8 env10792 = env10793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10792 == env10793) = true)

theorem identity10793 : scanCanonicalize (H12AffineFastState.compose env10793 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10793 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,169264,17,41311,8192,65,171280,5392,17665,35189,1364,156013,256,21792,46093,513]

theorem envBound10794 : H12AffineFastState.Bounded env10794 := by
  intro p hp
  have h : env10794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10793_10794 : H12AffineEnvironment.transform 15 8202 env10793 = env10794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10793 == env10794) = true)

theorem identity10794 : scanCanonicalize (H12AffineFastState.compose env10794 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10794 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4161,54561,17,41311,8192,65,56577,5392,17665,35189,1364,8572,256,21792,46093,513]

theorem envBound10795 : H12AffineFastState.Bounded env10795 := by
  intro p hp
  have h : env10795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10794_10795 : H12AffineEnvironment.transform 16 16401 env10794 = env10795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10794 == env10795) = true)

theorem identity10795 : scanCanonicalize (H12AffineFastState.compose env10795 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10795 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2420,1024,8541,4161,29821,17,3,8192,65,31837,5392,17665,10281,1364,8572,256,21792,5457,513]

theorem envBound10796 : H12AffineFastState.Bounded env10796 := by
  intro p hp
  have h : env10796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10795_10796 : H12AffineEnvironment.transform 14 8540 env10795 = env10796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10795 == env10796) = true)

theorem identity10796 : scanCanonicalize (H12AffineFastState.compose env10796 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound10796 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,8202,13341,2420,1024,8541,4161,113,17,3,8192,65,2129,5392,12557,10281,1364,8572,256,8492,5457,513]

theorem envBound10797 : H12AffineFastState.Bounded env10797 := by
  intro p hp
  have h : env10797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10796_10797 : H12AffineEnvironment.transform 13 13324 env10796 = env10797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env10796 == env10797) = true)

theorem identity10797 : scanCanonicalize (H12AffineFastState.compose env10797 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound10797 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env10798 : List Nat := [2,4,8,16,32,64,8,52,512,1024,2048,4096,8192,13324,8296,8202,13341,2112,1024,8297,4161,113,17,3,8192,65,2129,5156,12345,10281,1120,8264,52,8216,5221,513]

theorem envBound10798 : H12AffineFastState.Bounded env10798 := by
  intro p hp
  have h : env10798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10797_10798 : H12AffineEnvironment.transform 7 52 env10797 = env10798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env10797 == env10798) = true)

theorem identity10798 : scanCanonicalize (H12AffineFastState.compose env10798 (packedSelected [1,2,4,6,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10798 : packedSelected [1,2,4,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env10799 : List Nat := [2,4,8,16,32,64,8,52,512,52,2048,4096,8192,12344,8296,8202,12329,2112,52,8297,4161,113,17,3,8192,65,2129,4112,12345,10281,84,8264,52,8216,4177,513]

theorem envBound10799 : H12AffineFastState.Bounded env10799 := by
  intro p hp
  have h : env10799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10798_10799 : H12AffineEnvironment.transform 9 52 env10798 = env10799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10798 == env10799) = true)

theorem identity10799 : scanCanonicalize (H12AffineFastState.compose env10799 (packedSelected [0,1,2,6,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound10799 : packedSelected [0,1,2,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env10800 : List Nat := [2,4,8,16,32,64,8,52,512,52,2048,4096,105,4177,1,99,4160,2112,52,0,4161,113,17,3,105,65,2129,4112,4176,2112,84,33,52,113,4177,513]

theorem envBound10800 : H12AffineFastState.Bounded env10800 := by
  intro p hp
  have h : env10800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10799_10800 : H12AffineEnvironment.transform 12 105 env10799 = env10800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env10799 == env10800) = true)

theorem identity10800 : scanCanonicalize (H12AffineFastState.compose env10800 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound10800 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env10801 : List Nat := [2,4,8,16,32,64,8,52,512,52,2048,2064,105,2113,1,99,2128,2112,52,0,2129,113,17,3,105,65,2129,2048,2112,2112,84,33,52,113,2113,513]

theorem envBound10801 : H12AffineFastState.Bounded env10801 := by
  intro p hp
  have h : env10801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10800_10801 : H12AffineEnvironment.transform 11 2064 env10800 = env10801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env10800 == env10801) = true)

theorem identity10801 : scanCanonicalize (H12AffineFastState.compose env10801 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10801 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10802 : List Nat := [2,4,8,16,32,16,8,52,512,52,2048,2064,57,2065,1,51,2048,2064,52,0,2049,33,17,3,57,17,2049,2048,2064,2064,4,33,52,33,2065,513]

theorem envBound10802 : H12AffineFastState.Bounded env10802 := by
  intro p hp
  have h : env10802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10801_10802 : H12AffineEnvironment.transform 5 16 env10801 = env10802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10801 == env10802) = true)

theorem identity10802 : scanCanonicalize (H12AffineFastState.compose env10802 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10803 : List Nat := [2,4,8,0,32,0,8,36,512,36,2048,2048,41,2049,1,35,2048,2048,36,0,2049,33,1,3,41,1,2049,2048,2048,2048,4,33,36,33,2049,513]

theorem envBound10803 : H12AffineFastState.Bounded env10803 := by
  intro p hp
  have h : env10803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10802_10803 : H12AffineEnvironment.transform 3 0 env10802 = env10803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10802 == env10803) = true)

theorem identity10803 : scanCanonicalize (H12AffineFastState.compose env10803 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10804 : List Nat := [2,4,8,0,32,0,8,36,1,36,2048,2048,41,2049,1,35,2048,2048,36,0,2049,33,1,3,41,1,2049,2048,2048,2048,4,33,36,33,2049,0]

theorem envBound10804 : H12AffineFastState.Bounded env10804 := by
  intro p hp
  have h : env10804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10803_10804 : H12AffineEnvironment.transform 8 1 env10803 = env10804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10803 == env10804) = true)

theorem identity10804 : scanCanonicalize (H12AffineFastState.compose env10804 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound10804 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10805 : List Nat := [2,4,8,0,32,0,8,36,1,36,10,10,41,11,1,35,10,10,36,0,11,33,1,3,41,1,11,10,10,10,4,33,36,33,11,0]

theorem envBound10805 : H12AffineFastState.Bounded env10805 := by
  intro p hp
  have h : env10805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10804_10805 : H12AffineEnvironment.transform 10 10 env10804 = env10805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env10804 == env10805) = true)

theorem identity10805 : scanCanonicalize (H12AffineFastState.compose env10805 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10805 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10806 : List Nat := [2,4,3,0,32,0,3,36,1,36,1,1,34,0,1,35,1,1,36,0,0,33,1,3,34,1,0,1,1,1,4,33,36,33,0,0]

theorem envBound10806 : H12AffineFastState.Bounded env10806 := by
  intro p hp
  have h : env10806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10805_10806 : H12AffineEnvironment.transform 2 3 env10805 = env10806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10805 == env10806) = true)

def env10807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243002,17,98644,8193,65,171281,5392,17665,108927,1365,213351,256,21792,46092,74251]

theorem envBound10807 : H12AffineFastState.Bounded env10807 := by
  intro p hp
  have h : env10807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10792_10807 : H12AffineEnvironment.transform 6 9 env10792 = env10807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10792 == env10807) = true)

theorem identity10807 : scanCanonicalize (H12AffineFastState.compose env10807 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound10807 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4161,144493,17,3,8193,65,171281,5392,17665,10280,1365,180272,256,21792,46092,41820]

theorem envBound10808 : H12AffineFastState.Bounded env10808 := by
  intro p hp
  have h : env10808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10807_10808 : H12AffineEnvironment.transform 15 33111 env10807 = env10808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env10807 == env10808) = true)

theorem identity10808 : scanCanonicalize (H12AffineFastState.compose env10808 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound10808 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env10809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,46109,23589,1024,32769,4161,32880,17,3,8193,65,10508,5392,17665,10280,1365,29741,256,21792,46092,41820]

theorem envBound10809 : H12AffineFastState.Bounded env10809 := by
  intro p hp
  have h : env10809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10808_10809 : H12AffineEnvironment.transform 16 46109 env10808 = env10809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env10808 == env10809) = true)

theorem identity10809 : scanCanonicalize (H12AffineFastState.compose env10809 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound10809 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env10810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,16448,23589,1024,29788,4161,29741,17,3,8193,65,10508,5392,17665,10280,1365,29741,256,21792,16465,22273]

theorem envBound10810 : H12AffineFastState.Bounded env10810 := by
  intro p hp
  have h : env10810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10809_10810 : H12AffineEnvironment.transform 14 29789 env10809 = env10810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10809 == env10810) = true)

theorem identity10810 : scanCanonicalize (H12AffineFastState.compose env10810 (packedSelected [0,2,7,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound10810 : packedSelected [0,2,7,14,20] rootPS < 2^1333 := by decide +kernel

def env10811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13657,260,83,13593,10620,1024,261,4161,372,17,3,8193,65,10508,5392,12376,10280,1365,372,256,8313,13576,8792]

theorem envBound10811 : H12AffineFastState.Bounded env10811 := by
  intro p hp
  have h : env10811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10810_10811 : H12AffineEnvironment.transform 13 13657 env10810 = env10811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env10810 == env10811) = true)

theorem identity10811 : scanCanonicalize (H12AffineFastState.compose env10811 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound10811 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5488,260,83,5424,2389,1024,261,4161,372,17,3,40,65,2341,5392,4209,2049,1365,372,256,80,5409,625]

theorem envBound10812 : H12AffineFastState.Bounded env10812 := by
  intro p hp
  have h : env10812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10811_10812 : H12AffineEnvironment.transform 12 41 env10811 = env10812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env10811 == env10812) = true)

theorem identity10812 : scanCanonicalize (H12AffineFastState.compose env10812 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10812 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10813 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5409,260,2,5424,2308,1024,261,4112,293,17,3,40,16,2341,5392,4128,2049,1284,293,256,1,5409,544]

theorem envBound10813 : H12AffineFastState.Bounded env10813 := by
  intro p hp
  have h : env10813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10812_10813 : H12AffineEnvironment.transform 5 17 env10812 = env10813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10812 == env10813) = true)

theorem identity10813 : scanCanonicalize (H12AffineFastState.compose env10813 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10813 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10814 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,41,5157,0,2,5172,2048,1024,1,4112,33,17,3,40,16,2081,5140,4128,2049,1024,33,4,1,5157,544]

theorem envBound10814 : H12AffineFastState.Bounded env10814 := by
  intro p hp
  have h : env10814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10813_10814 : H12AffineEnvironment.transform 7 4 env10813 = env10814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10813 == env10814) = true)

theorem identity10814 : scanCanonicalize (H12AffineFastState.compose env10814 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10814 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10815 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,0,2,5141,2048,1024,1,4112,0,17,3,9,16,2048,5140,4097,2049,1024,0,4,1,5124,513]

theorem envBound10815 : H12AffineFastState.Bounded env10815 := by
  intro p hp
  have h : env10815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10814_10815 : H12AffineEnvironment.transform 4 1 env10814 = env10815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10814 == env10815) = true)

theorem identity10815 : scanCanonicalize (H12AffineFastState.compose env10815 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10815 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10816 : List Nat := [2,4,8,1,1,0,9,4,512,1024,2048,4096,8,5124,0,2,5124,2048,1024,1,4097,0,0,3,9,1,2048,5125,4097,2049,1024,0,4,1,5124,513]

theorem envBound10816 : H12AffineFastState.Bounded env10816 := by
  intro p hp
  have h : env10816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10815_10816 : H12AffineEnvironment.transform 3 1 env10815 = env10816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10815 == env10816) = true)

theorem identity10816 : scanCanonicalize (H12AffineFastState.compose env10816 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound10816 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10817 : List Nat := [2,4,8,1,1,0,9,4,512,1024,2048,1541,8,513,0,2,513,2048,1024,1,1540,0,0,3,9,1,2048,512,1540,2049,1024,0,4,1,513,513]

theorem envBound10817 : H12AffineFastState.Bounded env10817 := by
  intro p hp
  have h : env10817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10816_10817 : H12AffineEnvironment.transform 11 1541 env10816 = env10817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env10816 == env10817) = true)

theorem identity10817 : scanCanonicalize (H12AffineFastState.compose env10817 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound10817 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10818 : List Nat := [2,4,8,1,1,0,9,4,512,1024,1541,1541,8,513,0,2,513,1541,1024,1,1540,0,0,3,9,1,1541,512,1540,1540,1024,0,4,1,513,513]

theorem envBound10818 : H12AffineFastState.Bounded env10818 := by
  intro p hp
  have h : env10818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10817_10818 : H12AffineEnvironment.transform 10 1541 env10817 = env10818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env10817 == env10818) = true)

def env10819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270243,5392,17664,2210111,1501,4256861,256,2114912,2139333,74250]

theorem envBound10819 : H12AffineFastState.Bounded env10819 := by
  intro p hp
  have h : env10819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10782_10819 : H12AffineEnvironment.transform 22 2101329 env10782 = env10819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env10782 == env10819) = true)

def env10820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,17,98780,8328,65,4270243,5392,17664,108927,1501,4256861,256,21792,46213,74250]

theorem envBound10820 : H12AffineFastState.Bounded env10820 := by
  intro p hp
  have h : env10820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10819_10820 : H12AffineEnvironment.transform 20 4160 env10819 = env10820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10819 == env10820) = true)

theorem identity10820 : scanCanonicalize (H12AffineFastState.compose env10820 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213486) := by decide +kernel

theorem selectedBound10820 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,213486,17,98780,8328,65,158029,5392,17664,108927,1501,243123,256,21792,46213,74250]

theorem envBound10821 : H12AffineFastState.Bounded env10821 := by
  intro p hp
  have h : env10821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10820_10821 : H12AffineEnvironment.transform 21 213486 env10820 = env10821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213486 env10820 == env10821) = true)

theorem identity10821 : scanCanonicalize (H12AffineFastState.compose env10821 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10821 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env10822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4160,156133,17,41431,8328,65,158029,5392,17664,35188,1501,169400,256,21792,46213,513]

theorem envBound10822 : H12AffineFastState.Bounded env10822 := by
  intro p hp
  have h : env10822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10821_10822 : H12AffineEnvironment.transform 15 8203 env10821 = env10822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10821 == env10822) = true)

theorem identity10822 : scanCanonicalize (H12AffineFastState.compose env10822 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound10822 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2420,1024,32769,4160,8693,17,41431,8328,65,10589,5392,17664,35188,1501,54696,256,21792,46213,513]

theorem envBound10823 : H12AffineFastState.Bounded env10823 := by
  intro p hp
  have h : env10823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10822_10823 : H12AffineEnvironment.transform 16 16400 env10822 = env10823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10822 == env10823) = true)

theorem identity10823 : scanCanonicalize (H12AffineFastState.compose env10823 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound10823 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env10824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16400,2420,1024,29708,4160,8693,17,21978,8328,65,10589,5392,17664,32121,1501,8613,256,21792,16520,513]

theorem envBound10824 : H12AffineFastState.Bounded env10824 := by
  intro p hp
  have h : env10824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10823_10824 : H12AffineEnvironment.transform 14 29709 env10823 = env10824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env10823 == env10824) = true)

theorem identity10824 : scanCanonicalize (H12AffineFastState.compose env10824 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10824 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21840,342,16400,2420,1024,21841,4160,168,17,21978,469,65,2048,5392,17664,23588,1501,248,256,21792,16520,513]

theorem envBound10825 : H12AffineFastState.Bounded env10825 := by
  intro p hp
  have h : env10825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10824_10825 : H12AffineEnvironment.transform 12 349 env10824 = env10825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10824 == env10825) = true)

theorem identity10825 : scanCanonicalize (H12AffineFastState.compose env10825 (packedSelected [1,2,5,7,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3528) := by decide +kernel

theorem selectedBound10825 : packedSelected [1,2,5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env10826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,3528,6296,342,3544,2420,1024,6297,4160,168,17,6162,469,65,2048,5392,2248,4588,1501,248,256,6376,3392,513]

theorem envBound10826 : H12AffineFastState.Bounded env10826 := by
  intro p hp
  have h : env10826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10825_10826 : H12AffineEnvironment.transform 13 3528 env10825 = env10826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3528 env10825 == env10826) = true)

theorem identity10826 : scanCanonicalize (H12AffineFastState.compose env10826 (packedSelected [0,2,3,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound10826 : packedSelected [0,2,3,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env10827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,349,3528,2421,342,3544,2420,1024,2420,429,168,17,2559,469,65,2048,1277,2248,1,1501,248,256,2309,3392,513]

theorem envBound10827 : H12AffineFastState.Bounded env10827 := by
  intro p hp
  have h : env10827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10826_10827 : H12AffineEnvironment.transform 11 493 env10826 = env10827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env10826 == env10827) = true)

theorem identity10827 : scanCanonicalize (H12AffineFastState.compose env10827 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10827 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10828 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,152,40,3261,2048,35,3245,2049,1024,2049,216,168,17,2186,160,65,2048,1277,2248,1,1192,248,117,2160,3125,513]

theorem envBound10828 : H12AffineFastState.Bounded env10828 := by
  intro p hp
  have h : env10828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10827_10828 : H12AffineEnvironment.transform 7 117 env10827 = env10828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10827 == env10828) = true)

theorem identity10828 : scanCanonicalize (H12AffineFastState.compose env10828 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound10828 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env10829 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1125,152,40,216,1125,35,200,1124,1024,1124,216,168,17,1263,160,65,1125,1277,1197,1,1192,248,117,1045,80,513]

theorem envBound10829 : H12AffineFastState.Bounded env10829 := by
  intro p hp
  have h : env10829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10828_10829 : H12AffineEnvironment.transform 10 1125 env10828 = env10829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env10828 == env10829) = true)

theorem identity10829 : scanCanonicalize (H12AffineFastState.compose env10829 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10829 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env10830 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1077,152,40,136,1077,35,152,1076,1024,1076,136,168,17,1215,160,17,1077,1197,1197,1,1192,168,37,1045,0,513]

theorem envBound10830 : H12AffineFastState.Bounded env10830 := by
  intro p hp
  have h : env10830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10829_10830 : H12AffineEnvironment.transform 5 16 env10829 = env10830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10829 == env10830) = true)

theorem identity10830 : scanCanonicalize (H12AffineFastState.compose env10830 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound10830 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env10831 : List Nat := [2,4,8,16,32,16,128,37,512,188,137,152,40,136,137,35,152,136,188,136,136,168,17,3,160,17,137,17,17,1,20,168,37,169,0,513]

theorem envBound10831 : H12AffineFastState.Bounded env10831 := by
  intro p hp
  have h : env10831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10830_10831 : H12AffineEnvironment.transform 9 188 env10830 = env10831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env10830 == env10831) = true)

theorem identity10831 : scanCanonicalize (H12AffineFastState.compose env10831 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound10831 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10832 : List Nat := [2,4,8,16,32,16,128,37,26,188,137,152,40,136,137,35,152,136,188,136,136,168,17,3,160,17,137,17,17,1,20,168,37,169,0,27]

theorem envBound10832 : H12AffineFastState.Bounded env10832 := by
  intro p hp
  have h : env10832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10831_10832 : H12AffineEnvironment.transform 8 26 env10831 = env10832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env10831 == env10832) = true)

theorem identity10832 : scanCanonicalize (H12AffineFastState.compose env10832 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10833 : List Nat := [2,4,8,16,32,16,8,37,26,52,1,16,40,0,1,35,16,0,52,0,0,32,17,3,40,17,1,17,17,1,20,32,37,33,0,27]

theorem envBound10833 : H12AffineFastState.Bounded env10833 := by
  intro p hp
  have h : env10833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10832_10833 : H12AffineEnvironment.transform 6 8 env10832 = env10833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10832 == env10833) = true)

theorem identity10833 : scanCanonicalize (H12AffineFastState.compose env10833 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10834 : List Nat := [2,4,3,16,32,16,3,37,17,52,1,16,35,0,1,35,16,0,52,0,0,32,17,3,35,17,1,17,17,1,20,32,37,33,0,16]

theorem envBound10834 : H12AffineFastState.Bounded env10834 := by
  intro p hp
  have h : env10834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10833_10834 : H12AffineEnvironment.transform 2 3 env10833 = env10834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10833 == env10834) = true)

def env10835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98781,8328,65,4270243,5392,17664,108926,1501,4256861,256,21793,46212,74250]

theorem envBound10835 : H12AffineFastState.Bounded env10835 := by
  intro p hp
  have h : env10835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10819_10835 : H12AffineEnvironment.transform 20 4161 env10819 = env10835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10819 == env10835) = true)

theorem identity10835 : scanCanonicalize (H12AffineFastState.compose env10835 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound10835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179633,1024,32769,4161,4194304,16,21763,8328,65,4258941,5392,17664,32160,1501,4256861,256,21793,46212,63188]

theorem envBound10836 : H12AffineFastState.Bounded env10836 := by
  intro p hp
  have h : env10836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10835_10836 : H12AffineEnvironment.transform 15 54494 env10835 = env10836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env10835 == env10836) = true)

def env10837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4161,4194304,16,21763,8192,65,4258941,5392,17664,32040,1365,4256861,256,21793,46092,63068]

theorem envBound10837 : H12AffineFastState.Bounded env10837 := by
  intro p hp
  have h : env10837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10836_10837 : H12AffineEnvironment.transform 6 8 env10836 = env10837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10836 == env10837) = true)

theorem identity10837 : scanCanonicalize (H12AffineFastState.compose env10837 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound10837 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24908,56437,1024,32769,4161,4194304,16,21763,8192,65,4258941,5392,17664,32040,1365,4256861,256,21793,46092,63068]

theorem envBound10838 : H12AffineFastState.Bounded env10838 := by
  intro p hp
  have h : env10838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10837_10838 : H12AffineEnvironment.transform 16 24908 env10837 = env10838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env10837 == env10838) = true)

theorem identity10838 : scanCanonicalize (H12AffineFastState.compose env10838 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound10838 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env10839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,24908,10280,1024,29788,4161,4194304,16,21763,8192,65,4196384,5392,17664,32040,1365,4194304,256,21793,16465,513]

theorem envBound10839 : H12AffineFastState.Bounded env10839 := by
  intro p hp
  have h : env10839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10838_10839 : H12AffineEnvironment.transform 14 29789 env10838 = env10839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10838 == env10839) = true)

theorem identity10839 : scanCanonicalize (H12AffineFastState.compose env10839 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound10839 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,24908,10280,1024,29788,4161,8492,16,21763,8192,65,10508,5392,17664,32040,1365,8492,256,21793,16465,513]

theorem envBound10840 : H12AffineFastState.Bounded env10840 := by
  intro p hp
  have h : env10840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10839_10840 : H12AffineEnvironment.transform 21 8492 env10839 = env10840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env10839 == env10840) = true)

theorem identity10840 : scanCanonicalize (H12AffineFastState.compose env10840 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10840 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10841 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,24860,10280,1024,29708,4113,8492,16,21763,8192,17,10508,5392,17664,32040,1285,8492,256,21793,16385,513]

theorem envBound10841 : H12AffineFastState.Bounded env10841 := by
  intro p hp
  have h : env10841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10840_10841 : H12AffineEnvironment.transform 5 16 env10840 = env10841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10840 == env10841) = true)

theorem identity10841 : scanCanonicalize (H12AffineFastState.compose env10841 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10841 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10842 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,263,16400,2340,1024,21760,4113,32,16,21763,268,17,2048,5392,17664,23588,1285,32,256,21793,16385,513]

theorem envBound10842 : H12AffineFastState.Bounded env10842 := by
  intro p hp
  have h : env10842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10841_10842 : H12AffineEnvironment.transform 12 268 env10841 = env10842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10841 == env10842) = true)

theorem identity10842 : scanCanonicalize (H12AffineFastState.compose env10842 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2868) := by decide +kernel

theorem selectedBound10842 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env10843 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2868,268,16384,20021,263,16400,2340,1024,20020,2853,32,16,20023,268,17,2048,3620,17664,18192,1285,32,256,19989,16385,513]

theorem envBound10843 : H12AffineFastState.Bounded env10843 := by
  intro p hp
  have h : env10843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10842_10843 : H12AffineEnvironment.transform 11 2868 env10842 = env10843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2868 env10842 == env10843) = true)

theorem identity10843 : scanCanonicalize (H12AffineFastState.compose env10843 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1312) := by decide +kernel

theorem selectedBound10843 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env10844 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1312,1556,268,16384,17173,263,16400,1028,1024,17172,1541,32,16,17175,268,17,1312,772,17664,18192,1285,32,256,17205,16385,513]

theorem envBound10844 : H12AffineFastState.Bounded env10844 := by
  intro p hp
  have h : env10844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10843_10844 : H12AffineEnvironment.transform 10 1312 env10843 = env10844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1312 env10843 == env10844) = true)

theorem identity10844 : scanCanonicalize (H12AffineFastState.compose env10844 (packedSelected [0,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound10844 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env10845 : List Nat := [2,4,8,16,32,16,8,256,512,800,512,308,268,16384,17173,263,16400,804,800,17172,293,32,16,17175,268,17,512,772,16928,16432,549,32,256,17205,16385,513]

theorem envBound10845 : H12AffineFastState.Bounded env10845 := by
  intro p hp
  have h : env10845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10844_10845 : H12AffineEnvironment.transform 9 800 env10844 = env10845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env10844 == env10845) = true)

theorem identity10845 : scanCanonicalize (H12AffineFastState.compose env10845 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound10845 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env10846 : List Nat := [2,4,8,16,32,16,8,256,309,21,309,308,268,16384,16416,263,16400,17,21,16417,293,32,16,16418,268,17,309,49,16661,16432,272,32,256,16384,16385,308]

theorem envBound10846 : H12AffineFastState.Bounded env10846 := by
  intro p hp
  have h : env10846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10845_10846 : H12AffineEnvironment.transform 8 309 env10845 = env10846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env10845 == env10846) = true)

def env10847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4161,4194304,16,21763,8193,65,4258941,5392,17664,32041,1364,4256861,256,21793,46093,63069]

theorem envBound10847 : H12AffineFastState.Bounded env10847 := by
  intro p hp
  have h : env10847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10836_10847 : H12AffineEnvironment.transform 6 9 env10836 = env10847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10836 == env10847) = true)

theorem identity10847 : scanCanonicalize (H12AffineFastState.compose env10847 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound10847 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49168,32040,1024,32769,4161,4194304,16,21763,8193,65,4258941,5392,17664,32041,1364,4256861,256,21793,46093,63069]

theorem envBound10848 : H12AffineFastState.Bounded env10848 := by
  intro p hp
  have h : env10848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10847_10848 : H12AffineEnvironment.transform 16 49168 env10847 = env10848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env10847 == env10848) = true)

theorem identity10848 : scanCanonicalize (H12AffineFastState.compose env10848 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10848 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,49168,23669,1024,32769,4161,4194304,16,21763,348,65,4250912,5392,17664,23668,1364,4248832,256,21793,38224,55040]

theorem envBound10849 : H12AffineFastState.Bounded env10849 := by
  intro p hp
  have h : env10849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10848_10849 : H12AffineEnvironment.transform 12 349 env10848 = env10849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10848 == env10849) = true)

theorem identity10849 : scanCanonicalize (H12AffineFastState.compose env10849 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound10849 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env10850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,49168,23669,1024,32769,4161,21793,16,21763,348,65,34817,5392,17664,23668,1364,32801,256,21793,38224,55040]

theorem envBound10850 : H12AffineFastState.Bounded env10850 := by
  intro p hp
  have h : env10850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10849_10850 : H12AffineEnvironment.transform 21 21793 env10849 = env10850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env10849 == env10850) = true)

theorem identity10850 : scanCanonicalize (H12AffineFastState.compose env10850 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10850 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env10851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,33110,38161,2420,1024,32769,4161,32,16,2,348,65,34817,5392,4097,2421,1364,32801,256,32,38224,33281]

theorem envBound10851 : H12AffineFastState.Bounded env10851 := by
  intro p hp
  have h : env10851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10850_10851 : H12AffineEnvironment.transform 13 5377 env10850 = env10851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10850 == env10851) = true)

theorem identity10851 : scanCanonicalize (H12AffineFastState.compose env10851 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10851 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1297,1095,4096,2420,1024,1296,4161,32,16,2,348,65,3344,5392,4097,2421,1364,1328,256,32,4161,1808]

theorem envBound10852 : H12AffineFastState.Bounded env10852 := by
  intro p hp
  have h : env10852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10851_10852 : H12AffineEnvironment.transform 14 1297 env10851 = env10852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env10851 == env10852) = true)

theorem identity10852 : scanCanonicalize (H12AffineFastState.compose env10852 (packedSelected [4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1312) := by decide +kernel

theorem selectedBound10852 : packedSelected [4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1312,4096,349,5377,1297,1095,4096,1108,1024,1296,4161,32,16,2,348,65,48,5392,4097,1109,1364,1328,256,32,4161,1808]

theorem envBound10853 : H12AffineFastState.Bounded env10853 := by
  intro p hp
  have h : env10853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10852_10853 : H12AffineEnvironment.transform 10 1312 env10852 = env10853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1312 env10852 == env10853) = true)

theorem identity10853 : scanCanonicalize (H12AffineFastState.compose env10853 (packedSelected [0,1,3,5,6,7,8,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10853 : packedSelected [0,1,3,5,6,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env10854 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1312,4096,269,5377,1297,1047,4096,1028,1024,1296,4113,32,16,2,268,17,48,5392,4097,1029,1284,1328,256,32,4113,1808]

theorem envBound10854 : H12AffineFastState.Bounded env10854 := by
  intro p hp
  have h : env10854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10853_10854 : H12AffineEnvironment.transform 5 16 env10853 = env10854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10853 == env10854) = true)

theorem identity10854 : scanCanonicalize (H12AffineFastState.compose env10854 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10854 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10855 : List Nat := [2,4,8,16,32,16,9,256,512,20,308,4096,269,4373,261,3,4096,16,20,260,4113,32,16,2,268,17,48,4356,4097,17,272,292,256,32,4113,772]

theorem envBound10855 : H12AffineFastState.Bounded env10855 := by
  intro p hp
  have h : env10855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10854_10855 : H12AffineEnvironment.transform 9 20 env10854 = env10855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10854 == env10855) = true)

theorem identity10855 : scanCanonicalize (H12AffineFastState.compose env10855 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound10855 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env10856 : List Nat := [2,4,8,16,32,16,9,256,512,20,308,292,269,49,261,3,292,16,20,260,309,32,16,2,268,17,48,32,293,17,272,292,256,32,309,772]

theorem envBound10856 : H12AffineFastState.Bounded env10856 := by
  intro p hp
  have h : env10856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10855_10856 : H12AffineEnvironment.transform 11 292 env10855 = env10856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env10855 == env10856) = true)

theorem identity10856 : scanCanonicalize (H12AffineFastState.compose env10856 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10856 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10857 : List Nat := [2,4,8,16,1,16,9,256,512,20,277,261,269,16,261,3,261,16,20,260,276,1,16,2,268,17,17,1,260,17,272,261,256,1,276,772]

theorem envBound10857 : H12AffineFastState.Bounded env10857 := by
  intro p hp
  have h : env10857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10856_10857 : H12AffineEnvironment.transform 4 1 env10856 = env10857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10856 == env10857) = true)

theorem identity10857 : scanCanonicalize (H12AffineFastState.compose env10857 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10857 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env10858 : List Nat := [2,4,8,16,1,16,9,4,512,20,17,1,9,16,1,3,1,16,20,0,16,1,16,2,8,17,17,1,0,17,20,1,4,1,16,512]

theorem envBound10858 : H12AffineFastState.Bounded env10858 := by
  intro p hp
  have h : env10858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10857_10858 : H12AffineEnvironment.transform 7 4 env10857 = env10858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10857 == env10858) = true)

theorem identity10858 : scanCanonicalize (H12AffineFastState.compose env10858 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound10858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10859 : List Nat := [2,4,8,5,1,5,9,4,512,1,4,1,9,5,1,3,1,5,1,0,5,1,5,2,8,4,4,1,0,4,1,1,4,1,5,512]

theorem envBound10859 : H12AffineFastState.Bounded env10859 := by
  intro p hp
  have h : env10859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10858_10859 : H12AffineEnvironment.transform 3 5 env10858 = env10859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env10858 == env10859) = true)

theorem identity10859 : scanCanonicalize (H12AffineFastState.compose env10859 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound10859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10860 : List Nat := [2,4,8,5,1,5,9,4,9,1,4,1,9,5,1,3,1,5,1,0,5,1,5,2,8,4,4,1,0,4,1,1,4,1,5,9]

theorem envBound10860 : H12AffineFastState.Bounded env10860 := by
  intro p hp
  have h : env10860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10859_10860 : H12AffineEnvironment.transform 8 9 env10859 = env10860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env10859 == env10860) = true)

theorem identity10860 : scanCanonicalize (H12AffineFastState.compose env10860 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound10860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10861 : List Nat := [2,1,8,0,1,0,9,1,9,1,1,1,9,0,1,3,1,0,1,0,0,1,0,2,8,1,1,1,0,1,1,1,1,1,0,9]

theorem envBound10861 : H12AffineFastState.Bounded env10861 := by
  intro p hp
  have h : env10861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10860_10861 : H12AffineEnvironment.transform 1 1 env10860 = env10861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env10860 == env10861) = true)

theorem identity10861 : scanCanonicalize (H12AffineFastState.compose env10861 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10861 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10862 : List Nat := [2,1,3,0,1,0,2,1,2,1,1,1,2,0,1,3,1,0,1,0,0,1,0,2,3,1,1,1,0,1,1,1,1,1,0,2]

theorem envBound10862 : H12AffineFastState.Bounded env10862 := by
  intro p hp
  have h : env10862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10861_10862 : H12AffineEnvironment.transform 2 3 env10861 = env10862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10861 == env10862) = true)

def env10863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760179,5393,10507601,8497518,10491277,4256860,256,8410416,8434837,10564186]

theorem envBound10863 : H12AffineFastState.Bounded env10863 := by
  intro p hp
  have h : env10863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10781_10863 : H12AffineEnvironment.transform 23 2199965 env10781 = env10863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env10781 == env10863) = true)

def env10864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270243,5393,17665,2210110,1501,4256860,256,2114912,2139333,74250]

theorem envBound10864 : H12AffineFastState.Bounded env10864 := by
  intro p hp
  have h : env10864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10863_10864 : H12AffineEnvironment.transform 22 2101328 env10863 = env10864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env10863 == env10864) = true)

def env10865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,16,98781,8328,65,4270243,5393,17665,108926,1501,4256860,256,21792,46213,74250]

theorem envBound10865 : H12AffineFastState.Bounded env10865 := by
  intro p hp
  have h : env10865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10864_10865 : H12AffineEnvironment.transform 20 4160 env10864 = env10865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10864 == env10865) = true)

theorem identity10865 : scanCanonicalize (H12AffineFastState.compose env10865 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound10865 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,223599,1024,29909,4160,4194304,16,95497,8328,65,4270243,5393,17665,89514,1501,4194440,256,21792,16465,74250]

theorem envBound10866 : H12AffineFastState.Bounded env10866 := by
  intro p hp
  have h : env10866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10865_10866 : H12AffineEnvironment.transform 14 29908 env10865 = env10866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env10865 == env10866) = true)

def env10867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212079,1024,8661,4160,4194304,16,73737,8328,65,4270243,5393,4097,67754,1501,4194440,256,32,5457,74250]

theorem envBound10867 : H12AffineFastState.Bounded env10867 := by
  intro p hp
  have h : env10867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10866_10867 : H12AffineEnvironment.transform 13 5376 env10866 = env10867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10866 == env10867) = true)

theorem identity10867 : scanCanonicalize (H12AffineFastState.compose env10867 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound10867 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,67755,1024,8661,4160,4194304,16,73737,8328,65,4270243,5393,4097,67754,1501,4194440,256,32,5457,74250]

theorem envBound10868 : H12AffineFastState.Bounded env10868 := by
  intro p hp
  have h : env10868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10867_10868 : H12AffineEnvironment.transform 16 13508 env10867 = env10868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env10867 == env10868) = true)

theorem identity10868 : scanCanonicalize (H12AffineFastState.compose env10868 (packedSelected [0,2,3,4,5,6,9,10,16,27] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound10868 : packedSelected [0,2,3,4,5,6,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env10869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,67755,1024,8661,4160,73891,16,73737,8328,65,2048,5393,4097,67754,1501,73771,256,32,5457,74250]

theorem envBound10869 : H12AffineFastState.Bounded env10869 := by
  intro p hp
  have h : env10869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10868_10869 : H12AffineEnvironment.transform 21 73891 env10868 = env10869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env10868 == env10869) = true)

theorem identity10869 : scanCanonicalize (H12AffineFastState.compose env10869 (packedSelected [1,8,9,10,11,15,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8402) := by decide +kernel

theorem selectedBound10869 : packedSelected [1,8,9,10,11,15,20,22] rootPS < 2^1333 := by decide +kernel

def env10870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8402,13508,10361,1024,8661,4160,113,16,219,8328,65,2048,5393,4097,10360,1501,249,256,32,5457,728]

theorem envBound10870 : H12AffineFastState.Bounded env10870 := by
  intro p hp
  have h : env10870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10869_10870 : H12AffineEnvironment.transform 15 8402 env10869 = env10870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8402 env10869 == env10870) = true)

theorem identity10870 : scanCanonicalize (H12AffineFastState.compose env10870 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound10870 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env10871 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10361,1024,8461,4160,113,16,3,8272,65,2048,5393,4097,10360,1285,33,256,32,5457,512]

theorem envBound10871 : H12AffineFastState.Bounded env10871 := by
  intro p hp
  have h : env10871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10870_10871 : H12AffineEnvironment.transform 6 88 env10870 = env10871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env10870 == env10871) = true)

theorem identity10871 : scanCanonicalize (H12AffineFastState.compose env10871 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound10871 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10872 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,381,5376,113,375,5473,2308,1024,112,4160,113,16,3,301,65,2048,5393,4097,2309,1285,33,256,32,5457,512]

theorem envBound10872 : H12AffineFastState.Bounded env10872 := by
  intro p hp
  have h : env10872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10871_10872 : H12AffineEnvironment.transform 12 381 env10871 = env10872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env10871 == env10872) = true)

theorem identity10872 : scanCanonicalize (H12AffineFastState.compose env10872 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound10872 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env10873 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2405,381,3173,113,375,3076,2308,1024,112,2341,113,16,3,301,65,2048,3188,2404,2309,1285,33,256,32,3124,512]

theorem envBound10873 : H12AffineFastState.Bounded env10873 := by
  intro p hp
  have h : env10873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10872_10873 : H12AffineEnvironment.transform 11 2405 env10872 = env10873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env10872 == env10873) = true)

theorem identity10873 : scanCanonicalize (H12AffineFastState.compose env10873 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound10873 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env10874 : List Nat := [2,4,8,16,32,49,41,256,512,1024,2048,2324,268,3092,0,262,3076,2308,1024,1,2341,0,16,3,301,48,2048,3077,2325,2309,1285,33,256,32,3124,512]

theorem envBound10874 : H12AffineFastState.Bounded env10874 := by
  intro p hp
  have h : env10874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10873_10874 : H12AffineEnvironment.transform 5 49 env10873 = env10874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env10873 == env10874) = true)

theorem identity10874 : scanCanonicalize (H12AffineFastState.compose env10874 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10874 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env10875 : List Nat := [2,4,8,16,32,49,41,256,512,52,2048,2324,268,2080,0,262,2096,2308,52,1,2341,0,16,3,301,48,2048,2097,2325,2309,305,33,256,32,2048,512]

theorem envBound10875 : H12AffineFastState.Bounded env10875 := by
  intro p hp
  have h : env10875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10874_10875 : H12AffineEnvironment.transform 9 52 env10874 = env10875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10874 == env10875) = true)

theorem identity10875 : scanCanonicalize (H12AffineFastState.compose env10875 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10875 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env10876 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,2096,40,2080,0,34,2096,2080,52,1,2049,0,16,3,9,48,2048,2097,2097,2081,21,33,36,32,2048,512]

theorem envBound10876 : H12AffineFastState.Bounded env10876 := by
  intro p hp
  have h : env10876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10875_10876 : H12AffineEnvironment.transform 7 36 env10875 = env10876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10875 == env10876) = true)

theorem identity10876 : scanCanonicalize (H12AffineFastState.compose env10876 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound10876 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10877 : List Nat := [2,4,8,16,32,49,41,36,512,52,1,49,40,33,0,34,49,33,52,1,0,0,16,3,9,48,1,48,48,32,21,33,36,32,1,512]

theorem envBound10877 : H12AffineFastState.Bounded env10877 := by
  intro p hp
  have h : env10877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10876_10877 : H12AffineEnvironment.transform 10 1 env10876 = env10877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10876 == env10877) = true)

theorem identity10877 : scanCanonicalize (H12AffineFastState.compose env10877 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound10877 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10878 : List Nat := [2,4,8,16,32,49,41,36,33,52,1,49,40,33,0,34,49,33,52,1,0,0,16,3,9,48,1,48,48,32,21,33,36,32,1,33]

theorem envBound10878 : H12AffineFastState.Bounded env10878 := by
  intro p hp
  have h : env10878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10877_10878 : H12AffineEnvironment.transform 8 33 env10877 = env10878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10877 == env10878) = true)

theorem identity10878 : scanCanonicalize (H12AffineFastState.compose env10878 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10878 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10879 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,17,8,1,0,2,17,1,20,1,0,0,16,3,9,16,1,16,16,0,21,1,4,0,1,1]

theorem envBound10879 : H12AffineFastState.Bounded env10879 := by
  intro p hp
  have h : env10879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10878_10879 : H12AffineEnvironment.transform 4 0 env10878 = env10879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10878 == env10879) = true)

theorem identity10879 : scanCanonicalize (H12AffineFastState.compose env10879 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound10879 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10880 : List Nat := [2,1,8,16,0,17,9,1,1,17,1,17,8,1,0,2,17,1,17,1,0,0,16,3,9,16,1,16,16,0,16,1,1,0,1,1]

theorem envBound10880 : H12AffineFastState.Bounded env10880 := by
  intro p hp
  have h : env10880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10879_10880 : H12AffineEnvironment.transform 1 1 env10879 = env10880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env10879 == env10880) = true)

theorem identity10880 : scanCanonicalize (H12AffineFastState.compose env10880 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10880 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10881 : List Nat := [2,1,8,1,0,0,9,1,1,0,1,0,8,1,0,2,0,1,0,1,0,0,1,3,9,1,1,1,1,0,1,1,1,0,1,1]

theorem envBound10881 : H12AffineFastState.Bounded env10881 := by
  intro p hp
  have h : env10881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10880_10881 : H12AffineEnvironment.transform 3 1 env10880 = env10881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10880 == env10881) = true)

def env10882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212078,1024,8660,4160,4194304,16,73736,8328,65,4270243,5393,4096,67755,1501,4194440,256,33,5456,74250]

theorem envBound10882 : H12AffineFastState.Bounded env10882 := by
  intro p hp
  have h : env10882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10866_10882 : H12AffineEnvironment.transform 13 5377 env10866 = env10882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10866 == env10882) = true)

theorem identity10882 : scanCanonicalize (H12AffineFastState.compose env10882 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound10882 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,67619,1024,8660,4160,4194304,16,73736,8328,65,4270243,5393,4096,67755,1501,4194440,256,33,5456,74250]

theorem envBound10883 : H12AffineFastState.Bounded env10883 := by
  intro p hp
  have h : env10883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10882_10883 : H12AffineEnvironment.transform 16 13389 env10882 = env10883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env10882 == env10883) = true)

theorem identity10883 : scanCanonicalize (H12AffineFastState.compose env10883 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10883 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13389,10280,1024,8660,4160,4194304,16,3,8328,65,4196520,5393,4096,10400,1501,4194440,256,33,5456,513]

theorem envBound10884 : H12AffineFastState.Bounded env10884 := by
  intro p hp
  have h : env10884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10883_10884 : H12AffineEnvironment.transform 15 8203 env10883 = env10884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10883 == env10884) = true)

theorem identity10884 : scanCanonicalize (H12AffineFastState.compose env10884 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound10884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13389,10280,1024,8660,4160,112,16,3,8328,65,2264,5393,4096,10400,1501,248,256,33,5456,513]

theorem envBound10885 : H12AffineFastState.Bounded env10885 := by
  intro p hp
  have h : env10885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10884_10885 : H12AffineEnvironment.transform 21 112 env10884 = env10885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env10884 == env10885) = true)

theorem identity10885 : scanCanonicalize (H12AffineFastState.compose env10885 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10885 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,343,5393,2420,1024,136,4160,112,16,3,468,65,2264,5393,4096,2556,1501,248,256,33,5456,513]

theorem envBound10886 : H12AffineFastState.Bounded env10886 := by
  intro p hp
  have h : env10886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10885_10886 : H12AffineEnvironment.transform 12 348 env10885 = env10886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10885 == env10886) = true)

def env10887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,17,98780,8328,65,4270243,5393,17665,108927,1501,4256860,256,21793,46212,74250]

theorem envBound10887 : H12AffineFastState.Bounded env10887 := by
  intro p hp
  have h : env10887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10864_10887 : H12AffineEnvironment.transform 20 4161 env10864 = env10887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10864 == env10887) = true)

theorem identity10887 : scanCanonicalize (H12AffineFastState.compose env10887 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound10887 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,156133,17,98780,8328,65,215366,5393,17665,108927,1501,169401,256,21793,46212,74250]

theorem envBound10888 : H12AffineFastState.Bounded env10888 := by
  intro p hp
  have h : env10888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10887_10888 : H12AffineEnvironment.transform 21 156133 env10887 = env10888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env10887 == env10888) = true)

theorem identity10888 : scanCanonicalize (H12AffineFastState.compose env10888 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10888 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env10889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,2421,1024,32769,4161,66047,17,98780,8328,65,10588,5393,17665,108927,1501,128419,256,21793,46212,74250]

theorem envBound10889 : H12AffineFastState.Bounded env10889 := by
  intro p hp
  have h : env10889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10888_10889 : H12AffineEnvironment.transform 16 90138 env10888 = env10889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10888 == env10889) = true)

theorem identity10889 : scanCanonicalize (H12AffineFastState.compose env10889 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound10889 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,2421,1024,29909,4161,66047,17,95496,8328,65,10588,5393,17665,89515,1501,65911,256,21793,16464,74250]

theorem envBound10890 : H12AffineFastState.Bounded env10890 := by
  intro p hp
  have h : env10890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10889_10890 : H12AffineEnvironment.transform 14 29908 env10889 = env10890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env10889 == env10890) = true)

theorem identity10890 : scanCanonicalize (H12AffineFastState.compose env10890 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10890 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env10891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16401,2421,1024,29909,4161,8692,17,21763,8328,65,10588,5393,17665,32160,1501,8572,256,21793,16464,513]

theorem envBound10891 : H12AffineFastState.Bounded env10891 := by
  intro p hp
  have h : env10891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10890_10891 : H12AffineEnvironment.transform 15 8203 env10890 = env10891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10890 == env10891) = true)

def env10892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270242,5393,17664,2210111,1500,4256860,256,2114913,2139332,74251]

theorem envBound10892 : H12AffineFastState.Bounded env10892 := by
  intro p hp
  have h : env10892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10863_10892 : H12AffineEnvironment.transform 22 2101329 env10863 = env10892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env10863 == env10892) = true)

def env10893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,17,98781,8328,65,4270242,5393,17664,108927,1500,4256860,256,21793,46212,74251]

theorem envBound10893 : H12AffineFastState.Bounded env10893 := by
  intro p hp
  have h : env10893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10892_10893 : H12AffineEnvironment.transform 20 4160 env10892 = env10893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10892 == env10893) = true)

theorem identity10893 : scanCanonicalize (H12AffineFastState.compose env10893 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound10893 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169265,17,98781,8328,65,245139,5393,17664,108927,1500,156013,256,21793,46212,74251]

theorem envBound10894 : H12AffineFastState.Bounded env10894 := by
  intro p hp
  have h : env10894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10893_10894 : H12AffineEnvironment.transform 21 169265 env10893 = env10894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env10893 == env10894) = true)

def env10895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169265,17,98645,8192,65,245019,5393,17664,108927,1364,156013,256,21793,46092,74251]

theorem envBound10895 : H12AffineFastState.Bounded env10895 := by
  intro p hp
  have h : env10895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10894_10895 : H12AffineEnvironment.transform 6 8 env10894 = env10895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10894 == env10895) = true)

theorem identity10895 : scanCanonicalize (H12AffineFastState.compose env10895 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10895 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,169265,17,41311,8192,65,171281,5393,17664,35189,1364,156013,256,21793,46092,513]

theorem envBound10896 : H12AffineFastState.Bounded env10896 := by
  intro p hp
  have h : env10896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10895_10896 : H12AffineEnvironment.transform 15 8202 env10895 = env10896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10895 == env10896) = true)

theorem identity10896 : scanCanonicalize (H12AffineFastState.compose env10896 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10896 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4160,54560,17,41311,8192,65,56576,5393,17664,35189,1364,8572,256,21793,46092,513]

theorem envBound10897 : H12AffineFastState.Bounded env10897 := by
  intro p hp
  have h : env10897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10896_10897 : H12AffineEnvironment.transform 16 16401 env10896 = env10897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10896 == env10897) = true)

theorem identity10897 : scanCanonicalize (H12AffineFastState.compose env10897 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10897 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2420,1024,8541,4160,29820,17,3,8192,65,31836,5393,17664,10281,1364,8572,256,21793,5456,513]

theorem envBound10898 : H12AffineFastState.Bounded env10898 := by
  intro p hp
  have h : env10898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10897_10898 : H12AffineEnvironment.transform 14 8540 env10897 = env10898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10897 == env10898) = true)

theorem identity10898 : scanCanonicalize (H12AffineFastState.compose env10898 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound10898 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8202,13340,2420,1024,8541,4160,113,17,3,8192,65,2129,5393,12557,10281,1364,8572,256,8492,5456,513]

theorem envBound10899 : H12AffineFastState.Bounded env10899 := by
  intro p hp
  have h : env10899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10898_10899 : H12AffineEnvironment.transform 13 13325 env10898 = env10899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env10898 == env10899) = true)

theorem identity10899 : scanCanonicalize (H12AffineFastState.compose env10899 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound10899 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env10900 : List Nat := [2,4,8,16,32,64,8,100,512,1024,2048,4096,8192,13325,8248,8202,13340,2064,1024,8249,4160,113,17,3,8192,65,2129,5237,12393,10281,1072,8216,100,8264,5172,513]

theorem envBound10900 : H12AffineFastState.Bounded env10900 := by
  intro p hp
  have h : env10900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10899_10900 : H12AffineEnvironment.transform 7 100 env10899 = env10900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env10899 == env10900) = true)

theorem identity10900 : scanCanonicalize (H12AffineFastState.compose env10900 (packedSelected [1,4,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10900 : packedSelected [1,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env10901 : List Nat := [2,4,8,16,32,64,8,100,512,52,2048,4096,8192,12345,8248,8202,12328,2064,52,8249,4160,113,17,3,8192,65,2129,4161,12393,10281,4,8216,100,8264,4096,513]

theorem envBound10901 : H12AffineFastState.Bounded env10901 := by
  intro p hp
  have h : env10901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10900_10901 : H12AffineEnvironment.transform 9 52 env10900 = env10901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10900 == env10901) = true)

def env10902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169265,17,98644,8193,65,245018,5393,17664,108927,1365,156013,256,21793,46093,74251]

theorem envBound10902 : H12AffineFastState.Bounded env10902 := by
  intro p hp
  have h : env10902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10894_10902 : H12AffineEnvironment.transform 6 9 env10894 = env10902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10894 == env10902) = true)

theorem identity10902 : scanCanonicalize (H12AffineFastState.compose env10902 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound10902 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4160,169265,17,3,8193,65,146509,5393,17664,10280,1365,156013,256,21793,46093,41820]

theorem envBound10903 : H12AffineFastState.Bounded env10903 := by
  intro p hp
  have h : env10903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10902_10903 : H12AffineEnvironment.transform 15 33111 env10902 = env10903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env10902 == env10903) = true)

theorem identity10903 : scanCanonicalize (H12AffineFastState.compose env10903 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound10903 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env10904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,46108,23588,1024,32769,4160,8493,17,3,8193,65,34897,5393,17664,10280,1365,54641,256,21793,46093,41820]

theorem envBound10904 : H12AffineFastState.Bounded env10904 := by
  intro p hp
  have h : env10904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10903_10904 : H12AffineEnvironment.transform 16 46108 env10903 = env10904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env10903 == env10904) = true)

theorem identity10904 : scanCanonicalize (H12AffineFastState.compose env10904 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound10904 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env10905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,34,13673,23588,1024,372,4160,8493,17,3,8193,65,2340,5393,17664,10280,1365,21508,256,21793,13688,8745]

theorem envBound10905 : H12AffineFastState.Bounded env10905 := by
  intro p hp
  have h : env10905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10904_10905 : H12AffineEnvironment.transform 14 373 env10904 = env10905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env10904 == env10905) = true)

theorem identity10905 : scanCanonicalize (H12AffineFastState.compose env10905 (packedSelected [1,3,4,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10905 : packedSelected [1,3,4,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env10906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,373,34,5392,23588,1024,372,4160,340,17,3,120,65,2340,5393,17664,2129,1365,21508,256,21793,5377,592]

theorem envBound10906 : H12AffineFastState.Bounded env10906 := by
  intro p hp
  have h : env10906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10905_10906 : H12AffineEnvironment.transform 12 121 env10905 = env10906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10905 == env10906) = true)

theorem identity10906 : scanCanonicalize (H12AffineFastState.compose env10906 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound10906 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env10907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5157,373,34,5392,2049,1024,372,4160,340,17,3,120,65,2340,5393,4389,2129,1365,33,256,260,5377,592]

theorem envBound10907 : H12AffineFastState.Bounded env10907 := by
  intro p hp
  have h : env10907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10906_10907 : H12AffineEnvironment.transform 13 5157 env10906 = env10907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env10906 == env10907) = true)

theorem identity10907 : scanCanonicalize (H12AffineFastState.compose env10907 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10907 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10908 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5157,293,34,5392,2049,1024,292,4112,260,17,3,40,17,2340,5393,4389,2049,1285,33,256,260,5377,512]

theorem envBound10908 : H12AffineFastState.Bounded env10908 := by
  intro p hp
  have h : env10908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10907_10908 : H12AffineEnvironment.transform 5 16 env10907 = env10908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10907 == env10908) = true)

theorem identity10908 : scanCanonicalize (H12AffineFastState.compose env10908 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10908 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10909 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,41,5157,32,34,5141,2049,1024,33,4112,1,17,3,40,17,2081,5140,4128,2049,1024,33,5,1,5124,512]

theorem envBound10909 : H12AffineFastState.Bounded env10909 := by
  intro p hp
  have h : env10909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10908_10909 : H12AffineEnvironment.transform 7 5 env10908 = env10909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10908 == env10909) = true)

def env10910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98780,8328,65,4270242,5393,17664,108926,1500,4256860,256,21792,46213,74251]

theorem envBound10910 : H12AffineFastState.Bounded env10910 := by
  intro p hp
  have h : env10910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10892_10910 : H12AffineEnvironment.transform 20 4161 env10892 = env10910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10892 == env10910) = true)

def env10911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98644,8192,65,4270122,5393,17664,108926,1364,4256860,256,21792,46093,74251]

theorem envBound10911 : H12AffineFastState.Bounded env10911 := by
  intro p hp
  have h : env10911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10910_10911 : H12AffineEnvironment.transform 6 8 env10910 = env10911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10910 == env10911) = true)

theorem identity10911 : scanCanonicalize (H12AffineFastState.compose env10911 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound10911 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67618,1024,32769,4161,4194304,16,98644,8192,65,4270122,5393,17664,108926,1364,4256860,256,21792,46093,74251]

theorem envBound10912 : H12AffineFastState.Bounded env10912 := by
  intro p hp
  have h : env10912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10911_10912 : H12AffineEnvironment.transform 16 24909 env10911 = env10912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env10911 == env10912) = true)

theorem identity10912 : scanCanonicalize (H12AffineFastState.compose env10912 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound10912 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env10913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67618,1024,32769,4161,65911,16,98644,8192,65,10589,5393,17664,108926,1364,128299,256,21792,46093,74251]

theorem envBound10913 : H12AffineFastState.Bounded env10913 := by
  intro p hp
  have h : env10913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10912_10913 : H12AffineEnvironment.transform 21 65911 env10912 = env10913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env10912 == env10913) = true)

theorem identity10913 : scanCanonicalize (H12AffineFastState.compose env10913 (packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound10913 : packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS < 2^1333 := by decide +kernel

def env10914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24909,64809,1024,32769,4161,62588,16,29791,8192,65,10589,5393,17664,23669,1364,32,256,21792,46093,55040]

theorem envBound10914 : H12AffineFastState.Bounded env10914 := by
  intro p hp
  have h : env10914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10913_10914 : H12AffineEnvironment.transform 15 62731 env10913 = env10914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env10913 == env10914) = true)

theorem identity10914 : scanCanonicalize (H12AffineFastState.compose env10914 (packedSelected [2,5,6,10,11,12,14,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound10914 : packedSelected [2,5,6,10,11,12,14,20,24] rootPS < 2^1333 := by decide +kernel

def env10915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33031,5441,35109,1024,32769,4161,32880,16,83,8192,65,10589,5393,12556,10361,1364,32,256,8492,46093,41740]

theorem envBound10915 : H12AffineFastState.Bounded env10915 := by
  intro p hp
  have h : env10915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10914_10915 : H12AffineEnvironment.transform 13 13324 env10914 = env10915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env10914 == env10915) = true)

theorem identity10915 : scanCanonicalize (H12AffineFastState.compose env10915 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10915 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env10916 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,32768,33031,5393,35109,1024,32769,4113,32800,16,3,8192,17,10509,5393,12556,10281,1284,32,256,8492,46093,41740]

theorem envBound10916 : H12AffineFastState.Bounded env10916 := by
  intro p hp
  have h : env10916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10915_10916 : H12AffineEnvironment.transform 5 16 env10915 = env10916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10915 == env10916) = true)

theorem identity10916 : scanCanonicalize (H12AffineFastState.compose env10916 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10916 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env10917 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,263,5393,2341,1024,1,4113,32,16,3,8192,17,10509,5393,12556,10281,1284,32,256,8492,13325,8972]

theorem envBound10917 : H12AffineFastState.Bounded env10917 := by
  intro p hp
  have h : env10917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10916_10917 : H12AffineEnvironment.transform 14 0 env10916 = env10917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10916 == env10917) = true)

theorem identity10917 : scanCanonicalize (H12AffineFastState.compose env10917 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound10917 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env10918 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7465,2341,0,263,5393,2341,1024,1,4113,32,16,3,7465,17,5156,5393,3109,5376,1284,32,256,7173,2340,7717]

theorem envBound10918 : H12AffineFastState.Bounded env10918 := by
  intro p hp
  have h : env10918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10917_10918 : H12AffineEnvironment.transform 12 7465 env10917 = env10918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env10917 == env10918) = true)

theorem identity10918 : scanCanonicalize (H12AffineFastState.compose env10918 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound10918 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env10919 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1028,4096,4397,1313,0,263,5393,1313,1024,1,4113,32,16,3,4397,17,5156,5393,33,5376,1284,32,256,4097,1312,4641]

theorem envBound10919 : H12AffineFastState.Bounded env10919 := by
  intro p hp
  have h : env10919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10918_10919 : H12AffineEnvironment.transform 10 1028 env10918 = env10919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env10918 == env10919) = true)

def env10920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98645,8193,65,4270123,5393,17664,108926,1365,4256860,256,21792,46092,74251]

theorem envBound10920 : H12AffineFastState.Bounded env10920 := by
  intro p hp
  have h : env10920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10910_10920 : H12AffineEnvironment.transform 6 9 env10910 = env10920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10910 == env10920) = true)

theorem identity10920 : scanCanonicalize (H12AffineFastState.compose env10920 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound10920 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,108926,1024,32769,4161,4194304,16,98645,8193,65,4270123,5393,17664,108926,1365,4256860,256,21792,46092,74251]

theorem envBound10921 : H12AffineFastState.Bounded env10921 := by
  intro p hp
  have h : env10921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10920_10921 : H12AffineEnvironment.transform 16 49169 env10920 = env10921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env10920 == env10921) = true)

theorem identity10921 : scanCanonicalize (H12AffineFastState.compose env10921 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound10921 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,108926,1024,32769,4161,29741,16,98645,8193,65,89094,5393,17664,108926,1365,32881,256,21792,46092,74251]

theorem envBound10922 : H12AffineFastState.Bounded env10922 := by
  intro p hp
  have h : env10922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10921_10922 : H12AffineEnvironment.transform 21 29741 env10921 = env10922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env10921 == env10922) = true)

theorem identity10922 : scanCanonicalize (H12AffineFastState.compose env10922 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound10922 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env10923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,49169,2421,1024,32769,4161,29741,16,8542,8193,65,64525,5393,17664,2421,1365,32881,256,21792,46092,33280]

theorem envBound10923 : H12AffineFastState.Bounded env10923 := by
  intro p hp
  have h : env10923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10922_10923 : H12AffineEnvironment.transform 15 40971 env10922 = env10923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env10922 == env10923) = true)

theorem identity10923 : scanCanonicalize (H12AffineFastState.compose env10923 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound10923 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,32803,49169,2421,1024,32769,4161,21509,16,374,41,65,56357,5393,17664,2421,1365,32881,256,21792,37924,33280]

theorem envBound10924 : H12AffineFastState.Bounded env10924 := by
  intro p hp
  have h : env10924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10923_10924 : H12AffineEnvironment.transform 12 40 env10923 = env10924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env10923 == env10924) = true)

theorem identity10924 : scanCanonicalize (H12AffineFastState.compose env10924 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10924 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,32803,38160,2421,1024,32769,4161,260,16,374,41,65,35108,5393,4097,2421,1365,32881,256,33,37924,33280]

theorem envBound10925 : H12AffineFastState.Bounded env10925 := by
  intro p hp
  have h : env10925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10924_10925 : H12AffineEnvironment.transform 13 5377 env10924 = env10925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10924 == env10925) = true)

theorem identity10925 : scanCanonicalize (H12AffineFastState.compose env10925 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound10925 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env10926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,372,343,5220,2421,1024,373,4161,260,16,374,41,65,2128,5393,4097,2421,1365,261,256,33,5456,884]

theorem envBound10926 : H12AffineFastState.Bounded env10926 := by
  intro p hp
  have h : env10926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10925_10926 : H12AffineEnvironment.transform 14 372 env10925 = env10926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env10925 == env10926) = true)

theorem identity10926 : scanCanonicalize (H12AffineFastState.compose env10926 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10926 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env10927 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,40,4113,372,343,4468,2421,272,373,4161,260,16,374,41,65,2128,4097,4097,2421,69,261,256,33,4160,884]

theorem envBound10927 : H12AffineFastState.Bounded env10927 := by
  intro p hp
  have h : env10927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10926_10927 : H12AffineEnvironment.transform 9 272 env10926 = env10927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10926 == env10927) = true)

def env10928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound10928 : H12AffineFastState.Bounded env10928 := by
  intro p hp
  have h : env10928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10779_10928 : H12AffineEnvironment.transform 18 1025 env10779 = env10928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10779 == env10928) = true)

theorem identity10928 : scanCanonicalize (H12AffineFastState.compose env10928 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8686063) := by decide +kernel

theorem selectedBound10928 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8686063,8328,65,4409839,10816866,10507601,8830976,331263,15068206,257,2444611,2469095,272937]

theorem envBound10929 : H12AffineFastState.Bounded env10929 := by
  intro p hp
  have h : env10929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10928_10929 : H12AffineEnvironment.transform 23 8686063 env10928 = env10929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8686063 env10928 == env10929) = true)

def env10930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8192,65,4409703,10816866,10507601,8830976,331127,15068206,257,2444611,2468975,272937]

theorem envBound10930 : H12AffineFastState.Bounded env10930 := by
  intro p hp
  have h : env10930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10929_10930 : H12AffineEnvironment.transform 6 8 env10929 = env10930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10929 == env10930) = true)

theorem identity10930 : scanCanonicalize (H12AffineFastState.compose env10930 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 371055) := by decide +kernel

theorem selectedBound10930 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env10931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,371055,73736,8192,65,4409703,2139149,2489406,223599,331127,6309185,257,2444611,2468975,272937]

theorem envBound10931 : H12AffineFastState.Bounded env10931 := by
  intro p hp
  have h : env10931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10930_10931 : H12AffineEnvironment.transform 22 371055 env10930 = env10931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 371055 env10930 == env10931) = true)

theorem identity10931 : scanCanonicalize (H12AffineFastState.compose env10931 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10931 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env10932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,2097152,4194304,297317,2,8192,65,4352365,2139149,2415668,149861,273789,6309185,257,2387273,2395237,272937]

theorem envBound10932 : H12AffineFastState.Bounded env10932 := by
  intro p hp
  have h : env10932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10931_10932 : H12AffineEnvironment.transform 15 8202 env10931 = env10932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10931 == env10932) = true)

theorem identity10932 : scanCanonicalize (H12AffineFastState.compose env10932 (packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10932 : packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,2097152,4194304,297317,2,8192,65,4204924,2139149,2415668,2420,273789,6309185,257,2387273,2395237,272937]

theorem envBound10933 : H12AffineFastState.Bounded env10933 := by
  intro p hp
  have h : env10933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10932_10933 : H12AffineEnvironment.transform 16 16401 env10932 = env10933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10932 == env10933) = true)

theorem identity10933 : scanCanonicalize (H12AffineFastState.compose env10933 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10933 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env10934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,2097152,4194304,41293,2,8192,65,4204924,2139149,2159644,2420,1365,6309185,257,2114913,2139213,513]

theorem envBound10934 : H12AffineFastState.Bounded env10934 := by
  intro p hp
  have h : env10934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10933_10934 : H12AffineEnvironment.transform 17 10280 env10933 = env10934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10933 == env10934) = true)

theorem identity10934 : scanCanonicalize (H12AffineFastState.compose env10934 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound10934 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env10935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,58397,4194304,41293,2,8192,65,4204924,16400,4097,2420,1365,4235612,257,41340,16464,513]

theorem envBound10935 : H12AffineFastState.Bounded env10935 := by
  intro p hp
  have h : env10935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10934_10935 : H12AffineEnvironment.transform 20 58397 env10934 = env10935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env10934 == env10935) = true)

theorem identity10935 : scanCanonicalize (H12AffineFastState.compose env10935 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 24925) := by decide +kernel

theorem selectedBound10935 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,24925,8202,16401,10280,1025,24924,1344,4194304,16400,2,8192,65,4204924,16400,4097,2420,1365,4210689,257,16417,16464,513]

theorem envBound10936 : H12AffineFastState.Bounded env10936 := by
  intro p hp
  have h : env10936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10935_10936 : H12AffineEnvironment.transform 14 24925 env10935 = env10936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24925 env10935 == env10936) = true)

theorem identity10936 : scanCanonicalize (H12AffineFastState.compose env10936 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound10936 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env10937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10508,2129,8202,10525,10280,1025,2128,1344,4194304,10524,2,8192,65,4204924,10524,4097,2420,1365,4204813,257,10541,10588,513]

theorem envBound10937 : H12AffineFastState.Bounded env10937 := by
  intro p hp
  have h : env10937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10936_10937 : H12AffineEnvironment.transform 13 10508 env10936 = env10937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env10936 == env10937) = true)

theorem identity10937 : scanCanonicalize (H12AffineFastState.compose env10937 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 7456) := by decide +kernel

theorem selectedBound10937 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env10938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10508,2129,8202,10525,10280,1025,2128,1344,7456,10524,2,8192,65,13404,10524,4097,2420,1365,13357,257,10541,10588,513]

theorem envBound10938 : H12AffineFastState.Bounded env10938 := by
  intro p hp
  have h : env10938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10937_10938 : H12AffineEnvironment.transform 21 7456 env10937 = env10938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7456 env10937 == env10938) = true)

theorem identity10938 : scanCanonicalize (H12AffineFastState.compose env10938 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound10938 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,8192,10508,2129,8202,10525,10280,1025,2128,1344,3376,10524,2,8192,65,9292,10524,17,2420,1365,9277,257,10541,10588,513]

theorem envBound10939 : H12AffineFastState.Bounded env10939 := by
  intro p hp
  have h : env10939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10938_10939 : H12AffineEnvironment.transform 11 16 env10938 = env10939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10938 == env10939) = true)

theorem identity10939 : scanCanonicalize (H12AffineFastState.compose env10939 (packedSelected [4,9,23] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound10939 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env10940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1053,3345,2129,1047,3328,3125,1025,2128,1344,3376,3329,2,1053,65,81,3329,17,2420,1365,32,257,3376,3393,513]

theorem envBound10940 : H12AffineFastState.Bounded env10940 := by
  intro p hp
  have h : env10940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10939_10940 : H12AffineEnvironment.transform 12 1053 env10939 = env10940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env10939 == env10940) = true)

theorem identity10940 : scanCanonicalize (H12AffineFastState.compose env10940 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound10940 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env10941 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,16,348,2128,2129,342,2113,2420,320,2128,1,2161,2112,2,348,65,81,2112,17,2420,20,32,257,2161,2048,513]

theorem envBound10941 : H12AffineFastState.Bounded env10941 := by
  intro p hp
  have h : env10941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10940_10941 : H12AffineEnvironment.transform 9 321 env10940 = env10941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env10940 == env10941) = true)

theorem identity10941 : scanCanonicalize (H12AffineFastState.compose env10941 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound10941 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10942 : List Nat := [2,4,8,16,32,64,8,256,512,321,372,16,348,292,293,342,309,0,320,292,1,261,308,2,348,65,81,308,17,0,20,32,257,261,372,513]

theorem envBound10942 : H12AffineFastState.Bounded env10942 := by
  intro p hp
  have h : env10942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10941_10942 : H12AffineEnvironment.transform 10 372 env10941 = env10942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env10941 == env10942) = true)

theorem identity10942 : scanCanonicalize (H12AffineFastState.compose env10942 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound10942 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env10943 : List Nat := [2,4,8,16,32,32,8,256,512,289,276,16,316,292,293,310,309,0,288,292,1,261,308,2,316,33,49,308,17,0,20,32,257,261,276,513]

theorem envBound10943 : H12AffineFastState.Bounded env10943 := by
  intro p hp
  have h : env10943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10942_10943 : H12AffineEnvironment.transform 5 32 env10942 = env10943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env10942 == env10943) = true)

theorem identity10943 : scanCanonicalize (H12AffineFastState.compose env10943 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10943 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10944 : List Nat := [2,4,8,16,16,16,8,256,512,273,276,16,268,276,277,262,261,0,272,276,1,261,260,2,268,17,1,260,17,0,20,16,257,261,276,513]

theorem envBound10944 : H12AffineFastState.Bounded env10944 := by
  intro p hp
  have h : env10944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10943_10944 : H12AffineEnvironment.transform 4 16 env10943 = env10944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10943 == env10944) = true)

theorem identity10944 : scanCanonicalize (H12AffineFastState.compose env10944 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10944 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10945 : List Nat := [2,4,8,16,16,16,8,256,0,273,276,16,268,276,277,262,261,0,272,276,1,261,260,2,268,17,1,260,17,0,20,16,257,261,276,1]

theorem envBound10945 : H12AffineFastState.Bounded env10945 := by
  intro p hp
  have h : env10945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10944_10945 : H12AffineEnvironment.transform 8 0 env10944 = env10945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10944 == env10945) = true)

theorem identity10945 : scanCanonicalize (H12AffineFastState.compose env10945 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound10945 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10946 : List Nat := [2,4,8,16,16,16,8,21,0,4,1,16,25,1,0,19,16,0,5,1,1,16,17,2,25,17,1,17,17,0,20,16,20,16,1,1]

theorem envBound10946 : H12AffineFastState.Bounded env10946 := by
  intro p hp
  have h : env10946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10945_10946 : H12AffineEnvironment.transform 7 21 env10945 = env10946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env10945 == env10946) = true)

def env10947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4409702,10816866,10507601,8830976,331126,15068206,257,2444611,2468974,272937]

theorem envBound10947 : H12AffineFastState.Bounded env10947 := by
  intro p hp
  have h : env10947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10929_10947 : H12AffineEnvironment.transform 6 9 env10929 = env10947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10929 == env10947) = true)

def env10948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4262262,10816866,10507601,8683536,331126,15068206,257,2444611,2468974,272937]

theorem envBound10948 : H12AffineFastState.Bounded env10948 := by
  intro p hp
  have h : env10948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10947_10948 : H12AffineEnvironment.transform 16 16400 env10947 = env10948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10947 == env10948) = true)

theorem identity10948 : scanCanonicalize (H12AffineFastState.compose env10948 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10948 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429902,8193,65,4262262,10560842,10507601,8431672,75102,14795782,257,2188651,2196550,513]

theorem envBound10949 : H12AffineFastState.Bounded env10949 := by
  intro p hp
  have h : env10949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10948_10949 : H12AffineEnvironment.transform 17 10280 env10948 = env10949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10948 == env10949) = true)

def env10950 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429854,8193,17,4262182,10560794,10507521,8431672,75022,14795782,257,2188603,2196502,513]

theorem envBound10950 : H12AffineFastState.Bounded env10950 := by
  intro p hp
  have h : env10950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10949_10950 : H12AffineEnvironment.transform 5 16 env10949 = env10950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10949 == env10950) = true)

theorem identity10950 : scanCanonicalize (H12AffineFastState.compose env10950 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4292918) := by decide +kernel

theorem selectedBound10950 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env10951 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4292918,4268072,8193,17,4262182,6333484,6411319,4270350,75022,2114864,257,2188603,2196502,513]

theorem envBound10951 : H12AffineFastState.Bounded env10951 := by
  intro p hp
  have h : env10951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10950_10951 : H12AffineEnvironment.transform 22 4292918 env10950 = env10951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292918 env10950 == env10951) = true)

theorem identity10951 : scanCanonicalize (H12AffineFastState.compose env10951 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound10951 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env10952 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,8492,106522,65796,8193,17,75786,2131200,2225435,67618,75022,2114864,257,2188603,2196502,513]

theorem envBound10952 : H12AffineFastState.Bounded env10952 := by
  intro p hp
  have h : env10952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10951_10952 : H12AffineEnvironment.transform 21 8492 env10951 = env10952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env10951 == env10952) = true)

theorem identity10952 : scanCanonicalize (H12AffineFastState.compose env10952 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound10952 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10953 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,50449,8492,106522,65796,8193,17,75786,16401,77834,67618,75022,32801,257,106538,82183,513]

theorem envBound10953 : H12AffineFastState.Bounded env10953 := by
  intro p hp
  have h : env10953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10952_10953 : H12AffineEnvironment.transform 20 50449 env10952 = env10953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env10952 == env10953) = true)

theorem identity10953 : scanCanonicalize (H12AffineFastState.compose env10953 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound10953 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10954 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1025,32769,50449,8492,16,41230,8193,17,34816,16401,36864,43048,34052,32801,257,32,57613,513]

theorem envBound10954 : H12AffineFastState.Bounded env10954 := by
  intro p hp
  have h : env10954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10953_10954 : H12AffineEnvironment.transform 15 40970 env10953 = env10954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env10953 == env10954) = true)

theorem identity10954 : scanCanonicalize (H12AffineFastState.compose env10954 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10954 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10955 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,33031,16400,2341,1025,32769,50449,33,16,32771,268,17,34816,16401,36864,35109,34052,32801,257,32,49152,513]

theorem envBound10955 : H12AffineFastState.Bounded env10955 := by
  intro p hp
  have h : env10955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10954_10955 : H12AffineEnvironment.transform 12 269 env10954 = env10955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10954 == env10955) = true)

theorem identity10955 : scanCanonicalize (H12AffineFastState.compose env10955 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10955 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10956 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,262,16400,2341,1025,0,17680,33,16,2,268,17,2049,16401,4097,2340,1285,32,257,32,16385,513]

theorem envBound10956 : H12AffineFastState.Bounded env10956 := by
  intro p hp
  have h : env10956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10955_10956 : H12AffineEnvironment.transform 14 1 env10955 = env10956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10955 == env10956) = true)

theorem identity10956 : scanCanonicalize (H12AffineFastState.compose env10956 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound10956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10957 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1312,269,16384,1,262,16400,2341,1025,0,17680,33,16,2,268,17,2049,16401,1313,2340,1285,32,257,32,16385,513]

theorem envBound10957 : H12AffineFastState.Bounded env10957 := by
  intro p hp
  have h : env10957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10956_10957 : H12AffineEnvironment.transform 11 1312 env10956 = env10957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env10956 == env10957) = true)

theorem identity10957 : scanCanonicalize (H12AffineFastState.compose env10957 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound10957 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10958 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1556,1312,269,16384,1,262,16400,1841,1025,0,17680,33,16,2,268,17,1557,16401,1313,1840,1285,32,257,32,16385,513]

theorem envBound10958 : H12AffineFastState.Bounded env10958 := by
  intro p hp
  have h : env10958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10957_10958 : H12AffineEnvironment.transform 10 1556 env10957 = env10958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env10957 == env10958) = true)

theorem identity10958 : scanCanonicalize (H12AffineFastState.compose env10958 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound10958 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10959 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1556,1312,269,1028,1,262,1044,1841,1025,0,276,33,16,2,268,17,1557,1045,1313,1840,1285,32,257,32,1029,513]

theorem envBound10959 : H12AffineFastState.Bounded env10959 := by
  intro p hp
  have h : env10959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10958_10959 : H12AffineEnvironment.transform 13 1028 env10958 = env10959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env10958 == env10959) = true)

def env10960 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429855,8193,16,4262183,10560795,10507520,8431672,75023,14795782,257,2188602,2196503,513]

theorem envBound10960 : H12AffineFastState.Bounded env10960 := by
  intro p hp
  have h : env10960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10949_10960 : H12AffineEnvironment.transform 5 17 env10949 = env10960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10949 == env10960) = true)

theorem identity10960 : scanCanonicalize (H12AffineFastState.compose env10960 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4235580) := by decide +kernel

theorem selectedBound10960 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env10961 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4235580,4194339,8193,16,4262183,6390823,6353980,4196612,75023,2188602,257,2188602,2196503,513]

theorem envBound10961 : H12AffineFastState.Bounded env10961 := by
  intro p hp
  have h : env10961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10960_10961 : H12AffineEnvironment.transform 22 4235580 env10960 = env10961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235580 env10960 == env10961) = true)

theorem identity10961 : scanCanonicalize (H12AffineFastState.compose env10961 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound10961 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env10962 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,41260,16,41231,8193,16,108555,2172171,2118928,43048,75023,2188602,257,2188602,2196503,513]

theorem envBound10962 : H12AffineFastState.Bounded env10962 := by
  intro p hp
  have h : env10962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10961_10962 : H12AffineEnvironment.transform 21 41260 env10961 = env10962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env10961 == env10962) = true)

theorem identity10962 : scanCanonicalize (H12AffineFastState.compose env10962 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10962 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10963 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1025,32769,2097152,41260,16,41231,8193,16,34816,2098432,2118928,43048,1284,2114865,257,2114865,2139164,513]

theorem envBound10963 : H12AffineFastState.Bounded env10963 := by
  intro p hp
  have h : env10963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10962_10963 : H12AffineEnvironment.transform 15 8203 env10962 = env10963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10962 == env10963) = true)

theorem identity10963 : scanCanonicalize (H12AffineFastState.compose env10963 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10963 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10964 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10280,1025,0,2097152,8493,16,8462,8193,16,2049,2098432,2118928,10281,1284,2114865,257,2114865,2106397,513]

theorem envBound10964 : H12AffineFastState.Bounded env10964 := by
  intro p hp
  have h : env10964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10963_10964 : H12AffineEnvironment.transform 14 1 env10963 = env10964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10963 == env10964) = true)

theorem identity10964 : scanCanonicalize (H12AffineFastState.compose env10964 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10964 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10965 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,262,16400,2341,1025,0,2097152,32,16,3,268,16,2049,2098432,2118928,2340,1284,2114865,257,2114865,2098448,513]

theorem envBound10965 : H12AffineFastState.Bounded env10965 := by
  intro p hp
  have h : env10965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10964_10965 : H12AffineEnvironment.transform 12 269 env10964 = env10965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10964 == env10965) = true)

theorem identity10965 : scanCanonicalize (H12AffineFastState.compose env10965 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound10965 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10966 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,269,16384,1,262,16400,1296,1025,0,2097152,32,16,3,268,16,1076,2098432,2118928,1297,1284,2114865,257,2114865,2098448,513]

theorem envBound10966 : H12AffineFastState.Bounded env10966 := by
  intro p hp
  have h : env10966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10965_10966 : H12AffineEnvironment.transform 10 1077 env10965 = env10966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env10965 == env10966) = true)

theorem identity10966 : scanCanonicalize (H12AffineFastState.compose env10966 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(20+1) ^^^ 5157) := by decide +kernel

theorem selectedBound10966 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10967 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,269,16384,1,262,16400,1296,1025,0,5157,32,16,3,268,16,1076,4389,16693,1297,1284,20756,257,20756,4405,513]

theorem envBound10967 : H12AffineFastState.Bounded env10967 := by
  intro p hp
  have h : env10967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10966_10967 : H12AffineEnvironment.transform 20 5157 env10966 = env10967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5157 env10966 == env10967) = true)

theorem identity10967 : scanCanonicalize (H12AffineFastState.compose env10967 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound10967 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10968 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,269,293,1,262,309,1296,1025,0,5157,32,16,3,268,16,1076,4389,16,1297,1284,4145,257,4145,4405,513]

theorem envBound10968 : H12AffineFastState.Bounded env10968 := by
  intro p hp
  have h : env10968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10967_10968 : H12AffineEnvironment.transform 13 293 env10967 = env10968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env10967 == env10968) = true)

theorem identity10968 : scanCanonicalize (H12AffineFastState.compose env10968 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound10968 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env10969 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,1060,269,293,1,262,309,1296,1025,0,1,32,16,3,268,16,1076,1281,16,1297,1284,1045,257,1045,1297,513]

theorem envBound10969 : H12AffineFastState.Bounded env10969 := by
  intro p hp
  have h : env10969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10968_10969 : H12AffineEnvironment.transform 11 1060 env10968 = env10969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env10968 == env10969) = true)

theorem identity10969 : scanCanonicalize (H12AffineFastState.compose env10969 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10969 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10970 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,1060,40,0,1,35,16,1077,1025,0,1,32,16,3,41,16,1076,1060,16,1076,1057,1045,36,1045,1076,513]

theorem envBound10970 : H12AffineFastState.Bounded env10970 := by
  intro p hp
  have h : env10970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10969_10970 : H12AffineEnvironment.transform 7 37 env10969 = env10970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10969 == env10970) = true)

theorem identity10970 : scanCanonicalize (H12AffineFastState.compose env10970 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10970 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10971 : List Nat := [2,4,8,16,32,17,9,37,512,53,0,17,40,0,1,35,16,0,52,0,1,32,16,3,41,16,1,17,16,1,20,32,36,32,1,513]

theorem envBound10971 : H12AffineFastState.Bounded env10971 := by
  intro p hp
  have h : env10971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10970_10971 : H12AffineEnvironment.transform 9 53 env10970 = env10971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10970 == env10971) = true)

theorem identity10971 : scanCanonicalize (H12AffineFastState.compose env10971 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10972 : List Nat := [2,4,8,16,17,17,9,20,512,4,0,17,25,0,1,18,16,0,5,0,1,17,16,3,24,16,1,17,16,1,20,17,21,17,1,513]

theorem envBound10972 : H12AffineFastState.Bounded env10972 := by
  intro p hp
  have h : env10972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10971_10972 : H12AffineEnvironment.transform 4 17 env10971 = env10972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10971 == env10972) = true)

theorem identity10972 : scanCanonicalize (H12AffineFastState.compose env10972 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10973 : List Nat := [2,4,8,1,0,0,9,5,512,4,0,0,8,0,1,3,1,0,5,0,1,0,1,3,9,1,1,0,1,1,5,0,4,0,1,513]

theorem envBound10973 : H12AffineFastState.Bounded env10973 := by
  intro p hp
  have h : env10973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10972_10973 : H12AffineEnvironment.transform 3 1 env10972 = env10973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10972 == env10973) = true)

def env10974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4262263,10816866,10507601,8683537,331126,15068206,257,2444611,2468974,272937]

theorem envBound10974 : H12AffineFastState.Bounded env10974 := by
  intro p hp
  have h : env10974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10947_10974 : H12AffineEnvironment.transform 16 16401 env10947 = env10974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10947 == env10974) = true)

def env10975 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685878,8193,17,4262183,10816818,10507521,8683537,331046,15068206,257,2444563,2468926,272937]

theorem envBound10975 : H12AffineFastState.Bounded env10975 := by
  intro p hp
  have h : env10975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10974_10975 : H12AffineEnvironment.transform 5 16 env10974 = env10975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10974 == env10975) = true)

def env10976 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,8388608,8685878,8193,17,4262183,10815490,10506289,8683537,329750,15067422,257,2443299,2468110,272937]

theorem envBound10976 : H12AffineFastState.Bounded env10976 := by
  intro p hp
  have h : env10976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10975_10976 : H12AffineEnvironment.transform 9 304 env10975 = env10976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env10975 == env10976) = true)

theorem identity10976 : scanCanonicalize (H12AffineFastState.compose env10976 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4466712) := by decide +kernel

theorem selectedBound10976 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env10977 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,16401,262144,305,32769,2097152,4194304,4466712,4235566,8193,17,4262183,6365210,6584361,4237321,329750,2212102,257,2443299,2468110,272937]

theorem envBound10977 : H12AffineFastState.Bounded env10977 := by
  intro p hp
  have h : env10977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10976_10977 : H12AffineEnvironment.transform 22 4466712 env10976 = env10977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4466712 env10976 == env10977) = true)

def env10978 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,8192,16384,32768,65536,16401,262144,273,32769,2097152,4194304,4466712,4235534,8193,17,4262151,6365210,6584329,4237321,329750,2212102,257,2443267,2468110,272905]

theorem envBound10978 : H12AffineFastState.Bounded env10978 := by
  intro p hp
  have h : env10978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10977_10978 : H12AffineEnvironment.transform 4 0 env10977 = env10978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10977 == env10978) = true)

theorem identity10978 : scanCanonicalize (H12AffineFastState.compose env10978 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10978 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env10979 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,262144,273,32769,2097152,4194304,4458772,4227074,269,17,4262151,6357270,6576389,4229381,329750,2212102,257,2443267,2459650,264965]

theorem envBound10979 : H12AffineFastState.Bounded env10979 := by
  intro p hp
  have h : env10979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10978_10979 : H12AffineEnvironment.transform 12 268 env10978 = env10979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10978 == env10979) = true)

theorem identity10979 : scanCanonicalize (H12AffineFastState.compose env10979 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 280837) := by decide +kernel

theorem selectedBound10979 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env10980 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,262144,273,32769,280837,4194304,4458772,4227074,269,17,4262151,4540435,4198400,4229381,329750,362499,257,65798,114951,264965]

theorem envBound10980 : H12AffineFastState.Bounded env10980 := by
  intro p hp
  have h : env10980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10979_10980 : H12AffineEnvironment.transform 20 280837 env10979 = env10980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 280837 env10979 == env10980) = true)

theorem identity10980 : scanCanonicalize (H12AffineFastState.compose env10980 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 362498) := by decide +kernel

theorem selectedBound10980 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10981 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,262144,273,32769,280837,362498,98582,329728,269,17,295173,49169,366594,327943,329750,362499,257,65798,114951,264965]

theorem envBound10981 : H12AffineFastState.Bounded env10981 := by
  intro p hp
  have h : env10981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10980_10981 : H12AffineEnvironment.transform 21 362498 env10980 = env10981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362498 env10980 == env10981) = true)

theorem identity10981 : scanCanonicalize (H12AffineFastState.compose env10981 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound10981 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10982 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,65536,16401,2309,273,32769,16384,98567,98582,65797,269,17,34816,49169,102663,67586,65811,98566,257,65798,114951,512]

theorem envBound10982 : H12AffineFastState.Bounded env10982 := by
  intro p hp
  have h : env10982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10981_10982 : H12AffineEnvironment.transform 17 2309 env10981 = env10982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env10981 == env10982) = true)

theorem identity10982 : scanCanonicalize (H12AffineFastState.compose env10982 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound10982 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10983 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,32768,33030,16401,2309,273,32769,16384,1,16,32771,269,17,34816,49169,4097,35076,32789,0,257,32768,16385,512]

theorem envBound10983 : H12AffineFastState.Bounded env10983 := by
  intro p hp
  have h : env10983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10982_10983 : H12AffineEnvironment.transform 15 33030 env10982 = env10983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env10982 == env10983) = true)

theorem identity10983 : scanCanonicalize (H12AffineFastState.compose env10983 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10983 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10984 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,4096,268,16384,0,262,16401,2309,273,1,16384,1,16,3,269,17,2048,16401,4097,2308,21,0,257,0,16385,512]

theorem envBound10984 : H12AffineFastState.Bounded env10984 := by
  intro p hp
  have h : env10984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10983_10984 : H12AffineEnvironment.transform 14 0 env10983 = env10984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10983 == env10984) = true)

def env10985 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,32768,65536,16401,262144,272,32769,2097152,4194304,4466712,4235535,8193,17,4262150,6365210,6584328,4237321,329750,2212102,257,2443266,2468110,272904]

theorem envBound10985 : H12AffineFastState.Bounded env10985 := by
  intro p hp
  have h : env10985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10977_10985 : H12AffineEnvironment.transform 4 1 env10977 = env10985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10977 == env10985) = true)

theorem identity10985 : scanCanonicalize (H12AffineFastState.compose env10985 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound10985 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env10986 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,32768,65536,16401,2309,272,32769,2097152,4194304,4202781,4235535,8193,17,4262150,6365210,6320397,4237321,65811,2212102,257,2179335,2203659,8973]

theorem envBound10986 : H12AffineFastState.Bounded env10986 := by
  intro p hp
  have h : env10986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10985_10986 : H12AffineEnvironment.transform 17 2309 env10985 = env10986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env10985 == env10986) = true)

theorem identity10986 : scanCanonicalize (H12AffineFastState.compose env10986 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 122890) := by decide +kernel

theorem selectedBound10986 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env10987 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,32768,65536,16401,2309,272,32769,122890,4194304,4202781,4235535,8193,17,4262150,4243472,4296967,4237321,65811,8460,257,41229,16385,8973]

theorem envBound10987 : H12AffineFastState.Bounded env10987 := by
  intro p hp
  have h : env10987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10986_10987 : H12AffineEnvironment.transform 20 122890 env10986 = env10987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 122890 env10986 == env10987) = true)

theorem identity10987 : scanCanonicalize (H12AffineFastState.compose env10987 (packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10987 : packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env10988 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,0,65536,16401,2309,272,1,90122,4194304,4202781,4202767,8193,17,4262150,4210704,4264199,4204553,65811,8460,257,8461,16385,8973]

theorem envBound10988 : H12AffineFastState.Bounded env10988 := by
  intro p hp
  have h : env10988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10987_10988 : H12AffineEnvironment.transform 14 0 env10987 = env10988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10987 == env10988) = true)

theorem identity10988 : scanCanonicalize (H12AffineFastState.compose env10988 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(21+1) ^^^ 65798) := by decide +kernel

theorem selectedBound10988 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env10989 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,16384,0,65536,16401,2309,272,1,90122,65798,73755,73737,8193,17,2048,82198,4097,76047,65811,8460,257,8461,16385,8973]

theorem envBound10989 : H12AffineFastState.Bounded env10989 := by
  intro p hp
  have h : env10989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10988_10989 : H12AffineEnvironment.transform 21 65798 env10988 = env10989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65798 env10988 == env10989) = true)

theorem identity10989 : scanCanonicalize (H12AffineFastState.compose env10989 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound10989 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env10990 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8192,4372,0,65536,4357,2309,272,1,78110,65798,73755,73737,8193,17,2048,69634,4097,76047,65811,8460,257,8461,4373,8973]

theorem envBound10990 : H12AffineFastState.Bounded env10990 := by
  intro p hp
  have h : env10990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10989_10990 : H12AffineEnvironment.transform 13 4372 env10989 = env10990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env10989 == env10990) = true)

theorem identity10990 : scanCanonicalize (H12AffineFastState.compose env10990 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound10990 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env10991 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,6168,4372,0,65536,4357,2309,272,1,67846,65798,71683,71697,6169,17,2048,69634,4097,69911,65811,6420,257,6421,4373,6933]

theorem envBound10991 : H12AffineFastState.Bounded env10991 := by
  intro p hp
  have h : env10991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10990_10991 : H12AffineEnvironment.transform 12 6168 env10990 = env10991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env10990 == env10991) = true)

theorem identity10991 : scanCanonicalize (H12AffineFastState.compose env10991 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 4375) := by decide +kernel

theorem selectedBound10991 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10992 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,6168,4372,0,4375,4357,2309,272,1,6161,4113,2324,2310,6169,17,2048,277,4097,0,4100,6420,257,6421,4373,6933]

theorem envBound10992 : H12AffineFastState.Bounded env10992 := by
  intro p hp
  have h : env10992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10991_10992 : H12AffineEnvironment.transform 15 4375 env10991 = env10992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4375 env10991 == env10992) = true)

theorem identity10992 : scanCanonicalize (H12AffineFastState.compose env10992 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound10992 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10993 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,2325,269,2049,0,2050,2064,2309,272,1,260,2308,2324,2310,268,17,2048,277,2324,0,2321,1,257,0,2048,512]

theorem envBound10993 : H12AffineFastState.Bounded env10993 := by
  intro p hp
  have h : env10993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10992_10993 : H12AffineEnvironment.transform 11 2325 env10992 = env10993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env10992 == env10993) = true)

theorem identity10993 : scanCanonicalize (H12AffineFastState.compose env10993 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound10993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0