import H12CloudChart0Data227

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound57797 : H12AffineFastState.Bounded env57797 := by
  intro p hp
  have h : env57797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57796_57797 : H12AffineEnvironment.transform 12 5300 env57796 = env57797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env57796 == env57797) = true)

theorem identity57797 : scanCanonicalize (H12AffineFastState.compose env57797 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound57797 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,3839,1344,1109,2689,3815,10,1024,1109,493,1393,3866,1143,3703,16,131,1344,3766,3189,3747,3678,257,168,3815,513]

theorem envBound57798 : H12AffineFastState.Bounded env57798 := by
  intro p hp
  have h : env57798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57797_57798 : H12AffineEnvironment.transform 11 2635 env57797 = env57798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env57797 == env57798) = true)

theorem identity57798 : scanCanonicalize (H12AffineFastState.compose env57798 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57798 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57799 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2586,3758,1297,1028,2689,3766,10,1024,1028,444,1312,3866,1062,3622,16,131,1297,3766,3108,3747,3599,257,168,3766,513]

theorem envBound57799 : H12AffineFastState.Bounded env57799 := by
  intro p hp
  have h : env57799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57798_57799 : H12AffineEnvironment.transform 5 17 env57798 = env57799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57798 == env57799) = true)

theorem identity57799 : scanCanonicalize (H12AffineFastState.compose env57799 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound57799 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57800 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1703,1213,9,1297,1028,1062,17,10,1024,1028,444,1312,445,1062,129,16,131,1297,17,643,4,168,257,168,17,513]

theorem envBound57800 : H12AffineFastState.Bounded env57800 := by
  intro p hp
  have h : env57800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57799_57800 : H12AffineEnvironment.transform 10 1703 env57799 = env57800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env57799 == env57800) = true)

theorem identity57800 : scanCanonicalize (H12AffineFastState.compose env57800 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound57800 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57801 : List Nat := [2,4,8,16,32,17,128,256,512,548,131,665,9,821,544,514,17,10,548,544,444,772,445,514,129,16,131,821,17,643,4,168,257,168,17,513]

theorem envBound57801 : H12AffineFastState.Bounded env57801 := by
  intro p hp
  have h : env57801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57800_57801 : H12AffineEnvironment.transform 9 548 env57800 = env57801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env57800 == env57801) = true)

theorem identity57801 : scanCanonicalize (H12AffineFastState.compose env57801 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound57801 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env57802 : List Nat := [2,4,8,16,32,17,128,256,396,424,131,277,9,185,428,398,17,10,424,428,444,136,445,398,129,16,131,185,17,271,4,168,257,168,17,397]

theorem envBound57802 : H12AffineFastState.Bounded env57802 := by
  intro p hp
  have h : env57802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57801_57802 : H12AffineEnvironment.transform 8 396 env57801 = env57802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env57801 == env57802) = true)

theorem identity57802 : scanCanonicalize (H12AffineFastState.compose env57802 (packedSelected [1,2,3,4,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound57802 : packedSelected [1,2,3,4,9,10] rootPS < 2^1333 := by decide +kernel

def env57803 : List Nat := [2,4,8,16,32,17,128,4,136,172,131,17,9,185,168,138,17,10,172,168,184,136,185,138,129,16,131,185,17,11,4,168,5,168,17,137]

theorem envBound57803 : H12AffineFastState.Bounded env57803 := by
  intro p hp
  have h : env57803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57802_57803 : H12AffineEnvironment.transform 7 4 env57802 = env57803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57802 == env57803) = true)

theorem identity57803 : scanCanonicalize (H12AffineFastState.compose env57803 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57803 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57804 : List Nat := [2,4,8,16,32,17,8,4,0,36,11,17,9,49,32,2,17,10,36,32,48,0,49,2,9,16,11,49,17,11,4,32,5,32,17,1]

theorem envBound57804 : H12AffineFastState.Bounded env57804 := by
  intro p hp
  have h : env57804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57803_57804 : H12AffineEnvironment.transform 6 8 env57803 = env57804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57803 == env57804) = true)

theorem identity57804 : scanCanonicalize (H12AffineFastState.compose env57804 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound57804 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57805 : List Nat := [2,4,8,16,25,17,8,4,0,29,11,17,9,8,25,2,17,10,29,25,9,0,8,2,9,16,11,8,17,11,4,25,5,25,17,1]

theorem envBound57805 : H12AffineFastState.Bounded env57805 := by
  intro p hp
  have h : env57805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57804_57805 : H12AffineEnvironment.transform 4 25 env57804 = env57805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env57804 == env57805) = true)

theorem identity57805 : scanCanonicalize (H12AffineFastState.compose env57805 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57805 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57806 : List Nat := [1,4,8,16,25,17,8,4,0,29,8,17,9,8,25,1,17,9,29,25,9,0,8,1,9,16,8,8,17,8,4,25,5,25,17,1]

theorem envBound57806 : H12AffineFastState.Bounded env57806 := by
  intro p hp
  have h : env57806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57805_57806 : H12AffineEnvironment.transform 0 1 env57805 = env57806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57805 == env57806) = true)

theorem identity57806 : scanCanonicalize (H12AffineFastState.compose env57806 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57806 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57807 : List Nat := [1,4,8,0,9,1,8,4,0,13,8,1,9,8,9,1,1,9,13,9,9,0,8,1,9,0,8,8,1,8,4,9,5,9,1,1]

theorem envBound57807 : H12AffineFastState.Bounded env57807 := by
  intro p hp
  have h : env57807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57806_57807 : H12AffineEnvironment.transform 3 0 env57806 = env57807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57806 == env57807) = true)

def env57808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,65536,131072,69825,1024,12513,136513,1393,144713,140399,8329,139273,75005,1345,131153,75786,200846,206022,257,69730,131072,512]

theorem envBound57808 : H12AffineFastState.Bounded env57808 := by
  intro p hp
  have h : env57808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57793_57808 : H12AffineEnvironment.transform 13 1345 env57793 = env57808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57793 == env57808) = true)

theorem identity57808 : scanCanonicalize (H12AffineFastState.compose env57808 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57808 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,9712,65536,131072,67024,1024,9712,131152,1393,139352,140399,8329,139273,75005,1345,131153,75786,198047,206022,257,66931,131072,512]

theorem envBound57809 : H12AffineFastState.Bounded env57809 := by
  intro p hp
  have h : env57809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57808_57809 : H12AffineEnvironment.transform 11 1297 env57808 = env57809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57808 == env57809) = true)

def env57810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144713,169102,26056,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57810 : H12AffineFastState.Bounded env57810 := by
  intro p hp
  have h : env57810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57791_57810 : H12AffineEnvironment.transform 17 87425 env57791 = env57810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57791 == env57810) = true)

theorem identity57810 : scanCanonicalize (H12AffineFastState.compose env57810 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 30113) := by decide +kernel

theorem selectedBound57810 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,65536,131072,87425,1024,30113,136513,16433,144713,155951,26056,157000,90556,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57811 : H12AffineFastState.Bounded env57811 := by
  intro p hp
  have h : env57811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57810_57811 : H12AffineEnvironment.transform 14 30113 env57810 = env57811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30113 env57810 == env57811) = true)

def env57812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,65536,131072,69825,1024,12513,136513,1393,144713,140399,8328,139272,75004,1344,131153,75787,200846,206023,257,69730,131072,513]

theorem envBound57812 : H12AffineFastState.Bounded env57812 := by
  intro p hp
  have h : env57812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57811_57812 : H12AffineEnvironment.transform 13 1344 env57811 = env57812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57811 == env57812) = true)

theorem identity57812 : scanCanonicalize (H12AffineFastState.compose env57812 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound57812 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,9342,131072,13503,1024,12513,136513,1393,144713,140399,8328,139272,130,1344,131153,3189,144624,131257,257,13340,131072,513]

theorem envBound57813 : H12AffineFastState.Bounded env57813 := by
  intro p hp
  have h : env57813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57812_57813 : H12AffineEnvironment.transform 15 9342 env57812 = env57813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env57812 == env57813) = true)

theorem identity57813 : scanCanonicalize (H12AffineFastState.compose env57813 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound57813 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,9342,8216,13503,1024,12513,13657,1393,5457,1143,8328,16,130,1344,8265,3189,5352,8353,257,13340,8216,513]

theorem envBound57814 : H12AffineFastState.Bounded env57814 := by
  intro p hp
  have h : env57814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57813_57814 : H12AffineEnvironment.transform 16 8216 env57813 = env57814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env57813 == env57814) = true)

theorem identity57814 : scanCanonicalize (H12AffineFastState.compose env57814 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound57814 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1109,4298,5292,11,1024,1109,493,1393,5457,1143,5180,16,130,1344,5373,3189,5352,5141,257,168,5292,513]

theorem envBound57815 : H12AffineFastState.Bounded env57815 := by
  intro p hp
  have h : env57815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57814_57815 : H12AffineEnvironment.transform 12 5300 env57814 = env57815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env57814 == env57815) = true)

theorem identity57815 : scanCanonicalize (H12AffineFastState.compose env57815 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound57815 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,3839,1344,1109,2689,3815,11,1024,1109,493,1393,3866,1143,3703,16,130,1344,3766,3189,3747,3678,257,168,3815,513]

theorem envBound57816 : H12AffineFastState.Bounded env57816 := by
  intro p hp
  have h : env57816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57815_57816 : H12AffineEnvironment.transform 11 2635 env57815 = env57816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env57815 == env57816) = true)

theorem identity57816 : scanCanonicalize (H12AffineFastState.compose env57816 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57816 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,1344,500,1344,1109,1418,492,11,1024,1109,493,1393,17,1143,380,16,130,1344,445,894,424,341,257,168,492,513]

theorem envBound57817 : H12AffineFastState.Bounded env57817 := by
  intro p hp
  have h : env57817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57816_57817 : H12AffineEnvironment.transform 10 1803 env57816 = env57817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57816 == env57817) = true)

theorem identity57817 : scanCanonicalize (H12AffineFastState.compose env57817 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound57817 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57818 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1782,1213,9,1213,1109,1143,17,11,1024,1109,16,1164,17,1143,129,16,130,1213,64,643,85,168,252,168,17,513]

theorem envBound57818 : H12AffineFastState.Bounded env57818 := by
  intro p hp
  have h : env57818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57817_57818 : H12AffineEnvironment.transform 7 253 env57817 = env57818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env57817 == env57818) = true)

theorem identity57818 : scanCanonicalize (H12AffineFastState.compose env57818 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound57818 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57819 : List Nat := [2,4,8,16,32,64,128,253,512,548,210,665,9,665,625,595,17,11,548,625,16,680,17,595,129,16,130,665,64,643,85,168,252,168,17,513]

theorem envBound57819 : H12AffineFastState.Bounded env57819 := by
  intro p hp
  have h : env57819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57818_57819 : H12AffineEnvironment.transform 9 548 env57818 = env57819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env57818 == env57819) = true)

theorem identity57819 : scanCanonicalize (H12AffineFastState.compose env57819 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57819 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57820 : List Nat := [2,4,8,16,32,64,128,253,136,172,210,17,9,17,249,219,17,11,172,249,16,32,17,219,129,16,130,17,64,11,85,168,252,168,17,137]

theorem envBound57820 : H12AffineFastState.Bounded env57820 := by
  intro p hp
  have h : env57820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57819_57820 : H12AffineEnvironment.transform 8 136 env57819 = env57820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57819 == env57820) = true)

theorem identity57820 : scanCanonicalize (H12AffineFastState.compose env57820 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound57820 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57821 : List Nat := [2,4,8,16,32,64,89,36,81,117,11,17,9,17,32,2,17,11,117,32,16,32,17,2,88,16,91,17,64,11,85,113,37,113,17,80]

theorem envBound57821 : H12AffineFastState.Bounded env57821 := by
  intro p hp
  have h : env57821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57820_57821 : H12AffineEnvironment.transform 6 89 env57820 = env57821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57820 == env57821) = true)

theorem identity57821 : scanCanonicalize (H12AffineFastState.compose env57821 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound57821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57822 : List Nat := [2,4,8,16,24,64,89,28,81,77,11,17,9,17,24,2,17,11,77,24,16,24,17,2,88,16,91,17,64,11,85,73,29,73,17,80]

theorem envBound57822 : H12AffineFastState.Bounded env57822 := by
  intro p hp
  have h : env57822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57821_57822 : H12AffineEnvironment.transform 4 24 env57821 = env57822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env57821 == env57822) = true)

theorem identity57822 : scanCanonicalize (H12AffineFastState.compose env57822 (packedSelected [2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound57822 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env57823 : List Nat := [2,4,8,16,24,10,19,28,27,7,11,17,9,17,24,2,17,11,7,24,16,24,17,2,18,16,17,17,10,11,31,3,29,3,17,26]

theorem envBound57823 : H12AffineFastState.Bounded env57823 := by
  intro p hp
  have h : env57823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57822_57823 : H12AffineEnvironment.transform 5 10 env57822 = env57823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env57822 == env57823) = true)

theorem identity57823 : scanCanonicalize (H12AffineFastState.compose env57823 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57823 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57824 : List Nat := [0,4,8,16,24,8,17,28,25,5,9,17,9,17,24,0,17,9,5,24,16,24,17,0,16,16,17,17,8,9,29,1,29,1,17,24]

theorem envBound57824 : H12AffineFastState.Bounded env57824 := by
  intro p hp
  have h : env57824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57823_57824 : H12AffineEnvironment.transform 0 0 env57823 = env57824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57823 == env57824) = true)

theorem identity57824 : scanCanonicalize (H12AffineFastState.compose env57824 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57825 : List Nat := [0,4,1,16,17,1,17,21,16,5,0,17,0,17,17,0,17,0,5,17,16,17,17,0,16,16,17,17,1,0,20,1,20,1,17,17]

theorem envBound57825 : H12AffineFastState.Bounded env57825 := by
  intro p hp
  have h : env57825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57824_57825 : H12AffineEnvironment.transform 2 1 env57824 = env57825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57824 == env57825) = true)

theorem identity57825 : scanCanonicalize (H12AffineFastState.compose env57825 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57825 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57826 : List Nat := [0,4,1,0,1,1,1,5,0,5,0,1,0,1,1,0,1,0,5,1,0,1,1,0,0,0,1,1,1,0,4,1,4,1,1,1]

theorem envBound57826 : H12AffineFastState.Bounded env57826 := by
  intro p hp
  have h : env57826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57825_57826 : H12AffineEnvironment.transform 3 0 env57825 = env57826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57825 == env57826) = true)

def env57827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12512,65536,131072,69824,1024,12512,136513,1392,144713,140398,8329,139273,75005,1345,131153,75786,200846,206022,257,69730,131072,512]

theorem envBound57827 : H12AffineFastState.Bounded env57827 := by
  intro p hp
  have h : env57827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57811_57827 : H12AffineEnvironment.transform 13 1345 env57811 = env57827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57811 == env57827) = true)

theorem identity57827 : scanCanonicalize (H12AffineFastState.compose env57827 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57827 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,9713,65536,131072,67025,1024,9713,131152,1392,139352,140398,8329,139273,75005,1345,131153,75786,198047,206022,257,66931,131072,512]

theorem envBound57828 : H12AffineFastState.Bounded env57828 := by
  intro p hp
  have h : env57828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57827_57828 : H12AffineEnvironment.transform 11 1297 env57827 = env57828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57827 == env57828) = true)

def env57829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304863,4247641,6342041,2544861,16384,131153,4315355,6402143,221575,257,2295075,131072,4256464]

theorem envBound57829 : H12AffineFastState.Bounded env57829 := by
  intro p hp
  have h : env57829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57673_57829 : H12AffineEnvironment.transform 24 4247641 env57673 = env57829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env57673 == env57829) = true)

def env57830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144712,169103,2257033,157001,2544861,16384,131153,2324491,200847,221575,257,2295075,131072,2249216]

theorem envBound57830 : H12AffineFastState.Bounded env57830 := by
  intro p hp
  have h : env57830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57829_57830 : H12AffineEnvironment.transform 21 2269392 env57829 = env57830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env57829 == env57830) = true)

def env57831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144712,169103,26057,157001,311709,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound57831 : H12AffineFastState.Bounded env57831 := by
  intro p hp
  have h : env57831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57830_57831 : H12AffineEnvironment.transform 20 136512 env57830 = env57831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57830 == env57831) = true)

def env57832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144712,169103,26057,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound57832 : H12AffineFastState.Bounded env57832 := by
  intro p hp
  have h : env57832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57831_57832 : H12AffineEnvironment.transform 17 87424 env57831 = env57832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57831 == env57832) = true)

theorem identity57832 : scanCanonicalize (H12AffineFastState.compose env57832 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound57832 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,16384,32768,65536,131072,87424,1024,32768,136512,37940,136428,169103,17517,148717,103453,16384,131153,85231,200847,213027,257,69731,131072,18240]

theorem envBound57833 : H12AffineFastState.Bounded env57833 := by
  intro p hp
  have h : env57833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57832_57833 : H12AffineEnvironment.transform 12 420 env57832 = env57833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57832 == env57833) = true)

def env57834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,32768,65536,131072,69824,1024,32768,136512,37940,136428,169103,301,131501,103453,1344,131153,68015,200847,197987,257,69731,131072,512]

theorem envBound57834 : H12AffineFastState.Bounded env57834 := by
  intro p hp
  have h : env57834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57833_57834 : H12AffineEnvironment.transform 13 1344 env57833 = env57834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57833 == env57834) = true)

theorem identity57834 : scanCanonicalize (H12AffineFastState.compose env57834 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57834 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,420,1344,32768,65536,131072,67024,1024,32768,131152,33060,131580,164255,301,131501,98573,1344,131153,68015,198047,197987,257,66931,131072,512]

theorem envBound57835 : H12AffineFastState.Bounded env57835 := by
  intro p hp
  have h : env57835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57834_57835 : H12AffineEnvironment.transform 11 1296 env57834 = env57835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57834 == env57835) = true)

def env57836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,65536,131072,69825,1024,32768,136512,37940,136428,169103,300,131500,103453,1345,131153,68014,200847,197986,257,69731,131072,513]

theorem envBound57836 : H12AffineFastState.Bounded env57836 := by
  intro p hp
  have h : env57836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57833_57836 : H12AffineEnvironment.transform 13 1345 env57833 = env57836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57833 == env57836) = true)

theorem identity57836 : scanCanonicalize (H12AffineFastState.compose env57836 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57836 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38047,131072,33886,1024,32768,136512,37940,136428,169103,300,131500,130,1345,131153,40241,164880,168445,257,34044,131072,513]

theorem envBound57837 : H12AffineFastState.Bounded env57837 := by
  intro p hp
  have h : env57837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57836_57837 : H12AffineEnvironment.transform 15 38047 env57836 = env57837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57836 == env57837) = true)

theorem identity57837 : scanCanonicalize (H12AffineFastState.compose env57837 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 445) := by decide +kernel

theorem selectedBound57837 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38047,445,33886,1024,32768,5373,37940,5457,38194,300,17,130,1345,492,40241,34221,36928,257,34044,445,513]

theorem envBound57838 : H12AffineFastState.Bounded env57838 := by
  intro p hp
  have h : env57838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57837_57838 : H12AffineEnvironment.transform 16 445 env57837 = env57838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 445 env57837 == env57838) = true)

theorem identity57838 : scanCanonicalize (H12AffineFastState.compose env57838 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound57838 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1108,4299,445,10,1024,1108,5373,4192,5457,4454,300,17,130,1345,492,6501,505,5140,257,168,445,513]

theorem envBound57839 : H12AffineFastState.Bounded env57839 := by
  intro p hp
  have h : env57839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57838_57839 : H12AffineEnvironment.transform 14 1108 env57838 = env57839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env57838 == env57839) = true)

theorem identity57839 : scanCanonicalize (H12AffineFastState.compose env57839 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound57839 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,420,1345,1108,4299,445,10,1024,1108,5373,4192,5457,4454,300,17,130,1345,492,4802,505,5140,257,168,445,513]

theorem envBound57840 : H12AffineFastState.Bounded env57840 := by
  intro p hp
  have h : env57840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57839_57840 : H12AffineEnvironment.transform 10 935 env57839 = env57840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env57839 == env57840) = true)

theorem identity57840 : scanCanonicalize (H12AffineFastState.compose env57840 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound57840 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57841 : List Nat := [2,4,8,16,32,64,128,256,512,549,935,4096,420,868,625,4299,445,10,549,625,4824,4192,4980,4454,300,17,130,868,492,4802,505,4657,257,168,445,513]

theorem envBound57841 : H12AffineFastState.Bounded env57841 := by
  intro p hp
  have h : env57841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57840_57841 : H12AffineEnvironment.transform 9 549 env57840 = env57841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env57840 == env57841) = true)

theorem identity57841 : scanCanonicalize (H12AffineFastState.compose env57841 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound57841 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env57842 : List Nat := [2,4,8,16,32,64,128,256,512,549,935,17,420,868,625,218,445,10,549,625,713,113,869,375,300,17,130,868,492,723,505,544,257,168,445,513]

theorem envBound57842 : H12AffineFastState.Bounded env57842 := by
  intro p hp
  have h : env57842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57841_57842 : H12AffineEnvironment.transform 11 17 env57841 = env57842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env57841 == env57842) = true)

theorem identity57842 : scanCanonicalize (H12AffineFastState.compose env57842 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57842 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57843 : List Nat := [2,4,8,16,32,64,128,256,373,336,210,17,420,17,260,218,445,10,336,260,444,113,16,375,300,17,130,17,492,422,505,341,257,168,445,372]

theorem envBound57843 : H12AffineFastState.Bounded env57843 := by
  intro p hp
  have h : env57843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57842_57843 : H12AffineEnvironment.transform 8 373 env57842 = env57843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57842 == env57843) = true)

theorem identity57843 : scanCanonicalize (H12AffineFastState.compose env57843 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57843 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env57844 : List Nat := [2,4,8,16,32,64,3,256,373,336,81,17,295,17,260,89,318,10,336,260,319,113,16,375,300,17,1,17,367,293,378,341,257,43,318,372]

theorem envBound57844 : H12AffineFastState.Bounded env57844 := by
  intro p hp
  have h : env57844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57843_57844 : H12AffineEnvironment.transform 6 3 env57843 = env57844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57843 == env57844) = true)

def env57845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144712,169103,26057,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound57845 : H12AffineFastState.Bounded env57845 := by
  intro p hp
  have h : env57845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57831_57845 : H12AffineEnvironment.transform 17 87425 env57831 = env57845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57831 == env57845) = true)

theorem identity57845 : scanCanonicalize (H12AffineFastState.compose env57845 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 9445) := by decide +kernel

theorem selectedBound57845 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9445,32768,65536,131072,78180,1024,32768,136512,46480,144712,169103,300,131500,103452,9445,131153,68014,200847,197986,257,69731,131072,9125]

theorem envBound57846 : H12AffineFastState.Bounded env57846 := by
  intro p hp
  have h : env57846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57845_57846 : H12AffineEnvironment.transform 13 9445 env57845 = env57846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9445 env57845 == env57846) = true)

def env57847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,65536,131072,69824,1024,32768,136512,37940,136428,169103,300,131500,103452,1345,131153,68014,200847,197986,257,69731,131072,513]

theorem envBound57847 : H12AffineFastState.Bounded env57847 := by
  intro p hp
  have h : env57847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57846_57847 : H12AffineEnvironment.transform 12 420 env57846 = env57847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57846 == env57847) = true)

theorem identity57847 : scanCanonicalize (H12AffineFastState.compose env57847 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57847 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38047,131072,33887,1024,32768,136512,37940,136428,169103,300,131500,131,1345,131153,40241,164880,168445,257,34044,131072,513]

theorem envBound57848 : H12AffineFastState.Bounded env57848 := by
  intro p hp
  have h : env57848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57847_57848 : H12AffineEnvironment.transform 15 38047 env57847 = env57848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57847 == env57848) = true)

theorem identity57848 : scanCanonicalize (H12AffineFastState.compose env57848 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 445) := by decide +kernel

theorem selectedBound57848 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38047,445,33887,1024,32768,5373,37940,5457,38194,300,17,131,1345,492,40241,34221,36928,257,34044,445,513]

theorem envBound57849 : H12AffineFastState.Bounded env57849 := by
  intro p hp
  have h : env57849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57848_57849 : H12AffineEnvironment.transform 16 445 env57848 = env57849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 445 env57848 == env57849) = true)

theorem identity57849 : scanCanonicalize (H12AffineFastState.compose env57849 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound57849 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1108,4299,445,11,1024,1108,5373,4192,5457,4454,300,17,131,1345,492,6501,505,5140,257,168,445,513]

theorem envBound57850 : H12AffineFastState.Bounded env57850 := by
  intro p hp
  have h : env57850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57849_57850 : H12AffineEnvironment.transform 14 1108 env57849 = env57850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env57849 == env57850) = true)

theorem identity57850 : scanCanonicalize (H12AffineFastState.compose env57850 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound57850 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,420,1345,1108,4299,445,11,1024,1108,5373,4192,5457,4454,300,17,131,1345,492,4802,505,5140,257,168,445,513]

theorem envBound57851 : H12AffineFastState.Bounded env57851 := by
  intro p hp
  have h : env57851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57850_57851 : H12AffineEnvironment.transform 10 935 env57850 = env57851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env57850 == env57851) = true)

theorem identity57851 : scanCanonicalize (H12AffineFastState.compose env57851 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound57851 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,820,420,1345,1108,1023,445,11,1024,1108,1993,852,1637,594,300,17,131,1345,492,502,505,1824,257,168,445,513]

theorem envBound57852 : H12AffineFastState.Bounded env57852 := by
  intro p hp
  have h : env57852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57851_57852 : H12AffineEnvironment.transform 11 820 env57851 = env57852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env57851 == env57852) = true)

theorem identity57852 : scanCanonicalize (H12AffineFastState.compose env57852 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound57852 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env57853 : List Nat := [2,4,8,16,32,64,128,256,512,257,935,820,420,64,341,1023,445,11,257,341,712,852,868,594,300,17,131,64,492,502,505,545,257,168,445,513]

theorem envBound57853 : H12AffineFastState.Bounded env57853 := by
  intro p hp
  have h : env57853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57852_57853 : H12AffineEnvironment.transform 9 257 env57852 = env57853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env57852 == env57853) = true)

theorem identity57853 : scanCanonicalize (H12AffineFastState.compose env57853 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57853 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57854 : List Nat := [2,4,8,16,32,17,128,256,512,257,935,820,420,17,260,942,445,11,257,260,665,773,821,515,300,17,131,17,445,423,424,545,257,168,445,513]

theorem envBound57854 : H12AffineFastState.Bounded env57854 := by
  intro p hp
  have h : env57854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57853_57854 : H12AffineEnvironment.transform 5 17 env57853 = env57854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57853 == env57854) = true)

theorem identity57854 : scanCanonicalize (H12AffineFastState.compose env57854 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound57854 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57855 : List Nat := [2,4,8,16,32,17,128,256,292,257,131,16,420,17,260,138,445,11,257,260,445,33,17,295,300,17,131,17,445,423,424,261,257,168,445,293]

theorem envBound57855 : H12AffineFastState.Bounded env57855 := by
  intro p hp
  have h : env57855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57854_57855 : H12AffineEnvironment.transform 8 292 env57854 = env57855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env57854 == env57855) = true)

theorem identity57855 : scanCanonicalize (H12AffineFastState.compose env57855 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57855 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57856 : List Nat := [2,4,8,0,32,1,128,256,292,257,131,0,420,1,260,138,429,11,257,260,429,33,1,295,300,1,131,1,429,423,424,261,257,168,429,293]

theorem envBound57856 : H12AffineFastState.Bounded env57856 := by
  intro p hp
  have h : env57856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57855_57856 : H12AffineEnvironment.transform 3 0 env57855 = env57856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57855 == env57856) = true)

theorem identity57856 : scanCanonicalize (H12AffineFastState.compose env57856 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57856 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57857 : List Nat := [2,4,8,0,32,1,8,256,292,257,11,0,300,1,260,2,293,11,257,260,293,33,1,295,300,1,11,1,293,303,288,261,257,32,293,293]

theorem envBound57857 : H12AffineFastState.Bounded env57857 := by
  intro p hp
  have h : env57857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57856_57857 : H12AffineEnvironment.transform 6 8 env57856 = env57857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57856 == env57857) = true)

theorem identity57857 : scanCanonicalize (H12AffineFastState.compose env57857 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57857 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57858 : List Nat := [2,4,1,0,32,1,1,256,292,257,2,0,293,1,260,2,293,2,257,260,293,33,1,295,293,1,2,1,293,294,288,261,257,32,293,293]

theorem envBound57858 : H12AffineFastState.Bounded env57858 := by
  intro p hp
  have h : env57858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57857_57858 : H12AffineEnvironment.transform 2 1 env57857 = env57858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57857 == env57858) = true)

theorem identity57858 : scanCanonicalize (H12AffineFastState.compose env57858 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound57858 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57859 : List Nat := [2,4,1,0,2,1,1,256,262,257,2,0,263,1,260,2,263,2,257,260,263,3,1,261,263,1,2,1,263,260,258,261,257,2,263,263]

theorem envBound57859 : H12AffineFastState.Bounded env57859 := by
  intro p hp
  have h : env57859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57858_57859 : H12AffineEnvironment.transform 4 2 env57858 = env57859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env57858 == env57859) = true)

theorem identity57859 : scanCanonicalize (H12AffineFastState.compose env57859 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound57859 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57860 : List Nat := [2,4,1,0,2,1,1,6,0,7,2,0,1,1,2,2,1,2,7,2,1,3,1,3,1,1,2,1,1,2,4,3,7,2,1,1]

theorem envBound57860 : H12AffineFastState.Bounded env57860 := by
  intro p hp
  have h : env57860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57859_57860 : H12AffineEnvironment.transform 7 6 env57859 = env57860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env57859 == env57860) = true)

theorem identity57860 : scanCanonicalize (H12AffineFastState.compose env57860 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57861 : List Nat := [0,4,1,0,0,1,1,4,0,5,0,0,1,1,0,0,1,0,5,0,1,1,1,1,1,1,0,1,1,0,4,1,5,0,1,1]

theorem envBound57861 : H12AffineFastState.Bounded env57861 := by
  intro p hp
  have h : env57861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57860_57861 : H12AffineEnvironment.transform 0 0 env57860 = env57861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57860 == env57861) = true)

def env57862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,32768,65536,131072,69825,1024,32768,136512,37941,136429,169103,300,131500,103452,1344,131153,68014,200847,197986,257,69731,131072,512]

theorem envBound57862 : H12AffineFastState.Bounded env57862 := by
  intro p hp
  have h : env57862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57846_57862 : H12AffineEnvironment.transform 12 421 env57846 = env57862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env57846 == env57862) = true)

theorem identity57862 : scanCanonicalize (H12AffineFastState.compose env57862 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57862 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,421,1344,32768,65536,131072,67025,1024,32768,131152,33061,131581,164255,300,131500,98572,1344,131153,68014,198047,197986,257,66931,131072,512]

theorem envBound57863 : H12AffineFastState.Bounded env57863 := by
  intro p hp
  have h : env57863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57862_57863 : H12AffineEnvironment.transform 11 1296 env57862 = env57863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57862 == env57863) = true)

def env57864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144712,169103,26056,157001,311708,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound57864 : H12AffineFastState.Bounded env57864 := by
  intro p hp
  have h : env57864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57830_57864 : H12AffineEnvironment.transform 20 136513 env57830 = env57864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57830 == env57864) = true)

def env57865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144712,169103,26056,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound57865 : H12AffineFastState.Bounded env57865 := by
  intro p hp
  have h : env57865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57864_57865 : H12AffineEnvironment.transform 17 87424 env57864 = env57865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57864 == env57865) = true)

theorem identity57865 : scanCanonicalize (H12AffineFastState.compose env57865 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 12789) := by decide +kernel

theorem selectedBound57865 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12789,32768,65536,131072,74869,1024,32768,136513,46481,144712,169103,5181,136380,103452,12789,131153,72895,200847,200818,257,69730,131072,14004]

theorem envBound57866 : H12AffineFastState.Bounded env57866 := by
  intro p hp
  have h : env57866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57865_57866 : H12AffineEnvironment.transform 13 12789 env57865 = env57866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12789 env57865 == env57866) = true)

def env57867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,32768,65536,131072,69825,1024,32768,136513,33061,131580,169103,5181,136380,103452,1345,131153,72895,200847,200818,257,69730,131072,512]

theorem envBound57867 : H12AffineFastState.Bounded env57867 := by
  intro p hp
  have h : env57867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57866_57867 : H12AffineEnvironment.transform 12 5300 env57866 = env57867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env57866 == env57867) = true)

theorem identity57867 : scanCanonicalize (H12AffineFastState.compose env57867 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57867 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,421,1345,32768,65536,131072,67024,1024,32768,131152,33061,131580,164254,300,131501,98573,1345,131153,68014,198046,197987,257,66931,131072,512]

theorem envBound57868 : H12AffineFastState.Bounded env57868 := by
  intro p hp
  have h : env57868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57867_57868 : H12AffineEnvironment.transform 11 1297 env57867 = env57868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57867 == env57868) = true)

def env57869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,65536,131072,69824,1024,32768,136513,33060,131581,169103,5181,136380,103452,1344,131153,72895,200847,200818,257,69730,131072,513]

theorem envBound57869 : H12AffineFastState.Bounded env57869 := by
  intro p hp
  have h : env57869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57866_57869 : H12AffineEnvironment.transform 12 5301 env57866 = env57869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env57866 == env57869) = true)

theorem identity57869 : scanCanonicalize (H12AffineFastState.compose env57869 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57869 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38046,131072,33886,1024,32768,136513,33060,131581,169103,5181,136380,130,1344,131153,34849,164881,165100,257,34044,131072,513]

theorem envBound57870 : H12AffineFastState.Bounded env57870 := by
  intro p hp
  have h : env57870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57869_57870 : H12AffineEnvironment.transform 15 38046 env57869 = env57870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57869 == env57870) = true)

theorem identity57870 : scanCanonicalize (H12AffineFastState.compose env57870 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5293) := by decide +kernel

theorem selectedBound57870 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38046,5293,33886,1024,32768,492,33060,5456,32802,5181,17,130,1344,5372,34849,37052,36929,257,34044,5293,513]

theorem envBound57871 : H12AffineFastState.Bounded env57871 := by
  intro p hp
  have h : env57871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57870_57871 : H12AffineEnvironment.transform 16 5293 env57870 = env57871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5293 env57870 == env57871) = true)

theorem identity57871 : scanCanonicalize (H12AffineFastState.compose env57871 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound57871 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1108,4298,5293,10,1024,1108,492,1392,5456,1142,5181,17,130,1344,5372,3189,5352,5141,257,168,5293,513]

theorem envBound57872 : H12AffineFastState.Bounded env57872 := by
  intro p hp
  have h : env57872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57871_57872 : H12AffineEnvironment.transform 14 1108 env57871 = env57872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env57871 == env57872) = true)

theorem identity57872 : scanCanonicalize (H12AffineFastState.compose env57872 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound57872 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3766,2563,1344,1108,3708,2587,10,1024,1108,492,1392,3046,1142,2699,17,130,1344,2634,3189,2654,2723,257,168,2587,513]

theorem envBound57873 : H12AffineFastState.Bounded env57873 := by
  intro p hp
  have h : env57873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57872_57873 : H12AffineEnvironment.transform 11 3766 env57872 = env57873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env57872 == env57873) = true)

theorem identity57873 : scanCanonicalize (H12AffineFastState.compose env57873 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound57873 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,383,1993,892,1344,1108,1795,868,10,1024,1108,492,1392,665,1142,1012,17,130,1344,821,1290,801,988,257,168,868,513]

theorem envBound57874 : H12AffineFastState.Bounded env57874 := by
  intro p hp
  have h : env57874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57873_57874 : H12AffineEnvironment.transform 10 383 env57873 = env57874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env57873 == env57874) = true)

theorem identity57874 : scanCanonicalize (H12AffineFastState.compose env57874 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound57874 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57875 : List Nat := [2,4,8,16,32,64,128,253,512,1024,130,1588,641,1213,1108,1790,665,10,1024,1108,17,1165,665,1142,521,17,130,1213,712,1271,732,545,252,168,665,513]

theorem envBound57875 : H12AffineFastState.Bounded env57875 := by
  intro p hp
  have h : env57875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57874_57875 : H12AffineEnvironment.transform 7 253 env57874 = env57875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env57874 == env57875) = true)

theorem identity57875 : scanCanonicalize (H12AffineFastState.compose env57875 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 629) := by decide +kernel

theorem selectedBound57875 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57876 : List Nat := [2,4,8,16,32,64,128,253,512,629,130,65,641,712,545,139,665,10,629,545,17,760,665,515,521,17,130,712,712,642,732,545,252,168,665,513]

theorem envBound57876 : H12AffineFastState.Bounded env57876 := by
  intro p hp
  have h : env57876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57875_57876 : H12AffineEnvironment.transform 9 629 env57875 = env57876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 629 env57875 == env57876) = true)

theorem identity57876 : scanCanonicalize (H12AffineFastState.compose env57876 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound57876 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57877 : List Nat := [2,4,8,16,32,64,128,253,217,172,130,65,88,17,248,139,64,10,172,248,17,33,64,218,208,17,130,17,17,91,5,248,252,168,64,216]

theorem envBound57877 : H12AffineFastState.Bounded env57877 := by
  intro p hp
  have h : env57877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57876_57877 : H12AffineEnvironment.transform 8 217 env57876 = env57877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env57876 == env57877) = true)

theorem identity57877 : scanCanonicalize (H12AffineFastState.compose env57877 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound57877 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57878 : List Nat := [2,4,8,16,32,64,24,101,65,52,26,65,88,17,96,19,64,10,52,96,17,33,64,66,72,17,26,17,17,91,5,96,100,48,64,64]

theorem envBound57878 : H12AffineFastState.Bounded env57878 := by
  intro p hp
  have h : env57878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57877_57878 : H12AffineEnvironment.transform 6 24 env57877 = env57878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env57877 == env57878) = true)

theorem identity57878 : scanCanonicalize (H12AffineFastState.compose env57878 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57878 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57879 : List Nat := [2,4,8,16,27,64,24,94,65,15,26,65,88,17,91,19,64,10,15,91,17,26,64,66,72,17,26,17,17,91,5,91,95,11,64,64]

theorem envBound57879 : H12AffineFastState.Bounded env57879 := by
  intro p hp
  have h : env57879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57878_57879 : H12AffineEnvironment.transform 4 27 env57878 = env57879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57878 == env57879) = true)

theorem identity57879 : scanCanonicalize (H12AffineFastState.compose env57879 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound57879 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57880 : List Nat := [2,4,8,16,27,24,24,6,25,15,26,25,0,17,3,19,24,10,15,3,17,26,24,26,16,17,26,17,17,3,5,3,7,11,24,24]

theorem envBound57880 : H12AffineFastState.Bounded env57880 := by
  intro p hp
  have h : env57880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57879_57880 : H12AffineEnvironment.transform 5 24 env57879 = env57880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env57879 == env57880) = true)

theorem identity57880 : scanCanonicalize (H12AffineFastState.compose env57880 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound57880 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57881 : List Nat := [2,4,8,8,3,0,0,6,1,15,2,1,0,9,3,11,0,10,15,3,9,2,0,2,8,9,2,9,9,3,5,3,7,11,0,0]

theorem envBound57881 : H12AffineFastState.Bounded env57881 := by
  intro p hp
  have h : env57881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57880_57881 : H12AffineEnvironment.transform 3 8 env57880 = env57881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env57880 == env57881) = true)

def env57882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144712,169103,26056,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound57882 : H12AffineFastState.Bounded env57882 := by
  intro p hp
  have h : env57882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57864_57882 : H12AffineEnvironment.transform 17 87425 env57864 = env57882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57864 == env57882) = true)

theorem identity57882 : scanCanonicalize (H12AffineFastState.compose env57882 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound57882 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,16384,32768,65536,131072,87425,1024,32768,136513,33060,131581,169103,20861,152060,103453,16384,131153,88575,200847,218418,257,69730,131072,18241]

theorem envBound57883 : H12AffineFastState.Bounded env57883 := by
  intro p hp
  have h : env57883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57882_57883 : H12AffineEnvironment.transform 12 5301 env57882 = env57883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env57882 == env57883) = true)

def env57884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,65536,131072,69825,1024,32768,136513,33060,131581,169103,5181,136380,103453,1344,131153,72895,200847,200818,257,69730,131072,513]

theorem envBound57884 : H12AffineFastState.Bounded env57884 := by
  intro p hp
  have h : env57884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57883_57884 : H12AffineEnvironment.transform 13 1344 env57883 = env57884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57883 == env57884) = true)

theorem identity57884 : scanCanonicalize (H12AffineFastState.compose env57884 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57884 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38046,131072,33887,1024,32768,136513,33060,131581,169103,5181,136380,131,1344,131153,34849,164881,165100,257,34044,131072,513]

theorem envBound57885 : H12AffineFastState.Bounded env57885 := by
  intro p hp
  have h : env57885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57884_57885 : H12AffineEnvironment.transform 15 38046 env57884 = env57885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57884 == env57885) = true)

theorem identity57885 : scanCanonicalize (H12AffineFastState.compose env57885 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5293) := by decide +kernel

theorem selectedBound57885 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38046,5293,33887,1024,32768,492,33060,5456,32802,5181,17,131,1344,5372,34849,37052,36929,257,34044,5293,513]

theorem envBound57886 : H12AffineFastState.Bounded env57886 := by
  intro p hp
  have h : env57886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57885_57886 : H12AffineEnvironment.transform 16 5293 env57885 = env57886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5293 env57885 == env57886) = true)

theorem identity57886 : scanCanonicalize (H12AffineFastState.compose env57886 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound57886 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1108,4298,5293,11,1024,1108,492,1392,5456,1142,5181,17,131,1344,5372,3189,5352,5141,257,168,5293,513]

theorem envBound57887 : H12AffineFastState.Bounded env57887 := by
  intro p hp
  have h : env57887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57886_57887 : H12AffineEnvironment.transform 14 1108 env57886 = env57887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env57886 == env57887) = true)

theorem identity57887 : scanCanonicalize (H12AffineFastState.compose env57887 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound57887 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3766,2563,1344,1108,3708,2587,11,1024,1108,492,1392,3046,1142,2699,17,131,1344,2634,3189,2654,2723,257,168,2587,513]

theorem envBound57888 : H12AffineFastState.Bounded env57888 := by
  intro p hp
  have h : env57888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57887_57888 : H12AffineEnvironment.transform 11 3766 env57887 = env57888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env57887 == env57888) = true)

theorem identity57888 : scanCanonicalize (H12AffineFastState.compose env57888 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound57888 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57889 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,3183,2266,1344,1108,3237,2242,11,1024,1108,492,1392,2367,1142,2130,17,131,1344,2195,3189,2183,2170,257,168,2242,216]

theorem envBound57889 : H12AffineFastState.Bounded env57889 := by
  intro p hp
  have h : env57889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57888_57889 : H12AffineEnvironment.transform 8 217 env57888 = env57889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env57888 == env57889) = true)

theorem identity57889 : scanCanonicalize (H12AffineFastState.compose env57889 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound57889 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57890 : List Nat := [2,4,8,16,32,64,128,256,217,1024,131,1260,89,1344,1108,1062,65,11,1024,1108,492,1392,444,1142,209,17,131,1344,16,1270,4,249,257,168,65,216]

theorem envBound57890 : H12AffineFastState.Bounded env57890 := by
  intro p hp
  have h : env57890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57889_57890 : H12AffineEnvironment.transform 10 131 env57889 = env57890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env57889 == env57890) = true)

theorem identity57890 : scanCanonicalize (H12AffineFastState.compose env57890 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound57890 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57891 : List Nat := [2,4,8,16,32,64,128,256,217,173,131,65,89,493,249,139,65,11,173,249,492,477,444,219,209,17,131,493,16,91,4,249,257,168,65,216]

theorem envBound57891 : H12AffineFastState.Bounded env57891 := by
  intro p hp
  have h : env57891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57890_57891 : H12AffineEnvironment.transform 9 173 env57890 = env57891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env57890 == env57891) = true)

theorem identity57891 : scanCanonicalize (H12AffineFastState.compose env57891 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound57891 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57892 : List Nat := [2,4,8,16,32,64,128,252,217,173,131,65,89,17,249,139,65,11,173,249,16,33,64,219,209,17,131,17,16,91,4,249,253,168,65,216]

theorem envBound57892 : H12AffineFastState.Bounded env57892 := by
  intro p hp
  have h : env57892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57891_57892 : H12AffineEnvironment.transform 7 252 env57891 = env57892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env57891 == env57892) = true)

theorem identity57892 : scanCanonicalize (H12AffineFastState.compose env57892 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound57892 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57893 : List Nat := [2,4,8,16,32,64,24,100,65,53,27,65,89,17,97,19,65,11,53,97,16,33,64,67,73,17,27,17,16,91,4,97,101,48,65,64]

theorem envBound57893 : H12AffineFastState.Bounded env57893 := by
  intro p hp
  have h : env57893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57892_57893 : H12AffineEnvironment.transform 6 24 env57892 = env57893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env57892 == env57893) = true)

theorem identity57893 : scanCanonicalize (H12AffineFastState.compose env57893 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound57893 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57894 : List Nat := [2,4,8,16,32,42,24,14,43,53,27,43,51,17,11,19,43,11,53,11,16,33,42,41,35,17,27,17,16,49,4,11,15,48,43,42]

theorem envBound57894 : H12AffineFastState.Bounded env57894 := by
  intro p hp
  have h : env57894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57893_57894 : H12AffineEnvironment.transform 5 42 env57893 = env57894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env57893 == env57894) = true)

theorem identity57894 : scanCanonicalize (H12AffineFastState.compose env57894 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57895 : List Nat := [2,4,1,16,32,35,17,7,34,53,18,34,51,17,2,19,34,2,53,2,16,33,35,32,35,17,18,17,16,49,4,2,6,48,34,35]

theorem envBound57895 : H12AffineFastState.Bounded env57895 := by
  intro p hp
  have h : env57895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57894_57895 : H12AffineEnvironment.transform 2 1 env57894 = env57895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57894 == env57895) = true)

theorem identity57895 : scanCanonicalize (H12AffineFastState.compose env57895 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57895 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57896 : List Nat := [2,4,1,0,32,35,1,7,34,37,2,34,35,1,2,3,34,2,37,2,0,33,35,32,35,1,2,1,0,33,4,2,6,32,34,35]

theorem envBound57896 : H12AffineFastState.Bounded env57896 := by
  intro p hp
  have h : env57896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57895_57896 : H12AffineEnvironment.transform 3 0 env57895 = env57896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57895 == env57896) = true)

theorem identity57896 : scanCanonicalize (H12AffineFastState.compose env57896 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound57896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57897 : List Nat := [2,4,1,0,2,1,1,7,0,7,2,0,1,1,2,3,0,2,7,2,0,3,1,2,1,1,2,1,0,3,4,2,6,2,0,1]

theorem envBound57897 : H12AffineFastState.Bounded env57897 := by
  intro p hp
  have h : env57897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57896_57897 : H12AffineEnvironment.transform 4 2 env57896 = env57897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env57896 == env57897) = true)

theorem identity57897 : scanCanonicalize (H12AffineFastState.compose env57897 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57897 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57898 : List Nat := [1,4,1,0,1,1,1,4,0,4,1,0,1,1,1,0,0,1,4,1,0,0,1,1,1,1,1,1,0,0,4,1,5,1,0,1]

theorem envBound57898 : H12AffineFastState.Bounded env57898 := by
  intro p hp
  have h : env57898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57897_57898 : H12AffineEnvironment.transform 0 1 env57897 = env57898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57897 == env57898) = true)

def env57899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1345,32768,65536,131072,69824,1024,32768,136513,33060,131581,169103,5180,136381,103453,1345,131153,72894,200847,200819,257,69730,131072,512]

theorem envBound57899 : H12AffineFastState.Bounded env57899 := by
  intro p hp
  have h : env57899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57883_57899 : H12AffineEnvironment.transform 13 1345 env57883 = env57899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57883 == env57899) = true)

theorem identity57899 : scanCanonicalize (H12AffineFastState.compose env57899 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57899 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,420,1345,32768,65536,131072,67025,1024,32768,131152,33060,131581,164254,301,131500,98572,1345,131153,68015,198046,197986,257,66931,131072,512]

theorem envBound57900 : H12AffineFastState.Bounded env57900 := by
  intro p hp
  have h : env57900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57899_57900 : H12AffineEnvironment.transform 11 1297 env57899 = env57900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57899 == env57900) = true)

def env57901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144713,169102,2257032,157000,2544861,16384,131153,2324490,200846,221575,257,2295075,131072,2249217]

theorem envBound57901 : H12AffineFastState.Bounded env57901 := by
  intro p hp
  have h : env57901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57829_57901 : H12AffineEnvironment.transform 21 2269393 env57829 = env57901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env57829 == env57901) = true)

def env57902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144713,169102,26056,157000,311709,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound57902 : H12AffineFastState.Bounded env57902 := by
  intro p hp
  have h : env57902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57901_57902 : H12AffineEnvironment.transform 20 136512 env57901 = env57902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57901 == env57902) = true)

def env57903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144713,169102,26056,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound57903 : H12AffineFastState.Bounded env57903 := by
  intro p hp
  have h : env57903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57902_57903 : H12AffineEnvironment.transform 17 87424 env57902 = env57903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57902 == env57903) = true)

theorem identity57903 : scanCanonicalize (H12AffineFastState.compose env57903 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57903 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,32768,65536,131072,83052,1024,32768,132268,42109,140453,165218,26056,157000,99825,16384,131153,93514,196962,221575,257,65935,131072,18241]

theorem envBound57904 : H12AffineFastState.Bounded env57904 := by
  intro p hp
  have h : env57904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57903_57904 : H12AffineEnvironment.transform 11 492 env57903 = env57904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57903 == env57904) = true)

def env57905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,65536,131072,65836,1024,32768,132268,42109,140453,165218,8328,139272,99825,1344,131153,75786,196962,206023,257,65935,131072,513]

theorem envBound57905 : H12AffineFastState.Bounded env57905 := by
  intro p hp
  have h : env57905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57904_57905 : H12AffineEnvironment.transform 13 1344 env57904 = env57905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57904 == env57905) = true)

theorem identity57905 : scanCanonicalize (H12AffineFastState.compose env57905 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 34163) := by decide +kernel

theorem selectedBound57905 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34163,131072,33887,1024,32768,132268,42109,140453,165218,8328,139272,130,1344,131153,44409,164881,172468,257,34044,131072,513]

theorem envBound57906 : H12AffineFastState.Bounded env57906 := by
  intro p hp
  have h : env57906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57905_57906 : H12AffineEnvironment.transform 15 34163 env57905 = env57906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34163 env57905 == env57906) = true)

theorem identity57906 : scanCanonicalize (H12AffineFastState.compose env57906 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound57906 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34163,8216,33887,1024,32768,9396,42109,1213,42362,8328,16,130,1344,8265,44409,41993,33196,257,34044,8216,513]

theorem envBound57907 : H12AffineFastState.Bounded env57907 := by
  intro p hp
  have h : env57907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57906_57907 : H12AffineEnvironment.transform 16 8216 env57906 = env57907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env57906 == env57907) = true)

theorem identity57907 : scanCanonicalize (H12AffineFastState.compose env57907 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57907 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,1109,294,8216,10,1024,1109,9396,8232,1213,8495,8328,16,130,1344,8265,10540,8284,1529,257,169,8216,513]

theorem envBound57908 : H12AffineFastState.Bounded env57908 := by
  intro p hp
  have h : env57908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57907_57908 : H12AffineEnvironment.transform 14 1109 env57907 = env57908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57907 == env57908) = true)

theorem identity57908 : scanCanonicalize (H12AffineFastState.compose env57908 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound57908 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,2990,1344,1109,294,2998,10,1024,1109,3866,2950,1213,2689,2854,16,130,1344,3047,642,3058,1529,257,169,2998,513]

theorem envBound57909 : H12AffineFastState.Bounded env57909 := by
  intro p hp
  have h : env57909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57908_57909 : H12AffineEnvironment.transform 12 2990 env57908 = env57909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env57908 == env57909) = true)

theorem identity57909 : scanCanonicalize (H12AffineFastState.compose env57909 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57909 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,420,1344,1109,294,444,10,1024,1109,1296,396,1213,139,300,16,130,1344,493,642,504,1529,257,169,444,513]

theorem envBound57910 : H12AffineFastState.Bounded env57910 := by
  intro p hp
  have h : env57910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57909_57910 : H12AffineEnvironment.transform 10 522 env57909 = env57910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57909 == env57910) = true)

theorem identity57910 : scanCanonicalize (H12AffineFastState.compose env57910 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound57910 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57911 : List Nat := [2,4,8,16,32,64,128,256,512,548,522,492,420,868,625,294,444,10,548,625,820,396,665,139,300,16,130,868,493,642,504,989,257,169,444,513]

theorem envBound57911 : H12AffineFastState.Bounded env57911 := by
  intro p hp
  have h : env57911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57910_57911 : H12AffineEnvironment.transform 9 548 env57910 = env57911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env57910 == env57911) = true)

theorem identity57911 : scanCanonicalize (H12AffineFastState.compose env57911 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57911 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57912 : List Nat := [2,4,8,16,32,64,128,172,512,548,522,64,8,712,625,138,16,10,548,625,664,32,665,139,128,16,130,712,65,642,84,625,173,169,16,513]

theorem envBound57912 : H12AffineFastState.Bounded env57912 := by
  intro p hp
  have h : env57912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57911_57912 : H12AffineEnvironment.transform 7 172 env57911 = env57912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57911 == env57912) = true)

theorem identity57912 : scanCanonicalize (H12AffineFastState.compose env57912 (packedSelected [3,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound57912 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57913 : List Nat := [2,4,8,16,32,64,128,172,43,15,33,64,8,227,90,138,16,10,15,90,179,32,178,139,128,16,130,227,65,169,84,90,173,169,16,42]

theorem envBound57913 : H12AffineFastState.Bounded env57913 := by
  intro p hp
  have h : env57913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57912_57913 : H12AffineEnvironment.transform 8 43 env57912 = env57913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env57912 == env57913) = true)

theorem identity57913 : scanCanonicalize (H12AffineFastState.compose env57913 (packedSelected [0,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound57913 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env57914 : List Nat := [2,4,8,16,32,64,16,60,43,15,33,64,8,115,90,26,16,10,15,90,35,32,34,27,16,16,18,115,65,57,84,90,61,57,16,42]

theorem envBound57914 : H12AffineFastState.Bounded env57914 := by
  intro p hp
  have h : env57914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57913_57914 : H12AffineEnvironment.transform 6 16 env57913 = env57914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env57913 == env57914) = true)

theorem identity57914 : scanCanonicalize (H12AffineFastState.compose env57914 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound57914 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env57915 : List Nat := [2,4,8,16,18,64,16,14,25,15,19,64,8,65,90,26,16,10,15,90,17,18,16,27,16,16,18,65,65,11,84,90,15,11,16,24]

theorem envBound57915 : H12AffineFastState.Bounded env57915 := by
  intro p hp
  have h : env57915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57914_57915 : H12AffineEnvironment.transform 4 18 env57914 = env57915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env57914 == env57915) = true)

theorem identity57915 : scanCanonicalize (H12AffineFastState.compose env57915 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound57915 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57916 : List Nat := [2,4,8,16,18,24,16,14,25,15,19,24,8,25,2,26,16,10,15,2,17,18,16,27,16,16,18,25,25,11,12,2,15,11,16,24]

theorem envBound57916 : H12AffineFastState.Bounded env57916 := by
  intro p hp
  have h : env57916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57915_57916 : H12AffineEnvironment.transform 5 24 env57915 = env57916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env57915 == env57916) = true)

theorem identity57916 : scanCanonicalize (H12AffineFastState.compose env57916 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57916 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57917 : List Nat := [2,4,8,11,9,3,11,14,2,15,8,3,8,2,2,1,11,10,15,2,10,9,11,0,11,11,9,2,2,11,12,2,15,11,11,3]

theorem envBound57917 : H12AffineFastState.Bounded env57917 := by
  intro p hp
  have h : env57917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57916_57917 : H12AffineEnvironment.transform 3 11 env57916 = env57917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57916 == env57917) = true)

theorem identity57917 : scanCanonicalize (H12AffineFastState.compose env57917 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57918 : List Nat := [2,4,2,1,3,3,1,4,2,5,2,3,2,2,2,1,1,0,5,2,0,3,1,0,1,1,3,2,2,1,6,2,5,1,1,3]

theorem envBound57918 : H12AffineFastState.Bounded env57918 := by
  intro p hp
  have h : env57918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57917_57918 : H12AffineEnvironment.transform 2 2 env57917 = env57918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57917 == env57918) = true)

theorem identity57918 : scanCanonicalize (H12AffineFastState.compose env57918 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57918 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env57919 : List Nat := [1,4,1,1,0,0,1,4,1,5,1,0,1,1,1,1,1,0,5,1,0,0,1,0,1,1,0,1,1,1,5,1,5,1,1,0]

theorem envBound57919 : H12AffineFastState.Bounded env57919 := by
  intro p hp
  have h : env57919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57918_57919 : H12AffineEnvironment.transform 0 1 env57918 = env57919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57918 == env57919) = true)

def env57920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,32768,65536,131072,65837,1024,32768,132268,42109,140453,165218,8329,139273,99825,1345,131153,75787,196962,206022,257,65935,131072,512]

theorem envBound57920 : H12AffineFastState.Bounded env57920 := by
  intro p hp
  have h : env57920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57904_57920 : H12AffineEnvironment.transform 13 1345 env57904 = env57920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57904 == env57920) = true)

theorem identity57920 : scanCanonicalize (H12AffineFastState.compose env57920 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound57920 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57921 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,492,8192,444,32768,65536,131072,65837,253,32768,131153,41088,139352,164255,8329,139273,98572,444,131153,75787,196962,204859,257,65935,131072,512]

theorem envBound57921 : H12AffineFastState.Bounded env57921 := by
  intro p hp
  have h : env57921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57920_57921 : H12AffineEnvironment.transform 9 253 env57920 = env57921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env57920 == env57921) = true)

def env57922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144713,169102,26056,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound57922 : H12AffineFastState.Bounded env57922 := by
  intro p hp
  have h : env57922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57902_57922 : H12AffineEnvironment.transform 17 87425 env57902 = env57922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57902 == env57922) = true)

theorem identity57922 : scanCanonicalize (H12AffineFastState.compose env57922 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound57922 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,65536,131072,65837,1024,32768,136512,46481,144713,169102,12644,143844,103452,5292,131153,80358,200846,210219,257,69731,131072,5101]

theorem envBound57923 : H12AffineFastState.Bounded env57923 := by
  intro p hp
  have h : env57923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57922_57923 : H12AffineEnvironment.transform 13 5292 env57922 = env57923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env57922 == env57923) = true)

def env57924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,65536,131072,65837,1024,32768,132268,42109,140453,165218,8328,139272,99824,1344,131153,75786,196962,206023,257,65935,131072,513]

theorem envBound57924 : H12AffineFastState.Bounded env57924 := by
  intro p hp
  have h : env57924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57923_57924 : H12AffineEnvironment.transform 11 492 env57923 = env57924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57923 == env57924) = true)

theorem identity57924 : scanCanonicalize (H12AffineFastState.compose env57924 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 34163) := by decide +kernel

theorem selectedBound57924 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34163,131072,33886,1024,32768,132268,42109,140453,165218,8328,139272,131,1344,131153,44409,164881,172468,257,34044,131072,513]

theorem envBound57925 : H12AffineFastState.Bounded env57925 := by
  intro p hp
  have h : env57925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57924_57925 : H12AffineEnvironment.transform 15 34163 env57924 = env57925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34163 env57924 == env57925) = true)

theorem identity57925 : scanCanonicalize (H12AffineFastState.compose env57925 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound57925 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34163,8216,33886,1024,32768,9396,42109,1213,42362,8328,16,131,1344,8265,44409,41993,33196,257,34044,8216,513]

theorem envBound57926 : H12AffineFastState.Bounded env57926 := by
  intro p hp
  have h : env57926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57925_57926 : H12AffineEnvironment.transform 16 8216 env57925 = env57926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env57925 == env57926) = true)

theorem identity57926 : scanCanonicalize (H12AffineFastState.compose env57926 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57926 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,1109,294,8216,11,1024,1109,9396,8232,1213,8495,8328,16,131,1344,8265,10540,8284,1529,257,169,8216,513]

theorem envBound57927 : H12AffineFastState.Bounded env57927 := by
  intro p hp
  have h : env57927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57926_57927 : H12AffineEnvironment.transform 14 1109 env57926 = env57927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57926 == env57927) = true)

theorem identity57927 : scanCanonicalize (H12AffineFastState.compose env57927 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound57927 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,2990,1344,1109,294,2998,11,1024,1109,3866,2950,1213,2689,2854,16,131,1344,3047,642,3058,1529,257,169,2998,513]

theorem envBound57928 : H12AffineFastState.Bounded env57928 := by
  intro p hp
  have h : env57928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57927_57928 : H12AffineEnvironment.transform 12 2990 env57927 = env57928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env57927 == env57928) = true)

theorem identity57928 : scanCanonicalize (H12AffineFastState.compose env57928 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57928 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,420,1344,1109,294,444,11,1024,1109,1296,396,1213,139,300,16,131,1344,493,642,504,1529,257,169,444,513]

theorem envBound57929 : H12AffineFastState.Bounded env57929 := by
  intro p hp
  have h : env57929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57928_57929 : H12AffineEnvironment.transform 10 522 env57928 = env57929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57928 == env57929) = true)

theorem identity57929 : scanCanonicalize (H12AffineFastState.compose env57929 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound57929 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57930 : List Nat := [2,4,8,16,32,64,128,256,512,548,522,492,420,868,625,294,444,11,548,625,820,396,665,139,300,16,131,868,493,642,504,989,257,169,444,513]

theorem envBound57930 : H12AffineFastState.Bounded env57930 := by
  intro p hp
  have h : env57930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57929_57930 : H12AffineEnvironment.transform 9 548 env57929 = env57930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env57929 == env57930) = true)

theorem identity57930 : scanCanonicalize (H12AffineFastState.compose env57930 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57930 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57931 : List Nat := [2,4,8,16,32,64,128,172,512,548,522,64,8,712,625,138,16,11,548,625,664,32,665,139,128,16,131,712,65,642,84,625,173,169,16,513]

theorem envBound57931 : H12AffineFastState.Bounded env57931 := by
  intro p hp
  have h : env57931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57930_57931 : H12AffineEnvironment.transform 7 172 env57930 = env57931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57930 == env57931) = true)

theorem identity57931 : scanCanonicalize (H12AffineFastState.compose env57931 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound57931 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57932 : List Nat := [2,4,8,16,32,64,34,14,512,548,522,64,8,618,625,40,16,11,548,625,570,32,571,41,34,16,33,618,65,544,84,625,15,11,16,513]

theorem envBound57932 : H12AffineFastState.Bounded env57932 := by
  intro p hp
  have h : env57932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57931_57932 : H12AffineEnvironment.transform 6 34 env57931 = env57932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env57931 == env57932) = true)

theorem identity57932 : scanCanonicalize (H12AffineFastState.compose env57932 (packedSelected [2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound57932 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env57933 : List Nat := [2,4,8,16,18,64,16,14,512,534,522,64,8,600,579,26,16,11,534,579,520,18,521,27,16,16,19,600,65,530,84,579,15,11,16,513]

theorem envBound57933 : H12AffineFastState.Bounded env57933 := by
  intro p hp
  have h : env57933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57932_57933 : H12AffineEnvironment.transform 4 18 env57932 = env57933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env57932 == env57933) = true)

theorem identity57933 : scanCanonicalize (H12AffineFastState.compose env57933 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 73) := by decide +kernel

theorem selectedBound57933 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env57934 : List Nat := [2,4,8,16,18,64,16,14,73,95,67,64,8,17,10,26,16,11,95,10,65,18,64,27,16,16,19,17,65,91,84,10,15,11,16,72]

theorem envBound57934 : H12AffineFastState.Bounded env57934 := by
  intro p hp
  have h : env57934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57933_57934 : H12AffineEnvironment.transform 8 73 env57933 = env57934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 73 env57933 == env57934) = true)

theorem identity57934 : scanCanonicalize (H12AffineFastState.compose env57934 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound57934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57935 : List Nat := [2,4,8,16,18,9,16,14,0,22,10,9,8,17,10,26,16,11,22,10,8,18,9,27,16,16,19,17,8,18,29,10,15,11,16,1]

theorem envBound57935 : H12AffineFastState.Bounded env57935 := by
  intro p hp
  have h : env57935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57934_57935 : H12AffineEnvironment.transform 5 9 env57934 = env57935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env57934 == env57935) = true)

theorem identity57935 : scanCanonicalize (H12AffineFastState.compose env57935 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57936 : List Nat := [2,4,8,11,9,9,11,14,0,13,10,9,8,10,10,1,11,11,13,10,8,9,9,0,11,11,8,10,8,9,6,10,15,11,11,1]

theorem envBound57936 : H12AffineFastState.Bounded env57936 := by
  intro p hp
  have h : env57936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57935_57936 : H12AffineEnvironment.transform 3 11 env57935 = env57936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57935 == env57936) = true)

theorem identity57936 : scanCanonicalize (H12AffineFastState.compose env57936 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57936 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57937 : List Nat := [0,4,8,9,9,9,9,12,0,13,8,9,8,8,8,1,9,9,13,8,8,9,9,0,9,9,8,8,8,9,4,8,13,9,9,1]

theorem envBound57937 : H12AffineFastState.Bounded env57937 := by
  intro p hp
  have h : env57937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57936_57937 : H12AffineEnvironment.transform 0 0 env57936 = env57937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57936 == env57937) = true)

def leafEnv57937 : List Nat := [0,4,8,9,9,9,9,12,0,13,8,9,8,8,8,1,9,9,13,8,8,9,9,0,4,9,1,9,8,8,8,9,4,8,13,9,5,1,9,1,1,9,0]

def active57937 : List Nat := [1,2]

def tree57937 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood57937 : H12WitnessSearch.Good tree57937 := H12GlobalWitnessIndex.good

theorem leafIdentity57937 : H12AffineFastState.composeSystem env57937 rootObs = leafEnv57937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env57937 rootObs == leafEnv57937) = true)

theorem terminalChecked57937 : H12PackedTerminal.terminalCheckFast leafEnv57937 active57937 tree57937 = true := by decide +kernel

def env57938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1345,32768,65536,131072,65837,1024,32768,132269,42108,140452,165219,8329,139273,99825,1345,131153,75787,196963,206022,257,65934,131072,512]

theorem envBound57938 : H12AffineFastState.Bounded env57938 := by
  intro p hp
  have h : env57938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57923_57938 : H12AffineEnvironment.transform 11 493 env57923 = env57938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57923 == env57938) = true)

theorem identity57938 : scanCanonicalize (H12AffineFastState.compose env57938 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound57938 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57939 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,493,8192,445,32768,65536,131072,65837,252,32768,131153,41088,139352,164255,8329,139273,98573,445,131153,75787,196963,204858,257,65934,131072,512]

theorem envBound57939 : H12AffineFastState.Bounded env57939 := by
  intro p hp
  have h : env57939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57938_57939 : H12AffineEnvironment.transform 9 252 env57938 = env57939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env57938 == env57939) = true)

def env57940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144713,169102,26057,157000,311708,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound57940 : H12AffineFastState.Bounded env57940 := by
  intro p hp
  have h : env57940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57901_57940 : H12AffineEnvironment.transform 20 136513 env57901 = env57940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57901 == env57940) = true)

def env57941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144713,169102,26057,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound57941 : H12AffineFastState.Bounded env57941 := by
  intro p hp
  have h : env57941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57940_57941 : H12AffineEnvironment.transform 17 87424 env57940 = env57941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57940 == env57941) = true)

theorem identity57941 : scanCanonicalize (H12AffineFastState.compose env57941 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound57941 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,444,32768,65536,131072,70716,1024,32768,136513,46480,144713,169102,9333,140532,103452,444,131153,77047,200846,204859,257,69730,131072,1788]

theorem envBound57942 : H12AffineFastState.Bounded env57942 := by
  intro p hp
  have h : env57942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57941_57942 : H12AffineEnvironment.transform 13 444 env57941 = env57942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57941 == env57942) = true)

def env57943 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,32768,65536,131072,69824,252,32768,135613,45420,143797,168050,8329,139272,102624,444,131153,75787,200846,204859,257,69730,131072,512]

theorem envBound57943 : H12AffineFastState.Bounded env57943 := by
  intro p hp
  have h : env57943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57942_57943 : H12AffineEnvironment.transform 9 252 env57942 = env57943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env57942 == env57943) = true)

theorem identity57943 : scanCanonicalize (H12AffineFastState.compose env57943 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57943 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57944 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,492,8192,444,32768,65536,131072,65836,252,32768,131153,41088,139353,164254,8329,139272,98572,444,131153,75787,196962,204859,257,65934,131072,512]

theorem envBound57944 : H12AffineFastState.Bounded env57944 := by
  intro p hp
  have h : env57944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57943_57944 : H12AffineEnvironment.transform 11 492 env57943 = env57944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57943 == env57944) = true)

def env57945 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,65536,131072,69825,253,32768,135612,45421,143796,168051,8328,139273,102625,444,131153,75786,200846,204859,257,69730,131072,513]

theorem envBound57945 : H12AffineFastState.Bounded env57945 := by
  intro p hp
  have h : env57945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57942_57945 : H12AffineEnvironment.transform 9 253 env57942 = env57945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env57942 == env57945) = true)

theorem identity57945 : scanCanonicalize (H12AffineFastState.compose env57945 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 36963) := by decide +kernel

theorem selectedBound57945 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57946 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36963,131072,32930,253,32768,135612,45421,143796,168051,8328,139273,130,444,131153,47209,164077,176216,257,32769,131072,513]

theorem envBound57946 : H12AffineFastState.Bounded env57946 := by
  intro p hp
  have h : env57946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57945_57946 : H12AffineEnvironment.transform 15 36963 env57945 = env57946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36963 env57945 == env57946) = true)

theorem identity57946 : scanCanonicalize (H12AffineFastState.compose env57946 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound57946 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57947 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36963,8217,32930,253,32768,12709,45421,4525,45162,8328,16,130,444,8264,47209,41204,36929,257,32769,8217,513]

theorem envBound57947 : H12AffineFastState.Bounded env57947 := by
  intro p hp
  have h : env57947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57946_57947 : H12AffineEnvironment.transform 16 8217 env57946 = env57947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env57946 == env57947) = true)

theorem identity57947 : scanCanonicalize (H12AffineFastState.compose env57947 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound57947 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57948 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,168,4299,8217,10,253,168,12709,12741,4525,12482,8328,16,130,444,8264,14529,8284,4329,257,169,8217,513]

theorem envBound57948 : H12AffineFastState.Bounded env57948 := by
  intro p hp
  have h : env57948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57947_57948 : H12AffineEnvironment.transform 14 168 env57947 = env57948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env57947 == env57948) = true)

theorem identity57948 : scanCanonicalize (H12AffineFastState.compose env57948 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound57948 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57949 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,2990,444,168,4299,2999,10,253,168,6667,6763,4525,7020,2854,16,130,444,3046,4975,3058,4329,257,169,2999,513]

theorem envBound57949 : H12AffineFastState.Bounded env57949 := by
  intro p hp
  have h : env57949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57948_57949 : H12AffineEnvironment.transform 12 2990 env57948 = env57949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env57948 == env57949) = true)

theorem identity57949 : scanCanonicalize (H12AffineFastState.compose env57949 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 3047) := by decide +kernel

theorem selectedBound57949 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57950 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3047,2990,444,168,2860,2999,10,253,168,492,396,2634,139,2854,16,130,444,3046,2184,3058,2830,257,169,2999,513]

theorem envBound57950 : H12AffineFastState.Bounded env57950 := by
  intro p hp
  have h : env57950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57949_57950 : H12AffineEnvironment.transform 11 3047 env57949 = env57950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3047 env57949 == env57950) = true)

theorem identity57950 : scanCanonicalize (H12AffineFastState.compose env57950 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound57950 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57951 : List Nat := [2,4,8,16,32,64,128,256,512,253,210,821,892,444,168,1022,869,10,253,168,492,396,664,139,1012,16,130,444,820,90,800,988,257,169,869,513]

theorem envBound57951 : H12AffineFastState.Bounded env57951 := by
  intro p hp
  have h : env57951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57950_57951 : H12AffineEnvironment.transform 10 210 env57950 = env57951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env57950 == env57951) = true)

theorem identity57951 : scanCanonicalize (H12AffineFastState.compose env57951 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57951 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57952 : List Nat := [2,4,8,16,32,64,128,256,372,253,210,65,8,444,168,138,17,10,253,168,492,396,492,139,128,16,130,444,64,90,84,168,257,169,17,373]

theorem envBound57952 : H12AffineFastState.Bounded env57952 := by
  intro p hp
  have h : env57952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57951_57952 : H12AffineEnvironment.transform 8 372 env57951 = env57952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57951 == env57952) = true)

theorem identity57952 : scanCanonicalize (H12AffineFastState.compose env57952 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound57952 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57953 : List Nat := [2,4,8,16,32,64,128,95,43,253,210,65,8,227,168,138,17,10,253,168,179,211,179,139,128,16,130,227,64,90,84,168,94,169,17,42]

theorem envBound57953 : H12AffineFastState.Bounded env57953 := by
  intro p hp
  have h : env57953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57952_57953 : H12AffineEnvironment.transform 7 95 env57952 = env57953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env57952 == env57953) = true)

theorem identity57953 : scanCanonicalize (H12AffineFastState.compose env57953 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound57953 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env57954 : List Nat := [2,4,8,16,32,64,16,95,43,109,66,65,8,115,56,26,17,10,109,56,35,67,35,27,16,16,18,115,64,90,84,56,94,57,17,42]

theorem envBound57954 : H12AffineFastState.Bounded env57954 := by
  intro p hp
  have h : env57954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57953_57954 : H12AffineEnvironment.transform 6 16 env57953 = env57954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env57953 == env57954) = true)

theorem identity57954 : scanCanonicalize (H12AffineFastState.compose env57954 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound57954 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57955 : List Nat := [2,4,8,16,32,35,16,60,43,14,33,34,8,16,56,26,17,10,14,56,35,32,35,27,16,16,18,16,35,57,55,56,61,57,17,42]

theorem envBound57955 : H12AffineFastState.Bounded env57955 := by
  intro p hp
  have h : env57955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57954_57955 : H12AffineEnvironment.transform 5 35 env57954 = env57955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env57954 == env57955) = true)

theorem identity57955 : scanCanonicalize (H12AffineFastState.compose env57955 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57956 : List Nat := [2,4,8,16,16,19,16,12,27,14,17,18,8,16,8,26,17,10,14,8,19,16,19,27,16,16,18,16,19,9,7,8,13,9,17,26]

theorem envBound57956 : H12AffineFastState.Bounded env57956 := by
  intro p hp
  have h : env57956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57955_57956 : H12AffineEnvironment.transform 4 16 env57955 = env57956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57955 == env57956) = true)

theorem identity57956 : scanCanonicalize (H12AffineFastState.compose env57956 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57957 : List Nat := [2,4,8,10,10,9,10,12,1,14,11,8,8,10,8,0,11,10,14,8,9,10,9,1,10,10,8,10,9,9,7,8,13,9,11,0]

theorem envBound57957 : H12AffineFastState.Bounded env57957 := by
  intro p hp
  have h : env57957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57956_57957 : H12AffineEnvironment.transform 3 10 env57956 = env57957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57956 == env57957) = true)

theorem identity57957 : scanCanonicalize (H12AffineFastState.compose env57957 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57957 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57958 : List Nat := [1,4,8,9,9,9,9,12,1,13,8,8,8,9,8,0,8,9,13,8,9,9,9,1,9,9,8,9,9,9,4,8,13,9,8,0]

theorem envBound57958 : H12AffineFastState.Bounded env57958 := by
  intro p hp
  have h : env57958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57957_57958 : H12AffineEnvironment.transform 0 1 env57957 = env57958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57957 == env57958) = true)

def leafEnv57958 : List Nat := [1,4,8,9,9,9,9,12,1,13,8,8,8,9,8,0,8,9,13,8,9,9,9,1,4,9,1,9,8,9,9,9,4,8,13,9,5,0,8,0,1,8,0]

def active57958 : List Nat := [1,2]

def tree57958 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood57958 : H12WitnessSearch.Good tree57958 := H12GlobalWitnessIndex.good

theorem leafIdentity57958 : H12AffineFastState.composeSystem env57958 rootObs = leafEnv57958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env57958 rootObs == leafEnv57958) = true)

theorem terminalChecked57958 : H12PackedTerminal.terminalCheckFast leafEnv57958 active57958 tree57958 = true := by decide +kernel

def env57959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144713,169102,26057,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound57959 : H12AffineFastState.Bounded env57959 := by
  intro p hp
  have h : env57959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57940_57959 : H12AffineEnvironment.transform 17 87425 env57940 = env57959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57940 == env57959) = true)

theorem identity57959 : scanCanonicalize (H12AffineFastState.compose env57959 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound57959 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57960 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,65536,131072,86396,253,32768,135612,45421,143796,168051,24884,156085,102624,16384,131153,92598,200846,221575,257,69730,131072,17341]

theorem envBound57960 : H12AffineFastState.Bounded env57960 := by
  intro p hp
  have h : env57960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57959_57960 : H12AffineEnvironment.transform 9 253 env57959 = env57960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env57959 == env57960) = true)

def env57961 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,65536,131072,69824,253,32768,135612,45421,143796,168051,8328,139273,102624,444,131153,75786,200846,204859,257,69730,131072,513]

theorem envBound57961 : H12AffineFastState.Bounded env57961 := by
  intro p hp
  have h : env57961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57960_57961 : H12AffineEnvironment.transform 13 444 env57960 = env57961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57960 == env57961) = true)

theorem identity57961 : scanCanonicalize (H12AffineFastState.compose env57961 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 36963) := by decide +kernel

theorem selectedBound57961 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57962 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36963,131072,32931,253,32768,135612,45421,143796,168051,8328,139273,131,444,131153,47209,164077,176216,257,32769,131072,513]

theorem envBound57962 : H12AffineFastState.Bounded env57962 := by
  intro p hp
  have h : env57962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57961_57962 : H12AffineEnvironment.transform 15 36963 env57961 = env57962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36963 env57961 == env57962) = true)

theorem identity57962 : scanCanonicalize (H12AffineFastState.compose env57962 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound57962 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57963 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36963,8217,32931,253,32768,12709,45421,4525,45162,8328,16,131,444,8264,47209,41204,36929,257,32769,8217,513]

theorem envBound57963 : H12AffineFastState.Bounded env57963 := by
  intro p hp
  have h : env57963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57962_57963 : H12AffineEnvironment.transform 16 8217 env57962 = env57963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env57962 == env57963) = true)

theorem identity57963 : scanCanonicalize (H12AffineFastState.compose env57963 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound57963 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57964 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,168,4299,8217,11,253,168,12709,12741,4525,12482,8328,16,131,444,8264,14529,8284,4329,257,169,8217,513]

theorem envBound57964 : H12AffineFastState.Bounded env57964 := by
  intro p hp
  have h : env57964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57963_57964 : H12AffineEnvironment.transform 14 168 env57963 = env57964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env57963 == env57964) = true)

theorem identity57964 : scanCanonicalize (H12AffineFastState.compose env57964 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound57964 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57965 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,2990,444,168,4299,2999,11,253,168,6667,6763,4525,7020,2854,16,131,444,3046,4975,3058,4329,257,169,2999,513]

theorem envBound57965 : H12AffineFastState.Bounded env57965 := by
  intro p hp
  have h : env57965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57964_57965 : H12AffineEnvironment.transform 12 2990 env57964 = env57965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env57964 == env57965) = true)

theorem identity57965 : scanCanonicalize (H12AffineFastState.compose env57965 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 3047) := by decide +kernel

theorem selectedBound57965 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57966 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3047,2990,444,168,2860,2999,11,253,168,492,396,2634,139,2854,16,131,444,3046,2184,3058,2830,257,169,2999,513]

theorem envBound57966 : H12AffineFastState.Bounded env57966 := by
  intro p hp
  have h : env57966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57965_57966 : H12AffineEnvironment.transform 11 3047 env57965 = env57966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3047 env57965 == env57966) = true)

theorem identity57966 : scanCanonicalize (H12AffineFastState.compose env57966 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound57966 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57967 : List Nat := [2,4,8,16,32,64,128,256,512,253,210,821,892,444,168,1022,869,11,253,168,492,396,664,139,1012,16,131,444,820,90,800,988,257,169,869,513]

theorem envBound57967 : H12AffineFastState.Bounded env57967 := by
  intro p hp
  have h : env57967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57966_57967 : H12AffineEnvironment.transform 10 210 env57966 = env57967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env57966 == env57967) = true)

theorem identity57967 : scanCanonicalize (H12AffineFastState.compose env57967 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57967 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57968 : List Nat := [2,4,8,16,32,64,128,256,372,253,210,65,8,444,168,138,17,11,253,168,492,396,492,139,128,16,131,444,64,90,84,168,257,169,17,373]

theorem envBound57968 : H12AffineFastState.Bounded env57968 := by
  intro p hp
  have h : env57968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57967_57968 : H12AffineEnvironment.transform 8 372 env57967 = env57968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57967 == env57968) = true)

theorem identity57968 : scanCanonicalize (H12AffineFastState.compose env57968 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound57968 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57969 : List Nat := [2,4,8,16,32,64,34,256,372,95,112,65,8,286,10,40,17,11,95,10,334,302,334,41,34,16,33,286,64,90,84,10,257,11,17,373]

theorem envBound57969 : H12AffineFastState.Bounded env57969 := by
  intro p hp
  have h : env57969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57968_57969 : H12AffineEnvironment.transform 6 34 env57968 = env57969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env57968 == env57969) = true)

theorem identity57969 : scanCanonicalize (H12AffineFastState.compose env57969 (packedSelected [2,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound57969 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env57970 : List Nat := [2,4,8,16,32,8,34,256,316,23,56,9,8,286,10,40,17,11,23,10,262,302,262,41,34,16,33,286,8,18,28,10,257,11,17,317]

theorem envBound57970 : H12AffineFastState.Bounded env57970 := by
  intro p hp
  have h : env57970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57969_57970 : H12AffineEnvironment.transform 5 8 env57969 = env57970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env57969 == env57970) = true)

theorem identity57970 : scanCanonicalize (H12AffineFastState.compose env57970 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound57970 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env57971 : List Nat := [2,4,8,9,32,8,34,256,293,14,33,9,8,263,10,40,8,11,14,10,262,302,262,41,34,9,33,263,8,11,5,10,257,11,8,292]

theorem envBound57971 : H12AffineFastState.Bounded env57971 := by
  intro p hp
  have h : env57971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57970_57971 : H12AffineEnvironment.transform 3 9 env57970 = env57971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env57970 == env57971) = true)

theorem identity57971 : scanCanonicalize (H12AffineFastState.compose env57971 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 38) := by decide +kernel

theorem selectedBound57971 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57972 : List Nat := [2,4,8,9,32,8,34,38,3,14,33,9,8,33,10,40,8,11,14,10,32,8,32,41,34,9,33,33,8,11,5,10,39,11,8,2]

theorem envBound57972 : H12AffineFastState.Bounded env57972 := by
  intro p hp
  have h : env57972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57971_57972 : H12AffineEnvironment.transform 7 38 env57971 = env57972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 38 env57971 == env57972) = true)

theorem identity57972 : scanCanonicalize (H12AffineFastState.compose env57972 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57973 : List Nat := [2,4,8,9,10,8,8,12,3,14,11,9,8,11,10,2,8,11,14,10,10,8,10,3,8,9,11,11,8,11,5,10,13,11,8,2]

theorem envBound57973 : H12AffineFastState.Bounded env57973 := by
  intro p hp
  have h : env57973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57972_57973 : H12AffineEnvironment.transform 4 10 env57972 = env57973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57972 == env57973) = true)

theorem identity57973 : scanCanonicalize (H12AffineFastState.compose env57973 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57973 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57974 : List Nat := [1,4,8,9,9,8,8,12,0,13,8,9,8,8,9,1,8,8,13,9,9,8,9,0,8,9,8,8,8,8,5,9,13,8,8,1]

theorem envBound57974 : H12AffineFastState.Bounded env57974 := by
  intro p hp
  have h : env57974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57973_57974 : H12AffineEnvironment.transform 0 1 env57973 = env57974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57973 == env57974) = true)

theorem identity57974 : scanCanonicalize (H12AffineFastState.compose env57974 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57975 : List Nat := [1,4,0,1,1,0,0,4,0,5,0,1,0,0,1,1,0,0,5,1,1,0,1,0,0,1,0,0,0,0,5,1,5,0,0,1]

theorem envBound57975 : H12AffineFastState.Bounded env57975 := by
  intro p hp
  have h : env57975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57974_57975 : H12AffineEnvironment.transform 2 0 env57974 = env57975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57974 == env57975) = true)

def env57976 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,445,32768,65536,131072,69825,253,32768,135612,45421,143796,168051,8329,139272,102624,445,131153,75787,200846,204858,257,69730,131072,512]

theorem envBound57976 : H12AffineFastState.Bounded env57976 := by
  intro p hp
  have h : env57976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57960_57976 : H12AffineEnvironment.transform 13 445 env57960 = env57976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57960 == env57976) = true)

theorem identity57976 : scanCanonicalize (H12AffineFastState.compose env57976 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57976 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57977 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,493,8192,445,32768,65536,131072,65836,253,32768,131153,41088,139353,164254,8329,139272,98573,445,131153,75787,196963,204858,257,65935,131072,512]

theorem envBound57977 : H12AffineFastState.Bounded env57977 := by
  intro p hp
  have h : env57977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57976_57977 : H12AffineEnvironment.transform 11 493 env57976 = env57977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57976 == env57977) = true)

def env57978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304862,33554432,6342040,2544860,16384,131153,4315355,6402142,221575,257,2295074,131072,33563273]

theorem envBound57978 : H12AffineFastState.Bounded env57978 := by
  intro p hp
  have h : env57978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57672_57978 : H12AffineEnvironment.transform 22 6329753 env57672 = env57978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env57672 == env57978) = true)

def env57979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304862,4247640,6342040,2544860,16384,131153,4315355,6402142,221575,257,2295074,131072,4256465]

theorem envBound57979 : H12AffineFastState.Bounded env57979 := by
  intro p hp
  have h : env57979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57978_57979 : H12AffineEnvironment.transform 24 4247640 env57978 = env57979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env57978 == env57979) = true)

def env57980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144713,169102,2257032,157000,2544860,16384,131153,2324491,200846,221575,257,2295074,131072,2249217]

theorem envBound57980 : H12AffineFastState.Bounded env57980 := by
  intro p hp
  have h : env57980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57979_57980 : H12AffineEnvironment.transform 21 2269392 env57979 = env57980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env57979 == env57980) = true)

def env57981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144713,169102,26056,157000,311708,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57981 : H12AffineFastState.Bounded env57981 := by
  intro p hp
  have h : env57981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57980_57981 : H12AffineEnvironment.transform 20 136512 env57980 = env57981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57980 == env57981) = true)

def env57982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144713,169102,26056,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57982 : H12AffineFastState.Bounded env57982 := by
  intro p hp
  have h : env57982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57981_57982 : H12AffineEnvironment.transform 17 87424 env57981 = env57982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57981 == env57982) = true)

theorem identity57982 : scanCanonicalize (H12AffineFastState.compose env57982 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 107882) := by decide +kernel

theorem selectedBound57982 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,107882,87424,1024,32768,110634,46480,102435,78308,26056,114722,103452,16384,107835,93515,46564,50413,257,69730,107882,18241]

theorem envBound57983 : H12AffineFastState.Bounded env57983 := by
  intro p hp
  have h : env57983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57982_57983 : H12AffineEnvironment.transform 16 107882 env57982 = env57983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 107882 env57982 == env57983) = true)

def env57984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,107882,69824,1024,32768,110634,46480,102435,78308,8328,99682,103452,1344,107835,75787,46564,33197,257,69730,107882,513]

theorem envBound57984 : H12AffineFastState.Bounded env57984 := by
  intro p hp
  have h : env57984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57983_57984 : H12AffineEnvironment.transform 13 1344 env57983 = env57984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57983 == env57984) = true)

theorem identity57984 : scanCanonicalize (H12AffineFastState.compose env57984 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57984 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,12788,33886,1024,32768,9396,46480,1213,42362,8328,4604,130,1344,12709,48277,46564,33197,257,34044,12788,513]

theorem envBound57985 : H12AffineFastState.Bounded env57985 := by
  intro p hp
  have h : env57985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57984_57985 : H12AffineEnvironment.transform 15 38046 env57984 = env57985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57984 == env57985) = true)

theorem identity57985 : scanCanonicalize (H12AffineFastState.compose env57985 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57985 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,32768,34163,8217,33886,1024,32768,9396,42109,1213,42362,8328,17,130,1344,8264,44408,41993,33197,257,34044,8217,513]

theorem envBound57986 : H12AffineFastState.Bounded env57986 := by
  intro p hp
  have h : env57986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57985_57986 : H12AffineEnvironment.transform 11 493 env57985 = env57986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57985 == env57986) = true)

theorem identity57986 : scanCanonicalize (H12AffineFastState.compose env57986 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57986 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1109,294,8217,11,1024,1109,9396,8232,1213,8495,8328,17,130,1344,8264,10541,8284,1528,257,169,8217,513]

theorem envBound57987 : H12AffineFastState.Bounded env57987 := by
  intro p hp
  have h : env57987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57986_57987 : H12AffineEnvironment.transform 14 1109 env57986 = env57987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57986 == env57987) = true)

theorem identity57987 : scanCanonicalize (H12AffineFastState.compose env57987 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound57987 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,8192,1344,1109,294,8217,11,1024,1109,9396,8232,1213,8495,8328,17,130,1344,8264,10202,8284,1528,257,169,8217,513]

theorem envBound57988 : H12AffineFastState.Bounded env57988 := by
  intro p hp
  have h : env57988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57987_57988 : H12AffineEnvironment.transform 10 1783 env57987 = env57988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env57987 == env57988) = true)

theorem identity57988 : scanCanonicalize (H12AffineFastState.compose env57988 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound57988 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,420,1344,1109,294,445,11,1024,1109,1296,396,1213,139,300,17,130,1344,492,1662,504,1528,257,169,445,513]

theorem envBound57989 : H12AffineFastState.Bounded env57989 := by
  intro p hp
  have h : env57989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57988_57989 : H12AffineEnvironment.transform 12 420 env57988 = env57989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57988 == env57989) = true)

theorem identity57989 : scanCanonicalize (H12AffineFastState.compose env57989 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57989 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57990 : List Nat := [2,4,8,16,32,64,128,256,373,1024,1410,493,420,1344,1109,294,445,11,1024,1109,1296,396,1213,139,300,17,130,1344,492,1291,504,1528,257,169,445,372]

theorem envBound57990 : H12AffineFastState.Bounded env57990 := by
  intro p hp
  have h : env57990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57989_57990 : H12AffineEnvironment.transform 8 373 env57989 = env57990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57989 == env57990) = true)

theorem identity57990 : scanCanonicalize (H12AffineFastState.compose env57990 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57990 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57991 : List Nat := [2,4,8,16,32,64,128,15,122,1024,1165,226,171,1103,1109,41,178,11,1024,1109,1055,131,1213,139,35,17,130,1103,227,1028,247,1271,14,169,178,123]

theorem envBound57991 : H12AffineFastState.Bounded env57991 := by
  intro p hp
  have h : env57991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57990_57991 : H12AffineEnvironment.transform 7 15 env57990 = env57991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57990 == env57991) = true)

def env57992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,107882,69825,1024,32768,110634,46480,102435,78308,8329,99683,103452,1345,107835,75786,46564,33196,257,69730,107882,512]

theorem envBound57992 : H12AffineFastState.Bounded env57992 := by
  intro p hp
  have h : env57992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57983_57992 : H12AffineEnvironment.transform 13 1345 env57983 = env57992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57983 == env57992) = true)

theorem identity57992 : scanCanonicalize (H12AffineFastState.compose env57992 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57992 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,107882,67024,1024,32768,107835,41089,99634,74997,8329,99683,98573,1345,107835,75786,41205,33196,257,66931,107882,512]

theorem envBound57993 : H12AffineFastState.Bounded env57993 := by
  intro p hp
  have h : env57993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57992_57993 : H12AffineEnvironment.transform 11 1297 env57992 = env57993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57992 == env57993) = true)

def env57994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144713,169102,26056,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound57994 : H12AffineFastState.Bounded env57994 := by
  intro p hp
  have h : env57994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57981_57994 : H12AffineEnvironment.transform 17 87425 env57981 = env57994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57981 == env57994) = true)

theorem identity57994 : scanCanonicalize (H12AffineFastState.compose env57994 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 122922) := by decide +kernel

theorem selectedBound57994 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122922,87425,1024,32768,128362,46480,120163,95396,26056,99682,103453,16384,123003,93515,61604,33197,257,69730,122922,18241]

theorem envBound57995 : H12AffineFastState.Bounded env57995 := by
  intro p hp
  have h : env57995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57994_57995 : H12AffineEnvironment.transform 16 122922 env57994 = env57995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122922 env57994 == env57995) = true)

def env57996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,107882,69825,1024,32768,110634,46480,102435,78308,8328,99682,103453,1344,107835,75787,46564,33197,257,69730,107882,513]

theorem envBound57996 : H12AffineFastState.Bounded env57996 := by
  intro p hp
  have h : env57996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57995_57996 : H12AffineEnvironment.transform 13 1344 env57995 = env57996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57995 == env57996) = true)

theorem identity57996 : scanCanonicalize (H12AffineFastState.compose env57996 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57996 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,12788,33887,1024,32768,9396,46480,1213,42362,8328,4604,131,1344,12709,48277,46564,33197,257,34044,12788,513]

theorem envBound57997 : H12AffineFastState.Bounded env57997 := by
  intro p hp
  have h : env57997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57996_57997 : H12AffineEnvironment.transform 15 38046 env57996 = env57997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57996 == env57997) = true)

theorem identity57997 : scanCanonicalize (H12AffineFastState.compose env57997 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57997 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,32768,34163,8217,33887,1024,32768,9396,42109,1213,42362,8328,17,131,1344,8264,44408,41993,33197,257,34044,8217,513]

theorem envBound57998 : H12AffineFastState.Bounded env57998 := by
  intro p hp
  have h : env57998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57997_57998 : H12AffineEnvironment.transform 11 493 env57997 = env57998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57997 == env57998) = true)

theorem identity57998 : scanCanonicalize (H12AffineFastState.compose env57998 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57998 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1109,294,8217,10,1024,1109,9396,8232,1213,8495,8328,17,131,1344,8264,10541,8284,1528,257,169,8217,513]

theorem envBound57999 : H12AffineFastState.Bounded env57999 := by
  intro p hp
  have h : env57999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57998_57999 : H12AffineEnvironment.transform 14 1109 env57998 = env57999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57998 == env57999) = true)

theorem identity57999 : scanCanonicalize (H12AffineFastState.compose env57999 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound57999 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,8192,1344,1109,294,8217,10,1024,1109,9396,8232,1213,8495,8328,17,131,1344,8264,10202,8284,1528,257,169,8217,513]

theorem envBound58000 : H12AffineFastState.Bounded env58000 := by
  intro p hp
  have h : env58000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57999_58000 : H12AffineEnvironment.transform 10 1783 env57999 = env58000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env57999 == env58000) = true)

theorem identity58000 : scanCanonicalize (H12AffineFastState.compose env58000 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound58000 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,420,1344,1109,294,445,10,1024,1109,1296,396,1213,139,300,17,131,1344,492,1662,504,1528,257,169,445,513]

theorem envBound58001 : H12AffineFastState.Bounded env58001 := by
  intro p hp
  have h : env58001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58000_58001 : H12AffineEnvironment.transform 12 420 env58000 = env58001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58000 == env58001) = true)

theorem identity58001 : scanCanonicalize (H12AffineFastState.compose env58001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58002 : List Nat := [2,4,8,16,32,64,128,256,373,1024,1410,493,420,1344,1109,294,445,10,1024,1109,1296,396,1213,139,300,17,131,1344,492,1291,504,1528,257,169,445,372]

theorem envBound58002 : H12AffineFastState.Bounded env58002 := by
  intro p hp
  have h : env58002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58001_58002 : H12AffineEnvironment.transform 8 373 env58001 = env58002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58001 == env58002) = true)

theorem identity58002 : scanCanonicalize (H12AffineFastState.compose env58002 (packedSelected [3,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 419) := by decide +kernel

theorem selectedBound58002 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58003 : List Nat := [2,4,8,16,32,64,128,256,373,419,33,493,420,227,502,294,445,10,419,502,179,396,286,139,300,17,131,227,492,168,504,91,257,169,445,372]

theorem envBound58003 : H12AffineFastState.Bounded env58003 := by
  intro p hp
  have h : env58003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58002_58003 : H12AffineEnvironment.transform 9 419 env58002 = env58003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 419 env58002 == env58003) = true)

def env58004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,107883,69824,1024,32768,110635,46480,102434,78309,8329,99682,103453,1345,107834,75786,46565,33197,257,69730,107883,512]

theorem envBound58004 : H12AffineFastState.Bounded env58004 := by
  intro p hp
  have h : env58004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57995_58004 : H12AffineEnvironment.transform 13 1345 env57995 = env58004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57995 == env58004) = true)

theorem identity58004 : scanCanonicalize (H12AffineFastState.compose env58004 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58004 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,107883,67025,1024,32768,107834,41089,99635,74996,8329,99682,98572,1345,107834,75786,41204,33197,257,66931,107883,512]

theorem envBound58005 : H12AffineFastState.Bounded env58005 := by
  intro p hp
  have h : env58005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58004_58005 : H12AffineEnvironment.transform 11 1297 env58004 = env58005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58004 == env58005) = true)

def env58006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144713,169102,26057,157000,311709,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58006 : H12AffineFastState.Bounded env58006 := by
  intro p hp
  have h : env58006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57980_58006 : H12AffineEnvironment.transform 20 136513 env57980 = env58006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57980 == env58006) = true)

def env58007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144713,169102,26057,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58007 : H12AffineFastState.Bounded env58007 := by
  intro p hp
  have h : env58007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58006_58007 : H12AffineEnvironment.transform 17 87424 env58006 = env58007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58006 == env58007) = true)

theorem identity58007 : scanCanonicalize (H12AffineFastState.compose env58007 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 128314) := by decide +kernel

theorem selectedBound58007 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,128314,87424,1024,32768,123003,46481,114803,90548,26057,102514,103453,16384,128363,93514,58804,38077,257,69731,128314,18240]

theorem envBound58008 : H12AffineFastState.Bounded env58008 := by
  intro p hp
  have h : env58008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58007_58008 : H12AffineEnvironment.transform 16 128314 env58007 = env58008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 128314 env58007 == env58008) = true)

def env58009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,110714,69824,1024,32768,107835,46481,99635,74996,8329,102514,103453,1344,110635,75786,41204,38077,257,69731,110714,512]

theorem envBound58009 : H12AffineFastState.Bounded env58009 := by
  intro p hp
  have h : env58009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58008_58009 : H12AffineEnvironment.transform 13 1344 env58008 = env58009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58008 == env58009) = true)

theorem identity58009 : scanCanonicalize (H12AffineFastState.compose env58009 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58009 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,107882,67024,1024,32768,107835,41089,99635,74996,8329,99682,98573,1344,107835,75786,41204,33197,257,66931,107882,512]

theorem envBound58010 : H12AffineFastState.Bounded env58010 := by
  intro p hp
  have h : env58010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58009_58010 : H12AffineEnvironment.transform 11 1296 env58009 = env58010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58009 == env58010) = true)

def env58011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,110715,69825,1024,32768,107834,46481,99634,74997,8328,102514,103453,1345,110634,75787,41205,38077,257,69731,110715,513]

theorem envBound58011 : H12AffineFastState.Bounded env58011 := by
  intro p hp
  have h : env58011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58008_58011 : H12AffineEnvironment.transform 13 1345 env58008 = env58011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58008 == env58011) = true)

theorem identity58011 : scanCanonicalize (H12AffineFastState.compose env58011 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58011 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,9444,33886,1024,32768,12709,46481,4525,45162,8328,1261,130,1345,9397,48276,41205,38077,257,34044,9444,513]

theorem envBound58012 : H12AffineFastState.Bounded env58012 := by
  intro p hp
  have h : env58012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58011_58012 : H12AffineEnvironment.transform 15 38047 env58011 = env58012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58011 == env58012) = true)

theorem identity58012 : scanCanonicalize (H12AffineFastState.compose env58012 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58012 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58013 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,32768,36963,8216,32930,252,32768,12709,45421,4525,45162,8328,17,130,445,8265,47208,41205,36929,257,32768,8216,513]

theorem envBound58013 : H12AffineFastState.Bounded env58013 := by
  intro p hp
  have h : env58013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58012_58013 : H12AffineEnvironment.transform 9 252 env58012 = env58013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58012 == env58013) = true)

theorem identity58013 : scanCanonicalize (H12AffineFastState.compose env58013 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound58013 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58014 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,169,4298,8216,11,252,169,12709,12740,4525,12483,8328,17,130,445,8265,14529,8284,4328,257,169,8216,513]

theorem envBound58014 : H12AffineFastState.Bounded env58014 := by
  intro p hp
  have h : env58014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58013_58014 : H12AffineEnvironment.transform 14 169 env58013 = env58014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env58013 == env58014) = true)

theorem identity58014 : scanCanonicalize (H12AffineFastState.compose env58014 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound58014 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58015 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,4096,8192,445,169,4298,8216,11,252,169,12709,12740,4525,12483,8328,17,130,445,8265,13002,8284,4328,257,169,8216,513]

theorem envBound58015 : H12AffineFastState.Bounded env58015 := by
  intro p hp
  have h : env58015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58014_58015 : H12AffineEnvironment.transform 10 523 env58014 = env58015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env58014 == env58015) = true)

theorem identity58015 : scanCanonicalize (H12AffineFastState.compose env58015 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4168) := by decide +kernel

theorem selectedBound58015 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58016 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,4096,4168,445,169,4298,4176,11,252,169,493,396,4525,139,4288,17,130,445,4097,642,4116,4328,257,169,4176,513]

theorem envBound58016 : H12AffineFastState.Bounded env58016 := by
  intro p hp
  have h : env58016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58015_58016 : H12AffineEnvironment.transform 12 4168 env58015 = env58016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4168 env58015 == env58016) = true)

theorem identity58016 : scanCanonicalize (H12AffineFastState.compose env58016 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58016 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58017 : List Nat := [2,4,8,16,32,64,128,256,372,252,383,4096,4168,445,169,4298,4176,11,252,169,493,396,4525,139,4288,17,130,445,4097,502,4116,4328,257,169,4176,373]

theorem envBound58017 : H12AffineFastState.Bounded env58017 := by
  intro p hp
  have h : env58017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58016_58017 : H12AffineEnvironment.transform 8 372 env58016 = env58017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58016 == env58017) = true)

theorem identity58017 : scanCanonicalize (H12AffineFastState.compose env58017 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound58017 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env58018 : List Nat := [2,4,8,16,32,64,35,256,372,95,383,4096,4168,286,10,4201,4176,11,95,10,334,303,4366,40,4195,17,33,286,4097,341,4116,4171,257,10,4176,373]

theorem envBound58018 : H12AffineFastState.Bounded env58018 := by
  intro p hp
  have h : env58018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58017_58018 : H12AffineEnvironment.transform 6 35 env58017 = env58018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env58017 == env58018) = true)

theorem identity58018 : scanCanonicalize (H12AffineFastState.compose env58018 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58018 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58019 : List Nat := [2,4,8,16,32,16,35,256,292,15,303,4096,4120,286,10,4153,4096,11,15,10,286,303,4366,40,4147,17,33,286,4097,261,4116,4123,257,10,4096,293]

theorem envBound58019 : H12AffineFastState.Bounded env58019 := by
  intro p hp
  have h : env58019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58018_58019 : H12AffineEnvironment.transform 5 16 env58018 = env58019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58018 == env58019) = true)

theorem identity58019 : scanCanonicalize (H12AffineFastState.compose env58019 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 271) := by decide +kernel

theorem selectedBound58019 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58020 : List Nat := [2,4,8,16,32,16,35,256,292,15,303,271,279,286,10,310,271,11,15,10,286,303,1,40,316,17,33,286,270,261,283,276,257,10,271,293]

theorem envBound58020 : H12AffineFastState.Bounded env58020 := by
  intro p hp
  have h : env58020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58019_58020 : H12AffineEnvironment.transform 11 271 env58019 = env58020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 271 env58019 == env58020) = true)

theorem identity58020 : scanCanonicalize (H12AffineFastState.compose env58020 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58020 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env58021 : List Nat := [2,4,8,1,32,1,35,256,292,15,303,271,262,271,10,295,271,11,15,10,271,303,1,40,301,0,33,271,270,261,266,261,257,10,271,293]

theorem envBound58021 : H12AffineFastState.Bounded env58021 := by
  intro p hp
  have h : env58021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58020_58021 : H12AffineEnvironment.transform 3 1 env58020 = env58021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58020 == env58021) = true)

theorem identity58021 : scanCanonicalize (H12AffineFastState.compose env58021 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound58021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58022 : List Nat := [2,4,8,1,32,1,35,15,43,15,32,0,9,0,10,40,0,11,15,10,0,32,1,40,34,0,33,0,1,10,5,10,14,10,0,42]

theorem envBound58022 : H12AffineFastState.Bounded env58022 := by
  intro p hp
  have h : env58022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58021_58022 : H12AffineEnvironment.transform 7 15 env58021 = env58022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env58021 == env58022) = true)

theorem identity58022 : scanCanonicalize (H12AffineFastState.compose env58022 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58023 : List Nat := [2,4,0,1,32,1,35,7,35,7,32,0,1,0,2,32,0,3,7,2,0,32,1,32,34,0,33,0,1,2,5,2,6,2,0,34]

theorem envBound58023 : H12AffineFastState.Bounded env58023 := by
  intro p hp
  have h : env58023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58022_58023 : H12AffineEnvironment.transform 2 0 env58022 = env58023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58022 == env58023) = true)

theorem identity58023 : scanCanonicalize (H12AffineFastState.compose env58023 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound58023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58024 : List Nat := [2,4,0,1,0,1,3,7,3,7,0,0,1,0,2,0,0,3,7,2,0,0,1,0,2,0,1,0,1,2,5,2,6,2,0,2]

theorem envBound58024 : H12AffineFastState.Bounded env58024 := by
  intro p hp
  have h : env58024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58023_58024 : H12AffineEnvironment.transform 4 0 env58023 = env58024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58023 == env58024) = true)

theorem identity58024 : scanCanonicalize (H12AffineFastState.compose env58024 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58024 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58025 : List Nat := [0,4,0,1,0,1,1,5,1,5,0,0,1,0,0,0,0,1,5,0,0,0,1,0,0,0,1,0,1,0,5,0,4,0,0,0]

theorem envBound58025 : H12AffineFastState.Bounded env58025 := by
  intro p hp
  have h : env58025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58024_58025 : H12AffineEnvironment.transform 0 0 env58024 = env58025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58024 == env58025) = true)

def env58026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144713,169102,26057,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58026 : H12AffineFastState.Bounded env58026 := by
  intro p hp
  have h : env58026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58006_58026 : H12AffineEnvironment.transform 17 87425 env58006 = env58026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58006 == env58026) = true)

theorem identity58026 : scanCanonicalize (H12AffineFastState.compose env58026 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 110715) := by decide +kernel

theorem selectedBound58026 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,110715,87425,1024,32768,107834,46481,99634,74997,26057,120115,103452,16384,110634,93514,41205,53756,257,69731,110715,18240]

theorem envBound58027 : H12AffineFastState.Bounded env58027 := by
  intro p hp
  have h : env58027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58026_58027 : H12AffineEnvironment.transform 16 110715 env58026 = env58027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110715 env58026 == env58027) = true)

def env58028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,110715,69825,1024,32768,107834,46481,99634,74997,8329,102515,103452,1344,110634,75786,41205,38076,257,69731,110715,512]

theorem envBound58028 : H12AffineFastState.Bounded env58028 := by
  intro p hp
  have h : env58028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58027_58028 : H12AffineEnvironment.transform 13 1344 env58027 = env58028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58027 == env58028) = true)

theorem identity58028 : scanCanonicalize (H12AffineFastState.compose env58028 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58028 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,107883,67025,1024,32768,107834,41089,99634,74997,8329,99683,98572,1344,107834,75786,41205,33196,257,66931,107883,512]

theorem envBound58029 : H12AffineFastState.Bounded env58029 := by
  intro p hp
  have h : env58029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58028_58029 : H12AffineEnvironment.transform 11 1296 env58028 = env58029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58028 == env58029) = true)

def env58030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,110715,69824,1024,32768,107834,46481,99634,74997,8328,102514,103452,1345,110634,75787,41205,38077,257,69731,110715,513]

theorem envBound58030 : H12AffineFastState.Bounded env58030 := by
  intro p hp
  have h : env58030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58027_58030 : H12AffineEnvironment.transform 13 1345 env58027 = env58030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58027 == env58030) = true)

theorem identity58030 : scanCanonicalize (H12AffineFastState.compose env58030 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58030 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,9444,33887,1024,32768,12709,46481,4525,45162,8328,1261,131,1345,9397,48276,41205,38077,257,34044,9444,513]

theorem envBound58031 : H12AffineFastState.Bounded env58031 := by
  intro p hp
  have h : env58031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58030_58031 : H12AffineEnvironment.transform 15 38047 env58030 = env58031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58030 == env58031) = true)

theorem identity58031 : scanCanonicalize (H12AffineFastState.compose env58031 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58031 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58032 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,32768,36963,8216,32931,252,32768,12709,45421,4525,45162,8328,17,131,445,8265,47208,41205,36929,257,32768,8216,513]

theorem envBound58032 : H12AffineFastState.Bounded env58032 := by
  intro p hp
  have h : env58032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58031_58032 : H12AffineEnvironment.transform 9 252 env58031 = env58032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58031 == env58032) = true)

theorem identity58032 : scanCanonicalize (H12AffineFastState.compose env58032 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound58032 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58033 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,169,4298,8216,10,252,169,12709,12740,4525,12483,8328,17,131,445,8265,14529,8284,4328,257,169,8216,513]

theorem envBound58033 : H12AffineFastState.Bounded env58033 := by
  intro p hp
  have h : env58033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58032_58033 : H12AffineEnvironment.transform 14 169 env58032 = env58033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env58032 == env58033) = true)

theorem identity58033 : scanCanonicalize (H12AffineFastState.compose env58033 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound58033 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58034 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,4096,8192,445,169,4298,8216,10,252,169,12709,12740,4525,12483,8328,17,131,445,8265,13002,8284,4328,257,169,8216,513]

theorem envBound58034 : H12AffineFastState.Bounded env58034 := by
  intro p hp
  have h : env58034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58033_58034 : H12AffineEnvironment.transform 10 523 env58033 = env58034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env58033 == env58034) = true)

theorem identity58034 : scanCanonicalize (H12AffineFastState.compose env58034 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4168) := by decide +kernel

theorem selectedBound58034 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58035 : List Nat := [2,4,8,16,32,64,128,256,512,252,523,4096,4168,445,169,4298,4176,10,252,169,493,396,4525,139,4288,17,131,445,4097,642,4116,4328,257,169,4176,513]

theorem envBound58035 : H12AffineFastState.Bounded env58035 := by
  intro p hp
  have h : env58035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58034_58035 : H12AffineEnvironment.transform 12 4168 env58034 = env58035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4168 env58034 == env58035) = true)

theorem identity58035 : scanCanonicalize (H12AffineFastState.compose env58035 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58035 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58036 : List Nat := [2,4,8,16,32,64,128,256,372,252,383,4096,4168,445,169,4298,4176,10,252,169,493,396,4525,139,4288,17,131,445,4097,502,4116,4328,257,169,4176,373]

theorem envBound58036 : H12AffineFastState.Bounded env58036 := by
  intro p hp
  have h : env58036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58035_58036 : H12AffineEnvironment.transform 8 372 env58035 = env58036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58035 == env58036) = true)

theorem identity58036 : scanCanonicalize (H12AffineFastState.compose env58036 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 287) := by decide +kernel

theorem selectedBound58036 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env58037 : List Nat := [2,4,8,16,32,64,128,256,372,252,383,287,343,445,169,469,335,10,252,169,493,396,178,139,479,17,131,445,286,502,267,503,257,169,335,373]

theorem envBound58037 : H12AffineFastState.Bounded env58037 := by
  intro p hp
  have h : env58037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58036_58037 : H12AffineEnvironment.transform 11 287 env58036 = env58037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 287 env58036 == env58037) = true)

theorem identity58037 : scanCanonicalize (H12AffineFastState.compose env58037 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound58037 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58038 : List Nat := [2,4,8,16,32,64,128,94,42,252,33,65,9,227,169,139,17,10,252,169,179,210,178,139,129,17,131,227,64,168,85,169,95,169,17,43]

theorem envBound58038 : H12AffineFastState.Bounded env58038 := by
  intro p hp
  have h : env58038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58037_58038 : H12AffineEnvironment.transform 7 94 env58037 = env58038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env58037 == env58038) = true)

theorem identity58038 : scanCanonicalize (H12AffineFastState.compose env58038 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 57) := by decide +kernel

theorem selectedBound58038 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env58039 : List Nat := [2,4,8,16,32,57,128,39,42,133,33,56,9,154,169,139,17,10,133,169,179,171,178,139,129,17,131,154,57,168,44,169,38,169,17,43]

theorem envBound58039 : H12AffineFastState.Bounded env58039 := by
  intro p hp
  have h : env58039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58038_58039 : H12AffineEnvironment.transform 5 57 env58038 = env58039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 57 env58038 == env58039) = true)

theorem identity58039 : scanCanonicalize (H12AffineFastState.compose env58039 (packedSelected [4,5,11] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound58039 : packedSelected [4,5,11] rootPS < 2^1333 := by decide +kernel

def env58040 : List Nat := [2,4,8,16,32,57,11,39,42,14,33,56,9,17,34,0,17,10,14,34,56,32,57,0,10,17,8,17,57,35,44,34,38,34,17,43]

theorem envBound58040 : H12AffineFastState.Bounded env58040 := by
  intro p hp
  have h : env58040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58039_58040 : H12AffineEnvironment.transform 6 11 env58039 = env58040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env58039 == env58040) = true)

theorem identity58040 : scanCanonicalize (H12AffineFastState.compose env58040 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound58040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58041 : List Nat := [2,4,2,16,32,51,1,39,32,4,33,50,3,17,34,0,17,0,4,34,50,32,51,0,0,17,2,17,51,35,38,34,38,34,17,33]

theorem envBound58041 : H12AffineFastState.Bounded env58041 := by
  intro p hp
  have h : env58041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58040_58041 : H12AffineEnvironment.transform 2 2 env58040 = env58041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env58040 == env58041) = true)

theorem identity58041 : scanCanonicalize (H12AffineFastState.compose env58041 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound58041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58042 : List Nat := [2,4,2,2,32,33,1,39,32,4,33,32,3,3,34,0,3,0,4,34,32,32,33,0,0,3,2,3,33,35,38,34,38,34,3,33]

theorem envBound58042 : H12AffineFastState.Bounded env58042 := by
  intro p hp
  have h : env58042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58041_58042 : H12AffineEnvironment.transform 3 2 env58041 = env58042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env58041 == env58042) = true)

def env58043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144712,169103,2257033,157001,2544860,16384,131153,2324490,200847,221575,257,2295074,131072,2249216]

theorem envBound58043 : H12AffineFastState.Bounded env58043 := by
  intro p hp
  have h : env58043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57979_58043 : H12AffineEnvironment.transform 21 2269393 env57979 = env58043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env57979 == env58043) = true)

def env58044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144712,169103,26057,157001,311708,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound58044 : H12AffineFastState.Bounded env58044 := by
  intro p hp
  have h : env58044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58043_58044 : H12AffineEnvironment.transform 20 136512 env58043 = env58044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58043 == env58044) = true)

def env58045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144712,169103,26057,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound58045 : H12AffineFastState.Bounded env58045 := by
  intro p hp
  have h : env58045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58044_58045 : H12AffineEnvironment.transform 17 87424 env58044 = env58045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58044 == env58045) = true)

theorem identity58045 : scanCanonicalize (H12AffineFastState.compose env58045 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 103715) := by decide +kernel

theorem selectedBound58045 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103715,87424,1024,32768,98403,46481,106603,65964,26057,127082,103452,16384,103794,93514,34220,62628,257,69730,103715,18240]

theorem envBound58046 : H12AffineFastState.Bounded env58046 := by
  intro p hp
  have h : env58046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58045_58046 : H12AffineEnvironment.transform 16 103715 env58045 = env58046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103715 env58045 == env58046) = true)

def env58047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,103715,69824,1024,32768,98403,46481,106603,65964,8329,111914,103452,1344,103794,75786,34220,45540,257,69730,103715,512]

theorem envBound58047 : H12AffineFastState.Bounded env58047 := by
  intro p hp
  have h : env58047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58046_58047 : H12AffineEnvironment.transform 13 1344 env58046 = env58047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58046 == env58047) = true)

theorem identity58047 : scanCanonicalize (H12AffineFastState.compose env58047 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58047 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,98355,67024,1024,32768,98403,41089,106603,65964,8329,106554,98572,1344,98402,75786,34220,42228,257,66930,98355,512]

theorem envBound58048 : H12AffineFastState.Bounded env58048 := by
  intro p hp
  have h : env58048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58047_58048 : H12AffineEnvironment.transform 11 1296 env58047 = env58048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58047 == env58048) = true)

def env58049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,103715,69825,1024,32768,98403,46481,106603,65964,8328,111915,103452,1345,103794,75787,34220,45541,257,69730,103715,513]

theorem envBound58049 : H12AffineFastState.Bounded env58049 := by
  intro p hp
  have h : env58049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58046_58049 : H12AffineEnvironment.transform 13 1345 env58046 = env58049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58046 == env58049) = true)

theorem identity58049 : scanCanonicalize (H12AffineFastState.compose env58049 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58049 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,445,33887,1024,32768,5373,46481,13557,38194,8328,8629,130,1345,492,48277,34220,45541,257,34044,445,513]

theorem envBound58050 : H12AffineFastState.Bounded env58050 := by
  intro p hp
  have h : env58050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58049_58050 : H12AffineEnvironment.transform 15 38046 env58049 = env58050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58049 == env58050) = true)

theorem identity58050 : scanCanonicalize (H12AffineFastState.compose env58050 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound58050 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,32768,38046,445,33887,1024,32768,5373,37940,5456,38194,301,16,130,1345,492,40240,34220,36928,257,34044,445,513]

theorem envBound58051 : H12AffineFastState.Bounded env58051 := by
  intro p hp
  have h : env58051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58050_58051 : H12AffineEnvironment.transform 12 421 env58050 = env58051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env58050 == env58051) = true)

theorem identity58051 : scanCanonicalize (H12AffineFastState.compose env58051 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58051 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1108,4298,445,11,1024,1108,5373,4192,5456,4454,301,16,130,1345,492,6500,504,5140,257,168,445,513]

theorem envBound58052 : H12AffineFastState.Bounded env58052 := by
  intro p hp
  have h : env58052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58051_58052 : H12AffineEnvironment.transform 14 1108 env58051 = env58052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58051 == env58052) = true)

theorem identity58052 : scanCanonicalize (H12AffineFastState.compose env58052 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1882) := by decide +kernel

theorem selectedBound58052 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,4096,421,1345,1108,4298,445,11,1024,1108,5373,4192,5456,4454,301,16,130,1345,492,5694,504,5140,257,168,445,513]

theorem envBound58053 : H12AffineFastState.Bounded env58053 := by
  intro p hp
  have h : env58053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58052_58053 : H12AffineEnvironment.transform 10 1882 env58052 = env58053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1882 env58052 == env58053) = true)

theorem identity58053 : scanCanonicalize (H12AffineFastState.compose env58053 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound58053 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,444,421,1345,1108,374,445,11,1024,1108,1345,476,1260,218,301,16,130,1345,492,1922,504,1448,257,168,445,513]

theorem envBound58054 : H12AffineFastState.Bounded env58054 := by
  intro p hp
  have h : env58054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58053_58054 : H12AffineEnvironment.transform 11 444 env58053 = env58054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env58053 == env58054) = true)

theorem identity58054 : scanCanonicalize (H12AffineFastState.compose env58054 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound58054 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env58055 : List Nat := [2,4,8,16,32,64,128,256,512,257,603,444,421,64,341,374,445,11,257,341,64,476,493,218,301,16,130,64,492,643,504,169,257,168,445,513]

theorem envBound58055 : H12AffineFastState.Bounded env58055 := by
  intro p hp
  have h : env58055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58054_58055 : H12AffineEnvironment.transform 9 257 env58054 = env58055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env58054 == env58055) = true)

theorem identity58055 : scanCanonicalize (H12AffineFastState.compose env58055 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58055 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58056 : List Nat := [2,4,8,16,32,64,128,256,216,257,131,444,421,64,341,374,445,11,257,341,64,476,493,218,301,16,130,64,492,91,504,169,257,168,445,217]

theorem envBound58056 : H12AffineFastState.Bounded env58056 := by
  intro p hp
  have h : env58056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58055_58056 : H12AffineEnvironment.transform 8 216 env58055 = env58056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58055 == env58056) = true)

def env58057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144712,169103,26057,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound58057 : H12AffineFastState.Bounded env58057 := by
  intro p hp
  have h : env58057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58044_58057 : H12AffineEnvironment.transform 17 87425 env58044 = env58057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58044 == env58057) = true)

theorem identity58057 : scanCanonicalize (H12AffineFastState.compose env58057 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 118882) := by decide +kernel

theorem selectedBound58057 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0