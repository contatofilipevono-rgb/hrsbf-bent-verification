import H12CloudChart0Data012

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound3189 : H12AffineFastState.Bounded env3189 := by
  intro p hp
  have h : env3189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3188_3189 : H12AffineEnvironment.transform 3 0 env3188 = env3189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3188 == env3189) = true)

theorem identity3189 : scanCanonicalize (H12AffineFastState.compose env3189 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3190 : List Nat := [2,4,2,0,32,1,34,5,512,1024,2048,1573,2563,1573,2561,2595,1573,2080,1025,2561,1573,33,1,35,2594,1,2048,1572,1573,2081,1025,0,4,0,1572,512]

theorem envBound3190 : H12AffineFastState.Bounded env3190 := by
  intro p hp
  have h : env3190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3189_3190 : H12AffineEnvironment.transform 2 2 env3189 = env3190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3189 == env3190) = true)

theorem identity3190 : scanCanonicalize (H12AffineFastState.compose env3190 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound3190 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3191 : List Nat := [2,4,2,0,32,1,34,5,512,1024,513,1573,2,1573,0,34,1573,545,1025,0,1573,33,1,35,35,1,513,1572,1573,544,1025,0,4,0,1572,512]

theorem envBound3191 : H12AffineFastState.Bounded env3191 := by
  intro p hp
  have h : env3191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3190_3191 : H12AffineEnvironment.transform 10 513 env3190 = env3191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env3190 == env3191) = true)

theorem identity3191 : scanCanonicalize (H12AffineFastState.compose env3191 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3191 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3192 : List Nat := [2,4,2,0,32,1,34,5,0,1024,1,1061,2,1061,0,34,1061,33,1025,0,1061,33,1,35,35,1,1,1060,1061,32,1025,0,4,0,1060,0]

theorem envBound3192 : H12AffineFastState.Bounded env3192 := by
  intro p hp
  have h : env3192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3191_3192 : H12AffineEnvironment.transform 8 0 env3191 = env3192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3191 == env3192) = true)

theorem identity3192 : scanCanonicalize (H12AffineFastState.compose env3192 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3193 : List Nat := [2,4,2,0,1,1,3,5,0,1024,1,1028,2,1028,0,3,1028,0,1025,0,1028,0,1,2,2,1,1,1029,1028,1,1025,0,4,0,1029,0]

theorem envBound3193 : H12AffineFastState.Bounded env3193 := by
  intro p hp
  have h : env3193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3192_3193 : H12AffineEnvironment.transform 4 1 env3192 = env3193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3192 == env3193) = true)

def env3194 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,32768,32923,4112,262144,1025,32768,4096,4194304,4235409,41003,8329,4235409,303233,4096,4113,2080,42160,16,188,1,4198433,4235920]

theorem envBound3194 : H12AffineFastState.Bounded env3194 := by
  intro p hp
  have h : env3194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3181_3194 : H12AffineEnvironment.transform 13 4097 env3181 = env3194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3181 == env3194) = true)

theorem identity3194 : scanCanonicalize (H12AffineFastState.compose env3194 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3194 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3195 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,4097,32768,32906,4097,262144,1025,32768,4096,4194304,4235392,41003,8329,4235392,303233,4096,4096,2080,42145,1,173,1,4198433,4235905]

theorem envBound3195 : H12AffineFastState.Bounded env3195 := by
  intro p hp
  have h : env3195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3194_3195 : H12AffineEnvironment.transform 3 1 env3194 = env3195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3194 == env3195) = true)

theorem identity3195 : scanCanonicalize (H12AffineFastState.compose env3195 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 264192) := by decide +kernel

theorem selectedBound3195 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env3196 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,4097,32768,32906,4097,262144,1025,32768,4096,264192,305280,41003,8329,305280,303233,4096,4096,2080,42145,1,173,1,268321,305793]

theorem envBound3196 : H12AffineFastState.Bounded env3196 := by
  intro p hp
  have h : env3196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3195_3196 : H12AffineEnvironment.transform 21 264192 env3195 = env3196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264192 env3195 == env3196) = true)

theorem identity3196 : scanCanonicalize (H12AffineFastState.compose env3196 (packedSelected [4,9,20] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound3196 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3197 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,4097,32768,32906,4097,43048,1025,32768,4096,41000,168,41003,8329,168,2217,4096,4096,2080,42145,1,173,1,45065,681]

theorem envBound3197 : H12AffineFastState.Bounded env3197 := by
  intro p hp
  have h : env3197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3196_3197 : H12AffineEnvironment.transform 17 43048 env3196 = env3197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env3196 == env3197) = true)

theorem identity3197 : scanCanonicalize (H12AffineFastState.compose env3197 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3197 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3198 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1572,8192,1573,32768,32906,1573,43048,1025,32768,1572,41000,168,41003,8329,168,2217,1572,1572,2080,42145,1,173,1,42541,681]

theorem envBound3198 : H12AffineFastState.Bounded env3198 := by
  intro p hp
  have h : env3198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3197_3198 : H12AffineEnvironment.transform 11 1572 env3197 = env3198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env3197 == env3198) = true)

theorem identity3198 : scanCanonicalize (H12AffineFastState.compose env3198 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 1540) := by decide +kernel

theorem selectedBound3198 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3199 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1572,8192,1573,1540,1678,1573,11820,1025,1540,1572,9772,168,9775,8329,168,2217,1572,1572,2080,8869,1,173,1,8233,681]

theorem envBound3199 : H12AffineFastState.Bounded env3199 := by
  intro p hp
  have h : env3199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3198_3199 : H12AffineEnvironment.transform 14 1540 env3198 = env3199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1540 env3198 == env3199) = true)

theorem identity3199 : scanCanonicalize (H12AffineFastState.compose env3199 (packedSelected [2,6,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound3199 : packedSelected [2,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env3200 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1572,9,1573,1540,1678,1573,3621,1025,1540,1572,1573,168,1574,128,168,2217,1572,1572,2080,684,1,173,1,32,681]

theorem envBound3200 : H12AffineFastState.Bounded env3200 := by
  intro p hp
  have h : env3200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3199_3200 : H12AffineEnvironment.transform 12 9 env3199 = env3200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env3199 == env3200) = true)

theorem identity3200 : scanCanonicalize (H12AffineFastState.compose env3200 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound3200 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env3201 : List Nat := [2,4,8,1,32,0,2,46,512,1024,2048,1572,9,1573,1540,1548,1573,3621,1025,1540,1572,1573,42,1574,2,42,2091,1572,1572,2080,558,1,47,1,32,555]

theorem envBound3201 : H12AffineFastState.Bounded env3201 := by
  intro p hp
  have h : env3201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3200_3201 : H12AffineEnvironment.transform 6 2 env3200 = env3201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env3200 == env3201) = true)

theorem identity3201 : scanCanonicalize (H12AffineFastState.compose env3201 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound3201 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3202 : List Nat := [2,4,8,1,32,0,2,46,512,516,2048,32,9,33,0,8,33,2081,517,0,32,33,42,34,2,42,2091,32,32,2080,558,1,47,1,32,555]

theorem envBound3202 : H12AffineFastState.Bounded env3202 := by
  intro p hp
  have h : env3202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3201_3202 : H12AffineEnvironment.transform 9 516 env3201 = env3202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env3201 == env3202) = true)

theorem identity3202 : scanCanonicalize (H12AffineFastState.compose env3202 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound3202 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env3203 : List Nat := [2,4,8,1,32,0,2,46,512,516,0,32,9,33,0,8,33,33,517,0,32,33,42,34,2,42,43,32,32,32,558,1,47,1,32,555]

theorem envBound3203 : H12AffineFastState.Bounded env3203 := by
  intro p hp
  have h : env3203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3202_3203 : H12AffineEnvironment.transform 10 0 env3202 = env3203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env3202 == env3203) = true)

theorem identity3203 : scanCanonicalize (H12AffineFastState.compose env3203 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3203 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3204 : List Nat := [2,4,8,1,32,0,2,46,1,5,0,32,9,33,0,8,33,33,4,0,32,33,42,34,2,42,43,32,32,32,47,1,47,1,32,42]

theorem envBound3204 : H12AffineFastState.Bounded env3204 := by
  intro p hp
  have h : env3204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3203_3204 : H12AffineEnvironment.transform 8 1 env3203 = env3204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3203 == env3204) = true)

theorem identity3204 : scanCanonicalize (H12AffineFastState.compose env3204 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3205 : List Nat := [2,4,8,1,0,0,2,14,1,5,0,0,9,1,0,8,1,1,4,0,0,1,10,2,2,10,11,0,0,0,15,1,15,1,0,10]

theorem envBound3205 : H12AffineFastState.Bounded env3205 := by
  intro p hp
  have h : env3205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3204_3205 : H12AffineEnvironment.transform 4 0 env3204 = env3205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3204 == env3205) = true)

theorem identity3205 : scanCanonicalize (H12AffineFastState.compose env3205 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3206 : List Nat := [2,4,2,1,0,0,2,4,1,5,0,0,3,1,0,2,1,1,4,0,0,1,0,2,2,0,1,0,0,0,5,1,5,1,0,0]

theorem envBound3206 : H12AffineFastState.Bounded env3206 := by
  intro p hp
  have h : env3206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3205_3206 : H12AffineEnvironment.transform 2 2 env3205 = env3206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3205 == env3206) = true)

theorem identity3206 : scanCanonicalize (H12AffineFastState.compose env3206 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3207 : List Nat := [2,1,2,1,0,0,2,1,1,0,0,0,3,1,0,2,1,1,1,0,0,1,0,2,2,0,1,0,0,0,0,1,0,1,0,0]

theorem envBound3207 : H12AffineFastState.Bounded env3207 := by
  intro p hp
  have h : env3207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3206_3207 : H12AffineEnvironment.transform 1 1 env3206 = env3207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3206 == env3207) = true)

def env3208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849104,268435456,268435965,547953,598059,12644669,525568,545872,8479127,8914924]

theorem envBound3208 : H12AffineFastState.Bounded env3208 := by
  intro p hp
  have h : env3208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2956_3208 : H12AffineEnvironment.transform 20 4097 env2956 = env3208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env2956 == env3208) = true)

def env3209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849104,16384,16893,547953,598059,12644669,525568,545872,8479127,8914924]

theorem envBound3209 : H12AffineFastState.Bounded env3209 := by
  intro p hp
  have h : env3209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3208_3209 : H12AffineEnvironment.transform 27 16384 env3208 = env3209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3208 == env3209) = true)

def env3210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323792,16384,16893,22641,74795,12644669,256,20560,8479127,8389612]

theorem envBound3210 : H12AffineFastState.Bounded env3210 := by
  intro p hp
  have h : env3210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3209_3210 : H12AffineEnvironment.transform 18 1024 env3209 = env3210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3209 == env3210) = true)

theorem identity3210 : scanCanonicalize (H12AffineFastState.compose env3210 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound3210 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4265,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,303225,4265,4436,2264,74795,12624276,256,249,8466750,8389612]

theorem envBound3211 : H12AffineFastState.Bounded env3211 := by
  intro p hp
  have h : env3211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3210_3211 : H12AffineEnvironment.transform 13 4265 env3210 = env3211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3210 == env3211) = true)

def env3212 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,4194304,8388608,41003,8329,8388609,303145,4265,4356,2184,74795,12624276,256,169,8466750,8389564]

theorem envBound3212 : H12AffineFastState.Bounded env3212 := by
  intro p hp
  have h : env3212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3211_3212 : H12AffineEnvironment.transform 5 16 env3211 = env3212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3211 == env3212) = true)

theorem identity3212 : scanCanonicalize (H12AffineFastState.compose env3212 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3212 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3213 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,4194304,444,41003,8329,445,303145,4265,4356,2184,74795,4235304,256,169,77954,512]

theorem envBound3213 : H12AffineFastState.Bounded env3213 := by
  intro p hp
  have h : env3213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3212_3213 : H12AffineEnvironment.transform 22 444 env3212 = env3213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3212 == env3213) = true)

theorem identity3213 : scanCanonicalize (H12AffineFastState.compose env3213 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3213 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3214 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,41349,444,41003,8329,445,303145,4265,4356,2184,74795,429,256,169,77954,512]

theorem envBound3214 : H12AffineFastState.Bounded env3214 := by
  intro p hp
  have h : env3214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3213_3214 : H12AffineEnvironment.transform 21 41349 env3213 = env3214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3213 == env3214) = true)

theorem identity3214 : scanCanonicalize (H12AffineFastState.compose env3214 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3214 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3215 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,38842,4524,262144,1024,32768,4097,41349,444,41003,8329,445,303145,4265,4356,2184,45969,429,256,169,42808,512]

theorem envBound3215 : H12AffineFastState.Bounded env3215 := by
  intro p hp
  have h : env3215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3214_3215 : H12AffineEnvironment.transform 15 38842 env3214 = env3215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3214 == env3215) = true)

theorem identity3215 : scanCanonicalize (H12AffineFastState.compose env3215 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14225) := by decide +kernel

theorem selectedBound3215 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3216 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8235,4524,262144,1024,14225,4097,5652,444,6074,8329,445,268216,4265,4356,2184,1024,429,256,169,4265,512]

theorem envBound3216 : H12AffineFastState.Bounded env3216 := by
  intro p hp
  have h : env3216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3215_3216 : H12AffineEnvironment.transform 14 14225 env3215 = env3216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14225 env3215 == env3216) = true)

theorem identity3216 : scanCanonicalize (H12AffineFastState.compose env3216 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound3216 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3217 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8235,4524,2341,1024,14225,4097,5652,444,6074,8329,445,7837,4265,4356,2184,1024,429,256,169,4265,512]

theorem envBound3217 : H12AffineFastState.Bounded env3217 := by
  intro p hp
  have h : env3217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3216_3217 : H12AffineEnvironment.transform 17 2341 env3216 = env3217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env3216 == env3217) = true)

theorem identity3217 : scanCanonicalize (H12AffineFastState.compose env3217 (packedSelected [0,3,4,5,7,9,10,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound3217 : packedSelected [0,3,4,5,7,9,10,18,23] rootPS < 2^1333 := by decide +kernel

def env3218 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1945,8192,1840,8200,8235,1589,2341,1024,8200,1944,397,444,35,8329,445,2308,1840,1693,2184,1024,429,256,169,1840,512]

theorem envBound3218 : H12AffineFastState.Bounded env3218 := by
  intro p hp
  have h : env3218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3217_3218 : H12AffineEnvironment.transform 11 1945 env3217 = env3218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env3217 == env3218) = true)

theorem identity3218 : scanCanonicalize (H12AffineFastState.compose env3218 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3218 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3219 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1841,8192,1840,8200,8235,1589,2341,1024,8200,1840,293,276,35,8225,277,2308,1840,1589,2080,1024,261,256,1,1840,512]

theorem envBound3219 : H12AffineFastState.Bounded env3219 := by
  intro p hp
  have h : env3219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3218_3219 : H12AffineEnvironment.transform 6 40 env3218 = env3219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3218 == env3219) = true)

theorem identity3219 : scanCanonicalize (H12AffineFastState.compose env3219 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound3219 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3220 : List Nat := [2,4,8,16,32,16,40,256,512,273,2048,544,8192,545,8200,8235,804,2341,273,8200,545,293,276,35,8225,277,2308,545,804,2080,273,261,256,1,545,512]

theorem envBound3220 : H12AffineFastState.Bounded env3220 := by
  intro p hp
  have h : env3220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3219_3220 : H12AffineEnvironment.transform 9 273 env3219 = env3220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env3219 == env3220) = true)

theorem identity3220 : scanCanonicalize (H12AffineFastState.compose env3220 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3220 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3221 : List Nat := [2,4,8,16,27,16,19,256,512,273,2048,539,8192,538,8200,8208,799,2334,273,8200,538,286,276,24,8218,277,2308,538,799,2075,273,261,256,1,538,512]

theorem envBound3221 : H12AffineFastState.Bounded env3221 := by
  intro p hp
  have h : env3221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3220_3221 : H12AffineEnvironment.transform 4 27 env3220 = env3221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3220 == env3221) = true)

def env3222 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4097,4194304,8388608,41003,8329,8388608,303144,4265,4357,2185,74795,12624276,256,168,8466750,8389565]

theorem envBound3222 : H12AffineFastState.Bounded env3222 := by
  intro p hp
  have h : env3222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3211_3222 : H12AffineEnvironment.transform 5 17 env3211 = env3222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3211 == env3222) = true)

def env3223 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,262144,1024,32768,4097,4194304,8388608,41003,8329,8388608,303144,4265,4265,2185,74795,12623928,172,168,8466578,8389137]

theorem envBound3223 : H12AffineFastState.Bounded env3223 := by
  intro p hp
  have h : env3223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3222_3223 : H12AffineEnvironment.transform 7 172 env3222 = env3223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3222 == env3223) = true)

theorem identity3223 : scanCanonicalize (H12AffineFastState.compose env3223 (packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 106143) := by decide +kernel

theorem selectedBound3223 : packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env3224 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,4194304,8388608,41003,8329,8388608,81591,4265,4265,2185,74795,12623928,172,168,8466578,8389137]

theorem envBound3224 : H12AffineFastState.Bounded env3224 := by
  intro p hp
  have h : env3224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3223_3224 : H12AffineEnvironment.transform 17 106143 env3223 = env3224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106143 env3223 == env3224) = true)

def env3225 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,41088,8388608,41003,8329,8388608,81591,4265,4265,2185,74795,8388792,172,168,8466578,8389137]

theorem envBound3225 : H12AffineFastState.Bounded env3225 := by
  intro p hp
  have h : env3225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3224_3225 : H12AffineEnvironment.transform 21 41088 env3224 = env3225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3224 == env3225) = true)

theorem identity3225 : scanCanonicalize (H12AffineFastState.compose env3225 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 5668) := by decide +kernel

theorem selectedBound3225 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3226 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,41088,5668,41003,8329,5668,81591,4265,4265,2185,74795,5788,172,168,75446,5173]

theorem envBound3226 : H12AffineFastState.Bounded env3226 := by
  intro p hp
  have h : env3226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3225_3226 : H12AffineEnvironment.transform 22 5668 env3225 = env3226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5668 env3225 == env3226) = true)

theorem identity3226 : scanCanonicalize (H12AffineFastState.compose env3226 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3226 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3227 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1692,8192,1589,32768,65536,1693,100355,1024,32768,1693,41088,184,41003,8329,184,75819,1589,1589,2185,74795,0,172,168,75446,681]

theorem envBound3227 : H12AffineFastState.Bounded env3227 := by
  intro p hp
  have h : env3227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3226_3227 : H12AffineEnvironment.transform 11 1692 env3226 = env3227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env3226 == env3227) = true)

theorem identity3227 : scanCanonicalize (H12AffineFastState.compose env3227 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3227 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

def env3228 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1692,8192,1589,8201,65536,1693,75786,1024,8201,1693,137,184,34,8329,184,75819,1589,1589,2185,74795,0,172,168,75446,681]

theorem envBound3228 : H12AffineFastState.Bounded env3228 := by
  intro p hp
  have h : env3228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3227_3228 : H12AffineEnvironment.transform 14 8201 env3227 = env3228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3227 == env3228) = true)

theorem identity3228 : scanCanonicalize (H12AffineFastState.compose env3228 (packedSelected [1,2,6,8,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1575) := by decide +kernel

theorem selectedBound3228 : packedSelected [1,2,6,8,11,13,17] rootPS < 2^1333 := by decide +kernel

def env3229 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1692,1575,1589,1582,65536,1693,69165,1024,1582,1693,137,184,34,1710,184,69132,1589,1589,2185,66060,0,172,168,65681,681]

theorem envBound3229 : H12AffineFastState.Bounded env3229 := by
  intro p hp
  have h : env3229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3228_3229 : H12AffineEnvironment.transform 12 1575 env3228 = env3229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1575 env3228 == env3229) = true)

theorem identity3229 : scanCanonicalize (H12AffineFastState.compose env3229 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1700) := by decide +kernel

theorem selectedBound3229 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3230 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1692,1575,1589,1582,1700,1693,2185,1024,1582,1693,137,184,34,1710,184,2216,1589,1589,2185,1192,0,172,168,1589,681]

theorem envBound3230 : H12AffineFastState.Bounded env3230 := by
  intro p hp
  have h : env3230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3229_3230 : H12AffineEnvironment.transform 15 1700 env3229 = env3230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1700 env3229 == env3230) = true)

theorem identity3230 : scanCanonicalize (H12AffineFastState.compose env3230 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound3230 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3231 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1702,1692,1575,1589,1582,1700,1693,1583,1024,1582,1693,137,184,34,1710,184,1550,1589,1589,1583,1192,0,172,168,1589,681]

theorem envBound3231 : H12AffineFastState.Bounded env3231 := by
  intro p hp
  have h : env3231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3230_3231 : H12AffineEnvironment.transform 10 1702 env3230 = env3231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env3230 == env3231) = true)

theorem identity3231 : scanCanonicalize (H12AffineFastState.compose env3231 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound3231 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3232 : List Nat := [2,4,8,16,32,17,18,62,512,1024,1588,1550,1575,1589,1582,1590,1551,1583,1024,1582,1551,27,42,34,1596,42,1550,1589,1589,1583,1082,0,62,58,1589,571]

theorem envBound3232 : H12AffineFastState.Bounded env3232 := by
  intro p hp
  have h : env3232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3231_3232 : H12AffineEnvironment.transform 6 18 env3231 = env3232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env3231 == env3232) = true)

theorem identity3232 : scanCanonicalize (H12AffineFastState.compose env3232 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3233 : List Nat := [2,4,8,16,32,17,18,62,0,1024,1076,1038,1063,1077,1070,1078,1039,1071,1024,1070,1039,27,42,34,1084,42,1038,1077,1077,1071,1082,0,62,58,1077,59]

theorem envBound3233 : H12AffineFastState.Bounded env3233 := by
  intro p hp
  have h : env3233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3232_3233 : H12AffineEnvironment.transform 8 0 env3232 = env3233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3232 == env3233) = true)

theorem identity3233 : scanCanonicalize (H12AffineFastState.compose env3233 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3233 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3234 : List Nat := [2,4,8,16,27,17,18,5,0,1024,1039,1038,1052,1038,1045,1037,1039,1044,1024,1045,1039,27,17,25,1031,17,1038,1038,1038,1044,1025,0,5,1,1038,0]

theorem envBound3234 : H12AffineFastState.Bounded env3234 := by
  intro p hp
  have h : env3234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3233_3234 : H12AffineEnvironment.transform 4 27 env3233 = env3234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3233 == env3234) = true)

theorem identity3234 : scanCanonicalize (H12AffineFastState.compose env3234 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3235 : List Nat := [2,4,8,1,10,0,3,5,0,1024,1039,1038,1037,1038,1028,1037,1039,1029,1024,1028,1039,10,0,8,1031,0,1038,1038,1038,1029,1025,0,5,1,1038,0]

theorem envBound3235 : H12AffineFastState.Bounded env3235 := by
  intro p hp
  have h : env3235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3234_3235 : H12AffineEnvironment.transform 3 1 env3234 = env3235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3234 == env3235) = true)

theorem identity3235 : scanCanonicalize (H12AffineFastState.compose env3235 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3235 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3236 : List Nat := [2,4,8,1,10,0,3,5,0,4,11,10,9,10,0,9,11,1,4,0,11,10,0,8,3,0,10,10,10,1,5,0,5,1,10,0]

theorem envBound3236 : H12AffineFastState.Bounded env3236 := by
  intro p hp
  have h : env3236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3235_3236 : H12AffineEnvironment.transform 9 4 env3235 = env3236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3235 == env3236) = true)

theorem identity3236 : scanCanonicalize (H12AffineFastState.compose env3236 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3237 : List Nat := [2,4,2,1,0,0,3,5,0,4,1,0,3,0,0,3,1,1,4,0,1,0,0,2,3,0,0,0,0,1,5,0,5,1,0,0]

theorem envBound3237 : H12AffineFastState.Bounded env3237 := by
  intro p hp
  have h : env3237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3236_3237 : H12AffineEnvironment.transform 2 2 env3236 = env3237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3236 == env3237) = true)

def env3238 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,41089,8388608,41003,8329,8388608,81591,4265,4265,2185,74795,8388793,172,168,8466578,8389137]

theorem envBound3238 : H12AffineFastState.Bounded env3238 := by
  intro p hp
  have h : env3238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3224_3238 : H12AffineEnvironment.transform 21 41089 env3224 = env3238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3224 == env3238) = true)

theorem identity3238 : scanCanonicalize (H12AffineFastState.compose env3238 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound3238 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3239 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,13973,65536,4097,75786,1024,13973,4097,5652,8388608,5822,8329,8388608,81591,4265,4265,2185,74795,8388793,172,168,8466578,8389137]

theorem envBound3239 : H12AffineFastState.Bounded env3239 := by
  intro p hp
  have h : env3239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3238_3239 : H12AffineEnvironment.transform 14 13973 env3238 = env3239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env3238 == env3239) = true)

theorem identity3239 : scanCanonicalize (H12AffineFastState.compose env3239 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3239 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3240 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4097,13885,65536,4097,75786,1024,13885,4097,5652,8388608,5654,8225,8388608,81439,4097,4097,2081,74795,8388625,4,0,8466490,8389137]

theorem envBound3240 : H12AffineFastState.Bounded env3240 := by
  intro p hp
  have h : env3240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3239_3240 : H12AffineEnvironment.transform 6 40 env3239 = env3240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3239 == env3240) = true)

theorem identity3240 : scanCanonicalize (H12AffineFastState.compose env3240 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(22+1) ^^^ 79374) := by decide +kernel

theorem selectedBound3240 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3241 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4097,13885,65536,4097,75786,1024,13885,4097,5652,79374,5654,8225,79374,81439,4097,4097,2081,74795,79391,4,0,1588,78879]

theorem envBound3241 : H12AffineFastState.Bounded env3241 := by
  intro p hp
  have h : env3241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3240_3241 : H12AffineEnvironment.transform 22 79374 env3240 = env3241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 79374 env3240 == env3241) = true)

def env3242 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,262144,1024,32768,4097,4194304,8388608,41003,8329,8388608,303144,4265,4264,2185,74795,12623929,173,168,8466579,8389136]

theorem envBound3242 : H12AffineFastState.Bounded env3242 := by
  intro p hp
  have h : env3242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3222_3242 : H12AffineEnvironment.transform 7 173 env3222 = env3242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3222 == env3242) = true)

theorem identity3242 : scanCanonicalize (H12AffineFastState.compose env3242 (packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 48821) := by decide +kernel

theorem selectedBound3242 : packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env3243 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,4194304,8388608,41003,8329,8388608,7837,4265,4264,2185,74795,12623929,173,168,8466579,8389136]

theorem envBound3243 : H12AffineFastState.Bounded env3243 := by
  intro p hp
  have h : env3243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3242_3243 : H12AffineEnvironment.transform 17 48821 env3242 = env3243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48821 env3242 == env3243) = true)

def env3244 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,41088,8388608,41003,8329,8388608,7837,4265,4264,2185,74795,8388793,173,168,8466579,8389136]

theorem envBound3244 : H12AffineFastState.Bounded env3244 := by
  intro p hp
  have h : env3244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3243_3244 : H12AffineEnvironment.transform 21 41088 env3243 = env3244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3243 == env3244) = true)

theorem identity3244 : scanCanonicalize (H12AffineFastState.compose env3244 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 79374) := by decide +kernel

theorem selectedBound3244 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3245 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,41088,79374,41003,8329,79374,7837,4265,4264,2185,74795,79543,173,168,1693,78878]

theorem envBound3245 : H12AffineFastState.Bounded env3245 := by
  intro p hp
  have h : env3245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3244_3245 : H12AffineEnvironment.transform 22 79374 env3244 = env3245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 79374 env3244 == env3245) = true)

theorem identity3245 : scanCanonicalize (H12AffineFastState.compose env3245 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 14006) := by decide +kernel

theorem selectedBound3245 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3246 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,14006,4096,48821,1024,32768,4097,41088,184,41003,8329,184,7837,4265,4264,2185,4765,1,173,168,1693,680]

theorem envBound3246 : H12AffineFastState.Bounded env3246 := by
  intro p hp
  have h : env3246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3245_3246 : H12AffineEnvironment.transform 15 14006 env3245 = env3246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14006 env3245 == env3246) = true)

theorem identity3246 : scanCanonicalize (H12AffineFastState.compose env3246 (packedSelected [4,9,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound3246 : packedSelected [4,9,18,20,23] rootPS < 2^1333 := by decide +kernel

def env3247 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,8200,14006,4096,7869,1024,8200,4097,136,184,35,8329,184,7837,4265,4264,2185,4765,1,173,168,1693,680]

theorem envBound3247 : H12AffineFastState.Bounded env3247 := by
  intro p hp
  have h : env3247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3246_3247 : H12AffineEnvironment.transform 14 8200 env3246 = env3247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env3246 == env3247) = true)

theorem identity3247 : scanCanonicalize (H12AffineFastState.compose env3247 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3247 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3248 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1589,8192,1692,8200,8323,1589,2184,1024,8200,1588,136,184,35,8329,184,2216,1692,1693,2185,1192,1,173,168,1693,680]

theorem envBound3248 : H12AffineFastState.Bounded env3248 := by
  intro p hp
  have h : env3248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3247_3248 : H12AffineEnvironment.transform 11 1589 env3247 = env3248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3247 == env3248) = true)

theorem identity3248 : scanCanonicalize (H12AffineFastState.compose env3248 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound3248 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3249 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1703,1589,8192,1692,8200,8323,1589,1583,1024,8200,1588,136,184,35,8329,184,1551,1692,1693,1582,1192,1,173,168,1693,680]

theorem envBound3249 : H12AffineFastState.Bounded env3249 := by
  intro p hp
  have h : env3249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3248_3249 : H12AffineEnvironment.transform 10 1703 env3248 = env3249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env3248 == env3249) = true)

theorem identity3249 : scanCanonicalize (H12AffineFastState.compose env3249 (packedSelected [1,2,3,4,6,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound3249 : packedSelected [1,2,3,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env3250 : List Nat := [2,4,8,16,32,17,128,173,168,1024,1039,1181,8192,1076,8200,8323,1181,1159,1024,8200,1180,136,184,35,8329,184,1191,1076,1077,1158,1192,1,173,168,1077,0]

theorem envBound3250 : H12AffineFastState.Bounded env3250 := by
  intro p hp
  have h : env3250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3249_3250 : H12AffineEnvironment.transform 8 168 env3249 = env3250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env3249 == env3250) = true)

theorem identity3250 : scanCanonicalize (H12AffineFastState.compose env3250 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1198) := by decide +kernel

theorem selectedBound3250 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env3251 : List Nat := [2,4,8,16,32,17,128,173,168,1024,1039,1181,1198,1076,1190,1069,1181,1159,1024,1190,1180,136,184,35,1063,184,1191,1076,1077,1158,1192,1,173,168,1077,0]

theorem envBound3251 : H12AffineFastState.Bounded env3251 := by
  intro p hp
  have h : env3251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3250_3251 : H12AffineEnvironment.transform 12 1198 env3250 = env3251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1198 env3250 == env3251) = true)

theorem identity3251 : scanCanonicalize (H12AffineFastState.compose env3251 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound3251 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env3252 : List Nat := [2,4,8,16,32,17,128,173,168,167,168,58,9,147,1,138,58,32,167,1,59,136,184,35,128,184,0,147,146,33,15,1,173,168,146,0]

theorem envBound3252 : H12AffineFastState.Bounded env3252 := by
  intro p hp
  have h : env3252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3251_3252 : H12AffineEnvironment.transform 9 167 env3251 = env3252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env3251 == env3252) = true)

theorem identity3252 : scanCanonicalize (H12AffineFastState.compose env3252 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3252 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3253 : List Nat := [2,4,8,16,26,17,128,151,146,157,146,0,9,147,1,138,0,26,157,1,1,136,130,25,128,130,0,147,146,27,15,1,151,146,146,0]

theorem envBound3253 : H12AffineFastState.Bounded env3253 := by
  intro p hp
  have h : env3253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3252_3253 : H12AffineEnvironment.transform 4 26 env3252 = env3253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3252 == env3253) = true)

theorem identity3253 : scanCanonicalize (H12AffineFastState.compose env3253 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound3253 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3254 : List Nat := [2,4,8,16,26,17,19,4,1,14,1,0,9,0,1,25,0,26,14,1,1,27,17,25,19,17,0,0,1,27,15,1,4,1,1,0]

theorem envBound3254 : H12AffineFastState.Bounded env3254 := by
  intro p hp
  have h : env3254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3253_3254 : H12AffineEnvironment.transform 6 19 env3253 = env3254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env3253 == env3254) = true)

theorem identity3254 : scanCanonicalize (H12AffineFastState.compose env3254 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound3254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3255 : List Nat := [2,4,8,4,14,5,7,4,1,14,1,0,9,0,1,13,0,14,14,1,1,15,5,13,7,5,0,0,1,15,15,1,4,1,1,0]

theorem envBound3255 : H12AffineFastState.Bounded env3255 := by
  intro p hp
  have h : env3255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3254_3255 : H12AffineEnvironment.transform 3 4 env3254 = env3255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env3254 == env3255) = true)

theorem identity3255 : scanCanonicalize (H12AffineFastState.compose env3255 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3255 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3256 : List Nat := [2,1,8,1,11,0,2,1,1,11,1,0,9,0,1,8,0,11,11,1,1,10,0,8,2,0,0,0,1,10,10,1,1,1,1,0]

theorem envBound3256 : H12AffineFastState.Bounded env3256 := by
  intro p hp
  have h : env3256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3255_3256 : H12AffineEnvironment.transform 1 1 env3255 = env3256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3255 == env3256) = true)

def leafEnv3256 : List Nat := [2,1,8,1,11,0,2,1,1,11,1,0,9,0,1,8,0,11,11,1,1,10,0,8,10,2,1,0,0,0,1,10,10,1,1,1,1,3,1,0,1,0,0]

def active3256 : List Nat := [0,2]

def tree3256 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3256 : H12WitnessSearch.Good tree3256 := H12GlobalWitnessIndex.good

theorem leafIdentity3256 : H12AffineFastState.composeSystem env3256 rootObs = leafEnv3256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3256 rootObs == leafEnv3256) = true)

theorem terminalChecked3256 : H12PackedTerminal.terminalCheckFast leafEnv3256 active3256 tree3256 = true := by decide +kernel

def env3257 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,41089,8388608,41003,8329,8388608,7837,4265,4264,2185,74795,8388792,173,168,8466579,8389136]

theorem envBound3257 : H12AffineFastState.Bounded env3257 := by
  intro p hp
  have h : env3257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3243_3257 : H12AffineEnvironment.transform 21 41089 env3243 = env3257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3243 == env3257) = true)

theorem identity3257 : scanCanonicalize (H12AffineFastState.compose env3257 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 38590) := by decide +kernel

theorem selectedBound3257 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3258 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,38590,4096,48821,1024,32768,4097,41089,8388608,41003,8329,8388608,7837,4265,4264,2185,45717,8388792,173,168,8431149,8389136]

theorem envBound3258 : H12AffineFastState.Bounded env3258 := by
  intro p hp
  have h : env3258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3257_3258 : H12AffineEnvironment.transform 15 38590 env3257 = env3258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38590 env3257 == env3258) = true)

theorem identity3258 : scanCanonicalize (H12AffineFastState.compose env3258 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3258 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3259 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4096,32768,38423,4096,48668,1024,32768,4097,41000,8388608,41003,8224,8388608,7732,4096,4097,2080,45628,8388625,4,1,8431149,8389136]

theorem envBound3259 : H12AffineFastState.Bounded env3259 := by
  intro p hp
  have h : env3259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3258_3259 : H12AffineEnvironment.transform 6 41 env3258 = env3259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3258 == env3259) = true)

theorem identity3259 : scanCanonicalize (H12AffineFastState.compose env3259 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(22+1) ^^^ 46637) := by decide +kernel

theorem selectedBound3259 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3260 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4096,32768,38423,4096,48668,1024,32768,4097,41000,46637,41003,8224,46637,7732,4096,4097,2080,45628,46652,4,1,4096,46141]

theorem envBound3260 : H12AffineFastState.Bounded env3260 := by
  intro p hp
  have h : env3260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3259_3260 : H12AffineEnvironment.transform 22 46637 env3259 = env3260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46637 env3259 == env3260) = true)

theorem identity3260 : scanCanonicalize (H12AffineFastState.compose env3260 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4658) := by decide +kernel

theorem selectedBound3260 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3261 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,4658,4096,32768,38423,4096,35886,1024,32768,4097,37402,33823,37401,4626,33823,7732,4096,4097,2080,32782,33806,4,1,4096,34319]

theorem envBound3261 : H12AffineFastState.Bounded env3261 := by
  intro p hp
  have h : env3261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3260_3261 : H12AffineEnvironment.transform 12 4658 env3260 = env3261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4658 env3260 == env3261) = true)

theorem identity3261 : scanCanonicalize (H12AffineFastState.compose env3261 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3261 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3262 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,4096,4658,4096,32768,38423,4096,33312,1024,32768,4097,37402,33823,37401,4626,33823,4154,4096,4097,1582,32782,33806,4,1,4096,34319]

theorem envBound3262 : H12AffineFastState.Bounded env3262 := by
  intro p hp
  have h : env3262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3261_3262 : H12AffineEnvironment.transform 10 1550 env3261 = env3262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3261 == env3262) = true)

theorem identity3262 : scanCanonicalize (H12AffineFastState.compose env3262 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3262 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env3263 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1589,1031,1589,32768,32802,1589,33312,1024,32768,1588,33839,33823,33836,1063,33823,1551,1589,1588,1582,32782,33806,4,1,1589,34319]

theorem envBound3263 : H12AffineFastState.Bounded env3263 := by
  intro p hp
  have h : env3263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3262_3263 : H12AffineEnvironment.transform 11 1589 env3262 = env3263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3262 == env3263) = true)

theorem identity3263 : scanCanonicalize (H12AffineFastState.compose env3263 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3263 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3264 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1550,1589,1031,1589,1039,1069,1589,1583,1024,1039,1588,32,16,35,1063,16,1551,1589,1588,1582,1025,1,4,1,1589,512]

theorem envBound3264 : H12AffineFastState.Bounded env3264 := by
  intro p hp
  have h : env3264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3263_3264 : H12AffineEnvironment.transform 14 1039 env3263 = env3264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1039 env3263 == env3264) = true)

theorem identity3264 : scanCanonicalize (H12AffineFastState.compose env3264 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3264 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3265 : List Nat := [2,4,8,16,32,17,41,4,1,1024,1039,1076,1031,1076,1039,1069,1076,1070,1024,1039,1077,32,16,35,1063,16,1038,1076,1077,1071,1025,1,4,1,1076,1]

theorem envBound3265 : H12AffineFastState.Bounded env3265 := by
  intro p hp
  have h : env3265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3264_3265 : H12AffineEnvironment.transform 8 1 env3264 = env3265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3264 == env3265) = true)

theorem identity3265 : scanCanonicalize (H12AffineFastState.compose env3265 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound3265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3266 : List Nat := [2,4,8,16,32,17,41,4,1,21,26,33,18,33,26,56,33,59,21,26,32,32,16,35,50,16,27,33,32,58,20,1,4,1,33,1]

theorem envBound3266 : H12AffineFastState.Bounded env3266 := by
  intro p hp
  have h : env3266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3265_3266 : H12AffineEnvironment.transform 9 21 env3265 = env3266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env3265 == env3266) = true)

theorem identity3266 : scanCanonicalize (H12AffineFastState.compose env3266 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3267 : List Nat := [2,4,8,11,32,10,41,4,1,14,1,33,9,33,1,35,33,32,14,1,32,32,11,35,41,11,0,33,32,33,15,1,4,1,33,1]

theorem envBound3267 : H12AffineFastState.Bounded env3267 := by
  intro p hp
  have h : env3267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3266_3267 : H12AffineEnvironment.transform 3 11 env3266 = env3267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3266 == env3267) = true)

def env3268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323793,16384,16893,22640,74794,12644669,257,20561,8479127,8389613]

theorem envBound3268 : H12AffineFastState.Bounded env3268 := by
  intro p hp
  have h : env3268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3209_3268 : H12AffineEnvironment.transform 18 1025 env3209 = env3268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3209 == env3268) = true)

theorem identity3268 : scanCanonicalize (H12AffineFastState.compose env3268 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5544) := by decide +kernel

theorem selectedBound3268 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,5544,41003,8329,5624,323793,16384,16893,22640,74794,4252821,257,20561,95295,5701]

theorem envBound3269 : H12AffineFastState.Bounded env3269 := by
  intro p hp
  have h : env3269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3268_3269 : H12AffineEnvironment.transform 22 5544 env3268 = env3269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5544 env3268 == env3269) = true)

def env3270 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,5544,41003,8329,5544,323713,16384,16813,22560,74794,4252821,257,20481,95295,5653]

theorem envBound3270 : H12AffineFastState.Bounded env3270 := by
  intro p hp
  have h : env3270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3269_3270 : H12AffineEnvironment.transform 5 16 env3269 = env3270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3269 == env3270) = true)

def env3271 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,41260,5544,41003,8329,5544,323713,16384,16813,22560,74794,17849,257,20481,95295,5653]

theorem envBound3271 : H12AffineFastState.Bounded env3271 := by
  intro p hp
  have h : env3271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3270_3271 : H12AffineEnvironment.transform 21 41260 env3270 = env3271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env3270 == env3271) = true)

theorem identity3271 : scanCanonicalize (H12AffineFastState.compose env3271 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound3271 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env3272 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1025,32768,4097,41260,5544,41003,8329,5544,323713,16384,16813,22560,16656,17849,257,20481,4357,5653]

theorem envBound3272 : H12AffineFastState.Bounded env3272 := by
  intro p hp
  have h : env3272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3271_3272 : H12AffineEnvironment.transform 15 25914 env3271 = env3272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env3271 == env3272) = true)

def env3273 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1464,8192,16384,32768,25914,1044,262144,1025,32768,1465,41260,16,41003,8329,16,320825,16384,16813,19864,16656,17849,257,17849,1213,941]

theorem envBound3273 : H12AffineFastState.Bounded env3273 := by
  intro p hp
  have h : env3273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3272_3273 : H12AffineEnvironment.transform 11 1464 env3272 = env3273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env3272 == env3273) = true)

theorem identity3273 : scanCanonicalize (H12AffineFastState.compose env3273 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3273 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3274 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,16384,32768,25663,1044,262144,1025,32768,1212,41001,16,41003,8329,16,320572,16384,16552,19613,16405,17596,4,17596,1213,680]

theorem envBound3274 : H12AffineFastState.Bounded env3274 := by
  intro p hp
  have h : env3274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3273_3274 : H12AffineEnvironment.transform 7 5 env3273 = env3274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3273 == env3274) = true)

theorem identity3274 : scanCanonicalize (H12AffineFastState.compose env3274 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3274 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3275 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,1692,32768,8867,1044,262144,1025,32768,1212,41001,16,41003,8329,16,303776,1692,1588,2561,1673,544,4,544,1213,680]

theorem envBound3275 : H12AffineFastState.Bounded env3275 := by
  intro p hp
  have h : env3275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3274_3275 : H12AffineEnvironment.transform 13 1692 env3274 = env3275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env3274 == env3275) = true)

theorem identity3275 : scanCanonicalize (H12AffineFastState.compose env3275 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3275 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env3276 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,1692,8201,8867,1044,262144,1025,8201,1212,32,16,34,8329,16,262825,1692,1588,2561,1673,544,4,544,1213,680]

theorem envBound3276 : H12AffineFastState.Bounded env3276 := by
  intro p hp
  have h : env3276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3275_3276 : H12AffineEnvironment.transform 14 8201 env3275 = env3276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3275 == env3276) = true)

theorem identity3276 : scanCanonicalize (H12AffineFastState.compose env3276 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2560) := by decide +kernel

theorem selectedBound3276 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3277 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,1692,8201,8867,1044,2560,1025,8201,1212,32,16,34,8329,16,2217,1692,1588,2561,1673,544,4,544,1213,680]

theorem envBound3277 : H12AffineFastState.Bounded env3277 := by
  intro p hp
  have h : env3277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3276_3277 : H12AffineEnvironment.transform 17 2560 env3276 = env3277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2560 env3276 == env3277) = true)

theorem identity3277 : scanCanonicalize (H12AffineFastState.compose env3277 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3277 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3278 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,8192,1588,8201,8715,1044,2560,1025,8201,1044,32,16,34,8225,16,2049,1588,1588,2561,1569,544,4,544,1045,512]

theorem envBound3278 : H12AffineFastState.Bounded env3278 := by
  intro p hp
  have h : env3278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3277_3278 : H12AffineEnvironment.transform 6 40 env3277 = env3278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3277 == env3278) = true)

theorem identity3278 : scanCanonicalize (H12AffineFastState.compose env3278 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1565) := by decide +kernel

theorem selectedBound3278 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3279 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,1565,1588,1556,1046,1044,2560,1025,1556,1044,32,16,34,1596,16,2049,1588,1588,2561,1569,544,4,544,1045,512]

theorem envBound3279 : H12AffineFastState.Bounded env3279 := by
  intro p hp
  have h : env3279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3278_3279 : H12AffineEnvironment.transform 12 1565 env3278 = env3279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1565 env3278 == env3279) = true)

theorem identity3279 : scanCanonicalize (H12AffineFastState.compose env3279 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3279 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3280 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1582,1045,1565,1588,1556,1046,1044,1070,1025,1556,1044,32,16,34,1596,16,1583,1588,1588,1071,1569,544,4,544,1045,512]

theorem envBound3280 : H12AffineFastState.Bounded env3280 := by
  intro p hp
  have h : env3280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3279_3280 : H12AffineEnvironment.transform 10 1582 env3279 = env3280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env3279 == env3280) = true)

theorem identity3280 : scanCanonicalize (H12AffineFastState.compose env3280 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3280 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3281 : List Nat := [2,4,8,16,32,16,40,5,0,1024,1070,1045,1053,1076,1044,1046,1044,1070,1025,1044,1044,32,16,34,1084,16,1071,1076,1076,1071,1057,32,4,32,1045,0]

theorem envBound3281 : H12AffineFastState.Bounded env3281 := by
  intro p hp
  have h : env3281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3280_3281 : H12AffineEnvironment.transform 8 0 env3280 = env3281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3280 == env3281) = true)

theorem identity3281 : scanCanonicalize (H12AffineFastState.compose env3281 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3282 : List Nat := [2,4,8,16,27,16,19,5,0,1024,1045,1045,1053,1039,1044,1046,1044,1045,1025,1044,1044,27,16,25,1031,16,1044,1039,1039,1044,1050,27,4,27,1045,0]

theorem envBound3282 : H12AffineFastState.Bounded env3282 := by
  intro p hp
  have h : env3282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3281_3282 : H12AffineEnvironment.transform 4 27 env3281 = env3282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3281 == env3282) = true)

theorem identity3282 : scanCanonicalize (H12AffineFastState.compose env3282 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3283 : List Nat := [2,4,8,16,27,16,19,5,0,15,26,26,18,0,27,25,27,26,14,27,27,27,16,25,8,16,27,0,0,27,21,27,4,27,26,0]

theorem envBound3283 : H12AffineFastState.Bounded env3283 := by
  intro p hp
  have h : env3283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3282_3283 : H12AffineEnvironment.transform 9 15 env3282 = env3283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3282 == env3283) = true)

def env3284 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1465,8192,16384,32768,25914,1045,262144,1025,32768,1464,41260,17,41003,8329,17,320824,16384,16813,19865,16656,17849,257,17848,1212,940]

theorem envBound3284 : H12AffineFastState.Bounded env3284 := by
  intro p hp
  have h : env3284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3272_3284 : H12AffineEnvironment.transform 11 1465 env3272 = env3284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env3272 == env3284) = true)

theorem identity3284 : scanCanonicalize (H12AffineFastState.compose env3284 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3284 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3285 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,32768,25914,1045,262144,1025,32768,1296,41260,17,41003,8225,17,320824,16384,16645,19761,16656,17681,257,17680,1044,772]

theorem envBound3285 : H12AffineFastState.Bounded env3285 := by
  intro p hp
  have h : env3285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3284_3285 : H12AffineEnvironment.transform 6 40 env3284 = env3285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3284 == env3285) = true)

theorem identity3285 : scanCanonicalize (H12AffineFastState.compose env3285 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3285 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3286 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,32768,25914,1045,1038,1025,32768,1296,41260,17,41003,8225,17,57654,16384,16645,19761,16656,17681,257,17680,1044,772]

theorem envBound3286 : H12AffineFastState.Bounded env3286 := by
  intro p hp
  have h : env3286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3285_3286 : H12AffineEnvironment.transform 17 1038 env3285 = env3286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1038 env3285 == env3286) = true)

theorem identity3286 : scanCanonicalize (H12AffineFastState.compose env3286 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound3286 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env3287 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,2349,16384,32768,19479,1045,1038,1025,32768,1296,34817,17,35078,2316,17,51227,16384,16645,19761,16656,17681,257,17680,1044,772]

theorem envBound3287 : H12AffineFastState.Bounded env3287 := by
  intro p hp
  have h : env3287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3286_3287 : H12AffineEnvironment.transform 12 2349 env3286 = env3287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env3286 == env3287) = true)

theorem identity3287 : scanCanonicalize (H12AffineFastState.compose env3287 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3287 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3288 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,2088,16384,32768,19479,1045,1038,1025,32768,1045,34817,17,34819,2057,17,51227,16384,16384,19508,16405,17428,4,17429,1044,513]

theorem envBound3288 : H12AffineFastState.Bounded env3288 := by
  intro p hp
  have h : env3288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3287_3288 : H12AffineEnvironment.transform 7 5 env3287 = env3288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3287 == env3288) = true)

theorem identity3288 : scanCanonicalize (H12AffineFastState.compose env3288 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 19492) := by decide +kernel

theorem selectedBound3288 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3289 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,2088,16384,19492,19479,1045,1038,1025,19492,1045,17445,17,17447,2057,17,1087,16384,16384,19508,16405,17428,4,17429,1044,513]

theorem envBound3289 : H12AffineFastState.Bounded env3289 := by
  intro p hp
  have h : env3289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3288_3289 : H12AffineEnvironment.transform 14 19492 env3288 = env3289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19492 env3288 == env3289) = true)

theorem identity3289 : scanCanonicalize (H12AffineFastState.compose env3289 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound3289 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env3290 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,2088,1076,2064,2083,1045,1038,1025,2064,1045,17,17,19,2057,17,1087,1076,1076,2048,1057,32,4,33,1044,513]

theorem envBound3290 : H12AffineFastState.Bounded env3290 := by
  intro p hp
  have h : env3290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3289_3290 : H12AffineEnvironment.transform 13 1076 env3289 = env3290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env3289 == env3290) = true)

theorem identity3290 : scanCanonicalize (H12AffineFastState.compose env3290 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound3290 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3291 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1054,1044,1078,1076,1038,1085,1045,1038,1025,1038,1045,17,17,19,1047,17,1087,1076,1076,1054,1057,32,4,33,1044,513]

theorem envBound3291 : H12AffineFastState.Bounded env3291 := by
  intro p hp
  have h : env3291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3290_3291 : H12AffineEnvironment.transform 10 1054 env3290 = env3291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env3290 == env3291) = true)

theorem identity3291 : scanCanonicalize (H12AffineFastState.compose env3291 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound3291 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3292 : List Nat := [2,4,8,16,32,16,40,5,53,1024,1054,1044,1078,1076,1038,1085,1045,1038,1025,1038,1045,17,17,19,1047,17,1087,1076,1076,1054,1057,32,4,33,1044,52]

theorem envBound3292 : H12AffineFastState.Bounded env3292 := by
  intro p hp
  have h : env3292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3291_3292 : H12AffineEnvironment.transform 8 53 env3291 = env3292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env3291 == env3292) = true)

theorem identity3292 : scanCanonicalize (H12AffineFastState.compose env3292 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound3292 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env3293 : List Nat := [2,4,8,16,5,16,13,5,16,1024,1054,1044,1043,1041,1038,1048,1045,1038,1025,1038,1045,17,17,19,1047,17,1050,1041,1041,1054,1028,5,4,4,1044,17]

theorem envBound3293 : H12AffineFastState.Bounded env3293 := by
  intro p hp
  have h : env3293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3292_3293 : H12AffineEnvironment.transform 4 5 env3292 = env3293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env3292 == env3293) = true)

theorem identity3293 : scanCanonicalize (H12AffineFastState.compose env3293 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 26) := by decide +kernel

theorem selectedBound3293 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3294 : List Nat := [2,4,8,16,5,16,13,5,16,26,4,14,9,11,20,2,15,20,27,20,15,17,17,19,13,17,0,11,11,4,30,5,4,4,14,17]

theorem envBound3294 : H12AffineFastState.Bounded env3294 := by
  intro p hp
  have h : env3294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3293_3294 : H12AffineEnvironment.transform 9 26 env3293 = env3294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 26 env3293 == env3294) = true)

def env3295 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,41261,5544,41003,8329,5544,323713,16384,16813,22560,74794,17848,257,20481,95295,5653]

theorem envBound3295 : H12AffineFastState.Bounded env3295 := by
  intro p hp
  have h : env3295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3270_3295 : H12AffineEnvironment.transform 21 41261 env3270 = env3295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env3270 == env3295) = true)

theorem identity3295 : scanCanonicalize (H12AffineFastState.compose env3295 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3295 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env3296 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,41261,5376,41003,8225,5376,323625,16384,16645,22560,74794,17680,257,20481,95295,5653]

theorem envBound3296 : H12AffineFastState.Bounded env3296 := by
  intro p hp
  have h : env3296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3295_3296 : H12AffineEnvironment.transform 6 40 env3295 = env3296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3295 == env3296) = true)

def env3297 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1296,8192,16384,32768,65536,1044,262144,1025,32768,1297,41261,16,41003,8225,16,320825,16384,16645,19760,74794,17680,257,17681,90415,773]

theorem envBound3297 : H12AffineFastState.Bounded env3297 := by
  intro p hp
  have h : env3297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3296_3297 : H12AffineEnvironment.transform 11 1296 env3296 = env3297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env3296 == env3297) = true)

def env3298 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,32768,65536,1045,262144,1025,32768,1296,41261,17,41003,8225,17,320824,16384,16645,19761,74794,17680,257,17680,90414,772]

theorem envBound3298 : H12AffineFastState.Bounded env3298 := by
  intro p hp
  have h : env3298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3296_3298 : H12AffineEnvironment.transform 11 1297 env3296 = env3298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env3296 == env3298) = true)

theorem identity3298 : scanCanonicalize (H12AffineFastState.compose env3298 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3298 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3299 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,8192,16384,32768,65536,1045,262144,1025,32768,1045,41000,17,41003,8225,17,320573,16384,16384,19508,74794,17429,4,17429,90155,513]

theorem envBound3299 : H12AffineFastState.Bounded env3299 := by
  intro p hp
  have h : env3299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3298_3299 : H12AffineEnvironment.transform 7 5 env3298 = env3299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3298 == env3299) = true)

theorem identity3299 : scanCanonicalize (H12AffineFastState.compose env3299 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 26142) := by decide +kernel

theorem selectedBound3299 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3300 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,8192,16384,32768,26142,1045,262144,1025,32768,1045,41000,17,41003,8225,17,320573,16384,16384,19508,16948,17429,4,17429,1589,513]

theorem envBound3300 : H12AffineFastState.Bounded env3300 := by
  intro p hp
  have h : env3300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3299_3300 : H12AffineEnvironment.transform 15 26142 env3299 = env3300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26142 env3299 == env3300) = true)

theorem identity3300 : scanCanonicalize (H12AffineFastState.compose env3300 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3300 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3301 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,32768,26126,1029,262144,1025,32768,1029,41000,1,41003,8225,1,320557,16384,16384,19492,16932,17413,4,17413,1573,513]

theorem envBound3301 : H12AffineFastState.Bounded env3301 := by
  intro p hp
  have h : env3301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3300_3301 : H12AffineEnvironment.transform 3 0 env3300 = env3301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3300 == env3301) = true)

theorem identity3301 : scanCanonicalize (H12AffineFastState.compose env3301 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8745) := by decide +kernel

theorem selectedBound3301 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3302 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,8745,26126,1029,262144,1025,8745,1029,513,1,514,8225,1,280068,16384,16384,19492,16932,17413,4,17413,1573,513]

theorem envBound3302 : H12AffineFastState.Bounded env3302 := by
  intro p hp
  have h : env3302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3301_3302 : H12AffineEnvironment.transform 14 8745 env3301 = env3302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8745 env3301 == env3302) = true)

theorem identity3302 : scanCanonicalize (H12AffineFastState.compose env3302 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2567) := by decide +kernel

theorem selectedBound3302 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3303 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2567,16384,2094,19465,1029,262144,1025,2094,1029,513,1,514,2598,1,280068,16384,16384,19492,16932,17413,4,17413,1573,513]

theorem envBound3303 : H12AffineFastState.Bounded env3303 := by
  intro p hp
  have h : env3303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3302_3303 : H12AffineEnvironment.transform 12 2567 env3302 = env3303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2567 env3302 == env3303) = true)

theorem identity3303 : scanCanonicalize (H12AffineFastState.compose env3303 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3303 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env3304 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2567,1028,2094,2061,1029,262144,1025,2094,1029,513,1,514,2598,1,262656,1028,1028,2080,1568,1,4,1,1573,513]

theorem envBound3304 : H12AffineFastState.Bounded env3304 := by
  intro p hp
  have h : env3304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3303_3304 : H12AffineEnvironment.transform 13 1028 env3303 = env3304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env3303 == env3304) = true)

theorem identity3304 : scanCanonicalize (H12AffineFastState.compose env3304 (packedSelected [1,2,3] rootPS)) = affineNative (2^(17+1) ^^^ 1546) := by decide +kernel

theorem selectedBound3304 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3305 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2567,1028,2094,2061,1029,1546,1025,2094,1029,513,1,514,2598,1,1034,1028,1028,2080,1568,1,4,1,1573,513]

theorem envBound3305 : H12AffineFastState.Bounded env3305 := by
  intro p hp
  have h : env3305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3304_3305 : H12AffineEnvironment.transform 17 1546 env3304 = env3305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1546 env3304 == env3305) = true)

theorem identity3305 : scanCanonicalize (H12AffineFastState.compose env3305 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3305 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env3306 : List Nat := [2,4,8,0,32,0,40,5,512,14,2048,10,2567,10,2094,2061,11,516,15,2094,11,513,1,514,2598,1,4,10,10,2080,558,1,4,1,555,513]

theorem envBound3306 : H12AffineFastState.Bounded env3306 := by
  intro p hp
  have h : env3306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3305_3306 : H12AffineEnvironment.transform 9 14 env3305 = env3306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3305 == env3306) = true)

theorem identity3306 : scanCanonicalize (H12AffineFastState.compose env3306 (packedSelected [1,2,6,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound3306 : packedSelected [1,2,6,8,11] rootPS < 2^1333 := by decide +kernel

def env3307 : List Nat := [2,4,8,0,32,0,40,5,43,14,2048,10,2092,10,2094,2061,11,47,15,2094,11,42,1,41,2061,1,4,10,10,2080,5,1,4,1,0,42]

theorem envBound3307 : H12AffineFastState.Bounded env3307 := by
  intro p hp
  have h : env3307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3306_3307 : H12AffineEnvironment.transform 8 43 env3306 = env3307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env3306 == env3307) = true)

theorem identity3307 : scanCanonicalize (H12AffineFastState.compose env3307 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound3307 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3308 : List Nat := [2,4,8,0,15,0,7,5,4,14,2048,10,2051,10,2049,2061,11,0,15,2049,11,5,1,6,2061,1,4,10,10,2063,5,1,4,1,0,5]

theorem envBound3308 : H12AffineFastState.Bounded env3308 := by
  intro p hp
  have h : env3308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3307_3308 : H12AffineEnvironment.transform 4 15 env3307 = env3308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env3307 == env3308) = true)

theorem identity3308 : scanCanonicalize (H12AffineFastState.compose env3308 (packedSelected [0,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3308 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env3309 : List Nat := [2,4,3,0,4,0,7,5,4,5,2048,1,2051,1,2049,2054,0,0,4,2049,0,5,1,6,2054,1,4,1,1,2052,5,1,4,1,0,5]

theorem envBound3309 : H12AffineFastState.Bounded env3309 := by
  intro p hp
  have h : env3309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3308_3309 : H12AffineEnvironment.transform 2 3 env3308 = env3309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3308 == env3309) = true)

theorem identity3309 : scanCanonicalize (H12AffineFastState.compose env3309 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound3309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3310 : List Nat := [2,4,3,0,4,0,7,5,4,5,5,1,6,1,4,3,0,0,4,4,0,5,1,6,3,1,4,1,1,1,5,1,4,1,0,5]

theorem envBound3310 : H12AffineFastState.Bounded env3310 := by
  intro p hp
  have h : env3310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3309_3310 : H12AffineEnvironment.transform 10 5 env3309 = env3310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env3309 == env3310) = true)

theorem identity3310 : scanCanonicalize (H12AffineFastState.compose env3310 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3310 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3311 : List Nat := [2,0,3,0,0,0,3,1,0,1,1,1,2,1,0,3,0,0,0,0,0,1,1,2,3,1,0,1,1,1,1,1,0,1,0,1]

theorem envBound3311 : H12AffineFastState.Bounded env3311 := by
  intro p hp
  have h : env3311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3310_3311 : H12AffineEnvironment.transform 1 0 env3310 = env3311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3310 == env3311) = true)

def env3312 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,5544,41003,8329,5545,323712,16384,16812,22561,74794,4252821,257,20480,95295,5652]

theorem envBound3312 : H12AffineFastState.Bounded env3312 := by
  intro p hp
  have h : env3312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3269_3312 : H12AffineEnvironment.transform 5 17 env3269 = env3312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3269 == env3312) = true)

theorem identity3312 : scanCanonicalize (H12AffineFastState.compose env3312 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound3312 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3313 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1465,262144,1025,32768,1045,4194304,444,41003,8329,445,320660,16384,16812,19509,74794,4252821,257,17428,90155,512]

theorem envBound3313 : H12AffineFastState.Bounded env3313 := by
  intro p hp
  have h : env3313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3312_3313 : H12AffineEnvironment.transform 11 1044 env3312 = env3313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env3312 == env3313) = true)

theorem identity3313 : scanCanonicalize (H12AffineFastState.compose env3313 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3313 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3314 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1465,262144,1025,32768,1045,41348,444,41003,8329,445,320660,16384,16812,19509,74794,17681,257,17428,90155,512]

theorem envBound3314 : H12AffineFastState.Bounded env3314 := by
  intro p hp
  have h : env3314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3313_3314 : H12AffineEnvironment.transform 21 41348 env3313 = env3314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3313 == env3314) = true)

theorem identity3314 : scanCanonicalize (H12AffineFastState.compose env3314 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33710) := by decide +kernel

theorem selectedBound3314 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3315 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,33710,1465,262144,1025,32768,1045,41348,444,41003,8329,445,320660,16384,16812,19509,42884,17681,257,17428,58245,512]

theorem envBound3315 : H12AffineFastState.Bounded env3315 := by
  intro p hp
  have h : env3315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3314_3315 : H12AffineEnvironment.transform 15 33710 env3314 = env3315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33710 env3314 == env3315) = true)

theorem identity3315 : scanCanonicalize (H12AffineFastState.compose env3315 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3315 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3316 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26424,25750,1465,262144,1025,26424,1045,18108,444,18195,8329,445,263084,16384,16812,19509,16572,17681,257,17428,1213,512]

theorem envBound3316 : H12AffineFastState.Bounded env3316 := by
  intro p hp
  have h : env3316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3315_3316 : H12AffineEnvironment.transform 14 26424 env3315 = env3316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3315 == env3316) = true)

theorem identity3316 : scanCanonicalize (H12AffineFastState.compose env3316 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound3316 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26424,25750,1465,20157,1025,26424,1045,18108,444,18195,8329,445,19729,16384,16812,19509,16572,17681,257,17428,1213,512]

theorem envBound3317 : H12AffineFastState.Bounded env3317 := by
  intro p hp
  have h : env3317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3316_3317 : H12AffineEnvironment.transform 17 20157 env3316 = env3317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env3316 == env3317) = true)

def env3318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849104,16385,16892,547953,598059,12644669,525568,545872,8479127,8914924]

theorem envBound3318 : H12AffineFastState.Bounded env3318 := by
  intro p hp
  have h : env3318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3208_3318 : H12AffineEnvironment.transform 27 16385 env3208 = env3318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3208 == env3318) = true)

def env3319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323792,16385,16892,22641,74795,12644669,256,20560,8479127,8389612]

theorem envBound3319 : H12AffineFastState.Bounded env3319 := by
  intro p hp
  have h : env3319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3318_3319 : H12AffineEnvironment.transform 18 1024 env3318 = env3319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3318 == env3319) = true)

theorem identity3319 : scanCanonicalize (H12AffineFastState.compose env3319 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255801) := by decide +kernel

theorem selectedBound3319 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,4255801,41003,8329,4255848,323792,16385,16892,22641,74795,260,256,20560,4297134,4256725]

theorem envBound3320 : H12AffineFastState.Bounded env3320 := by
  intro p hp
  have h : env3320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3319_3320 : H12AffineEnvironment.transform 22 4255801 env3319 = env3320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255801 env3319 == env3320) = true)

def env3321 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4255801,41003,8329,4255800,323712,16385,16812,22561,74795,260,256,20480,4297134,4256645]

theorem envBound3321 : H12AffineFastState.Bounded env3321 := by
  intro p hp
  have h : env3321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3320_3321 : H12AffineEnvironment.transform 5 16 env3320 = env3321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3320 == env3321) = true)

def env3322 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,136,61617,41003,8329,61616,323712,16385,16812,22561,74795,260,256,20480,102694,62221]

theorem envBound3322 : H12AffineFastState.Bounded env3322 := by
  intro p hp
  have h : env3322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3321_3322 : H12AffineEnvironment.transform 21 136 env3321 = env3322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env3321 == env3322) = true)

theorem identity3322 : scanCanonicalize (H12AffineFastState.compose env3322 (packedSelected [9,17,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 49072) := by decide +kernel

theorem selectedBound3322 : packedSelected [9,17,21,22] rootPS < 2^1333 := by decide +kernel

def env3323 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,49072,1024,32768,4097,136,61617,41003,8329,61616,20272,16385,16812,22561,74795,260,256,20480,102694,62221]

theorem envBound3323 : H12AffineFastState.Bounded env3323 := by
  intro p hp
  have h : env3323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3322_3323 : H12AffineEnvironment.transform 17 49072 env3322 = env3323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49072 env3322 == env3323) = true)

def env3324 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4372,48904,1024,32768,4097,48,61449,41003,8241,61448,20272,16385,16660,22561,74795,260,256,20480,102694,62221]

theorem envBound3324 : H12AffineFastState.Bounded env3324 := by
  intro p hp
  have h : env3324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3323_3324 : H12AffineEnvironment.transform 6 56 env3323 = env3324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3323 == env3324) = true)

theorem identity3324 : scanCanonicalize (H12AffineFastState.compose env3324 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound3324 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3325 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28681,65536,4372,20225,1024,28681,4097,48,0,20514,8241,1,20272,16385,16660,22561,74795,260,256,20480,90415,772]

theorem envBound3325 : H12AffineFastState.Bounded env3325 := by
  intro p hp
  have h : env3325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3324_3325 : H12AffineEnvironment.transform 14 28681 env3324 = env3325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env3324 == env3325) = true)

theorem identity3325 : scanCanonicalize (H12AffineFastState.compose env3325 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound3325 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3326 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28681,8250,4372,20225,1024,28681,4097,48,0,20514,8241,1,20272,16385,16660,22561,1041,260,256,20480,16661,772]

theorem envBound3326 : H12AffineFastState.Bounded env3326 := by
  intro p hp
  have h : env3326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3325_3326 : H12AffineEnvironment.transform 15 8250 env3325 = env3326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env3325 == env3326) = true)

theorem identity3326 : scanCanonicalize (H12AffineFastState.compose env3326 (packedSelected [0,27] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound3326 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env3327 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,1840,8192,16384,26425,8250,1572,20225,1024,26425,1841,48,0,18194,8241,1,20272,16385,16660,20241,1041,260,256,18224,16661,772]

theorem envBound3327 : H12AffineFastState.Bounded env3327 := by
  intro p hp
  have h : env3327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3326_3327 : H12AffineEnvironment.transform 11 1840 env3326 = env3327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env3326 == env3327) = true)

theorem identity3327 : scanCanonicalize (H12AffineFastState.compose env3327 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound3327 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env3328 : List Nat := [2,4,8,16,32,16,56,30,512,1024,2048,1582,8192,16384,26151,8250,1572,19999,1024,26151,1583,48,0,17932,8241,1,20014,16385,16394,19983,1041,26,30,17966,16395,538]

theorem envBound3328 : H12AffineFastState.Bounded env3328 := by
  intro p hp
  have h : env3328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3327_3328 : H12AffineEnvironment.transform 7 30 env3327 = env3328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env3327 == env3328) = true)

theorem identity3328 : scanCanonicalize (H12AffineFastState.compose env3328 (packedSelected [2,3,5,10,11,23] rootPS)) = affineNative (2^(13+1) ^^^ 1599) := by decide +kernel

theorem selectedBound3328 : packedSelected [2,3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env3329 : List Nat := [2,4,8,16,32,16,56,30,512,1024,2048,1582,8192,1599,8216,8250,1572,2080,1024,8216,1583,48,0,51,8241,1,2065,1598,1589,2096,1041,26,30,17,1588,538]

theorem envBound3329 : H12AffineFastState.Bounded env3329 := by
  intro p hp
  have h : env3329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3328_3329 : H12AffineEnvironment.transform 13 1599 env3328 = env3329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1599 env3328 == env3329) = true)

theorem identity3329 : scanCanonicalize (H12AffineFastState.compose env3329 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound3329 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env3330 : List Nat := [2,4,8,16,32,16,56,30,512,1024,539,1582,8192,1599,8216,8250,1572,571,1024,8216,1583,48,0,51,8241,1,522,1598,1589,555,1041,26,30,17,1588,538]

theorem envBound3330 : H12AffineFastState.Bounded env3330 := by
  intro p hp
  have h : env3330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3329_3330 : H12AffineEnvironment.transform 10 539 env3329 = env3330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env3329 == env3330) = true)

theorem identity3330 : scanCanonicalize (H12AffineFastState.compose env3330 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3330 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env3331 : List Nat := [2,4,8,16,26,16,2,30,512,1024,539,1556,8192,1541,8216,8192,1566,513,1024,8216,1557,10,0,9,8203,1,522,1540,1551,529,1041,26,30,17,1550,538]

theorem envBound3331 : H12AffineFastState.Bounded env3331 := by
  intro p hp
  have h : env3331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3330_3331 : H12AffineEnvironment.transform 4 26 env3330 = env3331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3330 == env3331) = true)

theorem identity3331 : scanCanonicalize (H12AffineFastState.compose env3331 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound3331 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3332 : List Nat := [2,4,8,16,26,16,2,30,512,1024,539,1556,2,1541,26,2,1566,513,1024,26,1557,10,0,9,9,1,522,1540,1551,529,1041,26,30,17,1550,538]

theorem envBound3332 : H12AffineFastState.Bounded env3332 := by
  intro p hp
  have h : env3332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3331_3332 : H12AffineEnvironment.transform 12 2 env3331 = env3332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env3331 == env3332) = true)

theorem identity3332 : scanCanonicalize (H12AffineFastState.compose env3332 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3332 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3333 : List Nat := [2,4,8,10,0,10,2,4,512,1024,513,1550,2,1541,0,2,1540,513,1024,0,1551,10,0,9,9,1,522,1540,1551,523,1035,0,4,11,1550,512]

theorem envBound3333 : H12AffineFastState.Bounded env3333 := by
  intro p hp
  have h : env3333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3332_3333 : H12AffineEnvironment.transform 3 10 env3332 = env3333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3332 == env3333) = true)

theorem identity3333 : scanCanonicalize (H12AffineFastState.compose env3333 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3333 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3334 : List Nat := [2,4,2,0,0,0,2,4,512,1024,513,1540,2,1541,0,2,1540,513,1024,0,1541,0,0,3,3,1,512,1540,1541,513,1025,0,4,1,1540,512]

theorem envBound3334 : H12AffineFastState.Bounded env3334 := by
  intro p hp
  have h : env3334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3333_3334 : H12AffineEnvironment.transform 2 2 env3333 = env3334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3333 == env3334) = true)

theorem identity3334 : scanCanonicalize (H12AffineFastState.compose env3334 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3335 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1028,2,1029,0,2,1028,1,1024,0,1029,0,0,3,3,1,0,1028,1029,1,1025,0,4,1,1028,0]

theorem envBound3335 : H12AffineFastState.Bounded env3335 := by
  intro p hp
  have h : env3335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3334_3335 : H12AffineEnvironment.transform 8 0 env3334 = env3335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3334 == env3335) = true)

def leafEnv3335 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1028,2,1029,0,2,1028,1,1024,0,1029,0,0,3,1025,3,1,1,0,1028,1029,1,1025,0,4,1,4,2,1028,0,1,1029,0]

def active3335 : List Nat := [0,1,9]

def tree3335 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3335 : H12WitnessSearch.Good tree3335 := H12GlobalWitnessIndex.good

theorem leafIdentity3335 : H12AffineFastState.composeSystem env3335 rootObs = leafEnv3335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3335 rootObs == leafEnv3335) = true)

theorem terminalChecked3335 : H12PackedTerminal.terminalCheckFast leafEnv3335 active3335 tree3335 = true := by decide +kernel

def env3336 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4373,48905,1024,32768,4097,49,61448,41003,8240,61449,20272,16385,16661,22561,74795,260,256,20480,102694,62221]

theorem envBound3336 : H12AffineFastState.Bounded env3336 := by
  intro p hp
  have h : env3336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3323_3336 : H12AffineEnvironment.transform 6 57 env3323 = env3336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env3323 == env3336) = true)

theorem identity3336 : scanCanonicalize (H12AffineFastState.compose env3336 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53542) := by decide +kernel

theorem selectedBound3336 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3337 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,53542,4373,48905,1024,32768,4097,49,61448,41003,8240,61449,20272,16385,16661,22561,62733,260,256,20480,16384,62221]

theorem envBound3337 : H12AffineFastState.Bounded env3337 := by
  intro p hp
  have h : env3337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3336_3337 : H12AffineEnvironment.transform 15 53542 env3336 = env3337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53542 env3336 == env3337) = true)

theorem identity3337 : scanCanonicalize (H12AffineFastState.compose env3337 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound3337 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3338 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28681,8495,4373,20224,1024,28681,4097,49,1,20514,8240,0,20272,16385,16661,22561,1284,260,256,20480,16384,772]

theorem envBound3338 : H12AffineFastState.Bounded env3338 := by
  intro p hp
  have h : env3338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3337_3338 : H12AffineEnvironment.transform 14 28681 env3337 = env3338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env3337 == env3338) = true)

theorem identity3338 : scanCanonicalize (H12AffineFastState.compose env3338 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3338 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3339 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,8192,16384,28681,8495,4357,20224,1024,28681,4097,33,1,20514,8224,0,20256,16385,16645,22561,1284,260,256,20480,16384,772]

theorem envBound3339 : H12AffineFastState.Bounded env3339 := by
  intro p hp
  have h : env3339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3338_3339 : H12AffineEnvironment.transform 3 0 env3338 = env3339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3338 == env3339) = true)

theorem identity3339 : scanCanonicalize (H12AffineFastState.compose env3339 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2860) := by decide +kernel

theorem selectedBound3339 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3340 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,2860,16384,23333,2563,4357,20224,1024,23333,4097,33,1,20514,2828,0,20256,16385,16645,22561,1284,260,256,20480,16384,772]

theorem envBound3340 : H12AffineFastState.Bounded env3340 := by
  intro p hp
  have h : env3340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3339_3340 : H12AffineEnvironment.transform 12 2860 env3339 = env3340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2860 env3339 == env3340) = true)

theorem identity3340 : scanCanonicalize (H12AffineFastState.compose env3340 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 2351) := by decide +kernel

theorem selectedBound3340 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3341 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,2860,2351,4618,2563,4357,1583,1024,4618,4097,33,1,6413,2828,0,1551,2350,2090,4366,1284,260,256,6447,2351,772]

theorem envBound3341 : H12AffineFastState.Bounded env3341 := by
  intro p hp
  have h : env3341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3340_3341 : H12AffineEnvironment.transform 13 2351 env3340 = env3341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2351 env3340 == env3341) = true)

theorem identity3341 : scanCanonicalize (H12AffineFastState.compose env3341 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound3341 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3342 : List Nat := [2,4,8,0,32,0,41,256,512,1024,1802,4096,1062,1573,4618,1289,4357,1583,1024,4618,4097,33,1,5639,1030,0,1551,1572,1824,4366,1284,260,256,5669,1573,772]

theorem envBound3342 : H12AffineFastState.Bounded env3342 := by
  intro p hp
  have h : env3342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3341_3342 : H12AffineEnvironment.transform 10 1802 env3341 = env3342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env3341 == env3342) = true)

theorem identity3342 : scanCanonicalize (H12AffineFastState.compose env3342 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3342 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env3343 : List Nat := [2,4,8,0,32,0,41,256,512,1024,1802,1572,1062,1573,1070,1289,1825,1583,1024,1070,1573,33,1,35,1030,0,1551,1572,1824,1834,1284,260,256,1,1573,772]

theorem envBound3343 : H12AffineFastState.Bounded env3343 := by
  intro p hp
  have h : env3343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3342_3343 : H12AffineEnvironment.transform 11 1572 env3342 = env3343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env3342 == env3343) = true)

theorem identity3343 : scanCanonicalize (H12AffineFastState.compose env3343 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound3343 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3344 : List Nat := [2,4,8,0,32,0,41,46,512,1024,1572,1572,1062,1573,1070,1063,1551,1583,1024,1070,1573,33,1,35,1030,0,1551,1572,1550,1540,1066,42,46,1,1573,554]

theorem envBound3344 : H12AffineFastState.Bounded env3344 := by
  intro p hp
  have h : env3344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3343_3344 : H12AffineEnvironment.transform 7 46 env3343 = env3344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env3343 == env3344) = true)

theorem identity3344 : scanCanonicalize (H12AffineFastState.compose env3344 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3344 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3345 : List Nat := [2,4,8,0,11,0,2,5,512,1024,1551,1551,1037,1550,1029,1036,1551,1540,1024,1029,1550,10,1,8,1030,0,1551,1551,1550,1540,1025,1,5,1,1550,513]

theorem envBound3345 : H12AffineFastState.Bounded env3345 := by
  intro p hp
  have h : env3345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3344_3345 : H12AffineEnvironment.transform 4 11 env3344 = env3345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3344 == env3345) = true)

theorem identity3345 : scanCanonicalize (H12AffineFastState.compose env3345 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound3345 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3346 : List Nat := [2,4,8,0,11,0,2,5,4,1024,1035,1035,1037,1034,1029,1036,1035,1024,1024,1029,1034,10,1,8,1030,0,1035,1035,1034,1024,1025,1,5,1,1034,5]

theorem envBound3346 : H12AffineFastState.Bounded env3346 := by
  intro p hp
  have h : env3346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3345_3346 : H12AffineEnvironment.transform 8 4 env3345 = env3346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env3345 == env3346) = true)

theorem identity3346 : scanCanonicalize (H12AffineFastState.compose env3346 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3346 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3347 : List Nat := [2,1,8,0,11,0,2,0,1,1024,1035,1035,1032,1034,1024,1033,1035,1024,1024,1024,1034,10,1,8,1027,0,1035,1035,1034,1024,1025,1,0,1,1034,0]

theorem envBound3347 : H12AffineFastState.Bounded env3347 := by
  intro p hp
  have h : env3347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3346_3347 : H12AffineEnvironment.transform 1 1 env3346 = env3347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3346 == env3347) = true)

theorem identity3347 : scanCanonicalize (H12AffineFastState.compose env3347 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound3347 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3348 : List Nat := [2,1,8,0,11,0,2,0,1,11,0,0,3,1,11,2,0,11,11,11,1,10,1,8,8,0,0,0,1,11,10,1,0,1,1,0]

theorem envBound3348 : H12AffineFastState.Bounded env3348 := by
  intro p hp
  have h : env3348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3347_3348 : H12AffineEnvironment.transform 9 11 env3347 = env3348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env3347 == env3348) = true)

def leafEnv3348 : List Nat := [2,1,8,0,11,0,2,0,1,11,0,0,3,1,11,2,0,11,11,11,1,10,1,8,10,8,1,0,0,0,1,11,10,1,0,1,1,9,1,0,1,1,0]

def active3348 : List Nat := [0,2]

def tree3348 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3348 : H12WitnessSearch.Good tree3348 := H12GlobalWitnessIndex.good

theorem leafIdentity3348 : H12AffineFastState.composeSystem env3348 rootObs = leafEnv3348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3348 rootObs == leafEnv3348) = true)

theorem terminalChecked3348 : H12PackedTerminal.terminalCheckFast leafEnv3348 active3348 tree3348 = true := by decide +kernel

def env3349 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,137,61616,41003,8329,61617,323712,16385,16812,22561,74795,260,256,20480,102695,62220]

theorem envBound3349 : H12AffineFastState.Bounded env3349 := by
  intro p hp
  have h : env3349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3321_3349 : H12AffineEnvironment.transform 21 137 env3321 = env3349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env3321 == env3349) = true)

theorem identity3349 : scanCanonicalize (H12AffineFastState.compose env3349 (packedSelected [9,17,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 48668) := by decide +kernel

theorem selectedBound3349 : packedSelected [9,17,21,22] rootPS < 2^1333 := by decide +kernel

def env3350 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,48668,1024,32768,4097,137,61616,41003,8329,61617,20124,16385,16812,22561,74795,260,256,20480,102695,62220]

theorem envBound3350 : H12AffineFastState.Bounded env3350 := by
  intro p hp
  have h : env3350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3349_3350 : H12AffineEnvironment.transform 17 48668 env3349 = env3350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48668 env3349 == env3350) = true)

def env3351 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4372,48668,1024,32768,4097,49,61448,41003,8241,61449,20004,16385,16660,22561,74795,260,256,20480,102695,62220]

theorem envBound3351 : H12AffineFastState.Bounded env3351 := by
  intro p hp
  have h : env3351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3350_3351 : H12AffineEnvironment.transform 6 56 env3350 = env3351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3350 == env3351) = true)

theorem identity3351 : scanCanonicalize (H12AffineFastState.compose env3351 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53542) := by decide +kernel

theorem selectedBound3351 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3352 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,53542,4372,48668,1024,32768,4097,49,61448,41003,8241,61449,20004,16385,16660,22561,62733,260,256,20480,16385,62220]

theorem envBound3352 : H12AffineFastState.Bounded env3352 := by
  intro p hp
  have h : env3352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3351_3352 : H12AffineEnvironment.transform 15 53542 env3351 = env3352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53542 env3351 == env3352) = true)

theorem identity3352 : scanCanonicalize (H12AffineFastState.compose env3352 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound3352 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3353 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28681,8495,4372,19989,1024,28681,4097,49,1,20514,8241,0,20004,16385,16660,22561,1284,260,256,20480,16385,773]

theorem envBound3353 : H12AffineFastState.Bounded env3353 := by
  intro p hp
  have h : env3353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3352_3353 : H12AffineEnvironment.transform 14 28681 env3352 = env3353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env3352 == env3353) = true)

theorem identity3353 : scanCanonicalize (H12AffineFastState.compose env3353 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3353 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3354 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,8192,16384,28681,8495,4356,19973,1024,28681,4097,33,1,20514,8225,0,20004,16385,16644,22561,1284,260,256,20480,16385,773]

theorem envBound3354 : H12AffineFastState.Bounded env3354 := by
  intro p hp
  have h : env3354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3353_3354 : H12AffineEnvironment.transform 3 0 env3353 = env3354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3353 == env3354) = true)

theorem identity3354 : scanCanonicalize (H12AffineFastState.compose env3354 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2829) := by decide +kernel

theorem selectedBound3354 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3355 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,2829,16384,23300,2594,4356,19973,1024,23300,4097,33,1,20514,2860,0,20004,16385,16644,22561,1284,260,256,20480,16385,773]

theorem envBound3355 : H12AffineFastState.Bounded env3355 := by
  intro p hp
  have h : env3355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3354_3355 : H12AffineEnvironment.transform 12 2829 env3354 = env3355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2829 env3354 == env3355) = true)

theorem identity3355 : scanCanonicalize (H12AffineFastState.compose env3355 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound3355 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3356 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,2351,2829,16384,16939,2594,2091,19973,1024,16939,2350,33,1,18701,2860,0,20004,16385,16644,16654,1284,260,256,18735,16385,773]

theorem envBound3356 : H12AffineFastState.Bounded env3356 := by
  intro p hp
  have h : env3356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3355_3356 : H12AffineEnvironment.transform 11 2351 env3355 = env3356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env3355 == env3356) = true)

theorem identity3356 : scanCanonicalize (H12AffineFastState.compose env3356 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 1825) := by decide +kernel

theorem selectedBound3356 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3357 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,2351,2829,1825,1290,2594,2091,2340,1024,1290,2350,33,1,3628,2860,0,2309,1824,1573,1583,1284,260,256,3598,1824,773]

theorem envBound3357 : H12AffineFastState.Bounded env3357 := by
  intro p hp
  have h : env3357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3356_3357 : H12AffineEnvironment.transform 13 1825 env3356 = env3357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1825 env3356 == env3357) = true)

theorem identity3357 : scanCanonicalize (H12AffineFastState.compose env3357 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3357 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3358 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,2090,2568,1572,1039,2594,2091,2081,1024,1039,2091,33,1,3628,2601,0,2048,1573,1573,1583,1025,1,5,3598,1573,512]

theorem envBound3358 : H12AffineFastState.Bounded env3358 := by
  intro p hp
  have h : env3358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3357_3358 : H12AffineEnvironment.transform 7 5 env3357 = env3358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3357 == env3358) = true)

theorem identity3358 : scanCanonicalize (H12AffineFastState.compose env3358 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3358 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3359 : List Nat := [2,4,2,0,32,0,34,5,512,1024,2048,2080,2562,1572,1029,2594,2081,2081,1024,1029,2081,33,1,3622,2595,0,2048,1573,1573,1573,1025,1,5,3588,1573,512]

theorem envBound3359 : H12AffineFastState.Bounded env3359 := by
  intro p hp
  have h : env3359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3358_3359 : H12AffineEnvironment.transform 2 2 env3358 = env3359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3358 == env3359) = true)

theorem identity3359 : scanCanonicalize (H12AffineFastState.compose env3359 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3359 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env3360 : List Nat := [2,4,2,0,32,0,34,5,512,5,2048,2080,2562,545,0,2594,2081,2081,5,0,2081,33,1,2595,2595,0,2048,544,544,544,4,1,5,2561,544,512]

theorem envBound3360 : H12AffineFastState.Bounded env3360 := by
  intro p hp
  have h : env3360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3359_3360 : H12AffineEnvironment.transform 9 5 env3359 = env3360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3359 == env3360) = true)

def env3361 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4373,48668,1024,32768,4097,48,61449,41003,8240,61448,20005,16385,16661,22561,74795,260,256,20480,102695,62220]

theorem envBound3361 : H12AffineFastState.Bounded env3361 := by
  intro p hp
  have h : env3361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3350_3361 : H12AffineEnvironment.transform 6 57 env3350 = env3361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env3350 == env3361) = true)

theorem identity3361 : scanCanonicalize (H12AffineFastState.compose env3361 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound3361 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3362 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28681,65536,4373,19989,1024,28681,4097,48,0,20514,8240,1,20005,16385,16661,22561,74795,260,256,20480,90414,773]

theorem envBound3362 : H12AffineFastState.Bounded env3362 := by
  intro p hp
  have h : env3362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3361_3362 : H12AffineEnvironment.transform 14 28681 env3361 = env3362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env3361 == env3362) = true)

theorem identity3362 : scanCanonicalize (H12AffineFastState.compose env3362 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound3362 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3363 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28681,8251,4373,19989,1024,28681,4097,48,0,20514,8240,1,20005,16385,16661,22561,1040,260,256,20480,16661,773]

theorem envBound3363 : H12AffineFastState.Bounded env3363 := by
  intro p hp
  have h : env3363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3362_3363 : H12AffineEnvironment.transform 15 8251 env3362 = env3363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env3362 == env3363) = true)

theorem identity3363 : scanCanonicalize (H12AffineFastState.compose env3363 (packedSelected [0,27] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3363 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env3364 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,1572,8192,16384,26157,8251,1841,19989,1024,26157,1573,48,0,17926,8240,1,20005,16385,16661,19973,1040,260,256,17956,16661,773]

theorem envBound3364 : H12AffineFastState.Bounded env3364 := by
  intro p hp
  have h : env3364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3363_3364 : H12AffineEnvironment.transform 11 1572 env3363 = env3364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env3363 == env3364) = true)

theorem identity3364 : scanCanonicalize (H12AffineFastState.compose env3364 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 8998) := by decide +kernel

theorem selectedBound3364 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env3365 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,1572,8192,8998,1291,8251,1841,11571,1024,1291,1573,48,0,9504,8240,1,11523,8999,8755,11555,1040,260,256,9474,8755,773]

theorem envBound3365 : H12AffineFastState.Bounded env3365 := by
  intro p hp
  have h : env3365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3364_3365 : H12AffineEnvironment.transform 13 8998 env3364 = env3365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8998 env3364 == env3365) = true)

theorem identity3365 : scanCanonicalize (H12AffineFastState.compose env3365 (packedSelected [0,3,4,5,7,9,10,17,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound3365 : packedSelected [0,3,4,5,7,9,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3366 : List Nat := [2,4,8,16,32,16,57,21,512,1024,2048,1572,8192,8755,1054,8251,1572,11302,1024,1054,1573,48,0,9269,8240,1,11286,8754,8755,11318,1040,17,21,9239,8755,528]

theorem envBound3366 : H12AffineFastState.Bounded env3366 := by
  intro p hp
  have h : env3366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3365_3366 : H12AffineEnvironment.transform 7 21 env3365 = env3366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env3365 == env3366) = true)

theorem identity3366 : scanCanonicalize (H12AffineFastState.compose env3366 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 3612) := by decide +kernel

theorem selectedBound3366 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3367 : List Nat := [2,4,8,16,32,16,57,21,512,1024,2048,1572,3612,3119,1054,3623,1572,570,1024,1054,1573,48,0,2601,3628,1,522,3118,3119,554,1040,17,21,2571,3119,528]

theorem envBound3367 : H12AffineFastState.Bounded env3367 := by
  intro p hp
  have h : env3367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3366_3367 : H12AffineEnvironment.transform 12 3612 env3366 = env3367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3612 env3366 == env3367) = true)

theorem identity3367 : scanCanonicalize (H12AffineFastState.compose env3367 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound3367 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3368 : List Nat := [2,4,8,16,32,16,57,21,512,1024,539,1572,1031,1588,1054,1084,1572,570,1024,1054,1573,48,0,50,1079,1,522,1589,1588,554,1040,17,21,16,1588,528]

theorem envBound3368 : H12AffineFastState.Bounded env3368 := by
  intro p hp
  have h : env3368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3367_3368 : H12AffineEnvironment.transform 10 539 env3367 = env3368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env3367 == env3368) = true)

theorem identity3368 : scanCanonicalize (H12AffineFastState.compose env3368 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3368 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3369 : List Nat := [2,4,8,16,0,16,25,21,512,1024,539,1540,1031,1556,1054,1052,1540,538,1024,1054,1541,16,0,18,1047,1,522,1557,1556,522,1040,17,21,16,1556,528]

theorem envBound3369 : H12AffineFastState.Bounded env3369 := by
  intro p hp
  have h : env3369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3368_3369 : H12AffineEnvironment.transform 4 0 env3368 = env3369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3368 == env3369) = true)

theorem identity3369 : scanCanonicalize (H12AffineFastState.compose env3369 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3370 : List Nat := [2,4,8,16,0,16,25,21,512,5,539,513,2,529,27,25,513,538,5,27,512,16,0,18,18,1,522,528,529,522,21,17,21,16,529,528]

theorem envBound3370 : H12AffineFastState.Bounded env3370 := by
  intro p hp
  have h : env3370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3369_3370 : H12AffineEnvironment.transform 9 5 env3369 = env3370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3369 == env3370) = true)

theorem identity3370 : scanCanonicalize (H12AffineFastState.compose env3370 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound3370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3371 : List Nat := [2,4,8,16,0,16,25,21,27,5,0,26,2,10,27,25,26,1,5,27,27,16,0,18,18,1,17,11,10,17,21,17,21,16,10,11]

theorem envBound3371 : H12AffineFastState.Bounded env3371 := by
  intro p hp
  have h : env3371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3370_3371 : H12AffineEnvironment.transform 8 27 env3370 = env3371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env3370 == env3371) = true)

def env3372 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4255801,41003,8329,4255801,323713,16385,16813,22560,74795,260,256,20481,4297134,4256644]

theorem envBound3372 : H12AffineFastState.Bounded env3372 := by
  intro p hp
  have h : env3372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3320_3372 : H12AffineEnvironment.transform 5 17 env3320 = env3372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3320 == env3372) = true)

theorem identity3372 : scanCanonicalize (H12AffineFastState.compose env3372 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61828) := by decide +kernel

theorem selectedBound3372 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3373 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61828,445,41003,8329,445,323713,16385,16813,22560,74795,260,256,20481,90154,512]

theorem envBound3373 : H12AffineFastState.Bounded env3373 := by
  intro p hp
  have h : env3373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3372_3373 : H12AffineEnvironment.transform 21 61828 env3372 = env3373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61828 env3372 == env3373) = true)

theorem identity3373 : scanCanonicalize (H12AffineFastState.compose env3373 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound3373 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3374 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1024,32768,4097,41348,445,41003,8329,445,303233,4097,4525,2080,74795,260,256,1,77866,512]

theorem envBound3374 : H12AffineFastState.Bounded env3374 := by
  intro p hp
  have h : env3374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3373_3374 : H12AffineEnvironment.transform 13 4096 env3373 = env3374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3373 == env3374) = true)

theorem identity3374 : scanCanonicalize (H12AffineFastState.compose env3374 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3374 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3375 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,38842,4525,262144,1024,32768,4097,41348,445,41003,8329,445,303233,4097,4525,2080,45969,260,256,1,42896,512]

theorem envBound3375 : H12AffineFastState.Bounded env3375 := by
  intro p hp
  have h : env3375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3374_3375 : H12AffineEnvironment.transform 15 38842 env3374 = env3375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3374 == env3375) = true)

theorem identity3375 : scanCanonicalize (H12AffineFastState.compose env3375 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound3375 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3376 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,262144,1024,14137,4097,5821,445,5906,8329,445,268216,4097,4525,2080,1192,260,256,1,4265,512]

theorem envBound3376 : H12AffineFastState.Bounded env3376 := by
  intro p hp
  have h : env3376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3375_3376 : H12AffineEnvironment.transform 14 14137 env3375 = env3376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env3375 == env3376) = true)

theorem identity3376 : scanCanonicalize (H12AffineFastState.compose env3376 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound3376 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3377 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,2184,1024,14137,4097,5821,445,5906,8329,445,7984,4097,4525,2080,1192,260,256,1,4265,512]

theorem envBound3377 : H12AffineFastState.Bounded env3377 := by
  intro p hp
  have h : env3377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3376_3377 : H12AffineEnvironment.transform 17 2184 env3376 = env3377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env3376 == env3377) = true)

theorem identity3377 : scanCanonicalize (H12AffineFastState.compose env3377 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3377 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env3378 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,13972,8323,4096,2184,1024,13972,4097,5821,16,5823,8329,16,7837,4097,4096,2080,1192,169,173,1,4265,512]

theorem envBound3378 : H12AffineFastState.Bounded env3378 := by
  intro p hp
  have h : env3378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3377_3378 : H12AffineEnvironment.transform 7 173 env3377 = env3378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3377 == env3378) = true)

theorem identity3378 : scanCanonicalize (H12AffineFastState.compose env3378 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound3378 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3379 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,4096,8192,4096,13972,8323,4096,642,1024,13972,4097,5821,16,5823,8329,16,5271,4097,4096,554,1192,169,173,1,4265,512]

theorem envBound3379 : H12AffineFastState.Bounded env3379 := by
  intro p hp
  have h : env3379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3378_3379 : H12AffineEnvironment.transform 10 522 env3378 = env3379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env3378 == env3379) = true)

theorem identity3379 : scanCanonicalize (H12AffineFastState.compose env3379 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3379 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3380 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,1693,8192,1693,8201,8323,1693,642,1024,8201,1692,32,16,34,8329,16,522,1692,1693,554,1192,169,173,1,1588,512]

theorem envBound3380 : H12AffineFastState.Bounded env3380 := by
  intro p hp
  have h : env3380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3379_3380 : H12AffineEnvironment.transform 11 1693 env3379 = env3380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3379 == env3380) = true)

theorem identity3380 : scanCanonicalize (H12AffineFastState.compose env3380 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 170) := by decide +kernel

theorem selectedBound3380 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3381 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,1693,170,1693,163,41,1693,642,1024,163,1692,32,16,34,35,16,522,1692,1693,554,1192,169,173,1,1588,512]

theorem envBound3381 : H12AffineFastState.Bounded env3381 := by
  intro p hp
  have h : env3381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3380_3381 : H12AffineEnvironment.transform 12 170 env3380 = env3381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 170 env3380 == env3381) = true)

theorem identity3381 : scanCanonicalize (H12AffineFastState.compose env3381 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound3381 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env3382 : List Nat := [2,4,8,16,32,17,3,46,512,1024,522,1566,41,1566,32,41,1566,513,1024,32,1567,32,16,34,35,16,522,1567,1566,554,1067,42,46,1,1588,512]

theorem envBound3382 : H12AffineFastState.Bounded env3382 := by
  intro p hp
  have h : env3382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3381_3382 : H12AffineEnvironment.transform 6 3 env3381 = env3382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env3381 == env3382) = true)

theorem identity3382 : scanCanonicalize (H12AffineFastState.compose env3382 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3382 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env3383 : List Nat := [2,4,8,16,0,17,3,14,512,1024,522,1566,9,1566,0,9,1566,513,1024,0,1567,0,16,2,3,16,522,1567,1566,522,1035,10,14,1,1556,512]

theorem envBound3383 : H12AffineFastState.Bounded env3383 := by
  intro p hp
  have h : env3383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3382_3383 : H12AffineEnvironment.transform 4 0 env3382 = env3383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3382 == env3383) = true)

theorem identity3383 : scanCanonicalize (H12AffineFastState.compose env3383 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3384 : List Nat := [2,4,8,16,0,17,3,14,0,1024,10,1054,9,1054,0,9,1054,1,1024,0,1055,0,16,2,3,16,10,1055,1054,10,1035,10,14,1,1044,0]

theorem envBound3384 : H12AffineFastState.Bounded env3384 := by
  intro p hp
  have h : env3384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3383_3384 : H12AffineEnvironment.transform 8 0 env3383 = env3384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3383 == env3384) = true)

theorem identity3384 : scanCanonicalize (H12AffineFastState.compose env3384 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3385 : List Nat := [2,4,8,1,0,0,3,14,0,1024,10,1039,9,1039,0,9,1039,1,1024,0,1038,0,1,2,3,1,10,1038,1039,10,1035,10,14,1,1029,0]

theorem envBound3385 : H12AffineFastState.Bounded env3385 := by
  intro p hp
  have h : env3385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3384_3385 : H12AffineEnvironment.transform 3 1 env3384 = env3385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3384 == env3385) = true)

theorem identity3385 : scanCanonicalize (H12AffineFastState.compose env3385 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3385 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env3386 : List Nat := [2,4,2,1,0,0,3,4,0,1024,0,1029,3,1029,0,3,1029,1,1024,0,1028,0,1,2,3,1,0,1028,1029,0,1025,0,4,1,1029,0]

theorem envBound3386 : H12AffineFastState.Bounded env3386 := by
  intro p hp
  have h : env3386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3385_3386 : H12AffineEnvironment.transform 2 2 env3385 = env3386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3385 == env3386) = true)

def leafEnv3386 : List Nat := [2,4,2,1,0,0,3,4,0,1024,0,1029,3,1029,0,3,1029,1,1024,0,1028,0,1,2,1025,3,1,1,0,1028,1029,0,1025,0,4,1,4,2,1029,0,1,1029,0]

def active3386 : List Nat := [0,1,9]

def tree3386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3386 : H12WitnessSearch.Good tree3386 := H12GlobalWitnessIndex.good

theorem leafIdentity3386 : H12AffineFastState.composeSystem env3386 rootObs = leafEnv3386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3386 rootObs == leafEnv3386) = true)

theorem terminalChecked3386 : H12PackedTerminal.terminalCheckFast leafEnv3386 active3386 tree3386 = true := by decide +kernel

def env3387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323793,16385,16892,22640,74794,12644669,257,20561,8479127,8389613]

theorem envBound3387 : H12AffineFastState.Bounded env3387 := by
  intro p hp
  have h : env3387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3318_3387 : H12AffineEnvironment.transform 18 1025 env3318 = env3387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3318 == env3387) = true)

theorem identity3387 : scanCanonicalize (H12AffineFastState.compose env3387 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46393) := by decide +kernel

theorem selectedBound3387 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,46393,8388608,41003,8329,8388688,323793,16385,16892,22640,74794,8406020,257,20561,8479127,8389613]

theorem envBound3388 : H12AffineFastState.Bounded env3388 := by
  intro p hp
  have h : env3388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3387_3388 : H12AffineEnvironment.transform 21 46393 env3387 = env3388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46393 env3387 == env3388) = true)

def env3389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46393,8388608,41003,8329,8388608,323713,16385,16812,22560,74794,8406020,257,20481,8479127,8389565]

theorem envBound3389 : H12AffineFastState.Bounded env3389 := by
  intro p hp
  have h : env3389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3388_3389 : H12AffineEnvironment.transform 5 16 env3388 = env3389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3388 == env3389) = true)

theorem identity3389 : scanCanonicalize (H12AffineFastState.compose env3389 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3389 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46393,445,41003,8329,445,323713,16385,16812,22560,74794,17849,257,20481,90154,512]

theorem envBound3390 : H12AffineFastState.Bounded env3390 := by
  intro p hp
  have h : env3390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3389_3390 : H12AffineEnvironment.transform 22 445 env3389 = env3390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3389 == env3390) = true)

theorem identity3390 : scanCanonicalize (H12AffineFastState.compose env3390 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound3390 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1025,32768,1213,41349,445,41003,8329,445,320573,16385,16812,19612,74794,17849,257,17597,90154,512]

theorem envBound3391 : H12AffineFastState.Bounded env3391 := by
  intro p hp
  have h : env3391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3390_3391 : H12AffineEnvironment.transform 11 1212 env3390 = env3391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env3390 == env3391) = true)

theorem identity3391 : scanCanonicalize (H12AffineFastState.compose env3391 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound3391 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33542,1296,262144,1025,32768,1213,41349,445,41003,8329,445,320573,16385,16812,19612,42796,17849,257,17597,58156,512]

theorem envBound3392 : H12AffineFastState.Bounded env3392 := by
  intro p hp
  have h : env3392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3391_3392 : H12AffineEnvironment.transform 15 33542 env3391 = env3392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env3391 == env3392) = true)

theorem identity3392 : scanCanonicalize (H12AffineFastState.compose env3392 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound3392 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25663,1296,262144,1025,26425,1213,18108,445,18194,8329,445,262916,16385,16812,19612,16405,17849,257,17597,1045,512]

theorem envBound3393 : H12AffineFastState.Bounded env3393 := by
  intro p hp
  have h : env3393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3392_3393 : H12AffineEnvironment.transform 14 26425 env3392 = env3393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env3392 == env3393) = true)

theorem identity3393 : scanCanonicalize (H12AffineFastState.compose env3393 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3393 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env3394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,1692,8613,8867,1296,262144,1025,8613,1213,32,445,398,8329,445,262916,1693,1840,2560,1673,805,257,545,1045,512]

theorem envBound3394 : H12AffineFastState.Bounded env3394 := by
  intro p hp
  have h : env3394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3393_3394 : H12AffineEnvironment.transform 13 1692 env3393 = env3394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env3393 == env3394) = true)

theorem identity3394 : scanCanonicalize (H12AffineFastState.compose env3394 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3394 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3395 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1044,8192,1588,8461,8715,1296,262144,1025,8461,1045,32,277,294,8225,277,262916,1589,1840,2560,1569,805,257,545,1045,512]

theorem envBound3395 : H12AffineFastState.Bounded env3395 := by
  intro p hp
  have h : env3395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3394_3395 : H12AffineEnvironment.transform 6 40 env3394 = env3395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3394 == env3395) = true)

theorem identity3395 : scanCanonicalize (H12AffineFastState.compose env3395 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 9245) := by decide +kernel

theorem selectedBound3395 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3396 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1044,8192,1588,8461,8715,1296,9245,1025,8461,1045,32,277,294,8225,277,10009,1589,1840,2560,1569,805,257,545,1045,512]

theorem envBound3396 : H12AffineFastState.Bounded env3396 := by
  intro p hp
  have h : env3396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3395_3396 : H12AffineEnvironment.transform 17 9245 env3395 = env3396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9245 env3395 == env3396) = true)

theorem identity3396 : scanCanonicalize (H12AffineFastState.compose env3396 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3396 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3397 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,8192,1588,8200,8715,1045,9245,1025,8200,1045,32,16,35,8225,16,9756,1589,1589,2560,1569,544,4,545,1045,512]

theorem envBound3397 : H12AffineFastState.Bounded env3397 := by
  intro p hp
  have h : env3397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3396_3397 : H12AffineEnvironment.transform 7 5 env3396 = env3397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3396 == env3397) = true)

theorem identity3397 : scanCanonicalize (H12AffineFastState.compose env3397 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound3397 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3398 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1583,1044,8192,1588,8200,8715,1045,9245,1025,8200,1045,32,16,35,8225,16,9756,1589,1589,1071,1569,544,4,545,1045,512]

theorem envBound3398 : H12AffineFastState.Bounded env3398 := by
  intro p hp
  have h : env3398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3397_3398 : H12AffineEnvironment.transform 10 1583 env3397 = env3398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env3397 == env3398) = true)

theorem identity3398 : scanCanonicalize (H12AffineFastState.compose env3398 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 562) := by decide +kernel

theorem selectedBound3398 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3399 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1583,1044,562,1588,570,57,1045,1583,1025,570,1045,32,16,35,531,16,1070,1589,1589,1071,1569,544,4,545,1045,512]

theorem envBound3399 : H12AffineFastState.Bounded env3399 := by
  intro p hp
  have h : env3399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3398_3399 : H12AffineEnvironment.transform 12 562 env3398 = env3399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 562 env3398 == env3399) = true)

theorem identity3399 : scanCanonicalize (H12AffineFastState.compose env3399 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound3399 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3400 : List Nat := [2,4,8,16,32,16,40,5,512,564,27,544,562,0,570,57,545,27,565,570,545,32,16,35,531,16,538,1,1,539,21,544,4,545,545,512]

theorem envBound3400 : H12AffineFastState.Bounded env3400 := by
  intro p hp
  have h : env3400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3399_3400 : H12AffineEnvironment.transform 9 564 env3399 = env3400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env3399 == env3400) = true)

theorem identity3400 : scanCanonicalize (H12AffineFastState.compose env3400 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3401 : List Nat := [2,4,8,10,32,10,40,5,512,558,1,544,552,0,544,35,545,1,559,544,545,32,10,35,521,10,512,1,1,513,15,544,4,545,545,512]

theorem envBound3401 : H12AffineFastState.Bounded env3401 := by
  intro p hp
  have h : env3401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3400_3401 : H12AffineEnvironment.transform 3 10 env3400 = env3401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3400 == env3401) = true)

theorem identity3401 : scanCanonicalize (H12AffineFastState.compose env3401 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3401 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3402 : List Nat := [2,4,8,10,32,10,40,5,0,46,1,32,40,0,32,35,33,1,47,32,33,32,10,35,9,10,0,1,1,1,15,32,4,33,33,0]

theorem envBound3402 : H12AffineFastState.Bounded env3402 := by
  intro p hp
  have h : env3402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3401_3402 : H12AffineEnvironment.transform 8 0 env3401 = env3402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3401 == env3402) = true)

def env3403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46393,8388608,41003,8329,8388609,323712,16385,16813,22561,74794,8406020,257,20480,8479127,8389564]

theorem envBound3403 : H12AffineFastState.Bounded env3403 := by
  intro p hp
  have h : env3403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3388_3403 : H12AffineEnvironment.transform 5 17 env3388 = env3403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3388 == env3403) = true)

def env3404 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,46213,8388608,41003,8329,8388609,323712,16385,16401,22561,74794,8406020,189,20480,8478763,8389120]

theorem envBound3404 : H12AffineFastState.Bounded env3404 := by
  intro p hp
  have h : env3404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3403_3404 : H12AffineEnvironment.transform 7 188 env3403 = env3404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3403 == env3404) = true)

theorem identity3404 : scanCanonicalize (H12AffineFastState.compose env3404 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 46261) := by decide +kernel

theorem selectedBound3404 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3405 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,46213,46261,41003,8329,46260,323712,16385,16401,22561,74794,61617,189,20480,119966,46773]

theorem envBound3405 : H12AffineFastState.Bounded env3405 := by
  intro p hp
  have h : env3405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3404_3405 : H12AffineEnvironment.transform 22 46261 env3404 = env3405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46261 env3404 == env3405) = true)

def env3406 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,46213,46245,41003,8329,46244,323712,16385,16385,22561,74794,61601,173,20480,119950,46757]

theorem envBound3406 : H12AffineFastState.Bounded env3406 := by
  intro p hp
  have h : env3406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3405_3406 : H12AffineEnvironment.transform 3 0 env3405 = env3406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3405 == env3406) = true)

theorem identity3406 : scanCanonicalize (H12AffineFastState.compose env3406 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3406 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3407 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,46124,46092,41003,8224,46093,323625,16385,16385,22561,74794,61448,4,20480,119847,46604]

theorem envBound3407 : H12AffineFastState.Bounded env3407 := by
  intro p hp
  have h : env3407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3406_3407 : H12AffineEnvironment.transform 6 41 env3406 = env3407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3406 == env3407) = true)

theorem identity3407 : scanCanonicalize (H12AffineFastState.compose env3407 (packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound3407 : packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env3408 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53283,4097,262144,1025,32768,4097,46124,46092,41003,8224,46093,323625,16385,16385,22561,62473,61448,4,20480,1028,46604]

theorem envBound3408 : H12AffineFastState.Bounded env3408 := by
  intro p hp
  have h : env3408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3407_3408 : H12AffineEnvironment.transform 15 53283 env3407 = env3408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env3407 == env3408) = true)

theorem identity3408 : scanCanonicalize (H12AffineFastState.compose env3408 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 22528) := by decide +kernel

theorem selectedBound3408 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env3409 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53283,4097,22528,1025,32768,4097,46124,46092,41003,8224,46093,43049,16385,16385,22561,62473,61448,4,20480,1028,46604]

theorem envBound3409 : H12AffineFastState.Bounded env3409 := by
  intro p hp
  have h : env3409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3408_3409 : H12AffineEnvironment.transform 17 22528 env3408 = env3409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22528 env3408 == env3409) = true)

theorem identity3409 : scanCanonicalize (H12AffineFastState.compose env3409 (packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 7726) := by decide +kernel

theorem selectedBound3409 : packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3410 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,7726,32768,36365,4097,1582,1025,32768,4097,46124,46092,41003,8224,46093,43049,7727,7727,1551,43559,44582,4,3630,1028,46604]

theorem envBound3410 : H12AffineFastState.Bounded env3410 := by
  intro p hp
  have h : env3410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3409_3410 : H12AffineEnvironment.transform 13 7726 env3409 = env3410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7726 env3409 == env3410) = true)

theorem identity3410 : scanCanonicalize (H12AffineFastState.compose env3410 (packedSelected [0,3,4,5,6,7,9,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 1575) := by decide +kernel

theorem selectedBound3410 : packedSelected [0,3,4,5,6,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env3411 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,1575,7726,32768,36365,4097,1582,1025,32768,4097,37387,37419,34316,1543,37418,36366,7727,7727,1551,35840,34817,4,3630,1028,36907]

theorem envBound3411 : H12AffineFastState.Bounded env3411 := by
  intro p hp
  have h : env3411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3410_3411 : H12AffineEnvironment.transform 12 1575 env3410 = env3411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1575 env3410 == env3411) = true)

theorem identity3411 : scanCanonicalize (H12AffineFastState.compose env3411 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 4651) := by decide +kernel

theorem selectedBound3411 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3412 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,1575,7726,4651,7206,4097,1582,1025,4651,4097,32,0,5159,1543,1,7205,7727,7727,1551,7723,6698,4,3630,1028,512]

theorem envBound3412 : H12AffineFastState.Bounded env3412 := by
  intro p hp
  have h : env3412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3411_3412 : H12AffineEnvironment.transform 14 4651 env3411 = env3412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4651 env3411 == env3412) = true)

theorem identity3412 : scanCanonicalize (H12AffineFastState.compose env3412 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3412 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3413 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1038,4096,1575,4640,4651,4136,4097,1582,1025,4651,4097,32,0,5159,1543,1,4139,4641,4641,1551,4645,5668,4,544,1028,512]

theorem envBound3413 : H12AffineFastState.Bounded env3413 := by
  intro p hp
  have h : env3413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3412_3413 : H12AffineEnvironment.transform 10 1038 env3412 = env3413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env3412 == env3413) = true)

theorem identity3413 : scanCanonicalize (H12AffineFastState.compose env3413 (packedSelected [1,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound3413 : packedSelected [1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env3414 : List Nat := [2,4,8,0,32,1,41,5,11,1024,1038,4096,1068,4139,4128,4136,4097,1061,1025,4128,4097,32,0,5159,1036,1,4139,4138,4138,1028,4142,5167,4,43,1028,11]

theorem envBound3414 : H12AffineFastState.Bounded env3414 := by
  intro p hp
  have h : env3414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3413_3414 : H12AffineEnvironment.transform 8 11 env3413 = env3414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env3413 == env3414) = true)

def env3415 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4097,46213,46244,41003,8329,46245,323712,16385,16384,22561,74794,61600,172,20480,119951,46756]

theorem envBound3415 : H12AffineFastState.Bounded env3415 := by
  intro p hp
  have h : env3415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3405_3415 : H12AffineEnvironment.transform 3 1 env3405 = env3415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3405 == env3415) = true)

theorem identity3415 : scanCanonicalize (H12AffineFastState.compose env3415 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound3415 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3416 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,32768,28802,4096,262144,1025,32768,4097,46213,46244,41003,8329,46245,323712,16385,16384,22561,21672,61600,172,20480,41997,46756]

theorem envBound3416 : H12AffineFastState.Bounded env3416 := by
  intro p hp
  have h : env3416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3415_3416 : H12AffineEnvironment.transform 15 28802 env3415 = env3416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env3415 == env3416) = true)

theorem identity3416 : scanCanonicalize (H12AffineFastState.compose env3416 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound3416 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3417 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1196,262144,1025,32768,1197,41001,40968,41003,8329,40969,320556,16385,16384,19597,16388,58380,172,17580,41997,41480]

theorem envBound3417 : H12AffineFastState.Bounded env3417 := by
  intro p hp
  have h : env3417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3416_3417 : H12AffineEnvironment.transform 11 1196 env3416 = env3417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env3416 == env3417) = true)

theorem identity3417 : scanCanonicalize (H12AffineFastState.compose env3417 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8745) := by decide +kernel

theorem selectedBound3417 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3418 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,8745,25646,1196,262144,1025,8745,1197,512,545,514,8329,544,280069,16385,16384,19597,16388,17957,172,17580,1572,33]

theorem envBound3418 : H12AffineFastState.Bounded env3418 := by
  intro p hp
  have h : env3418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3417_3418 : H12AffineEnvironment.transform 14 8745 env3417 = env3418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8745 env3417 == env3418) = true)

theorem identity3418 : scanCanonicalize (H12AffineFastState.compose env3418 (packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound3418 : packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3419 : List Nat := [2,4,8,1,32,0,128,173,32,1024,2048,1196,8192,16384,8201,25646,1196,262144,1025,8201,1197,32,1,34,8329,0,279589,16385,16384,19597,16388,17413,172,17580,1028,33]

theorem envBound3419 : H12AffineFastState.Bounded env3419 := by
  intro p hp
  have h : env3419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3418_3419 : H12AffineEnvironment.transform 8 32 env3418 = env3419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3418 == env3419) = true)

theorem identity3419 : scanCanonicalize (H12AffineFastState.compose env3419 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16395) := by decide +kernel

theorem selectedBound3419 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3420 : List Nat := [2,4,8,1,32,0,128,173,32,1024,2048,1196,8192,16384,8201,25646,1196,16395,1025,8201,1197,32,1,34,8329,0,1070,16385,16384,19597,16388,17413,172,17580,1028,33]

theorem envBound3420 : H12AffineFastState.Bounded env3420 := by
  intro p hp
  have h : env3420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3419_3420 : H12AffineEnvironment.transform 17 16395 env3419 = env3420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16395 env3419 == env3420) = true)

theorem identity3420 : scanCanonicalize (H12AffineFastState.compose env3420 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3420 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3421 : List Nat := [2,4,8,1,32,0,41,4,32,1024,2048,1029,8192,16384,8201,25646,1029,16395,1025,8201,1028,32,1,34,8224,0,1070,16385,16384,19492,16388,17413,5,17413,1028,33]

theorem envBound3421 : H12AffineFastState.Bounded env3421 := by
  intro p hp
  have h : env3421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3420_3421 : H12AffineEnvironment.transform 6 41 env3420 = env3421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3420 == env3421) = true)

theorem identity3421 : scanCanonicalize (H12AffineFastState.compose env3421 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 3081) := by decide +kernel

theorem selectedBound3421 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3422 : List Nat := [2,4,8,1,32,0,41,4,32,1024,2048,1029,3081,16384,3072,18471,1029,16395,1025,3072,1028,32,1,34,3113,0,1070,16385,16384,19492,16388,17413,5,17413,1028,33]

theorem envBound3422 : H12AffineFastState.Bounded env3422 := by
  intro p hp
  have h : env3422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3421_3422 : H12AffineEnvironment.transform 12 3081 env3421 = env3422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3081 env3421 == env3422) = true)

theorem identity3422 : scanCanonicalize (H12AffineFastState.compose env3422 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3422 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3423 : List Nat := [2,4,8,1,32,0,41,4,32,1024,1038,1029,7,16384,14,17449,1029,16395,1025,14,1028,32,1,34,39,0,1070,16385,16384,16426,16388,17413,5,17413,1028,33]

theorem envBound3423 : H12AffineFastState.Bounded env3423 := by
  intro p hp
  have h : env3423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3422_3423 : H12AffineEnvironment.transform 10 1038 env3422 = env3423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env3422 == env3423) = true)

theorem identity3423 : scanCanonicalize (H12AffineFastState.compose env3423 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound3423 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3424 : List Nat := [2,4,8,1,32,0,41,4,32,32,46,37,7,16384,14,16393,37,16395,33,14,36,32,1,34,39,0,14,16385,16384,16426,16388,16421,5,16421,36,33]

theorem envBound3424 : H12AffineFastState.Bounded env3424 := by
  intro p hp
  have h : env3424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3423_3424 : H12AffineEnvironment.transform 9 32 env3423 = env3424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3423 == env3424) = true)

theorem identity3424 : scanCanonicalize (H12AffineFastState.compose env3424 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 11) := by decide +kernel

theorem selectedBound3424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3425 : List Nat := [2,4,8,1,32,0,41,4,32,32,46,37,7,11,14,2,37,0,33,14,36,32,1,34,39,0,14,10,11,33,15,46,5,46,36,33]

theorem envBound3425 : H12AffineFastState.Bounded env3425 := by
  intro p hp
  have h : env3425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3424_3425 : H12AffineEnvironment.transform 13 11 env3424 = env3425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11 env3424 == env3425) = true)

theorem identity3425 : scanCanonicalize (H12AffineFastState.compose env3425 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3425 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3426 : List Nat := [2,4,8,1,10,0,3,4,10,10,4,15,7,11,14,2,15,0,11,14,14,10,1,8,13,0,14,10,11,11,15,4,5,4,14,11]

theorem envBound3426 : H12AffineFastState.Bounded env3426 := by
  intro p hp
  have h : env3426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3425_3426 : H12AffineEnvironment.transform 4 10 env3425 = env3426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3425 == env3426) = true)

theorem identity3426 : scanCanonicalize (H12AffineFastState.compose env3426 (packedSelected [2,11] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3426 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env3427 : List Nat := [2,4,7,1,5,0,3,4,5,5,4,0,7,4,1,2,0,0,4,1,1,5,1,7,2,0,1,5,4,4,0,4,5,4,1,4]

theorem envBound3427 : H12AffineFastState.Bounded env3427 := by
  intro p hp
  have h : env3427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3426_3427 : H12AffineEnvironment.transform 2 7 env3426 = env3427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3426 == env3427) = true)

def leafEnv3427 : List Nat := [2,4,7,1,5,0,3,4,5,5,4,0,7,4,1,2,0,0,4,1,1,5,1,7,0,2,1,0,1,5,4,4,0,4,5,4,4,6,1,4,1,5,0]

def active3427 : List Nat := [0,1]

def tree3427 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3427 : H12WitnessSearch.Good tree3427 := H12GlobalWitnessIndex.good

theorem leafIdentity3427 : H12AffineFastState.composeSystem env3427 rootObs = leafEnv3427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3427 rootObs == leafEnv3427) = true)

theorem terminalChecked3427 : H12PackedTerminal.terminalCheckFast leafEnv3427 active3427 tree3427 = true := by decide +kernel

def env3428 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,46212,8388608,41003,8329,8388609,323712,16385,16400,22561,74794,8406020,188,20480,8478762,8389121]

theorem envBound3428 : H12AffineFastState.Bounded env3428 := by
  intro p hp
  have h : env3428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3403_3428 : H12AffineEnvironment.transform 7 189 env3403 = env3428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3403 == env3428) = true)

theorem identity3428 : scanCanonicalize (H12AffineFastState.compose env3428 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound3428 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3429 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53403,4112,262144,1025,32768,4097,46212,8388608,41003,8329,8388609,323712,16385,16400,22561,62641,8406020,188,20480,8433841,8389121]

theorem envBound3429 : H12AffineFastState.Bounded env3429 := by
  intro p hp
  have h : env3429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3428_3429 : H12AffineEnvironment.transform 15 53403 env3428 = env3429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env3428 == env3429) = true)

def env3430 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,46212,8388608,41003,8329,8388609,323712,16385,16384,22561,62625,8406020,172,20480,8433825,8389121]

theorem envBound3430 : H12AffineFastState.Bounded env3430 := by
  intro p hp
  have h : env3430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3429_3430 : H12AffineEnvironment.transform 3 0 env3429 = env3430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3429 == env3430) = true)

theorem identity3430 : scanCanonicalize (H12AffineFastState.compose env3430 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5124) := by decide +kernel

theorem selectedBound3430 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3431 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,46212,5124,41003,8329,5125,323712,16385,16384,22561,62625,20480,172,20480,42149,5637]

theorem envBound3431 : H12AffineFastState.Bounded env3431 := by
  intro p hp
  have h : env3431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3430_3431 : H12AffineEnvironment.transform 22 5124 env3430 = env3431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5124 env3430 == env3431) = true)

theorem identity3431 : scanCanonicalize (H12AffineFastState.compose env3431 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3431 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3432 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53282,4096,262144,1025,32768,4097,46125,5124,41003,8224,5125,323625,16385,16384,22561,62472,20480,5,20480,41996,5637]

theorem envBound3432 : H12AffineFastState.Bounded env3432 := by
  intro p hp
  have h : env3432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3431_3432 : H12AffineEnvironment.transform 6 41 env3431 = env3432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3431 == env3432) = true)

theorem identity3432 : scanCanonicalize (H12AffineFastState.compose env3432 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound3432 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3433 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53282,4096,43049,1025,32768,4097,46125,5124,41003,8224,5125,22528,16385,16384,22561,62472,20480,5,20480,41996,5637]

theorem envBound3433 : H12AffineFastState.Bounded env3433 := by
  intro p hp
  have h : env3433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3432_3433 : H12AffineEnvironment.transform 17 43049 env3432 = env3433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env3432 == env3433) = true)

theorem identity3433 : scanCanonicalize (H12AffineFastState.compose env3433 (packedSelected [1,2,3,4,5,6,7,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 13357) := by decide +kernel

theorem selectedBound3433 : packedSelected [1,2,3,4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3434 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,13357,25615,4096,7172,1025,13357,4097,0,5124,5126,8224,5125,22528,16385,16384,22561,16421,20480,5,20480,4129,5637]

theorem envBound3434 : H12AffineFastState.Bounded env3434 := by
  intro p hp
  have h : env3434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3433_3434 : H12AffineEnvironment.transform 14 13357 env3433 = env3434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13357 env3433 == env3434) = true)

theorem identity3434 : scanCanonicalize (H12AffineFastState.compose env3434 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4619) := by decide +kernel

theorem selectedBound3434 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env3435 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,4619,13357,13828,4096,7172,1025,13357,4097,0,5124,5126,8224,5125,2571,4618,4619,2602,4654,523,5,523,4129,5637]

theorem envBound3435 : H12AffineFastState.Bounded env3435 := by
  intro p hp
  have h : env3435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3434_3435 : H12AffineEnvironment.transform 13 4619 env3434 = env3435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4619 env3434 == env3435) = true)

theorem identity3435 : scanCanonicalize (H12AffineFastState.compose env3435 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2570) := by decide +kernel

theorem selectedBound3435 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env3436 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,2570,8192,2049,11815,11278,2570,1550,1025,11815,2571,0,3598,3596,8224,3599,2571,2048,2049,2602,2084,523,5,523,2603,3087]

theorem envBound3436 : H12AffineFastState.Bounded env3436 := by
  intro p hp
  have h : env3436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3435_3436 : H12AffineEnvironment.transform 11 2570 env3435 = env3436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2570 env3435 == env3436) = true)

theorem identity3436 : scanCanonicalize (H12AffineFastState.compose env3436 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound3436 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env3437 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,2570,1069,2049,2570,2083,2570,1550,1025,2570,2571,0,3598,3596,1037,3599,2571,2048,2049,2602,2084,523,5,523,2603,3087]

theorem envBound3437 : H12AffineFastState.Bounded env3437 := by
  intro p hp
  have h : env3437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3436_3437 : H12AffineEnvironment.transform 12 1069 env3436 = env3437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env3436 == env3437) = true)

theorem identity3437 : scanCanonicalize (H12AffineFastState.compose env3437 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3437 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3438 : List Nat := [2,4,8,0,32,1,41,4,512,15,2048,2570,34,2049,2570,2083,2570,513,14,2570,2571,0,2561,2563,2,2560,2571,2048,2049,2602,2084,523,5,523,2603,2048]

theorem envBound3438 : H12AffineFastState.Bounded env3438 := by
  intro p hp
  have h : env3438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3437_3438 : H12AffineEnvironment.transform 9 15 env3437 = env3438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3437 == env3438) = true)

theorem identity3438 : scanCanonicalize (H12AffineFastState.compose env3438 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

end H12CloudChart0