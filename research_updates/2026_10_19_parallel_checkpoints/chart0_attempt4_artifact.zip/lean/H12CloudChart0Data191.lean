import H12CloudChart0Data190

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound48368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48369 : List Nat := [2,4,8,16,32,16,8,37,512,517,2048,49,41,529,0,34,512,2049,516,1,32,33,17,2,41,17,2048,513,48,2049,548,33,36,32,529,513]

theorem envBound48369 : H12AffineFastState.Bounded env48369 := by
  intro p hp
  have h : env48369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48368_48369 : H12AffineEnvironment.transform 9 517 env48368 = env48369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env48368 == env48369) = true)

def env48370 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,49,41,33,0,34,48,2049,52,1,32,33,17,2,41,17,2048,49,48,2049,20,33,36,32,33,49]

theorem envBound48370 : H12AffineFastState.Bounded env48370 := by
  intro p hp
  have h : env48370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48369_48370 : H12AffineEnvironment.transform 8 48 env48369 = env48370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env48369 == env48370) = true)

theorem identity48370 : scanCanonicalize (H12AffineFastState.compose env48370 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48370 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48371 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,42,41,33,0,34,43,2049,47,1,32,33,10,2,41,10,2048,42,43,2049,15,33,36,32,33,42]

theorem envBound48371 : H12AffineFastState.Bounded env48371 := by
  intro p hp
  have h : env48371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48370_48371 : H12AffineEnvironment.transform 3 11 env48370 = env48371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48370 == env48371) = true)

def leafEnv48371 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,42,41,33,0,34,43,2049,47,1,32,33,10,2,14,41,1,10,2048,42,43,2049,15,33,36,32,5,34,33,42,1,32,0]

def active48371 : List Nat := [0,1,2,4,10]

def tree48371 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48371 : H12WitnessSearch.Good tree48371 := H12GlobalWitnessIndex.good

theorem leafIdentity48371 : H12AffineFastState.composeSystem env48371 rootObs = leafEnv48371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48371 rootObs == leafEnv48371) = true)

theorem terminalChecked48371 : H12PackedTerminal.terminalCheckFast leafEnv48371 active48371 tree48371 = true := by decide +kernel

def env48372 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,49,41,32,0,34,49,2049,53,1,32,33,17,2,41,17,2048,48,48,2049,21,33,36,32,32,48]

theorem envBound48372 : H12AffineFastState.Bounded env48372 := by
  intro p hp
  have h : env48372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48369_48372 : H12AffineEnvironment.transform 8 49 env48369 = env48372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48369 == env48372) = true)

def env48373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374097,145662401,525568,140903597,27337993,25733063]

theorem envBound48373 : H12AffineFastState.Bounded env48373 := by
  intro p hp
  have h : env48373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46917_48373 : H12AffineEnvironment.transform 29 155254785 env46917 = env48373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env46917 == env48373) = true)

def env48374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265169,145662401,525568,140903597,27337993,25733063]

theorem envBound48374 : H12AffineFastState.Bounded env48374 := by
  intro p hp
  have h : env48374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48373_48374 : H12AffineEnvironment.transform 25 64 env48373 = env48374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env48373 == env48374) = true)

def env48375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound48375 : H12AffineFastState.Bounded env48375 := by
  intro p hp
  have h : env48375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48374_48375 : H12AffineEnvironment.transform 26 30393344 env48374 = env48375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env48374 == env48375) = true)

def env48376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound48376 : H12AffineFastState.Bounded env48376 := by
  intro p hp
  have h : env48376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48375_48376 : H12AffineEnvironment.transform 18 1024 env48375 = env48376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env48375 == env48376) = true)

theorem identity48376 : scanCanonicalize (H12AffineFastState.compose env48376 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2213021) := by decide +kernel

theorem selectedBound48376 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2213021,8328,64,15074461,16400,10507600,8830977,10502284,4235612,256,8388656,8446356,10577754]

theorem envBound48377 : H12AffineFastState.Bounded env48377 := by
  intro p hp
  have h : env48377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48376_48377 : H12AffineEnvironment.transform 23 2213021 env48376 = env48377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2213021 env48376 == env48377) = true)

def env48378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21776,2213021,8328,64,6705549,16400,2097216,431377,2102684,4235612,256,21792,46212,2175562]

theorem envBound48378 : H12AffineFastState.Bounded env48378 := by
  intro p hp
  have h : env48378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48377_48378 : H12AffineEnvironment.transform 22 21776 env48377 = env48378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21776 env48377 == env48378) = true)

def env48379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21776,98645,8328,64,4592709,16400,17800,431377,20564,4235612,256,21792,46212,96130]

theorem envBound48379 : H12AffineFastState.Bounded env48379 := by
  intro p hp
  have h : env48379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48378_48379 : H12AffineEnvironment.transform 20 17864 env48378 = env48379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env48378 == env48379) = true)

def env48380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,16,98645,8328,64,4592709,5392,4232,431377,1364,4235612,256,32,46212,74370]

theorem envBound48380 : H12AffineFastState.Bounded env48380 := by
  intro p hp
  have h : env48380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48379_48380 : H12AffineEnvironment.transform 13 5376 env48379 = env48380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48379 == env48380) = true)

theorem identity48380 : scanCanonicalize (H12AffineFastState.compose env48380 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48380 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,4194304,16,98645,8192,64,4592709,5392,4096,431377,1364,4235612,256,32,46092,74250]

theorem envBound48381 : H12AffineFastState.Bounded env48381 := by
  intro p hp
  have h : env48381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48380_48381 : H12AffineEnvironment.transform 6 8 env48380 = env48381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48380 == env48381) = true)

theorem identity48381 : scanCanonicalize (H12AffineFastState.compose env48381 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48381 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env48382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,4194304,16,41310,8192,64,4592709,5392,4096,431377,1364,4235612,256,32,46092,513]

theorem envBound48382 : H12AffineFastState.Bounded env48382 := by
  intro p hp
  have h : env48382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48381_48382 : H12AffineEnvironment.transform 15 8203 env48381 = env48382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48381 == env48382) = true)

theorem identity48382 : scanCanonicalize (H12AffineFastState.compose env48382 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48382 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env48383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,4194304,16,2,8192,64,4592709,5392,4096,406605,1364,4194304,256,32,5456,513]

theorem envBound48383 : H12AffineFastState.Bounded env48383 := by
  intro p hp
  have h : env48383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48382_48383 : H12AffineEnvironment.transform 14 8540 env48382 = env48383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48382 == env48383) = true)

theorem identity48383 : scanCanonicalize (H12AffineFastState.compose env48383 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound48383 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10361,1024,8541,4160,4194304,16,2,8192,64,4340796,5392,4096,138292,1364,4194304,256,32,5456,513]

theorem envBound48384 : H12AffineFastState.Bounded env48384 := by
  intro p hp
  have h : env48384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48383_48384 : H12AffineEnvironment.transform 17 10361 env48383 = env48384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env48383 == env48384) = true)

theorem identity48384 : scanCanonicalize (H12AffineFastState.compose env48384 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound48384 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env48385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10361,1024,8541,4160,33,16,2,8192,64,146461,5392,4096,138292,1364,33,256,32,5456,513]

theorem envBound48385 : H12AffineFastState.Bounded env48385 := by
  intro p hp
  have h : env48385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48384_48385 : H12AffineEnvironment.transform 21 33 env48384 = env48385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env48384 == env48385) = true)

theorem identity48385 : scanCanonicalize (H12AffineFastState.compose env48385 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound48385 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13389,10361,1024,8541,4160,33,16,2,8192,64,2128,5392,4096,10361,1364,33,256,32,5456,513]

theorem envBound48386 : H12AffineFastState.Bounded env48386 := by
  intro p hp
  have h : env48386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48385_48386 : H12AffineEnvironment.transform 16 13389 env48385 = env48386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env48385 == env48386) = true)

theorem identity48386 : scanCanonicalize (H12AffineFastState.compose env48386 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48386 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48387 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8203,13341,10281,1024,8461,4112,33,16,2,8192,16,2048,5392,4096,10281,1284,33,256,32,5376,513]

theorem envBound48387 : H12AffineFastState.Bounded env48387 := by
  intro p hp
  have h : env48387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48386_48387 : H12AffineEnvironment.transform 5 16 env48386 = env48387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48386 == env48387) = true)

theorem identity48387 : scanCanonicalize (H12AffineFastState.compose env48387 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48387 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48388 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1024,0,4112,33,16,2,269,16,2048,5392,4096,2340,1284,33,256,32,5376,513]

theorem envBound48388 : H12AffineFastState.Bounded env48388 := by
  intro p hp
  have h : env48388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48387_48388 : H12AffineEnvironment.transform 12 269 env48387 = env48388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48387 == env48388) = true)

theorem identity48388 : scanCanonicalize (H12AffineFastState.compose env48388 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48389 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5172,2048,1024,0,4112,33,16,2,41,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound48389 : H12AffineFastState.Bounded env48389 := by
  intro p hp
  have h : env48389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48388_48389 : H12AffineEnvironment.transform 7 36 env48388 = env48389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48388 == env48389) = true)

def env48390 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,1,34,1028,2048,1024,0,32,33,16,2,41,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound48390 : H12AffineFastState.Bounded env48390 := by
  intro p hp
  have h : env48390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48389_48390 : H12AffineEnvironment.transform 11 48 env48389 = env48390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48389 == env48390) = true)

theorem identity48390 : scanCanonicalize (H12AffineFastState.compose env48390 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound48390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48391 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,48,41,1044,1,34,1028,1077,1024,0,32,33,16,2,41,16,1077,1028,48,1077,1056,33,36,32,1044,513]

theorem envBound48391 : H12AffineFastState.Bounded env48391 := by
  intro p hp
  have h : env48391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48390_48391 : H12AffineEnvironment.transform 10 1077 env48390 = env48391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env48390 == env48391) = true)

def env48392 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,41,32,1,34,48,1,52,0,32,33,16,2,41,16,1,48,48,1,20,33,36,32,32,513]

theorem envBound48392 : H12AffineFastState.Bounded env48392 := by
  intro p hp
  have h : env48392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48391_48392 : H12AffineEnvironment.transform 9 52 env48391 = env48392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48391 == env48392) = true)

def leafEnv48392 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,41,32,1,34,48,1,52,0,32,33,16,2,20,41,1,16,1,48,48,1,20,33,36,32,4,34,32,513,1,32,0]

def active48392 : List Nat := [0,1,2,3,4,8]

def tree48392 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48392 : H12WitnessSearch.Good tree48392 := H12GlobalWitnessIndex.good

theorem leafIdentity48392 : H12AffineFastState.composeSystem env48392 rootObs = leafEnv48392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48392 rootObs == leafEnv48392) = true)

theorem terminalChecked48392 : H12PackedTerminal.terminalCheckFast leafEnv48392 active48392 tree48392 = true := by decide +kernel

def env48393 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,41,33,1,34,49,0,53,0,32,33,16,2,41,16,0,49,48,0,21,33,36,32,33,513]

theorem envBound48393 : H12AffineFastState.Bounded env48393 := by
  intro p hp
  have h : env48393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48391_48393 : H12AffineEnvironment.transform 9 53 env48391 = env48393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48391 == env48393) = true)

theorem identity48393 : scanCanonicalize (H12AffineFastState.compose env48393 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48393 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48394 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,48,41,33,1,34,49,0,53,0,32,33,16,2,41,16,0,49,48,0,21,33,36,32,33,42]

theorem envBound48394 : H12AffineFastState.Bounded env48394 := by
  intro p hp
  have h : env48394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48393_48394 : H12AffineEnvironment.transform 8 43 env48393 = env48394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48393 == env48394) = true)

def leafEnv48394 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,48,41,33,1,34,49,0,53,0,32,33,16,2,21,41,1,16,0,49,48,0,21,33,36,32,4,34,33,42,1,32,0]

def active48394 : List Nat := [0,1,2,3,4]

def tree48394 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48394 : H12WitnessSearch.Good tree48394 := H12GlobalWitnessIndex.good

theorem leafIdentity48394 : H12AffineFastState.composeSystem env48394 rootObs = leafEnv48394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48394 rootObs == leafEnv48394) = true)

theorem terminalChecked48394 : H12PackedTerminal.terminalCheckFast leafEnv48394 active48394 tree48394 = true := by decide +kernel

def env48395 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,1,34,1029,2048,1024,0,33,33,16,2,41,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound48395 : H12AffineFastState.Bounded env48395 := by
  intro p hp
  have h : env48395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48389_48395 : H12AffineEnvironment.transform 11 49 env48389 = env48395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48389 == env48395) = true)

theorem identity48395 : scanCanonicalize (H12AffineFastState.compose env48395 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48396 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,49,41,1045,1,34,1029,0,1024,0,33,33,16,2,41,16,0,1029,49,0,1056,33,36,32,1045,513]

theorem envBound48396 : H12AffineFastState.Bounded env48396 := by
  intro p hp
  have h : env48396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48395_48396 : H12AffineEnvironment.transform 10 0 env48395 = env48396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48395 == env48396) = true)

def env48397 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,41,33,1,34,49,0,52,0,33,33,16,2,41,16,0,49,49,0,20,33,36,32,33,513]

theorem envBound48397 : H12AffineFastState.Bounded env48397 := by
  intro p hp
  have h : env48397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48396_48397 : H12AffineEnvironment.transform 9 52 env48396 = env48397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48396 == env48397) = true)

def leafEnv48397 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,41,33,1,34,49,0,52,0,33,33,16,2,20,41,1,16,0,49,49,0,20,33,36,32,4,34,33,513,1,33,0]

def active48397 : List Nat := [0,1,2,3,4,8]

def tree48397 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48397 : H12WitnessSearch.Good tree48397 := H12GlobalWitnessIndex.good

theorem leafIdentity48397 : H12AffineFastState.composeSystem env48397 rootObs = leafEnv48397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48397 rootObs == leafEnv48397) = true)

theorem terminalChecked48397 : H12PackedTerminal.terminalCheckFast leafEnv48397 active48397 tree48397 = true := by decide +kernel

def env48398 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,49,41,32,1,34,48,0,53,0,33,33,16,2,41,16,0,48,49,0,21,33,36,32,32,513]

theorem envBound48398 : H12AffineFastState.Bounded env48398 := by
  intro p hp
  have h : env48398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48396_48398 : H12AffineEnvironment.transform 9 53 env48396 = env48398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48396 == env48398) = true)

theorem identity48398 : scanCanonicalize (H12AffineFastState.compose env48398 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48399 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,49,41,32,1,34,48,0,53,0,33,33,16,2,41,16,0,48,49,0,21,33,36,32,32,42]

theorem envBound48399 : H12AffineFastState.Bounded env48399 := by
  intro p hp
  have h : env48399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48398_48399 : H12AffineEnvironment.transform 8 43 env48398 = env48399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48398 == env48399) = true)

def leafEnv48399 : List Nat := [2,4,8,16,32,16,8,36,43,53,0,49,41,32,1,34,48,0,53,0,33,33,16,2,21,41,1,16,0,48,49,0,21,33,36,32,4,34,32,42,1,33,0]

def active48399 : List Nat := [0,1,2,3,4]

def tree48399 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48399 : H12WitnessSearch.Good tree48399 := H12GlobalWitnessIndex.good

theorem leafIdentity48399 : H12AffineFastState.composeSystem env48399 rootObs = leafEnv48399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48399 rootObs == leafEnv48399) = true)

theorem terminalChecked48399 : H12PackedTerminal.terminalCheckFast leafEnv48399 active48399 tree48399 = true := by decide +kernel

def env48400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,17,98645,8328,64,4592709,5393,4233,431377,1365,4235612,256,33,46212,74371]

theorem envBound48400 : H12AffineFastState.Bounded env48400 := by
  intro p hp
  have h : env48400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48379_48400 : H12AffineEnvironment.transform 13 5377 env48379 = env48400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48379 == env48400) = true)

theorem identity48400 : scanCanonicalize (H12AffineFastState.compose env48400 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound48400 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,32,17,98645,8328,64,398437,5393,4233,431377,1365,41340,256,33,46212,74371]

theorem envBound48401 : H12AffineFastState.Bounded env48401 := by
  intro p hp
  have h : env48401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48400_48401 : H12AffineEnvironment.transform 21 32 env48400 = env48401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env48400 == env48401) = true)

def env48402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,17,98645,8192,64,398437,5393,4097,431377,1365,41340,256,33,46092,74251]

theorem envBound48402 : H12AffineFastState.Bounded env48402 := by
  intro p hp
  have h : env48402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48401_48402 : H12AffineEnvironment.transform 6 8 env48401 = env48402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48401 == env48402) = true)

theorem identity48402 : scanCanonicalize (H12AffineFastState.compose env48402 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound48402 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,4161,32,17,98645,8192,64,146508,5393,4097,179512,1365,41340,256,33,46092,74251]

theorem envBound48403 : H12AffineFastState.Bounded env48403 := by
  intro p hp
  have h : env48403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48402_48403 : H12AffineEnvironment.transform 17 10281 env48402 = env48403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48402 == env48403) = true)

def env48404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98645,8193,64,398437,5393,4096,431377,1365,41340,256,33,46093,74250]

theorem envBound48404 : H12AffineFastState.Bounded env48404 := by
  intro p hp
  have h : env48404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48401_48404 : H12AffineEnvironment.transform 6 9 env48401 = env48404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48401 == env48404) = true)

theorem identity48404 : scanCanonicalize (H12AffineFastState.compose env48404 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound48404 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1024,32769,4160,32,17,98645,8193,64,171281,5393,4096,138341,1365,41340,256,33,46093,74250]

theorem envBound48405 : H12AffineFastState.Bounded env48405 := by
  intro p hp
  have h : env48405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48404_48405 : H12AffineEnvironment.transform 17 35188 env48404 = env48405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env48404 == env48405) = true)

theorem identity48405 : scanCanonicalize (H12AffineFastState.compose env48405 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48405 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,65536,131072,2420,1024,1,4160,32,17,65877,8193,64,138513,5393,4096,138341,1365,8572,256,33,13325,74250]

theorem envBound48406 : H12AffineFastState.Bounded env48406 := by
  intro p hp
  have h : env48406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48405_48406 : H12AffineEnvironment.transform 14 0 env48405 = env48406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48405 == env48406) = true)

theorem identity48406 : scanCanonicalize (H12AffineFastState.compose env48406 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound48406 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env48407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,65536,5393,2420,1024,1,4160,32,17,65877,8193,64,2048,5393,4096,2420,1365,8572,256,33,13325,74250]

theorem envBound48407 : H12AffineFastState.Bounded env48407 := by
  intro p hp
  have h : env48407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48406_48407 : H12AffineEnvironment.transform 16 5393 env48406 = env48407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env48406 == env48407) = true)

theorem identity48407 : scanCanonicalize (H12AffineFastState.compose env48407 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48407 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,8203,5393,2420,1024,1,4160,32,17,8542,8193,64,2048,5393,4096,2420,1365,8572,256,33,13325,513]

theorem envBound48408 : H12AffineFastState.Bounded env48408 := by
  intro p hp
  have h : env48408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48407_48408 : H12AffineEnvironment.transform 15 8203 env48407 = env48408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48407 == env48408) = true)

theorem identity48408 : scanCanonicalize (H12AffineFastState.compose env48408 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound48408 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48409 : List Nat := [2,4,8,16,32,64,9,256,512,612,2048,4096,8192,4965,0,8203,4981,2420,612,1,4160,32,17,8542,8193,64,2048,4981,4096,2420,817,8572,256,33,12905,513]

theorem envBound48409 : H12AffineFastState.Bounded env48409 := by
  intro p hp
  have h : env48409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48408_48409 : H12AffineEnvironment.transform 9 612 env48408 = env48409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env48408 == env48409) = true)

def env48410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21776,98644,8328,64,4592708,16400,17801,431377,20565,4235612,256,21792,46212,96131]

theorem envBound48410 : H12AffineFastState.Bounded env48410 := by
  intro p hp
  have h : env48410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48378_48410 : H12AffineEnvironment.transform 20 17865 env48378 = env48410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env48378 == env48410) = true)

def env48411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,16,98644,8328,64,4592708,5392,4233,431377,1365,4235612,256,32,46212,74371]

theorem envBound48411 : H12AffineFastState.Bounded env48411 := by
  intro p hp
  have h : env48411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48410_48411 : H12AffineEnvironment.transform 13 5376 env48410 = env48411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48410 == env48411) = true)

theorem identity48411 : scanCanonicalize (H12AffineFastState.compose env48411 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48411 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4297,4194304,16,73736,8328,64,4592708,5392,4233,406605,1365,4194304,256,32,5592,74371]

theorem envBound48412 : H12AffineFastState.Bounded env48412 := by
  intro p hp
  have h : env48412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48411_48412 : H12AffineEnvironment.transform 14 8540 env48411 = env48412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48411 == env48412) = true)

def env48413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5392,262144,1024,8541,4297,4194304,16,73736,8328,64,4456788,5392,4233,270685,1365,4194304,256,32,5592,74371]

theorem envBound48413 : H12AffineFastState.Bounded env48413 := by
  intro p hp
  have h : env48413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48412_48413 : H12AffineEnvironment.transform 16 5392 env48412 = env48413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48412 == env48413) = true)

theorem identity48413 : scanCanonicalize (H12AffineFastState.compose env48413 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound48413 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5392,262144,1024,8541,4297,4194304,16,138,8328,64,4456788,5392,4233,270685,1365,4194304,256,32,5592,513]

theorem envBound48414 : H12AffineFastState.Bounded env48414 := by
  intro p hp
  have h : env48414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48413_48414 : H12AffineEnvironment.transform 15 8322 env48413 = env48414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env48413 == env48414) = true)

theorem identity48414 : scanCanonicalize (H12AffineFastState.compose env48414 (packedSelected [1,2,3,5,6,7,8,10,12,14,15,19,20,27,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48414 : packedSelected [1,2,3,5,6,7,8,10,12,14,15,19,20,27,38,41] rootPS < 2^1333 := by decide +kernel

def env48415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5392,10280,1024,8541,4297,4194304,16,138,8328,64,4204924,5392,4233,2421,1365,4194304,256,32,5592,513]

theorem envBound48415 : H12AffineFastState.Bounded env48415 := by
  intro p hp
  have h : env48415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48414_48415 : H12AffineEnvironment.transform 17 10280 env48414 = env48415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48414 == env48415) = true)

theorem identity48415 : scanCanonicalize (H12AffineFastState.compose env48415 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound48415 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5392,10280,1024,8541,4297,8200,16,138,8328,64,2420,5392,4233,2421,1365,8200,256,32,5592,513]

theorem envBound48416 : H12AffineFastState.Bounded env48416 := by
  intro p hp
  have h : env48416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48415_48416 : H12AffineEnvironment.transform 21 8200 env48415 = env48416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env48415 == env48416) = true)

theorem identity48416 : scanCanonicalize (H12AffineFastState.compose env48416 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48416 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10280,1024,8541,4160,8200,16,3,8193,64,2420,5392,4096,2421,1365,8200,256,32,5457,513]

theorem envBound48417 : H12AffineFastState.Bounded env48417 := by
  intro p hp
  have h : env48417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48416_48417 : H12AffineEnvironment.transform 6 9 env48416 = env48417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48416 == env48417) = true)

theorem identity48417 : scanCanonicalize (H12AffineFastState.compose env48417 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48417 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48418 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8203,5392,10280,1024,8461,4112,8200,16,3,8193,16,2340,5392,4096,2341,1285,8200,256,32,5377,513]

theorem envBound48418 : H12AffineFastState.Bounded env48418 := by
  intro p hp
  have h : env48418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48417_48418 : H12AffineEnvironment.transform 5 16 env48417 = env48418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48417 == env48418) = true)

theorem identity48418 : scanCanonicalize (H12AffineFastState.compose env48418 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48418 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48419 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,4405,8460,8203,4389,10280,53,8461,4112,8200,16,3,8193,16,2340,4389,4096,2341,304,8200,256,32,4404,513]

theorem envBound48419 : H12AffineFastState.Bounded env48419 := by
  intro p hp
  have h : env48419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48418_48419 : H12AffineEnvironment.transform 9 53 env48418 = env48419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48418 == env48419) = true)

theorem identity48419 : scanCanonicalize (H12AffineFastState.compose env48419 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48419 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48420 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,4113,8232,8203,4097,10280,53,8233,4112,8200,16,3,8193,16,2048,4097,4096,2049,20,8200,36,32,4112,513]

theorem envBound48420 : H12AffineFastState.Bounded env48420 := by
  intro p hp
  have h : env48420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48419_48420 : H12AffineEnvironment.transform 7 36 env48419 = env48420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48419 == env48420) = true)

theorem identity48420 : scanCanonicalize (H12AffineFastState.compose env48420 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound48420 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48421 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,51,4113,27,56,4097,2075,53,26,4112,59,16,3,50,16,2048,4097,4096,2049,20,59,36,32,4112,513]

theorem envBound48421 : H12AffineFastState.Bounded env48421 := by
  intro p hp
  have h : env48421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48420_48421 : H12AffineEnvironment.transform 12 51 env48420 = env48421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env48420 == env48421) = true)

theorem identity48421 : scanCanonicalize (H12AffineFastState.compose env48421 (packedSelected [0,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48421 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env48422 : List Nat := [2,4,8,11,32,11,9,36,512,46,2048,4096,40,4106,0,35,4097,2048,46,1,4107,32,11,3,41,11,2048,4097,4096,2049,15,32,36,32,4107,513]

theorem envBound48422 : H12AffineFastState.Bounded env48422 := by
  intro p hp
  have h : env48422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48421_48422 : H12AffineEnvironment.transform 3 11 env48421 = env48422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48421 == env48422) = true)

theorem identity48422 : scanCanonicalize (H12AffineFastState.compose env48422 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 522) := by decide +kernel

theorem selectedBound48422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48423 : List Nat := [2,4,8,11,32,11,9,36,512,46,2048,522,40,512,0,35,523,2048,46,1,513,32,11,3,41,11,2048,523,522,2049,15,32,36,32,513,513]

theorem envBound48423 : H12AffineFastState.Bounded env48423 := by
  intro p hp
  have h : env48423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48422_48423 : H12AffineEnvironment.transform 11 522 env48422 = env48423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 522 env48422 == env48423) = true)

theorem identity48423 : scanCanonicalize (H12AffineFastState.compose env48423 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48424 : List Nat := [2,4,8,11,32,11,9,36,1,46,2048,11,40,1,0,35,10,2048,46,1,0,32,11,3,41,11,2048,10,11,2049,15,32,36,32,0,0]

theorem envBound48424 : H12AffineFastState.Bounded env48424 := by
  intro p hp
  have h : env48424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48423_48424 : H12AffineEnvironment.transform 8 1 env48423 = env48424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48423 == env48424) = true)

theorem identity48424 : scanCanonicalize (H12AffineFastState.compose env48424 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48425 : List Nat := [2,4,8,11,0,11,9,4,1,14,2048,11,8,1,0,3,10,2048,14,1,0,0,11,3,9,11,2048,10,11,2049,15,0,4,0,0,0]

theorem envBound48425 : H12AffineFastState.Bounded env48425 := by
  intro p hp
  have h : env48425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48424_48425 : H12AffineEnvironment.transform 4 0 env48424 = env48425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48424 == env48425) = true)

theorem identity48425 : scanCanonicalize (H12AffineFastState.compose env48425 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48425 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48426 : List Nat := [2,4,8,11,0,11,9,4,1,14,0,11,8,1,0,3,10,0,14,1,0,0,11,3,9,11,0,10,11,1,15,0,4,0,0,0]

theorem envBound48426 : H12AffineFastState.Bounded env48426 := by
  intro p hp
  have h : env48426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48425_48426 : H12AffineEnvironment.transform 10 0 env48425 = env48426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48425 == env48426) = true)

theorem identity48426 : scanCanonicalize (H12AffineFastState.compose env48426 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48426 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48427 : List Nat := [2,4,3,0,0,0,2,4,1,5,0,0,3,1,0,3,1,0,5,1,0,0,0,3,2,0,0,1,0,1,4,0,4,0,0,0]

theorem envBound48427 : H12AffineFastState.Bounded env48427 := by
  intro p hp
  have h : env48427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48426_48427 : H12AffineEnvironment.transform 2 3 env48426 = env48427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48426 == env48427) = true)

def env48428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5393,262144,1024,8541,4297,4194304,16,73736,8328,64,4456789,5392,4233,270684,1365,4194304,256,32,5592,74371]

theorem envBound48428 : H12AffineFastState.Bounded env48428 := by
  intro p hp
  have h : env48428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48412_48428 : H12AffineEnvironment.transform 16 5393 env48412 = env48428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env48412 == env48428) = true)

def env48429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5393,10400,1024,8541,4297,4194304,16,73736,8328,64,4205045,5392,4233,2556,1365,4194304,256,32,5592,74371]

theorem envBound48429 : H12AffineFastState.Bounded env48429 := by
  intro p hp
  have h : env48429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48428_48429 : H12AffineEnvironment.transform 17 10400 env48428 = env48429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48428 == env48429) = true)

theorem identity48429 : scanCanonicalize (H12AffineFastState.compose env48429 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48429 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10400,1024,8541,4297,4194304,16,2,8328,64,4205045,5392,4233,2556,1365,4194304,256,32,5592,649]

theorem envBound48430 : H12AffineFastState.Bounded env48430 := by
  intro p hp
  have h : env48430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48429_48430 : H12AffineEnvironment.transform 15 8202 env48429 = env48430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48429 == env48430) = true)

theorem identity48430 : scanCanonicalize (H12AffineFastState.compose env48430 (packedSelected [0,7,9,11,14,16,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 8321) := by decide +kernel

theorem selectedBound48430 : packedSelected [0,7,9,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env48431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10400,1024,8541,4297,8321,16,2,8328,64,2420,5392,4233,2556,1365,8321,256,32,5592,649]

theorem envBound48431 : H12AffineFastState.Bounded env48431 := by
  intro p hp
  have h : env48431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48430_48431 : H12AffineEnvironment.transform 21 8321 env48430 = env48431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env48430 == env48431) = true)

theorem identity48431 : scanCanonicalize (H12AffineFastState.compose env48431 (packedSelected [0,2,4,6,7,9,14,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound48431 : packedSelected [0,2,4,6,7,9,14,16,20] rootPS < 2^1333 := by decide +kernel

def env48432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5376,508,170,5393,2048,1024,509,4297,33,16,2,40,64,2420,5392,4233,2556,1365,33,256,32,5592,649]

theorem envBound48432 : H12AffineFastState.Bounded env48432 := by
  intro p hp
  have h : env48432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48431_48432 : H12AffineEnvironment.transform 12 160 env48431 = env48432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env48431 == env48432) = true)

theorem identity48432 : scanCanonicalize (H12AffineFastState.compose env48432 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48432 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,373,35,5393,2048,1024,372,4160,33,16,2,40,64,2420,5392,4096,2421,1365,33,256,32,5457,512]

theorem envBound48433 : H12AffineFastState.Bounded env48433 := by
  intro p hp
  have h : env48433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48432_48433 : H12AffineEnvironment.transform 6 9 env48432 = env48433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48432 == env48433) = true)

theorem identity48433 : scanCanonicalize (H12AffineFastState.compose env48433 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound48433 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48434 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,41,5205,32,35,5188,2048,1024,33,4160,33,16,2,40,64,2081,5189,4096,2080,1024,33,85,32,5124,512]

theorem envBound48434 : H12AffineFastState.Bounded env48434 := by
  intro p hp
  have h : env48434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48433_48434 : H12AffineEnvironment.transform 7 85 env48433 = env48434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env48433 == env48434) = true)

theorem identity48434 : scanCanonicalize (H12AffineFastState.compose env48434 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound48434 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48435 : List Nat := [2,4,8,16,32,64,9,85,512,1024,32,4096,41,5205,32,35,5188,32,1024,33,4160,33,16,2,40,64,1,5189,4096,0,1024,33,85,32,5124,512]

theorem envBound48435 : H12AffineFastState.Bounded env48435 := by
  intro p hp
  have h : env48435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48434_48435 : H12AffineEnvironment.transform 10 32 env48434 = env48435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env48434 == env48435) = true)

theorem identity48435 : scanCanonicalize (H12AffineFastState.compose env48435 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48435 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48436 : List Nat := [2,4,8,16,1,64,9,85,512,1024,1,4096,8,5205,1,2,5188,1,1024,0,4160,0,16,2,9,64,1,5189,4096,0,1024,0,85,1,5124,512]

theorem envBound48436 : H12AffineFastState.Bounded env48436 := by
  intro p hp
  have h : env48436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48435_48436 : H12AffineEnvironment.transform 4 1 env48435 = env48436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48435 == env48436) = true)

theorem identity48436 : scanCanonicalize (H12AffineFastState.compose env48436 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound48436 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48437 : List Nat := [2,4,8,16,1,64,9,85,512,1024,1,1551,8,602,1,2,587,1,1024,0,1615,0,16,2,9,64,1,586,1551,0,1024,0,85,1,523,512]

theorem envBound48437 : H12AffineFastState.Bounded env48437 := by
  intro p hp
  have h : env48437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48436_48437 : H12AffineEnvironment.transform 11 1551 env48436 = env48437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env48436 == env48437) = true)

theorem identity48437 : scanCanonicalize (H12AffineFastState.compose env48437 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound48437 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env48438 : List Nat := [2,4,8,16,1,64,9,85,18,1024,1,1053,8,72,1,2,89,1,1024,0,1117,0,16,2,9,64,1,88,1053,0,1024,0,85,1,25,18]

theorem envBound48438 : H12AffineFastState.Bounded env48438 := by
  intro p hp
  have h : env48438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48437_48438 : H12AffineEnvironment.transform 8 18 env48437 = env48438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env48437 == env48438) = true)

theorem identity48438 : scanCanonicalize (H12AffineFastState.compose env48438 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 92) := by decide +kernel

theorem selectedBound48438 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48439 : List Nat := [2,4,8,16,1,64,9,85,18,92,1,65,8,72,1,2,89,1,92,0,1,0,16,2,9,64,1,88,65,0,92,0,85,1,25,18]

theorem envBound48439 : H12AffineFastState.Bounded env48439 := by
  intro p hp
  have h : env48439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48438_48439 : H12AffineEnvironment.transform 9 92 env48438 = env48439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 92 env48438 == env48439) = true)

theorem identity48439 : scanCanonicalize (H12AffineFastState.compose env48439 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48439 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48440 : List Nat := [2,2,8,16,1,64,9,83,18,90,1,65,8,72,1,2,89,1,90,0,1,0,16,2,9,64,1,88,65,0,90,0,83,1,25,18]

theorem envBound48440 : H12AffineFastState.Bounded env48440 := by
  intro p hp
  have h : env48440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48439_48440 : H12AffineEnvironment.transform 1 2 env48439 = env48440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48439 == env48440) = true)

theorem identity48440 : scanCanonicalize (H12AffineFastState.compose env48440 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound48440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48441 : List Nat := [2,2,8,16,1,9,9,26,18,19,1,8,8,1,1,2,16,1,19,0,1,0,16,2,9,9,1,17,8,0,19,0,26,1,25,18]

theorem envBound48441 : H12AffineFastState.Bounded env48441 := by
  intro p hp
  have h : env48441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48440_48441 : H12AffineEnvironment.transform 5 9 env48440 = env48441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env48440 == env48441) = true)

def env48442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5393,10401,1024,8541,4297,4194304,16,73736,8328,64,4205044,5392,4233,2557,1365,4194304,256,32,5592,74371]

theorem envBound48442 : H12AffineFastState.Bounded env48442 := by
  intro p hp
  have h : env48442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48428_48442 : H12AffineEnvironment.transform 17 10401 env48428 = env48442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48428 == env48442) = true)

theorem identity48442 : scanCanonicalize (H12AffineFastState.compose env48442 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound48442 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5393,10401,1024,8541,4297,4194304,16,138,8328,64,4205044,5392,4233,2557,1365,4194304,256,32,5592,513]

theorem envBound48443 : H12AffineFastState.Bounded env48443 := by
  intro p hp
  have h : env48443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48442_48443 : H12AffineEnvironment.transform 15 8322 env48442 = env48443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env48442 == env48443) = true)

theorem identity48443 : scanCanonicalize (H12AffineFastState.compose env48443 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48443 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env48444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10281,1024,8541,4161,4194304,16,2,8192,64,4204924,5392,4097,2421,1365,4194304,256,32,5456,513]

theorem envBound48444 : H12AffineFastState.Bounded env48444 := by
  intro p hp
  have h : env48444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48443_48444 : H12AffineEnvironment.transform 6 8 env48443 = env48444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48443 == env48444) = true)

theorem identity48444 : scanCanonicalize (H12AffineFastState.compose env48444 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound48444 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10281,1024,8541,4161,33,16,2,8192,64,10589,5392,4097,2421,1365,33,256,32,5456,513]

theorem envBound48445 : H12AffineFastState.Bounded env48445 := by
  intro p hp
  have h : env48445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48444_48445 : H12AffineEnvironment.transform 21 33 env48444 = env48445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env48444 == env48445) = true)

theorem identity48445 : scanCanonicalize (H12AffineFastState.compose env48445 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound48445 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5376,33,375,5393,2388,1024,32,4161,33,16,2,381,64,2080,5392,4097,2421,1365,33,256,32,5456,513]

theorem envBound48446 : H12AffineFastState.Bounded env48446 := by
  intro p hp
  have h : env48446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48445_48446 : H12AffineEnvironment.transform 12 381 env48445 = env48446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env48445 == env48446) = true)

theorem identity48446 : scanCanonicalize (H12AffineFastState.compose env48446 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48446 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env48447 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5376,1,343,5393,2388,1024,0,4161,1,16,2,349,64,2048,5392,4097,2389,1365,1,256,0,5456,513]

theorem envBound48447 : H12AffineFastState.Bounded env48447 := by
  intro p hp
  have h : env48447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48446_48447 : H12AffineEnvironment.transform 4 0 env48446 = env48447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48446 == env48447) = true)

theorem identity48447 : scanCanonicalize (H12AffineFastState.compose env48447 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 837) := by decide +kernel

theorem selectedBound48447 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48448 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,837,349,1605,1,343,1620,2388,1024,0,772,1,16,2,349,64,2048,1621,836,2389,1365,1,256,0,1557,513]

theorem envBound48448 : H12AffineFastState.Bounded env48448 := by
  intro p hp
  have h : env48448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48447_48448 : H12AffineEnvironment.transform 11 837 env48447 = env48448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 837 env48447 == env48448) = true)

theorem identity48448 : scanCanonicalize (H12AffineFastState.compose env48448 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound48448 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48449 : List Nat := [2,4,8,16,0,64,8,256,512,1024,529,837,349,1605,1,343,1620,837,1024,0,772,1,16,2,349,64,529,1621,836,836,1365,1,256,0,1557,513]

theorem envBound48449 : H12AffineFastState.Bounded env48449 := by
  intro p hp
  have h : env48449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48448_48449 : H12AffineEnvironment.transform 10 529 env48448 = env48449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env48448 == env48449) = true)

def env48450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,17,98644,8328,64,4592708,5393,4232,431377,1364,4235612,256,33,46212,74370]

theorem envBound48450 : H12AffineFastState.Bounded env48450 := by
  intro p hp
  have h : env48450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48410_48450 : H12AffineEnvironment.transform 13 5377 env48410 = env48450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48410 == env48450) = true)

theorem identity48450 : scanCanonicalize (H12AffineFastState.compose env48450 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41461) := by decide +kernel

theorem selectedBound48450 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,41461,17,98644,8328,64,439729,5393,4232,431377,1364,169,256,33,46212,74370]

theorem envBound48451 : H12AffineFastState.Bounded env48451 := by
  intro p hp
  have h : env48451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48450_48451 : H12AffineEnvironment.transform 21 41461 env48450 = env48451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41461 env48450 == env48451) = true)

def env48452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,41341,17,98644,8192,64,439609,5393,4096,431377,1364,33,256,33,46092,74250]

theorem envBound48452 : H12AffineFastState.Bounded env48452 := by
  intro p hp
  have h : env48452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48451_48452 : H12AffineEnvironment.transform 6 8 env48451 = env48452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48451 == env48452) = true)

theorem identity48452 : scanCanonicalize (H12AffineFastState.compose env48452 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound48452 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,4160,41341,17,98644,8192,64,171280,5393,4096,179512,1364,33,256,33,46092,74250]

theorem envBound48453 : H12AffineFastState.Bounded env48453 := by
  intro p hp
  have h : env48453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48452_48453 : H12AffineEnvironment.transform 17 10281 env48452 = env48453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48452 == env48453) = true)

theorem identity48453 : scanCanonicalize (H12AffineFastState.compose env48453 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound48453 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103446,10281,1024,32769,4160,41341,17,98644,8192,64,67846,5393,4096,76078,1364,33,256,33,46092,74250]

theorem envBound48454 : H12AffineFastState.Bounded env48454 := by
  intro p hp
  have h : env48454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48453_48454 : H12AffineEnvironment.transform 16 103446 env48453 = env48454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env48453 == env48454) = true)

theorem identity48454 : scanCanonicalize (H12AffineFastState.compose env48454 (packedSelected [0,1,5,7,8,9,12,14,15,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound48454 : packedSelected [0,1,5,7,8,9,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env48455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33030,5392,10281,1024,32769,4160,41341,17,82,8192,64,34816,5393,4096,43048,1364,33,256,33,46092,41740]

theorem envBound48455 : H12AffineFastState.Bounded env48455 := by
  intro p hp
  have h : env48455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48454_48455 : H12AffineEnvironment.transform 15 33030 env48454 = env48455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env48454 == env48455) = true)

theorem identity48455 : scanCanonicalize (H12AffineFastState.compose env48455 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48455 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,32768,33030,5392,2341,1024,32769,4160,32881,17,82,268,64,34816,5393,4096,35108,1364,33,256,33,38144,33280]

theorem envBound48456 : H12AffineFastState.Bounded env48456 := by
  intro p hp
  have h : env48456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48455_48456 : H12AffineEnvironment.transform 12 268 env48455 = env48456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48455 == env48456) = true)

theorem identity48456 : scanCanonicalize (H12AffineFastState.compose env48456 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound48456 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,343,5392,2341,1024,80,4160,32,17,82,268,64,2129,5393,4096,2421,1364,33,256,33,5457,593]

theorem envBound48457 : H12AffineFastState.Bounded env48457 := by
  intro p hp
  have h : env48457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48456_48457 : H12AffineEnvironment.transform 14 81 env48456 = env48457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env48456 == env48457) = true)

theorem identity48457 : scanCanonicalize (H12AffineFastState.compose env48457 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound48457 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48458 : List Nat := [2,4,8,16,32,43,8,256,512,1024,2048,4096,268,5377,58,316,5392,2341,1024,59,4139,32,17,57,268,43,2106,5393,4096,2334,1343,33,256,33,5434,570]

theorem envBound48458 : H12AffineFastState.Bounded env48458 := by
  intro p hp
  have h : env48458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48457_48458 : H12AffineEnvironment.transform 5 43 env48457 = env48458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env48457 == env48458) = true)

theorem identity48458 : scanCanonicalize (H12AffineFastState.compose env48458 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48458 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48459 : List Nat := [2,4,8,16,32,43,8,5,512,1024,2048,4096,9,5124,58,57,5141,2080,1024,59,4139,32,17,57,9,43,2106,5140,4096,2075,1082,33,5,33,5183,570]

theorem envBound48459 : H12AffineFastState.Bounded env48459 := by
  intro p hp
  have h : env48459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48458_48459 : H12AffineEnvironment.transform 7 5 env48458 = env48459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48458 == env48459) = true)

theorem identity48459 : scanCanonicalize (H12AffineFastState.compose env48459 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound48459 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env48460 : List Nat := [2,4,8,16,32,43,8,5,512,1024,1087,4096,9,5124,58,57,5141,1055,1024,59,4139,32,17,57,9,43,1029,5140,4096,1060,1082,33,5,33,5183,570]

theorem envBound48460 : H12AffineFastState.Bounded env48460 := by
  intro p hp
  have h : env48460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48459_48460 : H12AffineEnvironment.transform 10 1087 env48459 = env48460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env48459 == env48460) = true)

theorem identity48460 : scanCanonicalize (H12AffineFastState.compose env48460 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound48460 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env48461 : List Nat := [2,4,8,16,32,43,8,5,512,1024,1087,1060,9,32,58,57,49,1055,1024,59,1039,32,17,57,9,43,1029,48,1060,1060,1082,33,5,33,27,570]

theorem envBound48461 : H12AffineFastState.Bounded env48461 := by
  intro p hp
  have h : env48461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48460_48461 : H12AffineEnvironment.transform 11 1060 env48460 = env48461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env48460 == env48461) = true)

def env48462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,41340,17,98644,8193,64,439608,5393,4097,431377,1364,32,256,33,46093,74251]

theorem envBound48462 : H12AffineFastState.Bounded env48462 := by
  intro p hp
  have h : env48462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48451_48462 : H12AffineEnvironment.transform 6 9 env48451 = env48462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48451 == env48462) = true)

theorem identity48462 : scanCanonicalize (H12AffineFastState.compose env48462 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound48462 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1024,32769,4161,41340,17,98644,8193,64,146508,5393,4097,138341,1364,32,256,33,46093,74251]

theorem envBound48463 : H12AffineFastState.Bounded env48463 := by
  intro p hp
  have h : env48463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48462_48463 : H12AffineEnvironment.transform 17 35188 env48462 = env48463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env48462 == env48463) = true)

theorem identity48463 : scanCanonicalize (H12AffineFastState.compose env48463 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48463 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5392,35188,1024,32769,4161,41340,17,98644,8193,64,10588,5393,4097,2421,1364,32,256,33,46093,74251]

theorem envBound48464 : H12AffineFastState.Bounded env48464 := by
  intro p hp
  have h : env48464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48463_48464 : H12AffineEnvironment.transform 16 5392 env48463 = env48464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48463 == env48464) = true)

theorem identity48464 : scanCanonicalize (H12AffineFastState.compose env48464 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound48464 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,41050,5392,35188,1024,32769,4161,41340,17,8462,8193,64,10588,5393,4097,2421,1364,32,256,33,46093,33361]

theorem envBound48465 : H12AffineFastState.Bounded env48465 := by
  intro p hp
  have h : env48465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48464_48465 : H12AffineEnvironment.transform 15 41050 env48464 = env48465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env48464 == env48465) = true)

theorem identity48465 : scanCanonicalize (H12AffineFastState.compose env48465 (packedSelected [0,4,5,8,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound48465 : packedSelected [0,4,5,8,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env48466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,8203,5392,2341,1024,80,4161,8493,17,8462,8193,64,10588,5393,4097,2421,1364,32,256,33,13404,512]

theorem envBound48466 : H12AffineFastState.Bounded env48466 := by
  intro p hp
  have h : env48466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48465_48466 : H12AffineEnvironment.transform 14 81 env48465 = env48466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env48465 == env48466) = true)

theorem identity48466 : scanCanonicalize (H12AffineFastState.compose env48466 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48466 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env48467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,262,5392,2341,1024,80,4161,32,17,3,268,64,2129,5393,4097,2421,1364,32,256,33,5457,512]

theorem envBound48467 : H12AffineFastState.Bounded env48467 := by
  intro p hp
  have h : env48467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48466_48467 : H12AffineEnvironment.transform 12 269 env48466 = env48467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48466 == env48467) = true)

theorem identity48467 : scanCanonicalize (H12AffineFastState.compose env48467 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 881) := by decide +kernel

theorem selectedBound48467 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48468 : List Nat := [2,4,8,16,32,64,9,256,512,881,2048,4096,269,4720,81,262,4705,2341,881,80,4161,32,17,3,268,64,2129,4704,4097,2421,549,32,256,33,4640,512]

theorem envBound48468 : H12AffineFastState.Bounded env48468 := by
  intro p hp
  have h : env48468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48467_48468 : H12AffineEnvironment.transform 9 881 env48467 = env48468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 881 env48467 == env48468) = true)

theorem identity48468 : scanCanonicalize (H12AffineFastState.compose env48468 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound48468 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48469 : List Nat := [2,4,8,16,32,64,9,256,512,881,2048,2404,269,2836,81,262,2821,2341,881,80,2341,32,17,3,268,64,2129,2820,2405,2421,549,32,256,33,2884,512]

theorem envBound48469 : H12AffineFastState.Bounded env48469 := by
  intro p hp
  have h : env48469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48468_48469 : H12AffineEnvironment.transform 11 2404 env48468 = env48469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env48468 == env48469) = true)

theorem identity48469 : scanCanonicalize (H12AffineFastState.compose env48469 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48469 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48470 : List Nat := [2,4,8,16,1,64,9,256,512,848,2048,2373,269,2836,81,262,2821,2308,848,80,2308,1,17,3,268,64,2129,2820,2372,2388,516,1,256,0,2884,512]

theorem envBound48470 : H12AffineFastState.Bounded env48470 := by
  intro p hp
  have h : env48470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48469_48470 : H12AffineEnvironment.transform 4 1 env48469 = env48470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48469 == env48470) = true)

theorem identity48470 : scanCanonicalize (H12AffineFastState.compose env48470 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound48470 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48471 : List Nat := [2,4,8,16,1,64,9,256,81,257,2048,2373,269,2373,81,262,2388,2308,257,80,2308,1,17,3,268,64,2129,2389,2372,2388,85,1,256,0,2325,81]

theorem envBound48471 : H12AffineFastState.Bounded env48471 := by
  intro p hp
  have h : env48471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48470_48471 : H12AffineEnvironment.transform 8 81 env48470 = env48471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env48470 == env48471) = true)

theorem identity48471 : scanCanonicalize (H12AffineFastState.compose env48471 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound48471 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env48472 : List Nat := [2,4,8,16,1,64,9,84,81,85,2048,2065,89,2065,81,82,2048,2128,85,80,2128,1,17,3,88,64,2129,2049,2064,2048,85,1,84,0,2113,81]

theorem envBound48472 : H12AffineFastState.Bounded env48472 := by
  intro p hp
  have h : env48472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48471_48472 : H12AffineEnvironment.transform 7 84 env48471 = env48472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env48471 == env48472) = true)

theorem identity48472 : scanCanonicalize (H12AffineFastState.compose env48472 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48472 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48473 : List Nat := [2,4,8,16,1,16,9,4,1,5,2048,2065,9,2065,1,2,2048,2048,5,0,2048,1,17,3,8,16,2049,2049,2064,2048,5,1,4,0,2065,1]

theorem envBound48473 : H12AffineFastState.Bounded env48473 := by
  intro p hp
  have h : env48473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48472_48473 : H12AffineEnvironment.transform 5 16 env48472 = env48473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48472 == env48473) = true)

theorem identity48473 : scanCanonicalize (H12AffineFastState.compose env48473 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound48473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48474 : List Nat := [2,4,8,16,1,16,9,4,1,5,17,0,9,0,1,2,17,17,5,0,17,1,17,3,8,16,16,16,1,17,5,1,4,0,0,1]

theorem envBound48474 : H12AffineFastState.Bounded env48474 := by
  intro p hp
  have h : env48474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48473_48474 : H12AffineEnvironment.transform 10 17 env48473 = env48474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env48473 == env48474) = true)

def env48475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21777,2213021,8328,64,6705548,16400,2097217,431376,2102685,4235612,256,21793,46213,2175563]

theorem envBound48475 : H12AffineFastState.Bounded env48475 := by
  intro p hp
  have h : env48475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48377_48475 : H12AffineEnvironment.transform 22 21777 env48377 = env48475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21777 env48377 == env48475) = true)

def env48476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21777,98645,8328,64,4592708,16400,17801,431376,20565,4235612,256,21793,46213,96131]

theorem envBound48476 : H12AffineFastState.Bounded env48476 := by
  intro p hp
  have h : env48476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48475_48476 : H12AffineEnvironment.transform 20 17864 env48475 = env48476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env48475 == env48476) = true)

def env48477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,17,98645,8328,64,4592708,5392,4233,431376,1365,4235612,256,33,46213,74371]

theorem envBound48477 : H12AffineFastState.Bounded env48477 := by
  intro p hp
  have h : env48477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48476_48477 : H12AffineEnvironment.transform 13 5376 env48476 = env48477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48476 == env48477) = true)

theorem identity48477 : scanCanonicalize (H12AffineFastState.compose env48477 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound48477 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,73890,17,98645,8328,64,472294,5392,4233,431376,1365,98814,256,33,46213,74371]

theorem envBound48478 : H12AffineFastState.Bounded env48478 := by
  intro p hp
  have h : env48478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48477_48478 : H12AffineEnvironment.transform 21 73890 env48477 = env48478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env48477 == env48478) = true)

def env48479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,73770,17,98645,8192,64,472174,5392,4097,431376,1365,98678,256,33,46093,74251]

theorem envBound48479 : H12AffineFastState.Bounded env48479 := by
  intro p hp
  have h : env48479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48478_48479 : H12AffineEnvironment.transform 6 8 env48478 = env48479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48478 == env48479) = true)

theorem identity48479 : scanCanonicalize (H12AffineFastState.compose env48479 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound48479 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4160,73770,17,98645,8192,64,203847,5392,4097,179513,1365,98678,256,33,46093,74251]

theorem envBound48480 : H12AffineFastState.Bounded env48480 := by
  intro p hp
  have h : env48480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48479_48480 : H12AffineEnvironment.transform 17 10281 env48479 = env48480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48479 == env48480) = true)

theorem identity48480 : scanCanonicalize (H12AffineFastState.compose env48480 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48480 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env48481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10281,1024,32769,4160,33,17,41310,8192,64,146508,5392,4097,179513,1365,41341,256,33,46093,512]

theorem envBound48481 : H12AffineFastState.Bounded env48481 := by
  intro p hp
  have h : env48481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48480_48481 : H12AffineEnvironment.transform 15 8203 env48480 = env48481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48480 == env48481) = true)

theorem identity48481 : scanCanonicalize (H12AffineFastState.compose env48481 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound48481 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1125,8203,131072,10281,1024,1124,4160,33,17,9531,8192,64,146508,5392,4097,145756,1365,9496,256,33,12392,512]

theorem envBound48482 : H12AffineFastState.Bounded env48482 := by
  intro p hp
  have h : env48482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48481_48482 : H12AffineEnvironment.transform 14 1125 env48481 = env48482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env48481 == env48482) = true)

theorem identity48482 : scanCanonicalize (H12AffineFastState.compose env48482 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 8248) := by decide +kernel

theorem selectedBound48482 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1125,8203,8248,10281,1024,1124,4160,33,17,9531,8192,64,7284,5392,4097,6500,1365,9496,256,33,12392,512]

theorem envBound48483 : H12AffineFastState.Bounded env48483 := by
  intro p hp
  have h : env48483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48482_48483 : H12AffineEnvironment.transform 16 8248 env48482 = env48483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8248 env48482 == env48483) = true)

theorem identity48483 : scanCanonicalize (H12AffineFastState.compose env48483 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound48483 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env48484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,1125,1095,1140,3173,1024,1124,4160,33,17,375,1100,64,7284,5392,4097,6500,1365,340,256,33,5156,512]

theorem envBound48484 : H12AffineFastState.Bounded env48484 := by
  intro p hp
  have h : env48484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48483_48484 : H12AffineEnvironment.transform 12 1100 env48483 = env48484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env48483 == env48484) = true)

theorem identity48484 : scanCanonicalize (H12AffineFastState.compose env48484 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound48484 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,4096,1100,5376,1125,1095,1140,1076,1024,1124,4160,33,17,375,1100,64,5157,5392,4097,4405,1365,340,256,33,5156,512]

theorem envBound48485 : H12AffineFastState.Bounded env48485 := by
  intro p hp
  have h : env48485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48484_48485 : H12AffineEnvironment.transform 10 81 env48484 = env48485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env48484 == env48485) = true)

theorem identity48485 : scanCanonicalize (H12AffineFastState.compose env48485 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound48485 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env48486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1281,1100,1,1125,1095,1140,1076,1024,1124,1345,33,17,375,1100,64,292,17,1280,1076,1365,340,256,33,293,512]

theorem envBound48486 : H12AffineFastState.Bounded env48486 := by
  intro p hp
  have h : env48486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48485_48486 : H12AffineEnvironment.transform 11 1281 env48485 = env48486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env48485 == env48486) = true)

theorem identity48486 : scanCanonicalize (H12AffineFastState.compose env48486 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound48486 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48487 : List Nat := [2,4,8,16,32,64,8,256,512,304,81,49,380,1,341,375,324,260,304,340,113,33,17,375,380,64,292,17,48,260,101,340,256,33,293,512]

theorem envBound48487 : H12AffineFastState.Bounded env48487 := by
  intro p hp
  have h : env48487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48486_48487 : H12AffineEnvironment.transform 9 304 env48486 = env48487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env48486 == env48487) = true)

theorem identity48487 : scanCanonicalize (H12AffineFastState.compose env48487 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound48487 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48488 : List Nat := [2,4,8,16,32,64,8,84,512,100,81,49,40,1,1,35,16,80,100,0,113,33,17,35,40,64,112,17,48,80,101,0,84,33,113,512]

theorem envBound48488 : H12AffineFastState.Bounded env48488 := by
  intro p hp
  have h : env48488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48487_48488 : H12AffineEnvironment.transform 7 84 env48487 = env48488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env48487 == env48488) = true)

theorem identity48488 : scanCanonicalize (H12AffineFastState.compose env48488 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48488 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48489 : List Nat := [2,4,8,16,32,0,8,20,512,36,17,49,40,1,1,35,16,16,36,0,49,33,17,35,40,0,48,17,48,16,37,0,20,33,49,512]

theorem envBound48489 : H12AffineFastState.Bounded env48489 := by
  intro p hp
  have h : env48489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48488_48489 : H12AffineEnvironment.transform 5 0 env48488 = env48489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48488 == env48489) = true)

theorem identity48489 : scanCanonicalize (H12AffineFastState.compose env48489 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48489 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48490 : List Nat := [2,4,8,16,32,0,8,20,0,36,17,49,40,1,1,35,16,16,36,0,49,33,17,35,40,0,48,17,48,16,37,0,20,33,49,0]

theorem envBound48490 : H12AffineFastState.Bounded env48490 := by
  intro p hp
  have h : env48490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48489_48490 : H12AffineEnvironment.transform 8 0 env48489 = env48490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48489 == env48490) = true)

theorem identity48490 : scanCanonicalize (H12AffineFastState.compose env48490 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48491 : List Nat := [2,4,8,16,1,0,8,20,0,5,17,16,9,1,1,2,16,16,5,0,16,0,17,2,9,0,17,17,17,16,4,0,20,0,16,0]

theorem envBound48491 : H12AffineFastState.Bounded env48491 := by
  intro p hp
  have h : env48491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48490_48491 : H12AffineEnvironment.transform 4 1 env48490 = env48491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48490 == env48491) = true)

theorem identity48491 : scanCanonicalize (H12AffineFastState.compose env48491 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound48491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48492 : List Nat := [2,4,8,14,1,0,8,10,0,5,15,14,9,1,1,2,14,14,5,0,14,0,15,2,9,0,15,15,15,14,4,0,10,0,14,0]

theorem envBound48492 : H12AffineFastState.Bounded env48492 := by
  intro p hp
  have h : env48492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48491_48492 : H12AffineEnvironment.transform 3 14 env48491 = env48492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env48491 == env48492) = true)

theorem identity48492 : scanCanonicalize (H12AffineFastState.compose env48492 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound48492 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48493 : List Nat := [2,4,6,0,1,0,6,4,0,5,1,0,7,1,1,2,0,0,5,0,0,0,1,2,7,0,1,1,1,0,4,0,4,0,0,0]

theorem envBound48493 : H12AffineFastState.Bounded env48493 := by
  intro p hp
  have h : env48493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48492_48493 : H12AffineEnvironment.transform 2 6 env48492 = env48493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env48492 == env48493) = true)

def env48494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,73771,17,98645,8193,64,472175,5392,4096,431376,1365,98679,256,33,46092,74250]

theorem envBound48494 : H12AffineFastState.Bounded env48494 := by
  intro p hp
  have h : env48494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48478_48494 : H12AffineEnvironment.transform 6 9 env48478 = env48494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48478 == env48494) = true)

theorem identity48494 : scanCanonicalize (H12AffineFastState.compose env48494 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound48494 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1024,32769,4161,73771,17,98645,8193,64,245019,5392,4096,138340,1365,98679,256,33,46092,74250]

theorem envBound48495 : H12AffineFastState.Bounded env48495 := by
  intro p hp
  have h : env48495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48494_48495 : H12AffineEnvironment.transform 17 35188 env48494 = env48495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env48494 == env48495) = true)

theorem identity48495 : scanCanonicalize (H12AffineFastState.compose env48495 (packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 111947) := by decide +kernel

theorem selectedBound48495 : packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env48496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,111947,35188,1024,32769,4161,73771,17,98645,8193,64,2128,5392,4096,108847,1365,98679,256,33,46092,74250]

theorem envBound48496 : H12AffineFastState.Bounded env48496 := by
  intro p hp
  have h : env48496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48495_48496 : H12AffineEnvironment.transform 16 111947 env48495 = env48496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111947 env48495 == env48496) = true)

theorem identity48496 : scanCanonicalize (H12AffineFastState.compose env48496 (packedSelected [1,2,4,5,6,8,10,11,14,16,19,20,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound48496 : packedSelected [1,2,4,5,6,8,10,11,14,16,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env48497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8574,37941,35188,1024,32769,4161,341,17,41003,8193,64,2128,5392,4096,34897,1365,40969,256,33,46092,884]

theorem envBound48497 : H12AffineFastState.Bounded env48497 := by
  intro p hp
  have h : env48497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48496_48497 : H12AffineEnvironment.transform 15 8574 env48496 = env48497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env48496 == env48497) = true)

theorem identity48497 : scanCanonicalize (H12AffineFastState.compose env48497 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound48497 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env48498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,8574,5221,2340,1024,81,4161,341,17,8315,8193,64,2128,5392,4096,2049,1365,8281,256,33,13404,884]

theorem envBound48498 : H12AffineFastState.Bounded env48498 := by
  intro p hp
  have h : env48498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48497_48498 : H12AffineEnvironment.transform 14 80 env48497 = env48498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env48497 == env48498) = true)

theorem identity48498 : scanCanonicalize (H12AffineFastState.compose env48498 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48498 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48499 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,80,8203,5221,2129,1024,81,4161,32,17,8315,8193,64,2128,5221,4096,2049,1056,8281,117,33,13404,513]

theorem envBound48499 : H12AffineFastState.Bounded env48499 := by
  intro p hp
  have h : env48499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48498_48499 : H12AffineEnvironment.transform 7 117 env48498 = env48499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48498 == env48499) = true)

theorem identity48499 : scanCanonicalize (H12AffineFastState.compose env48499 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 5661) := by decide +kernel

theorem selectedBound48499 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48500 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,5661,5237,80,5654,5221,2129,1024,81,4161,32,17,5734,5660,64,2128,5221,4096,2049,1056,5700,117,33,577,513]

theorem envBound48500 : H12AffineFastState.Bounded env48500 := by
  intro p hp
  have h : env48500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48499_48500 : H12AffineEnvironment.transform 12 5661 env48499 = env48500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5661 env48499 == env48500) = true)

theorem identity48500 : scanCanonicalize (H12AffineFastState.compose env48500 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound48500 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48501 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1588,41,577,80,34,593,2129,1024,81,1653,32,17,82,40,64,2128,593,1588,2049,1056,112,117,33,577,513]

theorem envBound48501 : H12AffineFastState.Bounded env48501 := by
  intro p hp
  have h : env48501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48500_48501 : H12AffineEnvironment.transform 11 1588 env48500 = env48501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env48500 == env48501) = true)

def env48502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,16,98645,8328,64,4592708,5393,4232,431376,1364,4235612,256,32,46213,74370]

theorem envBound48502 : H12AffineFastState.Bounded env48502 := by
  intro p hp
  have h : env48502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48476_48502 : H12AffineEnvironment.transform 13 5377 env48476 = env48502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48476 == env48502) = true)

theorem identity48502 : scanCanonicalize (H12AffineFastState.compose env48502 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48502 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,4194304,16,41310,8328,64,4592708,5393,4232,431376,1364,4235612,256,32,46213,649]

theorem envBound48503 : H12AffineFastState.Bounded env48503 := by
  intro p hp
  have h : env48503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48502_48503 : H12AffineEnvironment.transform 15 8203 env48502 = env48503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48502 == env48503) = true)

theorem identity48503 : scanCanonicalize (H12AffineFastState.compose env48503 (packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS)) = affineNative (2^(21+1) ^^^ 297220) := by decide +kernel

theorem selectedBound48503 : packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env48504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,297220,16,41310,8328,64,171328,5393,4232,431376,1364,272472,256,32,46213,649]

theorem envBound48504 : H12AffineFastState.Bounded env48504 := by
  intro p hp
  have h : env48504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48503_48504 : H12AffineEnvironment.transform 21 297220 env48503 = env48504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297220 env48503 == env48504) = true)

def env48505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,297220,16,41310,8192,64,171328,5393,4096,431376,1364,272472,256,32,46093,513]

theorem envBound48505 : H12AffineFastState.Bounded env48505 := by
  intro p hp
  have h : env48505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48504_48505 : H12AffineEnvironment.transform 6 8 env48504 = env48505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48504 == env48505) = true)

theorem identity48505 : scanCanonicalize (H12AffineFastState.compose env48505 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48505 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env48506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4161,272472,16,2,8192,64,146460,5393,4096,406604,1364,272472,256,32,5457,513]

theorem envBound48506 : H12AffineFastState.Bounded env48506 := by
  intro p hp
  have h : env48506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48505_48506 : H12AffineEnvironment.transform 14 8540 env48505 = env48506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48505 == env48506) = true)

theorem identity48506 : scanCanonicalize (H12AffineFastState.compose env48506 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound48506 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10361,1024,8541,4161,33,16,2,8192,64,146460,5393,4096,138293,1364,33,256,32,5457,513]

theorem envBound48507 : H12AffineFastState.Bounded env48507 := by
  intro p hp
  have h : env48507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48506_48507 : H12AffineEnvironment.transform 17 10361 env48506 = env48507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env48506 == env48507) = true)

theorem identity48507 : scanCanonicalize (H12AffineFastState.compose env48507 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound48507 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13388,10361,1024,8541,4161,33,16,2,8192,64,2128,5393,4096,10361,1364,33,256,32,5457,513]

theorem envBound48508 : H12AffineFastState.Bounded env48508 := by
  intro p hp
  have h : env48508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48507_48508 : H12AffineEnvironment.transform 16 13388 env48507 = env48508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env48507 == env48508) = true)

theorem identity48508 : scanCanonicalize (H12AffineFastState.compose env48508 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48508 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48509 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,13340,10281,1024,8461,4113,33,16,2,8192,16,2048,5393,4096,10281,1284,33,256,32,5377,513]

theorem envBound48509 : H12AffineFastState.Bounded env48509 := by
  intro p hp
  have h : env48509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48508_48509 : H12AffineEnvironment.transform 5 16 env48508 = env48509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48508 == env48509) = true)

theorem identity48509 : scanCanonicalize (H12AffineFastState.compose env48509 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48509 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48510 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1024,0,4113,33,16,2,269,16,2048,5393,4096,2340,1284,33,256,32,5377,513]

theorem envBound48510 : H12AffineFastState.Bounded env48510 := by
  intro p hp
  have h : env48510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48509_48510 : H12AffineEnvironment.transform 12 269 env48509 = env48510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48509 == env48510) = true)

theorem identity48510 : scanCanonicalize (H12AffineFastState.compose env48510 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48510 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48511 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,34,5173,2048,1024,0,4113,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound48511 : H12AffineFastState.Bounded env48511 := by
  intro p hp
  have h : env48511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48510_48511 : H12AffineEnvironment.transform 7 36 env48510 = env48511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48510 == env48511) = true)

def env48512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4160,297220,16,41310,8193,64,171328,5393,4097,431376,1364,272472,256,32,46092,512]

theorem envBound48512 : H12AffineFastState.Bounded env48512 := by
  intro p hp
  have h : env48512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48504_48512 : H12AffineEnvironment.transform 6 9 env48504 = env48512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48504 == env48512) = true)

theorem identity48512 : scanCanonicalize (H12AffineFastState.compose env48512 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 171280) := by decide +kernel

theorem selectedBound48512 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,171280,1024,32769,4160,136212,16,41310,8193,64,171328,5393,4097,2048,1364,177480,256,32,46092,512]

theorem envBound48513 : H12AffineFastState.Bounded env48513 := by
  intro p hp
  have h : env48513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48512_48513 : H12AffineEnvironment.transform 17 171280 env48512 = env48513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171280 env48512 == env48513) = true)

theorem identity48513 : scanCanonicalize (H12AffineFastState.compose env48513 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48513 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146508,1024,8541,4160,136212,16,2,8193,64,146460,5393,4097,2048,1364,136212,256,32,5456,512]

theorem envBound48514 : H12AffineFastState.Bounded env48514 := by
  intro p hp
  have h : env48514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48513_48514 : H12AffineEnvironment.transform 14 8540 env48513 = env48514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48513 == env48514) = true)

theorem identity48514 : scanCanonicalize (H12AffineFastState.compose env48514 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound48514 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5377,112,295,131072,138592,1024,113,4160,136212,16,2,301,64,138544,5393,4097,2048,1364,136212,256,32,5456,512]

theorem envBound48515 : H12AffineFastState.Bounded env48515 := by
  intro p hp
  have h : env48515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48514_48515 : H12AffineEnvironment.transform 12 300 env48514 = env48515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env48514 == env48515) = true)

theorem identity48515 : scanCanonicalize (H12AffineFastState.compose env48515 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound48515 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5377,112,295,5172,2388,1024,113,4160,32,16,2,301,64,2308,5393,4097,2048,1364,32,256,32,5456,512]

theorem envBound48516 : H12AffineFastState.Bounded env48516 := by
  intro p hp
  have h : env48516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48515_48516 : H12AffineEnvironment.transform 16 5172 env48515 = env48516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env48515 == env48516) = true)

theorem identity48516 : scanCanonicalize (H12AffineFastState.compose env48516 (packedSelected [11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound48516 : packedSelected [11,12,15] rootPS < 2^1333 := by decide +kernel

def env48517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,4096,300,5377,112,295,5172,112,1024,113,4160,32,16,2,301,64,32,5393,4097,292,1364,32,256,32,5456,512]

theorem envBound48517 : H12AffineFastState.Bounded env48517 := by
  intro p hp
  have h : env48517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48516_48517 : H12AffineEnvironment.transform 10 292 env48516 = env48517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env48516 == env48517) = true)

theorem identity48517 : scanCanonicalize (H12AffineFastState.compose env48517 (packedSelected [2,4,9,11,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48517 : packedSelected [2,4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env48518 : List Nat := [2,4,8,16,0,64,9,256,512,1024,260,4096,268,5377,80,263,5140,80,1024,81,4160,0,16,2,269,64,0,5393,4097,260,1364,0,256,0,5456,512]

theorem envBound48518 : H12AffineFastState.Bounded env48518 := by
  intro p hp
  have h : env48518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48517_48518 : H12AffineEnvironment.transform 4 0 env48517 = env48518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48517 == env48518) = true)

theorem identity48518 : scanCanonicalize (H12AffineFastState.compose env48518 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48518 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env48519 : List Nat := [2,4,8,16,0,64,9,5,512,1024,1,4096,9,5124,80,2,5140,80,1024,81,4160,0,16,2,8,64,0,5140,4097,1,1105,0,5,0,5205,512]

theorem envBound48519 : H12AffineFastState.Bounded env48519 := by
  intro p hp
  have h : env48519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48518_48519 : H12AffineEnvironment.transform 7 5 env48518 = env48519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48518 == env48519) = true)

theorem identity48519 : scanCanonicalize (H12AffineFastState.compose env48519 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound48519 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48520 : List Nat := [2,4,8,16,0,64,9,5,512,1024,1,0,9,1028,80,2,1044,80,1024,81,64,0,16,2,8,64,0,1044,1,1,1105,0,5,0,1109,512]

theorem envBound48520 : H12AffineFastState.Bounded env48520 := by
  intro p hp
  have h : env48520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48519_48520 : H12AffineEnvironment.transform 11 0 env48519 = env48520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env48519 == env48520) = true)

def env48521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21777,98644,8328,64,4592709,16400,17800,431376,20564,4235612,256,21793,46213,96130]

theorem envBound48521 : H12AffineFastState.Bounded env48521 := by
  intro p hp
  have h : env48521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48475_48521 : H12AffineEnvironment.transform 20 17865 env48475 = env48521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env48475 == env48521) = true)

def env48522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,17,98644,8328,64,4592709,5392,4232,431376,1364,4235612,256,33,46213,74370]

theorem envBound48522 : H12AffineFastState.Bounded env48522 := by
  intro p hp
  have h : env48522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48521_48522 : H12AffineEnvironment.transform 13 5376 env48521 = env48522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48521 == env48522) = true)

theorem identity48522 : scanCanonicalize (H12AffineFastState.compose env48522 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound48522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,98678,17,98644,8328,64,496947,5392,4232,431376,1364,73770,256,33,46213,74370]

theorem envBound48523 : H12AffineFastState.Bounded env48523 := by
  intro p hp
  have h : env48523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48522_48523 : H12AffineEnvironment.transform 21 98678 env48522 = env48523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env48522 == env48523) = true)

def env48524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,98678,17,98644,8192,64,496947,5392,4096,431376,1364,73770,256,33,46093,74250]

theorem envBound48524 : H12AffineFastState.Bounded env48524 := by
  intro p hp
  have h : env48524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48523_48524 : H12AffineEnvironment.transform 6 8 env48523 = env48524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48523 == env48524) = true)

theorem identity48524 : scanCanonicalize (H12AffineFastState.compose env48524 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound48524 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4161,98678,17,98644,8192,64,245018,5392,4096,179513,1364,73770,256,33,46093,74250]

theorem envBound48525 : H12AffineFastState.Bounded env48525 := by
  intro p hp
  have h : env48525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48524_48525 : H12AffineEnvironment.transform 17 10281 env48524 = env48525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48524 == env48525) = true)

theorem identity48525 : scanCanonicalize (H12AffineFastState.compose env48525 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound48525 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5440,10281,1024,32769,4161,98678,17,98644,8192,64,108634,5392,4096,43129,1364,73770,256,33,46093,74250]

theorem envBound48526 : H12AffineFastState.Bounded env48526 := by
  intro p hp
  have h : env48526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48525_48526 : H12AffineEnvironment.transform 16 5440 env48525 = env48526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env48525 == env48526) = true)

theorem identity48526 : scanCanonicalize (H12AffineFastState.compose env48526 (packedSelected [4,9,12,14,15,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48526 : packedSelected [4,9,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env48527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,65536,5440,2421,1024,32769,4161,98678,17,98644,348,64,100614,5392,4096,35109,1364,65910,256,33,38225,66390]

theorem envBound48527 : H12AffineFastState.Bounded env48527 := by
  intro p hp
  have h : env48527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48526_48527 : H12AffineEnvironment.transform 12 348 env48526 = env48527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48526 == env48527) = true)

theorem identity48527 : scanCanonicalize (H12AffineFastState.compose env48527 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound48527 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33110,5440,2421,1024,32769,4161,32,17,2,348,64,2128,5392,4096,35109,1364,32800,256,33,38225,33280]

theorem envBound48528 : H12AffineFastState.Bounded env48528 := by
  intro p hp
  have h : env48528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48527_48528 : H12AffineEnvironment.transform 15 33110 env48527 = env48528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env48527 == env48528) = true)

theorem identity48528 : scanCanonicalize (H12AffineFastState.compose env48528 (packedSelected [0,1,2,3,5,7,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2373) := by decide +kernel

theorem selectedBound48528 : packedSelected [0,1,2,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env48529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2373,348,3141,32768,33110,3077,2421,1024,32769,2308,32,17,2,348,64,2128,3157,2373,35109,1364,32800,256,33,35860,33280]

theorem envBound48529 : H12AffineFastState.Bounded env48529 := by
  intro p hp
  have h : env48529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48528_48529 : H12AffineEnvironment.transform 11 2373 env48528 = env48529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2373 env48528 == env48529) = true)

theorem identity48529 : scanCanonicalize (H12AffineFastState.compose env48529 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound48529 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2373,348,3141,260,82,3077,2421,1024,261,2308,32,17,2,348,64,2128,3157,2373,2081,1364,292,256,33,3344,772]

theorem envBound48530 : H12AffineFastState.Bounded env48530 := by
  intro p hp
  have h : env48530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48529_48530 : H12AffineEnvironment.transform 14 260 env48529 = env48530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env48529 == env48530) = true)

theorem identity48530 : scanCanonicalize (H12AffineFastState.compose env48530 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48530 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env48531 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2325,268,3093,260,2,3077,2341,1024,261,2308,32,17,2,268,16,2048,3077,2325,2081,1284,292,256,33,3344,772]

theorem envBound48531 : H12AffineFastState.Bounded env48531 := by
  intro p hp
  have h : env48531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48530_48531 : H12AffineEnvironment.transform 5 16 env48530 = env48531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48530 == env48531) = true)

theorem identity48531 : scanCanonicalize (H12AffineFastState.compose env48531 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48531 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48532 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2325,268,2081,260,2,2097,2341,52,261,2308,32,17,2,268,16,2048,2097,2325,2081,304,292,256,33,2340,772]

theorem envBound48532 : H12AffineFastState.Bounded env48532 := by
  intro p hp
  have h : env48532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48531_48532 : H12AffineEnvironment.transform 9 52 env48531 = env48532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48531 == env48532) = true)

def env48533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,98678,17,98644,8193,64,496947,5392,4097,431376,1364,73770,256,33,46092,74251]

theorem envBound48533 : H12AffineFastState.Bounded env48533 := by
  intro p hp
  have h : env48533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48523_48533 : H12AffineEnvironment.transform 6 9 env48523 = env48533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48523 == env48533) = true)

theorem identity48533 : scanCanonicalize (H12AffineFastState.compose env48533 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound48533 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1024,32769,4160,98678,17,98644,8193,64,203847,5392,4097,138340,1364,73770,256,33,46092,74251]

theorem envBound48534 : H12AffineFastState.Bounded env48534 := by
  intro p hp
  have h : env48534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48533_48534 : H12AffineEnvironment.transform 17 35188 env48533 = env48534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env48533 == env48534) = true)

theorem identity48534 : scanCanonicalize (H12AffineFastState.compose env48534 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound48534 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,35188,1024,32769,4160,98678,17,98644,8193,64,67926,5392,4097,2421,1364,73770,256,33,46092,74251]

theorem envBound48535 : H12AffineFastState.Bounded env48535 := by
  intro p hp
  have h : env48535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48534_48535 : H12AffineEnvironment.transform 16 5393 env48534 = env48535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env48534 == env48535) = true)

theorem identity48535 : scanCanonicalize (H12AffineFastState.compose env48535 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48535 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5393,35188,1024,32769,4160,41340,17,41310,8193,64,10588,5392,4097,2421,1364,32,256,33,46092,513]

theorem envBound48536 : H12AffineFastState.Bounded env48536 := by
  intro p hp
  have h : env48536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48535_48536 : H12AffineEnvironment.transform 15 8202 env48535 = env48536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48535 == env48536) = true)

theorem identity48536 : scanCanonicalize (H12AffineFastState.compose env48536 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound48536 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1344,8202,5393,3124,1024,1345,4160,9276,17,9246,8193,64,10588,5392,4097,2421,1364,32,256,33,12620,513]

theorem envBound48537 : H12AffineFastState.Bounded env48537 := by
  intro p hp
  have h : env48537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48536_48537 : H12AffineEnvironment.transform 14 1344 env48536 = env48537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env48536 == env48537) = true)

theorem identity48537 : scanCanonicalize (H12AffineFastState.compose env48537 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound48537 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env48538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,5376,1344,2082,5393,3124,1024,1345,4160,3092,17,3126,2089,64,372,5392,4097,2421,1364,32,256,33,6500,513]

theorem envBound48538 : H12AffineFastState.Bounded env48538 := by
  intro p hp
  have h : env48538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48537_48538 : H12AffineEnvironment.transform 12 2088 env48537 = env48538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env48537 == env48538) = true)

theorem identity48538 : scanCanonicalize (H12AffineFastState.compose env48538 (packedSelected [0,3,5,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound48538 : packedSelected [0,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env48539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,2088,2420,1344,2082,2405,3124,1024,1345,3124,3092,17,3126,2089,64,372,2404,3189,2421,1364,32,256,33,1296,513]

theorem envBound48539 : H12AffineFastState.Bounded env48539 := by
  intro p hp
  have h : env48539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48538_48539 : H12AffineEnvironment.transform 11 3188 env48538 = env48539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env48538 == env48539) = true)

theorem identity48539 : scanCanonicalize (H12AffineFastState.compose env48539 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound48539 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,1280,348,0,1344,342,17,1344,1024,1345,1344,1376,17,1346,349,64,372,16,1281,1,1364,32,256,33,1296,513]

theorem envBound48540 : H12AffineFastState.Bounded env48540 := by
  intro p hp
  have h : env48540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48539_48540 : H12AffineEnvironment.transform 10 372 env48539 = env48540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env48539 == env48540) = true)

def env48541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,16,98644,8328,64,4592709,5393,4233,431376,1365,4235612,256,32,46213,74371]

theorem envBound48541 : H12AffineFastState.Bounded env48541 := by
  intro p hp
  have h : env48541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48521_48541 : H12AffineEnvironment.transform 13 5377 env48521 = env48541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48521 == env48541) = true)

theorem identity48541 : scanCanonicalize (H12AffineFastState.compose env48541 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound48541 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,4296,4194304,16,138,8328,64,4592709,5393,4233,431376,1365,4235612,256,32,46213,41821]

theorem envBound48542 : H12AffineFastState.Bounded env48542 := by
  intro p hp
  have h : env48542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48541_48542 : H12AffineEnvironment.transform 15 33246 env48541 = env48542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env48541 == env48542) = true)

def env48543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4160,4194304,16,2,8192,64,4592709,5393,4097,431376,1365,4235612,256,32,46093,41821]

theorem envBound48543 : H12AffineFastState.Bounded env48543 := by
  intro p hp
  have h : env48543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48542_48543 : H12AffineEnvironment.transform 6 8 env48542 = env48543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48542 == env48543) = true)

theorem identity48543 : scanCanonicalize (H12AffineFastState.compose env48543 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48543 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env48544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,35189,1024,32769,4160,4194304,16,2,8192,64,4365616,5393,4097,138341,1365,4235612,256,32,46093,41821]

theorem envBound48544 : H12AffineFastState.Bounded env48544 := by
  intro p hp
  have h : env48544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48543_48544 : H12AffineEnvironment.transform 17 35189 env48543 = env48544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48543 == env48544) = true)

theorem identity48544 : scanCanonicalize (H12AffineFastState.compose env48544 (packedSelected [0,2,6,11,14,16,18,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound48544 : packedSelected [0,2,6,11,14,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env48545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,35189,1024,32769,4160,8572,16,2,8192,64,179276,5393,4097,138341,1365,32800,256,32,46093,41821]

theorem envBound48545 : H12AffineFastState.Bounded env48545 := by
  intro p hp
  have h : env48545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48544_48545 : H12AffineEnvironment.transform 21 8572 env48544 = env48545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env48544 == env48545) = true)

theorem identity48545 : scanCanonicalize (H12AffineFastState.compose env48545 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound48545 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env48546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,5441,35189,1024,32769,4160,8572,16,2,8192,64,43277,5393,4097,2340,1365,32800,256,32,46093,41821]

theorem envBound48546 : H12AffineFastState.Bounded env48546 := by
  intro p hp
  have h : env48546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48545_48546 : H12AffineEnvironment.transform 16 5441 env48545 = env48546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env48545 == env48546) = true)

theorem identity48546 : scanCanonicalize (H12AffineFastState.compose env48546 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48546 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,32768,33110,5441,35189,1024,32769,4160,112,16,2,268,64,34817,5393,4097,2340,1365,32800,256,32,38145,33361]

theorem envBound48547 : H12AffineFastState.Bounded env48547 := by
  intro p hp
  have h : env48547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48546_48547 : H12AffineEnvironment.transform 12 268 env48546 = env48547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48546 == env48547) = true)

theorem identity48547 : scanCanonicalize (H12AffineFastState.compose env48547 (packedSelected [0,1,2,6,7,8,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound48547 : packedSelected [0,1,2,6,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env48548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,263,5441,2340,1024,80,4160,112,16,2,268,64,2128,5393,4097,2340,1365,113,256,32,5456,512]

theorem envBound48548 : H12AffineFastState.Bounded env48548 := by
  intro p hp
  have h : env48548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48547_48548 : H12AffineEnvironment.transform 14 81 env48547 = env48548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env48547 == env48548) = true)

theorem identity48548 : scanCanonicalize (H12AffineFastState.compose env48548 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48548 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48549 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,268,5377,81,263,5441,2308,1024,80,4160,80,16,2,268,64,2128,5393,4097,2308,1365,81,256,0,5456,512]

theorem envBound48549 : H12AffineFastState.Bounded env48549 := by
  intro p hp
  have h : env48549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48548_48549 : H12AffineEnvironment.transform 4 0 env48548 = env48549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48548 == env48549) = true)

theorem identity48549 : scanCanonicalize (H12AffineFastState.compose env48549 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48549 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48550 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,268,4113,81,263,4177,2308,272,80,4160,80,16,2,268,64,2128,4097,4097,2308,69,81,256,0,4160,512]

theorem envBound48550 : H12AffineFastState.Bounded env48550 := by
  intro p hp
  have h : env48550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48549_48550 : H12AffineEnvironment.transform 9 272 env48549 = env48550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48549 == env48550) = true)

theorem identity48550 : scanCanonicalize (H12AffineFastState.compose env48550 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48550 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48551 : List Nat := [2,4,8,16,0,1,8,256,512,272,2048,4096,268,4113,16,263,4112,2308,272,17,4097,17,16,2,268,1,2065,4097,4097,2308,4,16,256,0,4097,512]

theorem envBound48551 : H12AffineFastState.Bounded env48551 := by
  intro p hp
  have h : env48551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48550_48551 : H12AffineEnvironment.transform 5 1 env48550 = env48551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48550 == env48551) = true)

theorem identity48551 : scanCanonicalize (H12AffineFastState.compose env48551 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound48551 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48552 : List Nat := [2,4,8,16,0,1,8,256,512,272,2048,17,268,0,16,263,1,2308,272,17,16,17,16,2,268,1,2065,16,16,2308,4,16,256,0,16,512]

theorem envBound48552 : H12AffineFastState.Bounded env48552 := by
  intro p hp
  have h : env48552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48551_48552 : H12AffineEnvironment.transform 11 17 env48551 = env48552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48551 == env48552) = true)

def env48553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4161,4194304,16,3,8193,64,4592709,5393,4096,431376,1365,4235612,256,32,46092,41821]

theorem envBound48553 : H12AffineFastState.Bounded env48553 := by
  intro p hp
  have h : env48553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48542_48553 : H12AffineEnvironment.transform 6 9 env48542 = env48553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48542 == env48553) = true)

theorem identity48553 : scanCanonicalize (H12AffineFastState.compose env48553 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48553 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,131072,262144,1024,8541,4161,4194304,16,3,8193,64,4592709,5393,4096,406604,1365,4194304,256,32,5456,513]

theorem envBound48554 : H12AffineFastState.Bounded env48554 := by
  intro p hp
  have h : env48554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48553_48554 : H12AffineEnvironment.transform 14 8540 env48553 = env48554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48553 == env48554) = true)

theorem identity48554 : scanCanonicalize (H12AffineFastState.compose env48554 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound48554 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10360,1024,8541,4161,4194304,16,3,8193,64,4340797,5393,4096,138292,1365,4194304,256,32,5456,513]

theorem envBound48555 : H12AffineFastState.Bounded env48555 := by
  intro p hp
  have h : env48555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48554_48555 : H12AffineEnvironment.transform 17 10360 env48554 = env48555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env48554 == env48555) = true)

theorem identity48555 : scanCanonicalize (H12AffineFastState.compose env48555 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound48555 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,4097,10360,1024,8541,4161,4194304,16,3,8193,64,4205628,5393,4096,3125,1365,4194304,256,32,5456,513]

theorem envBound48556 : H12AffineFastState.Bounded env48556 := by
  intro p hp
  have h : env48556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48555_48556 : H12AffineEnvironment.transform 16 4097 env48555 = env48556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env48555 == env48556) = true)

theorem identity48556 : scanCanonicalize (H12AffineFastState.compose env48556 (packedSelected [9,14,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48556 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env48557 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8540,8203,4097,10360,272,8541,4161,4194304,16,3,8193,64,4204844,4097,4096,2341,69,4194304,256,32,4160,513]

theorem envBound48557 : H12AffineFastState.Bounded env48557 := by
  intro p hp
  have h : env48557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48556_48557 : H12AffineEnvironment.transform 9 272 env48556 = env48557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48556 == env48557) = true)

theorem identity48557 : scanCanonicalize (H12AffineFastState.compose env48557 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48557 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48558 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,4113,8460,8203,4097,10280,272,8461,4113,4194304,16,3,8193,16,4204844,4097,4096,2341,21,4194304,256,32,4112,513]

theorem envBound48558 : H12AffineFastState.Bounded env48558 := by
  intro p hp
  have h : env48558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48557_48558 : H12AffineEnvironment.transform 5 16 env48557 = env48558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48557 == env48558) = true)

theorem identity48558 : scanCanonicalize (H12AffineFastState.compose env48558 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48558 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48559 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8192,4113,8233,8203,4097,10280,53,8232,4113,4194304,16,3,8193,16,4204553,4097,4096,2048,21,4194304,37,32,4112,513]

theorem envBound48559 : H12AffineFastState.Bounded env48559 := by
  intro p hp
  have h : env48559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48558_48559 : H12AffineEnvironment.transform 7 37 env48558 = env48559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48558 == env48559) = true)

theorem identity48559 : scanCanonicalize (H12AffineFastState.compose env48559 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound48559 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env48560 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,6200,4113,6161,6195,4097,4112,53,6160,4113,4194304,16,3,6201,16,4198449,4097,4096,2048,21,4194304,37,32,4112,513]

theorem envBound48560 : H12AffineFastState.Bounded env48560 := by
  intro p hp
  have h : env48560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48559_48560 : H12AffineEnvironment.transform 12 6200 env48559 = env48560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env48559 == env48560) = true)

theorem identity48560 : scanCanonicalize (H12AffineFastState.compose env48560 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48560 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env48561 : List Nat := [2,4,8,10,32,10,9,37,512,47,2048,4096,6178,4107,6155,6185,4097,4106,47,6154,4107,4194304,10,3,6179,10,4198443,4097,4096,2048,15,4194304,37,32,4106,513]

theorem envBound48561 : H12AffineFastState.Bounded env48561 := by
  intro p hp
  have h : env48561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48560_48561 : H12AffineEnvironment.transform 3 10 env48560 = env48561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48560 == env48561) = true)

theorem identity48561 : scanCanonicalize (H12AffineFastState.compose env48561 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(21+1) ^^^ 6186) := by decide +kernel

theorem selectedBound48561 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env48562 : List Nat := [2,4,8,10,32,10,9,37,512,47,2048,4096,6178,4107,6155,6185,4097,4106,47,6154,4107,6186,10,3,6179,10,2049,4097,4096,2048,15,6186,37,32,4106,513]

theorem envBound48562 : H12AffineFastState.Bounded env48562 := by
  intro p hp
  have h : env48562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48561_48562 : H12AffineEnvironment.transform 21 6186 env48561 = env48562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 6186 env48561 == env48562) = true)

theorem identity48562 : scanCanonicalize (H12AffineFastState.compose env48562 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound48562 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48563 : List Nat := [2,4,8,10,32,10,9,37,10,47,2048,4096,6178,4107,6155,6185,4097,4106,47,6154,4107,6186,10,3,6179,10,2049,4097,4096,2048,15,6186,37,32,4106,11]

theorem envBound48563 : H12AffineFastState.Bounded env48563 := by
  intro p hp
  have h : env48563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48562_48563 : H12AffineEnvironment.transform 8 10 env48562 = env48563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env48562 == env48563) = true)

def env48564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound48564 : H12AffineFastState.Bounded env48564 := by
  intro p hp
  have h : env48564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48375_48564 : H12AffineEnvironment.transform 18 1025 env48375 = env48564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env48375 == env48564) = true)

theorem identity48564 : scanCanonicalize (H12AffineFastState.compose env48564 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237468) := by decide +kernel

theorem selectedBound48564 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237468,16777216,8328,64,23454749,18973836,160076,2417692,19111949,23160257,257,17031344,16974101,19040218]

theorem envBound48565 : H12AffineFastState.Bounded env48565 := by
  intro p hp
  have h : env48565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48564_48565 : H12AffineEnvironment.transform 22 2237468 env48564 = env48565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237468 env48564 == env48565) = true)

def env48566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237468,243088,8328,64,6705549,2240796,160076,2417692,2102685,6475857,257,21792,46213,2175562]

theorem envBound48566 : H12AffineFastState.Bounded env48566 := by
  intro p hp
  have h : env48566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48565_48566 : H12AffineEnvironment.transform 23 243088 env48565 = env48566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env48565 == env48566) = true)

def env48567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237468,243088,8328,64,2144661,2240796,160076,2417692,2102685,2373705,257,21792,46213,2175562]

theorem envBound48567 : H12AffineFastState.Bounded env48567 := by
  intro p hp
  have h : env48567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48566_48567 : H12AffineEnvironment.transform 21 452632 env48566 = env48567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env48566 == env48567) = true)

def env48568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144476,243088,8328,64,43477,139612,160076,324700,1501,272393,257,21792,46213,74250]

theorem envBound48568 : H12AffineFastState.Bounded env48568 := by
  intro p hp
  have h : env48568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48567_48568 : H12AffineEnvironment.transform 20 4160 env48567 = env48568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48567 == env48568) = true)

theorem identity48568 : scanCanonicalize (H12AffineFastState.compose env48568 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound48568 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4160,392286,73754,41430,8328,64,43477,79130,91402,324700,1501,272393,257,21792,46213,74250]

theorem envBound48569 : H12AffineFastState.Bounded env48569 := by
  intro p hp
  have h : env48569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48568_48569 : H12AffineEnvironment.transform 16 70726 env48568 = env48569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env48568 == env48569) = true)

def env48570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,4160,120062,73754,41430,8328,64,43477,79130,91402,56572,1501,169,257,21792,46213,74250]

theorem envBound48570 : H12AffineFastState.Bounded env48570 := by
  intro p hp
  have h : env48570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48569_48570 : H12AffineEnvironment.transform 17 10400 env48569 = env48570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48569 == env48570) = true)

theorem identity48570 : scanCanonicalize (H12AffineFastState.compose env48570 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound48570 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env48571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49305,10400,1025,32769,4160,33,62661,41430,8328,64,43477,57797,45525,56572,1501,169,257,21792,46213,63189]

theorem envBound48571 : H12AffineFastState.Bounded env48571 := by
  intro p hp
  have h : env48571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48570_48571 : H12AffineEnvironment.transform 15 54495 env48570 = env48571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env48570 == env48571) = true)

theorem identity48571 : scanCanonicalize (H12AffineFastState.compose env48571 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48571 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env48572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,54495,49305,2476,1025,32769,4160,33,54729,32986,388,64,35033,49353,37081,56572,1501,169,257,21792,38281,55257]

theorem envBound48572 : H12AffineFastState.Bounded env48572 := by
  intro p hp
  have h : env48572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48571_48572 : H12AffineEnvironment.transform 12 268 env48571 = env48572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48571 == env48572) = true)

theorem identity48572 : scanCanonicalize (H12AffineFastState.compose env48572 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48572 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env48573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,0,21727,16537,2476,1025,1,4160,33,21961,218,388,64,2265,16585,4313,23804,1501,169,257,21792,5513,22489]

theorem envBound48573 : H12AffineFastState.Bounded env48573 := by
  intro p hp
  have h : env48573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48572_48573 : H12AffineEnvironment.transform 14 0 env48572 = env48573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48572 == env48573) = true)

theorem identity48573 : scanCanonicalize (H12AffineFastState.compose env48573 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48573 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env48574 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,0,21647,16537,2476,1025,1,4112,33,21913,138,388,16,2185,16537,4233,23724,1421,169,257,21792,5513,22409]

theorem envBound48574 : H12AffineFastState.Bounded env48574 := by
  intro p hp
  have h : env48574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48573_48574 : H12AffineEnvironment.transform 5 16 env48573 = env48574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48573 == env48574) = true)

theorem identity48574 : scanCanonicalize (H12AffineFastState.compose env48574 (packedSelected [2,3,4,5,9,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

theorem selectedBound48574 : packedSelected [2,3,4,5,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48575 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3212,268,16384,0,18435,16537,2476,1025,1,3228,33,18709,138,388,16,2185,16537,3077,16416,1421,169,257,18860,2309,19205]

theorem envBound48575 : H12AffineFastState.Bounded env48575 := by
  intro p hp
  have h : env48575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48574_48575 : H12AffineEnvironment.transform 11 3212 env48574 = env48575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env48574 == env48575) = true)

theorem identity48575 : scanCanonicalize (H12AffineFastState.compose env48575 (packedSelected [0,1,3,4,5,6,7,8,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48575 : packedSelected [0,1,3,4,5,6,7,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env48576 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,3212,41,16384,0,18435,16537,2185,1025,1,3228,33,18480,138,161,16,2185,16537,3077,16416,1192,169,36,18569,2080,18976]

theorem envBound48576 : H12AffineFastState.Bounded env48576 := by
  intro p hp
  have h : env48576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48575_48576 : H12AffineEnvironment.transform 7 37 env48575 = env48576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48575 == env48576) = true)

theorem identity48576 : scanCanonicalize (H12AffineFastState.compose env48576 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound48576 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env48577 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,3212,41,2184,0,139,2065,2185,1025,1,3228,33,184,138,161,16,2185,2065,3077,2216,1192,169,36,1,2080,680]

theorem envBound48577 : H12AffineFastState.Bounded env48577 := by
  intro p hp
  have h : env48577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48576_48577 : H12AffineEnvironment.transform 13 2184 env48576 = env48577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env48576 == env48577) = true)

theorem identity48577 : scanCanonicalize (H12AffineFastState.compose env48577 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48577 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48578 : List Nat := [2,4,8,16,1,16,128,4,512,1024,2048,3212,8,2184,0,139,2065,2185,1025,1,3228,0,153,138,128,16,2185,2065,3077,2185,1161,136,5,1,2049,649]

theorem envBound48578 : H12AffineFastState.Bounded env48578 := by
  intro p hp
  have h : env48578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48577_48578 : H12AffineEnvironment.transform 4 1 env48577 = env48578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48577 == env48578) = true)

theorem identity48578 : scanCanonicalize (H12AffineFastState.compose env48578 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48578 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48579 : List Nat := [2,4,8,16,1,16,128,4,512,1024,1,1165,8,137,0,139,16,136,1025,1,1181,0,153,138,128,16,136,16,1028,136,1161,136,5,1,0,649]

theorem envBound48579 : H12AffineFastState.Bounded env48579 := by
  intro p hp
  have h : env48579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48578_48579 : H12AffineEnvironment.transform 10 1 env48578 = env48579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48578 == env48579) = true)

theorem identity48579 : scanCanonicalize (H12AffineFastState.compose env48579 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48579 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48580 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,1029,8,1,0,3,16,0,1025,1,1045,0,17,2,8,16,0,16,1028,0,1025,0,5,1,0,513]

theorem envBound48580 : H12AffineFastState.Bounded env48580 := by
  intro p hp
  have h : env48580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48579_48580 : H12AffineEnvironment.transform 6 8 env48579 = env48580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48579 == env48580) = true)

theorem identity48580 : scanCanonicalize (H12AffineFastState.compose env48580 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound48580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48581 : List Nat := [2,4,8,4,1,4,8,4,512,1024,1,1029,8,1,0,3,4,0,1025,1,1025,0,5,2,8,4,0,4,1028,0,1025,0,5,1,0,513]

theorem envBound48581 : H12AffineFastState.Bounded env48581 := by
  intro p hp
  have h : env48581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48580_48581 : H12AffineEnvironment.transform 3 4 env48580 = env48581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env48580 == env48581) = true)

theorem identity48581 : scanCanonicalize (H12AffineFastState.compose env48581 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48582 : List Nat := [2,4,8,4,1,4,8,4,512,4,1,1,8,1,0,3,4,0,5,1,5,0,5,2,8,4,0,4,0,0,5,0,5,1,0,513]

theorem envBound48582 : H12AffineFastState.Bounded env48582 := by
  intro p hp
  have h : env48582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48581_48582 : H12AffineEnvironment.transform 9 4 env48581 = env48582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48581 == env48582) = true)

theorem identity48582 : scanCanonicalize (H12AffineFastState.compose env48582 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound48582 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48583 : List Nat := [2,4,6,4,1,4,6,4,512,4,1,1,6,1,0,3,4,0,5,1,5,0,5,2,6,4,0,4,0,0,5,0,5,1,0,513]

theorem envBound48583 : H12AffineFastState.Bounded env48583 := by
  intro p hp
  have h : env48583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48582_48583 : H12AffineEnvironment.transform 2 6 env48582 = env48583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env48582 == env48583) = true)

theorem identity48583 : scanCanonicalize (H12AffineFastState.compose env48583 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48583 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48584 : List Nat := [2,4,6,4,1,4,6,4,1,4,1,1,6,1,0,3,4,0,5,1,5,0,5,2,6,4,0,4,0,0,5,0,5,1,0,0]

theorem envBound48584 : H12AffineFastState.Bounded env48584 := by
  intro p hp
  have h : env48584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48583_48584 : H12AffineEnvironment.transform 8 1 env48583 = env48584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48583 == env48584) = true)

theorem identity48584 : scanCanonicalize (H12AffineFastState.compose env48584 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48585 : List Nat := [2,2,0,2,1,2,0,2,1,2,1,1,0,1,0,3,2,0,3,1,3,0,3,2,0,2,0,2,0,0,3,0,3,1,0,0]

theorem envBound48585 : H12AffineFastState.Bounded env48585 := by
  intro p hp
  have h : env48585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48584_48585 : H12AffineEnvironment.transform 1 2 env48584 = env48585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48584 == env48585) = true)

theorem identity48585 : scanCanonicalize (H12AffineFastState.compose env48585 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48585 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env48586 : List Nat := [1,1,0,1,1,1,0,1,1,1,1,1,0,1,0,0,1,0,0,1,0,0,0,1,0,1,0,1,0,0,0,0,0,1,0,0]

theorem envBound48586 : H12AffineFastState.Bounded env48586 := by
  intro p hp
  have h : env48586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48585_48586 : H12AffineEnvironment.transform 0 1 env48585 = env48586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48585 == env48586) = true)

def env48587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,4160,120063,73754,41430,8328,64,43477,79130,91402,56573,1501,168,257,21792,46213,74250]

theorem envBound48587 : H12AffineFastState.Bounded env48587 := by
  intro p hp
  have h : env48587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48569_48587 : H12AffineEnvironment.transform 17 10401 env48569 = env48587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48569 == env48587) = true)

theorem identity48587 : scanCanonicalize (H12AffineFastState.compose env48587 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21976) := by decide +kernel

theorem selectedBound48587 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env48588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21976,65536,70726,10401,1025,21977,4160,65831,73754,29710,8328,64,31757,79130,91402,2341,1501,168,257,21792,24925,74250]

theorem envBound48588 : H12AffineFastState.Bounded env48588 := by
  intro p hp
  have h : env48588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48587_48588 : H12AffineEnvironment.transform 14 21976 env48587 = env48588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21976 env48587 == env48588) = true)

theorem identity48588 : scanCanonicalize (H12AffineFastState.compose env48588 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound48588 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env48589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,16384,21976,65536,70726,2265,1025,21977,4160,65831,65634,21622,240,64,23669,71010,83314,2341,1501,168,257,21792,16677,66162]

theorem envBound48589 : H12AffineFastState.Bounded env48589 := by
  intro p hp
  have h : env48589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48588_48589 : H12AffineEnvironment.transform 12 120 env48588 = env48589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env48588 == env48589) = true)

theorem identity48589 : scanCanonicalize (H12AffineFastState.compose env48589 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound48589 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,16384,21976,115,5173,2265,1025,21977,4160,340,17,21622,240,64,23669,5393,17665,2341,1501,168,257,21792,16677,513]

theorem envBound48590 : H12AffineFastState.Bounded env48590 := by
  intro p hp
  have h : env48590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48589_48590 : H12AffineEnvironment.transform 15 115 env48589 = env48590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env48589 == env48590) = true)

theorem identity48590 : scanCanonicalize (H12AffineFastState.compose env48590 (packedSelected [3,4,5,9,15,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound48590 : packedSelected [3,4,5,9,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env48591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,3173,6589,115,5173,2265,1025,6588,4160,340,17,6163,240,64,4112,5393,2404,2341,1501,168,257,6469,3392,513]

theorem envBound48591 : H12AffineFastState.Bounded env48591 := by
  intro p hp
  have h : env48591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48590_48591 : H12AffineEnvironment.transform 13 3173 env48590 = env48591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env48590 == env48591) = true)

theorem identity48591 : scanCanonicalize (H12AffineFastState.compose env48591 (packedSelected [1,2,6,8,10,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound48591 : packedSelected [1,2,6,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env48592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,309,120,3173,2184,115,1280,2265,1025,2185,373,340,17,2342,240,64,293,1060,2404,2341,1501,168,257,2160,3392,513]

theorem envBound48592 : H12AffineFastState.Bounded env48592 := by
  intro p hp
  have h : env48592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48591_48592 : H12AffineEnvironment.transform 11 309 env48591 = env48592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env48591 == env48592) = true)

theorem identity48592 : scanCanonicalize (H12AffineFastState.compose env48592 (packedSelected [1,8,10,11,12,14,20] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound48592 : packedSelected [1,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env48593 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,309,120,2265,2184,115,444,2265,189,2185,373,340,17,2342,240,64,293,152,2404,2341,353,168,257,2160,2556,513]

theorem envBound48593 : H12AffineFastState.Bounded env48593 := by
  intro p hp
  have h : env48593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48592_48593 : H12AffineEnvironment.transform 9 188 env48592 = env48593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env48592 == env48593) = true)

theorem identity48593 : scanCanonicalize (H12AffineFastState.compose env48593 (packedSelected [2,4,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound48593 : packedSelected [2,4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env48594 : List Nat := [2,4,8,16,32,64,128,256,512,188,373,309,120,428,509,115,444,428,189,508,373,340,17,83,240,64,293,152,17,80,353,168,257,261,137,513]

theorem envBound48594 : H12AffineFastState.Bounded env48594 := by
  intro p hp
  have h : env48594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48593_48594 : H12AffineEnvironment.transform 10 373 env48593 = env48594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env48593 == env48594) = true)

theorem identity48594 : scanCanonicalize (H12AffineFastState.compose env48594 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48594 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env48595 : List Nat := [2,4,8,16,32,64,8,256,512,52,373,309,120,292,373,115,308,292,53,372,373,340,17,83,120,64,293,16,17,80,353,32,257,261,1,513]

theorem envBound48595 : H12AffineFastState.Bounded env48595 := by
  intro p hp
  have h : env48595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48594_48595 : H12AffineEnvironment.transform 6 8 env48594 = env48595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48594 == env48595) = true)

theorem identity48595 : scanCanonicalize (H12AffineFastState.compose env48595 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48595 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48596 : List Nat := [2,4,8,16,32,64,8,36,512,52,81,17,120,0,81,115,16,0,53,80,81,112,17,83,120,64,1,16,17,80,69,32,37,33,1,513]

theorem envBound48596 : H12AffineFastState.Bounded env48596 := by
  intro p hp
  have h : env48596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48595_48596 : H12AffineEnvironment.transform 7 36 env48595 = env48596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48595 == env48596) = true)

theorem identity48596 : scanCanonicalize (H12AffineFastState.compose env48596 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound48596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48597 : List Nat := [2,4,8,16,32,64,8,36,65,52,81,17,120,0,81,115,16,0,53,80,81,112,17,83,120,64,1,16,17,80,69,32,37,33,1,64]

theorem envBound48597 : H12AffineFastState.Bounded env48597 := by
  intro p hp
  have h : env48597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48596_48597 : H12AffineEnvironment.transform 8 65 env48596 = env48597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env48596 == env48597) = true)

theorem identity48597 : scanCanonicalize (H12AffineFastState.compose env48597 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound48597 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env48598 : List Nat := [2,4,8,16,32,59,8,36,58,52,42,17,3,0,42,8,16,0,53,43,42,11,17,40,3,59,1,16,17,43,62,32,37,33,1,59]

theorem envBound48598 : H12AffineFastState.Bounded env48598 := by
  intro p hp
  have h : env48598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48597_48598 : H12AffineEnvironment.transform 5 59 env48597 = env48598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env48597 == env48598) = true)

theorem identity48598 : scanCanonicalize (H12AffineFastState.compose env48598 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48598 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48599 : List Nat := [2,4,8,16,10,17,8,14,16,30,0,17,3,0,0,8,16,0,31,1,0,11,17,2,3,17,1,16,17,1,20,10,15,11,1,17]

theorem envBound48599 : H12AffineFastState.Bounded env48599 := by
  intro p hp
  have h : env48599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48598_48599 : H12AffineEnvironment.transform 4 10 env48598 = env48599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48598 == env48599) = true)

def env48600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144477,243088,8328,64,43476,139613,160076,324701,1500,272392,257,21792,46213,74251]

theorem envBound48600 : H12AffineFastState.Bounded env48600 := by
  intro p hp
  have h : env48600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48567_48600 : H12AffineEnvironment.transform 20 4161 env48567 = env48600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48567 == env48600) = true)

theorem identity48600 : scanCanonicalize (H12AffineFastState.compose env48600 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound48600 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,452632,144477,155982,8328,64,43476,139613,160076,324701,1500,272392,257,21792,46213,63189]

theorem envBound48601 : H12AffineFastState.Bounded env48601 := by
  intro p hp
  have h : env48601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48600_48601 : H12AffineEnvironment.transform 15 54494 env48600 = env48601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env48600 == env48601) = true)

def env48602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146912,1025,32769,4161,54776,144477,155982,8328,64,43476,139613,160076,182717,1500,136680,257,21792,46213,63189]

theorem envBound48602 : H12AffineFastState.Bounded env48602 := by
  intro p hp
  have h : env48602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48601_48602 : H12AffineEnvironment.transform 17 146912 env48601 = env48602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env48601 == env48602) = true)

theorem identity48602 : scanCanonicalize (H12AffineFastState.compose env48602 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57748) := by decide +kernel

theorem selectedBound48602 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,57748,56436,1025,32769,4161,54776,54729,32986,8328,64,43476,49353,37080,10281,1500,62588,257,21792,46213,63189]

theorem envBound48603 : H12AffineFastState.Bounded env48603 := by
  intro p hp
  have h : env48603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48602_48603 : H12AffineEnvironment.transform 16 57748 env48602 = env48603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57748 env48602 == env48603) = true)

theorem identity48603 : scanCanonicalize (H12AffineFastState.compose env48603 (packedSelected [0,9,11,12,15,18,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound48603 : packedSelected [0,9,11,12,15,18,22,27] rootPS < 2^1333 := by decide +kernel

def env48604 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,54278,57676,56436,1025,32769,4161,54560,54545,32770,8272,64,43276,49169,36864,10281,1284,62588,257,21792,46173,62989]

theorem envBound48604 : H12AffineFastState.Bounded env48604 := by
  intro p hp
  have h : env48604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48603_48604 : H12AffineEnvironment.transform 6 88 env48603 = env48604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48603 == env48604) = true)

theorem identity48604 : scanCanonicalize (H12AffineFastState.compose env48604 (packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48604 : packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env48605 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,54278,49217,56436,1025,32769,4161,54560,54545,32770,349,64,34817,49169,36864,2340,1284,54641,257,21792,38224,55040]

theorem envBound48605 : H12AffineFastState.Bounded env48605 := by
  intro p hp
  have h : env48605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48604_48605 : H12AffineEnvironment.transform 12 269 env48604 = env48605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48604 == env48605) = true)

theorem identity48605 : scanCanonicalize (H12AffineFastState.compose env48605 (packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound48605 : packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env48606 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,21761,263,5440,2421,1025,21760,4161,33,16,21763,349,64,23808,5392,17665,2340,1284,112,257,21792,16465,513]

theorem envBound48606 : H12AffineFastState.Bounded env48606 := by
  intro p hp
  have h : env48606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48605_48606 : H12AffineEnvironment.transform 14 21761 env48605 = env48606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env48605 == env48606) = true)

theorem identity48606 : scanCanonicalize (H12AffineFastState.compose env48606 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound48606 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48607 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5457,80,263,5440,2421,1025,81,4161,33,16,82,349,64,2129,5392,4176,2340,1284,112,257,113,5376,513]

theorem envBound48607 : H12AffineFastState.Bounded env48607 := by
  intro p hp
  have h : env48607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48606_48607 : H12AffineEnvironment.transform 13 5457 env48606 = env48607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env48606 == env48607) = true)

theorem identity48607 : scanCanonicalize (H12AffineFastState.compose env48607 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48607 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48608 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,41,5237,80,35,5220,2129,1025,81,4161,33,16,82,121,64,2129,5172,4176,2048,1056,112,37,113,5156,513]

theorem envBound48608 : H12AffineFastState.Bounded env48608 := by
  intro p hp
  have h : env48608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48607_48608 : H12AffineEnvironment.transform 7 36 env48607 = env48608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48607 == env48608) = true)

theorem identity48608 : scanCanonicalize (H12AffineFastState.compose env48608 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48608 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env48609 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5173,2048,1025,0,4112,33,16,3,40,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound48609 : H12AffineFastState.Bounded env48609 := by
  intro p hp
  have h : env48609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48608_48609 : H12AffineEnvironment.transform 5 17 env48608 = env48609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48608 == env48609) = true)

def env48610 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,1,35,1029,2048,1025,0,32,33,16,3,40,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound48610 : H12AffineFastState.Bounded env48610 := by
  intro p hp
  have h : env48610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48609_48610 : H12AffineEnvironment.transform 11 48 env48609 = env48610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48609 == env48610) = true)

theorem identity48610 : scanCanonicalize (H12AffineFastState.compose env48610 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound48610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48611 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,48,41,1044,1,35,1029,529,1025,0,32,33,16,3,40,17,529,1028,49,529,1056,33,37,32,1044,513]

theorem envBound48611 : H12AffineFastState.Bounded env48611 := by
  intro p hp
  have h : env48611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48610_48611 : H12AffineEnvironment.transform 10 529 env48610 = env48611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env48610 == env48611) = true)

def env48612 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,41,32,1,35,49,529,53,0,32,33,16,3,40,17,529,48,49,529,20,33,37,32,32,513]

theorem envBound48612 : H12AffineFastState.Bounded env48612 := by
  intro p hp
  have h : env48612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48611_48612 : H12AffineEnvironment.transform 9 52 env48611 = env48612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48611 == env48612) = true)

def env48613 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,41,33,1,35,48,529,52,0,32,33,16,3,40,17,529,49,49,529,21,33,37,32,33,513]

theorem envBound48613 : H12AffineFastState.Bounded env48613 := by
  intro p hp
  have h : env48613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48611_48613 : H12AffineEnvironment.transform 9 53 env48611 = env48613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48611 == env48613) = true)

theorem identity48613 : scanCanonicalize (H12AffineFastState.compose env48613 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48613 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48614 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,48,41,33,1,35,48,58,52,0,32,33,16,3,40,17,58,49,49,58,21,33,37,32,33,42]

theorem envBound48614 : H12AffineFastState.Bounded env48614 := by
  intro p hp
  have h : env48614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48613_48614 : H12AffineEnvironment.transform 8 43 env48613 = env48614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48613 == env48614) = true)

def leafEnv48614 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,48,41,33,1,35,48,58,52,0,32,33,16,3,20,40,1,17,58,49,49,58,21,33,37,32,5,34,33,42,1,32,0]

def active48614 : List Nat := [0,1,2,3,4]

def tree48614 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48614 : H12WitnessSearch.Good tree48614 := H12GlobalWitnessIndex.good

theorem leafIdentity48614 : H12AffineFastState.composeSystem env48614 rootObs = leafEnv48614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48614 rootObs == leafEnv48614) = true)

theorem terminalChecked48614 : H12PackedTerminal.terminalCheckFast leafEnv48614 active48614 tree48614 = true := by decide +kernel

def env48615 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,1,35,1028,2048,1025,0,33,33,16,3,40,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound48615 : H12AffineFastState.Bounded env48615 := by
  intro p hp
  have h : env48615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48609_48615 : H12AffineEnvironment.transform 11 49 env48609 = env48615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48609 == env48615) = true)

theorem identity48615 : scanCanonicalize (H12AffineFastState.compose env48615 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound48615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48616 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,49,41,1045,1,35,1028,1572,1025,0,33,33,16,3,40,17,1572,1029,48,1572,1056,33,37,32,1045,513]

theorem envBound48616 : H12AffineFastState.Bounded env48616 := by
  intro p hp
  have h : env48616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48615_48616 : H12AffineEnvironment.transform 10 1572 env48615 = env48616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env48615 == env48616) = true)

def env48617 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,41,33,1,35,48,528,53,0,33,33,16,3,40,17,528,49,48,528,20,33,37,32,33,513]

theorem envBound48617 : H12AffineFastState.Bounded env48617 := by
  intro p hp
  have h : env48617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48616_48617 : H12AffineEnvironment.transform 9 52 env48616 = env48617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48616 == env48617) = true)

def env48618 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,41,32,1,35,49,529,52,0,33,33,16,3,40,17,529,48,48,529,21,33,37,32,32,513]

theorem envBound48618 : H12AffineFastState.Bounded env48618 := by
  intro p hp
  have h : env48618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48616_48618 : H12AffineEnvironment.transform 9 53 env48616 = env48618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48616 == env48618) = true)

theorem identity48618 : scanCanonicalize (H12AffineFastState.compose env48618 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48619 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,49,41,32,1,35,49,59,52,0,33,33,16,3,40,17,59,48,48,59,21,33,37,32,32,43]

theorem envBound48619 : H12AffineFastState.Bounded env48619 := by
  intro p hp
  have h : env48619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48618_48619 : H12AffineEnvironment.transform 8 42 env48618 = env48619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48618 == env48619) = true)

def leafEnv48619 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,49,41,32,1,35,49,59,52,0,33,33,16,3,20,40,1,17,59,48,48,59,21,33,37,32,5,34,32,43,1,33,0]

def active48619 : List Nat := [0,1,2,3,4]

def tree48619 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48619 : H12WitnessSearch.Good tree48619 := H12GlobalWitnessIndex.good

theorem leafIdentity48619 : H12AffineFastState.composeSystem env48619 rootObs = leafEnv48619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48619 rootObs == leafEnv48619) = true)

theorem terminalChecked48619 : H12PackedTerminal.terminalCheckFast leafEnv48619 active48619 tree48619 = true := by decide +kernel

def env48620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146913,1025,32769,4161,54777,144477,155982,8328,64,43476,139613,160076,182716,1500,136681,257,21792,46213,63189]

theorem envBound48620 : H12AffineFastState.Bounded env48620 := by
  intro p hp
  have h : env48620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48601_48620 : H12AffineEnvironment.transform 17 146913 env48601 = env48620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env48601 == env48620) = true)

theorem identity48620 : scanCanonicalize (H12AffineFastState.compose env48620 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound48620 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,57629,56572,1025,32769,4161,54777,54592,32851,8328,64,43476,49216,36945,10401,1500,62708,257,21792,46213,63189]

theorem envBound48621 : H12AffineFastState.Bounded env48621 := by
  intro p hp
  have h : env48621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48620_48621 : H12AffineEnvironment.transform 16 57629 env48620 = env48621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env48620 == env48621) = true)

theorem identity48621 : scanCanonicalize (H12AffineFastState.compose env48621 (packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound48621 : packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS < 2^1333 := by decide +kernel

def env48622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,32882,46513,34896,1025,32769,4161,33109,33260,32851,8328,64,43476,38124,36945,10401,1500,41048,257,396,46213,41593]

theorem envBound48622 : H12AffineFastState.Bounded env48622 := by
  intro p hp
  have h : env48622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48621_48622 : H12AffineEnvironment.transform 13 5292 env48621 = env48622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env48621 == env48622) = true)

theorem identity48622 : scanCanonicalize (H12AffineFastState.compose env48622 (packedSelected [0,1,3,4,8,10,12,14,15,16,17,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound48622 : packedSelected [0,1,3,4,8,10,12,14,15,16,17,22,24,27] rootPS < 2^1333 := by decide +kernel

def env48623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,217,171,13672,2185,1025,216,4161,396,309,138,8328,64,10509,5173,4232,10401,1500,8321,257,396,13404,8864]

end H12CloudChart0