import H12CloudChart0Data038

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env9718 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,24771,4605,20903,4961,8693,65,4194304,5005,34,8329,21041,4551,4214984,4215092,18632,504,4211101,4960,16616,21041,1021]

theorem envBound9718 : H12AffineFastState.Bounded env9718 := by
  intro p hp
  have h : env9718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9717_9718 : H12AffineEnvironment.transform 17 20903 env9717 = env9718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20903 env9717 == env9718) = true)

def env9719 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8693,8235,4605,4431,4961,8693,65,4194304,5005,34,8329,4825,4551,4198432,4198876,2080,504,4194677,4960,0,4825,1021]

theorem envBound9719 : H12AffineFastState.Bounded env9719 := by
  intro p hp
  have h : env9719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9718_9719 : H12AffineEnvironment.transform 13 232 env9718 = env9719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env9718 == env9719) = true)

theorem identity9719 : scanCanonicalize (H12AffineFastState.compose env9719 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9719 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9720 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8693,8235,4605,4431,4961,8693,65,477,5005,34,8329,4825,4551,4605,4097,2080,504,168,4960,0,4825,1021]

theorem envBound9720 : H12AffineFastState.Bounded env9720 := by
  intro p hp
  have h : env9720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9719_9720 : H12AffineEnvironment.transform 21 477 env9719 = env9720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9719 == env9720) = true)

theorem identity9720 : scanCanonicalize (H12AffineFastState.compose env9720 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound9720 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env9721 : List Nat := [2,4,8,16,32,64,128,256,512,257,602,4096,8192,232,8693,8235,4605,4431,4961,8693,65,477,5005,34,8329,4825,4551,4605,4097,634,504,168,4960,0,4825,1021]

theorem envBound9721 : H12AffineFastState.Bounded env9721 := by
  intro p hp
  have h : env9721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9720_9721 : H12AffineEnvironment.transform 10 602 env9720 = env9721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env9720 == env9721) = true)

theorem identity9721 : scanCanonicalize (H12AffineFastState.compose env9721 (packedSelected [0,3,5,7,8,12,14,15,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9721 : packedSelected [0,3,5,7,8,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env9722 : List Nat := [2,4,8,16,32,64,128,253,512,252,602,4096,8192,232,8200,8235,4096,4274,4764,8200,65,32,4720,34,8329,4825,4154,4096,4097,634,5,168,4765,0,4825,512]

theorem envBound9722 : H12AffineFastState.Bounded env9722 := by
  intro p hp
  have h : env9722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9721_9722 : H12AffineEnvironment.transform 7 253 env9721 = env9722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9721 == env9722) = true)

theorem identity9722 : scanCanonicalize (H12AffineFastState.compose env9722 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9722 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9723 : List Nat := [2,4,8,16,32,64,41,84,512,85,602,4096,8192,65,8200,8235,4096,4123,4661,8200,65,32,4720,34,8224,4720,4154,4096,4097,634,5,1,4660,0,4720,512]

theorem envBound9723 : H12AffineFastState.Bounded env9723 := by
  intro p hp
  have h : env9723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9722_9723 : H12AffineEnvironment.transform 6 41 env9722 = env9723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9722 == env9723) = true)

theorem identity9723 : scanCanonicalize (H12AffineFastState.compose env9723 (packedSelected [3,4,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound9723 : packedSelected [3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env9724 : List Nat := [2,4,8,16,32,64,41,84,107,85,49,4096,8192,65,8200,8235,4096,4123,4190,8200,65,32,4123,34,8224,4123,4154,4096,4097,17,5,1,4191,0,4123,107]

theorem envBound9724 : H12AffineFastState.Bounded env9724 := by
  intro p hp
  have h : env9724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9723_9724 : H12AffineEnvironment.transform 8 107 env9723 = env9724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env9723 == env9724) = true)

theorem identity9724 : scanCanonicalize (H12AffineFastState.compose env9724 (packedSelected [2,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 4115) := by decide +kernel

theorem selectedBound9724 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env9725 : List Nat := [2,4,8,16,32,64,41,84,107,85,49,4096,4115,65,4123,4152,4096,4123,4190,4123,65,32,4123,34,4147,4123,4154,4096,4097,17,5,1,4191,0,4123,107]

theorem envBound9725 : H12AffineFastState.Bounded env9725 := by
  intro p hp
  have h : env9725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9724_9725 : H12AffineEnvironment.transform 12 4115 env9724 = env9725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4115 env9724 == env9725) = true)

theorem identity9725 : scanCanonicalize (H12AffineFastState.compose env9725 (packedSelected [2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound9725 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env9726 : List Nat := [2,4,8,16,32,64,41,84,107,85,49,80,67,65,75,104,80,75,14,75,65,32,75,34,99,75,106,80,81,17,5,1,15,0,75,107]

theorem envBound9726 : H12AffineFastState.Bounded env9726 := by
  intro p hp
  have h : env9726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9725_9726 : H12AffineEnvironment.transform 11 80 env9725 = env9726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env9725 == env9726) = true)

theorem identity9726 : scanCanonicalize (H12AffineFastState.compose env9726 (packedSelected [0,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9726 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env9727 : List Nat := [2,4,8,16,32,11,41,31,32,30,49,27,8,10,0,35,27,0,14,0,10,32,0,34,40,0,33,27,26,17,5,1,15,0,0,32]

theorem envBound9727 : H12AffineFastState.Bounded env9727 := by
  intro p hp
  have h : env9727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9726_9727 : H12AffineEnvironment.transform 5 11 env9726 = env9727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9726 == env9727) = true)

theorem identity9727 : scanCanonicalize (H12AffineFastState.compose env9727 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound9727 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9728 : List Nat := [2,4,8,16,26,11,19,31,26,30,11,27,8,10,0,25,27,0,14,0,10,26,0,24,18,0,27,27,26,17,5,1,15,0,0,26]

theorem envBound9728 : H12AffineFastState.Bounded env9728 := by
  intro p hp
  have h : env9728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9727_9728 : H12AffineEnvironment.transform 4 26 env9727 = env9728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env9727 == env9728) = true)

theorem identity9728 : scanCanonicalize (H12AffineFastState.compose env9728 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9728 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9729 : List Nat := [2,4,8,10,0,11,9,5,0,4,11,1,8,10,0,3,1,0,14,0,10,0,0,2,8,0,1,1,0,11,5,1,15,0,0,0]

theorem envBound9729 : H12AffineFastState.Bounded env9729 := by
  intro p hp
  have h : env9729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9728_9729 : H12AffineEnvironment.transform 3 10 env9728 = env9729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9728 == env9729) = true)

theorem identity9729 : scanCanonicalize (H12AffineFastState.compose env9729 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9730 : List Nat := [2,4,3,1,0,0,2,5,0,4,0,1,3,1,0,3,1,0,5,0,1,0,0,2,3,0,1,1,0,0,5,1,4,0,0,0]

theorem envBound9730 : H12AffineFastState.Bounded env9730 := by
  intro p hp
  have h : env9730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9729_9730 : H12AffineEnvironment.transform 2 3 env9729 = env9730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9729 == env9730) = true)

def leafEnv9730 : List Nat := [2,4,3,1,0,0,2,5,0,4,0,1,3,1,0,3,1,0,5,0,1,0,0,2,4,3,1,0,1,1,0,0,5,1,4,0,5,2,0,0,1,1,0]

def active9730 : List Nat := [0,1]

def tree9730 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9730 : H12WitnessSearch.Good tree9730 := H12GlobalWitnessIndex.good

theorem leafIdentity9730 : H12AffineFastState.composeSystem env9730 rootObs = leafEnv9730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9730 rootObs == leafEnv9730) = true)

theorem terminalChecked9730 : H12PackedTerminal.terminalCheckFast leafEnv9730 active9730 tree9730 = true := by decide +kernel

def env9731 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8693,8234,4605,4430,4961,8693,65,4194304,5005,34,8329,4824,4551,4198433,4198877,2081,504,4194676,4960,1,4824,1021]

theorem envBound9731 : H12AffineFastState.Bounded env9731 := by
  intro p hp
  have h : env9731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9718_9731 : H12AffineEnvironment.transform 13 233 env9718 = env9731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env9718 == env9731) = true)

theorem identity9731 : scanCanonicalize (H12AffineFastState.compose env9731 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9731 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9732 : List Nat := [2,4,8,16,32,64,128,84,512,85,2048,4096,8192,233,8353,8234,4265,4122,4661,8353,65,4194304,4825,34,8329,4824,4243,4198433,4198537,2081,172,4194336,4660,1,4824,681]

theorem envBound9732 : H12AffineFastState.Bounded env9732 := by
  intro p hp
  have h : env9732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9731_9732 : H12AffineEnvironment.transform 7 84 env9731 = env9732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9731 == env9732) = true)

theorem identity9732 : scanCanonicalize (H12AffineFastState.compose env9732 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound9732 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9733 : List Nat := [2,4,8,16,32,64,128,84,512,85,754,4096,8192,233,8353,8234,4265,4122,4661,8353,65,4194304,4825,34,8329,4824,4243,4198433,4198537,723,172,4194336,4660,1,4824,681]

theorem envBound9733 : H12AffineFastState.Bounded env9733 := by
  intro p hp
  have h : env9733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9732_9733 : H12AffineEnvironment.transform 10 754 env9732 = env9733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env9732 == env9733) = true)

theorem identity9733 : scanCanonicalize (H12AffineFastState.compose env9733 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 712) := by decide +kernel

theorem selectedBound9733 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env9734 : List Nat := [2,4,8,16,32,64,128,84,512,85,754,712,8192,233,8353,8234,609,722,253,8353,65,4194304,17,34,8329,16,603,4195049,4194881,723,172,4194336,252,1,16,681]

theorem envBound9734 : H12AffineFastState.Bounded env9734 := by
  intro p hp
  have h : env9734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9733_9734 : H12AffineEnvironment.transform 11 712 env9733 = env9734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 712 env9733 == env9734) = true)

theorem identity9734 : scanCanonicalize (H12AffineFastState.compose env9734 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9734 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env9735 : List Nat := [2,4,8,16,32,64,41,84,512,85,603,609,8192,64,8200,8234,609,635,84,8200,65,4194304,17,34,8224,16,603,4194880,4194881,634,5,4194336,85,1,16,512]

theorem envBound9735 : H12AffineFastState.Bounded env9735 := by
  intro p hp
  have h : env9735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9734_9735 : H12AffineEnvironment.transform 6 41 env9734 = env9735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9734 == env9735) = true)

theorem identity9735 : scanCanonicalize (H12AffineFastState.compose env9735 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound9735 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9736 : List Nat := [2,4,8,16,32,64,41,84,512,85,603,609,8192,64,8200,8234,609,635,84,8200,65,32,17,34,8224,16,603,608,609,634,5,0,85,1,16,512]

theorem envBound9736 : H12AffineFastState.Bounded env9736 := by
  intro p hp
  have h : env9736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9735_9736 : H12AffineEnvironment.transform 21 32 env9735 = env9736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env9735 == env9736) = true)

theorem identity9736 : scanCanonicalize (H12AffineFastState.compose env9736 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound9736 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9737 : List Nat := [2,4,8,16,32,64,41,84,74,85,17,43,8192,64,8200,8234,43,49,84,8200,65,32,17,34,8224,16,17,42,43,48,5,0,85,1,16,74]

theorem envBound9737 : H12AffineFastState.Bounded env9737 := by
  intro p hp
  have h : env9737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9736_9737 : H12AffineEnvironment.transform 8 74 env9736 = env9737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env9736 == env9737) = true)

theorem identity9737 : scanCanonicalize (H12AffineFastState.compose env9737 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9737 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9738 : List Nat := [2,4,2,16,32,64,35,84,64,85,17,33,8192,64,8194,8224,33,49,84,8194,65,32,17,34,8224,16,17,32,33,48,5,0,85,1,16,64]

theorem envBound9738 : H12AffineFastState.Bounded env9738 := by
  intro p hp
  have h : env9738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9737_9738 : H12AffineEnvironment.transform 2 2 env9737 = env9738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9737 == env9738) = true)

theorem identity9738 : scanCanonicalize (H12AffineFastState.compose env9738 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9738 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9739 : List Nat := [2,4,2,16,32,49,35,37,49,36,17,33,8192,49,8194,8224,33,49,37,8194,48,32,17,34,8224,16,17,32,33,48,5,0,36,1,16,49]

theorem envBound9739 : H12AffineFastState.Bounded env9739 := by
  intro p hp
  have h : env9739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9738_9739 : H12AffineEnvironment.transform 5 49 env9738 = env9739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9738 == env9739) = true)

theorem identity9739 : scanCanonicalize (H12AffineFastState.compose env9739 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9739 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env9740 : List Nat := [2,4,2,1,32,32,35,37,32,36,0,33,8192,32,8194,8224,33,32,37,8194,33,32,0,34,8224,1,0,32,33,33,5,0,36,1,1,32]

theorem envBound9740 : H12AffineFastState.Bounded env9740 := by
  intro p hp
  have h : env9740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9739_9740 : H12AffineEnvironment.transform 3 1 env9739 = env9740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9739 == env9740) = true)

theorem identity9740 : scanCanonicalize (H12AffineFastState.compose env9740 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound9740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9741 : List Nat := [2,4,2,1,32,32,35,37,32,36,0,33,2,32,0,34,33,32,37,0,33,32,0,34,34,1,0,32,33,33,5,0,36,1,1,32]

theorem envBound9741 : H12AffineFastState.Bounded env9741 := by
  intro p hp
  have h : env9741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9740_9741 : H12AffineEnvironment.transform 12 2 env9740 = env9741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env9740 == env9741) = true)

theorem identity9741 : scanCanonicalize (H12AffineFastState.compose env9741 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9741 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env9742 : List Nat := [2,4,2,1,1,1,2,4,1,5,0,0,2,1,0,3,0,1,4,0,0,1,0,3,3,1,0,1,0,0,5,0,5,1,1,1]

theorem envBound9742 : H12AffineFastState.Bounded env9742 := by
  intro p hp
  have h : env9742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9741_9742 : H12AffineEnvironment.transform 4 1 env9741 = env9742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9741 == env9742) = true)

def leafEnv9742 : List Nat := [2,4,2,1,1,1,2,4,1,5,0,0,2,1,0,3,0,1,4,0,0,1,0,3,4,3,1,1,0,1,0,0,5,0,5,1,5,3,1,1,1,1,0]

def active9742 : List Nat := [0,1]

def tree9742 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9742 : H12WitnessSearch.Good tree9742 := H12GlobalWitnessIndex.good

theorem leafIdentity9742 : H12AffineFastState.composeSystem env9742 rootObs = leafEnv9742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9742 rootObs == leafEnv9742) = true)

theorem terminalChecked9742 : H12PackedTerminal.terminalCheckFast leafEnv9742 active9742 tree9742 = true := by decide +kernel

def env9743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,67108864,134217728,138678441,138678613,151259274,84484169,155451871,525568,151257258,203759842,16778207]

theorem envBound9743 : H12AffineFastState.Bounded env9743 := by
  intro p hp
  have h : env9743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8527_9743 : H12AffineEnvironment.transform 27 138678441 env8527 = env9743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env8527 == env9743) = true)

theorem identity9743 : scanCanonicalize (H12AffineFastState.compose env9743 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 16856620) := by decide +kernel

theorem selectedBound9743 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env9744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,16856620,134217728,138678441,138678613,151259274,530021,155451871,525568,151257258,153360078,16778207]

theorem envBound9744 : H12AffineFastState.Bounded env9744 := by
  intro p hp
  have h : env9744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9743_9744 : H12AffineEnvironment.transform 25 16856620 env9743 = env9744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 16856620 env9743 == env9744) = true)

def env9745 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,16777216,8329,16855852,134217728,138678441,138678613,151259274,529253,155451871,524288,151257258,153359310,16778207]

theorem envBound9745 : H12AffineFastState.Bounded env9745 := by
  intro p hp
  have h : env9745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9744_9745 : H12AffineEnvironment.transform 9 256 env9744 = env9745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env9744 == env9745) = true)

def env9746 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,16777216,8329,16855852,4985752,525105,525005,21502738,529253,17306183,524288,21500722,23593046,16778207]

theorem envBound9746 : H12AffineFastState.Bounded env9746 := by
  intro p hp
  have h : env9746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9745_9746 : H12AffineEnvironment.transform 26 4985752 env9745 = env9746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985752 env9745 == env9746) = true)

def env9747 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,4194304,524525,16777216,8329,16855852,4985752,525105,525005,21502738,529253,17306183,524288,21500722,21781062,16778207]

theorem envBound9747 : H12AffineFastState.Bounded env9747 := by
  intro p hp
  have h : env9747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9746_9747 : H12AffineEnvironment.transform 20 285200 env9746 = env9747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9746 == env9747) = true)

theorem identity9747 : scanCanonicalize (H12AffineFastState.compose env9747 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9747 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9748 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,476,524525,16777216,8329,16855852,791108,525105,525005,17308366,529253,17306183,524288,17306350,17587098,16778207]

theorem envBound9748 : H12AffineFastState.Bounded env9748 := by
  intro p hp
  have h : env9748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9747_9748 : H12AffineEnvironment.transform 21 476 env9747 = env9748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9747 == env9748) = true)

theorem identity9748 : scanCanonicalize (H12AffineFastState.compose env9748 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9748 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9749 : List Nat := [2,4,8,16,32,64,41,256,512,256,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,285200,373,524356,16777216,8224,16855852,791108,525105,524900,17308263,529253,17306183,524288,17306183,17586995,16778102]

theorem envBound9749 : H12AffineFastState.Bounded env9749 := by
  intro p hp
  have h : env9749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9748_9749 : H12AffineEnvironment.transform 6 41 env9748 = env9749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9748 == env9749) = true)

theorem identity9749 : scanCanonicalize (H12AffineFastState.compose env9749 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9749 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9750 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,285200,32,524356,16777216,8224,16855673,791108,524900,524900,17308263,528944,17306183,524288,17306183,17586790,16777763]

theorem envBound9750 : H12AffineFastState.Bounded env9750 := by
  intro p hp
  have h : env9750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9749_9750 : H12AffineEnvironment.transform 7 85 env9749 = env9750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9749 == env9750) = true)

theorem identity9750 : scanCanonicalize (H12AffineFastState.compose env9750 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound9750 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9751 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8201,65536,4097,262144,78414,8201,285200,32,78346,16777216,8224,16855673,335882,77866,77866,16853033,73854,16850953,78414,16850953,17131560,16777763]

theorem envBound9751 : H12AffineFastState.Bounded env9751 := by
  intro p hp
  have h : env9751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9750_9751 : H12AffineEnvironment.transform 18 78414 env9750 = env9751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env9750 == env9751) = true)

theorem identity9751 : scanCanonicalize (H12AffineFastState.compose env9751 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336419) := by decide +kernel

theorem selectedBound9751 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9752 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8201,65536,4097,262144,78414,8201,285200,32,78346,336419,8224,266330,335882,77866,77866,264714,73854,262698,78414,262698,18955,335872]

theorem envBound9752 : H12AffineFastState.Bounded env9752 := by
  intro p hp
  have h : env9752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9751_9752 : H12AffineEnvironment.transform 23 336419 env9751 = env9752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336419 env9751 == env9752) = true)

theorem identity9752 : scanCanonicalize (H12AffineFastState.compose env9752 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16394) := by decide +kernel

theorem selectedBound9752 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9753 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8201,65536,4097,16394,78414,8201,6682,32,78346,90665,8224,20560,90112,77866,77866,18944,73854,16928,78414,16928,18955,90122]

theorem envBound9753 : H12AffineFastState.Bounded env9753 := by
  intro p hp
  have h : env9753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9752_9753 : H12AffineEnvironment.transform 17 16394 env9752 = env9753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16394 env9752 == env9753) = true)

theorem identity9753 : scanCanonicalize (H12AffineFastState.compose env9753 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14400) := by decide +kernel

theorem selectedBound9753 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9754 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,16384,8201,14400,4097,16394,2574,8201,6682,32,2634,23145,8224,20560,22592,2154,2154,18944,6206,16928,2574,16928,18955,22602]

theorem envBound9754 : H12AffineFastState.Bounded env9754 := by
  intro p hp
  have h : env9754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9753_9754 : H12AffineEnvironment.transform 15 14400 env9753 = env9754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14400 env9753 == env9754) = true)

theorem identity9754 : scanCanonicalize (H12AffineFastState.compose env9754 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound9754 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9755 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,8192,8744,8201,14400,4097,8738,2574,8201,6682,32,2634,14401,8224,12920,14952,2154,2154,10280,6206,8200,2574,8200,10275,14946]

theorem envBound9755 : H12AffineFastState.Bounded env9755 := by
  intro p hp
  have h : env9755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9754_9755 : H12AffineEnvironment.transform 13 8744 env9754 = env9755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env9754 == env9755) = true)

theorem identity9755 : scanCanonicalize (H12AffineFastState.compose env9755 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6242) := by decide +kernel

theorem selectedBound9755 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9756 : List Nat := [2,4,8,16,32,64,41,85,512,85,2048,4096,6242,6730,6251,34,4097,6720,2574,6251,6682,32,2634,35,6210,2586,522,2154,2154,4170,6206,6250,2574,6250,4161,512]

theorem envBound9756 : H12AffineFastState.Bounded env9756 := by
  intro p hp
  have h : env9756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9755_9756 : H12AffineEnvironment.transform 12 6242 env9755 = env9756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6242 env9755 == env9756) = true)

def env9757 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,4194304,524525,16777216,8329,16855852,4985752,525105,525005,21502738,529253,17306183,524288,21500722,21781063,16778207]

theorem envBound9757 : H12AffineFastState.Bounded env9757 := by
  intro p hp
  have h : env9757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9746_9757 : H12AffineEnvironment.transform 20 285201 env9746 = env9757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9746 == env9757) = true)

theorem identity9757 : scanCanonicalize (H12AffineFastState.compose env9757 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9757 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9758 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,372,524525,16777216,8329,16855852,791276,525105,525005,17308262,529253,17306183,524288,17306182,17586995,16778207]

theorem envBound9758 : H12AffineFastState.Bounded env9758 := by
  intro p hp
  have h : env9758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9757_9758 : H12AffineEnvironment.transform 21 372 env9757 = env9758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9757 == env9758) = true)

theorem identity9758 : scanCanonicalize (H12AffineFastState.compose env9758 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9758 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9759 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,372,524525,35,8329,78607,791276,525105,525005,531013,529253,528996,524288,528997,809744,1020]

theorem envBound9759 : H12AffineFastState.Bounded env9759 := by
  intro p hp
  have h : env9759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9758_9759 : H12AffineEnvironment.transform 23 35 env9758 = env9759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9758 == env9759) = true)

theorem identity9759 : scanCanonicalize (H12AffineFastState.compose env9759 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342726) := by decide +kernel

theorem selectedBound9759 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9760 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,342726,8693,285201,372,342571,35,8329,78607,75818,342519,342027,336003,338339,338082,342726,338083,90582,1020]

theorem envBound9760 : H12AffineFastState.Bounded env9760 := by
  intro p hp
  have h : env9760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9759_9760 : H12AffineEnvironment.transform 18 342726 env9759 = env9760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342726 env9759 == env9760) = true)

theorem identity9760 : scanCanonicalize (H12AffineFastState.compose env9760 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound9760 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9761 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,2524,78618,8693,21453,372,78839,35,8329,78607,75818,77867,78295,76127,73855,74110,78618,74111,90582,1020]

theorem envBound9761 : H12AffineFastState.Bounded env9761 := by
  intro p hp
  have h : env9761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9760_9761 : H12AffineEnvironment.transform 17 2524 env9760 = env9761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env9760 == env9761) = true)

theorem identity9761 : scanCanonicalize (H12AffineFastState.compose env9761 (packedSelected [2,5,7,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 30753) := by decide +kernel

theorem selectedBound9761 : packedSelected [2,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env9762 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,30753,4605,2524,19259,8693,21453,372,19414,35,8329,19246,20491,18442,18934,20862,22622,22879,19259,22878,6647,1020]

theorem envBound9762 : H12AffineFastState.Bounded env9762 := by
  intro p hp
  have h : env9762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9761_9762 : H12AffineEnvironment.transform 15 30753 env9761 = env9762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30753 env9761 == env9762) = true)

theorem identity9762 : scanCanonicalize (H12AffineFastState.compose env9762 (packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 8858) := by decide +kernel

theorem selectedBound9762 : packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env9763 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,8858,8693,6843,4605,2524,10657,8693,12631,372,10572,35,8329,10676,12945,10896,11116,13284,15044,15301,10657,15300,6647,1020]

theorem envBound9763 : H12AffineFastState.Bounded env9763 := by
  intro p hp
  have h : env9763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9762_9763 : H12AffineEnvironment.transform 13 8858 env9762 = env9763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8858 env9762 == env9763) = true)

theorem identity9763 : scanCanonicalize (H12AffineFastState.compose env9763 (packedSelected [0,3,4,6,7,8,9,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2288) := by decide +kernel

theorem selectedBound9763 : packedSelected [0,3,4,6,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env9764 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,2288,2666,2309,6843,4605,2524,337,2309,6567,372,444,35,2169,324,6753,608,924,6932,4660,4917,337,4916,6647,1020]

theorem envBound9764 : H12AffineFastState.Bounded env9764 := by
  intro p hp
  have h : env9764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9763_9764 : H12AffineEnvironment.transform 12 2288 env9763 = env9764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2288 env9763 == env9764) = true)

theorem identity9764 : scanCanonicalize (H12AffineFastState.compose env9764 (packedSelected [0,2,4,7,9,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound9764 : packedSelected [0,2,4,7,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env9765 : List Nat := [2,4,8,16,32,64,128,256,512,256,391,4096,375,1005,130,4924,4605,91,337,130,4128,372,444,35,510,324,5094,608,924,4755,4660,4917,337,4916,4208,1020]

theorem envBound9765 : H12AffineFastState.Bounded env9765 := by
  intro p hp
  have h : env9765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9764_9765 : H12AffineEnvironment.transform 10 391 env9764 = env9765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env9764 == env9765) = true)

theorem identity9765 : scanCanonicalize (H12AffineFastState.compose env9765 (packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound9765 : packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env9766 : List Nat := [2,4,8,16,32,64,128,256,512,256,391,445,375,1005,130,641,64,91,337,130,413,372,444,35,510,324,603,608,924,814,905,648,337,649,461,1020]

theorem envBound9766 : H12AffineFastState.Bounded env9766 := by
  intro p hp
  have h : env9766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9765_9766 : H12AffineEnvironment.transform 11 445 env9765 = env9766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env9765 == env9766) = true)

theorem identity9766 : scanCanonicalize (H12AffineFastState.compose env9766 (packedSelected [1,2,5,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9766 : packedSelected [1,2,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9767 : List Nat := [2,4,8,16,32,64,128,85,512,85,210,232,34,696,130,641,64,91,4,130,200,33,233,35,171,17,603,608,713,635,732,648,4,649,152,681]

theorem envBound9767 : H12AffineFastState.Bounded env9767 := by
  intro p hp
  have h : env9767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9766_9767 : H12AffineEnvironment.transform 7 85 env9766 = env9767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9766 == env9767) = true)

theorem identity9767 : scanCanonicalize (H12AffineFastState.compose env9767 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound9767 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9768 : List Nat := [2,4,8,16,32,64,83,85,512,85,1,59,34,619,81,594,64,91,4,81,27,33,58,35,120,17,603,608,538,635,527,603,4,602,75,634]

theorem envBound9768 : H12AffineFastState.Bounded env9768 := by
  intro p hp
  have h : env9768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9767_9768 : H12AffineEnvironment.transform 6 83 env9767 = env9768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env9767 == env9768) = true)

theorem identity9768 : scanCanonicalize (H12AffineFastState.compose env9768 (packedSelected [4,6] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound9768 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env9769 : List Nat := [2,4,8,16,32,64,83,85,81,85,1,59,34,58,81,3,64,91,4,81,27,33,58,35,120,17,10,49,75,42,94,10,4,11,75,43]

theorem envBound9769 : H12AffineFastState.Bounded env9769 := by
  intro p hp
  have h : env9769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9768_9769 : H12AffineEnvironment.transform 8 81 env9768 = env9769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env9768 == env9769) = true)

theorem identity9769 : scanCanonicalize (H12AffineFastState.compose env9769 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9769 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9770 : List Nat := [2,4,8,16,32,59,40,46,42,46,1,59,34,58,42,3,59,32,4,42,27,33,58,35,3,17,10,49,48,42,37,10,4,11,48,43]

theorem envBound9770 : H12AffineFastState.Bounded env9770 := by
  intro p hp
  have h : env9770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9769_9770 : H12AffineEnvironment.transform 5 59 env9769 = env9770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9769 == env9770) = true)

theorem identity9770 : scanCanonicalize (H12AffineFastState.compose env9770 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9770 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9771 : List Nat := [2,4,8,1,32,42,40,46,42,46,1,42,34,43,42,3,42,32,4,42,10,33,43,35,3,0,10,32,33,42,37,10,4,11,33,43]

theorem envBound9771 : H12AffineFastState.Bounded env9771 := by
  intro p hp
  have h : env9771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9770_9771 : H12AffineEnvironment.transform 3 1 env9770 = env9771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9770 == env9771) = true)

theorem identity9771 : scanCanonicalize (H12AffineFastState.compose env9771 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9771 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9772 : List Nat := [2,0,8,1,32,42,40,42,42,42,1,42,34,43,42,3,42,32,0,42,10,33,43,35,3,0,10,32,33,42,33,10,0,11,33,43]

theorem envBound9772 : H12AffineFastState.Bounded env9772 := by
  intro p hp
  have h : env9772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9771_9772 : H12AffineEnvironment.transform 1 0 env9771 = env9772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9771 == env9772) = true)

theorem identity9772 : scanCanonicalize (H12AffineFastState.compose env9772 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9773 : List Nat := [2,0,8,1,10,0,2,0,0,0,1,0,8,1,0,3,0,10,0,0,10,11,1,9,3,0,10,10,11,0,11,10,0,11,11,1]

theorem envBound9773 : H12AffineFastState.Bounded env9773 := by
  intro p hp
  have h : env9773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9772_9773 : H12AffineEnvironment.transform 4 10 env9772 = env9773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9772 == env9773) = true)

theorem identity9773 : scanCanonicalize (H12AffineFastState.compose env9773 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9773 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9774 : List Nat := [2,0,2,1,0,0,2,0,0,0,1,0,2,1,0,3,0,0,0,0,0,1,1,3,3,0,0,0,1,0,1,0,0,1,1,1]

theorem envBound9774 : H12AffineFastState.Bounded env9774 := by
  intro p hp
  have h : env9774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9773_9774 : H12AffineEnvironment.transform 2 2 env9773 = env9774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9773 == env9774) = true)

def env9775 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524525,16777216,8329,16855852,4985753,525104,525004,21502739,529253,17306182,524288,21500723,23593047,16778207]

theorem envBound9775 : H12AffineFastState.Bounded env9775 := by
  intro p hp
  have h : env9775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9745_9775 : H12AffineEnvironment.transform 26 4985753 env9745 = env9775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985753 env9745 == env9775) = true)

def env9776 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,4194304,524525,16777216,8329,16855852,4985753,525104,525004,21502739,529253,17306182,524288,21500723,21781063,16778207]

theorem envBound9776 : H12AffineFastState.Bounded env9776 := by
  intro p hp
  have h : env9776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9775_9776 : H12AffineEnvironment.transform 20 285200 env9775 = env9776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9775 == env9776) = true)

theorem identity9776 : scanCanonicalize (H12AffineFastState.compose env9776 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9776 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9777 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,477,524525,16777216,8329,16855852,791108,525104,525004,17308366,529253,17306182,524288,17306350,17587098,16778207]

theorem envBound9777 : H12AffineFastState.Bounded env9777 := by
  intro p hp
  have h : env9777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9776_9777 : H12AffineEnvironment.transform 21 477 env9776 = env9777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9776 == env9777) = true)

theorem identity9777 : scanCanonicalize (H12AffineFastState.compose env9777 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9777 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9778 : List Nat := [2,4,8,16,32,64,40,256,512,256,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,285200,373,524357,16777216,8225,16855852,791108,525104,524900,17308262,529253,17306182,524288,17306182,17586994,16778103]

theorem envBound9778 : H12AffineFastState.Bounded env9778 := by
  intro p hp
  have h : env9778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9777_9778 : H12AffineEnvironment.transform 6 40 env9777 = env9778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9777 == env9778) = true)

theorem identity9778 : scanCanonicalize (H12AffineFastState.compose env9778 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9778 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9779 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,285200,33,524357,16777216,8225,16855672,791108,524900,524900,17308262,528945,17306182,524288,17306182,17586790,16777763]

theorem envBound9779 : H12AffineFastState.Bounded env9779 := by
  intro p hp
  have h : env9779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9778_9779 : H12AffineEnvironment.transform 7 84 env9778 = env9779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9778 == env9779) = true)

theorem identity9779 : scanCanonicalize (H12AffineFastState.compose env9779 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound9779 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9780 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8201,65536,4097,262144,78415,8201,285200,33,78346,16777216,8225,16855672,335883,77867,77867,16853033,73854,16850953,78415,16850953,17131561,16777763]

theorem envBound9780 : H12AffineFastState.Bounded env9780 := by
  intro p hp
  have h : env9780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9779_9780 : H12AffineEnvironment.transform 18 78415 env9779 = env9780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env9779 == env9780) = true)

theorem identity9780 : scanCanonicalize (H12AffineFastState.compose env9780 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336419) := by decide +kernel

theorem selectedBound9780 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9781 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8201,65536,4097,262144,78415,8201,285200,33,78346,336419,8225,266331,335883,77867,77867,264714,73854,262698,78415,262698,18954,335872]

theorem envBound9781 : H12AffineFastState.Bounded env9781 := by
  intro p hp
  have h : env9781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9780_9781 : H12AffineEnvironment.transform 23 336419 env9780 = env9781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336419 env9780 == env9781) = true)

theorem identity9781 : scanCanonicalize (H12AffineFastState.compose env9781 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16395) := by decide +kernel

theorem selectedBound9781 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9782 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8201,65536,4097,16395,78415,8201,6683,33,78346,90664,8225,20560,90112,77867,77867,18945,73854,16929,78415,16929,18954,90123]

theorem envBound9782 : H12AffineFastState.Bounded env9782 := by
  intro p hp
  have h : env9782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9781_9782 : H12AffineEnvironment.transform 17 16395 env9781 = env9782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16395 env9781 == env9782) = true)

theorem identity9782 : scanCanonicalize (H12AffineFastState.compose env9782 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14400) := by decide +kernel

theorem selectedBound9782 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9783 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,16384,8201,14400,4097,16395,2575,8201,6683,33,2634,23144,8225,20560,22592,2155,2155,18945,6206,16929,2575,16929,18954,22603]

theorem envBound9783 : H12AffineFastState.Bounded env9783 := by
  intro p hp
  have h : env9783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9782_9783 : H12AffineEnvironment.transform 15 14400 env9782 = env9783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14400 env9782 == env9783) = true)

theorem identity9783 : scanCanonicalize (H12AffineFastState.compose env9783 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound9783 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9784 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,8192,8745,8201,14400,4097,8738,2575,8201,6683,33,2634,14401,8225,12921,14953,2155,2155,10280,6206,8200,2575,8200,10275,14946]

theorem envBound9784 : H12AffineFastState.Bounded env9784 := by
  intro p hp
  have h : env9784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9783_9784 : H12AffineEnvironment.transform 13 8745 env9783 = env9784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env9783 == env9784) = true)

theorem identity9784 : scanCanonicalize (H12AffineFastState.compose env9784 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6242) := by decide +kernel

theorem selectedBound9784 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9785 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,4096,6242,6731,6251,34,4097,6720,2575,6251,6683,33,2634,35,6211,2587,523,2155,2155,4170,6206,6250,2575,6250,4161,512]

theorem envBound9785 : H12AffineFastState.Bounded env9785 := by
  intro p hp
  have h : env9785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9784_9785 : H12AffineEnvironment.transform 12 6242 env9784 = env9785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6242 env9784 == env9785) = true)

theorem identity9785 : scanCanonicalize (H12AffineFastState.compose env9785 (packedSelected [0,1,2,4,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 609) := by decide +kernel

theorem selectedBound9785 : packedSelected [0,1,2,4,5,13] rootPS < 2^1333 := by decide +kernel

def env9786 : List Nat := [2,4,8,16,32,64,40,84,512,84,2048,609,2563,2090,2570,34,608,2081,2575,2570,2170,33,2634,35,2594,2587,523,2155,2155,555,2655,2571,2575,2571,544,512]

theorem envBound9786 : H12AffineFastState.Bounded env9786 := by
  intro p hp
  have h : env9786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9785_9786 : H12AffineEnvironment.transform 11 609 env9785 = env9786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 609 env9785 == env9786) = true)

def env9787 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,4194304,524525,16777216,8329,16855852,4985753,525104,525004,21502739,529253,17306182,524288,21500723,21781062,16778207]

theorem envBound9787 : H12AffineFastState.Bounded env9787 := by
  intro p hp
  have h : env9787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9775_9787 : H12AffineEnvironment.transform 20 285201 env9775 = env9787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9775 == env9787) = true)

theorem identity9787 : scanCanonicalize (H12AffineFastState.compose env9787 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9787 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9788 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,372,524525,16777216,8329,16855852,791277,525104,525004,17308263,529253,17306182,524288,17306183,17586994,16778207]

theorem envBound9788 : H12AffineFastState.Bounded env9788 := by
  intro p hp
  have h : env9788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9787_9788 : H12AffineEnvironment.transform 21 372 env9787 = env9788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9787 == env9788) = true)

theorem identity9788 : scanCanonicalize (H12AffineFastState.compose env9788 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9788 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9789 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,372,524525,35,8329,78607,791277,525104,525004,531012,529253,528997,524288,528996,809745,1020]

theorem envBound9789 : H12AffineFastState.Bounded env9789 := by
  intro p hp
  have h : env9789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9788_9789 : H12AffineEnvironment.transform 23 35 env9788 = env9789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9788 == env9789) = true)

theorem identity9789 : scanCanonicalize (H12AffineFastState.compose env9789 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342726) := by decide +kernel

theorem selectedBound9789 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9790 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,262144,342726,8693,285201,372,342571,35,8329,78607,75819,342518,342026,336002,338339,338083,342726,338082,90583,1020]

theorem envBound9790 : H12AffineFastState.Bounded env9790 := by
  intro p hp
  have h : env9790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9789_9790 : H12AffineEnvironment.transform 18 342726 env9789 = env9790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342726 env9789 == env9790) = true)

theorem identity9790 : scanCanonicalize (H12AffineFastState.compose env9790 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound9790 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9791 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,65536,4605,2421,78771,8693,21348,372,78686,35,8329,78607,75819,77955,78207,76279,73942,74198,78771,74199,90583,1020]

theorem envBound9791 : H12AffineFastState.Bounded env9791 := by
  intro p hp
  have h : env9791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9790_9791 : H12AffineEnvironment.transform 17 2421 env9790 = env9791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env9790 == env9791) = true)

theorem identity9791 : scanCanonicalize (H12AffineFastState.compose env9791 (packedSelected [3,4,5,6,7,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound9791 : packedSelected [3,4,5,6,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env9792 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,4373,8693,65536,4605,2421,78771,8693,625,372,78686,35,8329,78607,75819,77955,78207,76279,73942,74198,78771,74199,78018,1020]

theorem envBound9792 : H12AffineFastState.Bounded env9792 := by
  intro p hp
  have h : env9792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9791_9792 : H12AffineEnvironment.transform 13 4373 env9791 = env9792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env9791 == env9792) = true)

theorem identity9792 : scanCanonicalize (H12AffineFastState.compose env9792 (packedSelected [1,2,3,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 278) := by decide +kernel

theorem selectedBound9792 : packedSelected [1,2,3,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env9793 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,278,4373,227,65536,4605,2421,70309,227,625,372,70216,35,415,70169,67901,70037,69737,67809,65984,65728,70309,65729,70100,1020]

theorem envBound9793 : H12AffineFastState.Bounded env9793 := by
  intro p hp
  have h : env9793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9792_9793 : H12AffineEnvironment.transform 12 278 env9792 = env9793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 278 env9792 == env9793) = true)

theorem identity9793 : scanCanonicalize (H12AffineFastState.compose env9793 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound9793 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env9794 : List Nat := [2,4,8,16,32,64,128,256,512,256,523,4096,278,4373,227,65536,4605,894,70309,227,625,372,70216,35,415,70169,66358,70037,69737,66282,65984,65728,70309,65729,70100,1020]

theorem envBound9794 : H12AffineFastState.Bounded env9794 := by
  intro p hp
  have h : env9794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9793_9794 : H12AffineEnvironment.transform 10 523 env9793 = env9794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env9793 == env9794) = true)

theorem identity9794 : scanCanonicalize (H12AffineFastState.compose env9794 (packedSelected [1,6,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9794 : packedSelected [1,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9795 : List Nat := [2,4,8,16,32,64,40,256,512,256,523,4096,278,4373,75,65536,4437,894,70157,75,625,372,70216,35,311,70169,66358,69949,69737,66114,65896,65640,70157,65641,70012,852]

theorem envBound9795 : H12AffineFastState.Bounded env9795 := by
  intro p hp
  have h : env9795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9794_9795 : H12AffineEnvironment.transform 6 40 env9794 = env9795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9794 == env9795) = true)

theorem identity9795 : scanCanonicalize (H12AffineFastState.compose env9795 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9795 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env9796 : List Nat := [2,4,8,16,32,64,40,37,512,37,523,4096,51,4144,75,65536,4208,603,70157,75,625,81,70216,35,18,70169,66067,69656,69737,66114,65613,65640,70157,65641,69721,625]

theorem envBound9796 : H12AffineFastState.Bounded env9796 := by
  intro p hp
  have h : env9796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9795_9796 : H12AffineEnvironment.transform 7 37 env9795 = env9796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9795 == env9796) = true)

theorem identity9796 : scanCanonicalize (H12AffineFastState.compose env9796 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound9796 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9797 : List Nat := [2,4,8,16,32,64,40,37,512,37,523,4096,51,4144,75,82,4208,603,4703,75,625,81,4634,35,18,4683,577,4170,4155,528,31,58,4703,59,4107,625]

theorem envBound9797 : H12AffineFastState.Bounded env9797 := by
  intro p hp
  have h : env9797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9796_9797 : H12AffineEnvironment.transform 15 82 env9796 = env9797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env9796 == env9797) = true)

theorem identity9797 : scanCanonicalize (H12AffineFastState.compose env9797 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound9797 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9798 : List Nat := [2,4,8,16,32,64,40,37,512,37,523,528,51,544,75,82,608,603,79,75,625,81,10,35,18,91,577,602,555,528,31,58,79,59,539,625]

theorem envBound9798 : H12AffineFastState.Bounded env9798 := by
  intro p hp
  have h : env9798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9797_9798 : H12AffineEnvironment.transform 11 528 env9797 = env9798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env9797 == env9798) = true)

theorem identity9798 : scanCanonicalize (H12AffineFastState.compose env9798 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9798 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env9799 : List Nat := [2,4,8,16,32,49,40,37,512,37,523,528,51,544,58,35,529,554,62,58,512,32,10,35,18,42,560,555,555,528,31,58,62,59,539,512]

theorem envBound9799 : H12AffineFastState.Bounded env9799 := by
  intro p hp
  have h : env9799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9798_9799 : H12AffineEnvironment.transform 5 49 env9798 = env9799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9798 == env9799) = true)

theorem identity9799 : scanCanonicalize (H12AffineFastState.compose env9799 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9799 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9800 : List Nat := [2,4,8,16,32,49,40,37,33,37,42,49,51,1,58,35,48,11,62,58,33,32,10,35,18,42,17,10,10,49,31,58,62,59,58,33]

theorem envBound9800 : H12AffineFastState.Bounded env9800 := by
  intro p hp
  have h : env9800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9799_9800 : H12AffineEnvironment.transform 8 33 env9799 = env9800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9799 == env9800) = true)

def env9801 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,16777216,8329,16855853,134217728,138678441,138678613,151259274,529252,155451871,524289,151257258,153359311,16778207]

theorem envBound9801 : H12AffineFastState.Bounded env9801 := by
  intro p hp
  have h : env9801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9744_9801 : H12AffineEnvironment.transform 9 257 env9744 = env9801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env9744 == env9801) = true)

def env9802 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,16777216,8329,16855853,4985752,525105,525005,21502738,529252,17306183,524289,21500722,23593047,16778207]

theorem envBound9802 : H12AffineFastState.Bounded env9802 := by
  intro p hp
  have h : env9802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9801_9802 : H12AffineEnvironment.transform 26 4985752 env9801 = env9802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985752 env9801 == env9802) = true)

def env9803 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,4194304,524524,16777216,8329,16855853,4985752,525105,525005,21502738,529252,17306183,524289,21500722,21781063,16778207]

theorem envBound9803 : H12AffineFastState.Bounded env9803 := by
  intro p hp
  have h : env9803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9802_9803 : H12AffineEnvironment.transform 20 285200 env9802 = env9803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9802 == env9803) = true)

theorem identity9803 : scanCanonicalize (H12AffineFastState.compose env9803 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9803 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9804 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,372,524524,16777216,8329,16855853,791276,525105,525005,17308262,529252,17306183,524289,17306182,17586995,16778207]

theorem envBound9804 : H12AffineFastState.Bounded env9804 := by
  intro p hp
  have h : env9804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9803_9804 : H12AffineEnvironment.transform 21 372 env9803 = env9804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9803 == env9804) = true)

theorem identity9804 : scanCanonicalize (H12AffineFastState.compose env9804 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9804 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9805 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,372,524524,35,8329,78606,791276,525105,525005,531013,529252,528996,524289,528997,809744,1020]

theorem envBound9805 : H12AffineFastState.Bounded env9805 := by
  intro p hp
  have h : env9805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9804_9805 : H12AffineEnvironment.transform 23 35 env9804 = env9805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9804 == env9805) = true)

theorem identity9805 : scanCanonicalize (H12AffineFastState.compose env9805 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342726) := by decide +kernel

theorem selectedBound9805 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9806 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,342726,8693,285200,372,342570,35,8329,78606,75818,342519,342027,336003,338338,338082,342727,338083,90582,1020]

theorem envBound9806 : H12AffineFastState.Bounded env9806 := by
  intro p hp
  have h : env9806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9805_9806 : H12AffineEnvironment.transform 18 342726 env9805 = env9806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342726 env9805 == env9806) = true)

theorem identity9806 : scanCanonicalize (H12AffineFastState.compose env9806 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound9806 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9807 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,2524,78618,8693,21452,372,78838,35,8329,78606,75818,77867,78295,76127,73854,74110,78619,74111,90582,1020]

theorem envBound9807 : H12AffineFastState.Bounded env9807 := by
  intro p hp
  have h : env9807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9806_9807 : H12AffineEnvironment.transform 17 2524 env9806 = env9807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env9806 == env9807) = true)

theorem identity9807 : scanCanonicalize (H12AffineFastState.compose env9807 (packedSelected [2,5,7,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 30857) := by decide +kernel

theorem selectedBound9807 : packedSelected [2,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env9808 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,30857,4605,2524,19347,8693,21452,372,19327,35,8329,19335,20643,18594,18782,20950,22775,23031,19346,23030,6495,1020]

theorem envBound9808 : H12AffineFastState.Bounded env9808 := by
  intro p hp
  have h : env9808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9807_9808 : H12AffineEnvironment.transform 15 30857 env9807 = env9808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30857 env9807 == env9808) = true)

theorem identity9808 : scanCanonicalize (H12AffineFastState.compose env9808 (packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 8755) := by decide +kernel

theorem selectedBound9808 : packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env9809 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,8755,8693,6842,4605,2524,10656,8693,12799,372,10572,35,8329,10676,12944,10897,11117,13285,15044,15300,10657,15301,6495,1020]

theorem envBound9809 : H12AffineFastState.Bounded env9809 := by
  intro p hp
  have h : env9809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9808_9809 : H12AffineEnvironment.transform 13 8755 env9808 = env9809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8755 env9808 == env9809) = true)

theorem identity9809 : scanCanonicalize (H12AffineFastState.compose env9809 (packedSelected [0,3,4,6,7,8,9,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2288) := by decide +kernel

theorem selectedBound9809 : packedSelected [0,3,4,6,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env9810 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,2288,2755,2309,6842,4605,2524,336,2309,6415,372,444,35,2169,324,6752,609,925,6933,4660,4916,337,4917,6495,1020]

theorem envBound9810 : H12AffineFastState.Bounded env9810 := by
  intro p hp
  have h : env9810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9809_9810 : H12AffineEnvironment.transform 12 2288 env9809 = env9810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2288 env9809 == env9810) = true)

theorem identity9810 : scanCanonicalize (H12AffineFastState.compose env9810 (packedSelected [0,2,4,7,9,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound9810 : packedSelected [0,2,4,7,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env9811 : List Nat := [2,4,8,16,32,64,128,256,512,257,390,4096,374,837,131,4924,4605,90,336,131,4233,372,444,35,511,324,5094,609,925,4755,4660,4916,337,4917,4313,1020]

theorem envBound9811 : H12AffineFastState.Bounded env9811 := by
  intro p hp
  have h : env9811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9810_9811 : H12AffineEnvironment.transform 10 390 env9810 = env9811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env9810 == env9811) = true)

theorem identity9811 : scanCanonicalize (H12AffineFastState.compose env9811 (packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound9811 : packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env9812 : List Nat := [2,4,8,16,32,64,128,256,512,257,390,277,374,837,131,553,232,90,336,131,412,372,444,35,511,324,755,609,925,902,801,545,337,544,460,1020]

theorem envBound9812 : H12AffineFastState.Bounded env9812 := by
  intro p hp
  have h : env9812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9811_9812 : H12AffineEnvironment.transform 11 277 env9811 = env9812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env9811 == env9812) = true)

theorem identity9812 : scanCanonicalize (H12AffineFastState.compose env9812 (packedSelected [1,2,5,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9812 : packedSelected [1,2,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9813 : List Nat := [2,4,8,16,32,64,128,85,512,84,211,64,35,528,131,553,232,90,5,131,201,33,233,35,170,17,755,609,712,723,628,545,4,544,153,681]

theorem envBound9813 : H12AffineFastState.Bounded env9813 := by
  intro p hp
  have h : env9813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9812_9813 : H12AffineEnvironment.transform 7 85 env9812 = env9813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9812 == env9813) = true)

theorem identity9813 : scanCanonicalize (H12AffineFastState.compose env9813 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9813 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9814 : List Nat := [2,4,8,16,32,59,128,46,512,47,168,59,35,528,131,553,147,33,5,131,178,33,146,35,170,17,648,538,691,680,527,545,4,544,153,681]

theorem envBound9814 : H12AffineFastState.Bounded env9814 := by
  intro p hp
  have h : env9814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9813_9814 : H12AffineEnvironment.transform 5 59 env9813 = env9814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9813 == env9814) = true)

theorem identity9814 : scanCanonicalize (H12AffineFastState.compose env9814 (packedSelected [1,2,3,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound9814 : packedSelected [1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env9815 : List Nat := [2,4,8,16,32,59,128,46,42,47,168,59,35,58,131,3,147,33,5,131,178,33,146,35,170,17,162,48,153,130,37,11,4,10,153,131]

theorem envBound9815 : H12AffineFastState.Bounded env9815 := by
  intro p hp
  have h : env9815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9814_9815 : H12AffineEnvironment.transform 8 42 env9814 = env9815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env9814 == env9815) = true)

def env9816 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,4194304,524524,16777216,8329,16855853,4985752,525105,525005,21502738,529252,17306183,524289,21500722,21781062,16778207]

theorem envBound9816 : H12AffineFastState.Bounded env9816 := by
  intro p hp
  have h : env9816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9802_9816 : H12AffineEnvironment.transform 20 285201 env9802 = env9816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9802 == env9816) = true)

theorem identity9816 : scanCanonicalize (H12AffineFastState.compose env9816 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9816 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9817 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,476,524524,16777216,8329,16855853,791108,525105,525005,17308366,529252,17306183,524289,17306350,17587098,16778207]

theorem envBound9817 : H12AffineFastState.Bounded env9817 := by
  intro p hp
  have h : env9817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9816_9817 : H12AffineEnvironment.transform 21 476 env9816 = env9817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9816 == env9817) = true)

theorem identity9817 : scanCanonicalize (H12AffineFastState.compose env9817 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9817 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9818 : List Nat := [2,4,8,16,32,64,41,256,512,257,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,285201,373,524357,16777216,8224,16855853,791108,525105,524900,17308263,529252,17306183,524289,17306183,17586995,16778102]

theorem envBound9818 : H12AffineFastState.Bounded env9818 := by
  intro p hp
  have h : env9818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9817_9818 : H12AffineEnvironment.transform 6 41 env9817 = env9818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9817 == env9818) = true)

theorem identity9818 : scanCanonicalize (H12AffineFastState.compose env9818 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9818 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9819 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,285201,32,524357,16777216,8224,16855672,791108,524900,524900,17308263,528945,17306183,524289,17306183,17586790,16777763]

theorem envBound9819 : H12AffineFastState.Bounded env9819 := by
  intro p hp
  have h : env9819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9818_9819 : H12AffineEnvironment.transform 7 85 env9818 = env9819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9818 == env9819) = true)

theorem identity9819 : scanCanonicalize (H12AffineFastState.compose env9819 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound9819 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9820 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8201,65536,4097,262144,78414,8201,285201,32,78347,16777216,8224,16855672,335882,77866,77866,16853033,73855,16850953,78415,16850953,17131560,16777763]

theorem envBound9820 : H12AffineFastState.Bounded env9820 := by
  intro p hp
  have h : env9820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9819_9820 : H12AffineEnvironment.transform 18 78414 env9819 = env9820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env9819 == env9820) = true)

theorem identity9820 : scanCanonicalize (H12AffineFastState.compose env9820 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336419) := by decide +kernel

theorem selectedBound9820 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9821 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8201,65536,4097,262144,78414,8201,285201,32,78347,336419,8224,266331,335882,77866,77866,264714,73855,262698,78415,262698,18955,335872]

theorem envBound9821 : H12AffineFastState.Bounded env9821 := by
  intro p hp
  have h : env9821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9820_9821 : H12AffineEnvironment.transform 23 336419 env9820 = env9821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336419 env9820 == env9821) = true)

theorem identity9821 : scanCanonicalize (H12AffineFastState.compose env9821 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16395) := by decide +kernel

theorem selectedBound9821 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9822 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8201,65536,4097,16395,78414,8201,6682,32,78347,90664,8224,20560,90113,77866,77866,18945,73855,16929,78415,16929,18955,90123]

theorem envBound9822 : H12AffineFastState.Bounded env9822 := by
  intro p hp
  have h : env9822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9821_9822 : H12AffineEnvironment.transform 17 16395 env9821 = env9822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16395 env9821 == env9822) = true)

theorem identity9822 : scanCanonicalize (H12AffineFastState.compose env9822 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14401) := by decide +kernel

theorem selectedBound9822 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9823 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8201,14401,4097,16395,2575,8201,6682,32,2634,23145,8224,20560,22592,2155,2155,18945,6206,16929,2574,16929,18955,22602]

theorem envBound9823 : H12AffineFastState.Bounded env9823 := by
  intro p hp
  have h : env9823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9822_9823 : H12AffineEnvironment.transform 15 14401 env9822 = env9823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14401 env9822 == env9823) = true)

theorem identity9823 : scanCanonicalize (H12AffineFastState.compose env9823 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound9823 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9824 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,8745,8201,14401,4097,8738,2575,8201,6682,32,2634,14400,8224,12921,14953,2155,2155,10280,6206,8200,2574,8200,10274,14947]

theorem envBound9824 : H12AffineFastState.Bounded env9824 := by
  intro p hp
  have h : env9824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9823_9824 : H12AffineEnvironment.transform 13 8745 env9823 = env9824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env9823 == env9824) = true)

theorem identity9824 : scanCanonicalize (H12AffineFastState.compose env9824 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6243) := by decide +kernel

theorem selectedBound9824 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9825 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,6243,6730,6250,34,4097,6721,2575,6250,6682,32,2634,35,6211,2586,522,2155,2155,4171,6206,6251,2574,6251,4161,512]

theorem envBound9825 : H12AffineFastState.Bounded env9825 := by
  intro p hp
  have h : env9825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9824_9825 : H12AffineEnvironment.transform 12 6243 env9824 = env9825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6243 env9824 == env9825) = true)

def env9826 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,524524,16777216,8329,16855853,4985753,525104,525004,21502739,529252,17306182,524289,21500723,23593046,16778207]

theorem envBound9826 : H12AffineFastState.Bounded env9826 := by
  intro p hp
  have h : env9826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9801_9826 : H12AffineEnvironment.transform 26 4985753 env9801 = env9826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985753 env9801 == env9826) = true)

def env9827 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,4194304,524524,16777216,8329,16855853,4985753,525104,525004,21502739,529252,17306182,524289,21500723,21781062,16778207]

theorem envBound9827 : H12AffineFastState.Bounded env9827 := by
  intro p hp
  have h : env9827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9826_9827 : H12AffineEnvironment.transform 20 285200 env9826 = env9827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9826 == env9827) = true)

theorem identity9827 : scanCanonicalize (H12AffineFastState.compose env9827 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9827 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9828 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,372,524524,16777216,8329,16855853,791277,525104,525004,17308263,529252,17306182,524289,17306183,17586994,16778207]

theorem envBound9828 : H12AffineFastState.Bounded env9828 := by
  intro p hp
  have h : env9828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9827_9828 : H12AffineEnvironment.transform 21 372 env9827 = env9828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9827 == env9828) = true)

theorem identity9828 : scanCanonicalize (H12AffineFastState.compose env9828 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9828 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9829 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285200,372,524524,35,8329,78606,791277,525104,525004,531012,529252,528997,524289,528996,809745,1020]

theorem envBound9829 : H12AffineFastState.Bounded env9829 := by
  intro p hp
  have h : env9829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9828_9829 : H12AffineEnvironment.transform 23 35 env9828 = env9829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9828 == env9829) = true)

theorem identity9829 : scanCanonicalize (H12AffineFastState.compose env9829 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342726) := by decide +kernel

theorem selectedBound9829 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9830 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,342726,8693,285200,372,342570,35,8329,78606,75819,342518,342026,336002,338338,338083,342727,338082,90583,1020]

theorem envBound9830 : H12AffineFastState.Bounded env9830 := by
  intro p hp
  have h : env9830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9829_9830 : H12AffineEnvironment.transform 18 342726 env9829 = env9830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342726 env9829 == env9830) = true)

theorem identity9830 : scanCanonicalize (H12AffineFastState.compose env9830 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound9830 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9831 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,2421,78771,8693,21349,372,78687,35,8329,78606,75819,77955,78207,76279,73943,74198,78770,74199,90583,1020]

theorem envBound9831 : H12AffineFastState.Bounded env9831 := by
  intro p hp
  have h : env9831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9830_9831 : H12AffineEnvironment.transform 17 2421 env9830 = env9831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env9830 == env9831) = true)

theorem identity9831 : scanCanonicalize (H12AffineFastState.compose env9831 (packedSelected [3,4,5,6,7,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound9831 : packedSelected [3,4,5,6,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env9832 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,4373,8693,65536,4605,2421,78771,8693,624,372,78687,35,8329,78606,75819,77955,78207,76279,73943,74198,78770,74199,78018,1020]

theorem envBound9832 : H12AffineFastState.Bounded env9832 := by
  intro p hp
  have h : env9832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9831_9832 : H12AffineEnvironment.transform 13 4373 env9831 = env9832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env9831 == env9832) = true)

theorem identity9832 : scanCanonicalize (H12AffineFastState.compose env9832 (packedSelected [1,2,3,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 278) := by decide +kernel

theorem selectedBound9832 : packedSelected [1,2,3,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env9833 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,278,4373,227,65536,4605,2421,70309,227,624,372,70217,35,415,70168,67901,70037,69737,67809,65985,65728,70308,65729,70100,1020]

theorem envBound9833 : H12AffineFastState.Bounded env9833 := by
  intro p hp
  have h : env9833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9832_9833 : H12AffineEnvironment.transform 12 278 env9832 = env9833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 278 env9832 == env9833) = true)

theorem identity9833 : scanCanonicalize (H12AffineFastState.compose env9833 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound9833 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env9834 : List Nat := [2,4,8,16,32,64,128,256,512,257,523,4096,278,4373,227,65536,4605,894,70309,227,624,372,70217,35,415,70168,66358,70037,69737,66282,65985,65728,70308,65729,70100,1020]

theorem envBound9834 : H12AffineFastState.Bounded env9834 := by
  intro p hp
  have h : env9834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9833_9834 : H12AffineEnvironment.transform 10 523 env9833 = env9834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env9833 == env9834) = true)

theorem identity9834 : scanCanonicalize (H12AffineFastState.compose env9834 (packedSelected [1,6,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9834 : packedSelected [1,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9835 : List Nat := [2,4,8,16,32,64,40,256,512,257,523,4096,278,4373,75,65536,4437,894,70157,75,624,372,70217,35,311,70168,66358,69949,69737,66114,65897,65640,70156,65641,70012,852]

theorem envBound9835 : H12AffineFastState.Bounded env9835 := by
  intro p hp
  have h : env9835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9834_9835 : H12AffineEnvironment.transform 6 40 env9834 = env9835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9834 == env9835) = true)

theorem identity9835 : scanCanonicalize (H12AffineFastState.compose env9835 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9835 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env9836 : List Nat := [2,4,8,16,32,64,40,37,512,36,523,4096,51,4144,75,65536,4208,603,70157,75,624,81,70217,35,18,70168,66067,69656,69737,66114,65612,65640,70156,65641,69721,625]

theorem envBound9836 : H12AffineFastState.Bounded env9836 := by
  intro p hp
  have h : env9836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9835_9836 : H12AffineEnvironment.transform 7 37 env9835 = env9836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9835 == env9836) = true)

theorem identity9836 : scanCanonicalize (H12AffineFastState.compose env9836 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound9836 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9837 : List Nat := [2,4,8,16,32,64,40,37,512,36,523,4096,51,4144,75,82,4208,603,4703,75,624,81,4635,35,18,4682,577,4170,4155,528,30,58,4702,59,4107,625]

theorem envBound9837 : H12AffineFastState.Bounded env9837 := by
  intro p hp
  have h : env9837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9836_9837 : H12AffineEnvironment.transform 15 82 env9836 = env9837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env9836 == env9837) = true)

theorem identity9837 : scanCanonicalize (H12AffineFastState.compose env9837 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound9837 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9838 : List Nat := [2,4,8,16,32,64,40,37,512,36,523,529,51,545,75,82,609,603,78,75,624,81,10,35,18,91,577,603,554,528,30,58,79,59,538,625]

theorem envBound9838 : H12AffineFastState.Bounded env9838 := by
  intro p hp
  have h : env9838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9837_9838 : H12AffineEnvironment.transform 11 529 env9837 = env9838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env9837 == env9838) = true)

theorem identity9838 : scanCanonicalize (H12AffineFastState.compose env9838 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9838 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env9839 : List Nat := [2,4,8,16,32,49,40,37,512,36,523,529,51,545,58,35,528,554,63,58,513,32,10,35,18,42,560,554,554,528,30,58,62,59,538,512]

theorem envBound9839 : H12AffineFastState.Bounded env9839 := by
  intro p hp
  have h : env9839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9838_9839 : H12AffineEnvironment.transform 5 49 env9838 = env9839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9838 == env9839) = true)

theorem identity9839 : scanCanonicalize (H12AffineFastState.compose env9839 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound9839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9840 : List Nat := [2,4,8,16,32,49,40,37,33,36,42,48,51,0,58,35,49,11,63,58,32,32,10,35,18,42,17,11,11,49,30,58,62,59,59,33]

theorem envBound9840 : H12AffineFastState.Bounded env9840 := by
  intro p hp
  have h : env9840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9839_9840 : H12AffineEnvironment.transform 8 33 env9839 = env9840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9839 == env9840) = true)

def env9841 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,4194304,524524,16777216,8329,16855853,4985753,525104,525004,21502739,529252,17306182,524289,21500723,21781063,16778207]

theorem envBound9841 : H12AffineFastState.Bounded env9841 := by
  intro p hp
  have h : env9841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9826_9841 : H12AffineEnvironment.transform 20 285201 env9826 = env9841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9826 == env9841) = true)

theorem identity9841 : scanCanonicalize (H12AffineFastState.compose env9841 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9841 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9842 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,285201,477,524524,16777216,8329,16855853,791108,525104,525004,17308366,529252,17306182,524289,17306350,17587098,16778207]

theorem envBound9842 : H12AffineFastState.Bounded env9842 := by
  intro p hp
  have h : env9842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9841_9842 : H12AffineEnvironment.transform 21 477 env9841 = env9842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9841 == env9842) = true)

theorem identity9842 : scanCanonicalize (H12AffineFastState.compose env9842 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9842 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9843 : List Nat := [2,4,8,16,32,64,40,256,512,257,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,285201,373,524356,16777216,8225,16855853,791108,525104,524900,17308262,529252,17306182,524289,17306182,17586994,16778103]

theorem envBound9843 : H12AffineFastState.Bounded env9843 := by
  intro p hp
  have h : env9843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9842_9843 : H12AffineEnvironment.transform 6 40 env9842 = env9843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9842 == env9843) = true)

theorem identity9843 : scanCanonicalize (H12AffineFastState.compose env9843 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9843 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9844 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8201,65536,4097,262144,524288,8201,285201,33,524356,16777216,8225,16855673,791108,524900,524900,17308262,528944,17306182,524289,17306182,17586790,16777763]

theorem envBound9844 : H12AffineFastState.Bounded env9844 := by
  intro p hp
  have h : env9844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9843_9844 : H12AffineEnvironment.transform 7 84 env9843 = env9844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9843 == env9844) = true)

theorem identity9844 : scanCanonicalize (H12AffineFastState.compose env9844 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound9844 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9845 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8201,65536,4097,262144,78415,8201,285201,33,78347,16777216,8225,16855673,335883,77867,77867,16853033,73855,16850953,78414,16850953,17131561,16777763]

theorem envBound9845 : H12AffineFastState.Bounded env9845 := by
  intro p hp
  have h : env9845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9844_9845 : H12AffineEnvironment.transform 18 78415 env9844 = env9845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env9844 == env9845) = true)

theorem identity9845 : scanCanonicalize (H12AffineFastState.compose env9845 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336419) := by decide +kernel

theorem selectedBound9845 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9846 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8201,65536,4097,262144,78415,8201,285201,33,78347,336419,8225,266330,335883,77867,77867,264714,73855,262698,78414,262698,18954,335872]

theorem envBound9846 : H12AffineFastState.Bounded env9846 := by
  intro p hp
  have h : env9846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9845_9846 : H12AffineEnvironment.transform 23 336419 env9845 = env9846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336419 env9845 == env9846) = true)

theorem identity9846 : scanCanonicalize (H12AffineFastState.compose env9846 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16394) := by decide +kernel

theorem selectedBound9846 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9847 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8201,65536,4097,16394,78415,8201,6683,33,78347,90665,8225,20560,90113,77867,77867,18944,73855,16928,78414,16928,18954,90122]

theorem envBound9847 : H12AffineFastState.Bounded env9847 := by
  intro p hp
  have h : env9847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9846_9847 : H12AffineEnvironment.transform 17 16394 env9846 = env9847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16394 env9846 == env9847) = true)

theorem identity9847 : scanCanonicalize (H12AffineFastState.compose env9847 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14401) := by decide +kernel

theorem selectedBound9847 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9848 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,16384,8201,14401,4097,16394,2574,8201,6683,33,2634,23144,8225,20560,22592,2154,2154,18944,6206,16928,2575,16928,18954,22603]

theorem envBound9848 : H12AffineFastState.Bounded env9848 := by
  intro p hp
  have h : env9848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9847_9848 : H12AffineEnvironment.transform 15 14401 env9847 = env9848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14401 env9847 == env9848) = true)

theorem identity9848 : scanCanonicalize (H12AffineFastState.compose env9848 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound9848 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9849 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,8192,8744,8201,14401,4097,8738,2574,8201,6683,33,2634,14400,8225,12920,14952,2154,2154,10280,6206,8200,2575,8200,10274,14947]

theorem envBound9849 : H12AffineFastState.Bounded env9849 := by
  intro p hp
  have h : env9849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9848_9849 : H12AffineEnvironment.transform 13 8744 env9848 = env9849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env9848 == env9849) = true)

theorem identity9849 : scanCanonicalize (H12AffineFastState.compose env9849 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6243) := by decide +kernel

theorem selectedBound9849 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9850 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,4096,6243,6731,6250,34,4097,6721,2574,6250,6683,33,2634,35,6210,2587,523,2154,2154,4171,6206,6251,2575,6251,4161,512]

theorem envBound9850 : H12AffineFastState.Bounded env9850 := by
  intro p hp
  have h : env9850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9849_9850 : H12AffineEnvironment.transform 12 6243 env9849 = env9850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6243 env9849 == env9850) = true)

theorem identity9850 : scanCanonicalize (H12AffineFastState.compose env9850 (packedSelected [0,1,2,4,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 608) := by decide +kernel

theorem selectedBound9850 : packedSelected [0,1,2,4,5,13] rootPS < 2^1333 := by decide +kernel

def env9851 : List Nat := [2,4,8,16,32,64,40,84,512,85,2048,608,2563,2091,2570,34,609,2081,2574,2570,2171,33,2634,35,2594,2587,523,2154,2154,555,2654,2571,2575,2571,545,512]

theorem envBound9851 : H12AffineFastState.Bounded env9851 := by
  intro p hp
  have h : env9851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9850_9851 : H12AffineEnvironment.transform 11 608 env9850 = env9851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 608 env9850 == env9851) = true)

def env9852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525568,6531129661,34359738368,59279183]

theorem envBound9852 : H12AffineFastState.Bounded env9852 := by
  intro p hp
  have h : env9852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3_9852 : H12AffineEnvironment.transform 19 32769 env3 = env9852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32769 env3 == env9852) = true)

theorem identity9852 : scanCanonicalize (H12AffineFastState.compose env9852 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9852 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env9853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525568,6531129661,34359738368,25733063]

theorem envBound9853 : H12AffineFastState.Bounded env9853 := by
  intro p hp
  have h : env9853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9852_9853 : H12AffineEnvironment.transform 24 8328 env9852 = env9853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9852 == env9853) = true)

theorem identity9853 : scanCanonicalize (H12AffineFastState.compose env9853 (packedSelected [6,25] rootPS)) = affineNative (2^(30+1) ^^^ 92374097) := by decide +kernel

theorem selectedBound9853 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374097,4294967296,525568,4308116844,34359738368,25733063]

theorem envBound9854 : H12AffineFastState.Bounded env9854 := by
  intro p hp
  have h : env9854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9853_9854 : H12AffineEnvironment.transform 30 92374097 env9853 = env9854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 92374097 env9853 == env9854) = true)

def env9855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374097,4294967296,525568,4308116844,620851224,25733063]

theorem envBound9855 : H12AffineFastState.Bounded env9855 := by
  intro p hp
  have h : env9855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9854_9855 : H12AffineEnvironment.transform 34 620851224 env9854 = env9855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 620851224 env9854 == env9855) = true)

def env9856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,536870912,1073741824,92374097,4294967296,525568,4308116844,620851224,25733063]

theorem envBound9856 : H12AffineFastState.Bounded env9856 := by
  intro p hp
  have h : env9856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9855_9856 : H12AffineEnvironment.transform 27 19497100 env9855 = env9856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497100 env9855 == env9856) = true)

def env9857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374097,4294967296,525568,4308116844,27337992,25733063]

theorem envBound9857 : H12AffineFastState.Bounded env9857 := by
  intro p hp
  have h : env9857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9856_9857 : H12AffineEnvironment.transform 28 77616400 env9856 = env9857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env9856 == env9857) = true)

def env9858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound9858 : H12AffineFastState.Bounded env9858 := by
  intro p hp
  have h : env9858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9857_9858 : H12AffineEnvironment.transform 31 145662400 env9857 = env9858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env9857 == env9858) = true)

def env9859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound9859 : H12AffineFastState.Bounded env9859 := by
  intro p hp
  have h : env9859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9858_9859 : H12AffineEnvironment.transform 29 155254784 env9858 = env9859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env9858 == env9859) = true)

def env9860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound9860 : H12AffineFastState.Bounded env9860 := by
  intro p hp
  have h : env9860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9859_9860 : H12AffineEnvironment.transform 25 64 env9859 = env9860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env9859 == env9860) = true)

def env9861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound9861 : H12AffineFastState.Bounded env9861 := by
  intro p hp
  have h : env9861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9860_9861 : H12AffineEnvironment.transform 26 30393344 env9860 = env9861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env9860 == env9861) = true)

def env9862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound9862 : H12AffineFastState.Bounded env9862 := by
  intro p hp
  have h : env9862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9861_9862 : H12AffineEnvironment.transform 18 1024 env9861 = env9862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9861 == env9862) = true)

theorem identity9862 : scanCanonicalize (H12AffineFastState.compose env9862 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2213006) := by decide +kernel

theorem selectedBound9862 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env9863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2213006,16777216,8328,64,23463054,18973836,102878,2557070,18890911,23160256,256,16777250,16834950,18966345]

theorem envBound9863 : H12AffineFastState.Bounded env9863 := by
  intro p hp
  have h : env9863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9862_9863 : H12AffineEnvironment.transform 22 2213006 env9862 = env9863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2213006 env9862 == env9863) = true)

def env9864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411540,2213006,16777216,8328,64,16959642,18973836,102878,2557070,18890911,17148372,256,16777250,16834950,18966345]

theorem envBound9864 : H12AffineFastState.Bounded env9864 := by
  intro p hp
  have h : env9864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9863_9864 : H12AffineEnvironment.transform 21 2411540 env9863 = env9864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411540 env9863 == env9864) = true)

theorem identity9864 : scanCanonicalize (H12AffineFastState.compose env9864 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound9864 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env9865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,329866,16,16777216,8328,64,16959642,16793618,102878,442384,16876545,17148372,256,16777250,16834950,16819159]

theorem envBound9865 : H12AffineFastState.Bounded env9865 := by
  intro p hp
  have h : env9865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9864_9865 : H12AffineEnvironment.transform 20 115870 env9864 = env9865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env9864 == env9865) = true)

def env9866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,329866,16,95496,8328,64,245138,79130,102878,442384,61705,318684,256,95530,103566,120543]

theorem envBound9866 : H12AffineFastState.Bounded env9866 := by
  intro p hp
  have h : env9866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9865_9866 : H12AffineEnvironment.transform 23 95496 env9865 = env9866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env9865 == env9866) = true)

theorem identity9866 : scanCanonicalize (H12AffineFastState.compose env9866 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound9866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env9867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,318548,16,41430,8328,64,158028,57796,17664,442384,61705,318684,256,41460,16464,513]

theorem envBound9867 : H12AffineFastState.Bounded env9867 := by
  intro p hp
  have h : env9867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9866_9867 : H12AffineEnvironment.transform 15 54494 env9866 = env9867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env9866 == env9867) = true)

def env9868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,318548,16,41310,8192,64,158028,57676,17664,442384,61705,318548,256,41340,16464,513]

theorem envBound9868 : H12AffineFastState.Bounded env9868 := by
  intro p hp
  have h : env9868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9867_9868 : H12AffineEnvironment.transform 6 8 env9867 = env9868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9867 == env9868) = true)

theorem identity9868 : scanCanonicalize (H12AffineFastState.compose env9868 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound9868 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,131072,262144,1024,8541,4160,294152,16,2,8192,64,158028,16400,17664,418124,20565,294152,256,32,16464,513]

theorem envBound9869 : H12AffineFastState.Bounded env9869 := by
  intro p hp
  have h : env9869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9868_9869 : H12AffineEnvironment.transform 14 8540 env9868 = env9869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env9868 == env9869) = true)

theorem identity9869 : scanCanonicalize (H12AffineFastState.compose env9869 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound9869 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9870 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,131072,262144,272,8541,4160,292888,16,2,8192,64,158028,16400,16400,418124,20565,292888,256,32,16464,513]

theorem envBound9870 : H12AffineFastState.Bounded env9870 := by
  intro p hp
  have h : env9870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9869_9870 : H12AffineEnvironment.transform 9 272 env9869 = env9870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env9869 == env9870) = true)

theorem identity9870 : scanCanonicalize (H12AffineFastState.compose env9870 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound9870 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env9871 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,4096,262144,272,8541,4160,292888,16,2,8192,64,31052,16400,16400,291148,20565,292888,256,32,16464,513]

theorem envBound9871 : H12AffineFastState.Bounded env9871 := by
  intro p hp
  have h : env9871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9870_9871 : H12AffineEnvironment.transform 16 4096 env9870 = env9871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env9870 == env9871) = true)

theorem identity9871 : scanCanonicalize (H12AffineFastState.compose env9871 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound9871 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9872 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28698,4096,2420,272,8541,4160,29036,16,2,8192,64,31052,16400,16400,30776,20565,29036,256,32,16464,513]

theorem envBound9872 : H12AffineFastState.Bounded env9872 := by
  intro p hp
  have h : env9872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9871_9872 : H12AffineEnvironment.transform 17 2420 env9871 = env9872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env9871 == env9872) = true)

theorem identity9872 : scanCanonicalize (H12AffineFastState.compose env9872 (packedSelected [1,2,5,6,8,12,15,24] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9872 : packedSelected [1,2,5,6,8,12,15,24] rootPS < 2^1333 := by decide +kernel

def env9873 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,8192,16384,8313,28698,4096,2129,53,8312,4160,28745,16,2,8192,64,30825,16400,16400,30776,20565,28745,37,32,16464,513]

theorem envBound9873 : H12AffineFastState.Bounded env9873 := by
  intro p hp
  have h : env9873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9872_9873 : H12AffineEnvironment.transform 7 37 env9872 = env9873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9872 == env9873) = true)

theorem identity9873 : scanCanonicalize (H12AffineFastState.compose env9873 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound9873 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env9874 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,8192,4161,8313,8283,4096,2129,53,8312,4160,8200,16,2,8192,64,10280,4177,4177,10361,20,8200,37,32,4113,513]

theorem envBound9874 : H12AffineFastState.Bounded env9874 := by
  intro p hp
  have h : env9874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9873_9874 : H12AffineEnvironment.transform 13 4161 env9873 = env9874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env9873 == env9874) = true)

theorem identity9874 : scanCanonicalize (H12AffineFastState.compose env9874 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound9874 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env9875 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,40,4161,81,115,4096,2129,53,80,4160,32,16,2,40,64,2048,4177,4177,2129,20,32,37,32,4113,513]

theorem envBound9875 : H12AffineFastState.Bounded env9875 := by
  intro p hp
  have h : env9875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9874_9875 : H12AffineEnvironment.transform 12 40 env9874 = env9875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env9874 == env9875) = true)

theorem identity9875 : scanCanonicalize (H12AffineFastState.compose env9875 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound9875 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env9876 : List Nat := [2,4,8,16,32,64,8,37,512,53,48,4096,40,4161,81,115,4096,97,53,80,4160,32,16,2,40,64,48,4177,4177,97,20,32,37,32,4113,513]

theorem envBound9876 : H12AffineFastState.Bounded env9876 := by
  intro p hp
  have h : env9876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9875_9876 : H12AffineEnvironment.transform 10 48 env9875 = env9876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env9875 == env9876) = true)

theorem identity9876 : scanCanonicalize (H12AffineFastState.compose env9876 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound9876 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env9877 : List Nat := [2,4,8,16,32,32,8,37,512,53,48,4096,40,4129,49,19,4096,1,53,48,4128,32,16,2,40,32,48,4145,4145,1,20,32,37,32,4113,513]

theorem envBound9877 : H12AffineFastState.Bounded env9877 := by
  intro p hp
  have h : env9877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9876_9877 : H12AffineEnvironment.transform 5 32 env9876 = env9877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env9876 == env9877) = true)

theorem identity9877 : scanCanonicalize (H12AffineFastState.compose env9877 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9877 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env9878 : List Nat := [2,4,8,16,1,1,8,4,512,20,17,4096,9,4096,16,19,4096,1,20,17,4097,1,16,2,9,1,17,4112,4112,1,20,1,4,1,4113,513]

theorem envBound9878 : H12AffineFastState.Bounded env9878 := by
  intro p hp
  have h : env9878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9877_9878 : H12AffineEnvironment.transform 4 1 env9877 = env9878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9877 == env9878) = true)

def env9879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,318548,16,41311,8193,64,158028,57677,17664,442384,61705,318549,256,41341,16464,513]

theorem envBound9879 : H12AffineFastState.Bounded env9879 := by
  intro p hp
  have h : env9879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9867_9879 : H12AffineEnvironment.transform 6 9 env9867 = env9879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9867 == env9879) = true)

def env9880 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,318468,16,41231,8193,16,157980,57629,17664,442384,61705,318469,256,41261,16384,513]

theorem envBound9880 : H12AffineFastState.Bounded env9880 := by
  intro p hp
  have h : env9880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9879_9880 : H12AffineEnvironment.transform 5 16 env9879 = env9880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9879 == env9880) = true)

theorem identity9880 : scanCanonicalize (H12AffineFastState.compose env9880 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound9880 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9881 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,179512,1024,32769,4112,155964,16,41231,8193,16,157980,57629,17664,32040,61705,155965,256,41261,16384,513]

theorem envBound9881 : H12AffineFastState.Bounded env9881 := by
  intro p hp
  have h : env9881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9880_9881 : H12AffineEnvironment.transform 17 179512 env9880 = env9881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env9880 == env9881) = true)

theorem identity9881 : scanCanonicalize (H12AffineFastState.compose env9881 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound9881 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env9882 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,24860,56356,1024,32769,4112,32,16,41231,8193,16,2048,57629,17664,32040,61705,33,256,41261,16384,513]

theorem envBound9882 : H12AffineFastState.Bounded env9882 := by
  intro p hp
  have h : env9882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9881_9882 : H12AffineEnvironment.transform 16 24860 env9881 = env9882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env9881 == env9882) = true)

theorem identity9882 : scanCanonicalize (H12AffineFastState.compose env9882 (packedSelected [0,1,7,8,12,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound9882 : packedSelected [0,1,7,8,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env9883 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,262,24860,2341,1024,21760,4112,32,16,29710,8193,16,2048,13340,17664,32040,9224,33,256,29740,16384,513]

theorem envBound9883 : H12AffineFastState.Bounded env9883 := by
  intro p hp
  have h : env9883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9882_9883 : H12AffineEnvironment.transform 14 21761 env9882 = env9883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env9882 == env9883) = true)

theorem identity9883 : scanCanonicalize (H12AffineFastState.compose env9883 (packedSelected [0,3,5,6,7,18] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound9883 : packedSelected [0,3,5,6,7,18] rootPS < 2^1333 := by decide +kernel

def env9884 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,6161,3344,262,14605,2341,1024,3345,4112,32,16,11295,8193,16,2048,13340,7441,9529,9224,33,256,11325,6161,513]

theorem envBound9884 : H12AffineFastState.Bounded env9884 := by
  intro p hp
  have h : env9884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9883_9884 : H12AffineEnvironment.transform 13 6161 env9883 = env9884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env9883 == env9884) = true)

theorem identity9884 : scanCanonicalize (H12AffineFastState.compose env9884 (packedSelected [2,3,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound9884 : packedSelected [2,3,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env9885 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,6161,3344,262,6145,2341,1024,3345,4112,32,16,3347,269,16,2048,5392,7441,1077,1284,33,256,3377,6161,513]

theorem envBound9885 : H12AffineFastState.Bounded env9885 := by
  intro p hp
  have h : env9885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9884_9885 : H12AffineEnvironment.transform 12 268 env9884 = env9885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env9884 == env9885) = true)

theorem identity9885 : scanCanonicalize (H12AffineFastState.compose env9885 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9885 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env9886 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,6161,3124,34,6145,2049,1024,3125,4112,32,16,3127,41,16,2048,5172,7221,1077,1056,33,36,3093,6161,513]

theorem envBound9886 : H12AffineFastState.Bounded env9886 := by
  intro p hp
  have h : env9886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9885_9886 : H12AffineEnvironment.transform 7 36 env9885 = env9886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9885 == env9886) = true)

theorem identity9886 : scanCanonicalize (H12AffineFastState.compose env9886 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound9886 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9887 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,40,6161,2048,34,6145,2049,52,2049,4112,32,16,2051,41,16,2048,4096,6145,1,20,33,36,2081,6161,513]

theorem envBound9887 : H12AffineFastState.Bounded env9887 := by
  intro p hp
  have h : env9887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9886_9887 : H12AffineEnvironment.transform 9 52 env9886 = env9887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env9886 == env9887) = true)

theorem identity9887 : scanCanonicalize (H12AffineFastState.compose env9887 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound9887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9888 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,4096,40,4112,1,34,4096,0,52,0,4112,32,16,2,41,16,1,4096,4096,1,20,33,36,32,4112,513]

theorem envBound9888 : H12AffineFastState.Bounded env9888 := by
  intro p hp
  have h : env9888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9887_9888 : H12AffineEnvironment.transform 10 1 env9887 = env9888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9887 == env9888) = true)

theorem identity9888 : scanCanonicalize (H12AffineFastState.compose env9888 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound9888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9889 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,49,40,33,1,34,49,0,52,0,33,32,16,2,41,16,1,49,49,1,20,33,36,32,33,513]

theorem envBound9889 : H12AffineFastState.Bounded env9889 := by
  intro p hp
  have h : env9889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9888_9889 : H12AffineEnvironment.transform 11 49 env9888 = env9889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env9888 == env9889) = true)

theorem identity9889 : scanCanonicalize (H12AffineFastState.compose env9889 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9890 : List Nat := [2,4,8,0,32,0,9,36,512,36,1,33,40,33,1,34,33,0,36,0,33,32,0,2,41,0,1,33,33,1,4,33,36,32,33,513]

theorem envBound9890 : H12AffineFastState.Bounded env9890 := by
  intro p hp
  have h : env9890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9889_9890 : H12AffineEnvironment.transform 3 0 env9889 = env9890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9889 == env9890) = true)

theorem identity9890 : scanCanonicalize (H12AffineFastState.compose env9890 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9890 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9891 : List Nat := [2,4,8,0,1,0,9,5,512,5,1,0,9,0,1,3,0,0,5,0,0,1,0,2,8,0,1,0,0,1,4,0,5,1,0,513]

theorem envBound9891 : H12AffineFastState.Bounded env9891 := by
  intro p hp
  have h : env9891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9890_9891 : H12AffineEnvironment.transform 4 1 env9890 = env9891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9890 == env9891) = true)

def env9892 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,318469,16,41230,8193,17,157981,57628,17664,442384,61705,318468,256,41260,16385,513]

theorem envBound9892 : H12AffineFastState.Bounded env9892 := by
  intro p hp
  have h : env9892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9879_9892 : H12AffineEnvironment.transform 5 17 env9879 = env9892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9879 == env9892) = true)

theorem identity9892 : scanCanonicalize (H12AffineFastState.compose env9892 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound9892 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9893 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,149813,1024,32769,4113,169264,16,41230,8193,17,157981,57628,17664,35109,61705,169265,256,41260,16385,513]

theorem envBound9893 : H12AffineFastState.Bounded env9893 := by
  intro p hp
  have h : env9893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9892_9893 : H12AffineEnvironment.transform 17 149813 env9892 = env9893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env9892 == env9893) = true)

theorem identity9893 : scanCanonicalize (H12AffineFastState.compose env9893 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound9893 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env9894 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29962,131072,149813,1024,8461,4113,144444,16,2,8193,17,157981,16400,17664,10281,20485,144445,256,32,16385,513]

theorem envBound9894 : H12AffineFastState.Bounded env9894 := by
  intro p hp
  have h : env9894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9893_9894 : H12AffineEnvironment.transform 14 8460 env9893 = env9894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env9893 == env9894) = true)

theorem identity9894 : scanCanonicalize (H12AffineFastState.compose env9894 (packedSelected [1,3,8,10,12,15,24] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound9894 : packedSelected [1,3,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env9895 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29962,5392,23589,1024,8461,4113,8492,16,2,8193,17,31757,16400,17664,10281,20485,8493,256,32,16385,513]

theorem envBound9895 : H12AffineFastState.Bounded env9895 := by
  intro p hp
  have h : env9895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9894_9895 : H12AffineEnvironment.transform 16 5392 env9894 = env9895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env9894 == env9895) = true)

theorem identity9895 : scanCanonicalize (H12AffineFastState.compose env9895 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound9895 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env9896 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,21510,5392,23589,1024,1,4113,32,16,2,269,17,23809,16400,17664,2341,20485,33,256,32,16385,513]

theorem envBound9896 : H12AffineFastState.Bounded env9896 := by
  intro p hp
  have h : env9896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9895_9896 : H12AffineEnvironment.transform 12 268 env9895 = env9896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env9895 == env9896) = true)

theorem identity9896 : scanCanonicalize (H12AffineFastState.compose env9896 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9896 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9897 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,16384,0,21510,5173,23589,1024,1,4113,32,16,2,40,17,23588,16400,17445,2048,20485,33,37,32,16385,513]

theorem envBound9897 : H12AffineFastState.Bounded env9897 := by
  intro p hp
  have h : env9897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9896_9897 : H12AffineEnvironment.transform 7 37 env9896 = env9897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9896 == env9897) = true)

theorem identity9897 : scanCanonicalize (H12AffineFastState.compose env9897 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound9897 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env9898 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,0,34,5173,2049,1024,1,4113,32,16,2,40,17,2048,5172,4097,2048,1057,33,37,32,5157,513]

theorem envBound9898 : H12AffineFastState.Bounded env9898 := by
  intro p hp
  have h : env9898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9897_9898 : H12AffineEnvironment.transform 13 5156 env9897 = env9898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env9897 == env9898) = true)

theorem identity9898 : scanCanonicalize (H12AffineFastState.compose env9898 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9899 : List Nat := [2,4,8,0,32,1,9,37,512,1024,2048,4096,41,5156,0,34,5157,2049,1024,1,4097,32,0,2,40,1,2048,5156,4097,2048,1057,33,37,32,5157,513]

theorem envBound9899 : H12AffineFastState.Bounded env9899 := by
  intro p hp
  have h : env9899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9898_9899 : H12AffineEnvironment.transform 3 0 env9898 = env9899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9898 == env9899) = true)

theorem identity9899 : scanCanonicalize (H12AffineFastState.compose env9899 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound9899 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9900 : List Nat := [2,4,8,0,32,1,9,37,512,1024,2048,513,41,1573,0,34,1572,2049,1024,1,512,32,0,2,40,1,2048,1573,512,2048,1057,33,37,32,1572,513]

theorem envBound9900 : H12AffineFastState.Bounded env9900 := by
  intro p hp
  have h : env9900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9899_9900 : H12AffineEnvironment.transform 11 513 env9899 = env9900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env9899 == env9900) = true)

theorem identity9900 : scanCanonicalize (H12AffineFastState.compose env9900 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound9900 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9901 : List Nat := [2,4,8,0,32,1,9,37,512,1024,513,513,41,1573,0,34,1572,512,1024,1,512,32,0,2,40,1,513,1573,512,513,1057,33,37,32,1572,513]

theorem envBound9901 : H12AffineFastState.Bounded env9901 := by
  intro p hp
  have h : env9901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9900_9901 : H12AffineEnvironment.transform 10 513 env9900 = env9901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env9900 == env9901) = true)

theorem identity9901 : scanCanonicalize (H12AffineFastState.compose env9901 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound9901 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env9902 : List Nat := [2,4,8,0,32,1,9,37,512,36,513,513,41,513,0,34,512,512,36,1,512,32,0,2,40,1,513,513,512,513,5,33,37,32,512,513]

theorem envBound9902 : H12AffineFastState.Bounded env9902 := by
  intro p hp
  have h : env9902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9901_9902 : H12AffineEnvironment.transform 9 36 env9901 = env9902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env9901 == env9902) = true)

theorem identity9902 : scanCanonicalize (H12AffineFastState.compose env9902 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9903 : List Nat := [2,4,8,0,10,1,9,15,512,14,513,513,3,513,0,8,512,512,14,1,512,10,0,2,2,1,513,513,512,513,5,11,15,10,512,513]

theorem envBound9903 : H12AffineFastState.Bounded env9903 := by
  intro p hp
  have h : env9903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9902_9903 : H12AffineEnvironment.transform 4 10 env9902 = env9903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9902 == env9903) = true)

def env9904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,329866,16,95497,8328,64,245139,79131,102878,442384,61704,318685,256,95531,103567,120542]

theorem envBound9904 : H12AffineFastState.Bounded env9904 := by
  intro p hp
  have h : env9904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9865_9904 : H12AffineEnvironment.transform 23 95497 env9865 = env9904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env9865 == env9904) = true)

def env9905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,329730,16,95497,8192,64,245019,79131,102742,442384,61704,318549,256,95531,103431,120406]

theorem envBound9905 : H12AffineFastState.Bounded env9905 := by
  intro p hp
  have h : env9905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9904_9905 : H12AffineEnvironment.transform 6 8 env9904 = env9905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9904 == env9905) = true)

theorem identity9905 : scanCanonicalize (H12AffineFastState.compose env9905 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound9905 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,45341,294153,16,2,8192,64,182288,16400,58461,442384,61704,318549,256,32,57612,41821]

theorem envBound9906 : H12AffineFastState.Bounded env9906 := by
  intro p hp
  have h : env9906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9905_9906 : H12AffineEnvironment.transform 15 29963 env9905 = env9906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env9905 == env9906) = true)

def env9907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16400,262144,1024,32769,45341,294153,16,2,8192,64,34816,16400,58461,294912,61704,318549,256,32,57612,41821]

theorem envBound9907 : H12AffineFastState.Bounded env9907 := by
  intro p hp
  have h : env9907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9906_9907 : H12AffineEnvironment.transform 16 16400 env9906 = env9907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env9906 == env9907) = true)

theorem identity9907 : scanCanonicalize (H12AffineFastState.compose env9907 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound9907 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env9908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16400,64809,1024,32769,45341,32800,16,2,8192,64,34816,16400,58461,32041,61704,8572,256,32,57612,41821]

theorem envBound9908 : H12AffineFastState.Bounded env9908 := by
  intro p hp
  have h : env9908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9907_9908 : H12AffineEnvironment.transform 17 64809 env9907 = env9908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env9907 == env9908) = true)

theorem identity9908 : scanCanonicalize (H12AffineFastState.compose env9908 (packedSelected [4,5,9,12,14,15,16,18,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound9908 : packedSelected [4,5,9,12,14,15,16,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env9909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,29963,16400,23809,1024,8233,4405,8200,16,2,8192,64,10280,16400,17525,32041,20768,8572,256,32,16676,885]

theorem envBound9909 : H12AffineFastState.Bounded env9909 := by
  intro p hp
  have h : env9909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9908_9909 : H12AffineEnvironment.transform 14 8232 env9908 = env9909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env9908 == env9909) = true)

theorem identity9909 : scanCanonicalize (H12AffineFastState.compose env9909 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound9909 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env9910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8232,8202,5393,2048,1024,8233,4405,8200,16,2,8192,64,10280,5393,4468,10280,1057,8572,256,32,5157,885]

theorem envBound9910 : H12AffineFastState.Bounded env9910 := by
  intro p hp
  have h : env9910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9909_9910 : H12AffineEnvironment.transform 13 5377 env9909 = env9910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env9909 == env9910) = true)

theorem identity9910 : scanCanonicalize (H12AffineFastState.compose env9910 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9910 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env9911 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8232,8202,5172,2048,1024,8233,4112,8200,16,2,8192,64,10280,5172,4177,10280,1057,8281,37,32,5157,592]

theorem envBound9911 : H12AffineFastState.Bounded env9911 := by
  intro p hp
  have h : env9911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9910_9911 : H12AffineEnvironment.transform 7 37 env9910 = env9911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9910 == env9911) = true)

theorem identity9911 : scanCanonicalize (H12AffineFastState.compose env9911 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound9911 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env9912 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,1100,5156,1124,1094,5172,2048,1024,1125,4112,1092,16,2,1100,64,3172,5172,4177,3172,1057,1045,37,32,5157,592]

theorem envBound9912 : H12AffineFastState.Bounded env9912 := by
  intro p hp
  have h : env9912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9911_9912 : H12AffineEnvironment.transform 12 1100 env9911 = env9912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env9911 == env9912) = true)

theorem identity9912 : scanCanonicalize (H12AffineFastState.compose env9912 (packedSelected [2,4,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9912 : packedSelected [2,4,9,14] rootPS < 2^1333 := by decide +kernel

def env9913 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,1052,5156,1076,1046,5172,2048,1024,1077,4112,1044,16,2,1052,16,3124,5172,4097,3124,1057,1045,37,32,5157,512]

theorem envBound9913 : H12AffineFastState.Bounded env9913 := by
  intro p hp
  have h : env9913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9912_9913 : H12AffineEnvironment.transform 5 16 env9912 = env9913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9912 == env9913) = true)

theorem identity9913 : scanCanonicalize (H12AffineFastState.compose env9913 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound9913 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9914 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1044,1052,48,1076,1046,32,2048,1024,1077,1028,1044,16,2,1052,16,3124,32,1045,3124,1057,1045,37,32,49,512]

theorem envBound9914 : H12AffineFastState.Bounded env9914 := by
  intro p hp
  have h : env9914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9913_9914 : H12AffineEnvironment.transform 11 1044 env9913 = env9914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env9913 == env9914) = true)

theorem identity9914 : scanCanonicalize (H12AffineFastState.compose env9914 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound9914 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9915 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1055,1044,1052,48,1076,1046,32,1055,1024,1077,1028,1044,16,2,1052,16,43,32,1045,43,1057,1045,37,32,49,512]

theorem envBound9915 : H12AffineFastState.Bounded env9915 := by
  intro p hp
  have h : env9915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9914_9915 : H12AffineEnvironment.transform 10 1055 env9914 = env9915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env9914 == env9915) = true)

theorem identity9915 : scanCanonicalize (H12AffineFastState.compose env9915 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 534) := by decide +kernel

theorem selectedBound9915 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env9916 : List Nat := [2,4,8,16,32,16,8,37,512,534,521,514,522,48,546,512,32,521,534,547,530,514,16,2,522,16,43,32,515,43,567,515,37,32,49,512]

theorem envBound9916 : H12AffineFastState.Bounded env9916 := by
  intro p hp
  have h : env9916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9915_9916 : H12AffineEnvironment.transform 9 534 env9915 = env9916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 534 env9915 == env9916) = true)

theorem identity9916 : scanCanonicalize (H12AffineFastState.compose env9916 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound9916 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9917 : List Nat := [2,4,8,16,32,16,8,37,2,20,11,0,8,48,32,2,32,11,20,33,16,0,16,2,8,16,43,32,1,43,53,1,37,32,49,2]

theorem envBound9917 : H12AffineFastState.Bounded env9917 := by
  intro p hp
  have h : env9917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9916_9917 : H12AffineEnvironment.transform 8 2 env9916 = env9917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env9916 == env9917) = true)

theorem identity9917 : scanCanonicalize (H12AffineFastState.compose env9917 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9917 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env9918 : List Nat := [2,4,8,16,0,16,8,5,2,20,11,0,8,16,0,2,0,11,20,1,16,0,16,2,8,16,11,0,1,11,21,1,5,0,17,2]

theorem envBound9918 : H12AffineFastState.Bounded env9918 := by
  intro p hp
  have h : env9918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9917_9918 : H12AffineEnvironment.transform 4 0 env9917 = env9918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9917 == env9918) = true)

theorem identity9918 : scanCanonicalize (H12AffineFastState.compose env9918 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound9918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9919 : List Nat := [2,4,8,14,0,14,8,5,2,10,11,0,8,14,0,2,0,11,10,1,14,0,14,2,8,14,11,0,1,11,11,1,5,0,15,2]

theorem envBound9919 : H12AffineFastState.Bounded env9919 := by
  intro p hp
  have h : env9919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9918_9919 : H12AffineEnvironment.transform 3 14 env9918 = env9919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env9918 == env9919) = true)

theorem identity9919 : scanCanonicalize (H12AffineFastState.compose env9919 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound9919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9920 : List Nat := [2,4,6,0,0,0,6,5,2,4,5,0,6,0,0,2,0,5,4,1,0,0,0,2,6,0,5,0,1,5,5,1,5,0,1,2]

theorem envBound9920 : H12AffineFastState.Bounded env9920 := by
  intro p hp
  have h : env9920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9919_9920 : H12AffineEnvironment.transform 2 6 env9919 = env9920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env9919 == env9920) = true)

theorem identity9920 : scanCanonicalize (H12AffineFastState.compose env9920 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9920 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9921 : List Nat := [2,1,3,0,0,0,3,0,2,1,0,0,3,0,0,2,0,0,1,1,0,0,0,2,3,0,0,0,1,0,0,1,0,0,1,2]

theorem envBound9921 : H12AffineFastState.Bounded env9921 := by
  intro p hp
  have h : env9921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9920_9921 : H12AffineEnvironment.transform 1 1 env9920 = env9921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9920 == env9921) = true)

def env9922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16401,262144,1024,32769,45341,294153,16,2,8192,64,34817,16400,58461,294913,61704,318549,256,32,57612,41821]

theorem envBound9922 : H12AffineFastState.Bounded env9922 := by
  intro p hp
  have h : env9922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9906_9922 : H12AffineEnvironment.transform 16 16401 env9906 = env9922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env9906 == env9922) = true)

theorem identity9922 : scanCanonicalize (H12AffineFastState.compose env9922 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound9922 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env9923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16401,43048,1024,32769,45341,54561,16,2,8192,64,34817,16400,58461,10281,61704,29821,256,32,57612,41821]

theorem envBound9923 : H12AffineFastState.Bounded env9923 := by
  intro p hp
  have h : env9923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9922_9923 : H12AffineEnvironment.transform 17 43048 env9922 = env9923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env9922 == env9923) = true)

theorem identity9923 : scanCanonicalize (H12AffineFastState.compose env9923 (packedSelected [1,3,5,7,12,14,15,16,18,19,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound9923 : packedSelected [1,3,5,7,12,14,15,16,18,19,23,27,28] rootPS < 2^1333 := by decide +kernel

def env9924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,29963,16401,2049,1024,8232,4404,29960,16,2,8192,64,10280,16400,17524,10281,20769,29821,256,32,16677,884]

theorem envBound9924 : H12AffineFastState.Bounded env9924 := by
  intro p hp
  have h : env9924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9923_9924 : H12AffineEnvironment.transform 14 8233 env9923 = env9924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env9923 == env9924) = true)

theorem identity9924 : scanCanonicalize (H12AffineFastState.compose env9924 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound9924 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env9925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,8574,5220,2049,1024,8232,4404,8573,16,2,8192,64,10280,5221,4097,10281,1364,8200,256,32,5456,884]

theorem envBound9925 : H12AffineFastState.Bounded env9925 := by
  intro p hp
  have h : env9925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9924_9925 : H12AffineEnvironment.transform 13 5237 env9924 = env9925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env9924 == env9925) = true)

theorem identity9925 : scanCanonicalize (H12AffineFastState.compose env9925 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound9925 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env9926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,372,35,5220,2049,1024,373,4404,32,16,2,349,64,2421,5221,4097,2420,1364,341,256,32,5456,884]

theorem envBound9926 : H12AffineFastState.Bounded env9926 := by
  intro p hp
  have h : env9926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9925_9926 : H12AffineEnvironment.transform 12 349 env9925 = env9926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env9925 == env9926) = true)

theorem identity9926 : scanCanonicalize (H12AffineFastState.compose env9926 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound9926 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env9927 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,0,35,5220,2049,1024,1,4160,32,16,2,41,64,2049,5221,4097,2048,1056,33,116,32,5156,512]

theorem envBound9927 : H12AffineFastState.Bounded env9927 := by
  intro p hp
  have h : env9927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9926_9927 : H12AffineEnvironment.transform 7 116 env9926 = env9927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env9926 == env9927) = true)

theorem identity9927 : scanCanonicalize (H12AffineFastState.compose env9927 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9927 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9928 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,9,5205,0,3,5188,2049,1024,1,4160,0,16,2,9,64,2049,5189,4097,2048,1024,1,84,0,5124,512]

theorem envBound9928 : H12AffineFastState.Bounded env9928 := by
  intro p hp
  have h : env9928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9927_9928 : H12AffineEnvironment.transform 4 0 env9927 = env9928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9927 == env9928) = true)

theorem identity9928 : scanCanonicalize (H12AffineFastState.compose env9928 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9928 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env9929 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5124,0,3,5141,2049,1024,1,4113,0,16,2,9,17,2049,5140,4097,2048,1024,1,5,0,5124,512]

theorem envBound9929 : H12AffineFastState.Bounded env9929 := by
  intro p hp
  have h : env9929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9928_9929 : H12AffineEnvironment.transform 5 17 env9928 = env9929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9928 == env9929) = true)

def env9930 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1044,0,3,1029,2049,1024,1,1,0,16,2,9,17,2049,1028,17,2048,1024,1,5,0,1044,512]

theorem envBound9930 : H12AffineFastState.Bounded env9930 := by
  intro p hp
  have h : env9930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9929_9930 : H12AffineEnvironment.transform 11 16 env9929 = env9930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env9929 == env9930) = true)

theorem identity9930 : scanCanonicalize (H12AffineFastState.compose env9930 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound9930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9931 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,9,1044,0,3,1029,1,1024,1,1,0,16,2,9,17,1,1028,17,0,1024,1,5,0,1044,512]

theorem envBound9931 : H12AffineFastState.Bounded env9931 := by
  intro p hp
  have h : env9931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9930_9931 : H12AffineEnvironment.transform 10 0 env9930 = env9931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9930 == env9931) = true)

def env9932 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,0,3,17,1,20,1,1,0,16,2,9,17,1,16,17,0,20,1,5,0,0,512]

theorem envBound9932 : H12AffineFastState.Bounded env9932 := by
  intro p hp
  have h : env9932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9931_9932 : H12AffineEnvironment.transform 9 20 env9931 = env9932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env9931 == env9932) = true)

theorem identity9932 : scanCanonicalize (H12AffineFastState.compose env9932 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound9932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9933 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,9,0,0,3,17,1,20,1,1,0,16,2,9,17,1,16,17,0,20,1,5,0,0,31]

theorem envBound9933 : H12AffineFastState.Bounded env9933 := by
  intro p hp
  have h : env9933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9932_9933 : H12AffineEnvironment.transform 8 31 env9932 = env9933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env9932 == env9933) = true)

def leafEnv9933 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,9,0,0,3,17,1,20,1,1,0,16,2,20,9,1,17,1,16,17,0,20,1,5,0,4,3,0,31,1,1,0]

def active9933 : List Nat := [0,1,2,3]

def tree9933 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9933 : H12WitnessSearch.Good tree9933 := H12GlobalWitnessIndex.good

theorem leafIdentity9933 : H12AffineFastState.composeSystem env9933 rootObs = leafEnv9933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9933 rootObs == leafEnv9933) = true)

theorem terminalChecked9933 : H12PackedTerminal.terminalCheckFast leafEnv9933 active9933 tree9933 = true := by decide +kernel

def env9934 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,1,0,3,16,1,21,1,1,0,16,2,9,17,1,17,17,0,21,1,5,0,1,512]

theorem envBound9934 : H12AffineFastState.Bounded env9934 := by
  intro p hp
  have h : env9934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9931_9934 : H12AffineEnvironment.transform 9 21 env9931 = env9934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env9931 == env9934) = true)

theorem identity9934 : scanCanonicalize (H12AffineFastState.compose env9934 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound9934 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9935 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,0,3,4,1,1,1,1,0,4,2,9,5,1,5,5,0,1,1,5,0,1,512]

theorem envBound9935 : H12AffineFastState.Bounded env9935 := by
  intro p hp
  have h : env9935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9934_9935 : H12AffineEnvironment.transform 3 4 env9934 = env9935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env9934 == env9935) = true)

def leafEnv9935 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,0,3,4,1,1,1,1,0,4,2,1,9,1,5,1,5,5,0,1,1,5,0,4,3,1,512,1,1,0]

def active9935 : List Nat := [0,1,2,8]

def tree9935 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9935 : H12WitnessSearch.Good tree9935 := H12GlobalWitnessIndex.good

theorem leafIdentity9935 : H12AffineFastState.composeSystem env9935 rootObs = leafEnv9935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9935 rootObs == leafEnv9935) = true)

theorem terminalChecked9935 : H12PackedTerminal.terminalCheckFast leafEnv9935 active9935 tree9935 = true := by decide +kernel

def env9936 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1045,0,3,1028,2049,1024,1,0,0,16,2,9,17,2049,1029,16,2048,1024,1,5,0,1045,512]

theorem envBound9936 : H12AffineFastState.Bounded env9936 := by
  intro p hp
  have h : env9936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9929_9936 : H12AffineEnvironment.transform 11 17 env9929 = env9936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9929 == env9936) = true)

theorem identity9936 : scanCanonicalize (H12AffineFastState.compose env9936 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound9936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9937 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,17,9,1045,0,3,1028,1045,1024,1,0,0,16,2,9,17,1045,1029,16,1044,1024,1,5,0,1045,512]

theorem envBound9937 : H12AffineFastState.Bounded env9937 := by
  intro p hp
  have h : env9937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9936_9937 : H12AffineEnvironment.transform 10 1044 env9936 = env9937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env9936 == env9937) = true)

def env9938 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,0,3,16,1,20,1,0,0,16,2,9,17,1,17,16,0,20,1,5,0,1,512]

theorem envBound9938 : H12AffineFastState.Bounded env9938 := by
  intro p hp
  have h : env9938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9937_9938 : H12AffineEnvironment.transform 9 20 env9937 = env9938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env9937 == env9938) = true)

theorem identity9938 : scanCanonicalize (H12AffineFastState.compose env9938 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound9938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9939 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,17,9,1,0,3,16,1,20,1,0,0,16,2,9,17,1,17,16,0,20,1,5,0,1,31]

theorem envBound9939 : H12AffineFastState.Bounded env9939 := by
  intro p hp
  have h : env9939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9938_9939 : H12AffineEnvironment.transform 8 31 env9938 = env9939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env9938 == env9939) = true)

def leafEnv9939 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,17,9,1,0,3,16,1,20,1,0,0,16,2,20,9,1,17,1,17,16,0,20,1,5,0,4,3,1,31,1,0,0]

def active9939 : List Nat := [0,1,2,3]

def tree9939 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9939 : H12WitnessSearch.Good tree9939 := H12GlobalWitnessIndex.good

theorem leafIdentity9939 : H12AffineFastState.composeSystem env9939 rootObs = leafEnv9939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9939 rootObs == leafEnv9939) = true)

theorem terminalChecked9939 : H12PackedTerminal.terminalCheckFast leafEnv9939 active9939 tree9939 = true := by decide +kernel

def env9940 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,17,9,0,0,3,17,0,21,1,0,0,16,2,9,17,0,16,16,1,21,1,5,0,0,512]

theorem envBound9940 : H12AffineFastState.Bounded env9940 := by
  intro p hp
  have h : env9940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9937_9940 : H12AffineEnvironment.transform 9 21 env9937 = env9940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env9937 == env9940) = true)

theorem identity9940 : scanCanonicalize (H12AffineFastState.compose env9940 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound9940 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9941 : List Nat := [2,4,8,4,0,5,8,5,512,1,1,5,9,0,0,3,5,0,1,1,0,0,4,2,9,5,0,4,4,1,1,1,5,0,0,512]

theorem envBound9941 : H12AffineFastState.Bounded env9941 := by
  intro p hp
  have h : env9941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9940_9941 : H12AffineEnvironment.transform 3 4 env9940 = env9941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env9940 == env9941) = true)

def leafEnv9941 : List Nat := [2,4,8,4,0,5,8,5,512,1,1,5,9,0,0,3,5,0,1,1,0,0,4,2,1,9,1,5,0,4,4,1,1,1,5,0,4,3,0,512,1,0,0]

def active9941 : List Nat := [0,1,2,8]

def tree9941 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9941 : H12WitnessSearch.Good tree9941 := H12GlobalWitnessIndex.good

theorem leafIdentity9941 : H12AffineFastState.composeSystem env9941 rootObs = leafEnv9941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9941 rootObs == leafEnv9941) = true)

theorem terminalChecked9941 : H12PackedTerminal.terminalCheckFast leafEnv9941 active9941 tree9941 = true := by decide +kernel

def env9942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,329731,16,95497,8193,64,245018,79131,102743,442384,61704,318548,256,95531,103430,120407]

theorem envBound9942 : H12AffineFastState.Bounded env9942 := by
  intro p hp
  have h : env9942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9904_9942 : H12AffineEnvironment.transform 6 9 env9904 = env9942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9904 == env9942) = true)

theorem identity9942 : scanCanonicalize (H12AffineFastState.compose env9942 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound9942 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,318549,16,41311,8193,64,158028,57677,17665,442384,61704,318548,256,41341,16464,513]

theorem envBound9943 : H12AffineFastState.Bounded env9943 := by
  intro p hp
  have h : env9943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9942_9943 : H12AffineEnvironment.transform 15 54358 env9942 = env9943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env9942 == env9943) = true)

def env9944 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,318469,16,41231,8193,16,157980,57629,17665,442384,61704,318468,256,41261,16384,513]

theorem envBound9944 : H12AffineFastState.Bounded env9944 := by
  intro p hp
  have h : env9944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9943_9944 : H12AffineEnvironment.transform 5 16 env9943 = env9944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9943 == env9944) = true)

theorem identity9944 : scanCanonicalize (H12AffineFastState.compose env9944 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound9944 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9945 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,179513,1024,32769,4113,155964,16,41231,8193,16,157980,57629,17665,32041,61704,155965,256,41261,16384,513]

theorem envBound9945 : H12AffineFastState.Bounded env9945 := by
  intro p hp
  have h : env9945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9944_9945 : H12AffineEnvironment.transform 17 179513 env9944 = env9945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env9944 == env9945) = true)

theorem identity9945 : scanCanonicalize (H12AffineFastState.compose env9945 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound9945 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env9946 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,24860,56357,1024,32769,4113,32,16,41231,8193,16,2048,57629,17665,32041,61704,33,256,41261,16384,513]

theorem envBound9946 : H12AffineFastState.Bounded env9946 := by
  intro p hp
  have h : env9946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9945_9946 : H12AffineEnvironment.transform 16 24860 env9945 = env9946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env9945 == env9946) = true)

theorem identity9946 : scanCanonicalize (H12AffineFastState.compose env9946 (packedSelected [0,1,7,8,12,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound9946 : packedSelected [0,1,7,8,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env9947 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,54278,16401,56357,1024,32769,4113,32,16,32770,268,16,2048,49168,17665,23588,53253,33,256,32800,16384,513]

theorem envBound9947 : H12AffineFastState.Bounded env9947 := by
  intro p hp
  have h : env9947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9946_9947 : H12AffineEnvironment.transform 12 269 env9946 = env9947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env9946 == env9947) = true)

theorem identity9947 : scanCanonicalize (H12AffineFastState.compose env9947 (packedSelected [1,4,7,8,11,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 19493) := by decide +kernel

theorem selectedBound9947 : packedSelected [1,4,7,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env9948 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,19493,6179,16401,4096,1024,19492,4113,32,16,19495,268,16,2048,3125,17665,23588,7200,33,256,19461,16384,513]

theorem envBound9948 : H12AffineFastState.Bounded env9948 := by
  intro p hp
  have h : env9948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9947_9948 : H12AffineEnvironment.transform 14 19493 env9947 = env9948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19493 env9947 == env9948) = true)

theorem identity9948 : scanCanonicalize (H12AffineFastState.compose env9948 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound9948 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9949 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2341,269,16384,19493,262,16401,2341,1024,19492,2356,32,16,19495,268,16,2048,3125,17665,17665,1285,33,256,19461,16384,513]

theorem envBound9949 : H12AffineFastState.Bounded env9949 := by
  intro p hp
  have h : env9949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9948_9949 : H12AffineEnvironment.transform 11 2341 env9948 = env9949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env9948 == env9949) = true)

theorem identity9949 : scanCanonicalize (H12AffineFastState.compose env9949 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1793) := by decide +kernel

theorem selectedBound9949 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env9950 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,1572,269,16384,17188,262,16401,1572,1024,17189,1589,32,16,17190,268,16,1793,820,17665,17665,1285,33,256,17156,16384,513]

theorem envBound9950 : H12AffineFastState.Bounded env9950 := by
  intro p hp
  have h : env9950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9949_9950 : H12AffineEnvironment.transform 10 1793 env9949 = env9950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env9949 == env9950) = true)

theorem identity9950 : scanCanonicalize (H12AffineFastState.compose env9950 (packedSelected [0,2,9] rootPS)) = affineNative (2^(13+1) ^^^ 309) := by decide +kernel

theorem selectedBound9950 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env9951 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,1572,269,309,529,262,292,1572,1024,528,1589,32,16,531,268,16,1793,820,1076,1076,1285,33,256,561,309,513]

theorem envBound9951 : H12AffineFastState.Bounded env9951 := by
  intro p hp
  have h : env9951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9950_9951 : H12AffineEnvironment.transform 13 309 env9950 = env9951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 309 env9950 == env9951) = true)

theorem identity9951 : scanCanonicalize (H12AffineFastState.compose env9951 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound9951 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env9952 : List Nat := [2,4,8,16,32,16,9,256,16,1024,1297,1076,269,309,1,262,292,1076,1024,0,1061,32,16,3,268,16,1297,292,1076,1076,1285,33,256,33,309,17]

theorem envBound9952 : H12AffineFastState.Bounded env9952 := by
  intro p hp
  have h : env9952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9951_9952 : H12AffineEnvironment.transform 8 16 env9951 = env9952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env9951 == env9952) = true)

theorem identity9952 : scanCanonicalize (H12AffineFastState.compose env9952 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9953 : List Nat := [2,4,8,0,32,0,9,256,0,1024,1281,1060,269,293,1,262,292,1060,1024,0,1061,32,0,3,268,0,1281,292,1060,1060,1285,33,256,33,293,1]

theorem envBound9953 : H12AffineFastState.Bounded env9953 := by
  intro p hp
  have h : env9953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9952_9953 : H12AffineEnvironment.transform 3 0 env9952 = env9953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9952 == env9953) = true)

theorem identity9953 : scanCanonicalize (H12AffineFastState.compose env9953 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound9953 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9954 : List Nat := [2,4,8,0,32,0,9,256,0,257,0,293,269,293,1,262,292,293,257,0,292,32,0,3,268,0,0,292,293,293,4,33,256,33,293,1]

theorem envBound9954 : H12AffineFastState.Bounded env9954 := by
  intro p hp
  have h : env9954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9953_9954 : H12AffineEnvironment.transform 9 257 env9953 = env9954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env9953 == env9954) = true)

def env9955 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,318468,16,41230,8193,17,157981,57628,17665,442384,61704,318469,256,41260,16385,513]

theorem envBound9955 : H12AffineFastState.Bounded env9955 := by
  intro p hp
  have h : env9955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9943_9955 : H12AffineEnvironment.transform 5 17 env9943 = env9955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9943 == env9955) = true)

theorem identity9955 : scanCanonicalize (H12AffineFastState.compose env9955 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound9955 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env9956 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,149813,1024,32769,4112,169265,16,41230,8193,17,157981,57628,17665,35109,61704,169264,256,41260,16385,513]

theorem envBound9956 : H12AffineFastState.Bounded env9956 := by
  intro p hp
  have h : env9956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9955_9956 : H12AffineEnvironment.transform 17 149813 env9955 = env9956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env9955 == env9956) = true)

theorem identity9956 : scanCanonicalize (H12AffineFastState.compose env9956 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound9956 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env9957 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,29963,131072,149813,1024,8461,4112,144445,16,2,8193,17,157981,16400,17665,10281,20484,144444,256,32,16385,513]

theorem envBound9957 : H12AffineFastState.Bounded env9957 := by
  intro p hp
  have h : env9957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9956_9957 : H12AffineEnvironment.transform 14 8460 env9956 = env9957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env9956 == env9957) = true)

theorem identity9957 : scanCanonicalize (H12AffineFastState.compose env9957 (packedSelected [1,3,8,10,12,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound9957 : packedSelected [1,3,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env9958 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8460,263,131072,146745,1024,8461,4112,144445,16,2,8193,17,138513,13340,12557,10281,9224,144444,256,32,13325,513]

theorem envBound9958 : H12AffineFastState.Bounded env9958 := by
  intro p hp
  have h : env9958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9957_9958 : H12AffineEnvironment.transform 13 13324 env9957 = env9958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env9957 == env9958) = true)

theorem identity9958 : scanCanonicalize (H12AffineFastState.compose env9958 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound9958 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env9959 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8460,263,5392,10281,1024,8461,4112,8493,16,2,8193,17,2049,13340,12557,10281,9224,8492,256,32,13325,513]

theorem envBound9959 : H12AffineFastState.Bounded env9959 := by
  intro p hp
  have h : env9959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9958_9959 : H12AffineEnvironment.transform 16 5392 env9958 = env9959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env9958 == env9959) = true)

theorem identity9959 : scanCanonicalize (H12AffineFastState.compose env9959 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound9959 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env9960 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,12572,8460,263,4096,10281,272,8461,4112,8493,16,2,8193,17,2049,12556,12557,10281,8472,8492,256,32,12573,513]

theorem envBound9960 : H12AffineFastState.Bounded env9960 := by
  intro p hp
  have h : env9960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9959_9960 : H12AffineEnvironment.transform 9 272 env9959 = env9960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env9959 == env9960) = true)

theorem identity9960 : scanCanonicalize (H12AffineFastState.compose env9960 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound9960 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9961 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,301,4145,33,263,4096,2308,272,32,4112,0,16,2,300,17,2049,4129,4128,2308,53,1,256,32,4144,513]

theorem envBound9961 : H12AffineFastState.Bounded env9961 := by
  intro p hp
  have h : env9961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9960_9961 : H12AffineEnvironment.transform 12 301 env9960 = env9961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env9960 == env9961) = true)

theorem identity9961 : scanCanonicalize (H12AffineFastState.compose env9961 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9961 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9962 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,4096,268,4112,0,263,4096,2308,272,1,4112,0,16,2,269,17,2049,4096,4097,2308,20,1,256,1,4113,513]

theorem envBound9962 : H12AffineFastState.Bounded env9962 := by
  intro p hp
  have h : env9962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9961_9962 : H12AffineEnvironment.transform 4 1 env9961 = env9962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9961 == env9962) = true)

theorem identity9962 : scanCanonicalize (H12AffineFastState.compose env9962 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound9962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9963 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,277,268,261,0,263,277,2308,272,1,261,0,16,2,269,17,2049,277,276,2308,20,1,256,1,260,513]

theorem envBound9963 : H12AffineFastState.Bounded env9963 := by
  intro p hp
  have h : env9963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9962_9963 : H12AffineEnvironment.transform 11 277 env9962 = env9963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env9962 == env9963) = true)

theorem identity9963 : scanCanonicalize (H12AffineFastState.compose env9963 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound9963 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9964 : List Nat := [2,4,8,16,1,17,9,256,512,272,523,277,268,261,0,263,277,783,272,1,261,0,16,2,269,17,522,277,276,783,20,1,256,1,260,513]

theorem envBound9964 : H12AffineFastState.Bounded env9964 := by
  intro p hp
  have h : env9964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9963_9964 : H12AffineEnvironment.transform 10 523 env9963 = env9964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env9963 == env9964) = true)

theorem identity9964 : scanCanonicalize (H12AffineFastState.compose env9964 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound9964 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env9965 : List Nat := [2,4,8,16,1,17,9,256,11,272,0,277,268,261,0,263,277,260,272,1,261,0,16,2,269,17,1,277,276,260,20,1,256,1,260,10]

theorem envBound9965 : H12AffineFastState.Bounded env9965 := by
  intro p hp
  have h : env9965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9964_9965 : H12AffineEnvironment.transform 8 11 env9964 = env9965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env9964 == env9965) = true)

def env9966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411541,2213006,16777216,8328,64,16959643,18973836,102878,2557070,18890911,17148373,256,16777250,16834950,18966345]

theorem envBound9966 : H12AffineFastState.Bounded env9966 := by
  intro p hp
  have h : env9966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9863_9966 : H12AffineEnvironment.transform 21 2411541 env9863 = env9966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411541 env9863 == env9966) = true)

def env9967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318549,120014,16777216,8328,64,16959643,16880844,102878,464078,16797919,17148373,256,16777250,16834950,16873225]

theorem envBound9967 : H12AffineFastState.Bounded env9967 := by
  intro p hp
  have h : env9967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9966_9967 : H12AffineEnvironment.transform 20 4160 env9966 = env9967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env9966 == env9967) = true)

def env9968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4160,62709,120014,16777216,8328,64,16959643,16880844,102878,212078,16797919,16875893,256,16777250,16834950,16873225]

theorem envBound9968 : H12AffineFastState.Bounded env9968 := by
  intro p hp
  have h : env9968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9967_9968 : H12AffineEnvironment.transform 17 10400 env9967 = env9968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env9967 == env9968) = true)

def env9969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119878,16777216,8192,64,16959507,16880708,102742,212078,16797783,16875893,256,16777250,16834830,16873225]

theorem envBound9969 : H12AffineFastState.Bounded env9969 := by
  intro p hp
  have h : env9969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9968_9969 : H12AffineEnvironment.transform 6 8 env9968 = env9969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9968 == env9969) = true)

theorem identity9969 : scanCanonicalize (H12AffineFastState.compose env9969 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound9969 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env9970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119878,2,8192,64,182289,103494,102742,212078,20565,98679,256,32,57612,96011]

theorem envBound9970 : H12AffineFastState.Bounded env9970 := by
  intro p hp
  have h : env9970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0