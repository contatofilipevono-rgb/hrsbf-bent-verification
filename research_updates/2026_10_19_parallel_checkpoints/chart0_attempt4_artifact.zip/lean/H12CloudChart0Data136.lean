import H12CloudChart0Data135

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound34515 : H12AffineFastState.Bounded env34515 := by
  intro p hp
  have h : env34515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34514_34515 : H12AffineEnvironment.transform 10 277 env34514 = env34515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env34514 == env34515) = true)

theorem identity34515 : scanCanonicalize (H12AffineFastState.compose env34515 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34515 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34516 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,40,49,0,35,33,48,53,1,49,33,17,3,41,16,49,33,33,49,21,32,36,33,48,513]

theorem envBound34516 : H12AffineFastState.Bounded env34516 := by
  intro p hp
  have h : env34516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34515_34516 : H12AffineEnvironment.transform 7 37 env34515 = env34516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34515 == env34516) = true)

def leafEnv34516 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,40,49,0,35,33,48,53,1,49,33,17,3,20,41,1,16,49,33,33,49,21,32,36,33,5,34,48,513,1,48,0]

def active34516 : List Nat := [0,1,2,3,4,8]

def tree34516 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34516 : H12WitnessSearch.Good tree34516 := H12GlobalWitnessIndex.good

theorem leafIdentity34516 : H12AffineFastState.composeSystem env34516 rootObs = leafEnv34516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34516 rootObs == leafEnv34516) = true)

theorem terminalChecked34516 : H12PackedTerminal.terminalCheckFast leafEnv34516 active34516 tree34516 = true := by decide +kernel

def env34517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,8388608,8429903,8193,65,4229152,10560843,10507601,8464750,75103,14795782,257,2188651,2196550,512]

theorem envBound34517 : H12AffineFastState.Bounded env34517 := by
  intro p hp
  have h : env34517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34484_34517 : H12AffineEnvironment.transform 17 35189 env34484 = env34517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env34484 == env34517) = true)

theorem identity34517 : scanCanonicalize (H12AffineFastState.compose env34517 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound34517 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,17460,4194304,8388608,8429903,8193,65,4229152,8479103,8393061,8464750,75103,12681266,257,74079,114802,512]

theorem envBound34518 : H12AffineFastState.Bounded env34518 := by
  intro p hp
  have h : env34518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34517_34518 : H12AffineEnvironment.transform 20 17460 env34517 = env34518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env34517 == env34518) = true)

theorem identity34518 : scanCanonicalize (H12AffineFastState.compose env34518 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 21604) := by decide +kernel

theorem selectedBound34518 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,17460,4194304,21604,62763,8193,65,4229152,79131,17665,97546,75103,4314198,257,74079,114802,512]

theorem envBound34519 : H12AffineFastState.Bounded env34519 := by
  intro p hp
  have h : env34519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34518_34519 : H12AffineEnvironment.transform 22 21604 env34518 = env34519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21604 env34518 == env34519) = true)

theorem identity34519 : scanCanonicalize (H12AffineFastState.compose env34519 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 62728) := by decide +kernel

theorem selectedBound34519 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env34520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,17460,62728,21604,62763,8193,65,32040,79131,17665,97546,75103,74078,257,74079,114802,512]

theorem envBound34520 : H12AffineFastState.Bounded env34520 := by
  intro p hp
  have h : env34520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34519_34520 : H12AffineEnvironment.transform 21 62728 env34519 = env34520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62728 env34519 == env34520) = true)

theorem identity34520 : scanCanonicalize (H12AffineFastState.compose env34520 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34520 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env34521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35189,1025,32769,17460,62728,21604,62763,8193,65,32040,5393,17665,23808,1365,340,257,341,57464,512]

theorem envBound34521 : H12AffineFastState.Bounded env34521 := by
  intro p hp
  have h : env34521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34520_34521 : H12AffineEnvironment.transform 15 8202 env34520 = env34521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34520 == env34521) = true)

theorem identity34521 : scanCanonicalize (H12AffineFastState.compose env34521 (packedSelected [0,7,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound34521 : packedSelected [0,7,17,20] rootPS < 2^1333 := by decide +kernel

def env34522 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,16384,32768,8202,16401,34848,1025,32769,17460,62557,21604,62590,8193,65,31869,5188,17492,23637,1024,1,84,0,57464,512]

theorem envBound34522 : H12AffineFastState.Bounded env34522 := by
  intro p hp
  have h : env34522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34521_34522 : H12AffineEnvironment.transform 7 85 env34521 = env34522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env34521 == env34522) = true)

theorem identity34522 : scanCanonicalize (H12AffineFastState.compose env34522 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound34522 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34523 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,88,16384,32768,82,16401,34848,1025,32769,17460,54277,21604,54310,89,65,23589,5188,17492,23637,1024,1,84,0,49184,512]

theorem envBound34523 : H12AffineFastState.Bounded env34523 := by
  intro p hp
  have h : env34523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34522_34523 : H12AffineEnvironment.transform 12 88 env34522 = env34523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env34522 == env34523) = true)

theorem identity34523 : scanCanonicalize (H12AffineFastState.compose env34523 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34523 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env34524 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,88,16384,1,82,16401,2081,1025,0,17460,21508,21604,21543,89,65,23589,5188,17492,23637,1024,1,84,0,16417,512]

theorem envBound34524 : H12AffineFastState.Bounded env34524 := by
  intro p hp
  have h : env34524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34523_34524 : H12AffineEnvironment.transform 14 1 env34523 = env34524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34523 == env34524) = true)

theorem identity34524 : scanCanonicalize (H12AffineFastState.compose env34524 (packedSelected [6,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34524 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env34525 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,41,16384,1,35,16401,2081,1025,0,17460,21508,21525,21543,40,48,23589,5173,17445,23588,1024,1,37,0,16417,512]

theorem envBound34525 : H12AffineFastState.Bounded env34525 := by
  intro p hp
  have h : env34525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34524_34525 : H12AffineEnvironment.transform 5 49 env34524 = env34525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34524 == env34525) = true)

theorem identity34525 : scanCanonicalize (H12AffineFastState.compose env34525 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound34525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34526 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,41,5156,1,35,5173,2081,1025,0,4112,32,49,3,40,48,2049,5173,4097,2048,1024,1,37,0,5125,512]

theorem envBound34526 : H12AffineFastState.Bounded env34526 := by
  intro p hp
  have h : env34526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34525_34526 : H12AffineEnvironment.transform 13 5156 env34525 = env34526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env34525 == env34526) = true)

theorem identity34526 : scanCanonicalize (H12AffineFastState.compose env34526 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound34526 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34527 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,570,41,1566,1,35,1551,2081,1025,0,554,32,49,3,40,48,2049,1551,571,2048,1024,1,37,0,1599,512]

theorem envBound34527 : H12AffineFastState.Bounded env34527 := by
  intro p hp
  have h : env34527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34526_34527 : H12AffineEnvironment.transform 11 570 env34526 = env34527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env34526 == env34527) = true)

theorem identity34527 : scanCanonicalize (H12AffineFastState.compose env34527 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound34527 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env34528 : List Nat := [2,4,8,16,32,49,9,36,512,1024,1044,570,41,1566,1,35,1551,1077,1025,0,554,32,49,3,40,48,1045,1551,571,1044,1024,1,37,0,1599,512]

theorem envBound34528 : H12AffineFastState.Bounded env34528 := by
  intro p hp
  have h : env34528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34527_34528 : H12AffineEnvironment.transform 10 1044 env34527 = env34528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env34527 == env34528) = true)

theorem identity34528 : scanCanonicalize (H12AffineFastState.compose env34528 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound34528 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env34529 : List Nat := [2,4,8,16,32,49,9,36,40,1024,1044,18,41,1078,1,35,1063,1077,1025,0,2,32,49,3,40,48,1045,1063,19,1044,1024,1,37,0,1047,40]

theorem envBound34529 : H12AffineFastState.Bounded env34529 := by
  intro p hp
  have h : env34529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34528_34529 : H12AffineEnvironment.transform 8 40 env34528 = env34529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env34528 == env34529) = true)

def env34530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound34530 : H12AffineFastState.Bounded env34530 := by
  intro p hp
  have h : env34530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34203_34530 : H12AffineEnvironment.transform 26 30393345 env34203 = env34530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env34203 == env34530) = true)

def env34531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound34531 : H12AffineFastState.Bounded env34531 := by
  intro p hp
  have h : env34531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34530_34531 : H12AffineEnvironment.transform 18 1024 env34530 = env34531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env34530 == env34531) = true)

theorem identity34531 : scanCanonicalize (H12AffineFastState.compose env34531 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534779) := by decide +kernel

theorem selectedBound34531 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534779,8328,65,14773626,469495,10507601,8830976,10955115,4704442,256,8874454,8882290,10882748]

theorem envBound34532 : H12AffineFastState.Bounded env34532 := by
  intro p hp
  have h : env34532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34531_34532 : H12AffineEnvironment.transform 23 2534779 env34531 = env34532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534779 env34531 == env34532) = true)

def env34533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773626,115151,10507601,8398904,10600787,4268162,256,8487406,8478794,10544772]

theorem envBound34533 : H12AffineFastState.Bounded env34533 := by
  intro p hp
  have h : env34533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34532_34533 : H12AffineEnvironment.transform 17 190520 env34532 = env34533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env34532 == env34533) = true)

def env34534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,2114883,8328,65,4291882,115151,17665,2111592,119043,4268162,256,2199998,2191386,63188]

theorem envBound34534 : H12AffineFastState.Bounded env34534 := by
  intro p hp
  have h : env34534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34533_34534 : H12AffineEnvironment.transform 22 2101328 env34533 = env34534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env34533 == env34534) = true)

def env34535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21763,8328,65,4291882,115151,17665,10280,119043,4268162,256,98814,90202,63188]

theorem envBound34535 : H12AffineFastState.Bounded env34535 := by
  intro p hp
  have h : env34535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34534_34535 : H12AffineEnvironment.transform 20 4160 env34534 = env34535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34534 == env34535) = true)

theorem identity34535 : scanCanonicalize (H12AffineFastState.compose env34535 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound34535 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190520,1024,32769,4160,4194304,16,21763,8328,65,4237813,5392,17665,10280,1500,4256861,256,21793,46213,63188]

theorem envBound34536 : H12AffineFastState.Bounded env34536 := by
  intro p hp
  have h : env34536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34535_34536 : H12AffineEnvironment.transform 15 54495 env34535 = env34536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env34535 == env34536) = true)

def env34537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190520,1024,32769,4160,4194304,16,21763,8192,65,4237693,5392,17665,10280,1364,4256861,256,21793,46093,63068]

theorem envBound34537 : H12AffineFastState.Bounded env34537 := by
  intro p hp
  have h : env34537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34536_34537 : H12AffineEnvironment.transform 6 8 env34536 = env34537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34536 == env34537) = true)

theorem identity34537 : scanCanonicalize (H12AffineFastState.compose env34537 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound34537 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,10281,1024,32769,4160,4194304,16,21763,8192,65,4237693,5392,17665,10280,1364,4256861,256,21793,46093,63068]

theorem envBound34538 : H12AffineFastState.Bounded env34538 := by
  intro p hp
  have h : env34538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34537_34538 : H12AffineEnvironment.transform 16 49169 env34537 = env34538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env34537 == env34538) = true)

theorem identity34538 : scanCanonicalize (H12AffineFastState.compose env34538 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34538 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,46156,10281,1024,32769,4160,4194304,16,8542,8192,65,4237693,5392,12636,10280,1364,4227072,256,8572,46093,33281]

theorem envBound34539 : H12AffineFastState.Bounded env34539 := by
  intro p hp
  have h : env34539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34538_34539 : H12AffineEnvironment.transform 13 13405 env34538 = env34539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34538 == env34539) = true)

theorem identity34539 : scanCanonicalize (H12AffineFastState.compose env34539 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound34539 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env34540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,46156,10281,1024,32769,4160,33,16,8542,8192,65,43356,5392,12636,10280,1364,32801,256,8572,46093,33281]

theorem envBound34540 : H12AffineFastState.Bounded env34540 := by
  intro p hp
  have h : env34540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34539_34540 : H12AffineEnvironment.transform 21 33 env34539 = env34540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env34539 == env34540) = true)

theorem identity34540 : scanCanonicalize (H12AffineFastState.compose env34540 (packedSelected [0,1,2,3,6,7,8,10,11,16,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound34540 : packedSelected [0,1,2,3,6,7,8,10,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env34541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,81,8283,13341,10281,1024,80,4160,33,16,8542,8192,65,10509,5392,12636,10280,1364,112,256,8572,13404,592]

theorem envBound34541 : H12AffineFastState.Bounded env34541 := by
  intro p hp
  have h : env34541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34540_34541 : H12AffineEnvironment.transform 14 81 env34540 = env34541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env34540 == env34541) = true)

theorem identity34541 : scanCanonicalize (H12AffineFastState.compose env34541 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34541 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env34542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,81,343,5393,2341,1024,80,4160,33,16,82,268,65,2049,5392,4176,2340,1364,112,256,112,5456,592]

theorem envBound34542 : H12AffineFastState.Bounded env34542 := by
  intro p hp
  have h : env34542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34541_34542 : H12AffineEnvironment.transform 12 268 env34541 = env34542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34541 == env34542) = true)

theorem identity34542 : scanCanonicalize (H12AffineFastState.compose env34542 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound34542 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34543 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4160,81,343,4096,2341,273,80,4160,33,16,82,268,65,2049,4097,4176,2340,69,112,256,112,4161,592]

theorem envBound34543 : H12AffineFastState.Bounded env34543 := by
  intro p hp
  have h : env34543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34542_34543 : H12AffineEnvironment.transform 9 273 env34542 = env34543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34542 == env34543) = true)

theorem identity34543 : scanCanonicalize (H12AffineFastState.compose env34543 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34543 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env34544 : List Nat := [2,4,8,16,32,64,8,4,512,21,2048,4096,8,4160,81,83,4096,2081,21,80,4160,33,16,82,8,65,2049,4097,4176,2080,69,112,4,112,4161,592]

theorem envBound34544 : H12AffineFastState.Bounded env34544 := by
  intro p hp
  have h : env34544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34543_34544 : H12AffineEnvironment.transform 7 4 env34543 = env34544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34543 == env34544) = true)

theorem identity34544 : scanCanonicalize (H12AffineFastState.compose env34544 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound34544 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env34545 : List Nat := [2,4,8,16,32,64,8,4,512,21,2048,97,8,33,81,83,97,2081,21,80,33,33,16,82,8,65,2049,96,49,2080,69,112,4,112,32,592]

theorem envBound34545 : H12AffineFastState.Bounded env34545 := by
  intro p hp
  have h : env34545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34544_34545 : H12AffineEnvironment.transform 11 97 env34544 = env34545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env34544 == env34545) = true)

theorem identity34545 : scanCanonicalize (H12AffineFastState.compose env34545 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34545 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34546 : List Nat := [2,4,8,16,32,17,8,4,512,21,2048,48,8,33,0,2,48,2081,21,1,33,33,16,3,8,16,2049,49,49,2080,20,33,4,33,32,513]

theorem envBound34546 : H12AffineFastState.Bounded env34546 := by
  intro p hp
  have h : env34546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34545_34546 : H12AffineEnvironment.transform 5 17 env34545 = env34546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34545 == env34546) = true)

theorem identity34546 : scanCanonicalize (H12AffineFastState.compose env34546 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound34546 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34547 : List Nat := [2,4,8,16,32,17,8,4,512,21,513,48,8,33,0,2,48,544,21,1,33,33,16,3,8,16,512,49,49,545,20,33,4,33,32,513]

theorem envBound34547 : H12AffineFastState.Bounded env34547 := by
  intro p hp
  have h : env34547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34546_34547 : H12AffineEnvironment.transform 10 513 env34546 = env34547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env34546 == env34547) = true)

theorem identity34547 : scanCanonicalize (H12AffineFastState.compose env34547 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound34547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34548 : List Nat := [2,4,8,16,32,17,8,4,49,21,48,48,8,33,0,2,48,17,21,1,33,33,16,3,8,16,49,49,49,16,20,33,4,33,32,48]

theorem envBound34548 : H12AffineFastState.Bounded env34548 := by
  intro p hp
  have h : env34548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34547_34548 : H12AffineEnvironment.transform 8 49 env34547 = env34548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34547 == env34548) = true)

theorem identity34548 : scanCanonicalize (H12AffineFastState.compose env34548 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34548 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34549 : List Nat := [2,4,8,16,16,17,8,4,1,21,0,0,8,17,0,2,0,17,21,1,17,17,16,3,8,16,1,1,1,16,20,17,4,17,16,0]

theorem envBound34549 : H12AffineFastState.Bounded env34549 := by
  intro p hp
  have h : env34549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34548_34549 : H12AffineEnvironment.transform 4 16 env34548 = env34549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34548 == env34549) = true)

theorem identity34549 : scanCanonicalize (H12AffineFastState.compose env34549 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34550 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,0,8,1,0,2,0,1,5,1,1,1,0,3,8,0,1,1,1,0,4,1,4,1,0,0]

theorem envBound34550 : H12AffineFastState.Bounded env34550 := by
  intro p hp
  have h : env34550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34549_34550 : H12AffineEnvironment.transform 3 0 env34549 = env34550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34549 == env34550) = true)

def env34551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4160,4194304,16,21763,8193,65,4237692,5392,17665,10280,1365,4256861,256,21793,46092,63069]

theorem envBound34551 : H12AffineFastState.Bounded env34551 := by
  intro p hp
  have h : env34551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34536_34551 : H12AffineEnvironment.transform 6 9 env34536 = env34551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34536 == env34551) = true)

theorem identity34551 : scanCanonicalize (H12AffineFastState.compose env34551 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound34551 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4160,4194304,16,21763,8193,65,4237692,5392,17665,10280,1365,4256861,256,21793,46092,63069]

theorem envBound34552 : H12AffineFastState.Bounded env34552 := by
  intro p hp
  have h : env34552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34551_34552 : H12AffineEnvironment.transform 16 24909 env34551 = env34552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env34551 == env34552) = true)

theorem identity34552 : scanCanonicalize (H12AffineFastState.compose env34552 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound34552 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4160,8492,16,21763,8193,65,34896,5392,17665,10280,1365,54641,256,21793,46092,63069]

theorem envBound34553 : H12AffineFastState.Bounded env34553 := by
  intro p hp
  have h : env34553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34552_34553 : H12AffineEnvironment.transform 21 8492 env34552 = env34553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env34552 == env34553) = true)

theorem identity34553 : scanCanonicalize (H12AffineFastState.compose env34553 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound34553 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env34554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,30042,24909,10361,1024,8461,4160,8492,16,21763,8193,65,10588,5392,17665,10280,1365,29821,256,21793,5376,22353]

theorem envBound34554 : H12AffineFastState.Bounded env34554 := by
  intro p hp
  have h : env34554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34553_34554 : H12AffineEnvironment.transform 14 8460 env34553 = env34554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env34553 == env34554) = true)

theorem identity34554 : scanCanonicalize (H12AffineFastState.compose env34554 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34554 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env34555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,342,5441,10361,1024,8461,4160,8492,16,8463,8193,65,10588,5392,12557,10280,1365,113,256,8493,5376,9053]

theorem envBound34555 : H12AffineFastState.Bounded env34555 := by
  intro p hp
  have h : env34555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34554_34555 : H12AffineEnvironment.transform 13 13324 env34554 = env34555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34554 == env34555) = true)

theorem identity34555 : scanCanonicalize (H12AffineFastState.compose env34555 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 5180) := by decide +kernel

theorem selectedBound34555 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env34556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5180,48,5424,342,5441,7237,1024,5425,4160,5392,16,5427,5181,65,7520,5392,1329,7188,1365,113,256,5393,5376,5985]

theorem envBound34556 : H12AffineFastState.Bounded env34556 := by
  intro p hp
  have h : env34556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34555_34556 : H12AffineEnvironment.transform 12 5180 env34555 = env34556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env34555 == env34556) = true)

theorem identity34556 : scanCanonicalize (H12AffineFastState.compose env34556 (packedSelected [0,1,2,3,4,5,6,8,10,11,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound34556 : packedSelected [0,1,2,3,4,5,6,8,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,592,1644,48,1888,342,1809,3605,1024,1889,528,1856,16,1891,1645,65,3888,1856,1329,3652,1365,113,256,1857,1872,1329]

theorem envBound34557 : H12AffineFastState.Bounded env34557 := by
  intro p hp
  have h : env34557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34556_34557 : H12AffineEnvironment.transform 11 592 env34556 = env34557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env34556 == env34557) = true)

theorem identity34557 : scanCanonicalize (H12AffineFastState.compose env34557 (packedSelected [0,1,3,4,5,8,11,12,16] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound34557 : packedSelected [0,1,3,4,5,8,11,12,16] rootPS < 2^1333 := by decide +kernel

def env34558 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,592,860,48,592,342,545,2853,304,593,528,624,16,595,861,65,2560,624,1,2932,101,113,256,625,608,1]

theorem envBound34558 : H12AffineFastState.Bounded env34558 := by
  intro p hp
  have h : env34558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34557_34558 : H12AffineEnvironment.transform 9 304 env34557 = env34558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env34557 == env34558) = true)

theorem identity34558 : scanCanonicalize (H12AffineFastState.compose env34558 (packedSelected [1,3,4,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound34558 : packedSelected [1,3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env34559 : List Nat := [2,4,8,16,32,48,9,256,512,304,2048,544,812,48,544,294,545,2853,304,545,528,512,16,547,813,49,2560,512,1,2820,21,1,256,513,528,1]

theorem envBound34559 : H12AffineFastState.Bounded env34559 := by
  intro p hp
  have h : env34559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34558_34559 : H12AffineEnvironment.transform 5 48 env34558 = env34559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env34558 == env34559) = true)

theorem identity34559 : scanCanonicalize (H12AffineFastState.compose env34559 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound34559 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34560 : List Nat := [2,4,8,16,32,48,9,256,33,304,2048,1,269,48,1,294,0,2308,304,0,49,33,16,2,268,49,2081,33,1,2341,21,1,256,32,49,1]

theorem envBound34560 : H12AffineFastState.Bounded env34560 := by
  intro p hp
  have h : env34560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34559_34560 : H12AffineEnvironment.transform 8 33 env34559 = env34560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env34559 == env34560) = true)

theorem identity34560 : scanCanonicalize (H12AffineFastState.compose env34560 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34560 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34561 : List Nat := [2,4,8,16,1,17,9,256,0,273,2048,1,269,17,1,263,0,2308,273,0,16,0,16,2,268,16,2048,0,1,2308,21,1,256,1,16,1]

theorem envBound34561 : H12AffineFastState.Bounded env34561 := by
  intro p hp
  have h : env34561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34560_34561 : H12AffineEnvironment.transform 4 1 env34560 = env34561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34560 == env34561) = true)

theorem identity34561 : scanCanonicalize (H12AffineFastState.compose env34561 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34562 : List Nat := [2,4,8,16,1,17,9,20,0,5,2048,1,25,17,1,19,0,2064,5,0,16,0,16,2,24,16,2048,0,1,2064,21,1,20,1,16,1]

theorem envBound34562 : H12AffineFastState.Bounded env34562 := by
  intro p hp
  have h : env34562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34561_34562 : H12AffineEnvironment.transform 7 20 env34561 = env34562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34561 == env34562) = true)

theorem identity34562 : scanCanonicalize (H12AffineFastState.compose env34562 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34563 : List Nat := [2,4,8,10,1,11,9,14,0,5,2048,1,3,11,1,9,0,2058,5,0,10,0,10,2,2,10,2048,0,1,2058,15,1,14,1,10,1]

theorem envBound34563 : H12AffineFastState.Bounded env34563 := by
  intro p hp
  have h : env34563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34562_34563 : H12AffineEnvironment.transform 3 10 env34562 = env34563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34562 == env34563) = true)

theorem identity34563 : scanCanonicalize (H12AffineFastState.compose env34563 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34563 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34564 : List Nat := [2,4,3,1,1,0,2,5,0,5,2048,1,3,0,1,2,0,2049,5,0,1,0,1,2,2,1,2048,0,1,2049,4,1,5,1,1,1]

theorem envBound34564 : H12AffineFastState.Bounded env34564 := by
  intro p hp
  have h : env34564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34563_34564 : H12AffineEnvironment.transform 2 3 env34563 = env34564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34563 == env34564) = true)

def env34565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,21762,8328,65,4291882,115151,17665,10281,119043,4268162,256,98815,90203,63188]

theorem envBound34565 : H12AffineFastState.Bounded env34565 := by
  intro p hp
  have h : env34565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34534_34565 : H12AffineEnvironment.transform 20 4161 env34534 = env34565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34534 == env34565) = true)

theorem identity34565 : scanCanonicalize (H12AffineFastState.compose env34565 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201830) := by decide +kernel

theorem selectedBound34565 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,201830,17,21762,8328,65,158028,115151,17665,10281,119043,144612,256,98815,90203,63188]

theorem envBound34566 : H12AffineFastState.Bounded env34566 := by
  intro p hp
  have h : env34566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34565_34566 : H12AffineEnvironment.transform 21 201830 env34565 = env34566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201830 env34565 == env34566) = true)

theorem identity34566 : scanCanonicalize (H12AffineFastState.compose env34566 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34566 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138477,1024,29908,4161,201830,17,21762,8328,65,158028,79130,17665,10281,75222,144612,256,95530,90203,513]

theorem envBound34567 : H12AffineFastState.Bounded env34567 := by
  intro p hp
  have h : env34567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34566_34567 : H12AffineEnvironment.transform 14 29909 env34566 = env34567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34566 == env34567) = true)

theorem identity34567 : scanCanonicalize (H12AffineFastState.compose env34567 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound34567 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,97526,1024,29908,4161,29821,17,21762,8328,65,67927,79130,17665,10281,75222,87295,256,95530,90203,513]

theorem envBound34568 : H12AffineFastState.Bounded env34568 := by
  intro p hp
  have h : env34568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34567_34568 : H12AffineEnvironment.transform 16 90139 env34567 = env34568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env34567 == env34568) = true)

theorem identity34568 : scanCanonicalize (H12AffineFastState.compose env34568 (packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound34568 : packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS < 2^1333 := by decide +kernel

def env34569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,79251,76158,1024,8540,4161,8693,17,138,8328,65,67927,79130,4233,10281,75222,65911,256,73890,79315,513]

theorem envBound34569 : H12AffineFastState.Bounded env34569 := by
  intro p hp
  have h : env34569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34568_34569 : H12AffineEnvironment.transform 13 5512 env34568 = env34569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34568 == env34569) = true)

theorem identity34569 : scanCanonicalize (H12AffineFastState.compose env34569 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34569 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env34570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,5528,2421,1024,8540,4161,8693,17,138,8328,65,10588,5393,4233,10281,1501,8572,256,169,5592,513]

theorem envBound34570 : H12AffineFastState.Bounded env34570 := by
  intro p hp
  have h : env34570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34569_34570 : H12AffineEnvironment.transform 15 8203 env34569 = env34570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34569 == env34570) = true)

theorem identity34570 : scanCanonicalize (H12AffineFastState.compose env34570 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound34570 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5512,508,170,5528,2421,1024,509,4161,340,17,138,41,65,2557,5393,4233,2184,1501,477,256,169,5592,513]

theorem envBound34571 : H12AffineFastState.Bounded env34571 := by
  intro p hp
  have h : env34571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34570_34571 : H12AffineEnvironment.transform 12 161 env34570 = env34571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env34570 == env34571) = true)

theorem identity34571 : scanCanonicalize (H12AffineFastState.compose env34571 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34571 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env34572 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,121,5456,292,114,5440,2421,1024,293,4161,340,17,82,41,65,2341,5393,4177,2128,1285,261,256,113,5376,513]

theorem envBound34572 : H12AffineFastState.Bounded env34572 := by
  intro p hp
  have h : env34572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34571_34572 : H12AffineEnvironment.transform 6 88 env34571 = env34572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34571 == env34572) = true)

theorem identity34572 : scanCanonicalize (H12AffineFastState.compose env34572 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34572 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env34573 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,121,5157,81,114,5173,2048,1024,80,4161,33,17,82,41,65,2128,5220,4177,2128,1136,112,117,113,5237,513]

theorem envBound34573 : H12AffineFastState.Bounded env34573 := by
  intro p hp
  have h : env34573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34572_34573 : H12AffineEnvironment.transform 7 117 env34572 = env34573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34572 == env34573) = true)

def env34574 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,1,34,5173,2048,1024,0,4113,33,17,2,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound34574 : H12AffineFastState.Bounded env34574 := by
  intro p hp
  have h : env34574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34573_34574 : H12AffineEnvironment.transform 5 16 env34573 = env34574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34573 == env34574) = true)

def env34575 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1045,1,34,1029,2048,1024,0,33,33,17,2,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound34575 : H12AffineFastState.Bounded env34575 := by
  intro p hp
  have h : env34575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34574_34575 : H12AffineEnvironment.transform 11 48 env34574 = env34575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34574 == env34575) = true)

theorem identity34575 : scanCanonicalize (H12AffineFastState.compose env34575 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound34575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34576 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,48,41,1045,1,34,1029,1044,1024,0,33,33,17,2,41,17,1044,1028,49,1044,1056,32,37,33,1045,513]

theorem envBound34576 : H12AffineFastState.Bounded env34576 := by
  intro p hp
  have h : env34576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34575_34576 : H12AffineEnvironment.transform 10 1044 env34575 = env34576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env34575 == env34576) = true)

def env34577 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,48,41,33,1,34,49,32,52,0,33,33,17,2,41,17,32,48,49,32,20,32,37,33,33,513]

theorem envBound34577 : H12AffineFastState.Bounded env34577 := by
  intro p hp
  have h : env34577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34576_34577 : H12AffineEnvironment.transform 9 52 env34576 = env34577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34576 == env34577) = true)

def env34578 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,41,32,1,34,48,33,53,0,33,33,17,2,41,17,33,49,49,33,21,32,37,33,32,513]

theorem envBound34578 : H12AffineFastState.Bounded env34578 := by
  intro p hp
  have h : env34578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34576_34578 : H12AffineEnvironment.transform 9 53 env34576 = env34578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34576 == env34578) = true)

theorem identity34578 : scanCanonicalize (H12AffineFastState.compose env34578 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34578 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34579 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,48,41,32,1,34,48,33,53,0,33,33,17,2,41,17,33,49,49,33,21,32,37,33,32,42]

theorem envBound34579 : H12AffineFastState.Bounded env34579 := by
  intro p hp
  have h : env34579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34578_34579 : H12AffineEnvironment.transform 8 43 env34578 = env34579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34578 == env34579) = true)

def leafEnv34579 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,48,41,32,1,34,48,33,53,0,33,33,17,2,21,41,1,17,33,49,49,33,21,32,37,33,4,34,32,42,1,33,0]

def active34579 : List Nat := [0,1,2,3,4]

def tree34579 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34579 : H12WitnessSearch.Good tree34579 := H12GlobalWitnessIndex.good

theorem leafIdentity34579 : H12AffineFastState.composeSystem env34579 rootObs = leafEnv34579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34579 rootObs == leafEnv34579) = true)

theorem terminalChecked34579 : H12PackedTerminal.terminalCheckFast leafEnv34579 active34579 tree34579 = true := by decide +kernel

def env34580 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1044,1,34,1028,2048,1024,0,32,33,17,2,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound34580 : H12AffineFastState.Bounded env34580 := by
  intro p hp
  have h : env34580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34574_34580 : H12AffineEnvironment.transform 11 49 env34574 = env34580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34574 == env34580) = true)

theorem identity34580 : scanCanonicalize (H12AffineFastState.compose env34580 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound34580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34581 : List Nat := [2,4,8,16,32,16,8,37,512,1024,32,49,41,1044,1,34,1028,32,1024,0,32,33,17,2,41,17,32,1029,48,32,1056,32,37,33,1044,513]

theorem envBound34581 : H12AffineFastState.Bounded env34581 := by
  intro p hp
  have h : env34581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34580_34581 : H12AffineEnvironment.transform 10 32 env34580 = env34581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env34580 == env34581) = true)

def env34582 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,41,32,1,34,48,32,52,0,32,33,17,2,41,17,32,49,48,32,20,32,37,33,32,513]

theorem envBound34582 : H12AffineFastState.Bounded env34582 := by
  intro p hp
  have h : env34582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34581_34582 : H12AffineEnvironment.transform 9 52 env34581 = env34582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34581 == env34582) = true)

def env34583 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,41,33,1,34,49,32,53,0,32,33,17,2,41,17,32,48,48,32,21,32,37,33,33,513]

theorem envBound34583 : H12AffineFastState.Bounded env34583 := by
  intro p hp
  have h : env34583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34581_34583 : H12AffineEnvironment.transform 9 53 env34581 = env34583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34581 == env34583) = true)

theorem identity34583 : scanCanonicalize (H12AffineFastState.compose env34583 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34583 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34584 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,49,41,33,1,34,49,32,53,0,32,33,17,2,41,17,32,48,48,32,21,32,37,33,33,43]

theorem envBound34584 : H12AffineFastState.Bounded env34584 := by
  intro p hp
  have h : env34584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34583_34584 : H12AffineEnvironment.transform 8 42 env34583 = env34584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34583 == env34584) = true)

def leafEnv34584 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,49,41,33,1,34,49,32,53,0,32,33,17,2,21,41,1,17,32,48,48,32,21,32,37,33,4,34,33,43,1,32,0]

def active34584 : List Nat := [0,1,2,3,4]

def tree34584 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34584 : H12WitnessSearch.Good tree34584 := H12GlobalWitnessIndex.good

theorem leafIdentity34584 : H12AffineFastState.composeSystem env34584 rootObs = leafEnv34584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34584 rootObs == leafEnv34584) = true)

theorem terminalChecked34584 : H12PackedTerminal.terminalCheckFast leafEnv34584 active34584 tree34584 = true := by decide +kernel

def env34585 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,35,5173,2048,1024,1,4112,33,17,3,41,16,2049,5173,4096,2049,1057,33,36,32,5156,513]

theorem envBound34585 : H12AffineFastState.Bounded env34585 := by
  intro p hp
  have h : env34585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34573_34585 : H12AffineEnvironment.transform 5 17 env34573 = env34585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34573 == env34585) = true)

theorem identity34585 : scanCanonicalize (H12AffineFastState.compose env34585 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34586 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4113,0,35,4097,2048,52,1,4112,33,17,3,41,16,2049,4097,4096,2049,21,33,36,32,4112,513]

theorem envBound34586 : H12AffineFastState.Bounded env34586 := by
  intro p hp
  have h : env34586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34585_34586 : H12AffineEnvironment.transform 9 52 env34585 = env34586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34585 == env34586) = true)

theorem identity34586 : scanCanonicalize (H12AffineFastState.compose env34586 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound34586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34587 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,32,40,49,0,35,33,2048,52,1,48,33,17,3,41,16,2049,33,32,2049,21,33,36,32,48,513]

theorem envBound34587 : H12AffineFastState.Bounded env34587 := by
  intro p hp
  have h : env34587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34586_34587 : H12AffineEnvironment.transform 11 32 env34586 = env34587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env34586 == env34587) = true)

theorem identity34587 : scanCanonicalize (H12AffineFastState.compose env34587 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound34587 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34588 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,40,49,0,35,33,49,52,1,48,33,17,3,41,16,48,33,32,48,21,33,36,32,48,513]

theorem envBound34588 : H12AffineFastState.Bounded env34588 := by
  intro p hp
  have h : env34588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34587_34588 : H12AffineEnvironment.transform 10 49 env34587 = env34588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env34587 == env34588) = true)

def leafEnv34588 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,40,49,0,35,33,49,52,1,48,33,17,3,21,41,1,16,48,33,32,48,21,33,36,32,4,34,48,513,1,49,0]

def active34588 : List Nat := [0,1,2,3,4,8]

def tree34588 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34588 : H12WitnessSearch.Good tree34588 := H12GlobalWitnessIndex.good

theorem leafIdentity34588 : H12AffineFastState.composeSystem env34588 rootObs = leafEnv34588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34588 rootObs == leafEnv34588) = true)

theorem terminalChecked34588 : H12PackedTerminal.terminalCheckFast leafEnv34588 active34588 tree34588 = true := by decide +kernel

def env34589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,2114883,8328,65,4291883,115151,17664,2111593,119042,4268162,256,2199999,2191387,63189]

theorem envBound34589 : H12AffineFastState.Bounded env34589 := by
  intro p hp
  have h : env34589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34533_34589 : H12AffineEnvironment.transform 22 2101329 env34533 = env34589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env34533 == env34589) = true)

def env34590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,21763,8328,65,4291883,115151,17664,10281,119042,4268162,256,98815,90203,63189]

theorem envBound34590 : H12AffineFastState.Bounded env34590 := by
  intro p hp
  have h : env34590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34589_34590 : H12AffineEnvironment.transform 20 4160 env34589 = env34590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34589 == env34590) = true)

theorem identity34590 : scanCanonicalize (H12AffineFastState.compose env34590 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254131) := by decide +kernel

theorem selectedBound34590 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254131,17,21763,8328,65,171416,115151,17664,10281,119042,180273,256,98815,90203,63189]

theorem envBound34591 : H12AffineFastState.Bounded env34591 := by
  intro p hp
  have h : env34591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34590_34591 : H12AffineEnvironment.transform 21 254131 env34590 = env34591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254131 env34590 == env34591) = true)

def env34592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254011,17,21763,8192,65,171280,115015,17664,10281,119042,180273,256,98679,90203,63069]

theorem envBound34592 : H12AffineFastState.Bounded env34592 := by
  intro p hp
  have h : env34592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34591_34592 : H12AffineEnvironment.transform 6 8 env34591 = env34592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34591 == env34592) = true)

theorem identity34592 : scanCanonicalize (H12AffineFastState.compose env34592 (packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 115014) := by decide +kernel

theorem selectedBound34592 : packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env34593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,115014,76158,1024,32769,4160,8573,17,21763,8192,65,89174,115015,17664,10281,119042,65911,256,98679,90203,63069]

theorem envBound34593 : H12AffineFastState.Bounded env34593 := by
  intro p hp
  have h : env34593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34592_34593 : H12AffineEnvironment.transform 16 115014 env34592 = env34593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115014 env34592 == env34593) = true)

theorem identity34593 : scanCanonicalize (H12AffineFastState.compose env34593 (packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound34593 : packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS < 2^1333 := by decide +kernel

def env34594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,5393,64809,1024,32769,4160,8573,17,21763,8192,65,34817,5392,17664,10281,1365,54560,256,21792,46092,63069]

theorem envBound34594 : H12AffineFastState.Bounded env34594 := by
  intro p hp
  have h : env34594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34593_34594 : H12AffineEnvironment.transform 15 54359 env34593 = env34594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env34593 == env34594) = true)

theorem identity34594 : scanCanonicalize (H12AffineFastState.compose env34594 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34594 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,5393,23668,1024,8540,4160,8573,17,21763,8192,65,10588,5392,17664,10281,1365,29821,256,21792,5457,22272]

theorem envBound34595 : H12AffineFastState.Bounded env34595 := by
  intro p hp
  have h : env34595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34594_34595 : H12AffineEnvironment.transform 14 8541 env34594 = env34595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34594 == env34595) = true)

theorem identity34595 : scanCanonicalize (H12AffineFastState.compose env34595 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34595 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,2421,1024,8540,4160,8573,17,2,8192,65,10588,5392,4097,10281,1365,8572,256,33,5457,513]

theorem envBound34596 : H12AffineFastState.Bounded env34596 := by
  intro p hp
  have h : env34596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34595_34596 : H12AffineEnvironment.transform 13 5377 env34595 = env34596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34595 == env34596) = true)

theorem identity34596 : scanCanonicalize (H12AffineFastState.compose env34596 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34596 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,263,5393,2421,1024,80,4160,113,17,2,268,65,2128,5392,4097,2341,1365,112,256,33,5457,513]

theorem envBound34597 : H12AffineFastState.Bounded env34597 := by
  intro p hp
  have h : env34597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34596_34597 : H12AffineEnvironment.transform 12 268 env34596 = env34597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34596 == env34597) = true)

theorem identity34597 : scanCanonicalize (H12AffineFastState.compose env34597 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34597 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34598 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2341,1024,0,4112,33,17,2,268,17,2048,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound34598 : H12AffineFastState.Bounded env34598 := by
  intro p hp
  have h : env34598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34597_34598 : H12AffineEnvironment.transform 5 16 env34597 = env34598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34597 == env34598) = true)

theorem identity34598 : scanCanonicalize (H12AffineFastState.compose env34598 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34598 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34599 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5173,2049,1024,0,4112,33,17,2,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound34599 : H12AffineFastState.Bounded env34599 := by
  intro p hp
  have h : env34599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34598_34599 : H12AffineEnvironment.transform 7 36 env34598 = env34599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34598 == env34599) = true)

def env34600 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,1,35,1029,2049,1024,0,32,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound34600 : H12AffineFastState.Bounded env34600 := by
  intro p hp
  have h : env34600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34599_34600 : H12AffineEnvironment.transform 11 48 env34599 = env34600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34599 == env34600) = true)

theorem identity34600 : scanCanonicalize (H12AffineFastState.compose env34600 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound34600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34601 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,48,40,1045,1,35,1029,2049,1024,0,32,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,48]

theorem envBound34601 : H12AffineFastState.Bounded env34601 := by
  intro p hp
  have h : env34601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34600_34601 : H12AffineEnvironment.transform 8 49 env34600 = env34601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34600 == env34601) = true)

def env34602 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,40,33,1,35,49,2049,52,0,32,33,17,2,40,17,2048,48,49,2049,21,32,36,33,33,48]

theorem envBound34602 : H12AffineFastState.Bounded env34602 := by
  intro p hp
  have h : env34602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34601_34602 : H12AffineEnvironment.transform 9 52 env34601 = env34602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34601 == env34602) = true)

def env34603 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,40,32,1,35,48,2049,53,0,32,33,17,2,40,17,2048,49,49,2049,20,32,36,33,32,48]

theorem envBound34603 : H12AffineFastState.Bounded env34603 := by
  intro p hp
  have h : env34603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34601_34603 : H12AffineEnvironment.transform 9 53 env34601 = env34603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34601 == env34603) = true)

theorem identity34603 : scanCanonicalize (H12AffineFastState.compose env34603 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34604 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,43,40,32,1,35,43,2049,46,0,32,33,10,2,40,10,2048,42,42,2049,15,32,36,33,32,43]

theorem envBound34604 : H12AffineFastState.Bounded env34604 := by
  intro p hp
  have h : env34604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34603_34604 : H12AffineEnvironment.transform 3 11 env34603 = env34604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34603 == env34604) = true)

def leafEnv34604 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,43,40,32,1,35,43,2049,46,0,32,33,10,2,15,40,1,10,2048,42,42,2049,15,32,36,33,4,35,32,43,1,32,0]

def active34604 : List Nat := [0,1,2,4,10]

def tree34604 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34604 : H12WitnessSearch.Good tree34604 := H12GlobalWitnessIndex.good

theorem leafIdentity34604 : H12AffineFastState.composeSystem env34604 rootObs = leafEnv34604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34604 rootObs == leafEnv34604) = true)

theorem terminalChecked34604 : H12PackedTerminal.terminalCheckFast leafEnv34604 active34604 tree34604 = true := by decide +kernel

def env34605 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,1,35,1028,2049,1024,0,33,33,17,2,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound34605 : H12AffineFastState.Bounded env34605 := by
  intro p hp
  have h : env34605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34599_34605 : H12AffineEnvironment.transform 11 49 env34599 = env34605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34599 == env34605) = true)

theorem identity34605 : scanCanonicalize (H12AffineFastState.compose env34605 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound34605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34606 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,49,40,529,1,35,513,2049,517,0,33,33,17,2,40,17,2048,512,48,2049,548,32,36,33,529,513]

theorem envBound34606 : H12AffineFastState.Bounded env34606 := by
  intro p hp
  have h : env34606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34605_34606 : H12AffineEnvironment.transform 9 517 env34605 = env34606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env34605 == env34606) = true)

def env34607 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,40,33,1,35,49,2049,53,0,33,33,17,2,40,17,2048,48,48,2049,20,32,36,33,33,49]

theorem envBound34607 : H12AffineFastState.Bounded env34607 := by
  intro p hp
  have h : env34607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34606_34607 : H12AffineEnvironment.transform 8 48 env34606 = env34607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34606 == env34607) = true)

theorem identity34607 : scanCanonicalize (H12AffineFastState.compose env34607 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34607 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34608 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,42,40,33,1,35,42,2049,46,0,33,33,10,2,40,10,2048,43,43,2049,15,32,36,33,33,42]

theorem envBound34608 : H12AffineFastState.Bounded env34608 := by
  intro p hp
  have h : env34608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34607_34608 : H12AffineEnvironment.transform 3 11 env34607 = env34608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34607 == env34608) = true)

def leafEnv34608 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,42,40,33,1,35,42,2049,46,0,33,33,10,2,15,40,1,10,2048,43,43,2049,15,32,36,33,4,35,33,42,1,33,0]

def active34608 : List Nat := [0,1,2,4,10]

def tree34608 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34608 : H12WitnessSearch.Good tree34608 := H12GlobalWitnessIndex.good

theorem leafIdentity34608 : H12AffineFastState.composeSystem env34608 rootObs = leafEnv34608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34608 rootObs == leafEnv34608) = true)

theorem terminalChecked34608 : H12PackedTerminal.terminalCheckFast leafEnv34608 active34608 tree34608 = true := by decide +kernel

def env34609 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,40,32,1,35,48,2049,52,0,33,33,17,2,40,17,2048,49,48,2049,21,32,36,33,32,48]

theorem envBound34609 : H12AffineFastState.Bounded env34609 := by
  intro p hp
  have h : env34609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34606_34609 : H12AffineEnvironment.transform 8 49 env34606 = env34609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34606 == env34609) = true)

def env34610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254010,17,21763,8193,65,171281,115014,17664,10281,119042,180273,256,98678,90203,63068]

theorem envBound34610 : H12AffineFastState.Bounded env34610 := by
  intro p hp
  have h : env34610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34591_34610 : H12AffineEnvironment.transform 6 9 env34591 = env34610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34591 == env34610) = true)

theorem identity34610 : scanCanonicalize (H12AffineFastState.compose env34610 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34610 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149861,1024,8540,4160,213351,17,21763,8193,65,146508,90139,17664,10281,94303,156012,256,73771,90203,22273]

theorem envBound34611 : H12AffineFastState.Bounded env34611 := by
  intro p hp
  have h : env34611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34610_34611 : H12AffineEnvironment.transform 14 8541 env34610 = env34611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34610 == env34611) = true)

theorem identity34611 : scanCanonicalize (H12AffineFastState.compose env34611 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound34611 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,79131,97406,1024,8540,4160,29820,17,21763,8193,65,67927,90139,17664,10281,94303,87159,256,73771,90203,22273]

theorem envBound34612 : H12AffineFastState.Bounded env34612 := by
  intro p hp
  have h : env34612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34611_34612 : H12AffineEnvironment.transform 16 79131 env34611 = env34612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env34611 == env34612) = true)

theorem identity34612 : scanCanonicalize (H12AffineFastState.compose env34612 (packedSelected [0,4,8,10,12,14,15,16,18,22,23,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound34612 : packedSelected [0,4,8,10,12,14,15,16,18,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env34613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,293,65536,71011,89094,1024,292,4160,21508,17,21763,121,65,67927,82019,17664,2129,86055,87159,256,65619,81955,22273]

theorem envBound34613 : H12AffineFastState.Bounded env34613 := by
  intro p hp
  have h : env34613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34612_34613 : H12AffineEnvironment.transform 12 120 env34612 = env34613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env34612 == env34613) = true)

theorem identity34613 : scanCanonicalize (H12AffineFastState.compose env34613 (packedSelected [6,9,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34613 : packedSelected [6,9,22] rootPS < 2^1333 := by decide +kernel

def env34614 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,1,65536,70727,89094,1024,0,4160,21508,17,21543,121,65,67699,82019,17444,2129,86055,87159,36,65619,81955,22053]

theorem envBound34614 : H12AffineFastState.Bounded env34614 := by
  intro p hp
  have h : env34614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34613_34614 : H12AffineEnvironment.transform 7 36 env34613 = env34614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34613 == env34614) = true)

theorem identity34614 : scanCanonicalize (H12AffineFastState.compose env34614 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound34614 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env34615 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,1,21511,16448,2049,1024,0,4160,21508,17,21543,121,65,23668,5220,17444,2129,1056,112,36,21588,5156,22053]

theorem envBound34615 : H12AffineFastState.Bounded env34615 := by
  intro p hp
  have h : env34615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34614_34615 : H12AffineEnvironment.transform 15 21511 env34614 = env34615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env34614 == env34615) = true)

def env34616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21762,8328,65,4291883,115151,17664,10280,119042,4268162,256,98814,90202,63189]

theorem envBound34616 : H12AffineFastState.Bounded env34616 := by
  intro p hp
  have h : env34616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34589_34616 : H12AffineEnvironment.transform 20 4161 env34589 = env34616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34589 == env34616) = true)

theorem identity34616 : scanCanonicalize (H12AffineFastState.compose env34616 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34616 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,4194304,16,21762,8328,65,4218145,57797,17664,10280,61704,4194440,256,41460,16464,63189]

theorem envBound34617 : H12AffineFastState.Bounded env34617 := by
  intro p hp
  have h : env34617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34616_34617 : H12AffineEnvironment.transform 15 8202 env34616 = env34617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34616 == env34617) = true)

def env34618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,4194304,16,21762,8192,65,4218145,57677,17664,10280,61704,4194304,256,41340,16464,63069]

theorem envBound34618 : H12AffineFastState.Bounded env34618 := by
  intro p hp
  have h : env34618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34617_34618 : H12AffineEnvironment.transform 6 8 env34617 = env34618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34617 == env34618) = true)

theorem identity34618 : scanCanonicalize (H12AffineFastState.compose env34618 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound34618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1024,32769,4161,4194304,16,21762,8192,65,4218145,57677,17664,10280,61704,4194304,256,41340,16464,63069]

theorem envBound34619 : H12AffineFastState.Bounded env34619 := by
  intro p hp
  have h : env34619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34618_34619 : H12AffineEnvironment.transform 16 49169 env34618 = env34619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env34618 == env34619) = true)

theorem identity34619 : scanCanonicalize (H12AffineFastState.compose env34619 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound34619 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env34620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1024,32769,4161,62588,16,21762,8192,65,43357,57677,17664,10280,61704,62588,256,41340,16464,63069]

theorem envBound34620 : H12AffineFastState.Bounded env34620 := by
  intro p hp
  have h : env34620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34619_34620 : H12AffineEnvironment.transform 21 62588 env34619 = env34620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env34619 == env34620) = true)

theorem identity34620 : scanCanonicalize (H12AffineFastState.compose env34620 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34620 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env34621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8202,46156,10281,1024,32769,4161,32801,16,8543,8192,65,43357,38160,12637,10280,34133,32801,256,41340,13325,33280]

theorem envBound34621 : H12AffineFastState.Bounded env34621 := by
  intro p hp
  have h : env34621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34620_34621 : H12AffineEnvironment.transform 13 13405 env34620 = env34621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34620 == env34621) = true)

theorem identity34621 : scanCanonicalize (H12AffineFastState.compose env34621 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34621 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8202,5392,10281,1024,8541,4161,8573,16,8543,8192,65,2049,13388,12637,10280,9225,8573,256,32,13325,9052]

theorem envBound34622 : H12AffineFastState.Bounded env34622 := by
  intro p hp
  have h : env34622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34621_34622 : H12AffineEnvironment.transform 14 8540 env34621 = env34622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34621 == env34622) = true)

theorem identity34622 : scanCanonicalize (H12AffineFastState.compose env34622 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound34622 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,0,8192,9309,8540,8202,1296,10281,1024,8541,65,8573,16,8543,8192,65,2049,9292,8541,10280,9225,8573,256,32,9229,9052]

theorem envBound34623 : H12AffineFastState.Bounded env34623 := by
  intro p hp
  have h : env34623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34622_34623 : H12AffineEnvironment.transform 11 0 env34622 = env34623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env34622 == env34623) = true)

theorem identity34623 : scanCanonicalize (H12AffineFastState.compose env34623 (packedSelected [2,4,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34623 : packedSelected [2,4,9,12,15] rootPS < 2^1333 := by decide +kernel

def env34624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,0,41,1140,373,35,1296,2048,1024,372,65,340,16,374,41,65,2049,1125,372,2049,1056,340,256,32,1060,885]

theorem envBound34624 : H12AffineFastState.Bounded env34624 := by
  intro p hp
  have h : env34624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34623_34624 : H12AffineEnvironment.transform 12 41 env34623 = env34624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34623 == env34624) = true)

theorem identity34624 : scanCanonicalize (H12AffineFastState.compose env34624 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 330) := by decide +kernel

theorem selectedBound34624 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env34625 : List Nat := [2,4,8,16,32,64,8,256,512,330,2048,0,41,318,373,35,90,2048,330,372,65,340,16,374,41,65,2049,303,372,2049,362,340,256,32,366,885]

theorem envBound34625 : H12AffineFastState.Bounded env34625 := by
  intro p hp
  have h : env34625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34624_34625 : H12AffineEnvironment.transform 9 330 env34624 = env34625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 330 env34624 == env34625) = true)

def env34626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,4194304,16,21762,8193,65,4218145,57676,17664,10280,61704,4194305,256,41341,16464,63068]

theorem envBound34626 : H12AffineFastState.Bounded env34626 := by
  intro p hp
  have h : env34626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34617_34626 : H12AffineEnvironment.transform 6 9 env34617 = env34626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34617 == env34626) = true)

theorem identity34626 : scanCanonicalize (H12AffineFastState.compose env34626 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound34626 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24909,35189,1024,32769,4161,4194304,16,21762,8193,65,4218145,57676,17664,10280,61704,4194305,256,41341,16464,63068]

theorem envBound34627 : H12AffineFastState.Bounded env34627 := by
  intro p hp
  have h : env34627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34626_34627 : H12AffineEnvironment.transform 16 24909 env34626 = env34627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env34626 == env34627) = true)

theorem identity34627 : scanCanonicalize (H12AffineFastState.compose env34627 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound34627 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24909,35189,1024,32769,4161,41340,16,21762,8193,65,64605,57676,17664,10280,61704,41341,256,41341,16464,63068]

theorem envBound34628 : H12AffineFastState.Bounded env34628 := by
  intro p hp
  have h : env34628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34627_34628 : H12AffineEnvironment.transform 21 41340 env34627 = env34628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env34627 == env34628) = true)

theorem identity34628 : scanCanonicalize (H12AffineFastState.compose env34628 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound34628 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env34629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,16384,32768,2,16709,35189,1024,32769,4161,33140,16,21762,9,65,56405,49476,17664,2080,53504,33141,256,33141,16464,54868]

theorem envBound34629 : H12AffineFastState.Bounded env34629 := by
  intro p hp
  have h : env34629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34628_34629 : H12AffineEnvironment.transform 12 8 env34628 = env34629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env34628 == env34629) = true)

theorem identity34629 : scanCanonicalize (H12AffineFastState.compose env34629 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound34629 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env34630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5204,32768,2,5393,35189,1024,32769,4161,33140,16,342,9,65,34817,38160,4436,2080,34132,33141,256,33141,5124,33280]

theorem envBound34630 : H12AffineFastState.Bounded env34630 := by
  intro p hp
  have h : env34630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34629_34630 : H12AffineEnvironment.transform 13 5204 env34629 = env34630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env34629 == env34630) = true)

theorem identity34630 : scanCanonicalize (H12AffineFastState.compose env34630 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34630 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5204,1,2,5393,2420,1024,0,4161,373,16,342,9,65,2048,5393,4436,2080,1365,372,256,372,5124,513]

theorem envBound34631 : H12AffineFastState.Bounded env34631 := by
  intro p hp
  have h : env34631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34630_34631 : H12AffineEnvironment.transform 14 1 env34630 = env34631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34630 == env34631) = true)

theorem identity34631 : scanCanonicalize (H12AffineFastState.compose env34631 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound34631 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34632 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,4096,8,4112,1,2,4437,2420,68,0,4161,373,16,342,9,65,2048,4437,4436,2080,273,372,256,372,4160,513]

theorem envBound34632 : H12AffineFastState.Bounded env34632 := by
  intro p hp
  have h : env34632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34631_34632 : H12AffineEnvironment.transform 9 68 env34631 = env34632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env34631 == env34632) = true)

def env34633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773626,115150,10507601,8398905,10600786,4268163,256,8487407,8478795,10544773]

theorem envBound34633 : H12AffineFastState.Bounded env34633 := by
  intro p hp
  have h : env34633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34532_34633 : H12AffineEnvironment.transform 17 190521 env34532 = env34633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env34532 == env34633) = true)

def env34634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,2114882,8328,65,4291882,115150,17665,2111593,119042,4268163,256,2199999,2191387,63189]

theorem envBound34634 : H12AffineFastState.Bounded env34634 := by
  intro p hp
  have h : env34634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34633_34634 : H12AffineEnvironment.transform 22 2101328 env34633 = env34634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env34633 == env34634) = true)

def env34635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21762,8328,65,4291882,115150,17665,10281,119042,4268163,256,98815,90203,63189]

theorem envBound34635 : H12AffineFastState.Bounded env34635 := by
  intro p hp
  have h : env34635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34634_34635 : H12AffineEnvironment.transform 20 4160 env34634 = env34635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34634 == env34635) = true)

def env34636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21762,8192,65,4291882,115014,17665,10281,119042,4268043,256,98679,90203,63069]

theorem envBound34636 : H12AffineFastState.Bounded env34636 := by
  intro p hp
  have h : env34636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34635_34636 : H12AffineEnvironment.transform 6 8 env34635 = env34636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34635 == env34636) = true)

theorem identity34636 : scanCanonicalize (H12AffineFastState.compose env34636 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound34636 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,4194304,16,21762,8192,65,4291882,115014,17665,10281,119042,4268043,256,98679,90203,63069]

theorem envBound34637 : H12AffineFastState.Bounded env34637 := by
  intro p hp
  have h : env34637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34636_34637 : H12AffineEnvironment.transform 16 49168 env34636 = env34637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env34636 == env34637) = true)

theorem identity34637 : scanCanonicalize (H12AffineFastState.compose env34637 (packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34637 : packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS < 2^1333 := by decide +kernel

def env34638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1024,29789,4160,4194304,16,21762,8192,65,4291882,79130,17665,10281,75102,4268043,256,95531,90203,513]

theorem envBound34638 : H12AffineFastState.Bounded env34638 := by
  intro p hp
  have h : env34638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34637_34638 : H12AffineEnvironment.transform 14 29788 env34637 = env34638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34637 == env34638) = true)

theorem identity34638 : scanCanonicalize (H12AffineFastState.compose env34638 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34638 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env34639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13388,10281,1024,29789,4160,4194304,16,21762,8192,65,4218145,5393,17665,10281,1365,4194304,256,21792,16464,513]

theorem envBound34639 : H12AffineFastState.Bounded env34639 := by
  intro p hp
  have h : env34639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34638_34639 : H12AffineEnvironment.transform 15 8203 env34638 = env34639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34638 == env34639) = true)

theorem identity34639 : scanCanonicalize (H12AffineFastState.compose env34639 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34639 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env34640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21840,263,5440,2341,1024,21841,4160,4194304,16,21762,268,65,4218145,5393,17665,2341,1365,4194304,256,21792,16464,513]

theorem envBound34640 : H12AffineFastState.Bounded env34640 := by
  intro p hp
  have h : env34640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34639_34640 : H12AffineEnvironment.transform 12 268 env34639 = env34640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34639 == env34640) = true)

theorem identity34640 : scanCanonicalize (H12AffineFastState.compose env34640 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound34640 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21840,263,5440,2341,1024,21841,4160,21793,16,21762,268,65,2048,5393,17665,2341,1365,21793,256,21792,16464,513]

theorem envBound34641 : H12AffineFastState.Bounded env34641 := by
  intro p hp
  have h : env34641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34640_34641 : H12AffineEnvironment.transform 21 21793 env34640 = env34641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env34640 == env34641) = true)

theorem identity34641 : scanCanonicalize (H12AffineFastState.compose env34641 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound34641 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env34642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,1,263,5440,2341,1024,0,4160,112,16,83,268,65,2048,5393,4176,2341,1365,112,256,113,5377,513]

theorem envBound34642 : H12AffineFastState.Bounded env34642 := by
  intro p hp
  have h : env34642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34641_34642 : H12AffineEnvironment.transform 13 5457 env34641 = env34642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env34641 == env34642) = true)

theorem identity34642 : scanCanonicalize (H12AffineFastState.compose env34642 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34642 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34643 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1024,0,4113,33,16,2,268,16,2048,5393,4097,2341,1284,33,256,32,5377,513]

theorem envBound34643 : H12AffineFastState.Bounded env34643 := by
  intro p hp
  have h : env34643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34642_34643 : H12AffineEnvironment.transform 5 17 env34642 = env34643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34642 == env34643) = true)

theorem identity34643 : scanCanonicalize (H12AffineFastState.compose env34643 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34644 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5173,2049,1024,0,4113,33,16,2,40,16,2048,5173,4097,2049,1056,33,36,32,5157,513]

theorem envBound34644 : H12AffineFastState.Bounded env34644 := by
  intro p hp
  have h : env34644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34643_34644 : H12AffineEnvironment.transform 7 36 env34643 = env34644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34643 == env34644) = true)

theorem identity34644 : scanCanonicalize (H12AffineFastState.compose env34644 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound34644 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34645 : List Nat := [2,4,8,16,32,17,8,36,512,1024,522,4096,40,5156,1,35,5173,523,1024,0,4113,33,16,2,40,16,522,5173,4097,523,1056,33,36,32,5157,513]

theorem envBound34645 : H12AffineFastState.Bounded env34645 := by
  intro p hp
  have h : env34645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34644_34645 : H12AffineEnvironment.transform 10 522 env34644 = env34645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env34644 == env34645) = true)

theorem identity34645 : scanCanonicalize (H12AffineFastState.compose env34645 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34645 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34646 : List Nat := [2,4,8,16,0,17,8,4,512,1024,522,4096,8,5124,1,3,5141,523,1024,0,4113,1,16,2,8,16,522,5141,4097,523,1024,1,4,0,5125,513]

theorem envBound34646 : H12AffineFastState.Bounded env34646 := by
  intro p hp
  have h : env34646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34645_34646 : H12AffineEnvironment.transform 4 0 env34645 = env34646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34645 == env34646) = true)

def env34647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21762,8193,65,4291882,115015,17665,10281,119042,4268042,256,98678,90203,63068]

theorem envBound34647 : H12AffineFastState.Bounded env34647 := by
  intro p hp
  have h : env34647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34635_34647 : H12AffineEnvironment.transform 6 9 env34635 = env34647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34635 == env34647) = true)

theorem identity34647 : scanCanonicalize (H12AffineFastState.compose env34647 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound34647 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4160,4194304,16,21762,8193,65,4291882,115015,17665,10281,119042,4268042,256,98678,90203,63068]

theorem envBound34648 : H12AffineFastState.Bounded env34648 := by
  intro p hp
  have h : env34648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34647_34648 : H12AffineEnvironment.transform 16 24908 env34647 = env34648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env34647 == env34648) = true)

theorem identity34648 : scanCanonicalize (H12AffineFastState.compose env34648 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound34648 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,35189,1024,32769,4160,4194304,16,21762,8193,65,4229152,13389,17665,10281,9224,4248832,256,29820,38225,63068]

theorem envBound34649 : H12AffineFastState.Bounded env34649 := by
  intro p hp
  have h : env34649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34648_34649 : H12AffineEnvironment.transform 15 62730 env34648 = env34649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env34648 == env34649) = true)

theorem identity34649 : scanCanonicalize (H12AffineFastState.compose env34649 (packedSelected [1,4,8,9,12,14,19,20,38] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound34649 : packedSelected [1,4,8,9,12,14,19,20,38] rootPS < 2^1333 := by decide +kernel

def env34650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,35189,1024,32769,4160,341,16,21762,8193,65,35189,13389,17665,10281,9224,54357,256,29820,38225,63068]

theorem envBound34650 : H12AffineFastState.Bounded env34650 := by
  intro p hp
  have h : env34650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34649_34650 : H12AffineEnvironment.transform 21 341 env34649 = env34650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env34649 == env34650) = true)

theorem identity34650 : scanCanonicalize (H12AffineFastState.compose env34650 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound34650 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env34651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,24908,32040,1024,29788,4160,341,16,21762,8193,65,32040,13389,17665,10281,9224,8200,256,29820,24844,513]

theorem envBound34651 : H12AffineFastState.Bounded env34651 := by
  intro p hp
  have h : env34651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34650_34651 : H12AffineEnvironment.transform 14 29789 env34650 = env34651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env34650 == env34651) = true)

theorem identity34651 : scanCanonicalize (H12AffineFastState.compose env34651 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound34651 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env34652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,9293,343,12636,11576,1024,9292,4160,341,16,1298,8193,65,11576,13389,5393,10281,9224,8200,256,9324,12572,513]

theorem envBound34652 : H12AffineFastState.Bounded env34652 := by
  intro p hp
  have h : env34652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34651_34652 : H12AffineEnvironment.transform 13 4112 env34651 = env34652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env34651 == env34652) = true)

theorem identity34652 : scanCanonicalize (H12AffineFastState.compose env34652 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34652 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env34653 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,4112,9244,262,12557,11576,1024,9245,4113,260,16,1298,8193,16,11576,13340,5393,10281,9224,8200,256,9277,12572,513]

theorem envBound34653 : H12AffineFastState.Bounded env34653 := by
  intro p hp
  have h : env34653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34652_34653 : H12AffineEnvironment.transform 5 17 env34652 = env34653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34652 == env34653) = true)

theorem identity34653 : scanCanonicalize (H12AffineFastState.compose env34653 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound34653 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34654 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,4112,1076,262,4389,3344,1024,1077,4113,260,16,1298,41,16,3344,5172,5393,2049,1056,32,256,1045,4404,513]

theorem envBound34654 : H12AffineFastState.Bounded env34654 := by
  intro p hp
  have h : env34654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34653_34654 : H12AffineEnvironment.transform 12 40 env34653 = env34654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env34653 == env34654) = true)

theorem identity34654 : scanCanonicalize (H12AffineFastState.compose env34654 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34654 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env34655 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,4112,1076,34,4097,3124,1024,1077,4113,32,16,1078,41,16,3124,5172,5173,2049,1056,32,36,1045,4112,513]

theorem envBound34655 : H12AffineFastState.Bounded env34655 := by
  intro p hp
  have h : env34655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34654_34655 : H12AffineEnvironment.transform 7 36 env34654 = env34655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34654 == env34655) = true)

theorem identity34655 : scanCanonicalize (H12AffineFastState.compose env34655 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound34655 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34656 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,17,40,1,1076,34,16,3124,1024,1077,0,32,16,1078,41,16,3124,1061,1060,2049,1056,32,36,1045,1,513]

theorem envBound34656 : H12AffineFastState.Bounded env34656 := by
  intro p hp
  have h : env34656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34655_34656 : H12AffineEnvironment.transform 11 17 env34655 = env34656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34655 == env34656) = true)

theorem identity34656 : scanCanonicalize (H12AffineFastState.compose env34656 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34656 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34657 : List Nat := [2,4,2,16,32,17,3,36,512,1024,2048,17,34,1,1076,34,16,3124,1024,1077,0,32,16,1078,35,16,3124,1061,1060,2049,1056,32,36,1045,1,513]

theorem envBound34657 : H12AffineFastState.Bounded env34657 := by
  intro p hp
  have h : env34657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34656_34657 : H12AffineEnvironment.transform 2 2 env34656 = env34657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34656 == env34657) = true)

theorem identity34657 : scanCanonicalize (H12AffineFastState.compose env34657 (packedSelected [0,1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound34657 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env34658 : List Nat := [2,4,2,16,32,17,3,36,512,1024,528,17,34,1,1076,34,16,1572,1024,1077,0,32,16,1078,35,16,1572,1061,1060,529,1056,32,36,1045,1,513]

theorem envBound34658 : H12AffineFastState.Bounded env34658 := by
  intro p hp
  have h : env34658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34657_34658 : H12AffineEnvironment.transform 10 528 env34657 = env34658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env34657 == env34658) = true)

def env34659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,21763,8328,65,4291882,115150,17665,10280,119042,4268163,256,98814,90202,63189]

theorem envBound34659 : H12AffineFastState.Bounded env34659 := by
  intro p hp
  have h : env34659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34634_34659 : H12AffineEnvironment.transform 20 4161 env34634 = env34659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34634 == env34659) = true)

theorem identity34659 : scanCanonicalize (H12AffineFastState.compose env34659 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180409) := by decide +kernel

theorem selectedBound34659 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180409,17,21763,8328,65,245139,115150,17665,10280,119042,254010,256,98814,90202,63189]

theorem envBound34660 : H12AffineFastState.Bounded env34660 := by
  intro p hp
  have h : env34660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34659_34660 : H12AffineEnvironment.transform 21 180409 env34659 = env34660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env34659 == env34660) = true)

def env34661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180273,17,21763,8192,65,245019,115014,17665,10280,119042,254010,256,98678,90202,63069]

theorem envBound34661 : H12AffineFastState.Bounded env34661 := by
  intro p hp
  have h : env34661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34660_34661 : H12AffineEnvironment.transform 6 8 env34660 = env34661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34660 == env34661) = true)

theorem identity34661 : scanCanonicalize (H12AffineFastState.compose env34661 (packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound34661 : packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env34662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82198,108847,1024,32769,4161,98599,17,21763,8192,65,64525,115014,17665,10280,119042,41260,256,98678,90202,63069]

theorem envBound34662 : H12AffineFastState.Bounded env34662 := by
  intro p hp
  have h : env34662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34661_34662 : H12AffineEnvironment.transform 16 82198 env34661 = env34662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env34661 == env34662) = true)

theorem identity34662 : scanCanonicalize (H12AffineFastState.compose env34662 (packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound34662 : packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS < 2^1333 := by decide +kernel

def env34663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,13388,56437,1024,32769,4161,62589,17,21763,8192,65,64525,46108,17665,10280,42072,41260,256,62508,5376,63069]

theorem envBound34663 : H12AffineFastState.Bounded env34663 := by
  intro p hp
  have h : env34663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34662_34663 : H12AffineEnvironment.transform 15 30042 env34662 = env34663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env34662 == env34663) = true)

theorem identity34663 : scanCanonicalize (H12AffineFastState.compose env34663 (packedSelected [4,10,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound34663 : packedSelected [4,10,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env34664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,30042,13388,2420,1024,21760,4161,8572,17,21763,8192,65,10508,24861,17665,10280,29017,29741,256,8493,5376,9052]

theorem envBound34664 : H12AffineFastState.Bounded env34664 := by
  intro p hp
  have h : env34664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34663_34664 : H12AffineEnvironment.transform 14 21761 env34663 = env34664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env34663 == env34664) = true)

def env34665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180272,17,21763,8193,65,245018,115015,17665,10280,119042,254010,256,98679,90202,63068]

theorem envBound34665 : H12AffineFastState.Bounded env34665 := by
  intro p hp
  have h : env34665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34660_34665 : H12AffineEnvironment.transform 6 9 env34660 = env34665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34660 == env34665) = true)

theorem identity34665 : scanCanonicalize (H12AffineFastState.compose env34665 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34665 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4161,156013,17,21763,8193,65,203847,90138,17665,10280,94303,213351,256,73770,90202,22273]

theorem envBound34666 : H12AffineFastState.Bounded env34666 := by
  intro p hp
  have h : env34666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34665_34666 : H12AffineEnvironment.transform 14 8541 env34665 = env34666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34665 == env34666) = true)

theorem identity34666 : scanCanonicalize (H12AffineFastState.compose env34666 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound34666 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env34667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21591,131072,149860,1024,8540,4161,156013,17,21763,8193,65,149520,13389,17665,10280,9224,136496,256,29821,13325,22273]

theorem envBound34667 : H12AffineFastState.Bounded env34667 := by
  intro p hp
  have h : env34667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34666_34667 : H12AffineEnvironment.transform 15 21591 env34666 = env34667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env34666 == env34667) = true)

theorem identity34667 : scanCanonicalize (H12AffineFastState.compose env34667 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound34667 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env34668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21591,24908,10280,1024,8540,4161,33,17,21763,8193,65,10588,13389,17665,10280,9224,29820,256,29821,13325,22273]

theorem envBound34668 : H12AffineFastState.Bounded env34668 := by
  intro p hp
  have h : env34668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34667_34668 : H12AffineEnvironment.transform 16 24908 env34667 = env34668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env34667 == env34668) = true)

theorem identity34668 : scanCanonicalize (H12AffineFastState.compose env34668 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound34668 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8541,9499,4096,10280,1024,8540,4161,33,17,9295,8193,65,10588,13389,13389,10280,9224,1328,256,1329,13325,9805]

theorem envBound34669 : H12AffineFastState.Bounded env34669 := by
  intro p hp
  have h : env34669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34668_34669 : H12AffineEnvironment.transform 13 12620 env34668 = env34669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env34668 == env34669) = true)

theorem identity34669 : scanCanonicalize (H12AffineFastState.compose env34669 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound34669 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env34670 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,5157,1076,114,4096,3393,1024,1077,4161,33,17,294,1384,65,3125,4388,4388,3393,353,1328,256,1329,4452,804]

theorem envBound34670 : H12AffineFastState.Bounded env34670 := by
  intro p hp
  have h : env34670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34669_34670 : H12AffineEnvironment.transform 12 1385 env34669 = env34670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env34669 == env34670) = true)

theorem identity34670 : scanCanonicalize (H12AffineFastState.compose env34670 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34670 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env34671 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4112,1,114,4096,2420,53,0,4161,33,17,294,349,65,2048,4388,4388,2420,353,261,256,260,4452,804]

theorem envBound34671 : H12AffineFastState.Bounded env34671 := by
  intro p hp
  have h : env34671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34670_34671 : H12AffineEnvironment.transform 9 53 env34670 = env34671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34670 == env34671) = true)

theorem identity34671 : scanCanonicalize (H12AffineFastState.compose env34671 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34671 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34672 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,121,4112,1,114,4096,2129,53,0,4161,33,17,3,120,65,2048,4097,4097,2129,68,32,37,33,4161,513]

theorem envBound34672 : H12AffineFastState.Bounded env34672 := by
  intro p hp
  have h : env34672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34671_34672 : H12AffineEnvironment.transform 7 37 env34671 = env34672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34671 == env34672) = true)

theorem identity34672 : scanCanonicalize (H12AffineFastState.compose env34672 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34672 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34673 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4112,1,34,4096,2049,53,0,4113,33,17,3,40,17,2048,4097,4097,2049,20,32,37,33,4113,513]

theorem envBound34673 : H12AffineFastState.Bounded env34673 := by
  intro p hp
  have h : env34673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34672_34673 : H12AffineEnvironment.transform 5 16 env34672 = env34673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34672 == env34673) = true)

def env34674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,2114882,8328,65,4291883,115150,17664,2111592,119043,4268163,256,2199998,2191386,63188]

theorem envBound34674 : H12AffineFastState.Bounded env34674 := by
  intro p hp
  have h : env34674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34633_34674 : H12AffineEnvironment.transform 22 2101329 env34633 = env34674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env34633 == env34674) = true)

def env34675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,21762,8328,65,4291883,115150,17664,10280,119043,4268163,256,98814,90202,63188]

theorem envBound34675 : H12AffineFastState.Bounded env34675 := by
  intro p hp
  have h : env34675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34674_34675 : H12AffineEnvironment.transform 20 4160 env34674 = env34675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34674 == env34675) = true)

theorem identity34675 : scanCanonicalize (H12AffineFastState.compose env34675 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound34675 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,21762,8328,65,215367,115150,17664,10280,119043,201967,256,98814,90202,63188]

theorem envBound34676 : H12AffineFastState.Bounded env34676 := by
  intro p hp
  have h : env34676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34675_34676 : H12AffineEnvironment.transform 21 144492 env34675 = env34676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env34675 == env34676) = true)

def env34677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,21762,8192,65,215367,115014,17664,10280,119043,201831,256,98678,90202,63068]

theorem envBound34677 : H12AffineFastState.Bounded env34677 := by
  intro p hp
  have h : env34677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34676_34677 : H12AffineEnvironment.transform 6 8 env34676 = env34677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34676 == env34677) = true)

theorem identity34677 : scanCanonicalize (H12AffineFastState.compose env34677 (packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound34677 : packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS < 2^1333 := by decide +kernel

def env34678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33030,131072,190521,1024,32769,4160,144492,17,21762,8192,65,182337,16448,17664,10280,20485,169313,256,112,57692,63068]

theorem envBound34678 : H12AffineFastState.Bounded env34678 := by
  intro p hp
  have h : env34678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34677_34678 : H12AffineEnvironment.transform 15 33030 env34677 = env34678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env34677 == env34678) = true)

theorem identity34678 : scanCanonicalize (H12AffineFastState.compose env34678 (packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound34678 : packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33030,49217,10360,1024,32769,4160,62509,17,21762,8192,65,2048,16448,17664,10280,20485,21792,256,112,57692,63068]

theorem envBound34679 : H12AffineFastState.Bounded env34679 := by
  intro p hp
  have h : env34679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34678_34679 : H12AffineEnvironment.transform 16 49217 env34678 = env34679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env34678 == env34679) = true)

theorem identity34679 : scanCanonicalize (H12AffineFastState.compose env34679 (packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound34679 : packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env34680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,21591,5392,10360,1024,21840,4160,8572,17,21762,8192,65,2048,16448,17664,10280,20485,21792,256,112,13325,8973]

theorem envBound34680 : H12AffineFastState.Bounded env34680 := by
  intro p hp
  have h : env34680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34679_34680 : H12AffineEnvironment.transform 14 21841 env34679 = env34680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env34679 == env34680) = true)

theorem identity34680 : scanCanonicalize (H12AffineFastState.compose env34680 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34680 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,21591,5392,2421,1024,21840,4160,113,17,21762,269,65,2048,16448,17664,2341,20485,21792,256,112,5376,512]

theorem envBound34681 : H12AffineFastState.Bounded env34681 := by
  intro p hp
  have h : env34681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34680_34681 : H12AffineEnvironment.transform 12 269 env34680 = env34681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34680 == env34681) = true)

theorem identity34681 : scanCanonicalize (H12AffineFastState.compose env34681 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4421) := by decide +kernel

theorem selectedBound34681 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,4421,1044,1298,5392,2421,1024,1045,4160,113,17,1095,269,65,2048,4357,5189,2341,320,1125,256,112,5376,512]

theorem envBound34682 : H12AffineFastState.Bounded env34682 := by
  intro p hp
  have h : env34682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34681_34682 : H12AffineEnvironment.transform 13 4421 env34681 = env34682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4421 env34681 == env34682) = true)

theorem identity34682 : scanCanonicalize (H12AffineFastState.compose env34682 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound34682 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34683 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,269,4421,292,34,4128,2421,304,293,4160,113,17,375,269,65,2048,4357,4469,2341,320,341,256,112,4144,512]

theorem envBound34683 : H12AffineFastState.Bounded env34683 := by
  intro p hp
  have h : env34683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34682_34683 : H12AffineEnvironment.transform 9 304 env34682 = env34683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env34682 == env34683) = true)

theorem identity34683 : scanCanonicalize (H12AffineFastState.compose env34683 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34683 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env34684 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,4096,40,4192,1,34,4128,2128,21,0,4160,113,17,82,40,65,2048,4128,4176,2048,101,112,37,112,4144,512]

theorem envBound34684 : H12AffineFastState.Bounded env34684 := by
  intro p hp
  have h : env34684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34683_34684 : H12AffineEnvironment.transform 7 37 env34683 = env34684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34683 == env34684) = true)

theorem identity34684 : scanCanonicalize (H12AffineFastState.compose env34684 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound34684 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34685 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,2065,40,2161,1,34,2097,2128,21,0,2129,113,17,82,40,65,2048,2097,2113,2048,101,112,37,112,2081,512]

theorem envBound34685 : H12AffineFastState.Bounded env34685 := by
  intro p hp
  have h : env34685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34684_34685 : H12AffineEnvironment.transform 11 2065 env34684 = env34685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env34684 == env34685) = true)

theorem identity34685 : scanCanonicalize (H12AffineFastState.compose env34685 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound34685 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34686 : List Nat := [2,4,8,16,32,48,8,37,512,21,2048,2065,40,2049,1,34,2097,2080,21,0,2081,1,17,34,40,49,2048,2097,2097,2048,21,0,37,0,2081,512]

theorem envBound34686 : H12AffineFastState.Bounded env34686 := by
  intro p hp
  have h : env34686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34685_34686 : H12AffineEnvironment.transform 5 48 env34685 = env34686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env34685 == env34686) = true)

def env34687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,21762,8193,65,215367,115015,17664,10280,119043,201830,256,98679,90202,63069]

theorem envBound34687 : H12AffineFastState.Bounded env34687 := by
  intro p hp
  have h : env34687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34676_34687 : H12AffineEnvironment.transform 6 9 env34676 = env34687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34676 == env34687) = true)

theorem identity34687 : scanCanonicalize (H12AffineFastState.compose env34687 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4160,144492,17,21762,8193,65,215367,90138,17664,10280,94302,201830,256,73770,90202,22272]

theorem envBound34688 : H12AffineFastState.Bounded env34688 := by
  intro p hp
  have h : env34688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34687_34688 : H12AffineEnvironment.transform 14 8541 env34687 = env34688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34687 == env34688) = true)

theorem identity34688 : scanCanonicalize (H12AffineFastState.compose env34688 (packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 24681) := by decide +kernel

theorem selectedBound34688 : packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24681,10509,1024,8540,4160,21509,17,21762,8193,65,76078,90138,17664,10280,94302,95247,256,73770,90202,22272]

theorem envBound34689 : H12AffineFastState.Bounded env34689 := by
  intro p hp
  have h : env34689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34688_34689 : H12AffineEnvironment.transform 16 24681 env34688 = env34689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24681 env34688 == env34689) = true)

theorem identity34689 : scanCanonicalize (H12AffineFastState.compose env34689 (packedSelected [1,2,4,5,6,7,8,11,14,18,22,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34689 : packedSelected [1,2,4,5,6,7,8,11,14,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env34690 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,65536,24681,10360,1024,8233,4160,21509,17,21623,8193,65,75867,90138,17525,10280,94302,95247,117,73770,90202,22133]

theorem envBound34690 : H12AffineFastState.Bounded env34690 := by
  intro p hp
  have h : env34690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34689_34690 : H12AffineEnvironment.transform 7 117 env34689 = env34690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34689 == env34690) = true)

theorem identity34690 : scanCanonicalize (H12AffineFastState.compose env34690 (packedSelected [0,1,2,3,5,6,7,8,11,14,23] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound34690 : packedSelected [0,1,2,3,5,6,7,8,11,14,23] rootPS < 2^1333 := by decide +kernel

def env34691 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1101,16384,1125,65536,17444,3125,1024,1124,4160,21509,17,21623,1100,65,68630,83031,17525,3173,87059,86082,117,66663,82967,22133]

theorem envBound34691 : H12AffineFastState.Bounded env34691 := by
  intro p hp
  have h : env34691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34690_34691 : H12AffineEnvironment.transform 12 1101 env34690 = env34691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env34690 == env34691) = true)

theorem identity34691 : scanCanonicalize (H12AffineFastState.compose env34691 (packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 20531) := by decide +kernel

theorem selectedBound34691 : packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env34692 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1101,16384,1125,20531,17444,3125,1024,1124,4160,21509,17,21623,1100,65,23589,5220,17525,3173,1056,113,117,21588,5156,22133]

theorem envBound34692 : H12AffineFastState.Bounded env34692 := by
  intro p hp
  have h : env34692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34691_34692 : H12AffineEnvironment.transform 15 20531 env34691 = env34692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20531 env34691 == env34692) = true)

theorem identity34692 : scanCanonicalize (H12AffineFastState.compose env34692 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound34692 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34693 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1101,4112,1125,35,5172,3125,1024,1124,4160,1045,17,1127,1100,65,3125,5220,5221,3173,1056,113,117,1092,5156,1637]

theorem envBound34693 : H12AffineFastState.Bounded env34693 := by
  intro p hp
  have h : env34693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34692_34693 : H12AffineEnvironment.transform 13 4112 env34692 = env34693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env34692 == env34693) = true)

theorem identity34693 : scanCanonicalize (H12AffineFastState.compose env34693 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound34693 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env34694 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,1085,4112,1045,35,5172,3125,1024,1044,4144,1045,17,1047,1084,49,3125,5140,5141,3093,1056,1,5,1076,5156,1557]

theorem envBound34694 : H12AffineFastState.Bounded env34694 := by
  intro p hp
  have h : env34694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34693_34694 : H12AffineEnvironment.transform 5 48 env34693 = env34694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env34693 == env34694) = true)

theorem identity34694 : scanCanonicalize (H12AffineFastState.compose env34694 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34695 : List Nat := [2,4,8,16,32,48,9,5,512,52,2048,4096,9,4112,33,35,4096,2049,52,32,4144,33,17,35,8,49,2049,4128,4129,2081,20,1,5,0,4112,545]

theorem envBound34695 : H12AffineFastState.Bounded env34695 := by
  intro p hp
  have h : env34695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34694_34695 : H12AffineEnvironment.transform 9 52 env34694 = env34695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34694 == env34695) = true)

theorem identity34695 : scanCanonicalize (H12AffineFastState.compose env34695 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound34695 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34696 : List Nat := [2,4,8,16,32,48,9,5,512,52,2048,529,9,513,33,35,529,2049,52,32,545,33,17,35,8,49,2049,561,560,2081,20,1,5,0,513,545]

theorem envBound34696 : H12AffineFastState.Bounded env34696 := by
  intro p hp
  have h : env34696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34695_34696 : H12AffineEnvironment.transform 11 529 env34695 = env34696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env34695 == env34696) = true)

theorem identity34696 : scanCanonicalize (H12AffineFastState.compose env34696 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound34696 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34697 : List Nat := [2,4,8,16,32,48,9,5,512,52,42,529,9,513,33,35,529,43,52,32,545,33,17,35,8,49,43,561,560,11,20,1,5,0,513,545]

theorem envBound34697 : H12AffineFastState.Bounded env34697 := by
  intro p hp
  have h : env34697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34696_34697 : H12AffineEnvironment.transform 10 42 env34696 = env34697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env34696 == env34697) = true)

theorem identity34697 : scanCanonicalize (H12AffineFastState.compose env34697 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound34697 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env34698 : List Nat := [2,4,8,16,32,48,9,5,58,52,42,43,9,59,33,35,43,43,52,32,27,33,17,35,8,49,43,11,10,11,20,1,5,0,59,27]

theorem envBound34698 : H12AffineFastState.Bounded env34698 := by
  intro p hp
  have h : env34698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34697_34698 : H12AffineEnvironment.transform 8 58 env34697 = env34698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env34697 == env34698) = true)

theorem identity34698 : scanCanonicalize (H12AffineFastState.compose env34698 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34698 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env34699 : List Nat := [2,4,2,16,32,48,3,5,48,52,32,33,3,49,33,35,33,33,52,32,17,33,17,35,2,49,33,1,0,1,20,1,5,0,49,17]

theorem envBound34699 : H12AffineFastState.Bounded env34699 := by
  intro p hp
  have h : env34699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34698_34699 : H12AffineEnvironment.transform 2 2 env34698 = env34699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34698 == env34699) = true)

theorem identity34699 : scanCanonicalize (H12AffineFastState.compose env34699 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34699 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env34700 : List Nat := [2,1,2,16,32,48,3,0,48,49,32,33,3,49,33,35,33,33,49,32,17,33,17,35,2,49,33,1,0,1,17,1,0,0,49,17]

theorem envBound34700 : H12AffineFastState.Bounded env34700 := by
  intro p hp
  have h : env34700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34699_34700 : H12AffineEnvironment.transform 1 1 env34699 = env34700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34699 == env34700) = true)

theorem identity34700 : scanCanonicalize (H12AffineFastState.compose env34700 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34701 : List Nat := [0,1,0,16,32,48,1,0,48,49,32,33,1,49,33,33,33,33,49,32,17,33,17,33,0,49,33,1,0,1,17,1,0,0,49,17]

theorem envBound34701 : H12AffineFastState.Bounded env34701 := by
  intro p hp
  have h : env34701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34700_34701 : H12AffineEnvironment.transform 0 0 env34700 = env34701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34700 == env34701) = true)

theorem identity34701 : scanCanonicalize (H12AffineFastState.compose env34701 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34701 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env34702 : List Nat := [0,1,0,16,0,16,1,0,16,17,0,1,1,17,1,1,1,1,17,0,17,1,17,1,0,17,1,1,0,1,17,1,0,0,17,17]

theorem envBound34702 : H12AffineFastState.Bounded env34702 := by
  intro p hp
  have h : env34702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34701_34702 : H12AffineEnvironment.transform 4 0 env34701 = env34702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34701 == env34702) = true)

theorem identity34702 : scanCanonicalize (H12AffineFastState.compose env34702 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34702 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34703 : List Nat := [0,1,0,1,0,1,1,0,1,0,0,1,1,0,1,1,1,1,0,0,0,1,0,1,0,0,1,1,0,1,0,1,0,0,0,0]

theorem envBound34703 : H12AffineFastState.Bounded env34703 := by
  intro p hp
  have h : env34703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34702_34703 : H12AffineEnvironment.transform 3 1 env34702 = env34703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34702 == env34703) = true)

def env34704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21763,8328,65,4291883,115150,17664,10281,119043,4268163,256,98815,90203,63188]

theorem envBound34704 : H12AffineFastState.Bounded env34704 := by
  intro p hp
  have h : env34704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34674_34704 : H12AffineEnvironment.transform 20 4161 env34674 = env34704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34674 == env34704) = true)

theorem identity34704 : scanCanonicalize (H12AffineFastState.compose env34704 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34704 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138476,1024,29908,4161,4194304,16,21763,8328,65,4291883,79131,17664,10281,75222,4268163,256,95530,90203,513]

theorem envBound34705 : H12AffineFastState.Bounded env34705 := by
  intro p hp
  have h : env34705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34704_34705 : H12AffineEnvironment.transform 14 29909 env34704 = env34705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34704 == env34705) = true)

def env34706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138476,1024,8660,4161,4194304,16,3,8328,65,4270123,79131,4096,10281,75222,4268163,256,73770,79195,513]

theorem envBound34706 : H12AffineFastState.Bounded env34706 := by
  intro p hp
  have h : env34706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34705_34706 : H12AffineEnvironment.transform 13 5376 env34705 = env34706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34705 == env34706) = true)

theorem identity34706 : scanCanonicalize (H12AffineFastState.compose env34706 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound34706 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13509,10281,1024,8660,4161,4194304,16,3,8328,65,4270123,79131,4096,10281,75222,4268163,256,73770,79195,513]

theorem envBound34707 : H12AffineFastState.Bounded env34707 := by
  intro p hp
  have h : env34707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34706_34707 : H12AffineEnvironment.transform 16 13509 env34706 = env34707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env34706 == env34707) = true)

theorem identity34707 : scanCanonicalize (H12AffineFastState.compose env34707 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34707 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env34708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13509,10281,1024,8660,4161,4194304,16,3,8328,65,4196384,5392,4096,10281,1501,4194440,256,33,5456,513]

theorem envBound34708 : H12AffineFastState.Bounded env34708 := by
  intro p hp
  have h : env34708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34707_34708 : H12AffineEnvironment.transform 15 8203 env34707 = env34708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34707 == env34708) = true)

theorem identity34708 : scanCanonicalize (H12AffineFastState.compose env34708 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 249) := by decide +kernel

theorem selectedBound34708 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13509,10281,1024,8660,4161,249,16,3,8328,65,2265,5392,4096,10281,1501,113,256,33,5456,513]

theorem envBound34709 : H12AffineFastState.Bounded env34709 := by
  intro p hp
  have h : env34709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34708_34709 : H12AffineEnvironment.transform 21 249 env34708 = env34709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 249 env34708 == env34709) = true)

theorem identity34709 : scanCanonicalize (H12AffineFastState.compose env34709 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound34709 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,478,5392,2556,1024,1,4161,249,16,3,349,65,2265,5392,4096,2556,1501,113,256,33,5456,513]

theorem envBound34710 : H12AffineFastState.Bounded env34710 := by
  intro p hp
  have h : env34710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34709_34710 : H12AffineEnvironment.transform 12 469 env34709 = env34710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env34709 == env34710) = true)

theorem identity34710 : scanCanonicalize (H12AffineFastState.compose env34710 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34710 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env34711 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,0,399,5392,2477,1024,1,4112,168,16,3,268,16,2184,5392,4096,2477,1420,32,256,33,5377,513]

theorem envBound34711 : H12AffineFastState.Bounded env34711 := by
  intro p hp
  have h : env34711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34710_34711 : H12AffineEnvironment.transform 5 17 env34710 = env34711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34710 == env34711) = true)

theorem identity34711 : scanCanonicalize (H12AffineFastState.compose env34711 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound34711 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34712 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2232,388,3512,0,399,3496,2477,1024,1,2216,168,16,3,268,16,2184,3496,2232,2477,1420,32,256,33,3513,513]

theorem envBound34712 : H12AffineFastState.Bounded env34712 := by
  intro p hp
  have h : env34712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34711_34712 : H12AffineEnvironment.transform 11 2232 env34711 = env34712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env34711 == env34712) = true)

theorem identity34712 : scanCanonicalize (H12AffineFastState.compose env34712 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 920) := by decide +kernel

theorem selectedBound34712 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env34713 : List Nat := [2,4,8,16,32,17,128,256,512,920,2048,2232,388,2592,0,399,2608,2477,920,1,2216,168,16,3,268,16,2184,2608,2232,2477,532,32,256,33,2593,513]

theorem envBound34713 : H12AffineFastState.Bounded env34713 := by
  intro p hp
  have h : env34713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34712_34713 : H12AffineEnvironment.transform 9 920 env34712 = env34713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env34712 == env34713) = true)

theorem identity34713 : scanCanonicalize (H12AffineFastState.compose env34713 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound34713 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34714 : List Nat := [2,4,8,16,32,17,41,256,512,817,2048,2065,301,2592,0,294,2608,2308,817,1,2049,1,16,3,268,16,2081,2608,2065,2308,532,32,256,33,2593,513]

theorem envBound34714 : H12AffineFastState.Bounded env34714 := by
  intro p hp
  have h : env34714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34713_34714 : H12AffineEnvironment.transform 6 41 env34713 = env34714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env34713 == env34714) = true)

theorem identity34714 : scanCanonicalize (H12AffineFastState.compose env34714 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound34714 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env34715 : List Nat := [2,4,8,16,32,17,41,256,276,37,2048,2065,301,2356,0,294,2340,2308,37,1,2049,1,16,3,268,16,2081,2340,2065,2308,256,32,256,33,2357,277]

theorem envBound34715 : H12AffineFastState.Bounded env34715 := by
  intro p hp
  have h : env34715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34714_34715 : H12AffineEnvironment.transform 8 276 env34714 = env34715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env34714 == env34715) = true)

theorem identity34715 : scanCanonicalize (H12AffineFastState.compose env34715 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34715 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env34716 : List Nat := [2,4,8,16,17,17,24,256,276,20,2048,2065,284,2309,0,279,2325,2308,20,1,2049,1,16,3,268,16,2064,2325,2065,2308,256,17,256,16,2308,277]

theorem envBound34716 : H12AffineFastState.Bounded env34716 := by
  intro p hp
  have h : env34716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34715_34716 : H12AffineEnvironment.transform 4 17 env34715 = env34716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34715 == env34716) = true)

theorem identity34716 : scanCanonicalize (H12AffineFastState.compose env34716 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34716 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env34717 : List Nat := [2,4,8,16,17,17,24,20,0,20,2048,2065,8,2065,0,3,2049,2064,20,1,2049,1,16,3,24,16,2064,2049,2065,2064,20,17,20,16,2064,1]

theorem envBound34717 : H12AffineFastState.Bounded env34717 := by
  intro p hp
  have h : env34717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34716_34717 : H12AffineEnvironment.transform 7 20 env34716 = env34717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34716 == env34717) = true)

theorem identity34717 : scanCanonicalize (H12AffineFastState.compose env34717 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34717 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34718 : List Nat := [2,4,8,16,17,17,24,20,0,20,1,16,8,16,0,3,0,17,20,1,0,1,16,3,24,16,17,0,16,17,20,17,20,16,17,1]

theorem envBound34718 : H12AffineFastState.Bounded env34718 := by
  intro p hp
  have h : env34718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34717_34718 : H12AffineEnvironment.transform 10 1 env34717 = env34718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34717 == env34718) = true)

theorem identity34718 : scanCanonicalize (H12AffineFastState.compose env34718 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34718 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env34719 : List Nat := [2,4,8,1,0,0,9,5,0,5,1,1,8,1,0,3,0,0,5,1,0,1,1,3,9,1,0,0,1,0,5,0,5,1,0,1]

theorem envBound34719 : H12AffineFastState.Bounded env34719 := by
  intro p hp
  have h : env34719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34718_34719 : H12AffineEnvironment.transform 3 1 env34718 = env34719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34718 == env34719) = true)

theorem identity34719 : scanCanonicalize (H12AffineFastState.compose env34719 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34720 : List Nat := [2,4,2,1,0,0,3,5,0,5,1,1,2,1,0,3,0,0,5,1,0,1,1,3,3,1,0,0,1,0,5,0,5,1,0,1]

theorem envBound34720 : H12AffineFastState.Bounded env34720 := by
  intro p hp
  have h : env34720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34719_34720 : H12AffineEnvironment.transform 2 2 env34719 = env34720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34719 == env34720) = true)

def env34721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138476,1024,8661,4161,4194304,16,2,8328,65,4270122,79131,4097,10281,75222,4268163,256,73771,79194,513]

theorem envBound34721 : H12AffineFastState.Bounded env34721 := by
  intro p hp
  have h : env34721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34705_34721 : H12AffineEnvironment.transform 13 5377 env34705 = env34721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34705 == env34721) = true)

theorem identity34721 : scanCanonicalize (H12AffineFastState.compose env34721 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound34721 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,10401,1024,8661,4161,4194304,16,2,8328,65,4270122,79131,4097,10281,75222,4268163,256,73771,79194,513]

theorem envBound34722 : H12AffineFastState.Bounded env34722 := by
  intro p hp
  have h : env34722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34721_34722 : H12AffineEnvironment.transform 16 13389 env34721 = env34722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env34721 == env34722) = true)

theorem identity34722 : scanCanonicalize (H12AffineFastState.compose env34722 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound34722 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env34723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,10401,1024,8661,4161,73770,16,2,8328,65,2048,79131,4097,10281,75222,169,256,73771,79194,513]

theorem envBound34723 : H12AffineFastState.Bounded env34723 := by
  intro p hp
  have h : env34723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34722_34723 : H12AffineEnvironment.transform 21 73770 env34722 = env34723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env34722 == env34723) = true)

theorem identity34723 : scanCanonicalize (H12AffineFastState.compose env34723 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34723 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env34724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13389,10401,1024,8661,4161,33,16,2,8328,65,2048,5392,4097,10281,1501,169,256,32,5457,513]

theorem envBound34724 : H12AffineFastState.Bounded env34724 := by
  intro p hp
  have h : env34724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34723_34724 : H12AffineEnvironment.transform 15 8203 env34723 = env34724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34723 == env34724) = true)

theorem identity34724 : scanCanonicalize (H12AffineFastState.compose env34724 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34724 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,216,263,5441,2477,1024,217,4161,33,16,2,388,65,2048,5392,4097,2341,1501,169,256,32,5457,513]

theorem envBound34725 : H12AffineFastState.Bounded env34725 := by
  intro p hp
  have h : env34725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34724_34725 : H12AffineEnvironment.transform 12 268 env34724 = env34725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34724 == env34725) = true)

theorem identity34725 : scanCanonicalize (H12AffineFastState.compose env34725 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34725 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,263,5441,2341,1024,81,4161,33,16,2,268,65,2048,5392,4097,2341,1365,33,256,32,5457,513]

theorem envBound34726 : H12AffineFastState.Bounded env34726 := by
  intro p hp
  have h : env34726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34725_34726 : H12AffineEnvironment.transform 6 8 env34725 = env34726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34725 == env34726) = true)

theorem identity34726 : scanCanonicalize (H12AffineFastState.compose env34726 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34726 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34727 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5237,80,115,5173,2129,1024,81,4161,33,16,2,120,65,2048,5220,4097,2129,1057,33,116,32,5157,513]

theorem envBound34727 : H12AffineFastState.Bounded env34727 := by
  intro p hp
  have h : env34727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34726_34727 : H12AffineEnvironment.transform 7 116 env34726 = env34727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34726 == env34727) = true)

theorem identity34727 : scanCanonicalize (H12AffineFastState.compose env34727 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34727 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env34728 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4112,33,16,2,41,16,2048,5173,4097,2048,1057,33,37,32,5157,513]

theorem envBound34728 : H12AffineFastState.Bounded env34728 := by
  intro p hp
  have h : env34728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34727_34728 : H12AffineEnvironment.transform 5 17 env34727 = env34728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34727 == env34728) = true)

def env34729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound34729 : H12AffineFastState.Bounded env34729 := by
  intro p hp
  have h : env34729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34530_34729 : H12AffineEnvironment.transform 18 1025 env34530 = env34729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env34530 == env34729) = true)

theorem identity34729 : scanCanonicalize (H12AffineFastState.compose env34729 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444795) := by decide +kernel

theorem selectedBound34729 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444795,16777216,8328,65,23236091,18973837,333994,2330106,19188203,23160257,257,17074519,17066226,19263037]

theorem envBound34730 : H12AffineFastState.Bounded env34730 := by
  intro p hp
  have h : env34730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34729_34730 : H12AffineEnvironment.transform 22 2444795 env34729 = env34730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444795 env34729 == env34730) = true)

def env34731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,16777216,8328,65,16959643,18973837,333994,2330106,19188203,16851105,257,17074519,17066226,19263037]

theorem envBound34731 : H12AffineFastState.Bounded env34731 := by
  intro p hp
  have h : env34731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34730_34731 : H12AffineEnvironment.transform 21 2114912 env34730 = env34731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env34730 == env34731) = true)

def env34732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431208,8328,65,2609267,302181,333994,2330106,119043,2373705,257,2199999,2191386,63189]

theorem envBound34732 : H12AffineFastState.Bounded env34732 := by
  intro p hp
  have h : env34732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34731_34732 : H12AffineEnvironment.transform 23 2431208 env34731 = env34732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env34731 == env34732) = true)

def env34733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329896,8328,65,507955,302181,333994,236986,119043,272393,257,98815,90202,63189]

theorem envBound34733 : H12AffineFastState.Bounded env34733 := by
  intro p hp
  have h : env34733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34732_34733 : H12AffineEnvironment.transform 20 4160 env34732 = env34733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34732 == env34733) = true)

theorem identity34733 : scanCanonicalize (H12AffineFastState.compose env34733 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound34733 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,21792,351675,329896,8328,65,472295,288945,333994,223598,75223,272393,257,95531,90202,513]

theorem envBound34734 : H12AffineFastState.Bounded env34734 := by
  intro p hp
  have h : env34734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34733_34734 : H12AffineEnvironment.transform 14 29908 env34733 = env34734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env34733 == env34734) = true)

def env34735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,21792,351539,329760,8192,65,472175,288825,333858,223598,75103,272393,257,95531,90202,513]

theorem envBound34735 : H12AffineFastState.Bounded env34735 := by
  intro p hp
  have h : env34735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34734_34735 : H12AffineEnvironment.transform 6 8 env34734 = env34735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34734 == env34735) = true)

theorem identity34735 : scanCanonicalize (H12AffineFastState.compose env34735 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound34735 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env34736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1025,29789,4160,21792,351539,329760,8192,65,283764,288825,333858,2421,75103,272393,257,95531,90202,513]

theorem envBound34736 : H12AffineFastState.Bounded env34736 := by
  intro p hp
  have h : env34736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34735_34736 : H12AffineEnvironment.transform 16 90139 env34735 = env34736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env34735 == env34736) = true)

theorem identity34736 : scanCanonicalize (H12AffineFastState.compose env34736 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound34736 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env34737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12393,1077,65536,69746,262144,1025,1076,4160,9545,339290,329760,8192,65,271389,268368,333858,2421,75103,272393,257,66882,69683,513]

theorem envBound34737 : H12AffineFastState.Bounded env34737 := by
  intro p hp
  have h : env34737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34736_34737 : H12AffineEnvironment.transform 13 12393 env34736 = env34737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env34736 == env34737) = true)

theorem identity34737 : scanCanonicalize (H12AffineFastState.compose env34737 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound34737 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env34738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12393,1077,65536,69746,2129,1025,1076,4160,9545,75019,65649,8192,65,11340,4097,69747,2421,75103,8280,257,66882,69683,513]

theorem envBound34738 : H12AffineFastState.Bounded env34738 := by
  intro p hp
  have h : env34738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34737_34738 : H12AffineEnvironment.transform 17 2129 env34737 = env34738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env34737 == env34738) = true)

theorem identity34738 : scanCanonicalize (H12AffineFastState.compose env34738 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound34738 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12393,1077,9498,13672,2129,1025,1076,4160,9545,17,9579,8192,65,11340,4097,13673,2421,69,8280,257,8280,13609,513]

theorem envBound34739 : H12AffineFastState.Bounded env34739 := by
  intro p hp
  have h : env34739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34738_34739 : H12AffineEnvironment.transform 15 9498 env34738 = env34739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env34738 == env34739) = true)

theorem identity34739 : scanCanonicalize (H12AffineFastState.compose env34739 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound34739 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5376,1077,115,4097,2129,1025,1076,4160,32,17,2,1385,65,2341,4097,4096,2421,69,1329,257,1329,4160,513]

theorem envBound34740 : H12AffineFastState.Bounded env34740 := by
  intro p hp
  have h : env34740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34739_34740 : H12AffineEnvironment.transform 12 1385 env34739 = env34740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env34739 == env34740) = true)

theorem identity34740 : scanCanonicalize (H12AffineFastState.compose env34740 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound34740 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1329,4096,1385,5376,1077,115,4097,1376,1025,1076,4160,32,17,2,1385,65,1044,4097,4096,1092,69,1329,257,1329,4160,513]

theorem envBound34741 : H12AffineFastState.Bounded env34741 := by
  intro p hp
  have h : env34741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34740_34741 : H12AffineEnvironment.transform 10 1329 env34740 = env34741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env34740 == env34741) = true)

def env34742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,21792,351538,329761,8193,65,472174,288824,333859,223598,75102,272393,257,95531,90202,513]

theorem envBound34742 : H12AffineFastState.Bounded env34742 := by
  intro p hp
  have h : env34742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34734_34742 : H12AffineEnvironment.transform 6 9 env34734 = env34742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34734 == env34742) = true)

theorem identity34742 : scanCanonicalize (H12AffineFastState.compose env34742 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34742 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env34743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,65536,131072,262144,1025,21840,4160,21792,351538,329761,269,65,464226,280884,333859,215138,66642,264453,257,87079,82262,513]

theorem envBound34743 : H12AffineFastState.Bounded env34743 := by
  intro p hp
  have h : env34743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34742_34743 : H12AffineEnvironment.transform 12 268 env34742 = env34743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34742 == env34743) = true)

theorem identity34743 : scanCanonicalize (H12AffineFastState.compose env34743 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34743 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,65536,131072,262144,1025,81,4160,33,329779,329761,269,65,464226,269365,333859,204131,66642,264453,257,65830,70743,513]

theorem envBound34744 : H12AffineFastState.Bounded env34744 := by
  intro p hp
  have h : env34744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34743_34744 : H12AffineEnvironment.transform 13 5377 env34743 = env34744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34743 == env34744) = true)

theorem identity34744 : scanCanonicalize (H12AffineFastState.compose env34744 (packedSelected [0,7,16] rootPS)) = affineNative (2^(17+1) ^^^ 204082) := by decide +kernel

theorem selectedBound34744 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env34745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,65536,131072,204082,1025,81,4160,33,136449,136467,269,65,2128,196871,132369,204131,66642,201783,257,65830,70743,513]

theorem envBound34745 : H12AffineFastState.Bounded env34745 := by
  intro p hp
  have h : env34745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34744_34745 : H12AffineEnvironment.transform 17 204082 env34744 = env34745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204082 env34744 == env34745) = true)

theorem identity34745 : scanCanonicalize (H12AffineFastState.compose env34745 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound34745 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env34746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,65536,5392,67618,1025,81,4160,33,17,3,269,65,2128,70679,4097,67699,66642,65831,257,65830,70743,513]

theorem envBound34746 : H12AffineFastState.Bounded env34746 := by
  intro p hp
  have h : env34746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34745_34746 : H12AffineEnvironment.transform 16 5392 env34745 = env34746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env34745 == env34746) = true)

theorem identity34746 : scanCanonicalize (H12AffineFastState.compose env34746 (packedSelected [0,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 5655) := by decide +kernel

theorem selectedBound34746 : packedSelected [0,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,5655,5392,7733,1025,81,4160,33,17,3,269,65,2128,512,4097,7780,4677,5936,257,5937,576,513]

theorem envBound34747 : H12AffineFastState.Bounded env34747 := by
  intro p hp
  have h : env34747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34746_34747 : H12AffineEnvironment.transform 15 5655 env34746 = env34747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5655 env34746 == env34747) = true)

theorem identity34747 : scanCanonicalize (H12AffineFastState.compose env34747 (packedSelected [2,4,7,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound34747 : packedSelected [2,4,7,10,12] rootPS < 2^1333 := by decide +kernel

def env34748 : List Nat := [2,4,8,16,32,64,9,256,512,21,2048,4096,268,4372,80,4610,4357,6688,20,81,4160,33,17,3,269,65,2128,512,4097,6769,4677,4901,257,4900,576,513]

theorem envBound34748 : H12AffineFastState.Bounded env34748 := by
  intro p hp
  have h : env34748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34747_34748 : H12AffineEnvironment.transform 9 21 env34747 = env34748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34747 == env34748) = true)

theorem identity34748 : scanCanonicalize (H12AffineFastState.compose env34748 (packedSelected [2,3,4,5,7,15] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound34748 : packedSelected [2,3,4,5,7,15] rootPS < 2^1333 := by decide +kernel

def env34749 : List Nat := [2,4,8,16,32,64,9,256,512,21,2048,772,268,528,80,262,513,2340,20,81,836,33,17,3,269,65,2128,512,773,2421,321,33,257,32,576,513]

theorem envBound34749 : H12AffineFastState.Bounded env34749 := by
  intro p hp
  have h : env34749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34748_34749 : H12AffineEnvironment.transform 11 772 env34748 = env34749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env34748 == env34749) = true)

theorem identity34749 : scanCanonicalize (H12AffineFastState.compose env34749 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound34749 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34750 : List Nat := [2,4,8,16,32,64,9,256,276,21,2048,16,268,260,80,262,277,2340,20,81,80,33,17,3,269,65,2128,276,17,2421,321,33,257,32,340,277]

theorem envBound34750 : H12AffineFastState.Bounded env34750 := by
  intro p hp
  have h : env34750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34749_34750 : H12AffineEnvironment.transform 8 276 env34749 = env34750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env34749 == env34750) = true)

theorem identity34750 : scanCanonicalize (H12AffineFastState.compose env34750 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound34750 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34751 : List Nat := [2,4,8,16,32,64,9,256,276,21,341,16,268,260,80,262,277,113,20,81,80,33,17,3,269,65,261,276,17,32,321,33,257,32,340,277]

theorem envBound34751 : H12AffineFastState.Bounded env34751 := by
  intro p hp
  have h : env34751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34750_34751 : H12AffineEnvironment.transform 10 341 env34750 = env34751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env34750 == env34751) = true)

theorem identity34751 : scanCanonicalize (H12AffineFastState.compose env34751 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound34751 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34752 : List Nat := [2,4,8,16,32,64,9,101,113,21,48,16,105,97,80,99,112,113,20,81,80,33,17,3,104,65,96,113,17,32,36,33,100,32,49,112]

theorem envBound34752 : H12AffineFastState.Bounded env34752 := by
  intro p hp
  have h : env34752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34751_34752 : H12AffineEnvironment.transform 7 101 env34751 = env34752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env34751 == env34752) = true)

theorem identity34752 : scanCanonicalize (H12AffineFastState.compose env34752 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound34752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34753 : List Nat := [2,4,8,16,32,32,9,5,17,21,48,16,9,1,48,3,16,17,20,49,48,33,17,3,8,33,0,17,17,32,36,33,4,32,49,16]

theorem envBound34753 : H12AffineFastState.Bounded env34753 := by
  intro p hp
  have h : env34753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34752_34753 : H12AffineEnvironment.transform 5 32 env34752 = env34753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env34752 == env34753) = true)

def env34754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329897,8328,65,507954,302181,333994,236987,119043,272392,257,98814,90203,63189]

theorem envBound34754 : H12AffineFastState.Bounded env34754 := by
  intro p hp
  have h : env34754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34732_34754 : H12AffineEnvironment.transform 20 4161 env34732 = env34754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34732 == env34754) = true)

theorem identity34754 : scanCanonicalize (H12AffineFastState.compose env34754 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound34754 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,4161,21793,120015,98780,8328,65,215367,5392,102879,236987,119043,41341,257,98814,90203,63189]

theorem envBound34755 : H12AffineFastState.Bounded env34755 := by
  intro p hp
  have h : env34755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34754_34755 : H12AffineEnvironment.transform 17 35189 env34754 = env34755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env34754 == env34755) = true)

def env34756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1025,8661,4161,21793,95515,73736,8328,65,215367,5392,77835,212079,94423,169,257,73770,90203,22273]

theorem envBound34756 : H12AffineFastState.Bounded env34756 := by
  intro p hp
  have h : env34756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34755_34756 : H12AffineEnvironment.transform 14 8660 env34755 = env34756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env34755 == env34756) = true)

theorem identity34756 : scanCanonicalize (H12AffineFastState.compose env34756 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound34756 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,131072,10401,1025,8661,4161,21793,17,21762,8328,65,146509,5392,17665,149861,1501,169,257,21792,5457,22273]

theorem envBound34757 : H12AffineFastState.Bounded env34757 := by
  intro p hp
  have h : env34757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34756_34757 : H12AffineEnvironment.transform 15 29962 env34756 = env34757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env34756 == env34757) = true)

theorem identity34757 : scanCanonicalize (H12AffineFastState.compose env34757 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(16+1) ^^^ 13540) := by decide +kernel

theorem selectedBound34757 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env34758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,13540,10401,1025,8661,4161,21793,17,21762,8328,65,2217,5392,17665,32129,1501,169,257,21792,5457,22273]

theorem envBound34758 : H12AffineFastState.Bounded env34758 := by
  intro p hp
  have h : env34758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34757_34758 : H12AffineEnvironment.transform 16 13540 env34757 = env34758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13540 env34757 == env34758) = true)

def env34759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1025,8660,4161,21793,95514,73737,8328,65,215367,5392,77834,212078,94422,168,257,73771,90203,22272]

theorem envBound34759 : H12AffineFastState.Bounded env34759 := by
  intro p hp
  have h : env34759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34755_34759 : H12AffineEnvironment.transform 14 8661 env34755 = env34759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env34755 == env34759) = true)

theorem identity34759 : scanCanonicalize (H12AffineFastState.compose env34759 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34759 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34760 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,4161,21793,95514,73737,8193,65,215367,5392,77834,212078,94303,33,257,73771,90203,22272]

theorem envBound34760 : H12AffineFastState.Bounded env34760 := by
  intro p hp
  have h : env34760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34759_34760 : H12AffineEnvironment.transform 6 9 env34759 = env34760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34759 == env34760) = true)

theorem identity34760 : scanCanonicalize (H12AffineFastState.compose env34760 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound34760 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env34761 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24860,10281,1025,8541,4161,21793,95514,73737,8193,65,75867,5392,77834,89458,94303,33,257,73771,90203,22272]

theorem envBound34761 : H12AffineFastState.Bounded env34761 := by
  intro p hp
  have h : env34761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34760_34761 : H12AffineEnvironment.transform 16 24860 env34760 = env34761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env34760 == env34761) = true)

theorem identity34761 : scanCanonicalize (H12AffineFastState.compose env34761 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound34761 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env34762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,24860,10281,1025,8541,4161,21793,16,21763,8193,65,23889,5392,17664,10360,1365,33,257,21793,5457,22272]

theorem envBound34762 : H12AffineFastState.Bounded env34762 := by
  intro p hp
  have h : env34762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34761_34762 : H12AffineEnvironment.transform 15 29962 env34761 = env34762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env34761 == env34762) = true)

theorem identity34762 : scanCanonicalize (H12AffineFastState.compose env34762 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34762 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env34763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,262,5392,10281,1025,8541,4161,8493,16,8463,8193,65,10589,5392,12556,10360,1365,33,257,8493,5457,8972]

theorem envBound34763 : H12AffineFastState.Bounded env34763 := by
  intro p hp
  have h : env34763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34762_34763 : H12AffineEnvironment.transform 13 13324 env34762 = env34763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34762 == env34763) = true)

theorem identity34763 : scanCanonicalize (H12AffineFastState.compose env34763 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound34763 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env34764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6200,3124,6500,262,5392,4113,1025,6501,4161,6421,16,6455,6201,65,4453,5392,2356,4160,1365,33,257,6421,5457,6964]

theorem envBound34764 : H12AffineFastState.Bounded env34764 := by
  intro p hp
  have h : env34764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34763_34764 : H12AffineEnvironment.transform 12 6200 env34763 = env34764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env34763 == env34764) = true)

theorem identity34764 : scanCanonicalize (H12AffineFastState.compose env34764 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34764 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env34765 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,6200,3124,6452,262,5392,4113,1025,6453,4113,6421,16,6455,6201,17,4405,5392,2356,4112,1285,33,257,6421,5377,6964]

theorem envBound34765 : H12AffineFastState.Bounded env34765 := by
  intro p hp
  have h : env34765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34764_34765 : H12AffineEnvironment.transform 5 16 env34764 = env34765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34764 == env34765) = true)

theorem identity34765 : scanCanonicalize (H12AffineFastState.compose env34765 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34765 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34766 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,6200,3124,6161,35,5173,4113,1025,6160,4113,6192,16,6162,6201,17,4112,5173,2065,4112,1056,33,36,6192,5156,6673]

theorem envBound34766 : H12AffineFastState.Bounded env34766 := by
  intro p hp
  have h : env34766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34765_34766 : H12AffineEnvironment.transform 7 37 env34765 = env34766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34765 == env34766) = true)

theorem identity34766 : scanCanonicalize (H12AffineFastState.compose env34766 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound34766 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34767 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2080,24,3124,49,35,3093,2097,1025,48,2097,16,16,50,25,17,2096,3093,2065,2096,1056,33,36,16,3076,561]

theorem envBound34767 : H12AffineFastState.Bounded env34767 := by
  intro p hp
  have h : env34767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34766_34767 : H12AffineEnvironment.transform 11 2080 env34766 = env34767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env34766 == env34767) = true)

theorem identity34767 : scanCanonicalize (H12AffineFastState.compose env34767 (packedSelected [2,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34767 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env34768 : List Nat := [2,4,8,16,16,16,9,21,512,1024,2048,2064,24,3076,1,19,3093,2049,1025,0,2049,16,16,2,25,17,2048,3093,2065,2048,1040,17,20,16,3076,513]

theorem envBound34768 : H12AffineFastState.Bounded env34768 := by
  intro p hp
  have h : env34768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34767_34768 : H12AffineEnvironment.transform 4 16 env34767 = env34768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34767 == env34768) = true)

theorem identity34768 : scanCanonicalize (H12AffineFastState.compose env34768 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound34768 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34769 : List Nat := [2,4,8,16,16,16,9,21,512,21,2048,2064,24,2065,1,19,2048,2049,20,0,2049,16,16,2,25,17,2048,2048,2065,2048,5,17,20,16,2065,513]

theorem envBound34769 : H12AffineFastState.Bounded env34769 := by
  intro p hp
  have h : env34769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34768_34769 : H12AffineEnvironment.transform 9 21 env34768 = env34769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34768 == env34769) = true)

end H12CloudChart0